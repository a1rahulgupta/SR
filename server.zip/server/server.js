require('dotenv').config();
const express = require('express');
const methodOverride = require('method-override');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const nodeCache = require("node-cache");
const i18n = require("i18n");
const crypto = require('./app/utils/crypto');
const join = require('path').join;
const models = join(__dirname, 'app/api/v1/models');
const twilio = require('twilio');
const favicon = require('serve-favicon');

const http = require('http');

global.__rootRequire = function (relpath) {
  return require(path.join(__dirname, relpath));
};

global.__debug = function () {
  if (!process.env.NODE_ENV || process.env.NODE_ENV === 'local' || process.env.NODE_ENV === 'development' || process.env.NODE_ENV === 'aws') {
    console.log.apply(console, arguments);
  }
}

i18n.configure({
  // setup some locales - other locales default to the first locale
  locales: 'en',
  directory: __dirname + '/app/locales',
  updateFiles: false
});


const app = express();
// Bootstrap models
fs.readdirSync(models)
  .filter(file => ~file.search(/^[^\.].*\.js$/))
  .forEach(file => require(join(models, file)));

require('./app/config/database');

const server = require('http').Server(app);
const io = require('socket.io').listen(server);


const config = __rootRequire('app/config/config');
var usernames = {};
var videoCtrl = require('./app/api/v1/modules/video_call/controllers/video_call_ctrl.js');
videoCtrl.startSocket(io,usernames);

const port = process.env.PORT || config.port;

app.use(function (req, res, next) {
  i18n.init(req, res);
  next();
});


app.use(bodyParser.json({
  limit: '50mb'
}));
//parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({
  extended: true,
  limit: '50mb'
})); //The value can be a string or array (when extended is false), or any type (when extended is true).
app.use(methodOverride());
// view engine setup
app.engine('html', function (path, opt, fn) {
  fs.readFile(path, 'utf-8', function (error, str) {
    if (error) return str;
    return fn(null, str);
  });
});

app.set('view engine', 'html');
//app.set('views', path.join(__dirname, '../client/admin/index.html'));
//app.set('views', path.join(__dirname, '../client/frontend/index.html'));
//app.set("view options", {layout: false});
// app.use(express.static(path.join(__dirname, '../client')));
// app.use('/assets', express.static(path.join(__dirname, 'assets')));
app.use(express.static(path.join(__dirname, '/node_modules')));
app.use(express.static(path.join(__dirname, '../client')));
app.use(express.static(path.join(__dirname, '../client/users')));
app.use(express.static(path.join(__dirname, '../client/admin')))
app.use(favicon(path.join(__dirname, '../client/users/assets/images', 'favicon1.png')));

app.get('/', function (req, res, next) {
  res.sendFile(path.join(__dirname, '../client/users/index.html'));
});
app.get('/admin', function (req, res, next) {
  res.sendFile(path.join(__dirname, '../client/admin/index.html'));
});

app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, OPTIONS, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type, Authorization, Origin, Host, Accept, Origin, Referer, User-Agent');

  if (req.method == 'OPTIONS') {
    res.status(200).end();
  } else {
    next();
  }
});


app.get('/reset_pw/*', function (req, res, next) {
  let key = req.params && req.params[0] ? req.params[0] : null;
  res.redirect('/frontend/#/main/reset_pw/' + key)

})

app.get('/chat', function (req, res, next) {
  res.sendFile(path.join(__dirname + '../client/users/chat.html'));
})


app.use(function (req, res, next) {
  req.config = config;
  req.base_url = req.protocol + '://' + req.get('host');
  next();
})

// API's Routing
app.use('/api/v1', require('./app/api/v1/routes')(express));
app.use(logErrors);
app.use(clientErrorHandler);
app.use(errorHandler);

if (process.env.NODE_ENV === 'aws' || process.env.NODE_ENV === 'development' || process.env.NODE_ENV === 'local') {
  //client starts
  // app.use('/dist', express.static(path.join(__dirname, 'public/dist')));
  // app.use('/assets', express.static(path.join(__dirname, 'public/assets')));
  // app.use('/', function (req, res, next) {
  //   res.sendFile(path.join(__dirname, '../client/users/index.html'));
  // });
  //client ends
}

function logErrors(err, req, res, next) {
  console.error(err.stack)
  next(err)
}

function clientErrorHandler(err, req, res, next) {
  if (req.xhr) {
    res.status(500).send({
      error: i18n.__("INTERNAL_ERROR")
    })
  } else {
    next(err)
  }
}

function errorHandler(err, req, res, next) {
  if (res.headersSent) {
    return next(err)
  }
  res.status(500)
  res.render('error', {
    error: err
  })
}


function normalizePort(val) {
  const port = parseInt(val, 10);

  if (isNaN(port)) {
    // named pipe
    return val;
  }

  if (port >= 0) {
    // port number
    return port;
  }

  return false;
}

/**
 * Event listener for HTTP server "error" event.
 */

function onError(error) {
  if (error.syscall !== 'listen') {
    throw error;
  }

  const bind = typeof port === 'string' ?
    'Pipe ' + port :
    'Port ' + port;

  // handle specific listen errors with friendly messages
  switch (error.code) {
    case 'EACCES':
      console.error(bind + ' requires elevated privileges');
      process.exit(1);
      break;
    case 'EADDRINUSE':
      console.error(bind + ' is already in use');
      process.exit(1);
      break;
    default:
      throw error;
  }
}

/**
 * Event listener for HTTP server "listening" event.
 */

function onListening() {
  const addr = httpsServer.address();
  const bind = typeof addr === 'string' ?
    'pipe ' + addr :
    'port ' + addr.port;
  console.log('Listening on ' + bind);
}

app.use(function (req, res, next) {
    res.redirect(config.server_url+'#/page-not-found');
});
// start the server
server.listen(port);
__debug('Server started At ' + config.server_url + " ENV " + process.env.NODE_ENV);





