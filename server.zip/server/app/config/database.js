'use strict';

/* DB */
var mongoose = require('mongoose');
require('./../api/v1/models/user_model');
const cron = __rootRequire('app/utils/cron');


switch (process.env.NODE_ENV) {
    case 'local':
        var uri = process.env.LOCAL_DB_URI;
        var options = {
            user: process.env.LOCAL_DB_USER,
            pass: process.env.LOCAL_DB_PASS,
            promiseLibrary: require('bluebird')
        }
        break;
    case 'development':
        var uri = process.env.DEV_DB_URI;
        var options = {
            user: process.env.DEV_DB_USER,
            pass: process.env.DEV_DB_PASS,
            promiseLibrary: require('bluebird')
        }
        break;
    case 'aws':
        var uri = process.env.AWS_DB_URI;
        var options = {
            user: process.env.AWS_DB_USER,
            pass: process.env.AWS_DB_PASS,
            promiseLibrary: require('bluebird')
        }
        break;    
}

/**********Connect when local 172.10.1.7:27017 will not work. This connect to staging*****************/
// var uri = 'mongodb://52.34.207.5:27017/interpreter';
// var options = {
//     user: 'interpreter',
//     pass: 'iHjt32D890',
//     promiseLibrary: require('bluebird')
// }
/*********End*************************/

mongoose.connect(uri, options);
mongoose.Promise = global.Promise;

connect()
    .on('error', console.log)
    .on('disconnected', connect)
    .once('open', listen);

function connect() {
    return mongoose.connect(uri, options).connection;
}

function listen() {
    console.log('DB connected !');
    cron.cronStart();
    cron.cronPayment();
}
/* end DB */