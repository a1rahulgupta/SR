var config = {
  local: {
    options: {
      from: 'no-reply@mylanguagelink.com'
    },
    connectionURL: 'smtps://viralcontentsystem@gmail.com:viral@123@smtp.gmail.com',
    templatePath: __rootRequire('app/core/email/templates/')
  },
  development: {
    options: {
      from: 'no-reply@mylanguagelink.com'
    },
    connectionURL: 'smtps://viralcontentsystem@gmail.com:viral@123@smtp.gmail.com',
    templatePath: __rootRequire('app/core/email/templates/')
  },
  production: {
    options: {
      from: 'no-reply@mylanguagelink.com'
    },
    connectionURL: 'smtps://viralcontentsystem@gmail.com:viral@123@smtp.gmail.com',
    templatePath: __rootRequire('app/core/email/templates/')
  },
  aws: {
    options: {
      from: 'no-reply@mylanguagelink.com'
    },
    connectionURL: 'smtps://viralcontentsystem@gmail.com:viral@123@smtp.gmail.com',
    templatePath: __rootRequire('app/core/email/templates/')
  }
};


module.exports = config; 
