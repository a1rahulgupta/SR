var moment = require('moment');
var ENV = process.env.ENV || process.env.NODE_ENV || 'development';
var base_url, server_url;
if (ENV == 'development') {
    base_url = "http://52.34.207.5:5084";
    server_url = "http://52.34.207.5:5084"; //Staging server
} else if (ENV == 'aws') {
    base_url = "http://localhost:5084";
    server_url = "http://localhost:5084"; //AWS server
    //base_url = "https://www.interpreting.works";
    //server_url = "https://www.interpreting.works"; //AWS server
} else if (ENV == 'local') {
    base_url = "http://localhost:5084";
    server_url = "http://localhost:5084";
} else {

}

console.log(base_url)
console.log(server_url)
module.exports = {
    port: 5084,
    env: ENV,
    server_url: server_url,
    authPass: 'Pojmed2569Wer&dcLoi96523WerJioSwetWgPMbc',
    //tokenExpiryTime: '168 hours',
    tokenExpiryTime: '24 hours',
    //tokenExpiryTime: '1 minutes',
    secretKey: process.env.SALT_KEY,
    'MOMENT_DATE_TIME_FORMAT': 'YYYY-MM-DD HH:mm:ss',
    DATE_FORMAT: 'DD/MM/YYYY',
    TIME_FORMAT: 'HH12:MIAM',
    statusCode: {
        'error': '0',
        'success': '1',
        'badRequest': '2',
        'unauthorized': '3',
        'notFound': '4',
        'forbidden': '5',
        'invalid': '6',
        'serviceUnavailable': '7',
    },
    pattern: any = {
        'USERNAME': /[a-zA-Z0-9_]{3,15}$/ig,
        'NAME': /^[a-zA-Z . \-\']*$/,
        "CITY": /^[a-zA-Z . \-\']*$/,
        "EMAIL": /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
        "POSTAL_CODE": /(^\d{5}(-\d{4})?$)|(^[ABCEGHJKLMNPRSTVXY]{1}\d{1}[A-Z]{1} *\d{1}[A-Z]{1}\d{1}$)/, // /(^\d{5}$)|(^\d{5}-\d{4}$)/,
        "SUB_DOMAIN": /^[/a-z/A-Z][a-zA-Z0-9-]*[^/-/./0-9]$/,
        "PHONE_NO": /\(?\d{3}\)?-? *\d{3}-? *-?\d{4}/,
        "TASK_CODE": /^[0-9999]{1,4}$/,
        "SSN": /^((\d{3}-?\d{2}-?\d{4})|(X{3}-?X{2}-?X{4}))$/
    },
    email: {
        abuse_email: "support@interpreting.works",
        copyright: (new Date().getFullYear()) + " Copyright Language Link Corporation",
        logo_url: "/assets/images/logo_001.png",
        base_url: base_url
    },
    roles: {
        "super_admin": 1,
        "admin_staff": 2,
        "agency_admin": 3,
        "agency_user": 4,
        "interpreter": 5,
        "client": 6
    },
    role_type: {
        "SUPER_ADMIN": { id: 1, name: "super_admin", group: "super_admin" },
        "ADMIN_STAFF": { id: 2, name: "admin_staff", group: "admin_staff" },
        "AGENCY_ADMIN": { id: 3, name: "agency_admin", group: "agency" },
        "AGENCY_USER": { id: 4, name: "agency_staff", group: "agency" },
        "INTERPRETER": { id: 5, name: "interpreter", group: "interpreter" },
        "CLIENT": { id: 6, name: "client", group: "client" }
    },
    upload_dir: {
        "USER_PROFILE_PIC": "/assets/images/default-img.png",
        "BLOG_PIC": '/public/uploads/blogs/',
        "BLOG_CATEGORY_PIC": '/public/uploads/blogs/category/',
        "DEFAULT_MALE_PIC": '/public/assets/icons/male_avatar.png',
        "DEFAULT_FEMALE_PIC": '/assets/images/default-img.png',
        "DEFAULT_MALE_WHITE_PIC": '/public/assets/icons/male_avatar_white.png',
        "DEFAULT_FEMALE_WHITE_PIC": '/public/assets/icons/female_avatar_white.png',
        "COMPANY_LOGO_DIR": '/public/uploads/logos/',
        "DEFAULT_COMPANY_LOGO": '/public/assets/icons/default_logo.png',
        "DOCUMENTS_DIR": '/uploads/'
    },
    files: {
        MAX_IMG_SIZE: 20 * 2000 * 2000
    },
    page: {
        limit: 10,
        orderBy: 'created',
        sortDirection: 'desc'
    },
    email_templates: {
        EMAIL_SUBJECT_ACCOUNT_ACTIVATION: {
            id: 1,
            template_name: 'security_code_tmpl'
        },
        EMAIL_SUBJECT_INJURY_SHIFT_NOTIFICATION: {
            id: 2
        },
        EMAIL_SUBJECT_EHS_INVITE: {
            id: 3,
            template_name: 'ehs_user_invite_tmpl'
        },
        EMAIL_SUBJECT_IN_HOUSE_REFERRAL: {
            id: 4,
            template_name: 'in_house_referral_tmpl'
        },
        EMAIL_SUBJECT_PATIENT_MESSAGE: {
            id: 5,
            template_name: 'patient_message_tmpl'
        },

        EMAIL_SUBJECT_RESET_PASSWORD_CONFIRMATION: {
            id: 5
        },
        EMAIL_APPOINTMENT_SCHEDULE: {
            id: 6,
            template_name: 'appiontment _schedule_tmpl',
            subject: 'Your appointment has been scheduled.'
        },
        EMAIL_SUBJECT_ACCOUNT_ACTIVATION_PASSWORD: {
            id: 7,
            template_name: 'security_code_password_tmpl'
        },
        EMAIL_SUBJECT_ACCOUNT_ACTIVATION_CONFIRMATION: {
            id: 6
        },
        FORGOT_EMAIL_SENT: {
            id: 2,
            template_name: 'forgot_password_tmpl'
        },
        EMAIL_SUBJECT_ALERT_NOTIFICATION: {
            id: 30
        },
        EMAIL_SUBJECT_MANUAL_SHIFT_NOTIFICATION: {
            id: 31
        },
    },

    aws_ses : {
        accessKeyId : 'AKIAIRVNB6JIVO6NOSYQ',
        secretAccessKey : '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',
        region : 'us-east-1',
        fromName : 'Sachinelli <sachinelli@interpreting.works>'
    },

    //Send Sms through Twilio
    TWILIO_ACCOUNT_SID :'ACe4bca396fcc625235348318d2be36508',
    TWILIO_AUTH_TOKEN: '9c03c854c5643dd1651462f316ea88d8',
    TWILIO_FROM_NUMBER:'(234) 203-5097',
    isValidName: isValidName,
    isMobileNumber: isMobileNumber,
    isEmail: isEmail,
    isGender: isGender,
    isEmpty:isEmpty,
    generateShortId: generateShortId,
    isAddress: isAddress,
    isZipCode: isZipCode,
    isSpokenWritten: isSpokenWritten


};

function generateShortId() {
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

  for (var i = 0; i < 10; i++){
    text += possible.charAt(Math.floor(Math.random() * possible.length));

  }
    return text;
}

function isValidName(name) {
    return /^[a-zA-Z '-]+$/.test(name);
}

function isMobileNumber(phone) {
    return /^[+0-9]+$/.test(phone);
}

function isEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
}

function isGender(gender) {
    return (gender == "Male" || gender == "Female") ? true : false;
}

function isEmpty(data) {
    if (data && data !== null && data !== undefined && data !== '') {
        return false;
    } else {
        return true;
    }
}

function isAddress(address) {
    return /^[a-zA-Z0-9 .,'/:#-]+$/.test(address);
}

function isZipCode(zip) {
    return /^[A-Z0-9 ]+$/.test(zip);
}

function isSpokenWritten(spoken) {
    var arr = ['Native', 'Fluent', 'Good', 'Basic'];
    var count = 0;
    for(var i=0; i<arr.length;i++){
        if(arr[i] === spoken){
            count++;
            break;
        }
    }
    if(count == 0){
        return false;
    }else{
        return true;
    }
}
