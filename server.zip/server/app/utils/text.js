exports.capitalize = _capitalize;
exports.makeEmpty = _makeEmpty;
exports.isUrl = _isUrl;
exports.vitals = _vitals;

function _capitalize(text) {
  if (text) {
    return text.charAt(0).toUpperCase() + text.slice(1);
  }
  return text;
}


function _makeEmpty(data) {


  if (data instanceof Array) {

    for (var key in data) {
      if (data[key] instanceof Object) {

        data[key] = _makeEmpty(data[key]);

      } else {

        data[key] = data[key] == null ? "" : data[key];
      }
    }
  } else if (data instanceof Object) {

    Object.keys(data).forEach(function (key, i) {

      if (data[key] instanceof Object) {

        data[key] = _makeEmpty(data[key]);

      } else {

        data[key] = data[key] == null ? "" : data[key];
      }
    });

  }

  return data;
}

function _isUrl(str) {
  return new RegExp(/(https?:\/\/[^\s]+)/gi).test(str)
}

function _vitals(data) {

  let unit = {
    "blood_pressure": "mmHg",
    "height": "m",
    "weight": "Kg",
    "pulse": "bmp",
    "temperature": "&deg;C"
  };

  if (data instanceof Array) {

    for (var key in data) {
      if (data[key] instanceof Object) {

        data[key] = _vitals(data[key]);

      } else {
        
        data[key] = data[key] == null ? "" : data[key] + " " + (unit[key]!==undefined ? unit[key]:"");
      }
    }
  } else if (data instanceof Object) {

    Object.keys(data).forEach(function (key, i) {

      if (data[key] instanceof Object) {

        data[key] = _vitals(data[key]);

      } else { 

        
        if(key=='blood_pressure'){
          data[key] = (data['bp_systolic'] && data['bp_diastolic']) ? data['bp_systolic'] + "/" + data['bp_diastolic']  + " " + (unit[key]!==undefined ? unit[key]:"") :"";
        }else if(key=='bmi'){
            data[key] = data[key] == null ? "" : parseFloat(data[key]).toFixed(2) + " " + (unit[key]!==undefined ? unit[key]:"");
        }else{
          data[key] = data[key] == null ? "" : data[key] + " " + (unit[key]!==undefined ? unit[key]:"");
        }       
      }
    });

  }

  return data;



}