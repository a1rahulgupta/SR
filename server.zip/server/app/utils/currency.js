const formatCurrency = require('format-currency');
let options = {
    format: '%v %c',
    code: ''
}
exports.formatCurrency = _formatCurrency;
exports.formatMoneyAll = _formatMoneyAll;

function _formatCurrency(value, opts) {
    opts = opts || options;
    return formatCurrency(value, opts);
}

function _formatMoneyAll(data,fields) {
    if (!data && data.length == 0) {
        return false;
    }    
    fields = (fields instanceof Array) ? fields : [fields];
    if (data instanceof Array) {

        for (var key in data) {
            if (data[key] instanceof Object) {

                data[key] = _formatMoneyAll(data[key],fields);

            } else {
                if (fields.indexOf(key) !== -1)
                    data[key] = (data[key] == null || data[key]=='') ? 0.0 : __parseFloat(data[key]);
            }
        }
    } else if (data instanceof Object) {

        Object.keys(data).forEach(function (key, i) {

            if (data[key] instanceof Object) {

                data[key] = _formatMoneyAll(data[key],fields);

            } else {

                if (fields.indexOf(key) !== -1)
                    data[key] = (data[key] == null || data[key]=='') ? 0.0  : __parseFloat(data[key]);
            }
        });

    }

    return data;
}

function __parseFloat(number) {
    return  parseFloat(parseFloat(Math.round(number * 100) / 100).toFixed(2))
    
}