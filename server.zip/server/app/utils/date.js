/**
 * A collection of utility funtions to handle dates
 * @author Mohammad H.
 * @created 25 April, 2017
 */
exports.check = _check;
exports.humanitize = _humanitize;



function _check(date) {



    return date;
}


function _humanitize(time) {
    var t = {
        hour: 0,
        minute: 0
    };
    if (time) {
        time = time.split(":");

        if (time instanceof Array) {

            t.hour = time[0] + ((parseInt(time[0]) > 1) ? " hours" : " hour");
            t.minute = time[1] + ((parseInt(time[1]) > 1) ? " minutes" : " minute");;
        }
    }
    return t
}
