var smtpTransport = require('nodemailer-smtp-transport');
var nodemailer = require('nodemailer');
var path = require('path');
const jwt = require('jsonwebtoken');
//var ejs = require('ejs');
module.exports = {



    sendmail: function (to, mailSubject) {
        var linkToBeSend = "http" + ":" + "//localhost:5084/api/v1/clients/enterPassword"

        var smtpTransport = nodemailer.createTransport({
            service: 'Gmail',
            auth: {
                user: 'vishaka.renge14@gmail.com',
                pass: 'VISHAKA@14'
            }
        });
        var mailOptions = {
            to: to,
            from: 'Web Interpreter<vishaka.renge14@gmail.com>',
            subject: 'Change Password',
            html: "<p>Hi " + " " + ",</p>" +
                "<p>You have requested a password reset, so please click this link to continue</p>" +
                '<a href="' + linkToBeSend + '">Reset Password</a><br/>'
        };
        smtpTransport.sendMail(mailOptions, function (err, info) {
            if (err) {
                // if error while sending mail return control with err message
                console.log("Due to following error not able to send mail", "<mark>", err, "</mark>");
            }
            console.log('Message sent: ' + info.response);

        });


    },







}