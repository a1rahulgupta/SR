var jwt = require('jsonwebtoken');
var bcrypt = require('crypto');
var config = require('./../config/config');
var async = require('async');
var fs = require('fs');
var i18n = require("i18n");
var allowed = [
    '/agency/agencyRegisterEmailCheck',    
    '/subscription',
    '/agency/regestration',
    '/admin/login',
    '/user/login',
    '/user/practice_login',
    '/user/registration',
    '/user/practice_registration',
    '/user/send_code',
    '/user/resend_code',
    '/user/verify_code',
    '/user/send_code_practice',
    '/practice/search',
    '/user/forgot_user',
    '/user/sso_fb_login',
    '/user/sso_twitter_login',
    '/user/sso_linkedin_login',
    '/user/sso_googleplus_login',
    '/user/forgot_pw',
    '/user/activate_account',
    '/user/validate_link',
    '/user/reset_pw',
    '/getStateList',
    '/getCityList',
    '/user/getAccessControl',
    '/user/getDesignations',
    '/practice/getList',
    '/practice/deletePractice',
    '/user/getList',
    '/user/deleteUser',
    '/practice/enable',
    '/practice/disable',
    '/twilio/sendOtp',
    '/twilio/generateToken',
    '/practice/existing_practice',
    '/interpreters/setPassword',
    '/user/getEmailUsingKey/:id',
    '/user/completeUserRegistration',
    '/admin/subscribe'
    
];

module.exports = {
    ensureAuthorized: function (req, res, next) {
        if (allowed.indexOf(req.path) !== -1) {
            return next();
        }
        var bearerToken;
        var bearerHeader = req.headers["authorization"];
        if (typeof bearerHeader !== 'undefined') {
            var bearer = bearerHeader.split(" ");
            bearerToken = bearer[1];
            req.token = bearerToken;
            if (req.config.secretKey) {
                jwt.verify(bearerToken, req.config.secretKey, function (err, decoded) {
                    req.user = decoded;
                    if (err) {
                        res.json({
                            status: req.config.statusCode.unauthorized,
                            // data: {},
                            message: 'Invalid Token'
                        });
                    } else {
                        next();
                    }
                });
            } else {
                res.json({
                    status: req.config.statusCode.serviceUnavailable,
                    //error: err,
                    message: "Service is temporarily unavailable"
                });
            }

        } else {
            res.json({
                status: req.config.statusCode.unauthorized,
                message: 'Token is missing!'
            });
        }
    },
    ensureAccess: function (req, res, next) {
        if (req.user) {

            if (req.user.role.permissions != 'ALL') {
                if (req.user.role.permissions instanceof String)
                    var userPermissions = req.user.role.permissions.split(',');
                if (typeof req.modulesArray[req.path] != 'undefined') {
                    if (userPermissions.indexOf(String(req.modulesArray[req.path])) >= 0) {
                        next();
                    } else {
                        res.json({
                            status: req.config.statusCode.unauthorized,
                            message: "You are not authorized to access this module"
                        });
                    }
                } else {
                    res.json({
                        status: req.config.statusCode.authErr,
                        message: i18n.__("UN_AUTHORIZED")
                    });
                }
            } else {
                next();
            }

        } else {
            next();
        }
    },
    randomSecurityNumber: function () {
        return Math.floor(Math.random() * 99999);
    },
    randomString: function () {
        return Math.random().toString(36).slice(-8);
    },
    formatedRandomPassword: function(len){
          var length = (len)?(len):(6);
            var string = "abcdefghijkmnpqrstuvwxyz"; //to upper 
            var capital = "ABCDEFGHJKLMNPQRSTUVWXYZ"; //to upper 
            var numeric = '123456789';
            var punctuation = '!@#$';
            var password = "";
            var character = "";
            var crunch = true;
            while( password.length<length ) {
                entity1 = Math.ceil(string.length * Math.random()*Math.random());
                entity2 = Math.ceil(capital.length * Math.random()*Math.random());
                entity3 = Math.ceil(numeric.length * Math.random()*Math.random());
                entity4 = Math.ceil(punctuation.length * Math.random()*Math.random());
                hold = string.charAt( entity1 );
                //hold = (entity1%2==0)?(hold.toUpperCase()):(hold);
                character += hold;
                character += capital.charAt( entity2 );
                character += numeric.charAt( entity3 );
                character += punctuation.charAt( entity4 );
                password = character;
            }
            return password;
        },

   
    checkPracticePermission: function (req, res, next) {
        let practice_id = null;
        switch (req.user.role.role) {
            case 'practice':
            case 'practice_staff':
                practice_id = req.user.practice_id;
                break;
            default:
                return null;
        }
        return practice_id;
    },
    isEmail: function (email) {
        var regex = new RegExp(config.pattern.EMAIL);
        return regex.test(email);
    },
    //    generatePassword: function (myPlaintextPassword, callback) {
    //         this.getSecurityInfo('secratekey', function (err, securityData) {
    //             if (!err) {
    //                 //var salt = bcrypt.genSaltSync(8);
    //                 //var passwordHash  = bcrypt.hashSync(myPlaintextPassword, salt);
    //                 var salt = crypto.randomBytes(64).toString('base64');
    //                 var passwordHash = myPlaintextPassword + salt;
    //                 var cipher = crypto.createCipher(algorithm, securityData.key)
    //                 var crypted = cipher.update(passwordHash, 'utf8', 'hex')
    //                 var cryptedPassword = crypted + cipher.final('hex');
    //                 callback(null, salt, cryptedPassword, securityData);
    //             } else {
    //                 callback(err);
    //             }
    //         });
    //     },
    getSecurityInfo: function (type, callback) {
        var request = require('request');
        request.post({
            url: config.secureServerUrl + '/api/v1/gd',
            form: { 'type': type, pwd: config.authPass }
        }, function (err, httpResponse, body) {
            if (!err) {
                callback(null, JSON.parse(body).data);
            } else {
                callback(err);
            }
        });
    },

};

