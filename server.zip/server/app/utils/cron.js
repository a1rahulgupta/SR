const mongoose = require('mongoose');
const CronJob = require('cron').CronJob;
const moment = require('moment');
const User = mongoose.model('Users');
const ClientModel = mongoose.model('Clients');
const InterpreterModel = mongoose.model('Interpreters');
const emailSend = __rootRequire('app/core/email');
const async = require('async');
const RoleModel = mongoose.model('Roles');
const SubscriptionModel = mongoose.model('Subscriptions');
const CardDetailModel = mongoose.model('Card_details');
const PaymentModel = mongoose.model('Payments');
const AgencySubscriptionModel = mongoose.model('Agency_subscriptions');
const config = __rootRequire('app/config/config.js');

const voucher_codes = require('voucher-code-generator');
const stripe = require("stripe")('sk_test_v8sGUiDgrCVhulcdhOBLaedx');



module.exports = {
    cronStart : cronStart,
    cronPayment: cronPayment
}

function cronStart(){
    var resUser = {};
    function sendEmail(){
        console.log("in send mail");
        if(config.env == 'aws'){
            var baseUrl = 'https://www.interpreting.works';
        }else{
            var baseUrl = config.email.base_url;
        }
        var options = {
            template: 'set_password.html',
            repalcement: {
                "{{user.name}}": resUser.first_name.charAt(0).toUpperCase()+resUser.first_name.slice(1).toLowerCase()+ ' ' +resUser.last_name.charAt(0).toUpperCase()+resUser.last_name.slice(1).toLowerCase(),
                "{{user.email}}": resUser.email,
                "{{user.activation_key}}": baseUrl + '/#/setPassword/' + resUser.activation_key,
                "{{logo_url}}": baseUrl + config.email.logo_url,
                "{{copyright}}": config.email.copyright,
                "{{link.abuse_email}}": config.email.abuse_email
            },
            to: resUser.email,
            from:"Language Link <languagelink.noreply@interpreting.works>",
            subject: 'Complete Registration'
        };
        emailSend.smtp.sendMail(options, function (err, response) {
            if (err) {
                console.log("err in email send",err);
                // __debug(err)
            }else{
                console.log("response in email send:",response);
                
            }
        })
    }
    var job1 = new CronJob({
        cronTime: '0 */20 * * * *',
        onTick: function() {
            console.log("job 1 started");
            User.find({
                is_verification_email_send: false,
                is_deleted: false
            })
            .limit(50)
            .populate('role_id')
            .then((userData) => {
                console.log("userData",userData);
                async.eachSeries(userData,function(data,next){
                    setTimeout(function () {
                        resUser.user_id = data._id;
                        resUser.email = data.email;
                        resUser.activation_key = data.activation_key;
                        resUser.role = data.role_id.role;
                        switch(data.role_id.role){
                            case config.role_type.SUPER_ADMIN.name:
                            case config.role_type.ADMIN_STAFF.name:
                                next();
                            break;
                            case config.role_type.AGENCY_ADMIN.name:
                            case config.role_type.AGENCY_USER.name:
                                next();
                            break;
                            case config.role_type.CLIENT.name:
                                next();
                            break;
                            case config.role_type.INTERPRETER.name:
                                InterpreterModel.findOne({
                                    user_id:resUser.user_id
                                })
                                .then((interpreterData) => {
                                    if(!interpreterData){
                                        next();
                                    }else{
                                        resUser.id = interpreterData._id;
                                        resUser.first_name = interpreterData.first_name;
                                        resUser.last_name = interpreterData.last_name;
                                        
                                        User.findOneAndUpdate({
                                            _id: resUser.user_id
                                        }, {
                                            is_verification_email_send: true
                                        }, {
                                            new: true
                                        }).then((userUpdated) => {
                                            if(!userUpdated){
                                                console.log("error comes in updating record in database");
                                                next();
                                            }else{
                                                console.log("saved record");
                                                sendEmail();
                                                next();
                                            }
                                        })    
                                    }
                                    
                                })
                            break;
                        }
                    }, 10000);               
                },function(){
                    
                })
            })
        },
        start: false,
        timeZone: 'Asia/Kolkata'
    });
    // job1.start();

}

function cronPayment() {
    var job2 = new CronJob({
        cronTime: '* * * * *',
        onTick: function(req, res, next) {
            AgencySubscriptionModel.findOne({
                is_renewable: true,
                subscription_expiry_date: {
                    $lte: Date.now()
                }
            }).then((agencySubscriptionData) => {
                if(agencySubscriptionData){
                    CardDetailModel.findOne({
                        agency_id: agencySubscriptionData.agency_id
                    }).then((cardDetailData) => {
                        if(cardDetailData){
                            SubscriptionModel.findOne({
                                _id: agencySubscriptionData.subscription_id
                            }).then((subscriptionData) => {
                                if(subscriptionData){
                                    stripe.charges.create({
                                        amount: parseFloat(subscriptionData.amount * 100),
                                        // amount: parseFloat("100.00"), //Amount in cents i.e. 100.00 == $1.00
                                        currency: 'USD',
                                        description: "Renewable payment",
                                        customer: cardDetailData.customer_id
                                    }).then(function(cardPayment) {
                                        if(cardPayment){
                                            var paymentData = {};
                                            if (cardPayment.status == 'succeeded' || cardPayment.status == 'pending') {
                                                var invoiceCode = voucher_codes.generate({
                                                    prefix: "INV",
                                                    length: 4,
                                                    count: 1,
                                                    charset: "0123456789"
                                                })
                                                paymentData.status = cardPayment.status;
                                                paymentData = {
                                                    agency_id: agencySubscriptionData.agency_id,
                                                    subscription_id: subscriptionData._id,
                                                    card_detail_id: cardDetailData._id,
                                                    customer_id: cardDetailData.customer_id,
                                                    total_amount: subscriptionData.amount,
                                                    card_number: cardDetailData.card_no,
                                                    card_brand_name: cardDetailData.brand_name,
                                                    payment_date: moment().format(),
                                                    stripe_payment_id: cardPayment.id,
                                                    stripe_response_message: cardPayment.failure_message,
                                                    stripe_response_code: cardPayment.failure_code,
                                                    stripe_response_json: cardPayment,
                                                    payment_unique_id: invoiceCode[0]
                                                }
                                                var PaymentRecord = new PaymentModel(paymentData);
                                                PaymentRecord.save(function(err, paymentData) {
                                                    if (err) {
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: req.body,
                                                            message: i18n.__("ERROR")
                                                        })
                                                        // res.json({ code: 402, message: 'Request could not be processed. Please try again.', data: {} });
                                                    } else {
                                                        AgencySubscriptionModel.findOneAndUpdate({
                                                            _id: agencySubscriptionData._id
                                                        }, {
                                                            status: false,
                                                            is_renewable: false
                                                        }, {
                                                            new: true
                                                        }).then(function(agencySubscriptionUpdate) {
                                                            if (subscriptionData.interval == 'Monthly') {
                                                                var expiryDate = moment().add(1, 'months').format();
                                                            } else if (subscriptionData.interval == 'Quarterly') {
                                                                var expiryDate = moment().add(3, 'months').format();
                                                            } else if (subscriptionData.interval == 'Half-Yearly') {
                                                                var expiryDate = moment().add(6, 'months').format();
                                                            } else {
                                                                var expiryDate = moment().add(12, 'months').format();
                                                            }
                                                            var userPlanObj = {
                                                                agency_id: agencySubscriptionUpdate.agency_id,
                                                                subscription_id: subscriptionData._id,
                                                                plan_name: subscriptionData.plan_name,
                                                                plan_duration: subscriptionData.interval,
                                                                plan_amount: subscriptionData.amount,
                                                                video_service_charge: subscriptionData.video_service_charge,
                                                                charge_after_minutes: subscriptionData.charge_after_minutes,
                                                                booking_limit: subscriptionData.booking_limit,
                                                                subscription_expiry_date: expiryDate,
                                                                is_renewable: subscriptionData.is_renewable
                                                            };

                                                            var PlanRecord = new AgencySubscriptionModel(userPlanObj);
                                                            PlanRecord.save(function(err, userPlanData) {
                                                                if (err) {
                                                                    res.json({
                                                                        status: req.config.statusCode.error,
                                                                        data: req.body,
                                                                        message: i18n.__("ERROR")
                                                                    })
                                                                    // return res.json(Response(500, constant.validateMsg.internalError, err));
                                                                } else {
                                                                    var updatePayment = {
                                                                        agency_subscription_id: userPlanData._id
                                                                    };
                                                                    PaymentModel.findOneAndUpdate({
                                                                        _id: paymentData._id
                                                                    }, {
                                                                        $set: updatePayment
                                                                    }, {
                                                                        new: true
                                                                    }, function(err, isPaymentUpdated) {
                                                                        if (err) {
                                                                            res.json({
                                                                                status: req.config.statusCode.error,
                                                                                data: req.body,
                                                                                message: i18n.__("ERROR")
                                                                            })
                                                                        } else {
                                                                            AgencySubscriptionModel.findOneAndUpdate({
                                                                                    _id: userPlanData._id
                                                                                }, {
                                                                                    $set: {
                                                                                        payment_id: paymentData._id
                                                                                    }
                                                                                }, {
                                                                                    new: true
                                                                                })
                                                                                .lean()
                                                                                .exec(function(err, isPaymentDetailsUpdated) {
                                                                                    if (err) {
                                                                                        res.json({
                                                                                            status: req.config.statusCode.error,
                                                                                            data: req.body,
                                                                                            message: i18n.__("ERROR")
                                                                                        })
                                                                                    } else {
                                                                                        // res.json({
                                                                                        //     status: req.config.statusCode.success,
                                                                                        //     data: isPaymentDetailsUpdated,
                                                                                        //     message: i18n.__('Agency Renew successfully.')
                                                                                        // });
                                                                                    }
                                                                                });
                                                                        }
                                                                    })
                                                                }
                                                            })

                                                        })
                                                    }
                                                })

                                            }
                                        }
                                    })
                                }
                                
                            })
                        }
                        
                    })
                }
            }).catch(function(err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                })
            });
        },
    });
    job2.start(); 
}

