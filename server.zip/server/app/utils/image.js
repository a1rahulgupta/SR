

var config = __rootRequire('app/config/config');

var default_pic = config.upload_dir.DEFAULT_MALE_PIC;

exports.setImagePath = setImagePath;

// Set User profile picture path [Ref: http://jsfiddle.net/FM3qu/383/]
function setImagePath(attributes, field, dir) {
    field = field || 'profile_pic';
    dir = dir || config.upload_dir.USER_PROFILE_PIC;
    if (attributes instanceof Array) {
       
        for (var key in attributes) {
            if (attributes[key].hasOwnProperty('client_id') && attributes[key]['client_id'] instanceof Object) {
                // console.log("In client ..........")

                attributes[key]['client_id'] = setImagePath(attributes[key]['client_id'], field, dir);
            }

            if (attributes[key].hasOwnProperty('interpreter_id') && attributes[key]['interpreter_id'] instanceof Object) {
                //console.log("In caregiver ..........")
                attributes[key]['interpreter_id'] = setImagePath(attributes[key]['interpreter_id'], field, dir);
            }
            if (attributes[key].hasOwnProperty(field)) {
                //console.log(attributes)
                attributes[key][field] = _getImgPath(attributes[key], field, dir);
            }
            
            attributes[key][field] = _getImgPath(attributes[key], field, dir);
            
        }
    } else {

        if (attributes.hasOwnProperty(field)) {
            attributes[field] = _getImgPath(attributes, field, dir);

        }
    }
    return attributes;
}

function _getImgPath(attributes, field, dir) {
    dir = dir || config.upload_dir.USER_PROFILE_PIC;
    var gender = attributes['gender'];   
    switch (gender) {
        case 'male' || 'Male':
            default_pic = config.upload_dir.DEFAULT_MALE_PIC;
            default_white_pic = config.upload_dir.DEFAULT_MALE_WHITE_PIC;
            break;
        case 'female' || 'Female':
            default_pic = config.upload_dir.DEFAULT_FEMALE_PIC;
            default_white_pic = config.upload_dir.DEFAULT_FEMALE_WHITE_PIC;
            break;
        default:
            default_pic = config.upload_dir.DEFAULT_MALE_PIC;
            default_white_pic = config.upload_dir.DEFAULT_MALE_WHITE_PIC;
    }

    if (attributes[field]) {
        attributes[field] = config.server_url + dir + attributes[field];
        attributes['has_profile_pic'] = true;
    } else {
        attributes[field] = config.server_url + default_pic;
        attributes[field + "_white"] = config.server_url + default_white_pic;
        attributes['has_profile_pic'] = false;
    }
    return attributes[field];
}




function setImagePathBK(attributes, field) {
    var _ent = ['client', 'caregiver', 'user', 'company']

    for (var key in attributes) {

        if (attributes[key] && (attributes[key].hasOwnProperty('client') || attributes[key].hasOwnProperty('caregiver')
            || attributes[key].hasOwnProperty('user'))) {
            __debug(attributes[key]);
            return setImagePath(attributes[key], 'profile_pic');
        }


        if (attributes[key].hasOwnProperty(field)) {
            //__debug(attributes[key][field], field);
            var default_pic = config.upload_dir.DEFAULT_MALE_PIC;
            var gender = attributes[key]['gender'];
            switch (gender) {
                case 'male':
                    default_pic = config.upload_dir.DEFAULT_MALE_PIC;
                    break;
                case 'female':
                    default_pic = config.upload_dir.DEFAULT_FEMALE_PIC;
                    break;
                default:
                    attributes[key][field] = (attributes[key][field]) ?
                        config.server_url + config.upload_dir.USER_PROFILE_PIC + attributes[key][field]
                        : config.server_url + default_pic;

            }

        }

    }
    return attributes;
}



