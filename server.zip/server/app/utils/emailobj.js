var jwt = require('jsonwebtoken');
var Joi = require('joi');
var moment = require('moment');
var crypto = __rootRequire('app/utils/crypto');
var loader = __rootRequire('app/api/v1/loader');
var userModel = require('./../api/v1/modules/user/models/user_model');
var bcrypt = require('bcrypt');
var santize = __rootRequire('app/utils/santize');
var i18n = require("i18n");
var _ = require("lodash");
var file = __rootRequire('app/core/file');
var companyPModel = loader.loadModel('/company/models/company_profile_model');
var clientModel = loader.loadModel('/client/models/client_model');
var caregiverModel = loader.loadModel('/caregiver/models/caregiver_model');
var EmailTemplateModel = loader.loadModel('/email_template/models/email_template_model');
//var schedular = require('../../../core/schedular/schedular');

var schedular = require('./../core/schedular/schedular');


module.exports = {
    configEmailObj: function (email,req) {
        console.log(email,"email in obj")
        return new Promise(function (resolve, reject) {
       
            var user = {}, forgot_pw_key = null;

                    var uuidV4 = require('uuid/v4');
                    forgot_pw_key = uuidV4();
                    new userModel()
                        .where('email', email)
                        .fetch({
                            columns: ['id', 'email', 'first_name', 'last_name', 'role_id'],
                            withRelated: [
                                {
                                    role: function (qb) {
                                        qb.column('id', 'role');
                                    }
                                }
                            ]
                        })
                        .then(function (result) {
                            if (!result) throw i18n.__('INVALID_EMAIL', req.body.email);
                            user = result.toJSON();

                            return new userModel()
                                .off('updating') //This will remove updating event listeners
                                .where({ id: user.id, email: user.email })
                                .save({
                                    forgot_pw_key: forgot_pw_key,
                                    key_expiration: moment.utc().add(3, 'days').format(req.config.MOMENT_DATE_TIME_FORMAT)
                                }, { patch: true });

                        }).then(function (result) {
                            if (!result) throw new Error(i18n.__('INTERNAL_ERROR'))
                            return _.assign(result.toJSON(), user);

                        }).then(function (user) {

                            if (user.role.role == req.config.role_type.CAREGIVER.name) {
                                
                                return new caregiverModel()
                                    .where({ user_id: user.id }) //, is_deleted: 0
                                    .fetch()
                                    .then(function (caregiver) {
                                        if (!caregiver) throw i18n.__("ERROR");
                                        return caregiver = caregiver.toJSON();

                                    }).then(function (caregiver) {
                                        var company_id = caregiver.company_id;

                                        return new EmailTemplateModel()
                                            .query(function (qb) {
                                                qb.whereRaw("user_id  = (select user_id from company_profiles where id = ? limit 1) and template_name = ? ", [company_id, req.config.email_templates.FORGOT_EMAIL_SENT.id])
                                                    .then(function (email_template) {
                                                        console.log(email_template, "email tempalte 1")
                                                        return email_template;

                                                    });
                                            })
                                            .fetch()
                                    });
                            } else if (user.role.role == req.config.role_type.CLIENT.name) {
                                    console.log(user,"user")
                                return new clientModel()
                                    .where({ user_id: user.id }) //, is_deleted: 0
                                    .fetch()
                                    .then(function (client) {
                                        if (!client) throw i18n.__("ERROR");
                                        return client = client.toJSON();

                                    }).then(function (client) {
                                        var company_id = client.company_id;
                                        return new EmailTemplateModel()
                                            .query(function (qb) {
                                                qb.whereRaw("user_id  = (select user_id from company_profiles where id = ? limit 1) and template_name = ? ", [company_id, req.config.email_templates.FORGOT_EMAIL_SENT.id])
                                                    .then(function (email_template) {
                                                        console.log(email_template, "email tempalte 2")
                                                        return email_template;

                                                    });
                                            })
                                            .fetch()
                                    });
                            } else if (user.role.role == req.config.role_type.COMPANY.name) {

                                return new companyPModel()
                                    .where({ user_id: user.id })
                                    .fetch()
                                    .then(function (company) {
                                        if (!company) throw i18n.__("ERROR");
                                        return company = company.toJSON();
                                    }).then(function (company) {
                                        var company_id = company.user_id;
                                        return new EmailTemplateModel()
                                            .where({ user_id: company_id })
                                            .fetch()
                                            .then(function (email_template) {
                                                console.log(email_template,"email template_name")
                                                return email_template;
                                            })
                                    })
                            }


                        }).then(function(user){
                              console.log(user,"user in then")
                              return user;
                        })
                        .then(function (email_template) {

                            if (email_template && email_template.length > 0) {
                                return email_template;
                            }
                            return new EmailTemplateModel()
                                .where({
                                    user_id: req.config.role_type.SUPER_ADMIN.id,
                                    id: req.config.email_templates.FORGOT_EMAIL_SENT.id
                                })
                                .fetch();

                        }).then(function (user) {
                        
                            resolve(user)
                    
                        }).catch(function (err) {
                            __debug(err);
                           reject(err)
                        });
                });
                //end Model





    },



}