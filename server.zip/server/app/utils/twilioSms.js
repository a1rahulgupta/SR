var config = require('./../config/config.js');
console.log("asdfsafd",config.TWILIO_FROM_NUMBER);
var twilio = {};
const i18n = require("i18n");
const util = require('util');
const mongoose = require('mongoose');
const TwilioKeysModel = mongoose.model('Twilio_keys');

twilio.sendSMS = function sendSMS(data, callback) {
    TwilioKeysModel.findOne({
        status: true,
        is_deleted: false 
    }).exec(function(err, twilioKeys){
        if(twilioKeys){
            console.log("twilioKeys",twilioKeys);
            var fromNo = twilioKeys.toll_free_number  
            var toNo = data.to;
            var message = data.message;
            var client = require('twilio')(
                twilioKeys.accountSid,
                twilioKeys.authToken
            );
            client.messages.create({ 
                 from: fromNo,
                 to: toNo,
                 body: message
            }, function(err, message) {
                var smsObj = {}  
                if (err) {
                    console.log("smsobj error", err);
                    smsObj.status = '400';
                    smsObj.message = err;
                    callback(smsObj);  
                } else {
                    console.log("smsObj success", smsObj);
                    smsObj.status = '200';
                    smsObj.message = message;
                    callback(smsObj);
                }
            });      
        }
    })  
}

module.exports = twilio;
