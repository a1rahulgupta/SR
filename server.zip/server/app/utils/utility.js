var config = require('./../config/config');
var async = require('async');
var i18n = require("i18n");
var moment = require('moment');
require('moment-recur');

module.exports = {
    getDayString: getDayString,
    getMonthString: getMonthString,
    addHoursInDate: addHoursInDate,
    convertTo24Format: convertTo24Format,

    convertVirtualEventsDateIntoDateTime: function(startTime,endTime,stopTimeDateTime,startTimeOnly,endTimeOnly, month_start_date, month_end_date, interval, repeating_every_no, weekArray){    //function to find the recurring inetrvals:start/end            
        var recurringDateTimeStartEndOfEvent = [];      
          
        //start Event Calculation//
        var eventStartTime = startTimeOnly;
        var eventEndTime = endTimeOnly;

        var month_start_date = moment(month_start_date).startOf('day');
        var month_end_date = moment(month_end_date).startOf('day');
        var momentObjMonth_start_date = new Date(moment(month_start_date));
        var momentObjMonth_end_date = new Date(moment(month_end_date));

        var tmpStartTime = convertTo24Format(startTimeOnly);
        var tmpEndTime = convertTo24Format(endTimeOnly);
          
        var localStartDateTime =  moment(startTime).utc();
        var localEndDateTime = moment(endTime).utc();

        var localTimeStopTime =  moment(stopTimeDateTime).utc();                                         
        var startHours = new Date(localStartDateTime).getHours();
        var startMinutes = new Date(localStartDateTime).getMinutes();
        var startDayString = getDayString(new Date(localStartDateTime).getDay());
        var startDateOfMonth = new Date(localStartDateTime).getDate();
        var startMonthOfYear = getMonthString(new Date(localStartDateTime).getMonth());
        //end of event Calculation//

        var endHours = new Date(localEndDateTime).getHours();
        var endMinutes = new Date(localEndDateTime).getMinutes();
        var endDayString = getDayString(new Date(localEndDateTime).getDay());
        var endDateOfMonth = new Date(localEndDateTime).getDate();
        var endMonthOfYear = getMonthString(new Date(localEndDateTime).getMonth());

        if(interval == "daily"){
            var recurringDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(1).days();
            var recurringDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(1).days();
            if(recurringDatesForStart.all().length > 0){
                for(var i = 0 ; i<recurringDatesForStart.all().length; i++){ 
                    if(i%repeating_every_no == 0){
                        var recurringDateOnly =  recurringDatesForStart.all()[i];
                        recurringDateTimeStartEndOfEvent.push({
                            startEvent : addHoursInDate(recurringDateOnly, startHours, startMinutes),
                            endEvent : ""
                        });
                        recurringDateOnly = "";
                    }else{
                        continue;
                    }
                }
            }

            if(recurringDatesForEnd.all().length > 0){
                var z = 0;
                for(var j = 0 ; j<recurringDatesForEnd.all().length; j++){
                    if(j%repeating_every_no == 0){
                        var recurringDateEndOnly =  recurringDatesForEnd.all()[j];
                        recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringDateEndOnly, endHours, endMinutes),
                        recurringDateEndOnly = "";
                        z++;
                    }else{
                        continue;
                    }
                }
            }

        }else if(interval == "weekly"){
            var weekDayStartString = [];
            var weekDayEndString = [];
            weekDayStartString.push(startDayString);
            weekDayEndString.push(endDayString)
                                                
            var recurringWeeklyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(weekDayStartString).daysOfWeek();
            var recurringWeeklyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(weekDayEndString).daysOfWeek(); 
            if(recurringWeeklyDatesForStart.all().length > 0){

                for(var i = 0; i<recurringWeeklyDatesForStart.all().length; i++){
                    if(i%repeating_every_no == 0){
                        var recurringWeeklyDateOnly =  recurringWeeklyDatesForStart.all()[i];
                        recurringDateTimeStartEndOfEvent.push({
                            startEvent : addHoursInDate(recurringWeeklyDateOnly, startHours, startMinutes),
                            endEvent : ""
                        });
                        recurringWeeklyDateOnly = "";
                    }else{
                        continue;
                    }
                }
            }
            if(recurringWeeklyDatesForEnd.all().length > 0){
                var z = 0;
                for(var j = 0 ; j<recurringWeeklyDatesForEnd.all().length; j++){
                    if(j%repeating_every_no == 0){
                        var recurringWeeklyDateEndOnly =  recurringWeeklyDatesForEnd.all()[j];
                        recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringWeeklyDateEndOnly, endHours, endMinutes),
                        recurringWeeklyDateEndOnly = "";
                        z++;
                    }else{
                        continue;
                    }
                }
            } 
        }else if(interval == "custom (weekly)"){
            var weekDayStartString = weekArray;
            var weekDayEndString = weekArray;
            var arr = [];
            var array1d = [];
            var arr1d = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
            for(var u=0; u<arr1d.length; u++){
                if(weekArray.indexOf(arr1d[u]) != -1){
                    array1d.push(arr1d[u]);
                }
            }

            arr['sunday'] = 0;
            arr['monday'] = 1;
            arr['tuesday'] = 2;
            arr['wednesday'] = 3;
            arr['thursday'] = 4;
            arr['friday'] = 5;
            arr['saturday'] = 6;
            var len = weekArray.length;
            var recurringWeeklyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(weekDayStartString).daysOfWeek();
            var recurringWeeklyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(weekDayEndString).daysOfWeek(); 
            if(recurringWeeklyDatesForStart.all().length > 0){
                var t2,t3 = 0;
                for(var p=0; p < weekArray.length; p++){
                    t2 = getDayString(new Date(recurringWeeklyDatesForStart.all()[0]).getDay());
                    t3++;
                    if(arr[t2.toLowerCase()] <= arr[array1d[p].toLowerCase()] ){
                        break;
                    }
                }
                for(var i = t3; i <= recurringWeeklyDatesForStart.all().length; i++){
                    var recurringWeeklyDateOnly =  recurringWeeklyDatesForStart.all()[i-t3];
                    recurringDateTimeStartEndOfEvent.push({
                        startEvent : addHoursInDate(recurringWeeklyDateOnly, startHours, startMinutes),
                        endEvent : ""
                    });
                    recurringWeeklyDateOnly = "";
                    if( i%len  == 0 ){
                        var skip  = len*repeating_every_no - len;
                        i = i + skip; 
                    }
                }
            }
            if(recurringWeeklyDatesForEnd.all().length > 0){
                var t2,t3 = 0;
                for(var p=0; p < weekArray.length; p++){
                    t2 = getDayString(new Date(recurringWeeklyDatesForStart.all()[0]).getDay());
                    t3++;
                    if(arr[t2.toLowerCase()] <= arr[array1d[p].toLowerCase()] ){
                        break;
                    }
                }
                var z = 0;
                for(var j = t3 ; j <= recurringWeeklyDatesForEnd.all().length; j++){
                        var recurringWeeklyDateEndOnly =  recurringWeeklyDatesForEnd.all()[j-t3];
                        recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringWeeklyDateEndOnly, endHours, endMinutes),
                        recurringWeeklyDateEndOnly = "";
                        z++;
                    if(j%len  == 0 ){
                        var skip  = len*repeating_every_no - len;
                        j = j + skip;
                    }
                }
            } 
        }else if(interval == "monthly"){
            var recurringMonthlyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(startDateOfMonth).dayOfMonth();
            var recurringMonthlyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(endDateOfMonth).dayOfMonth();
            if(recurringMonthlyDatesForStart.all().length > 0){
                for(var i = 0 ; i<recurringMonthlyDatesForStart.all().length; i++){
                    if(i%repeating_every_no == 0){
                        var recurringMonthDateOnly =  recurringMonthlyDatesForStart.all()[i]
                        recurringDateTimeStartEndOfEvent.push({
                            startEvent :  addHoursInDate(recurringMonthDateOnly, startHours, startMinutes),
                            endEvent : ""
                        });
                        recurringMonthDateOnly = "";
                    }else{
                        continue;
                    }

                }
            }
            if(recurringMonthlyDatesForEnd.all().length > 0){
                var z = 0;
                for(var j = 0 ; j<recurringMonthlyDatesForEnd.all().length; j++){
                    if(j%repeating_every_no == 0){
                        var recurringMonthDateEndOnly =  recurringMonthlyDatesForEnd.all()[j];
                        recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringMonthDateEndOnly, endHours, endMinutes),
                        recurringMonthDateEndOnly = "";
                        z++;
                    }else{
                        continue;
                    }
                }
            }
        }else if(interval == "yearly"){ 
            var recurringYearlyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(startDateOfMonth).daysOfMonth().every(startMonthOfYear).monthsOfYear();
            var recurringYearlyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(endDateOfMonth).daysOfMonth().every(endMonthOfYear).monthsOfYear();
            if(recurringYearlyDatesForStart.all().length > 0){
                for(var i = 0 ; i<recurringYearlyDatesForStart.all().length; i++){
                    if(i%repeating_every_no == 0){
                        var recurringYearlyDateOnly =  recurringYearlyDatesForStart.all()[i]
                        recurringDateTimeStartEndOfEvent.push({
                          startEvent : addHoursInDate(recurringYearlyDateOnly, startHours, startMinutes),
                          endEvent : ""
                        });
                        recurringYearlyDateOnly = "";
                    }else{
                        continue;
                    }
                }
            }
            if(recurringYearlyDatesForEnd.all().length > 0){
                var z = 0;
                for(var j = 0 ; j<recurringYearlyDatesForEnd.all().length; j++){
                    if(j%repeating_every_no == 0){
                        var recurringYearlyDateEndOnly =  recurringYearlyDatesForEnd.all()[j];
                        recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringYearlyDateEndOnly, endHours, endMinutes),
                        recurringYearlyDateEndOnly = "";
                        z++;
                    }else{
                        continue;
                    }
                }
            }  
        }
        return recurringDateTimeStartEndOfEvent;          
    }


};

function getDayString(day){
    var dayString = ""
    switch (day) {
        case 0:
            dayString = "Sunday";
            break;
        case 1:
            dayString = "Monday";
            break;
        case 2:
            dayString = "Tuesday";
            break;
        case 3:
            dayString = "Wednesday";
            break;
        case 4:
            dayString = "Thursday";
            break;
        case 5:
            dayString = "Friday";
            break;
        case 6:
            dayString = "Saturday";
    }
    return dayString;
}

function getMonthString(month_no){
    var monthString = ""
    switch (month_no) {
        case 0:
            monthString = "January";
            break;
        case 1:
            monthString = "February";
            break;
        case 2:
            monthString = "March";
            break;
        case 3:
            monthString = "April";
            break;
        case 4:
            monthString = "May";
            break;
        case 5:
            monthString = "June";
            break;
        case 6:
            monthString = "July";
            break;
        case 7:
            monthString = "August";
            break;
        case 8:
            monthString = "September";
            break;
        case 9:
            monthString = "October";
            break;
        case 10:
            monthString = "November";
            break;
        case 11:
            monthString = "December";
            break;    
    }
    return monthString;
}

function addHoursInDate(recurringWeeklyDateOnly, startHours, startMinutes){
    var newRecurringWeeklyDateOnly = new Date(recurringWeeklyDateOnly);
    newRecurringWeeklyDateOnly.setHours(startHours);
    newRecurringWeeklyDateOnly.setMinutes(startMinutes);
    return moment(newRecurringWeeklyDateOnly);
}

function convertTo24Format(timeStr){
    var tmp=timeStr;
    var tmpArr = tmp.split(':');
    var t = tmpArr[1].split(' ')[1];
    var hour= tmpArr[0].trim();
    var minute= tmpArr[1].split(' ')[0];
    if(t=='PM'){
        if(hour!=12){
            hour = parseInt(hour) + 12;
        }
    } else if(t=='AM'){
        if(hour==12){
            hour=0;
        }
    }
    return { 'hour': hour, 'minute': minute};
}

