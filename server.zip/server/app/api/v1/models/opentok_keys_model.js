'use strict';

var mongoose = require('mongoose'),
    mongoosePaginate = require('mongoose-paginate');

var OpentokKeysSchema = mongoose.Schema({
    apiKey: {
        type: String
    },
    apiSecret: {
        type: String
    },
    is_deleted: {
        type: Boolean,
        default:false
    },
    status: {
        type: Boolean,
        default:true
    }
}, {
    timestamps: true
});

mongoose.model('Opentok_keys', OpentokKeysSchema);