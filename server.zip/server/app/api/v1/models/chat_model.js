'use strict';

const mongoose = require('mongoose');
const ChatSchema = mongoose.Schema({
    booking_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Bookings'
    },
    video_call_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Video_calls'
    },
    interpreter_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Interpreters'
    },
    client_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Clients'
    },
    sender_id: {
        type: String
    },
    receiver_id: {
        type: String
    },
    message: {
        type: String
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});
mongoose.model('Chats', ChatSchema);