'use strict';

const mongoose = require('mongoose'),
    crypto = require('crypto'),
    jwt = require('jsonwebtoken'),
    mongoosePaginate = require('mongoose-paginate');

const AdminSchema = mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    country_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Countries'
    },
    first_name: {
        type: String,
        required: true
    },
    last_name: {
        type: String,   
        required: true
    },
    profile_pic: {
        type: String
    },
    gender: {
        type: String
    },
     mobile_no: {
        type: String
        // required: true
    },
    alternate_no: {
        type: String
        // required: false
    },
    address1: {
        type: String
        // required: true
    },
    address2: {
        type: String
        // required: true
    },
    state: {
        type: String
        // required: true
    },
    city: {
        type: String
        // required: true
    },
    zip: {
        type: String
        // required: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    },
    status: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

mongoose.model('Admin', AdminSchema);