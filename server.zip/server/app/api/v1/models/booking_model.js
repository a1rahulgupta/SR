'use strict';

const mongoose = require('mongoose'),
mongoosePaginate = require('mongoose-paginate');
var BookingSchema = mongoose.Schema({
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies',
        required: true
    },
    client_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Clients',
        required: true
    },
    interpreter_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Interpreters'
    },
    contact_info: {
        type: String
    },
    service_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Services'
    },
    booking_id:{
        type:String
    },
    service_title: {
        type: String
    },
    language_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Languages'
    },
    booking_from: {
        type: Date,
        required: true
    },
    booking_to: {
        type: Date,
        required: true
    },
    working_from: {
        type: String
    },
    working_to: {
        type: String
    },
    booking_description: {
        type: String
    },
    notes: {
        type: String
    },
    lat: {
        type: String
    },
    lng: {
        type: String
    },
    address: {
        type: String
    },
    is_deleted: {
        type: Boolean,
        default: false
    },
    status: { 
        type: String,
        enum: ['pending', 'completed', 'canceled', 'in_process', 'closed'], default: 'pending' 
    },
    is_closed_by: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    is_canceled_by: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    }
}, {
    timestamps: true
});

mongoose.model('Bookings', BookingSchema);