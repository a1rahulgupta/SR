'use strict';

const mongoose = require('mongoose'),
    
mongoosePaginate = require('mongoose-paginate');

const RoleSchema = mongoose.Schema({
    role: {
        type: String,
        required: true
    },
    group: {
        type: String
    }
}, {
    timestamps: true
});
RoleSchema.plugin(mongoosePaginate);
mongoose.model('Roles', RoleSchema);