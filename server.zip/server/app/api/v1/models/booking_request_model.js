
'use strict';

const mongoose = require('mongoose'),
    mongoosePaginate = require('mongoose-paginate');

const BookingRequestSchema = mongoose.Schema({
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    booking_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Bookings'
    },
    interpreter_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Interpreters'
    },
    sent_to: {
        type: String
    },
    text: {
        type: String
    },
    request_token: {
        type: String
    },
    accept: {
        type: Boolean,
        default: false
    },
    status: {
          type: Boolean,
          default: true  
    }
}, {
     timestamps: true
});

mongoose.model('Booking_request', BookingRequestSchema);
