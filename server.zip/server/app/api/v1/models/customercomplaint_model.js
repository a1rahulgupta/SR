'use strict';

const mongoose = require('mongoose'),
    mongoosePaginate = require('mongoose-paginate');

const CustomercomplaintSchema = mongoose.Schema({
    booking_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Schedulers'
    },
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    client_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Clients'
    },
    interpreter_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Interpreters'
    },
    check_in_out_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Check_in_outs'
    },
    service_title: {
        type: String
    },
    booking_description: {
        type: String
    },
    complaint_comments: {
        type: String
    },
    status: { 
        type: String,
        enum: ['new', 'completed', 'canceled', 'in_process', 'closed'], 
        default: 'new' 
    },
    is_deleted: {
        type: Boolean,
        default: false
    },
}, {
     timestamps: true
});
CustomercomplaintSchema.plugin(mongoosePaginate);

mongoose.model('Customercomplaint', CustomercomplaintSchema);