'use strict';

const mongoose = require('mongoose'),
    
mongoosePaginate = require('mongoose-paginate');

const WebCallSchema = mongoose.Schema({
    agency_id: {
    	type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    booking_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Schedulers'
    },
    interpreter_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Interpreters'
    },
    client_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Clients'
    },
    sender_id: {
        type: String
    },
    receiver_id: {
        type: String
    },
    session_id: {
        type: String
    },
    token: {
        type: String
    },
    is_deleted: {
        type:Boolean,
        default: false
    },
    status: {
        type:Boolean,
        default: true  
    }
}, {
    timestamps: true
});
mongoose.model('Web_calls', WebCallSchema);