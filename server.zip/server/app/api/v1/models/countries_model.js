'use strict';

const mongoose = require('mongoose');
const CountrySchema = mongoose.Schema({
    country_name: {
        type: String,
        required:true
    },
    country_code: {
        type: String,
        required:true
    },
    status: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});
mongoose.model('Countries', CountrySchema);