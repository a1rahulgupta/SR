'use strict';

const mongoose = require('mongoose'),
      mongoosePaginate = require('mongoose-paginate');

const InterpreterSchema = mongoose.Schema({
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    first_name: {
        type: String,
        required: true
    },
    last_name: {
        type: String,
        required: true
    },
    interpreter_shortid: {
        type: String
    },
    profile_pic: {
        type: String
    },
    mobile_no: {
        type: String,
    },
    dob: {
        type: Date
    },
    age: {
        type: String
    },
    alternate_no: {
        type: String
    },
    gender: {
        type: String,
    },
    address1: {
        type: String
    },
    address2: {
        type: String
    },
    country_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Countries'
    },
    state: {
        type: String
    },
    city: {
        type: String
    },
    zip: {
        type: String
    },
    lat: {
        type: String
    },
    lng: {
        type: String
    },
    location:  {
        type: {
            type: String,
            default: "Point"
        },
        coordinates: {
            type: Array,
            default: [0,0]
        }                                    
    },                                    
    certificate: {
        type: Boolean,
        default: false
    },
    working_status: {
        type: String
    },
    working_from: {
        type: String
    },
    working_to: {
        type: String
    },
    working_days: {
        monday:         {type: Boolean, default: false},
        tuesday:        {type: Boolean, default: false},
        wednesday:      {type: Boolean, default: false},
        thursday:       {type: Boolean, default: false},
        friday:         {type: Boolean, default: false},
        saturday:       {type: Boolean, default: false},
        sunday:         {type: Boolean, default: false},
    },
    notes: {
        type: String
    },
    status: {
        type: Boolean,
        default: false  
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Interpreters', InterpreterSchema);