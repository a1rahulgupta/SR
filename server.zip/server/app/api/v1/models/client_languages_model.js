'use strict';

const mongoose = require('mongoose'),
      mongoosePaginate = require('mongoose-paginate');

const ClientLanguagesSchema = mongoose.Schema({
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    client_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Clients'  
    },
    language_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Languages'  
    },
    name:  {
        type: String
    },
    ticked: {
        type: Boolean,
        default: true
    }    
}, {
    timestamps: true
});

mongoose.model('Client_languages', ClientLanguagesSchema);