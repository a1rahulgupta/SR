'use strict';

const mongoose = require('mongoose'),
      mongoosePaginate = require('mongoose-paginate');

const InterpreterUnavailabelSchema = mongoose.Schema({
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    interpreter_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Interpreters'  
    },
    leave_date:  {
        type: Date,
        default: ''
    }, 
    leave_status: {
        type: Boolean,
        default: true
    }    
}, {
    timestamps: true
});

mongoose.model('Interpreter_unavailabels', InterpreterUnavailabelSchema);