'use strict';

const mongoose = require('mongoose'),
    
mongoosePaginate = require('mongoose-paginate');

const InterpreterCertificateSchema = mongoose.Schema({
    interpreter_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Interpreters'
    },
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    certificates: {
            court_certified: { 
            	type: String
           	},
            court_screened: { 
            	type: String
            }
    },
}, {
    timestamps: true
});

mongoose.model('Interpreter_certificates', InterpreterCertificateSchema);