'use strict';

const mongoose = require('mongoose'),
    mongoosePaginate = require('mongoose-paginate');

const PaymentSchema = mongoose.Schema({
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    subscription_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Subscriptions',
        default: null
    },
    agency_subscription_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agency_subscriptions'
    },
    card_detail_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'CardDetails',
        default: null
    },
    customer_id:  {
        type: String,
        default: null
    },
    payment_unique_id: {
        type: String,
        default: null
    },
    total_amount: {
        type: Number,
        default: null
    },
    card_number: {
        type: String,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
        default: null
    },
    card_brand_name: {
        type: String,
        default: null
    },
    payment_date: {
        type: Date,
        default: Date.now
    },
    stripe_payment_id:  {
        type: String,
        default: null
    },
    stripe_response_message: {
        type: Boolean,
        default: false
    },
    stripe_response_code: {
        type: String,
        default: null
    },
    stripe_response_json: {

    },
    status: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
    timestamps: true
});

var PaymentModel = mongoose.model('Payments',PaymentSchema);
module.exports = PaymentModel


