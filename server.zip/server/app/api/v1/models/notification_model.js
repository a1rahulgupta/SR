'use strict';

const mongoose = require('mongoose'),
    mongoosePaginate = require('mongoose-paginate');

const NotificationModelSchema = mongoose.Schema({
    role_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Role'
    },
    email: {
        type: String,
        required: true
    },
    hash: {
        type: String,
    },
    salt: {
        type: String,
    },
    last_login: {
        type: Date
    },
    forgot_request: {
        type: Date
    },
    forgot_token: {
        type: String,
    },
    status: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    },
    first_name: {
        type: String
    },
    last_name: {
        type: String
    },
    image: {
        type: String
    }
}, {
    timestamps: true
});

mongoose.model('Notifications', NotificationModelSchema);