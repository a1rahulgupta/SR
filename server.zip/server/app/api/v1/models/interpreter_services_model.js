'use strict';

const mongoose = require('mongoose'),
      mongoosePaginate = require('mongoose-paginate');

const InterpreterServicesSchema = mongoose.Schema({
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    interpreter_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Interpreters'  
    },
    service_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Services'  
    },
    name:  {
        type: String
    },
    ticked: {
        type: Boolean,
        default: true
    }    
}, {
    timestamps: true
});

mongoose.model('Interpreter_services', InterpreterServicesSchema);