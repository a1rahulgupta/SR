'use strict';

const mongoose = require('mongoose'),
    mongoosePaginate = require('mongoose-paginate');

const ClientSchema = mongoose.Schema({
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    country_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Countries'
    },
    first_name: {
        type: String,
        required: true
    },
    last_name: {
        type: String,
        required: true
    },
    client_shortid: {
        type: String
    },
    profile_pic: {
        type: String
    },
    mobile_no: {
        type: String,
    },
    dob: {
        type: Date
    },
    age: {
        type: String
    },
    alternate_no: {
        type: String
    },
    gender: {
        type: String
    },
    address1: {
        type: String
    },
    address2: {
        type: String
    },
    state: {
        type: String
    },
    city: {
        type: String
    },
    zip: {
        type: String
    },
    is_deleted: {
        type: Boolean,
        default: false
    },
    status: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

mongoose.model('Clients', ClientSchema);