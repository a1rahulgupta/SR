'use strict';

var mongoose = require('mongoose'),
    mongoosePaginate = require('mongoose-paginate');

var AgencySchema = mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    country_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Countries'
    },
    agency_type: {
        type: String
    },
    agency_name: {
        type: String
    },
    mobile_no: {
        type: String
    },
    alternate_no: {
        type: String
    },
    address1: {
        type: String
    },
    address2: {
        type: String
    },
    profile_pic: {
        type: String
    },
    state: {
        type: String
    },
    city: {
        type: String
    },
    zip: {
        type: String
    },
    is_deleted: {
        type: Boolean,
        default: false
    },
    notes: {
        type: String
    },
    status: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var AgencyModel = mongoose.model('Agencies', AgencySchema);