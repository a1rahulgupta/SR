'use strict';

const mongoose = require('mongoose'),
mongoosePaginate = require('mongoose-paginate');
var EventSchema = mongoose.Schema({
    event_name: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    },
    status: { 
        type: Boolean,
        default: true
    }    
}, {
    timestamps: true
});

mongoose.model('Events', EventSchema);