'use strict';

const mongoose = require('mongoose'),
    mongoosePaginate = require('mongoose-paginate');

const SubscribeEmailSchema = mongoose.Schema({
    email: {
        type: String,
        required: true,
        lowercase: true,
    },
    status: {
          type: Boolean,
          default: true  
    },
    is_deleted: {
        type: Boolean,
        default: false
    },
}, {
     timestamps: true
});

mongoose.model('Subscribe_email', SubscribeEmailSchema);
