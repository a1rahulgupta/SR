'use strict';

const mongoose = require('mongoose'),
      mongoosePaginate = require('mongoose-paginate');

const InterpreterLanguageSchema = mongoose.Schema({
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    interpreter_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Interpreters'  
    },
    language_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Languages'
    }, 
    spoken: {
        type: String
    },
    written: {
        type: String
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

mongoose.model('Interpreter_languages', InterpreterLanguageSchema);