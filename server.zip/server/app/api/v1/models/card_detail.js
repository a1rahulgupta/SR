'use strict';

const mongoose = require('mongoose'),
      mongoosePaginate = require('mongoose-paginate');

const CardDetailSchema = mongoose.Schema({
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    card_no:  {
        type: String
    }, 
    card_holder_name: {
        type: String
    },
    brand_name: {
        type: String
    },  
    customer_id:  {
        type: String
    }, 
    customer_response:  {

    }, 
    token: {
        type: String
    },
    is_default: {
        type: Boolean,
        default: false
    },
    status: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        true: Boolean,
        default: false
    }
}, {
    timestamps: true
});

mongoose.model('Card_details', CardDetailSchema);