'use strict';

const mongoose = require('mongoose'),
    crypto = require('crypto'),
    jwt = require('jsonwebtoken'),
    mongoosePaginate = require('mongoose-paginate');

const UserSchema = mongoose.Schema({
    role_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Roles'
    },
    email: {
        type: String,
        lowercase: true,
        required: false
    },
    password: {
        type: String,
    },
    last_login: {
        type: Date
    },
    forgot_request: {
        type: Date
    },
    change_request: {
        type: Date
    },
    forgot_token: {
        type: String,
    },
    activation_key: {
        type: String
    },
    status: {
        type: Boolean,
        default: false
    },
    is_verified: {
        type: Boolean,
        default: false
    },
    is_verification_email_send: {
        type: Boolean,
        default: false
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});
UserSchema.plugin(mongoosePaginate);


UserSchema.methods.setPassword = function (password) {
    this.salt = crypto.randomBytes(16).toString('hex');
    this.hash = crypto.pbkdf2Sync(password, this.salt, 1000, 64).toString('hex');
};
UserSchema.methods.createPassword = function (password) {
    const obj = {}
    obj.salt = crypto.randomBytes(16).toString('hex');
    obj.hash = crypto.pbkdf2Sync(password, obj.salt, 1000, 64).toString('hex');
    return obj;
};
UserSchema.methods.validPassword = function (password) {
    const hash = crypto.pbkdf2Sync(password, this.salt, 1000, 64).toString('hex');
    return this.hash === hash;
};

UserSchema.methods.generateJWT = function () {

    // set expiration to 60 days
    const today = new Date();
    const exp = new Date(today);
    exp.setDate(today.getDate() + 60);

    return jwt.sign({
        _id: this._id,
        username: this.username,
        exp: parseInt(exp.getTime() / 1000),
    }, config.SECRET);
};

UserSchema.statics.getUserByUsername = function (username, callback) {
    User.findOne({
        username: username,
        /*status: {
            $ne: false
        },*/
        deleted: {
            $ne: true
        }
    }, function (err, userdata) {
        if (err) {
            callback(err);
        } else {
            if (userdata !== null) {
                callback(null, userdata)
            } else {
                callback('No user found');
            }
        }
    });
};

/**
 * [getUsers - To check user exist or not ]
 * @param  {object} username
 * @param  {object} email
 * @param  {object} id // on update case id will not be blank as well as on add case it will be blank
 * @return {json}
 */
UserSchema.statics.existCheck = function (username, email, id, callback) {
    const where = {
        $or: [{
            username: new RegExp('^' + username + '$', "i")
        }, {
            email: new RegExp('^' + email + '$', "i")
        }],
        deleted: {
            $ne: true
        }
    };
    if (id) {
        where = {
            $or: [{
                username: new RegExp('^' + username + '$', "i")
            }, {
                email: new RegExp('^' + email + '$', "i")
            }],
            deleted: {
                $ne: true
            },
            username: {
                $ne: config.ADMIN_USERNAME
            },
            _id: {
                $ne: id
            }
        };
    }
    User.findOne(where, function (err, userdata) {
        if (err) {
            callback(err)
        } else {
            if (userdata) {
                callback(null, true);
            } else {
                callback(null, false);
            }
        }
    });
};
/*
 * Get User Listing
 */
UserSchema.statics.getUsers = function (page, callback) {
    const sortBy = {},
        where = {
            deleted: false
        };

    sortBy.updatedAt = -1;
    return User.paginate(where, {
        page: page,
        limit: 1,
        populate: [{
            path: 'group_id',
            select: 'title name',
            'match': {
                name: {
                    $ne: 'super_admin'
                }
            }
        }],
        sortBy: sortBy,
    }, callback);
};

UserSchema.statics.checkUserExist = function (email, userType, id, callback) {
    if (userType == 'driver') {
        const query = id == '' ? {
            username: email,
            deleted: false
        } : {
            username: email,
            deleted: false,
            driver_id: {
                $ne: id
            }
        }

    } else if (userType == 'owner') {
        const query = id == '' ? {
            username: email,
            deleted: false
        } : {
            username: email,
            deleted: false,
            owner_id: {
                $ne: id
            }
        }

    }
    User.findOne(query, function (err, driver) {
        if (err) {
            callback(err)
        } else {
            if (driver) {
                callback(null, true);
            } else {
                callback(null, false);
            }
        }
    })

}

mongoose.model('Users', UserSchema);