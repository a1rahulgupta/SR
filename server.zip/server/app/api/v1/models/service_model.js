'use strict';

const mongoose = require('mongoose'),
    mongoosePaginate = require('mongoose-paginate');

const ServiceSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    description: {
        type: String
    },
    status: {
          type: Boolean,
          default: true  
    },
    is_deleted: {
        type: Boolean,
        default: false
    },
}, {
     timestamps: true
});
ServiceSchema.plugin(mongoosePaginate);

mongoose.model('Services', ServiceSchema);
