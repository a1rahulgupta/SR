'use strict';

const mongoose = require('mongoose'),
    
mongoosePaginate = require('mongoose-paginate');

const CheckInOutSchema = mongoose.Schema({
    agency_id: {
    	type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    booking_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Schedulers'
    },
    interpreter_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Interpreters'
    },
    client_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Clients'
    },
    lat: {
        type: String
    },
    long: {
        type: String
    },
    radius: {
        type: Number
    },
    check_in_time: {
        type: String
    },
    check_out_time: {
        type: String
    },
    check_in_date: {
        type: Date
    },
    check_out_date: {
        type: Date
    },
    reason_manual: {
        type: String  
    },
    verification_type: { 
        type: String,
        enum: ['GPS', 'Manual'], default: 'GPS' 
    },
    verification_type_out: { 
        type: String,
        enum: ['GPS', 'Manual'], default: 'GPS' 
    },
    check_io_approval:{
        type: String,
        enum: ['approved', 'disapproved'], default: 'disapproved'
    },
    time_confirmation: {
        type: Boolean,
        default: false
    },
    time_confirmation_out: {
        type: Boolean,
        default: false
    },
    review:{
        type:String
    },
    rating: {
        type: Number
    },
    is_review_rating_done: {
        type: Boolean,
        default: false
    },
    is_complaint_lodge:{
        type: Boolean,
        default: false  
    },
    status: {
        type: Boolean,
        default: true  
    },
    is_deleted: {
        type: Boolean,
        default: false    
    }
}, {
    timestamps: true
});
mongoose.model('Check_in_outs', CheckInOutSchema);

