'use strict';

var mongoose = require('mongoose'),
    mongoosePaginate = require('mongoose-paginate');

var StripeKeysSchema = mongoose.Schema({
    publishable_key: {
        type: String
    },
    secret_key: {
        type: String
    },
    is_deleted: {
        type: Boolean,
        default:false
    },
    status: {
        type: Boolean,
        default:true
    }
}, {
    timestamps: true
});

mongoose.model('Stripe_keys', StripeKeysSchema);