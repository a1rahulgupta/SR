'use strict';

const mongoose = require('mongoose'),
      mongoosePaginate = require('mongoose-paginate');

const AgencySubscriptionSchema = mongoose.Schema({
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    subscription_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Subscriptions'
    },
    payment_id: {
        type: mongoose.Schema.Types.ObjectId,   
        ref: 'Payments'
    },
    plan_name:  {
        type: String,
        default: null
    }, 
    plan_description: {
        type: String,
        default: null
    },  
    plan_features: {
        type: Array,
        default: null
    },
    video_service_charge: {
        type: Number
    },
    charge_after_minutes: {
        type: Number
    },
    booking_limit: {
        type: Number
    },
    plan_duration:  {
        type: String,
        default: null
    }, 
    plan_amount:  {
        type: Number,
        default: null
    }, 
    is_renewable: {
        type: Boolean,
        default: true
    },
    subscription_expiry_date: {
        type: Date
    }, 
    status: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

mongoose.model('Agency_subscriptions', AgencySubscriptionSchema);