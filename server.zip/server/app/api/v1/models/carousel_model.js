'use strict';

var mongoose = require('mongoose'),
    mongoosePaginate = require('mongoose-paginate');

var CarouselSchema = mongoose.Schema({
    heading: {
        type: String
    },
    description: {
        type: String
    },
    image: {
        type: String
    },
    is_deleted: {
        type: Boolean,
        default: false
    },
    status: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var CarouselModel = mongoose.model('Carousels', CarouselSchema);