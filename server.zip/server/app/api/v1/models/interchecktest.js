// 'use strict';

// const mongoose = require('mongoose'),
//     mongoosePaginate = require('mongoose-paginate');

// const InterpreterSchema = mongoose.Schema({
//     agency_id: {
//         type: mongoose.Schema.Types.ObjectId,
//         ref: 'Agencies'
//     },
//     user_id: {
//         type: mongoose.Schema.Types.ObjectId,
//         ref: 'Users'
//     },
//     first_name: {
//         type: String,
//         required: true
//     },
//     last_name: {
//         type: String,
//         required: true
//     },
//     interpreter_shortid: {
//         type: String
//     },
//     profile_pic: {
//         type: String
//     },
//     mobile_no: {
//         type: String,
//     },
//     dob: {
//         type: Date
//     },
//     age: {
//         type: String
//     },
//     alternate_no: {
//         type: String
//     },
//     ssn: {
//         type: String
//     },
//     gender: {
//         type: String,
//     },
//     address1: {
//         type: String
//     },
//     address2: {
//         type: String
//     },
//     country: {
//         type: String
//     },
//     state: {
//         type: String
//     },
//     city: {
//         type: String
//     },
//     zip: {
//         type: String
//     },
//     certificate: {
//         type: Boolean,
//         default: false
//     },
//     languages: {
//         type: Array
//     },
//     working_status: {
//         type: String
//     },
//     working_from: {
//         type: String
//     },
//     working_to: {
//         type: String
//     },
//     services: {
//         type: Array
//     },
//     working_days: {
//         type: Array
//     },
//     is_deleted: {
//         type: Boolean,
//         default: false
//     },
//     notes: {
//         type: String
//     },
//     status: {
//         type: Boolean,
//         default: false  
//     }
// }, {
//     timestamps: true
// });

// mongoose.model('Interpreters', InterpreterSchema);