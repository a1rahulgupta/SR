'use strict';

var mongoose = require('mongoose'),
    mongoosePaginate = require('mongoose-paginate');

var SubscriptionSchema = mongoose.Schema({
    created_by: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Admin'
    },
    subscription_id: {
        type: String,
        required: true
    },
    plan_name: {
        type: String,
        required: true
    },
    plan_description: {
        type: String
    },
    plan_features: {
        type: Array,
        default: null
    },
    currency: {
        type: String, 
        default: 'USD'
    },
    amount: {
        type: Number
    },
    video_service_charge: {
        type: Number
    },
    charge_after_minutes: {
        type: Number
    },
    booking_limit: {
        type: Number
    },
    interval: {
        type: String,
        enum: ['Monthly', 'Quaterly', 'Half-Yearly', 'Yearly'], 
        default: 'Monthly'
    },
    is_renewable: {
        type: Boolean,
        default: true
    },
    // trial_period_days: {
    //     type: Number
    // },
    is_deleted: {
        type: Boolean,
        default:false
    },
    status: {
        type: Boolean,
        default:false
    }
}, {
    timestamps: true
});

mongoose.model('Subscriptions', SubscriptionSchema);