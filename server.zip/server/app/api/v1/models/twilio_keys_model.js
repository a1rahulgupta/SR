'use strict';

var mongoose = require('mongoose'),
    mongoosePaginate = require('mongoose-paginate');

var TwilioKeysSchema = mongoose.Schema({
    accountSid: {
        type: String
    },
    authToken: {
        type: String
    },
    application_sid:{
        type: String
    },
    toll_free_number: {
        type: String
    },
    is_deleted: {
        type: Boolean,
        default:false
    },
    status: {
        type: Boolean,
        default:true
    }
}, {
    timestamps: true
});

mongoose.model('Twilio_keys', TwilioKeysSchema);