'use strict';

const mongoose = require('mongoose'),
mongoosePaginate = require('mongoose-paginate');
var SchedulerSchema = mongoose.Schema({
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies',
        required: true
    },
    client_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Clients',
        required: true
    },
    interpreter_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Interpreters'
    },
    contact_info: {
        type: String
    },
    service_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Services'
    },
    booking_short_id:{
        type:String,
        required: true
    },
    service_title: {
        type: String
    },
    language_interprete_from: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Languages'
    },
    language_interprete_into: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Languages'
    },
    start_date: {
        type: Date,
        required: true
    },
    end_date: {
        type: Date,
        required: true
    },
    start_time: {
        type: String
    },
    end_time: {
        type: String
    },
    booking_description: {
        type: String
    },
    is_recurring: {
        type: Boolean,
        default: false
    },
    repeating_every_week:{
        type: String
    },
    repeating_every_no:{
        type: String
    },
    custom_weekly_repeat_on: {
        monday:         {type: Boolean, default: false},
        tuesday:        {type: Boolean, default: false},
        wednesday:      {type: Boolean, default: false},
        thursday:       {type: Boolean, default: false},
        friday:         {type: Boolean, default: false},
        saturday:       {type: Boolean, default: false},
        sunday:         {type: Boolean, default: false},
    },
    event_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Events'
    },
    event_end_date: {
        type: Date
    },
    recurrence_rule: {
        type: String,
        enum: ['daily','weekly', 'monthly', 'yearly', 'custom (weekly)', 'none'], default: 'none' 
    },
    notes: {
        type: String,
    },
    lat: {
        type: String,
    },
    lng: {
        type: String
    },
    address: {
        type: String
    },
    status: { 
        type: String,
        enum: ['new', 'scheduled', 'pending', 'completed', 'canceled', 'in_process', 'closed'], default: 'new' 
    },
    is_closed_by: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    is_canceled_by: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    is_deleted: {
        type: Boolean,
        default: false
    },
}, {
    timestamps: true
});

mongoose.model('Schedulers', SchedulerSchema);