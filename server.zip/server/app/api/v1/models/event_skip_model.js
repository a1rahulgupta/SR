'use strict';

const mongoose = require('mongoose'),
      mongoosePaginate = require('mongoose-paginate');

const ScheduleSkipSchema = mongoose.Schema({
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    scheduler_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Schedulers'  
    },
    start_date:  {
        type: Date,
        required: true
    },
    end_date:  {
        type: Date,
        required: true
    }, 
    event_skip_status: {
        type: Boolean,
        default: true
    }    
}, {
    timestamps: true
});

mongoose.model('Schedule_skips', ScheduleSkipSchema);