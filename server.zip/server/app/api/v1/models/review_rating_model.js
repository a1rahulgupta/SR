'use strict';

const mongoose = require('mongoose'),
mongoosePaginate = require('mongoose-paginate');

const ReviewRatingSchema = mongoose.Schema({
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    booking_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Bookings'
    },
    client_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Clients'
    },
    interpreter_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Interpreters'
    },
    review:{
        type:String
    },
    rating: {
        type: Number
    },
    rating_from : {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    rating_to : {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    status: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});
mongoose.model('ReviewRatings', ReviewRatingSchema);