'use strict';

const mongoose = require('mongoose'),
    mongoosePaginate = require('mongoose-paginate');

const AgencyUsersSchema = mongoose.Schema({
    agency_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Agencies'
    },
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    role_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Roles'
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

mongoose.model('Agency_users', AgencyUsersSchema);