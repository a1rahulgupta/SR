var crypto = __rootRequire('app/utils/crypto');
module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];

    var invoice_ctrl = require('./controllers/invoice_ctrl')
    router.post('/invoice/listAgencyInvoice', middlewares, invoice_ctrl.listAgencyInvoice);
    router.get('/invoice/getAgencyInvoiceById/:id', middlewares, invoice_ctrl.getAgencyInvoiceById);
    router.get('/invoice/getCurrentPlanDetails', middlewares, invoice_ctrl.getCurrentPlanDetails);
    router.post('/invoice/stopRecurringPayment', middlewares, invoice_ctrl.stopRecurringPayment);
    router.post('/invoice/startRecurringPayment', middlewares, invoice_ctrl.startRecurringPayment);

    return router;
}