const _ = require("lodash");
const moment = require('moment');
const Joi = require('joi');
const i18n = require("i18n");
const formidable = require('formidable');
const bcrypt = require('bcrypt');
const util = require('util');
const mongoose = require('mongoose');
const santize = __rootRequire('app/utils/santize');
const image = __rootRequire('app/utils/image');
const text = __rootRequire('app/utils/text');

//Models 
const User = mongoose.model('Users');
const AgencyModel = mongoose.model('Agencies');
const ClientModel = mongoose.model('Clients');
const RoleModel = mongoose.model('Roles');
const InterpreterModel = mongoose.model('Interpreters');
const EmailTemplateModel = mongoose.model('Email_Templates');
const AgencyUser = mongoose.model('Agency_users');
const AgencySubscriptionModel = mongoose.model('Agency_subscriptions');
const SubscriptionModel = mongoose.model('Subscriptions');
// const PaymentModel = mongoose.model('Payments');
// const PaymentModel = require('../../../models/payment_model.js');
const uuidV4 = require('uuid/v4');
const emailSend = __rootRequire('app/core/email');
const common = __rootRequire('app/config/common.js');
const fs = require('fs');
const path = require('path');
const twilioSms = __rootRequire('app/utils/twilioSms');



module.exports = {

     listAgencyInvoice: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            is_deleted: false
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        // var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                    'plan_name': new RegExp(searchText, 'gi')
                },
                {
                    'plan_duration': new RegExp(searchText, 'gi')
                },
                {
                    'paymentInfo.payment_unique_id': new RegExp(searchText, 'gi')
                }
            ];
        }

        var aggregateQuery = [{
                $lookup: {
                    from: 'payments',
                    localField: "payment_id",
                    foreignField: "_id",
                    as: "paymentInfo"
                }
            },
            {
                $unwind: {
                    path: "$paymentInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $match: condition
            }
        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        AgencySubscriptionModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                AgencySubscriptionModel.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    getAgencyInvoiceById: function (req, res, next) {
        AgencySubscriptionModel.findOne({_id: req.params.id})
          .populate('agency_id', 'agency_name address1 address2 mobile_no city state country zip')
          .populate('payment_id', 'payment_unique_id')
          .then((result)=>{
                res.json({
                    status: req.config.statusCode.success,
                     data: result,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                 });
          }).catch((err)=>{
                res.json({
                    status: req.config.statusCode.success,
                     data: {},
                    message: i18n.__("ERROR")
                });
          })
    },

    getCurrentPlanDetails: function (req, res, next) {
        AgencySubscriptionModel.findOne({agency_id: req.user.agency_id, status: true})
          .populate('agency_id', 'agency_name address1 address2 mobile_no city state country zip user_id')
          .populate('payment_id', 'payment_unique_id')
          .then((result)=>{
                res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                 });
          }).catch((err)=>{
                res.json({
                status: req.config.statusCode.success,
                 data: {},
                message: i18n.__("ERROR")
             });
          })
    },

    stopRecurringPayment: function(req, res, next){
        AgencySubscriptionModel.findOneAndUpdate({agency_id: req.user.agency_id, is_renewable: true}, {is_renewable: false}, {new: true},function(err,result){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })    
            } else {
               res.json({
                    status: req.config.statusCode.success,
                     data: result,
                    message: i18n.__("RECURRING_PAYMENT_STOPPED_SUCCESSFULLY")
                 }); 
            }
        })
    },

    startRecurringPayment: function(req, res, next){
        AgencySubscriptionModel.findOneAndUpdate({_id: req.body.currentPlanId, agency_id: req.user.agency_id, is_renewable: false}, {is_renewable: true}, {new: true},function(err,result){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })    
            } else {
                res.json({
                    status: req.config.statusCode.success,
                     data: result,
                    message: i18n.__("RECURRING_PAYMENT_STARTED_SUCCESSFULLY")
                 }); 
            }
        })
    },

}