const _ = require("lodash");
const moment = require('moment');
const Joi = require('joi');
const i18n = require("i18n");
const mongoose = require('mongoose');
const shortid = require('shortid');
const fs = require('fs');
const pdf = require('html-pdf');
const santize = __rootRequire('app/utils/santize');
const validator = __rootRequire('app/config/config.js');
const async = require('async');
var asyncEach = require('async-each-series');
const common = __rootRequire('app/config/common.js');
const twilioSms = __rootRequire('app/utils/twilioSms');
const uuidV4 = require('uuid/v4');
//Models 
const User = mongoose.model('Users');
const AgencyModel = mongoose.model('Agencies');
const ClientModel = mongoose.model('Clients');
const InterpreterModel = mongoose.model('Interpreters');
const SubscriptionModel = mongoose.model('Subscriptions');
const AgencySubscriptionModel = mongoose.model('Agency_subscriptions');
const PaymentModel = mongoose.model('Payments');
const EmailTemplateModel = mongoose.model('Email_Templates');
const Booking = mongoose.model('Bookings');
const ReviewRatingModel = mongoose.model('ReviewRatings');
const BookingRequestModel = mongoose.model('Booking_request');
const InterpreterLanguageModel = mongoose.model('Interpreter_languages');


module.exports = {
    listBookings: function (req, res, next) {
        req.query = santize.escape(req.query);
        var page = parseInt(req.query.page) - 1 || 0;
        var limit = parseInt(req.query.limit) || req.config.page.limit;
        var conditions = {};
        if(req.user.role == 'interpreter'){
         conditions = { is_deleted: false, interpreter_id: req.user.interpreter_id };
     }else if(req.user.role == 'client'){
         conditions = { is_deleted: false, client_id: req.user.client_id };
     }else{
        conditions = { agency_id: req.user.id, is_deleted: false };
    }

    if(req.query.client_id !=null && req.query.client_id !=undefined && req.query.client_id !=''){
        conditions.client_id = mongoose.Types.ObjectId(req.query.client_id);
    }

    Booking.where(conditions).count().exec().then((count) => {
            // __debug(count)
            Booking.find(conditions)
            .sort({ createdAt: -1 })
            .populate('client_id', 'first_name last_name _id')
            .populate('interpreter_id', 'first_name last_name _id')
            .exec()
            .then((bookings) => {
                return bookings
            }).then((bookings) => {
                res.json({
                    status: req.config.statusCode.success,
                    data: bookings,
                    count: count
                });
            })
            .catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            })
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        });
    },


    getAgencyBookingList: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.id),
            is_deleted: false
        }

        if(req.body.client_id){
            condition.client_id = mongoose.Types.ObjectId(req.body.client_id);
        }
        
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                'service_title': new RegExp(searchText, 'gi')
            },
            {
                'booking_id': new RegExp(searchText, 'gi')
            },
            {
                'clientInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'clientInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'interpreterInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'interpreterInfo.last_name': new RegExp(searchText, 'gi')
            }
            ];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'clients',
                localField: "client_id",
                foreignField: "_id",
                as: "clientInfo"
            }
        },
        {
            $unwind: {
                path: "$clientInfo",
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $match: condition
        }, {
            $lookup: {
                from: 'interpreters',
                localField: "interpreter_id",
                foreignField: "_id",
                as: "interpreterInfo"
            }
        }, {
            $unwind: {
                path: "$interpreterInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $match: condition
        }

        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        Booking.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                Booking.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    addBooking: function (req, res, next) {
        AgencySubscriptionModel.findOne({agency_id: req.user.agency_id, status: true})
            .then((agencySubscriptionData)=>{
                SubscriptionModel.findOne({_id: agencySubscriptionData.subscription_id})
                    .then((subscriptionData)=>{
                        Booking.find({agency_id: req.user.id})
                            .then((bookingData)=>{
                                if(bookingData.length >= subscriptionData.booking_limit){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: req.body,
                                        message: i18n.__("BOOKING_LIMIT_REACHED")
                                    })
                                } else{
                                    genId();
                                    function addData(shortBookingId){
                                        req.body.booking_id = shortBookingId;
                                        booking = new Booking(req.body);
                                        booking.agency_id = req.user.id;
                                        booking.save()
                                        .then((result) => {
                                            res.json({
                                                status: req.config.statusCode.success,
                                                data: result,
                                                message: i18n.__("BOOKED_SUCCESSFULLY")
                                            });
                                        }).catch((err) => {
                                                //__debug(err)
                                                res.json({
                                                    status: req.config.statusCode.error,
                                                    data: req.body,
                                                    message: i18n.__("ERROR")
                                                })

                                            });
                                    }

                                    function genId(){
                                        var shortBookingId = validator.generateShortId();
                                        Booking.find({booking_id: shortBookingId}, function(err, bookingData) {
                                            if(err){
                                                res.json({
                                                    status: req.config.statusCode.error,
                                                    data: {},
                                                    message: i18n.__("ERROR")
                                                })
                                            } else if(bookingData.length>0){
                                                genId();
                                            } else{
                                                addData(shortBookingId);
                                            }
                                        })
                                    }
                                }
                            })
                    })
            }).catch((err) => {
                    //__debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })
            })
        
    },

    updateBooking: function (req, res, next) {
        Booking.findOneAndUpdate({
            _id: req.body._id,
            agency_id: req.user.id
        }, {
            service_title: req.body.service_title,
            language_id: req.body.language_id,
            client_id: req.body.client_id,
            booking_from: req.body.booking_from,
            booking_to: req.body.booking_to,
            booking_description: req.body.booking_description,
            notes: req.body.notes,
            working_from: req.body.working_from,
            working_to: req.body.working_to,
            contact_info: req.body.contact_info,
            address: req.body.address,
            lat: req.body.lat,
            lng: req.body.lng

        }, {
            new: true
        })
        .then((result) => {
            res.json({
                status: req.config.statusCode.success,
                data: result,
                message: i18n.__("BOOKED_SUCCESSFULLY")
            });
        }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });

    },
    deleteBooking: function (req, res, next) {
        //__debug("id", req.body.id)
        Booking.findOneAndUpdate({
            _id: req.params.id,
            agency_id: req.user.id
        }, {
            is_deleted: true
        }, {
            new: true
        })
        .then((result) => {
            res.json({
                status: req.config.statusCode.success,
                data: result,
                message: i18n.__("BOOKING_DELETED_SUCCESSFULLY")
            });
        }).catch((err) => {
                //__debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });

    },

    getBooking: function (req, res, next) {
        // console.log("inside getBooking", req.user);
        var conditions = {};
        if(req.user.role == 'interpreter'){
            conditions = { 
                _id: req.params.id
                // agency_id: req.user.agency_id,
                // interpreter_id: req.user.interpreter_id
            }
        }else{
            conditions = {
                _id: req.params.id,
                agency_id: req.user.id 
            }
        }
        Booking.findOne(conditions)
        .exec()
        .then((booking) => {
            res.json({
                status: req.config.statusCode.success,
                data: booking
            });
        })
        .catch((err) => {
            __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    getBookingViewById: function (req, res, next) {
        Booking.findOne({_id: req.params.id})
        .populate('interpreter_id', 'first_name last_name')
        .populate('client_id', 'first_name last_name')
        .populate('language_id', 'language_name')
        .exec()
        .then((booking) => {
            res.json({
                status: req.config.statusCode.success,
                data: booking
            });
        })
        .catch((err) => {
            __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    getBookingInterpreterById: function (req, res, next) {
        // req.query = santize.escape(req.query);
        Booking.findOne({_id: req.params.id})
        .populate('client_id')
        .populate('language_id')
        .exec()
        .then((booking) => {
            res.json({
                status: req.config.statusCode.success,
                data: booking
            });
        })
        .catch((err) => {
            __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    listBookingByInterpreterId: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            // agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            interpreter_id: mongoose.Types.ObjectId(req.user.interpreter_id),
            is_deleted: false
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        // var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                'clientInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'clientInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'status': new RegExp(searchText, 'gi')
            },
            {
                'booking_id': new RegExp(searchText, 'gi')
            },
            {
                'address': new RegExp(searchText, 'gi')
            }
            ];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'clients',
                localField: "client_id",
                foreignField: "_id",
                as: "clientInfo"
            }
        },
        {
            $unwind: {
                path: "$clientInfo",
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $match: condition
        }
        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        Booking.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                Booking.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    getInterpreterBookingById: function (req, res, next) {
        Booking.findOne({
            _id:req.params.id,
            is_deleted:false
            // interpreter_id:req.user.interpreter_id
        })
        .populate('client_id')
        .populate('interpreter_id')
        .populate('language_id')
        .exec()
        .then((booking) => {
            res.json({
                status: req.config.statusCode.success,
                data: booking
            });
        })
        .catch((err) => {
            __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    listBookingByClientId: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            // agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            client_id: mongoose.Types.ObjectId(req.user.client_id),
            
            is_deleted: false
        }

        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        // var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                'interpreterInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'interpreterInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'status': new RegExp(searchText, 'gi')
            },
            {
                'booking_id': new RegExp(searchText, 'gi')
            },
            {
                'service_title': new RegExp(searchText, 'gi')
            }
            ];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'interpreters',
                localField: "interpreter_id",
                foreignField: "_id",
                as: "interpreterInfo"
            }
        },
        {
            $unwind: {
                path: "$interpreterInfo",
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $match: condition
        }
        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        Booking.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                Booking.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    addBookingByClient: function (req, res, next) {
        AgencySubscriptionModel.findOne({agency_id: req.user.agency_id, status: true})
            .then((agencySubscriptionData)=>{
                SubscriptionModel.findOne({_id: agencySubscriptionData.subscription_id})
                    .then((subscriptionData)=>{
                        AgencyModel.findOne({_id: req.user.agency_id}).exec(function(err,agencyData){
                            if(err){
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: req.body,
                                    message: i18n.__("ERROR")
                                })
                            }else if(agencyData){
                                Booking.find({agency_id: agencyData.user_id})
                                    .then((bookingData)=>{
                                        if(bookingData.length >= subscriptionData.booking_limit){
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: req.body,
                                                message: i18n.__("BOOKING_LIMIT_REACHED")
                                            })
                                        } else{
                                            genId();
                                            function addData(shortBookingId){
                                                booking = new Booking(req.body);
                                                booking.booking_id = shortBookingId;
                                                booking.agency_id = agencyData.user_id;
                                                booking.client_id = req.user.client_id;
                                                booking.save()
                                                .then((result) => {
                                                    res.json({
                                                        status: req.config.statusCode.success,
                                                        data: result,
                                                        message: i18n.__("BOOKED_SUCCESSFULLY")
                                                    });
                                                }).catch((err) => {
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: req.body,
                                                            message: i18n.__("ERROR")
                                                        })

                                                    });
                                            }

                                            function genId(){
                                                var shortBookingId = validator.generateShortId();
                                                Booking.find({booking_id: shortBookingId}, function(err, bookingData) {
                                                    if(err){
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: req.body,
                                                            message: i18n.__("ERROR")
                                                        })
                                                    } else if(bookingData.length>0){
                                                        genId();
                                                    } else{
                                                        addData(shortBookingId);
                                                    }
                                                })
                                            }
                                        }
                                    })
                            }else{
                                res.json({
                                    status: req.config.statusCode.notFound,
                                    data: {},
                                    message: i18n.__("NO_RECORD_FOUND")
                                });
                            }
                        })
                        
                    })
            }).catch((err) => {
                    //__debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })
            })  

    },

    getClientBookingById: function (req, res, next) {
        Booking.findOne({
            _id:req.params.id,
            is_deleted:false
            // interpreter_id:req.user.interpreter_id
        })
        .exec()
        .then((booking) => {
            res.json({
                status: req.config.statusCode.success,
                data: booking
            });
        })
        .catch((err) => {
            __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    getClientBookingViewById: function (req, res, next) {
        Booking.findOne({
            _id:req.params.id,
            is_deleted:false
            // interpreter_id:req.user.interpreter_id
        })
        .populate('interpreter_id')
        .populate('client_id')
        .populate('language_id')
        .exec()
        .then((booking) => {
            res.json({
                status: req.config.statusCode.success,
                data: booking
            });
        })
        .catch((err) => {
            __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    updateBookingByClient: function (req, res, next) {
        //__debug(req.body.id)
        Booking.findOneAndUpdate({
            _id: req.body._id,
            agency_id: req.body.agency_id
        }, {
            service_title: req.body.service_title,
            language_id: req.body.language_id,
            contact_info: req.body.contact_info,
            client_id: req.user.client_id,
            booking_from: req.body.booking_from,
            booking_to: req.body.booking_to,
            booking_description: req.body.booking_description,
            notes: req.body.notes,
            working_from: req.body.working_from,
            working_to: req.body.working_to,
            address: req.body.address,
            lat: req.body.lat,
            lng: req.body.lng

        }, {
            new: true
        })
        .then((result) => {
            res.json({
                status: req.config.statusCode.success,
                data: result,
                message: i18n.__("BOOKED_SUCCESSFULLY")
            });
        }).catch((err) => {
                //__debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });

    },

    cancelBookingByClient: function (req, res, next) {
        //__debug("id", req.body.id)
        Booking.findOneAndUpdate({
            _id: req.body.id
        }, {
            is_canceled_by: req.user.id,
            status: 'canceled'
        }, {
            new: true
        })
        .then((result) => {
            res.json({
                status: req.config.statusCode.success,
                data: result,
                message: i18n.__("Booking canceled sucessfully")
            });
        }).catch((err) => {
                //__debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });

    },

    closeBookingByClient: function (req, res, next) {
        //__debug("id", req.body.id)
        Booking.findOneAndUpdate({
            _id: req.body.id
        }, {
            is_closed_by: req.user.id,
            status: 'closed'
        }, {
            new: true
        })
        .then((result) => {
            res.json({
                status: req.config.statusCode.success,
                data: result,
                message: i18n.__("Booking closed sucessfully")
            });
        }).catch((err) => {
                //__debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });

    },

    getBookingByClientId: function (req, res, next) {
        // req.query = santize.escape(req.query);
        Booking.findOne({_id: req.params.id})
        .exec()
        .then((booking) => {
            res.json({
                status: req.config.statusCode.success,
                data: booking
            });
        })
        .catch((err) => {
            __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    searchBookingByDate: function (req, res, next) {
        var dateFrom = moment(req.body.searchFrom).startOf('day');
        var dateTo = moment(req.body.searchTo).endOf('day');
        var momentObjFrom = new Date(moment(dateFrom));
        var momentObjTo = new Date(moment(dateTo));
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.id),
            is_deleted: false,
            $and:[
            {booking_from: {$gte: momentObjFrom}}, 
            { booking_to: {$lte: momentObjTo}}
            ]
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'clients',
                localField: "client_id",
                foreignField: "_id",
                as: "clientInfo"
            }
        },
        {
            $unwind: {
                path: "$clientInfo",
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $match: condition
        }, {
            $lookup: {
                from: 'interpreters',
                localField: "interpreter_id",
                foreignField: "_id",
                as: "interpreterInfo"
            }
        }, {
            $unwind: {
                path: "$interpreterInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $match: condition
        }

        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        Booking.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                Booking.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    listBookingByClientIdInReport: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            client_id: mongoose.Types.ObjectId(req.body.clientId),
            agency_id: mongoose.Types.ObjectId(req.user.id),
            is_deleted: false
        }

        // var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                'interpreterInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'interpreterInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'clientInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'clientInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'booking_id': new RegExp(searchText, 'gi')
            },
            {
                'service_title': new RegExp(searchText, 'gi')
            }
            ];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'clients',
                localField: "client_id",
                foreignField: "_id",
                as: "clientInfo"
            }
        },
        {
            $unwind: {
                path: "$clientInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $lookup: {
                from: 'interpreters',
                localField: "interpreter_id",
                foreignField: "_id",
                as: "interpreterInfo"
            }
        }, {
            $unwind: {
                path: "$interpreterInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $match: condition
        }

        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        Booking.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                Booking.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    listLanguageBookingInReport: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.id),
            language_id: mongoose.Types.ObjectId(req.body.language),
            is_deleted: false
        }

        // var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                'interpreterInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'interpreterInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'clientInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'clientInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'booking_id': new RegExp(searchText, 'gi')
            },
            {
                'service_title': new RegExp(searchText, 'gi')
            }
            ];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'clients',
                localField: "client_id",
                foreignField: "_id",
                as: "clientInfo"
            }
        },
        {
            $unwind: {
                path: "$clientInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $lookup: {
                from: 'interpreters',
                localField: "interpreter_id",
                foreignField: "_id",
                as: "interpreterInfo"
            }
        }, {
            $unwind: {
                path: "$interpreterInfo",
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $lookup: {
                from: 'languages',
                localField: "language_id",
                foreignField: "_id",
                as: "languageInfo"
            }
        }, {
            $unwind: {
                path: "$languageInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $match: condition
        }];

        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        Booking.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                Booking.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    listTopTenLanguageReport: function (req, res, next) {
         var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.id), 
            is_deleted: false
         }
        var aggregate = [{
                $lookup: {
                    from: 'languages',
                    localField: "language_id",
                    foreignField: "_id",
                    as: "languageInfo"
                }
            },
            { $unwind: "$languageInfo"},
            { 
                $match: condition
            },
            {
                $group: {
                    _id: '$languageInfo._id',
                    count: { "$sum": 1},
                    language_name: { $first : "$languageInfo.language_name"}
                }
            
            },{
                $sort : {count: -1}
            },{
                $limit: 10
            }
        ];

        Booking.aggregate(aggregate).exec(function (err, record) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                res.json({
                    status: req.config.statusCode.success,
                    data: record,
                    message: i18n.__("Get data succesfully")
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },
    
    exportPdfTopTenLaguageReport: function (req, res, next) {
        var logoUrl = req.config.email.base_url+req.config.email.logo_url;
        var timestamp = Number(new Date());
        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.id), 
            is_deleted: false
         }
        var aggregate = [{
                $lookup: {
                    from: 'languages',
                    localField: "language_id",
                    foreignField: "_id",
                    as: "languageInfo"
                }
            },
            { $unwind: "$languageInfo"},
            { 
                $match: condition
            },
            {
                $group: {
                    _id: '$languageInfo._id',
                    count: { "$sum": 1},
                    language_name: { $first : "$languageInfo.language_name"}
                }
            
            },{
                $sort : {count: -1}
            },{
                $limit: 10
            }
        ];

        Booking.aggregate(aggregate).exec(function (err, record) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                var options = { "format": "Letter"};
                var filename = "doc" + timestamp + '_' + common.randomToken(6) +  ".pdf";
                var path = "./../client/users/assets/uploads/reports/" + filename;

                var headerHtml = "<!DOCTYPE html><head><meta charset='utf-8' /><meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'/><meta http-equiv='X-UA-Compatible' content='IE=edge' /><meta http-equiv='Content-Type' content='text/html; charset=utf-8'><title>HTML</title></head>"+
                                   "   <body style='float: left; width: 100%; margin: 0px; padding: 0px; height: 100%; font-family: sans-serif,arial; font-size: 11px; color: rgb(85, 85, 85); background: rgb(252, 252, 252) none repeat scroll 0% 0%;'>"+
                                   "    <div style='float: left; width: 100%;  box-sizing: border-box; padding: 20px 5px 0px; overflow: auto; '>"+
                                   "    <div style='float: left; width: 81px;'>"+
                                   "        <img src="+logoUrl+" alt='company logo' style='max-width: 100%; margin-left: 10px; display: block; width: 81px; float: left; '>"+
                                   "    </div>"+
                                   "    <div style='float: right; width: 222px;'>"+
                                   "        <div style='float: left; width: 100%; height: auto; box-sizing: border-box; margin-bottom: 6px; font-size: 15px; color: rgb(51, 51, 51); text-align: left; word-wrap: break-word; '>Language Link Corporation</div>"+
                                   "        <div style='float: left; width: 222px; height: auto; box-sizing: border-box; text-align: left; word-wrap: break-word;'>900 Chapel St. 10th Floor, New Haven, CT 06510</div>"+
                                   "    </div>"+
                                   "    </div>"+
                                   "    <div style='float: left; padding-left:10px; width: 100%; box-sizing: border-box; margin-top: 21px; padding-top: 10px; border-top: 1px solid #eee;'>"+
                                   "    <div style='float: left; font-weight: bold; font-size: 10px;'>Report Name : Top 10 Language</div>"+
                                   "    </div>"+
                                   "    <div style='float: left; width: 98%;   margin-left:5px; margin-right:5px; box-sizing: border-box; border: 1px solid rgb(204, 204, 204); margin-top: 15px; background: white none repeat scroll 0% 0%;'>"+
                                   "    <div style='float: left; width: 100%; box-shadow: 0px 0px 7px 2px #ddd; min-height: 615px;'>"+
                                   "    <div style='float: left; width: 100%;'>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 50%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Language</div>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 50%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px; border-right: 0;'>No of Booking</div>"+
                                   "    </div>";

                var footerHtml =   "    </div>"+
                                   "    </div>"+
                                   "    </div>"+
                                   "    <div style='float: left; position: fixed: bottom: 0; width: 100%; background: #eee; box-sizing: border-box; padding: 4px 0px;'>"+
                                   "    <div style='font-style: italic; width: 100%; max-width: 1200px; text-align: center; float: none; margin: 0px auto; box-sizing: border-box; padding-right: 5px;'>All Rights Reserved &copy; Language Link Corporation</div>"+
                                   "    </div>"+
                                   "    </body>"+
                                   "    </html>";
                var html = "";
                async.eachSeries(record, function(resultOne, next){
                        if(resultOne._id !=null && resultOne._id !=undefined && resultOne._id !=''){
                            var languageName = resultOne.language_name.charAt(0).toUpperCase()+resultOne.language_name.slice(1).toLowerCase();
                            html += "<div style='width: 100%; position: relative; height: 100%; float: left; border-bottom: 1px solid #ccc;'>"+
                                   "<div style='box-sizing: border-box; width: 50%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+languageName+"</div>"+
                                   "<div style='box-sizing: border-box; width: 50%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.count+"</div>"+
                                   "</div>";
                            
                            var finalHtml = headerHtml+html+footerHtml;
                             pdf.create(finalHtml, options).toFile(path, function(err, data) {
                            if(err){
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: req.body,
                                    message: i18n.__("ERROR")
                                })
                            } else{
                                next();
                            } 
                          });
                            
                        }
                    },function(err){
                      if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })
                      }else{
                        res.json({
                            status: req.config.statusCode.success,
                            data: path,
                            message: i18n.__("GET_FILE_PATH_SUCCESSFULLY")
                        });
                      }
                    })
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("No record found.")
            });
        })
    },

    getBookingDetailForInterpreterCalendar: function (req, res, next) {
        var startDate = moment(req.body.startDate).startOf('day'); // set to 12:00 am today
        var endDate = moment(req.body.startDate).endOf('day');
        var btwnCondition = {};
        btwnCondition = {
            $or: [
                {
                    $and: [
                        { booking_from: { $gte: new Date(startDate)} },
                        { booking_from: { $lte: new Date(endDate)} }
                    ]
                }, 
                {
                    $and: [
                        { booking_to: { $gte: new Date(startDate)} }, 
                        { booking_to: { $lte: new Date(endDate)} }
                    ]
                },            
                {
                    $and: [
                        { booking_from: { $lte: new Date(moment(req.body.startDate))} }, 
                        { booking_to: { $gte: new Date(moment(req.body.startDate))} }
                    ]
                },                        
            ]
        };
        btwnCondition.interpreter_id = mongoose.Types.ObjectId(req.user.interpreter_id);
        Booking.find(btwnCondition)
        .populate('client_id', 'first_name last_name')
        .then((bookingData)=>{
            res.json({
                status: req.config.statusCode.success,
                data: bookingData,
                message: i18n.__('GET_BOOKING_DETAILS_SUCCESSFULLY')
            });
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })

        });

                
    },

    getBookingDetailForInterpreterCalendarInAgency: function (req, res, next) {
        var startDate = moment(req.body.startDate).startOf('day'); // set to 12:00 am today
        var endDate = moment(req.body.startDate).endOf('day');
        var btwnCondition = {};
        btwnCondition = {
            $or: [
                {
                    $and: [
                        { booking_from: { $gte: new Date(startDate)} },
                        { booking_from: { $lte: new Date(endDate)} }
                    ]
                }, 
                {
                    $and: [
                        { booking_to: { $gte: new Date(startDate)} }, 
                        { booking_to: { $lte: new Date(endDate)} }
                    ]
                },            
                {
                    $and: [
                        { booking_from: { $lte: new Date(moment(req.body.startDate))} }, 
                        { booking_to: { $gte: new Date(moment(req.body.startDate))} }
                    ]
                },                        
            ]
        };
        btwnCondition.interpreter_id = mongoose.Types.ObjectId(req.body.interpreter_id);
        Booking.find(btwnCondition)
        .populate('client_id', 'first_name last_name')
        .then((bookingData)=>{
            res.json({
                status: req.config.statusCode.success,
                data: bookingData,
                message: i18n.__('GET_BOOKING_DETAILS_SUCCESSFULLY')
            });
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })

        });

                
    },


    getInterpreterBookingViewById: function (req, res, next) {
        Booking.findOne({_id: req.params.id, interpreter_id: req.user.interpreter_id, is_deleted:false})
        .populate('interpreter_id', 'first_name last_name')
        .populate('client_id', 'first_name last_name')
        .populate('language_id', 'language_name')
        .exec()
        .then((booking) => {
            res.json({
                status: req.config.statusCode.success,
                data: booking,
                message: i18n.__('GET_BOOKING_DETAILS_SUCCESSFULLY')
            });
        })
        .catch((err) => {
            __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    getInterpreterBookingViewByIdInAgency: function (req, res, next) {
        Booking.findOne({_id: req.body.id, interpreter_id: req.body.interpreter_id, is_deleted:false})
        .populate('interpreter_id', 'first_name last_name')
        .populate('client_id', 'first_name last_name')
        .populate('language_id', 'language_name')
        .exec()
        .then((booking) => {
            res.json({
                status: req.config.statusCode.success,
                data: booking,
                message: i18n.__('GET_BOOKING_DETAILS_SUCCESSFULLY')
            });
        })
        .catch((err) => {
            __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    getClientBookingByIdInAgency: function (req, res, next) {
        Booking.findOne({_id: req.body.id, client_id: req.body.client_id, is_deleted:false})
        .populate('interpreter_id', 'first_name last_name')
        .populate('client_id', 'first_name last_name')
        .populate('language_id', 'language_name')
        .exec()
        .then((booking) => {
            res.json({
                status: req.config.statusCode.success,
                data: booking,
                message: i18n.__('GET_BOOKING_DETAILS_SUCCESSFULLY')
            });
        })
        .catch((err) => {
            __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    listBookingOfInterpreterInAgency: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.id),
            interpreter_id: mongoose.Types.ObjectId(req.body.interpreter_id),
            is_deleted: false
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        // var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                'clientInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'clientInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'booking_id': new RegExp(searchText, 'gi')
            },
            {
                'service_title': new RegExp(searchText, 'gi')
            }
            ];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'clients',
                localField: "client_id",
                foreignField: "_id",
                as: "clientInfo"
            }
        },
        {
            $unwind: {
                path: "$clientInfo",
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $match: condition
        },{
            $lookup: {
                from: 'interpreters',
                localField: "interpreter_id",
                foreignField: "_id",
                as: "interpreterInfo"
            }
        }, {
            $unwind: {
                path: "$interpreterInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $match: condition
        }
        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        Booking.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                Booking.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    listBookingOfClientInAgency: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.id),
            client_id: mongoose.Types.ObjectId(req.body.client_id),
            
            is_deleted: false
        }

        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        // var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                'interpreterInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'interpreterInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'booking_id': new RegExp(searchText, 'gi')
            },
            {
                'service_title': new RegExp(searchText, 'gi')
            }
            ];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'interpreters',
                localField: "interpreter_id",
                foreignField: "_id",
                as: "interpreterInfo"
            }
        },
        {
            $unwind: {
                path: "$interpreterInfo",
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $match: condition
        }
        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        Booking.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                Booking.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    getBookingInterpretersLocation: function (req, res, next) {
        Booking.findOne({_id: req.body.id})
        .populate('interpreter_id', 'first_name last_name')
        .populate('client_id', 'first_name last_name')
        .populate('language_id', 'language_name')
        .exec()
        .then((booking) => {
            var bookingStartTime = moment(booking.working_from, "HH:mm a");
            var bookingEndTime = moment(booking.working_to, "HH:mm a");
            var booking_from_day = moment(booking.booking_from).format('dddd').toLowerCase();
            console.log("booking_from_day",booking_from_day);
            console.log("bookingStartTime",bookingStartTime);
            console.log("bookingEndTime",bookingEndTime);
            var interpreterCondition = {
                agency_id: req.user.agency_id,
                status: true
            };
            InterpreterModel.find(interpreterCondition,{lat: 1, lng: 1, first_name: 1, last_name: 1, working_from: 1, working_to: 1, working_days: 1 }).exec(function(err, interpretersArray){
                if(err){
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        interpretersArray: [],
                        interpretersData: [],
                        message: i18n.__("ERROR")
                    });
                }else if(interpretersArray){          
                    var languageMatchedInterpretersArray = [];
                    async.eachSeries(interpretersArray, function(iterativeInterpreter, firstNext){
                        console.log("in async series");
                        InterpreterLanguageModel.findOne({
                            agency_id: req.user.agency_id,
                            interpreter_id: iterativeInterpreter._id,
                            language_id: booking.language_id._id,
                            is_deleted: false
                         }).exec(function(err,iterativeInterpreterLanguageMatched){
                            if(err){
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("ERROR")
                                });
                            }else if(iterativeInterpreterLanguageMatched){
                                if(iterativeInterpreter.working_days[booking_from_day] == true){
                                    var interpreterStartTime = moment(iterativeInterpreter.working_from, "HH:mm a");
                                    var interpreterEndTime = moment(iterativeInterpreter.working_to, "HH:mm a");
                                    console.log("interpreterStartTime", interpreterStartTime);
                                    console.log("interpreterEndTime", interpreterEndTime);
                                    if(bookingStartTime.hour() >= interpreterStartTime.hour() && bookingEndTime.hour() <= interpreterEndTime.hour()){
                                        if(bookingEndTime.minutes() <= interpreterEndTime.minutes()){
                                            console.log("found in booking time");
                                            var interpreterlanguageMatch = {};
                                            interpreterlanguageMatch = iterativeInterpreter;
                                            languageMatchedInterpretersArray.push(interpreterlanguageMatch); 
                                            firstNext();
                                        }else{
                                            firstNext();
                                        }    
                                    }else{
                                        firstNext();
                                    }
                                }else{
                                    firstNext();
                                }
                            }else{
                                console.log("not found marker interpreter language");
                                firstNext();
                            }
                         })    
                           
                    },function(err){
                        if(err){
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        }else{
                            console.log("languageMatchedInterpretersArray",languageMatchedInterpretersArray);
                            BookingRequestModel.find({booking_id: booking._id,status: true}).populate('interpreter_id').exec(function(err,selectedInterpreters){
                                if(err){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        interpretersArray: [],
                                        interpretersData: [],
                                        message: i18n.__("ERROR")
                                    });     
                                }else if(selectedInterpreters){
                                    var selectedInterpretersArray = [];
                                    async.eachSeries(selectedInterpreters, function(selectedInterpreter, next){
                                        //Start Rating
                                        var selectedNewInterpreter = {};
                                        selectedNewInterpreter = selectedInterpreter.toObject();
                                        ReviewRatingModel.aggregate([
                                            { $match: { interpreter_id: mongoose.Types.ObjectId(selectedNewInterpreter._id), is_deleted: false } }, {
                                                "$group": {
                                                    "_id": '$rating_to',
                                                    "avgRating": { "$avg": { "$ifNull": ["$rating", 0] } }
                                                }
                                            }
                                        ], function(err, rating) {
                                            var rate = 0;
                                            if (rating[0]) {
                                                if (rating[0].avgRating) {
                                                    rate = rating[0].avgRating;
                                                }
                                            }
                                            selectedNewInterpreter.rate = rate;
                                            selectedInterpretersArray.push(selectedNewInterpreter);
                                            next();     
                                        });
                                        //End rating   
                                    },function(err){
                                      if(err){
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: {},
                                            message: i18n.__("ERROR")
                                        })
                                      }else{
                                            var current_lng = parseFloat(booking.lng),
                                            current_lat = parseFloat(booking.lat);
                                            maxDistance = req.body.radiusInMeter; // 1 Mile = 1609.34 Meter
                                            var condition = {agency_id: req.user.agency_id};
                                            condition.location = {
                                                $near: {
                                                    $geometry: {
                                                        type: "Point",
                                                        coordinates: [current_lng, current_lat]
                                                    },
                                                    $minDistance: 0,
                                                    $maxDistance: maxDistance
                                                }
                                            };
                                            condition.status = true;
                                            InterpreterModel.find(condition).exec(function(err,interpretersDetails){
                                                if(err){
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: {},
                                                        message: i18n.__("ERROR")
                                                    });
                                                }else if(interpretersDetails){
                                                    console.log("interpretersDetails########",interpretersDetails);
                                                    var interpretersData = [];
                                                    async.eachSeries(interpretersDetails, function(singleInterpreter, next){
                                                        
                                                        InterpreterLanguageModel.findOne({
                                                            agency_id: req.user.agency_id,
                                                            interpreter_id: singleInterpreter._id,
                                                            language_id: booking.language_id._id,
                                                            is_deleted: false
                                                         }).exec(function(err,interpreterLanguageMatched){
                                                            if(err){
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: {},
                                                                    message: i18n.__("ERROR")
                                                                });
                                                            }else if(interpreterLanguageMatched){
                                                                if(singleInterpreter.working_days[booking_from_day] == true){
                                                                    console.log("singleInterpreter",singleInterpreter);

                                                                    var availableInterpreterStartTime = moment(singleInterpreter.working_from, "HH:mm a");
                                                                    var availableInterpreterEndTime = moment(singleInterpreter.working_to, "HH:mm a");
                                                                    console.log("availableInterpreterStartTime", availableInterpreterStartTime );
                                                                    console.log("availableInterpreterEndTime", availableInterpreterEndTime);
                                                                    if(bookingStartTime.hour() >= availableInterpreterStartTime.hour() && bookingEndTime.hour() <= availableInterpreterEndTime.hour()){
                                                                        console.log("bookingEndTime.minutes()",bookingEndTime.minutes());
                                                                        console.log("availableInterpreterEndTime.minutes()",availableInterpreterEndTime.minutes());
                                                                        if(bookingEndTime.minutes() <= availableInterpreterEndTime.minutes()){
                                                                            console.log("found in available booking time");
                                                                            //Start Rating
                                                                            var singleNewInterpreter = {};
                                                                            singleNewInterpreter = singleInterpreter.toObject();
                                                                            ReviewRatingModel.aggregate([
                                                                                { $match: { interpreter_id: mongoose.Types.ObjectId(singleInterpreter._id), is_deleted: false } }, {
                                                                                    "$group": {
                                                                                        "_id": '$rating_to',
                                                                                        "avgRating": { "$avg": { "$ifNull": ["$rating", 0] } }
                                                                                    }
                                                                                }
                                                                            ], function(err, rating) {
                                                                                var rate = 0;
                                                                                if (rating[0]) {
                                                                                    if (rating[0].avgRating) {
                                                                                        rate = rating[0].avgRating;
                                                                                    }
                                                                                }
                                                                                singleNewInterpreter.rate = rate;
                                                                                singleNewInterpreter.selected = false;
                                                                                async.eachSeries(selectedInterpretersArray, function(checkedInterpreter, next){
                                                                                    if(_.isEqual(singleNewInterpreter._id,checkedInterpreter.interpreter_id._id)){
                                                                                        singleNewInterpreter.selected = true;
                                                                                        next();
                                                                                    }else{
                                                                                        next();
                                                                                    }
                                                                                },function(err){
                                                                                  if(err){
                                                                                    res.json({
                                                                                        status: req.config.statusCode.error,
                                                                                        data: {},
                                                                                        message: i18n.__("ERROR")
                                                                                    })
                                                                                  }else{
                                                                                    interpretersData.push(singleNewInterpreter);
                                                                                    next(); 
                                                                                  }
                                                                                })  
                                                                            });
                                                                            //End rating
                                                                        }else{
                                                                            console.log("comes in founddddd");
                                                                            next();
                                                                        }
                                                                    }else{
                                                                        next();
                                                                    }
                                                                }else{
                                                                    next();
                                                                }    
                                                            }else{
                                                                console.log("not found matched language");
                                                                next();
                                                            }
                                                        })    
                                                    },function(err){
                                                        if(err){
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: {},
                                                                message: i18n.__("ERROR")
                                                            })
                                                        }else{
                                                            if(languageMatchedInterpretersArray.length>0){
                                                                res.json({
                                                                    status: req.config.statusCode.success,
                                                                    data: booking,
                                                                    interpretersArray: languageMatchedInterpretersArray,
                                                                    interpretersData: interpretersData,
                                                                    selectedInterpretersArray: selectedInterpretersArray, 
                                                                    message: i18n.__("Record found") 
                                                                });
                                                            }else{
                                                                res.json({
                                                                    status: req.config.statusCode.success,
                                                                    data: booking,
                                                                    interpretersArray: languageMatchedInterpretersArray,
                                                                    interpretersData: interpretersData,
                                                                    selectedInterpretersArray: selectedInterpretersArray, 
                                                                    message: i18n.__("INTERPRETERS_NOT_AVAILABLE_FOR_THIS_BOOKING") 
                                                                });
                                                            }
                                                        }
                                                    })
                                                }else{
                                                   res.json({
                                                        status: req.config.statusCode.notFound,
                                                        data: {},
                                                        interpretersArray: [],
                                                        interpretersData: [],
                                                        selectedInterpretersArray: [],
                                                        message: i18n.__("NO_RECORD_FOUND")
                                                    });
                                                }
                                            })      
                                        }
                                    })
                                }else{
                                    res.json({
                                        status: req.config.statusCode.notFound,
                                        data: {},
                                        interpretersArray: [],
                                        interpretersData: [],
                                        selectedInterpretersArray: [],
                                        message: i18n.__("NO_RECORD_FOUND")
                                    });        
                                }
                            })
                        }
                    })


                    
                    
                }else{
                    res.json({
                        status: req.config.statusCode.notFound,
                        data: {},
                        interpretersArray: [],
                        interpretersData: [],
                        selectedInterpretersArray: [],
                        message: i18n.__("NO_RECORD_FOUND")
                    });
                }
            })
        })
        .catch(function(err){
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            });
        })
    },

    sendRequestToInterpreters: function (req, res, next) {
        var booking = req.body.booking;
        var interpreterSelectedArray = req.body.interpreterSelectedArray;
        async.eachSeries(req.body.interpreterSelectedArray, function(selectedInterpreter, next){
            if(req.config.env == 'aws'){
                var baseUrl = 'https://www.interpreting.works';
            }else{
                var baseUrl = req.config.email.base_url;
            }
            var request_token = uuidV4();
            var text = "You received a new booking request for service title:"+ ' ' + booking.service_title+ ', Start Date: '+moment(booking.booking_from).format("YYYY-MM-DD")+ ' End Date: '+ moment(booking.booking_to).format("DD-MM-YYYY")+ ', Time: '+booking.working_from+ ' to '+booking.working_to +' for language: '+  booking.language_id.language_name.charAt(0).toUpperCase()+booking.language_id.language_name.slice(1).toLowerCase()+' at address: '+booking.address+ '. If you want to accept this booking kindly visit to the provided link: ' +baseUrl+ '/#/acceptRequest/' + request_token;
            var data = { to: selectedInterpreter.mobile_no, message: text }
            var request = {
                agency_id: req.user.agency_id,
                booking_id: booking._id,
                interpreter_id: selectedInterpreter._id,
                sent_to: selectedInterpreter.mobile_no ? selectedInterpreter.mobile_no : data.to,
                text:  selectedInterpreter.text ? selectedInterpreter.text : data.message,
                request_token: selectedInterpreter.request_token ? selectedInterpreter.request_token : request_token,
                accept: false
            }
            if(selectedInterpreter.selected == true){
                request.status = true;
            }else{
                request.status = false;
            }
            var condition = {
                agency_id:req.user.agency_id,
                interpreter_id:selectedInterpreter._id,
                booking_id: booking._id
            }
            BookingRequestModel.update(condition,{
                $set: request
            },{
                upsert: true
            },function(err, requestData){
                if(err){
                    console.log("error1",err);
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                } else{
                    if(selectedInterpreter.selected == true){
                        twilioSms.sendSMS(data, function(returnData) {
                            next();
                        });
                    }else{
                        next();
                    }
                }
            })
        },function(err){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })
            }else{
                res.json({
                    status: req.config.statusCode.success,
                    data: {},
                    message: i18n.__("Request sent succesfully")
                });
            }
        })        
    },

    downloadPaperVoucher: function (req, res, next) {
        Booking.findOne({_id: req.query.id, is_deleted:false})
            .populate('interpreter_id', 'first_name last_name profile_pic')
            .populate('client_id', 'first_name last_name')
            .populate('language_id', 'language_name')
            .then((result) => {
                AgencyModel.findOne({user_id: result.agency_id, status: true}).exec(function(err,agencyData){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })
                    }else if(agencyData){
                        var logoUrl = req.config.email.base_url+ (agencyData.profile_pic ? agencyData.profile_pic :req.config.email.logo_url);
                        var profileUrl = req.config.email.base_url+ (result.interpreter_id.profile_pic ? result.interpreter_id.profile_pic: req.config.upload_dir.USER_PROFILE_PIC);
                        var timestamp = Number(new Date());
                        var options = { "format": "Letter"};
                        var filename = "doc" + timestamp + '_' + common.randomToken(6) +  ".pdf";
                        var path = "./../client/users/assets/uploads/reports/" + filename;
                       
                        var headerHtml = "<!DOCTYPE html><head><meta charset='utf-8' /><meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'/><meta http-equiv='X-UA-Compatible' content='IE=edge' /><meta http-equiv='Content-Type' content='text/html; charset=utf-8'><title>HTML</title></head>"+
                                           "    <div style='font-size: 9px; margin:0 auto;width:100%; min-height: 611px;'>"+
                                           "    <img src="+logoUrl+" alt='company logo' style='position: absolute;height:350px;padding-left: 5px; opacity: 0.1;  margin-left: 120px; margin-top: 200px; width: 350px; z-index: -1;border-radius: 100%; padding-top:5px;'>"+
                                           "    <div style='float:left;width:100%;border:1px solid #88191c;'>"+
                                           "    <div style='float:left;width:100%;border-bottom:1px solid #88191c;'>"+
                                           "    <div style='float:left;'>"+
                                           "    <img src="+logoUrl+" alt='company logo' style='width:50px;padding-left: 2px;border-radius: 100%; padding-top:1px;'>"+
                                           "    </div>"+
                                           "    <div style='float:left;padding-top: 18px;padding-left: 20px;color:#602826;font-weight:bold;'>"+agencyData.agency_name+"</div>"+
                                           "    <div style='float: right;'>"+ 
                                           "    <div style='float:left;padding-top: 18px;'><span style='float:left; font-weight:bold;  padding-right: 5px;'>Interpreter’s name:</span>"+result.interpreter_id.first_name.charAt(0).toUpperCase()+result.interpreter_id.first_name.slice(1).toLowerCase()+ ' ' +result.interpreter_id.last_name.charAt(0).toUpperCase()+result.interpreter_id.last_name.slice(1).toLowerCase()+"</div>"+
                                           "    <img src="+profileUrl+" alt='Interpreter profile' style='float: left; margin-left: 5px; margin-top:3px; border: 1px solid #777; margin-right: 4px; width: 36px; height:36px; border-radius: 100%; padding-bottom: 1px;'>"+
                                           "    </div>"+
                                           "    </div>";

                        var footerHtml =   "";

                        var html = "    <div style='float:left;width:100%;'>"+
                                           "    <div style='float:left;width:100%;text-align:center;font-weight:bold;padding:10px 0; margin-bottom:10px;'>Event Description</div>"+
                                           "    <div style='width:100%;float:left;margin-bottom:10px;'>"+
                                           "    <div style='float:left;width:50%;'><span style='font-weight:bold;float: left; width: 70px;padding-left: 5px;'>Service Title:</span>"+result.service_title+"</div>"+
                                           "    <div style='float:left;width:50%;'><span style='font-weight:bold;float: left;width: 70px;'>Date:</span>"+moment(result.booking_from).format('ddd DD-MMM-YYYY')+"</div>"+
                                           "    <div style='float:left;width:50%;'><span style='font-weight:bold;float: left;width: 70px;padding-left: 5px;'>Time:</span>"+result.working_from+ ' - '+result.working_to+"</div>"+
                                           "    <div style='float:left;width:50%;'><span style='font-weight:bold;float: left;width: 70px;'>Language:</span>"+result.language_id.language_name.charAt(0).toUpperCase()+result.language_id.language_name.slice(1).toLowerCase()+"</div>"+
                                           "    <div style='float:left;width:50%;'><span style='font-weight:bold;float: left;width: 70px;padding-left: 5px;'>Contact Info:</span>"+result.client_id.first_name.charAt(0).toUpperCase()+result.client_id.first_name.slice(1).toLowerCase()+ ' ' +result.client_id.last_name.charAt(0).toUpperCase()+result.client_id.last_name.slice(1).toLowerCase()+"</div>"+
                                           "    <div style='float:left;width:50%;'><span style='font-weight:bold;float: left;width: 70px;'>Address:</span>"+result.address+"</div>"+
                                           "    </div>"+
                                           "    </div>"+
                                  
                                           "    <div style='float:left;width:100%;border-bottom:1px solid #88191c;'>"+
                                           "    <table style='float:left;width:100%;'>"+
                                           "    <thead style='background:#a6b6cb;'>"+
                                           "    <tr>"+
                                           "    <th style='text-align:center;padding:5px;'>Case Name/LEP Name</th>"+
                                           "    <th style='text-align:center;padding:5px;'>Case#</th>"+
                                           "    <th style='text-align:center;padding:5px;'>Comments</th>"+
                                           "    </tr>"+
                                           "    </thead>"+
                                           "    <tbody style='background:#eee;'>"+
                                           "    <tr>"+
                                           "    <td style='text-align:center;'> - </td>"+
                                           "    <td style='text-align:center;'> - </td>"+
                                           "    <td style='text-align:center;'> - </td>"+
                                           "    </tr>"+
                                           "    </tbody>"+
                                           "    </table>"+
                                           "    </div>"+

                                           "    <div style='float:left;width:100%;border-bottom:1px solid #88191c;'>"+
           
                                           "    <div style='width:30%;float:left;border-right:1px solid #88191c;height:100px;padding:5px;'>Stamp In/Time in</div>"+
                                           "     <div style='width:30%;float:left;border-right:1px solid #88191c;height:100px;padding:5px;'>Stamp Out/Time out</div>"+
                                           "     <div style='width:30%;float:left;padding:5px;'>Report:</div>"+
                                           "    </div>"+
                                               
                                           "    <div style='float:left;width:100%;'>"+
                                               
                                           "     <div style='width:48.15%;float:left;border-right:1px solid #88191c;height:100px;padding:5px;'>Authorizing Signature</div>"+
                                           "     <div style='width:48.15%;float:left;height:100px;padding:5px;'>Authorizing Name</div>"+
                                               
                                           "    </div>"+

                                           "    </div>"+
                                           "    </div>";
                        var finalHtml = headerHtml + html + footerHtml;
                        pdf.create(finalHtml, options).toFile(path, function(err, data) {
                            if(err){
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("ERROR")
                                })
                            } else{
                                 res.json({
                                    status: req.config.statusCode.success,
                                    data: path,
                                    message: i18n.__("Get file path successfully")
                                });
                            } 
                        });
                    }
                })
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("No record found.")
                })
            });
    },

    listClientBookingSuperAdmin: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            client_id: mongoose.Types.ObjectId(req.body.client_id),
            is_deleted: false
        }

        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        // var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                'interpreterInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'interpreterInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'booking_id': new RegExp(searchText, 'gi')
            },
            {
                'service_title': new RegExp(searchText, 'gi')
            }
            ];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'interpreters',
                localField: "interpreter_id",
                foreignField: "_id",
                as: "interpreterInfo"
            }
        },
        {
            $unwind: {
                path: "$interpreterInfo",
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $match: condition
        }
        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        Booking.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                Booking.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },


    listBookingInterpreterSuperAdmin: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            interpreter_id: mongoose.Types.ObjectId(req.body.interpreter_id),
            is_deleted: false
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        // var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                'clientInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'clientInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'booking_id': new RegExp(searchText, 'gi')
            },
            {
                'service_title': new RegExp(searchText, 'gi')
            }
            ];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'clients',
                localField: "client_id",
                foreignField: "_id",
                as: "clientInfo"
            }
        },
        {
            $unwind: {
                path: "$clientInfo",
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $match: condition
        },{
            $lookup: {
                from: 'interpreters',
                localField: "interpreter_id",
                foreignField: "_id",
                as: "interpreterInfo"
            }
        }, {
            $unwind: {
                path: "$interpreterInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $match: condition
        }
        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        Booking.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                Booking.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        console.log("result",result);
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    getBookingDetailCalendarSuperAdmin: function (req, res, next) {
        var startDate = moment(req.body.startDate).startOf('day'); // set to 12:00 am today
        var endDate = moment(req.body.startDate).endOf('day');
        var btwnCondition = {};
        btwnCondition = {
            $or: [
                {
                    $and: [
                        { booking_from: { $gte: new Date(startDate)} },
                        { booking_from: { $lte: new Date(endDate)} }
                    ]
                }, 
                {
                    $and: [
                        { booking_to: { $gte: new Date(startDate)} }, 
                        { booking_to: { $lte: new Date(endDate)} }
                    ]
                },            
                {
                    $and: [
                        { booking_from: { $lte: new Date(moment(req.body.startDate))} }, 
                        { booking_to: { $gte: new Date(moment(req.body.startDate))} }
                    ]
                },                        
            ]
        };
        btwnCondition.interpreter_id = mongoose.Types.ObjectId(req.body.interpreter_id);
        Booking.find(btwnCondition)
        .populate('client_id', 'first_name last_name')
        .then((bookingData)=>{
            if(!bookingData){
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })
            }else{
                res.json({
                    status: req.config.statusCode.success,
                    data: bookingData,
                    message: i18n.__('GET_BOOKING_DETAILS_SUCCESSFULLY')
                });
            }
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })

        });            
    },

    getCompletedInterpreterBookings: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            interpreter_id: mongoose.Types.ObjectId(req.body.interpreterId),
            agency_id: mongoose.Types.ObjectId(req.user.id),
            is_deleted: false,
            status: 'closed'
        }

        var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                'clientInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'clientInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'booking_id': new RegExp(searchText, 'gi')
            },
            {
                'service_title': new RegExp(searchText, 'gi')
            }];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'clients',
                localField: "client_id",
                foreignField: "_id",
                as: "clientInfo"
            }
        },
        {
            $unwind: {
                path: "$clientInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $match: condition
        }

        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        Booking.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                Booking.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var bookingArray = []
                        async.each(result, function(singleBooking, callback) {
                            var singleNewBooking = {};
                            singleNewBooking = singleBooking;
                            var startTime = moment(singleBooking.working_from, "HH:mm a");
                            var endTime = moment(singleBooking.working_to, "HH:mm a");
                            var duration = moment.duration(endTime.diff(startTime));
                            var hours = parseInt(duration.asHours());
                            var minutes = parseInt(duration.asMinutes())-hours*60;
                            var working_hours =  hours + ' hrs and '+ minutes+' min';
                            singleBooking.working_hours = working_hours;
                            bookingArray.push(singleBooking);
                            callback();
                        }, function(err) {
                            if (err) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: [],
                                    count: 0,
                                    message: i18n.__("ERROR")
                                });
                            } else {
                                var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                                res.json({
                                    status: req.config.statusCode.success,
                                    data: bookingArray,
                                    count: cnt
                                });
                            }
                        })
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    exportToPdfByInterpreterIdInReports: function (req, res, next) {
        var logoUrl = req.config.email.base_url+req.config.email.logo_url;
        var timestamp = Number(new Date());
        Booking.find({agency_id: mongoose.Types.ObjectId(req.user.id), interpreter_id: mongoose.Types.ObjectId(req.params.id), is_deleted:false, status: 'closed'})
            .populate('client_id', 'first_name last_name')
            .populate('interpreter_id', 'first_name last_name')
            .then((result) => {
                if(!result){
                    res.json({
                        status: req.config.statusCode.error,
                        data: [],
                        message: i18n.__("ERROR")
                    });
                }else if(result.length > 0){
                    AgencyModel.findOne({user_id: mongoose.Types.ObjectId(req.user.id), status: true})
                    .populate('country_id')
                    .exec(function(err, agencyData){
                        if(err){
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            });
                        }else if(agencyData){
                            var options = { "format": "Letter"};
                            var profileUrl = req.config.email.base_url+ (agencyData.profile_pic ? agencyData.profile_pic: req.config.upload_dir.USER_PROFILE_PIC);
                            var filename = "doc" + timestamp + '_' + common.randomToken(6) +  ".pdf";
                            var path = "./../client/users/assets/uploads/reports/" + filename;
                            var agencyName = agencyData.agency_name;
                            if(agencyName && agencyData.address1!= '' && agencyData.address1 != null && agencyData.address1 != undefined && agencyData.address2 != '' && agencyData.address2 != null && agencyData.address2 != undefined){
                                var agencyAddress = agencyData.address1+', '+agencyData.address2+ ', '+agencyData.city+', '+agencyData.state+', '+agencyData.country_id.country_code.toUpperCase()+', '+agencyData.zip;   
                            }else if(agencyName && agencyData.address1 && !agencyData.address2){
                                var agencyAddress = agencyData.address1+', '+agencyData.city+', '+agencyData.state+', '+agencyData.country_id.country_code.toUpperCase()+', '+agencyData.zip;
                            }else{
                                var agencyAddress = '';
                            } 

                            var headerHtml  = "<!DOCTYPE html><head><meta charset='utf-8' /><meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'/><meta http-equiv='X-UA-Compatible' content='IE=edge' /><meta http-equiv='Content-Type' content='text/html; charset=utf-8'><title>HTML</title></head>"+
                                               "   <body style='float: left; width: 100%; margin: 0px; padding: 0px; height: 100%; font-family: sans-serif,arial; font-size: 11px; color: rgb(85, 85, 85); background: rgb(252, 252, 252) none repeat scroll 0% 0%;'>"+
                                               "    <div style='float: left; width: 100%;  box-sizing: border-box; padding: 20px 5px 0px; overflow: auto; '>"+

                                               "    <div style='float:left;'>"+
                                               "    <img src="+profileUrl+" alt='company logo' style='width:60px;padding-left: 5px;border-radius: 100%; padding-top:1px;'>"+
                                               "    </div>"+

                                               "    <div style='float: right; width: 222px;'>"+
                                               "        <div style='float: left; width: 100%; height: auto; box-sizing: border-box; margin-bottom: 6px; font-size: 15px; color: rgb(51, 51, 51); text-align: left; word-wrap: break-word; '>"+ agencyName +"</div>"+
                                               "        <div style='float: left; width: 222px; height: auto; box-sizing: border-box; text-align: left; word-wrap: break-word;'>"+agencyAddress+"</div>"+
                                               "    </div>"+
                                               "    </div>"+
                                               "    <div style='float: left; padding-left:10px; width: 100%; box-sizing: border-box; margin-top: 21px; padding-top: 10px; border-top: 1px solid #eee;'>"+
                                               "    <div style='float: left; font-weight: bold; font-size: 10px;'>Report Name : Booking Per Interpreter</div>"+
                                               "    <div style='float: right; box-sizing: border-box; padding-right: 10px;  font-size: 10px; font-weight: bold;'>Account Name : "+result[0].interpreter_id.first_name+" "+result[0].interpreter_id.last_name+"</div>"+
                                               "    </div>"+
                                               "    <div style='float: left; width: calc(100% - 10px;);   margin-left:5px; margin-right:5px; box-sizing: border-box; border: 1px solid rgb(204, 204, 204); margin-top: 15px; background: white none repeat scroll 0% 0%;'>"+
                                               "    <div style='float: left; width: 100%; box-shadow: 0px 0px 7px 2px #ddd; min-height: 615px;'>"+
                                               "    <div style='float: left; width: 100%;'>"+
                                               "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Booking Id</div>"+
                                               "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Service Title</div>"+
                                               "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Account Name</div>"+
                                               "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Booking Date</div>"+
                                               "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Booking Time</div>"+
                                               "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px; border-right: 0;'>Working Hours</div>"+
                                               "    </div>";

                            var footerHtml =   "    </div>"+
                                               "    </div>"+
                                               "    </div>"+
                                               "    <div style='float: left; position: fixed: bottom: 0; width: 100%; background: #eee; box-sizing: border-box; padding: 4px 0px;'>"+
                                               "    <div style='font-style: italic; width: 100%; max-width: 1200px; text-align: center; float: none; margin: 0px auto; box-sizing: border-box; padding-right: 5px;'>All Rights Reserved &copy; Language Link Corporation</div>"+
                                               "    </div>"+
                                               "    </body>"+
                                               "    </html>";

                              var html = "";

                              async.eachSeries(result, function(bookingObj, next){

                                        var resultOne = {};
                                        resultOne = bookingObj;
                                        var startTime = moment(resultOne.working_from, "HH:mm a");
                                        var endTime = moment(resultOne.working_to, "HH:mm a");
                                        var duration = moment.duration(endTime.diff(startTime));
                                        var hours = parseInt(duration.asHours());
                                        var minutes = parseInt(duration.asMinutes())-hours*60;
                                        var working_hours =  hours + ' hrs and '+ minutes+' min';
                                        resultOne.working_hours = working_hours;

                                        html += "<div style='width: 100%; position: relative; height: 100%; float: left; border-bottom: 1px solid #ccc;'>"+
                                               "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.booking_id+"</div>"+
                                               "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.service_title+"</div>"+
                                               "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.client_id.first_name+" "+resultOne.client_id.last_name+"</div>"+
                                               "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+moment(resultOne.booking_from).format("DD/MMM/YYYY")+"</div>"+
                                               "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.working_from+" - "+resultOne.working_to+"</div>"+
                                               "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.working_hours+"</div>"+
                                               "</div>";
                                       var finalHtml = headerHtml+html+footerHtml;
                                        pdf.create(finalHtml, options).toFile(path, function(err, data) {
                                        if(err){
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: {},
                                                message: i18n.__("ERROR")
                                            })
                                        } else{
                                            next();
                                        } 
                                      });
                                         
                                },function(err){
                                  if(err){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("ERROR")
                                    })
                                  }else{
                                    res.json({
                                        status: req.config.statusCode.success,
                                        data: path,
                                        message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                                    });
                                  }
                                })
                        }else{
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            });
                        }
                    })
                }else{
                    res.json({
                        status: req.config.statusCode.notFound,
                        data: {},
                        message: i18n.__("NO_RECORD_FOUND")
                    });
                }
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                })

            });
    },



}   

