module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];

    var booking_ctrl = require('./controllers/booking_ctrl')

    router.get('/bookings/listBookings', middlewares, booking_ctrl.listBookings)
    router.get('/bookings/getBooking/:id', middlewares, booking_ctrl.getBooking)
    router.get('/bookings/getBookingViewById/:id', middlewares, booking_ctrl.getBookingViewById)
    router.post('/bookings/getBookingInterpretersLocation', middlewares, booking_ctrl.getBookingInterpretersLocation)
    router.post('/bookings/sendRequestToInterpreters', middlewares, booking_ctrl.sendRequestToInterpreters)
    router.post('/bookings/addBooking', middlewares, booking_ctrl.addBooking)
    router.post('/bookings/updateBooking', middlewares, booking_ctrl.updateBooking)
    router.delete('/bookings/deleteBooking/:id', middlewares, booking_ctrl.deleteBooking)
    router.post('/bookings/getAgencyBookingList', middlewares, booking_ctrl.getAgencyBookingList)
    router.post('/bookings/listBookingByInterpreterId', middlewares, booking_ctrl.listBookingByInterpreterId)
    router.get('/bookings/getInterpreterBookingById/:id', middlewares, booking_ctrl.getInterpreterBookingById)
    router.get('/bookings/getBookingInterpreterById/:id', middlewares, booking_ctrl.getBookingInterpreterById)
    router.post('/bookings/listBookingByClientId', middlewares, booking_ctrl.listBookingByClientId)
    router.post('/bookings/addBookingByClient', middlewares, booking_ctrl.addBookingByClient)
    router.get('/bookings/getClientBookingById/:id', middlewares, booking_ctrl.getClientBookingById)
    router.post('/bookings/updateBookingByClient', middlewares, booking_ctrl.updateBookingByClient)
    router.post('/bookings/cancelBookingByClient', middlewares, booking_ctrl.cancelBookingByClient)
    router.post('/bookings/closeBookingByClient', middlewares, booking_ctrl.closeBookingByClient)
    router.get('/bookings/getBookingByClientId/:id', middlewares, booking_ctrl.getBookingByClientId)
    router.get('/bookings/getClientBookingViewById/:id', middlewares, booking_ctrl.getClientBookingViewById)
    router.post('/bookings/searchBookingByDate', middlewares, booking_ctrl.searchBookingByDate)
    router.post('/bookings/listBookingByClientIdInReport', middlewares, booking_ctrl.listBookingByClientIdInReport)
    router.post('/bookings/listLanguageBookingInReport', middlewares, booking_ctrl.listLanguageBookingInReport)
    router.get('/bookings/listTopTenLanguageReport', middlewares, booking_ctrl.listTopTenLanguageReport)  
    router.get('/bookings/exportPdfTopTenLaguageReport', middlewares, booking_ctrl.exportPdfTopTenLaguageReport)   
    router.post('/bookings/getBookingDetailForInterpreterCalendar', middlewares, booking_ctrl.getBookingDetailForInterpreterCalendar);
    router.post('/bookings/getBookingDetailForInterpreterCalendarInAgency', middlewares, booking_ctrl.getBookingDetailForInterpreterCalendarInAgency);
    router.post('/bookings/getInterpreterBookingViewByIdInAgency', middlewares, booking_ctrl.getInterpreterBookingViewByIdInAgency);
    router.post('/bookings/listBookingOfInterpreterInAgency', middlewares, booking_ctrl.listBookingOfInterpreterInAgency)
    router.post('/bookings/listBookingOfClientInAgency', middlewares, booking_ctrl.listBookingOfClientInAgency)
    router.post('/bookings/getClientBookingByIdInAgency', middlewares, booking_ctrl.getClientBookingByIdInAgency);
    router.get('/bookings/getInterpreterBookingViewById/:id', middlewares, booking_ctrl.getInterpreterBookingViewById);  
    router.get('/bookings/downloadPaperVoucher', middlewares, booking_ctrl.downloadPaperVoucher);
    router.post('/bookings/listClientBookingSuperAdmin', middlewares, booking_ctrl.listClientBookingSuperAdmin);
    router.post('/bookings/listBookingInterpreterSuperAdmin', middlewares, booking_ctrl.listBookingInterpreterSuperAdmin);
    router.post('/bookings/getBookingDetailCalendarSuperAdmin', middlewares, booking_ctrl.getBookingDetailCalendarSuperAdmin);
    router.post('/bookings/getCompletedInterpreterBookings', middlewares, booking_ctrl.getCompletedInterpreterBookings)
    router.get('/bookings/exportToPdfByInterpreterIdInReports/:id', middlewares, booking_ctrl.exportToPdfByInterpreterIdInReports)
    
        
    return router;
}