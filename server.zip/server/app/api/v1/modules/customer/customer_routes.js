var crypto = __rootRequire('app/utils/crypto');
module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];
    var customer_ctrl = require('./controllers/customer_ctrl')
    
    router.post('/customercomplaint/listComplaints', middlewares, customer_ctrl.listComplaints);
    router.post('/customercomplaint/addcustomercomplaint', middlewares, customer_ctrl.addCustomerComplaint);
    router.post('/customercomplaint/updatecustomercomplaint', middlewares, customer_ctrl.updateCustomerComplaint);
    router.get('/customercomplaint/getBookingIdsByClientId', middlewares, customer_ctrl.getBookingIdsByClientId);
    router.get('/customercomplaint/getBookingsByAgencyId', middlewares, customer_ctrl.getBookingsByAgencyId);
    router.post('/customercomplaint/searchComplaintByDate', middlewares, customer_ctrl.searchComplaintByDate)
    router.delete('/customercomplaint/deleteComplaint/:id',middlewares, customer_ctrl.deleteComplaint);
    router.get('/customercomplaint/getCompletedBookingsByClientId', middlewares, customer_ctrl.getCompletedBookingsByClientId);
    router.get('/customercomplaint/getSelectedBookingDetail', middlewares, customer_ctrl.getSelectedBookingDetail);
    router.post('/customercomplaint/lodgeComplaintByClient', middlewares, customer_ctrl.lodgeComplaintByClient);
    router.post('/customercomplaint/lodgeComplaintByAgency', middlewares, customer_ctrl.lodgeComplaintByAgency);
    router.get('/customercomplaint/getCompletedBookingsForUpdate', middlewares, customer_ctrl.getCompletedBookingsForUpdate);
    router.post('/customercomplaint/makeComplaintInProcess', middlewares, customer_ctrl.makeComplaintInProcess);
    router.post('/customercomplaint/makeComplaintStatusCompleted', middlewares, customer_ctrl.makeComplaintStatusCompleted);
    router.post('/customercomplaint/approveComplaint', middlewares, customer_ctrl.approveComplaint);
    router.get('/customercomplaint/getComplaintById/:id', middlewares, customer_ctrl.getComplaintById);
    

    return router;
}