const _ = require("lodash");
const moment = require('moment');
const Joi = require('joi');
const i18n = require("i18n");
const mongoose = require('mongoose');
const santize = __rootRequire('app/utils/santize');
const image = __rootRequire('app/utils/image');
const text = __rootRequire('app/utils/text');
//Models 
const User = mongoose.model('Users');
const AgencyModel = mongoose.model('Agencies');
const Booking = mongoose.model('Bookings');
const ClientModel = mongoose.model('Clients');
const InterpreterModel = mongoose.model('Interpreters');
const EmailTemplateModel = mongoose.model('Email_Templates');
const AgencyUser = mongoose.model('Agency_users');
const Services = mongoose.model('Services');
const CustomerComplaintModel = mongoose.model('Customercomplaint');
const SchedulerModel = mongoose.model('Schedulers');
const CheckInOutModel = mongoose.model('Check_in_outs');


module.exports = {

    listComplaints: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {};
        if(req.user.role == 'client'){
            condition = { 
                agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                client_id: mongoose.Types.ObjectId(req.user.client_id),
                is_deleted: false
            };
        }else if(req.user.role == 'agency_admin'){
            condition = { 
                agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                is_deleted: false
            };

            if(req.body.client_id !=null && req.body.client_id !=undefined && req.body.client_id !=''){
                condition.client_id = mongoose.Types.ObjectId(req.body.client_id);
            }
        }
        
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                    'interpreterInfo.first_name': new RegExp(searchText, 'gi')
                },
                {
                    'interpreterInfo.last_name': new RegExp(searchText, 'gi')
                },
                {
                    'clientInfo.first_name': new RegExp(searchText, 'gi')
                },
                {
                    'clientInfo.last_name': new RegExp(searchText, 'gi')
                },
                {
                    'bookingInfo.booking_short_id': new RegExp(searchText, 'gi')
                },
                {
                    'service_title': new RegExp(searchText, 'gi')
                },
                {
                    'status': new RegExp(searchText, 'gi')
                }
            ];
        }

        var aggregateQuery = [{
                $lookup: {
                    from: 'interpreters',
                    localField: "interpreter_id",
                    foreignField: "_id",
                    as: "interpreterInfo"
                }
            },
            {
                $unwind: {
                    path: "$interpreterInfo",
                    preserveNullAndEmptyArrays: true
                }
            },{
                $lookup: {
                    from: 'clients',
                    localField: "client_id",
                    foreignField: "_id",
                    as: "clientInfo"
                }
            },
            {
                $unwind: {
                    path: "$clientInfo",
                    preserveNullAndEmptyArrays: true
                }
            },{
                $lookup: {
                    from: 'schedulers',
                    localField: "booking_id",
                    foreignField: "_id",
                    as: "bookingInfo"
                }
            }, {
                $unwind: {
                    path: "$bookingInfo",
                    preserveNullAndEmptyArrays: true
                }
            },{
                $match: condition
            }
        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        CustomerComplaintModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                CustomerComplaintModel.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },


    addCustomerComplaint: function (req, res, next) {
        customers = new CustomerComplaintModel(req.body);
        customers.save()
            .then((result) => {
                res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    message: i18n.__("CUSTOMER_COMPLAINT_ADDED_SUCCESSFULLY")
                });
            }).catch((err) => {
                //__debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });


    },

    getBookingIdsByClientId: function (req, res, next) {
        Booking.find({client_id: req.user.client_id, is_deleted:false},{booking_id:1}).exec(function(err, bookingData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })
            } else{
                res.json({
                    status: req.config.statusCode.success,
                    data: bookingData,
                    message: i18n.__("GET_ BOOKING_ID_BY_CLIENT_ID")
                });
            }
        })
    },

    getBookingsByAgencyId: function (req, res, next) {
        Booking.find({agency_id: req.user.id, is_deleted:false}).exec(function(err, bookingData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })
            } else{
                res.json({
                    status: req.config.statusCode.success,
                    data: bookingData,
                    message: i18n.__("Get booking data by agency id")
                });
            }
        })
    },

    searchComplaintByDate: function (req, res, next) {
        var dateFrom = moment(req.body.searchFrom).startOf('day');
        var dateTo = moment(req.body.searchTo).endOf('day');

        var momentObjFrom = new Date(moment(dateFrom));
        var momentObjTo = new Date(moment(dateTo));
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {};
        if(req.user.role == 'client'){
            condition = { 
                agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                client_id: mongoose.Types.ObjectId(req.user.client_id),
                createdAt: {$gte: momentObjFrom, $lte: momentObjTo},
                is_deleted: false
            };
        }else if(req.user.role == 'agency_admin'){
            condition = { 
                agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                createdAt: {$gte: momentObjFrom, $lte: momentObjTo},
                is_deleted: false
            };
            if(req.body.client_id !=null && req.body.client_id !=undefined && req.body.client_id !=''){
                condition.client_id = mongoose.Types.ObjectId(req.body.client_id);
            }
        }

        var aggregateQuery = [{
                $lookup: {
                    from: 'interpreters',
                    localField: "interpreter_id",
                    foreignField: "_id",
                    as: "interpreterInfo"
                }
            },
            {
                $unwind: {
                    path: "$interpreterInfo",
                    preserveNullAndEmptyArrays: true
                }
            },{
                $lookup: {
                    from: 'clients',
                    localField: "client_id",
                    foreignField: "_id",
                    as: "clientInfo"
                }
            },
            {
                $unwind: {
                    path: "$clientInfo",
                    preserveNullAndEmptyArrays: true
                }
            },{
                $lookup: {
                    from: 'schedulers',
                    localField: "booking_id",
                    foreignField: "_id",
                    as: "bookingInfo"
                }
            }, {
                $unwind: {
                    path: "$bookingInfo",
                    preserveNullAndEmptyArrays: true
                }
            },{
                $match: condition
            }
        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        CustomerComplaintModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                CustomerComplaintModel.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    getCompletedBookingsByClientId: function (req, res, next) {
        var condition = {};
        if(req.user.role == 'client'){
            condition = { 
                agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                client_id: mongoose.Types.ObjectId(req.user.client_id),
                is_deleted: false,
                check_io_approval: 'approved',
                is_complaint_lodge: false
            };
        }else if(req.user.role == 'agency_admin'){
            condition = { 
                agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                is_deleted: false,
                check_io_approval: 'approved',
                is_complaint_lodge: false
            };
        }

        CheckInOutModel.find(condition, {check_in_date: 1})
        .populate('booking_id', 'service_title')
        .exec(function(err, bookingData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                })
            }else{
                res.json({
                    status: req.config.statusCode.success,
                    data: bookingData,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }
        })
    },

    getCompletedBookingsForUpdate: function (req, res, next) {
        var condition = {};
        if(req.user.role == 'client'){
            condition = { 
                agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                client_id: mongoose.Types.ObjectId(req.user.client_id),
                is_deleted: false,
                check_io_approval: 'approved'
            };
        }else if(req.user.role == 'agency_admin'){
            condition = { 
                agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                is_deleted: false,
                check_io_approval: 'approved'
            };
        }

        CheckInOutModel.find(condition, {check_in_date: 1})
        .populate('booking_id', 'service_title')
        .exec(function(err, bookingData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                })
            }else{
                console.log("bookingData", bookingData);
                res.json({
                    status: req.config.statusCode.success,
                    data: bookingData,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }
        })
    },

    getSelectedBookingDetail: function (req, res, next) {
        var condition = {};
        if(req.user.role == 'client'){
            condition = { 
                _id: mongoose.Types.ObjectId(req.query.id),
                agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                client_id: mongoose.Types.ObjectId(req.user.client_id),
                is_deleted: false,
                check_io_approval: 'approved'
            };
        } else if(req.user.role == 'agency_admin'){
            condition = { 
                _id: mongoose.Types.ObjectId(req.query.id),
                agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                is_deleted: false,
                check_io_approval: 'approved'
            };
        }
        
        CheckInOutModel.findOne(condition, {check_in_date: 1})
        .populate('booking_id', 'booking_short_id service_title booking_description')
        .populate('interpreter_id', 'first_name last_name')
        .populate('client_id', '_id first_name last_name')
        .populate('agency_id', '_id')
        .exec(function(err, bookingData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            }else{
                res.json({
                    status: req.config.statusCode.success,
                    data: bookingData,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }
        })
    },

    lodgeComplaintByClient: function (req, res, next) { 
        var customers = new CustomerComplaintModel(req.body);
        customers.save(function(err, saveComplaint){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })
            }else{
                CheckInOutModel.findOneAndUpdate({
                    _id: saveComplaint.check_in_out_id,
                }, {
                    is_complaint_lodge: true
                },{
                    new: true
                })
                .exec(function(err, result){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        })
                    }else{
                        res.json({
                            status: req.config.statusCode.success,
                            data: saveComplaint,
                            message: i18n.__("CUSTOMER_COMPLAINT_ADDED_SUCCESSFULLY")
                        }); 
                    }
                })   
            }
        }).catch(function(err){
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        })
    },

    getComplaintById: function (req, res, next) {
        if(mongoose.Types.ObjectId.isValid(req.params.id)){
            CustomerComplaintModel.findById(req.params.id)
            .populate('client_id', 'first_name last_name')
            .populate('interpreter_id', 'first_name last_name')
            .populate('booking_id', 'booking_short_id')
            .exec(function(err, result) {
                if(err){
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                }else{
                    res.json({
                        status: req.config.statusCode.success,
                        data: result,
                        message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                    });
                }
            }).catch(function(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            });
        }else{
            res.json({
                status: req.config.statusCode.invalid,
                data: {},
                message: i18n.__("INVALID_ID")
            });
        }
    },

    updateCustomerComplaint: function (req, res, next) {
        var updateData = req.body;
        CustomerComplaintModel.findOneAndUpdate({
            _id: req.body._id,
        }, {
            $set: updateData
        },{
            new: true
        })
        .exec(function(err, result){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            }else{
                res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    message: i18n.__("COMPLAINT_UPDATED")
                });
            }
        }).catch(function(err){
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        });
    },

    deleteComplaint: function (req, res, next) {
        CustomerComplaintModel.findOneAndUpdate({
            _id: req.params.id,
        }, {
            $set: {
                is_deleted: true
            }
        }, {
            new: true
        })
        .exec(function(err, result){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            }else{
                CheckInOutModel.findOneAndUpdate({
                    _id: result.check_in_out_id,
                }, {
                    is_complaint_lodge: false
                }, {
                    new: true
                })
                .exec(function(err, result){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        })
                    }else{
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            message: i18n.__("COMPLAINT_DELETED")
                        });
                    }
                })
            }
        }).catch(function(err){
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        });
    },

    lodgeComplaintByAgency: function (req, res, next) { 
        var customers = new CustomerComplaintModel(req.body);
        customers.save(function(err, saveComplaint){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })
            }else{
                CheckInOutModel.findOneAndUpdate({
                    _id: saveComplaint.check_in_out_id,
                }, {
                    is_complaint_lodge: true
                },{
                    new: true
                })
                .exec(function(err, result){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        })
                    }else{
                        res.json({
                            status: req.config.statusCode.success,
                            data: saveComplaint,
                            message: i18n.__("CUSTOMER_COMPLAINT_ADDED_SUCCESSFULLY")
                        }); 
                    }
                }) 
            }
        }).catch(function(err){
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        })
    },

    makeComplaintInProcess: function (req, res, next) {
        CustomerComplaintModel.findOneAndUpdate({
            _id: req.body.id,
        }, {
            status: 'in_process'
        }, {
            new: true
        })
        .exec(function(err, result){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            }else{
                 res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    message: i18n.__("COMPLAINT_STATUS_CHANGED")
                });
            }
        }).catch(function(err){
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        });
    },

    makeComplaintStatusCompleted: function (req, res, next) {
        CustomerComplaintModel.findOneAndUpdate({
            _id: req.body.id,
        }, {
            status: 'completed'
        }, {
            new: true
        })
        .exec(function(err, result){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            }else{
                 res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    message: i18n.__("COMPLAINT_STATUS_CHANGED")
                });
            }
        }).catch(function(err){
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        });
    },

    approveComplaint: function (req, res, next) {
        CustomerComplaintModel.findOneAndUpdate({
            _id: req.body.id,
        }, {
            status: 'closed'
        }, {
            new: true
        })
        .exec(function(err, result){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            }else{
                 res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    message: i18n.__("COMPLAINT_STATUS_CHANGED")
                });
            }
        }).catch(function(err){
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        });
    },

}