const _ = require("lodash");
const moment = require('moment');
const Joi = require('joi');
const i18n = require("i18n");
const mongoose = require('mongoose');
const santize = __rootRequire('app/utils/santize');
const image = __rootRequire('app/utils/image');
const text = __rootRequire('app/utils/text');
const formidable = require('formidable');
const fs = require('fs');
const fs_extra= require('fs-extra');
const path = require('path');
const common = __rootRequire('app/config/common.js');

//Models 
const User = mongoose.model('Users');
const AgencyModel = mongoose.model('Agencies');
const Booking = mongoose.model('Bookings');
const ClientModel = mongoose.model('Clients');
const InterpreterModel = mongoose.model('Interpreters');
const EmailTemplateModel = mongoose.model('Email_Templates');
const AgencyUser = mongoose.model('Agency_users');
const Services = mongoose.model('Services');
const CustomerComplaintModel = mongoose.model('Customercomplaint');
const CarouselModel = mongoose.model('Carousels');


module.exports = {

    listCarouselSuperAdmin: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            updatedAt: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            is_deleted: false
        }

        var searchText = req.body.searchText;
        
        if(searchText){
            var regexStr = searchText.split('%20').join(" ");
        }
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [ {
                    'heading': new RegExp(regexStr, 'gi')
                },
                {
                    'description': new RegExp(regexStr, 'gi')
                }
            ];
        }

        CarouselModel.find(condition)
        .sort(sorting)
        .skip(parseInt(skip))
        .limit(parseInt(count))
        .exec(function(err, carouselData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                })
            }else if(carouselData.length > 0){
                CarouselModel.find(condition)
                    .count()
                    .exec(function(err, cnt){
                        if(err){
                            res.json({
                                status: req.config.statusCode.error,
                                data: [],
                                count: 0,
                                message: i18n.__("ERROR")
                            })
                        }else{
                            res.json({
                                status: req.config.statusCode.success,
                                data: carouselData,
                                count: cnt,
                                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                            });            
                        }
                    })
            }else{
                res.json({
                    status: req.config.statusCode.notFound,
                    data: [],
                    count: 0,
                    message: i18n.__("NO_RECORD_FOUND")
                })
            }
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            })

        });
    },

    addCarouselImage: function (req, res, next) {
        var form = new formidable.IncomingForm();
        form.parse(req, function (err, fields, files) {
            var carouselObj;
            var tmpCertificates = {};
            if(fields.carouselObj!=undefined && fields.carouselObj!=''){
                try{
                    carouselObj = JSON.parse(fields.carouselObj);
                }catch(err){

                }
            }
            if(typeof carouselObj == 'object'){
                var timestamp = Number(new Date()); // current time as number
                var fileName='';
                var fileExt = '';
                var carouselImagePath = "./../client/users/assets/uploads/carousel_image/";
                if(typeof files.imageFile == 'object'){
                    fileExt = files.imageFile.name.split('.');
                    if(fileExt.length>0){
                        fileExt = fileExt[fileExt.length-1];    
                    }else{
                        fileExt = '';
                    }
                    
                    tmpCertificates.imageFile = timestamp+'_'+common.randomToken(6)+"."+fileExt;
                    carouselObj.image ="/assets/uploads/carousel_image/"+tmpCertificates.imageFile;
                    
                    fs_extra.copy(files.imageFile.path, carouselImagePath + tmpCertificates.imageFile, function(err) {  
                        if (err) {
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        } else {
                            var carouselModel = new CarouselModel();
                            carouselModel.heading = carouselObj.heading;
                            carouselModel.description = carouselObj.description;
                            carouselModel.image = carouselObj.image;
                            carouselModel.save(function(err, carouselData){
                                if(err){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("ERROR")
                                    })
                                }else{
                                    res.json({
                                        status: req.config.statusCode.success,
                                        data: carouselData,
                                        message: i18n.__("SAVED")
                                    });
                                }
                            }).catch((err) => {
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("ERROR")
                                })

                            });
                        }
                    });
                }
            }else{
                res.json({
                    status: req.config.statusCode.badRequest,
                    data: {},
                    message: i18n.__("INVALID_REQUEST")
                })
            }  
        })
    },

    getUploadedCarouselBySuperAdmin: function (req, res, next) {
        var carouselId = req.params.id;
        CarouselModel.findById(carouselId,{'image':1, 'description':1, 'heading':1}).exec(function(err, carouselData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            }else if(carouselData){
                res.json({
                    status: req.config.statusCode.success,
                    data: carouselData,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }else{
                res.json({
                    status: req.config.statusCode.notFound,
                    data: {},
                    message: i18n.__("NO_RECORD_FOUND")
                })
            }
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })

        });
    },

    updateCarouselDetailBySuperAdmin: function (req, res, next) {
        var form = new formidable.IncomingForm();
        form.parse(req, function (err, fields, files) {
            var carouselObj;
            var tmpCertificates = {};
            if(fields.carouselObj!=undefined && fields.carouselObj!=''){
                try{
                    carouselObj = JSON.parse(fields.carouselObj);
                }catch(err){

                }
            }
            function updateRecord(carouselObj){
                CarouselModel.findOneAndUpdate({
                    _id: carouselObj._id,
                    is_deleted: false 
                },{
                    heading : carouselObj.heading,
                    description : carouselObj.description,
                    image : carouselObj.image    
                },{
                    new: true
                }).exec(function(err, carouselData){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        })
                    }else{
                        res.json({
                            status: req.config.statusCode.success,
                            data: carouselData,
                            message: i18n.__("UPDATED_SUCESS")
                        });
                    }
                }).catch(function(err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })

                });
            }
            if(typeof carouselObj == 'object'){

                var timestamp = Number(new Date()); // current time as number
                var fileName='';
                var fileExt = '';
                var carouselImagePath = "./../client/users/assets/uploads/carousel_image/";
                if(typeof files.imageFile == 'object'){
                    fileExt = files.imageFile.name.split('.');
                    if(fileExt.length>0){
                        fileExt = fileExt[fileExt.length-1];    
                    }else{
                        fileExt = '';
                    }
                    
                    tmpCertificates.imageFile = timestamp+'_'+common.randomToken(6)+"."+fileExt;
                    carouselObj.image ="/assets/uploads/carousel_image/"+tmpCertificates.imageFile;
                    
                    fs_extra.copy(files.imageFile.path, carouselImagePath + tmpCertificates.imageFile, function(err) {  
                        if (err) {
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        } else {
                            updateRecord(carouselObj);
                        }
                    });
                }else{
                    updateRecord(carouselObj);
                } 
            } 
        })
    },  

    deleteCarouselBySuperAdmin: function (req, res, next) {
        CarouselModel.findOneAndUpdate({
            _id: req.params.id
        }, {
            is_deleted: true
        }, {
            new: true
        })
        .exec(function(err, carouselData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            }else{
                res.json({
                    status: req.config.statusCode.success,
                    data: carouselData,
                    message: i18n.__("DELETED_SUCCESS")
                });       
            }
        }).catch(function(err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            })
        });
    },

    changeCarouselStatusBySuperAdmin: function (req, res, next) {
        CarouselModel.findOneAndUpdate({
            _id: req.body.id
        }, {
            status: req.body.status
        }, {
            new: true
        })
        .exec(function(err, result) {
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            }else{
                res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    message: i18n.__('Banner ' + ((req.body.status == true) ? 'activated' : 'deactivated') + ' successfully')
                });
            }
        })
    },

    getCarouselDetails: function (req, res, next) {
        CarouselModel.find({
            is_deleted:false,
            status: true
        },{
            'heading': 1, 'description': 1, 'image': 1
        }).exec(function(err, carouselData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            }else if(carouselData.length > 0){
                res.json({
                    status: req.config.statusCode.success,
                    data: carouselData,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }else{
                res.json({
                    status: req.config.statusCode.notFound,
                    data: {},
                    message: i18n.__("NO_RECORD_FOUND")
                })
            }   
        }).catch(function(err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            })
        });
    }    


}