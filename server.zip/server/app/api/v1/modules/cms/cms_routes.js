var crypto = __rootRequire('app/utils/crypto');
module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];
    var cms_ctrl = require('./controllers/cms_ctrl');

    router.post('/cms/listCarouselSuperAdmin', cms_ctrl.listCarouselSuperAdmin);
    router.post('/cms/addCarouselImage', cms_ctrl.addCarouselImage);
    router.get('/cms/getUploadedCarouselBySuperAdmin/:id', cms_ctrl.getUploadedCarouselBySuperAdmin);
    router.post('/cms/updateCarouselDetailBySuperAdmin', cms_ctrl.updateCarouselDetailBySuperAdmin);
    router.delete('/cms/deleteCarouselBySuperAdmin/:id', cms_ctrl.deleteCarouselBySuperAdmin);
    router.post('/cms/changeCarouselStatusBySuperAdmin', cms_ctrl.changeCarouselStatusBySuperAdmin);
    router.get('/cms/getCarouselDetails', cms_ctrl.getCarouselDetails);

    return router;
}