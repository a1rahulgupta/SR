var jwt = require('jsonwebtoken');
var Joi = require('joi');
var moment = require('moment');
var async = require('async');
var crypto = __rootRequire('app/utils/crypto');
var permissionModel = require('./../models/permission_model');
const uuidV4 = require('uuid/v4');
module.exports = {

    permission_tree: function (req, res, next) {
        var id = req.query.id || 0;
        IterateOver(id).then(function(val) {
            res.json({
                status: req.config.statusCode.success,
                data: val,
                message: 'modules found successfully!'
            });
        }); 
    },

    permission_tree_Sa: function (req, res, next) {
        var id = req.query.id || 0;
        IterateOverSa(id).then(function(val) {
            res.json({
                status: req.config.statusCode.success,
                data: val,
                message: 'modules found successfully!'
            });
        }); 
    }  
}



function IterateOver(id) {
    var q = require('q');
    var deferred = q.defer();
    new permissionModel().query(function (qb) { 
        qb.whereRaw("parent_id = " + id + " AND list_display = 1");
    }).fetchAll().then(function (result) {
        var d = result.toJSON();
        if(d.length > 0){
            async.forEachOf(d, function (value, key, callback) {
                IterateOver(value.id).then(function(val) {
                    d[key]['chield'] = val;
                    callback();
                })             
            }, function (err) {
               deferred.resolve(d);
            });
        }else{
            deferred.resolve([]);
        }           
    });
    return deferred.promise;
}


function IterateOverSa(id) {
    var q = require('q');
    var deferred = q.defer();
    new permissionModel().query(function (qb) { 
        qb.whereRaw("parent_id = " + id + " AND list_display = 0");
    }).fetchAll().then(function (result) {
        var d = result.toJSON();
        if(d.length > 0){
            async.forEachOf(d, function (value, key, callback) {
                IterateOverSa(value.id).then(function(val) {
                    d[key]['chield'] = val;
                    callback();
                })             
            }, function (err) {
               deferred.resolve(d);
            });
        }else{
            deferred.resolve([]);
        }           
    });
    return deferred.promise;
}
