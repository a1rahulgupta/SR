module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];

    var client_ctrl = require('./controllers/client_ctrl')

    router.get('/clients/listAgencyClients', middlewares, client_ctrl.listAgencyClients)
    router.get('/clients/listAgencyClientsInReports', middlewares, client_ctrl.listAgencyClientsInReports)
    router.post('/clients/addAgencyClients', middlewares, client_ctrl.addAgencyClients);
    router.post('/clients/updateAgencyClient', middlewares, client_ctrl.updateAgencyClient);
    router.delete('/clients/deleteAgencyClient/:id', middlewares, client_ctrl.deleteAgencyClient);
    router.get('/clients/getAgencyClientById/:id', middlewares, client_ctrl.getAgencyClientById);
    router.post('/clients/listClients', middlewares, client_ctrl.listClients);
    router.post('/clients/changeClientStatus', middlewares, client_ctrl.changeClientStatus);
    router.get('/clients/getClientProfileDetailById', middlewares, client_ctrl.getClientProfileDetailById);
    router.get('/clients/listTopTenClientsReport', middlewares, client_ctrl.listTopTenClientsReport);
    router.post('/clients/updateAgencyClientLanguage', middlewares, client_ctrl.updateAgencyClientLanguage);
    router.post('/clients/updateClientProfile', middlewares, client_ctrl.updateClientProfile);
    router.get('/clients/getClientNameByClientIdInReport/:id', middlewares, client_ctrl.getClientNameByClientIdInReport);

    //Super Admin
    router.post('/clients/listClientsSuperAdmin', middlewares, client_ctrl.listClientsSuperAdmin);
    router.get('/clients/getClientViewSuperAdmin/:id', middlewares, client_ctrl.getClientViewSuperAdmin);  
    router.get('/clients/getClientBySuperAdmin/:id', middlewares, client_ctrl.getClientBySuperAdmin);
    router.post('/clients/addClientSuperAdmin', middlewares, client_ctrl.addClientSuperAdmin);
    router.delete('/clients/deleteClientSuperAdmin/:id', middlewares, client_ctrl.deleteClientSuperAdmin);
    router.post('/clients/changeClientStatusSuperAdmin', middlewares, client_ctrl.changeClientStatusSuperAdmin);
    router.post('/clients/updateClientSuperAdmin', middlewares, client_ctrl.updateClientSuperAdmin);
    router.post('/clients/activateClientSuperAdmin', middlewares, client_ctrl.activateClientSuperAdmin);
    router.get('/clients/getCountOfClient', middlewares, client_ctrl.getCountOfClient);
    router.get('/clients/getClientListByAgency', middlewares, client_ctrl.getClientListByAgency);       
           

    return router;
}