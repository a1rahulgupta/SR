const _ = require("lodash");
const moment = require('moment');
const Joi = require('joi');
const i18n = require("i18n");
const formidable = require('formidable');
const bcrypt = require('bcrypt');
const util = require('util');
const mongoose = require('mongoose');
const santize = __rootRequire('app/utils/santize');
const validator = __rootRequire('app/config/config.js');
const image = __rootRequire('app/utils/image');
const text = __rootRequire('app/utils/text');
const async = require('async');

//Models 
const User = mongoose.model('Users');
const AgencyModel = mongoose.model('Agencies');
const ClientModel = mongoose.model('Clients');
const SchedulerModel = mongoose.model('Schedulers');
const ClientLanguagesModel = mongoose.model('Client_languages');
const RoleModel = mongoose.model('Roles');
const Booking = mongoose.model('Bookings');
const InterpreterModel = mongoose.model('Interpreters');
const EmailTemplateModel = mongoose.model('Email_Templates');
const AgencyUser = mongoose.model('Agency_users');
const VideoCallModel = mongoose.model('Video_calls');
const CustomerComplaintModel = mongoose.model('Customercomplaint');
const uuidV4 = require('uuid/v4');
const emailSend = __rootRequire('app/core/email');
const common = __rootRequire('app/config/common.js');
const fs = require('fs');
const path = require('path');
const twilioSms = __rootRequire('app/utils/twilioSms');


module.exports = {

    listAgencyClients: function (req, res, next) {
        ClientModel.find({
                agency_id: req.user.agency_id,
                is_deleted: false,
                status: true
            }, {
                _id: 1,
                first_name: 1,
                last_name: 1,
                gender: 1,
                profile_pic: 1,
                email: 1,
                password: 1

            })
            .exec()
            .then((clients) => {
                clients = image.setImagePath(clients, 'profile_pic')

                res.json({
                    status: req.config.statusCode.success,
                    data: clients
                });
            })
            .catch((err) => {
                __debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            })
    },



    listClients: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            is_deleted: false
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        // var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                    'first_name': new RegExp(searchText, 'gi')
                },
                {
                    'last_name': new RegExp(searchText, 'gi')
                },
                {
                    'mobile_no': new RegExp(searchText, 'gi')
                },
                {
                    'client_shortid': new RegExp(searchText, 'gi')
                },
                {
                    'userInfo.email': new RegExp(searchText, 'gi')
                },
            ];
        }

        var aggregateQuery = [{
                $lookup: {
                    from: 'users',
                    localField: "user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: {
                    path: "$userInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $match: condition
            }
        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        ClientModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                ClientModel.aggregate(countQuery).exec(function (err, dataCount) {
                    // console.log("CLIENTCOUNT", dataCount);
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    addAgencyClients: function (req, res, next) {
        // console.log("addAgencyClients", req.body);
        genId();
        function addData(shortBookingId){
            // console.log("addAgencyClients", req.body);
            // return false;
                if (req.body.imageFile) {
                var timestamp = Number(new Date()); // current time as number
                var imageFile = req.body.imageFile;
                // console.log("imageFile", filename);
                var filename = +timestamp + '_' + common.randomToken(6) + '.' + 'png';
                // console.log("imageFile", filename);
                var imagePath = "./../client/users/assets/uploads/profile/" + filename;
            }
            // return false;
            function register() {
                User.findOne({
                    email: req.body.email
                }, function (err, emailData) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })
                    } else {
                        if (emailData) {
                            res.json({
                                status: req.config.statusCode.error,
                                data: req.body,
                                message: i18n.__("Email Id already exist ! Try with different Email.")
                            })
                        } else {
                            RoleModel.findOne({role:req.config.role_type.CLIENT.name}).exec(function(err,roleData){
                                if(err){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: req.body,
                                        message: i18n.__("ERROR")
                                    })
                                }else if(roleData){
                                        var user = new User();
                                        user.email = req.body.email;
                                        user.role_id = roleData._id;
                                        user.activation_key = uuidV4();
                                        user.save()
                                            .then((userData) => {
                                                client = new ClientModel(req.body);
                                                client.agency_id = req.user.agency_id;
                                                client.user_id = userData._id;
                                                client.client_shortid = shortBookingId;
                                                if (filename) {
                                                    client.profile_pic = "/assets/uploads/profile/" + filename;
                                                }

                                                client.save()
                                                    .then((clientData) => {
                                                        if(req.body.languages != '' && req.body.languages !=undefined && req.body.languages != null){
                                                            async.eachSeries(req.body.languages,function(data,next){
                                                                var clientLanguage = new ClientLanguagesModel();
                                                                clientLanguage.agency_id = req.user.agency_id;
                                                                clientLanguage.client_id = clientData._id;
                                                                clientLanguage.language_id = data._id;
                                                                clientLanguage.name = data.name;
                                                                clientLanguage.ticked = data.ticked;
                                                                clientLanguage.save()
                                                                .then((languageData) => {
                                                                    next();
                                                                })
                                                            },function(err){
                                                                
                                                            })
                                                        } 

                                                        if(req.config.env == 'aws'){
                                                            var baseUrl = 'https://www.interpreting.works';
                                                        }else{
                                                            var baseUrl = req.config.email.base_url;
                                                        }
                                                        var options = {
                                                            template: 'set_password.html',
                                                            from: req.user.email,
                                                            repalcement: {
                                                                "{{user.name}}": clientData.first_name.charAt(0).toUpperCase()+clientData.first_name.slice(1).toLowerCase()+ ' ' +clientData.last_name.charAt(0).toUpperCase()+clientData.last_name.slice(1).toLowerCase(),
                                                                "{{user.email}}": userData.email,
                                                                "{{user.activation_key}}": baseUrl + '/#/setPassword/' + userData.activation_key,
                                                                "{{logo_url}}": baseUrl + req.config.email.logo_url,
                                                                "{{copyright}}": req.config.email.copyright,
                                                                "{{link.abuse_email}}": req.config.email.abuse_email
                                                            },
                                                            to: userData.email,
                                                            subject: 'Complete Registration'
                                                        };
                                                        emailSend.smtp.sendMail(options, function (err, response) {
                                                            if (err) {
                                                                //__debug(err)
                                                                console.log(err);
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: req.body,
                                                                    message: i18n.__("ERROR")
                                                                })
                                                            }else{
                                                                User.findOneAndUpdate({
                                                                    _id: userData._id
                                                                }, {
                                                                    is_verification_email_send: true
                                                                }, {
                                                                    new: true
                                                                }).then((userData) => {

                                                                })
                                                            }
                                                        })
                                                        return clientData 
                                                    }).then((clientData) => {
                                                        // var linkTo = req.config.email.base_url+ '/#/setPassword/' + userData.activation_key;
                                                        // var text = "You've registered with this email " + userData.email + "\n to complete your registration click on the provided link below\n" + linkTo + "\n If you didn't request this, you can ignore this email.";
                                                        // var data = { to: '+919990795913', message: text }
                                                        // twilioSms.sendSMS(data, function(returnData) {
                                                        //     console.log('twilio', returnData);
                                                        // });
                                                        res.json({
                                                            status: req.config.statusCode.success,
                                                            data: clientData,
                                                            message: i18n.__("Client added succesfully")
                                                        });                                            
                                                    }).catch((err) => {
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: req.body,
                                                            message: i18n.__("ERROR")
                                                        })
                                                    });
                                            }).catch((err) => {
                                                //__debug(err)
                                                res.json({
                                                    status: req.config.statusCode.error,
                                                    data: req.body,
                                                    message: i18n.__("ERROR")
                                                })
                                            });
                                }else{
                                    res.json({
                                        status: req.config.statusCode.success,
                                        data: {},
                                        message: i18n.__("No record found")
                                    });
                                }
                            })
                        }
                    }
                })
            }

            if (req.body.imageFile) {
                var base64Data = req.body.imageFile.replace(/^data:image\/png;base64,/, "");
                base64Data += base64Data.replace('+', ' ');
                binaryData = new Buffer(base64Data, 'base64').toString('binary');
                fs.writeFile(imagePath, binaryData, "binary", function (err) {
                    if (err) {
                        res.json({
                            code: 402,
                            'message': 'Request could not be processed. Please try again.',
                            data: {}
                        });
                    } else {
                        register();
                    }
                });
            } else {
                register();
            }
        }

        function genId(){
            var shortBookingId = validator.generateShortId();
            ClientModel.find({client_shortid: shortBookingId}, function(err, clientData) {
                if(err){
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                } else if(clientData.length>0){s
                    genId();
                } else{
                    addData(shortBookingId);
                }
            })
        }

    },


    updateAgencyClient: function (req, res, next) {
        if (req.body.imageFile) {
            var timestamp = Number(new Date()); // current time as number
            var imageFile = req.body.imageFile;
            var filename = +timestamp + '_' + common.randomToken(6) + '.' + 'png';
            var imagePath = "./../client/users/assets/uploads/profile/" + filename;
        }

        function update() {
            User.findOne({
                email: req.body.email,
                _id: {
                    $ne: req.body.user_id
                }
            }, function (err, email) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR")
                    })
                } else {
                    if (email) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("Email Id already exist ! Try with different Email.")
                        })
                    } else {
                        var updateData = req.body;
                        if (filename) {
                            updateData.profile_pic = "/assets/uploads/profile/" + filename;
                        }
                        ClientModel.update({
                            _id: req.body._id
                        }, {
                            $set: updateData
                        }, function (err) {
                            if (err) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: req.body,
                                    message: i18n.__("ERROR")
                                })
                            } else {
                                User.update({
                                    _id: req.body.user_id._id
                                }, {
                                    $set: {
                                        email: req.body.email
                                    }
                                }, function (err) {
                                    if (err) {
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: req.body,
                                            message: i18n.__("ERROR")
                                        })
                                    } else {
                                        if(req.body.languages != '' && req.body.languages !=undefined && req.body.languages != null){
                                            async.eachSeries(req.body.languages,function(data,next){
                                                var language = {
                                                    agency_id: req.user.agency_id,
                                                    client_id:req.body._id,
                                                    language_id: data._id,
                                                    name:data.name,
                                                    ticked: data.ticked
                                                }
                                                ClientLanguagesModel.update({
                                                    agency_id:req.user.agency_id,
                                                    client_id:req.body._id,
                                                    language_id: data._id
                                                },{
                                                    $set: language
                                                },{
                                                    upsert: true
                                                },function(err, clientLanguageData){
                                                    if(err){
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: req.body,
                                                            message: i18n.__("ERROR")
                                                        })
                                                    } else{
                                                        next();
                                                    }
                                                })
                                            }),function(err){
                                                if(err){
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: req.body,
                                                        message: i18n.__("ERROR")
                                                    })
                                                }else{
                                                    
                                                }
                                            }
                                        }
                                        res.json({
                                            status: req.config.statusCode.success,
                                            data: req.body,
                                            message: i18n.__("Client profile details updated succesfully")
                                        });
                                    }
                                })

                            }
                        })
                    }
                } 
            });
        }


        if (req.body.imageFile) {
            // console.log("INSIDE req.body.imageFile", req.body.imageFile);
            var base64Data = req.body.imageFile.replace(/^data:image\/png;base64,/, "");
            base64Data += base64Data.replace('+', ' ');
            binaryData = new Buffer(base64Data, 'base64').toString('binary');
            fs.writeFile(imagePath, binaryData, "binary", function (err) {
                if (err) {
                    res.json({
                        code: 402,
                        'message': 'Request could not be processed. Please try again.',
                        data: {}
                    });
                } else {
                    update();
                }
            });
        } else {
            update();
        }
    },

    deleteAgencyClient: function (req, res, next) {
        ClientModel.findOneAndUpdate({
                _id: req.params.id,
                agency_id: req.user.agency_id
            }, {
                is_deleted: true
            }, {
                new: true
            })
            .then((result) => {
                User.findOneAndUpdate({
                    _id: result.user_id
                }, {
                    is_deleted: true
                }, {
                    new: true
                }).then((userDetails) => {
                    res.json({
                        status: req.config.statusCode.success,
                        data: result,
                        message: i18n.__("CLIENT_DELETED_SUCCESSFULLY")
                    });
                }).catch((err) => {
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR")
                    })

                });

            })

    },

    getAgencyClientById: function (req, res, next) {
        var condition = {
            _id: mongoose.Types.ObjectId(req.params.id),
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            is_deleted: false
        }

        var aggregateQuery = [
            {
            $lookup: {
                    from: 'users',
                    localField: "user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: {
                    path: "$userInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $lookup: {
                    from: 'countries',
                    localField: "country_id",
                    foreignField: "_id",
                    as: "countriesInfo"
                }
            },
            {
                $unwind: {
                    path: "$countriesInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $lookup: {
                    from: 'client_languages',
                    localField: "_id",
                    foreignField: "client_id",
                    as: "clientLanguageInfo"
                }
            },
            {
                $match: condition
            },
            {    
            $project: {
                    first_name:1,
                    last_name:1,
                    profile_pic:1,
                    client_shortid:1,
                    dob:1,
                    age:1,
                    alternate_no:1,
                    mobile_no:1,
                    gender:1,
                    city:1,
                    state:1,
                    zip:1,
                    address1:1,
                    address2:1,
                    email: "$userInfo.email",
                    user_id:"$userInfo._id",
                    country_id: "$countriesInfo._id",
                    country_name:"$countriesInfo.country_name",
                    languages: {
                            $filter: {
                                input: "$clientLanguageInfo",        
                                as: "item",        
                                cond: {          
                                    $and: [
                                        {              
                                            $eq: ["$$item.ticked", true]            
                                        },            
                                        {              
                                            $eq: ["$$item.client_id", mongoose.Types.ObjectId(req.params.id)]            
                                        },                  
                                    ]
                                }
                            }
                        },
                }
            }
            
        ];
         ClientModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                // console.log("error", err);
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            } else {
                // console.log("result", result);
                res.json({
                    status: req.config.statusCode.success,
                    data: result[0],
                    message: i18n.__("Get Data Suuccessfully")
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },


    changeClientStatus: function (req, res, next) {
        ClientModel.findOneAndUpdate({
                _id: req.body.id,
                agency_id: req.user.agency_id
            }, {
                status: req.body.status
            }, {
                new: true
            })
            .then((result) => {
                User.findOneAndUpdate({
                    _id: result.user_id
                }, {
                    status: req.body.status
                }, {
                    new: true
                }).then((userDetails) => {
                    res.json({
                        status: req.config.statusCode.success,
                        data: result,
                        message: i18n.__('Client ' + ((req.body.status == true) ? 'activated' : 'deactivated') + ' successfully')
                    });
                }).catch((err) => {
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR")
                    })

                });

            })
    },


    getClientProfileDetailById: function (req, res, next) {
        var condition = {
            _id: mongoose.Types.ObjectId(req.user.client_id),
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            is_deleted: false
        }

        var aggregateQuery = [
            {
            $lookup: {
                    from: 'users',
                    localField: "user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: {
                    path: "$userInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $lookup: {
                    from: 'countries',
                    localField: "country_id",
                    foreignField: "_id",
                    as: "countriesInfo"
                }
            },
            {
                $unwind: {
                    path: "$countriesInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $lookup: {
                    from: 'client_languages',
                    localField: "_id",
                    foreignField: "client_id",
                    as: "clientLanguageInfo"
                }
            },
            {
                $match: condition
            },
            {    
            $project: {
                    first_name:1,
                    last_name:1,
                    profile_pic:1,
                    client_shortid:1,
                    dob:1,
                    age:1,
                    alternate_no:1,
                    mobile_no:1,
                    gender:1,
                    city:1,
                    state:1,
                    zip:1,
                    address1:1,
                    address2:1,
                    agency_id:1,
                    email: "$userInfo.email",
                    user_id:"$userInfo._id",
                    country_id: "$countriesInfo._id",
                    country_name:"$countriesInfo.country_name",
                    languages: {
                            $filter: {
                                input: "$clientLanguageInfo",        
                                as: "item",        
                                cond: {          
                                    $and: [
                                        {              
                                            $eq: ["$$item.ticked", true]            
                                        },            
                                        {              
                                            $eq: ["$$item.client_id", mongoose.Types.ObjectId(req.user.client_id)]            
                                        },                  
                                    ]
                                }
                            }
                        },
                }
            }
            
        ];
         ClientModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            } else {
                AgencyModel.populate(result[0], {path: 'agency_id', select: {'agency_name': 1, 'profile_pic': 1}}, function(err, populatedAgencyDetail) {
                    result[0] = populatedAgencyDetail;
                    res.json({
                        status: req.config.statusCode.success,
                        data: result[0],
                        message: i18n.__("Get Client profile Suuccessfully")
                    });
                });
                
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    listAgencyClientsInReports: function (req, res, next) {
        ClientModel.find({
                agency_id: req.user.agency_id,
                is_deleted: false
            }, {
                _id: 1,
                first_name: 1,
                last_name: 1
            })
            .populate('user_id', 'email')
            .exec()
            .then((clients) => {
                clients = image.setImagePath(clients, 'profile_pic')

                res.json({
                    status: req.config.statusCode.success,
                    data: clients
                });
            })
            .catch((err) => {
                __debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            })
    },

    listTopTenClientsReport: function (req, res, next) {
         var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.id), 
            is_deleted: false
         }
        var aggregate = [{
                $lookup: {
                    from: 'clients',
                    localField: "client_id",
                    foreignField: "_id",
                    as: "clientInfo"
                }
            },
            { $unwind: "$clientInfo"},
            { 
                $match: condition
            }, {
                $lookup: {
                    from: 'users',
                    localField: "clientInfo.user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            }, { $unwind: '$userInfo' },
            {
                $group: {
                    _id: '$clientInfo._id',
                    count: { "$sum": 1},
                    first_name: { $first : "$clientInfo.first_name"},
                    last_name: { $first : "$clientInfo.last_name"},
                    client_shortid: { $first : "$clientInfo.client_shortid"},
                    mobile_no: { $first : "$clientInfo.mobile_no"},
                    email: { $first : "$userInfo.email"}
                }
            
            },{
                $sort : {count: -1}
            },{
                $limit: 10
            }
        ];

        Booking.aggregate(aggregate).exec(function (err, record) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                res.json({
                    status: req.config.statusCode.success,
                    data: record,
                    message: i18n.__("Get data succesfully")
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    updateAgencyClientLanguage: function(req, res, next){
        ClientLanguagesModel.findOneAndUpdate({
            language_id: req.body.language_id,
            client_id : req.body.client_id,
            ticked: true
        }, {
            ticked: false
        }, {
            new: true
        })
        .then((result) => {
            res.json({
                status: req.config.statusCode.success,
                data: result,
                message: i18n.__('LANGUAGE_UPDATED') 
            });
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    updateClientProfile: function (req, res, next) {
        if (req.body.imageFile) {
            var timestamp = Number(new Date()); // current time as number
            var imageFile = req.body.imageFile;
            var filename = +timestamp + '_' + common.randomToken(6) + '.' + 'png';
            var imagePath = "./../client/users/assets/uploads/profile/" + filename;
        }

        function update() {
            User.findOne({
                email: req.body.email,
                _id: {
                    $ne: req.body.user_id
                }
            }, function (err, email) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR")
                    })
                } else {
                    if (email) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("Email Id already exist ! Try with different Email.")
                        })
                    } else {
                        var updateData = req.body;
                        if (filename) {
                            updateData.profile_pic = "/assets/uploads/profile/" + filename;
                        }
                        ClientModel.update({
                            _id: req.body._id
                        }, {
                            $set: updateData
                        }, function (err) {
                            if (err) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: req.body,
                                    message: i18n.__("ERROR")
                                })
                            } else {
                                User.update({
                                    _id: req.body.user_id._id
                                }, {
                                    $set: {
                                        email: req.body.email
                                    }
                                }, function (err) {
                                    if (err) {
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: req.body,
                                            message: i18n.__("ERROR")
                                        })
                                    } else {
                                        if(req.body.languages != '' && req.body.languages !=undefined && req.body.languages != null){
                                            async.eachSeries(req.body.languages,function(data,next){
                                                var language = {
                                                    agency_id: req.user.agency_id,
                                                    client_id:req.body._id,
                                                    language_id: data._id,
                                                    name:data.name,
                                                    ticked: data.ticked
                                                }
                                                ClientLanguagesModel.update({
                                                    agency_id:req.user.agency_id,
                                                    client_id:req.body._id,
                                                    language_id: data._id
                                                },{
                                                    $set: language
                                                },{
                                                    upsert: true
                                                },function(err, clientLanguageData){
                                                    if(err){
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: req.body,
                                                            message: i18n.__("ERROR")
                                                        })
                                                    } else{
                                                        next();
                                                    }
                                                })
                                            }),function(err){
                                                if(err){
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: req.body,
                                                        message: i18n.__("ERROR")
                                                    })
                                                }else{
                                                    
                                                }
                                            }
                                        }
                                        res.json({
                                            status: req.config.statusCode.success,
                                            data: req.body,
                                            message: i18n.__("Client profile details updated succesfully")
                                        });
                                    }
                                })

                            }
                        })
                    }
                } 
            });
        }


        if (req.body.imageFile) {
            // console.log("INSIDE req.body.imageFile", req.body.imageFile);
            var base64Data = req.body.imageFile.replace(/^data:image\/png;base64,/, "");
            base64Data += base64Data.replace('+', ' ');
            binaryData = new Buffer(base64Data, 'base64').toString('binary');
            fs.writeFile(imagePath, binaryData, "binary", function (err) {
                if (err) {
                    res.json({
                        code: 402,
                        'message': 'Request could not be processed. Please try again.',
                        data: {}
                    });
                } else {
                    update();
                }
            });
        } else {
            update();
        }
    },

    getClientNameByClientIdInReport: function(req, res, next){
        ClientModel.findOne({agency_id:req.user.agency_id ,_id: req.params.id, is_deleted:false})
        .then((clientData)=>{
            res.json({
                status: req.config.statusCode.success,
                data: clientData,
                message: i18n.__('Get client name successfully')
            });
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })

        });
    },

    listClientsSuperAdmin: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            is_deleted: false
        }

        if(req.body.agency_id){
            condition.agency_id = mongoose.Types.ObjectId(req.body.agency_id);
        }

        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        // var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                    'first_name': new RegExp(searchText, 'gi')
                },
                {
                    'last_name': new RegExp(searchText, 'gi')
                },
                {
                    'mobile_no': new RegExp(searchText, 'gi')
                },
                {
                    'client_shortid': new RegExp(searchText, 'gi')
                },
                {
                    'userInfo.email': new RegExp(searchText, 'gi')
                },
            ];
        }

        var aggregateQuery = [{
                $lookup: {
                    from: 'users',
                    localField: "user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: {
                    path: "$userInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $match: condition
            }
        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        ClientModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                ClientModel.aggregate(countQuery).exec(function (err, dataCount) {
                    // console.log("CLIENTCOUNT", dataCount);
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

     getClientViewSuperAdmin: function (req, res, next) {
        var condition = {
            _id: mongoose.Types.ObjectId(req.params.id),
            is_deleted: false
        }

        var aggregateQuery = [
            {
            $lookup: {
                    from: 'users',
                    localField: "user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: {
                    path: "$userInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $lookup: {
                    from: 'countries',
                    localField: "country_id",
                    foreignField: "_id",
                    as: "countriesInfo"
                }
            },
            {
                $unwind: {
                    path: "$countriesInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $lookup: {
                    from: 'client_languages',
                    localField: "_id",
                    foreignField: "client_id",
                    as: "clientLanguageInfo"
                }
            },
            {
                $match: condition
            },
            {    
            $project: {
                    first_name:1,
                    last_name:1,
                    profile_pic:1,
                    client_shortid:1,
                    dob:1,
                    age:1,
                    alternate_no:1,
                    mobile_no:1,
                    gender:1,
                    city:1,
                    state:1,
                    zip:1,
                    address1:1,
                    address2:1,
                    email: "$userInfo.email",
                    user_id:"$userInfo._id",
                    country_id: "$countriesInfo._id",
                    country_name:"$countriesInfo.country_name",
                    languages: {
                            $filter: {
                                input: "$clientLanguageInfo",        
                                as: "item",        
                                cond: {          
                                    $and: [
                                        {              
                                            $eq: ["$$item.ticked", true]            
                                        },            
                                        {              
                                            $eq: ["$$item.client_id", mongoose.Types.ObjectId(req.params.id)]            
                                        },                  
                                    ]
                                }
                            }
                        },
                }
            }
            
        ];
         ClientModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                // console.log("error", err);
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            } else {
                // console.log("result", result);
                res.json({
                    status: req.config.statusCode.success,
                    data: result[0],
                    message: i18n.__("Get Data Suuccessfully")
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    getClientBySuperAdmin: function (req, res, next) {
        var condition = {
            _id: mongoose.Types.ObjectId(req.params.id),
            is_deleted: false
        }

        var aggregateQuery = [
            {
            $lookup: {
                    from: 'users',
                    localField: "user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: {
                    path: "$userInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $lookup: {
                    from: 'countries',
                    localField: "country_id",
                    foreignField: "_id",
                    as: "countriesInfo"
                }
            },
            {
                $unwind: {
                    path: "$countriesInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $lookup: {
                    from: 'client_languages',
                    localField: "_id",
                    foreignField: "client_id",
                    as: "clientLanguageInfo"
                }
            },
            {
                $match: condition
            },
            {    
            $project: {
                    first_name:1,
                    last_name:1,
                    profile_pic:1,
                    client_shortid:1,
                    dob:1,
                    age:1,
                    alternate_no:1,
                    mobile_no:1,
                    gender:1,
                    city:1,
                    state:1,
                    zip:1,
                    address1:1,
                    agency_id: 1,
                    address2:1,
                    email: "$userInfo.email",
                    user_id:"$userInfo._id",
                    country_id: "$countriesInfo._id",
                    country_name:"$countriesInfo.country_name",
                    languages: {
                        $filter: {
                            input: "$clientLanguageInfo",        
                            as: "item",        
                            cond: {          
                                $and: [
                                    {              
                                        $eq: ["$$item.ticked", true]            
                                    },            
                                    {              
                                        $eq: ["$$item.client_id", mongoose.Types.ObjectId(req.params.id)]            
                                    },                  
                                ]
                            }
                        }
                    },
                }
            }
            
        ];
         ClientModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            } else {
                res.json({
                    status: req.config.statusCode.success,
                    data: result[0],
                    message: i18n.__("Get Data Suuccessfully")
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    addClientSuperAdmin: function (req, res, next) {
        genId();
        function addData(shortBookingId){
            if (req.body.imageFile) {
                var timestamp = Number(new Date()); // current time as number
                var imageFile = req.body.imageFile;
                var filename = +timestamp + '_' + common.randomToken(6) + '.' + 'png';
                var imagePath = "./../client/users/assets/uploads/profile/" + filename;
            }
            function register() {
                User.findOne({
                    email: req.body.email
                }, function (err, emailData) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })
                    } else {
                        if (emailData) {
                            res.json({
                                status: req.config.statusCode.error,
                                data: req.body,
                                message: i18n.__("Email Id already exist ! Try with different Email.")
                            })
                        } else {
                            RoleModel.findOne({role:req.config.role_type.CLIENT.name}).exec(function(err,roleData){
                                if(err){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: req.body,
                                        message: i18n.__("ERROR")
                                    })
                                }else if(roleData){
                                        var user = new User();
                                        user.email = req.body.email;
                                        user.role_id = roleData._id;
                                        user.activation_key = uuidV4();
                                        user.save()
                                            .then((userData) => {
                                                client = new ClientModel(req.body);
                                                client.agency_id = req.body.agency_id;
                                                client.user_id = userData._id;
                                                client.client_shortid = shortBookingId;
                                                if (filename) {
                                                    client.profile_pic = "/assets/uploads/profile/" + filename;
                                                }

                                                client.save()
                                                    .then((clientData) => {
                                                        if(req.body.languages != '' && req.body.languages !=undefined && req.body.languages != null){
                                                            async.eachSeries(req.body.languages,function(data,next){
                                                                var clientLanguage = new ClientLanguagesModel();
                                                                clientLanguage.agency_id = req.body.agency_id;
                                                                clientLanguage.client_id = clientData._id;
                                                                clientLanguage.language_id = data._id;
                                                                clientLanguage.name = data.name;
                                                                clientLanguage.ticked = data.ticked;
                                                                clientLanguage.save()
                                                                .then((languageData) => {
                                                                    next();
                                                                })
                                                            },function(err){
                                                                
                                                            })
                                                        } 

                                                        if(req.config.env == 'aws'){
                                                            var baseUrl = 'https://www.interpreting.works';
                                                        }else{
                                                            var baseUrl = req.config.email.base_url;
                                                        }
                                                        console.log("req.config.env",req.config.env);
                                                        var options = {
                                                            template: 'set_password.html',
                                                            from: req.user.email,
                                                            repalcement: {
                                                                "{{user.name}}": clientData.first_name.charAt(0).toUpperCase()+clientData.first_name.slice(1).toLowerCase()+ ' ' +clientData.last_name.charAt(0).toUpperCase()+clientData.last_name.slice(1).toLowerCase(),
                                                                "{{user.email}}": userData.email,
                                                                "{{user.activation_key}}": baseUrl + '/#/setPassword/' + userData.activation_key,
                                                                "{{logo_url}}": baseUrl + req.config.email.logo_url,
                                                                "{{copyright}}": req.config.email.copyright,
                                                                "{{link.abuse_email}}": req.config.email.abuse_email
                                                            },
                                                            to: userData.email,
                                                            subject: 'Complete Registration',
                                                        };
                                                        emailSend.smtp.sendMail(options, function (err, response) {
                                                            if (err) {
                                                                console.log('Mail faild',err);
                                                            }else{
                                                                console.log("response",response);
                                                                User.findOneAndUpdate({
                                                                    _id: userData._id
                                                                }, {
                                                                    is_verification_email_send: true
                                                                }, {
                                                                    new: true
                                                                }).then((userData) => {

                                                                })
                                                            }
                                                        })
                                                        return clientData 
                                                    }).then((clientData) => {
                                                        res.json({
                                                            status: req.config.statusCode.success,
                                                            data: clientData,
                                                            message: i18n.__("Client added succesfully")
                                                        });                                            
                                                    }).catch((err) => {
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: req.body,
                                                            message: i18n.__("ERROR")
                                                        })
                                                    });
                                            }).catch((err) => {
                                                res.json({
                                                    status: req.config.statusCode.error,
                                                    data: req.body,
                                                    message: i18n.__("ERROR")
                                                })
                                            });
                                }else{
                                    res.json({
                                        status: req.config.statusCode.success,
                                        data: {},
                                        message: i18n.__("No record found")
                                    });
                                }
                            })
                        }
                    }
                })
            }

            if (req.body.imageFile) {
                var base64Data = req.body.imageFile.replace(/^data:image\/png;base64,/, "");
                base64Data += base64Data.replace('+', ' ');
                binaryData = new Buffer(base64Data, 'base64').toString('binary');
                fs.writeFile(imagePath, binaryData, "binary", function (err) {
                    if (err) {
                        res.json({
                            code: 402,
                            data: {},
                            message: 'REQUEST_NOT_PROCEED'
                        });
                    } else {
                        register();
                    }
                });
            } else {
                register();
            }
        }

        function genId(){
            var shortBookingId = validator.generateShortId();
            ClientModel.find({client_shortid: shortBookingId}, function(err, clientData) {
                if(err){
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                } else if(clientData.length>0){s
                    genId();
                } else{
                    addData(shortBookingId);
                }
            })
        }

    },

    deleteClientSuperAdmin: function (req, res, next) {
        ClientModel.findOneAndUpdate({
            _id: req.params.id
        }, {
            is_deleted: true
        }, {
            new: true
        })
        .then((result) => {
            if(!result){
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })
            }else{
                User.findOneAndUpdate({
                    _id: result.user_id
                }, {
                    is_deleted: true
                }, {
                    new: true
                }).then((userDetails) => {
                    res.json({
                        status: req.config.statusCode.success,
                        data: result,
                        message: i18n.__("CLIENT_DELETED_SUCCESSFULLY")
                    });
                })       
            }
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })
        });
    },

    changeClientStatusSuperAdmin: function (req, res, next) {
        ClientModel.findOneAndUpdate({
            _id: req.body.id
        }, {
            status: req.body.status
        }, {
            new: true
        })
        .then((result) => {
            if(!result){
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })
            }else{
                User.findOneAndUpdate({
                    _id: result.user_id
                }, {
                    status: req.body.status
                }, {
                    new: true
                }).then((userDetails) => {
                    res.json({
                        status: req.config.statusCode.success,
                        data: result,
                        message: i18n.__('Client ' + ((req.body.status == true) ? 'activated' : 'deactivated') + ' successfully')
                    });
                })        
            }    
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })
        })
    },

    updateClientSuperAdmin: function (req, res, next) {
        if (req.body.imageFile) {
            var timestamp = Number(new Date()); // current time as number
            var imageFile = req.body.imageFile;
            var filename = +timestamp + '_' + common.randomToken(6) + '.' + 'png';
            var imagePath = "./../client/users/assets/uploads/profile/" + filename;
        }

        function update() {
            User.findOne({
                email: req.body.email,
                _id: {
                    $ne: req.body.user_id
                }
            }, function (err, email) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR")
                    })
                } else {
                    if (email) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("Email Id already exist ! Try with different Email.")
                        })
                    } else {
                        var updateData = req.body;
                        if (filename) {
                            updateData.profile_pic = "/assets/uploads/profile/" + filename;
                        }
                        ClientModel.update({
                            _id: req.body._id
                        }, {
                            $set: updateData
                        }, function (err) {
                            if (err) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: req.body,
                                    message: i18n.__("ERROR")
                                })
                            } else {
                                User.update({
                                    _id: req.body.user_id._id
                                }, {
                                    $set: {
                                        email: req.body.email
                                    }
                                }, function (err) {
                                    if (err) {
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: req.body,
                                            message: i18n.__("ERROR")
                                        })
                                    } else {
                                        if(req.body.languages != '' && req.body.languages !=undefined && req.body.languages != null){
                                            async.eachSeries(req.body.languages,function(data,next){
                                                var language = {
                                                    agency_id: req.body.agency_id,
                                                    client_id:req.body._id,
                                                    language_id: data._id,
                                                    name:data.name,
                                                    ticked: data.ticked
                                                }
                                                ClientLanguagesModel.update({
                                                    agency_id:req.body.agency_id,
                                                    client_id:req.body._id,
                                                    language_id: data._id
                                                },{
                                                    $set: language
                                                },{
                                                    upsert: true
                                                },function(err, clientLanguageData){
                                                    if(err){
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: req.body,
                                                            message: i18n.__("ERROR")
                                                        })
                                                    } else{
                                                        next();
                                                    }
                                                })
                                            }),function(err){
                                                if(err){
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: req.body,
                                                        message: i18n.__("ERROR")
                                                    })
                                                }else{
                                                    
                                                }
                                            }
                                        }
                                        res.json({
                                            status: req.config.statusCode.success,
                                            data: req.body,
                                            message: i18n.__("ACCOUNT_UPDATED_SUCCESSFULLY")
                                        });
                                    }
                                })

                            }
                        })
                    }
                } 
            });
        }


        if (req.body.imageFile) {
            var base64Data = req.body.imageFile.replace(/^data:image\/png;base64,/, "");
            base64Data += base64Data.replace('+', ' ');
            binaryData = new Buffer(base64Data, 'base64').toString('binary');
            fs.writeFile(imagePath, binaryData, "binary", function (err) {
                if (err) {
                    res.json({
                        code: 402,
                        data: {},
                        message: 'REQUEST_NOT_PROCEED'
                    });
                } else {
                    update();
                }
            });
        } else {
            update();
        }
    },

    activateClientSuperAdmin: function (req, res, next){
        function sendEmailNotification(obj){
            if(req.config.env == 'aws'){
                var baseUrl = 'https://www.interpreting.works';
            }else{
                var baseUrl = req.config.email.base_url;
            }
            var options = {
                template: 'completeUserRegistration.html',
                from: 'rahul@yopmail.com',
                repalcement: {
                    "{{user.name}}": obj.first_name.charAt(0).toUpperCase()+obj.first_name.slice(1).toLowerCase()+ ' ' + obj.last_name.charAt(0).toUpperCase()+obj.last_name.slice(1).toLowerCase(),
                    "{{user.email}}": obj.email,
                    "{{user.url}}": baseUrl + '/#/login/',
                    "{{user.email}}": obj.email,
                    "{{user.password}}": req.body.password,
                    "{{logo_url}}": baseUrl + req.config.email.logo_url,
                    "{{copyright}}": req.config.email.copyright,
                    "{{link.abuse_email}}": req.config.email.abuse_email
                },
                to: obj.email,
                subject: 'Registration Completed Successfully'
            };
            emailSend.smtp.sendMail(options, function (err, response) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                }else{
                    var text ="Your Registration completed successfully.";
                    var data = { to: '+919990795913', message: text }
                    twilioSms.sendSMS(data, function(returnData) {
                    });
                    res.json({
                        status: req.config.statusCode.success,
                        data: obj.result,
                        message: i18n.__("Registration completed successfully for this account")
                    });
                }
            })
        }

        bcrypt.genSalt(10, function (err, salt) {
            bcrypt.hash(req.body.password, salt, function (err, hash) {
                if (!err) {
                    User.findOne({_id:req.body.user_id}).exec(function(err,userData){
                        if(err){
                            console.log("err1",err);
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        }else if(userData){
                            userData.password = hash;
                            userData.activation_key = '';
                            userData.is_verified = true;
                            userData.status = true;
                            userData.save(function(err, result){
                                if(err){
                                    console.log("err2",err);
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("ERROR")
                                    })
                                }else{
                                    ClientModel.findOne({user_id:result._id}).exec(function(err,clientData){
                                        if(err){
                                            console.log("err3",err);
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: {},
                                                message: i18n.__("ERROR")
                                            })
                                        }else if(clientData){
                                            clientData.status = true;
                                            clientData.save(function(err,savedData){
                                                if(err){
                                                    console.log("err4",err);
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: {},
                                                        message: i18n.__("ERROR")
                                                    })
                                                }else{
                                                    var obj = {
                                                        first_name:clientData.first_name,
                                                        last_name:clientData.last_name,
                                                        email: result.email,
                                                        result:result
                                                    }
                                                    console.log("obj",obj);
                                                    sendEmailNotification(obj);        
                                                }
                                            })
                                        }else{
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: {},
                                                message: i18n.__("ERROR")
                                            });
                                        }
                                    }) 
                                }
                            })

                        }else{
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        }
                    }).catch(function (err) {
                        console.log("err5",err);
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })
                    })
                }
            })
        })
    },

    getCountOfClient: function(req, res, next) {
        SchedulerModel.find({
            client_id: req.user.client_id,
            is_deleted:false
        }).count().exec(function(err, bookingCount){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                });
            }else {
                VideoCallModel.find({
                    client_id: mongoose.Types.ObjectId(req.user.client_id)
                }).count().exec(function(err, videoCount) {
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        });
                    }else{
                        CustomerComplaintModel.find({
                            client_id: req.user.client_id,
                            is_deleted: false
                        }).count().exec(function(err, complaintCount) {
                            if(err){
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("ERROR")
                                });
                            }else{
                                res.json({
                                    status: req.config.statusCode.success,
                                    data: {'countBookings': bookingCount,
                                           'countVideos': videoCount,
                                           'countComplaints': complaintCount
                                    },
                                    message: i18n.__('GET_COUNT_SUCCESSFULLY')
                                });       
                            }
                        })
                    }
                })
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            });
        })
    },

    getClientListByAgency: function (req, res, next) {
        ClientModel.find({agency_id: mongoose.Types.ObjectId(req.user.agency_id), status: true, is_deleted: false},{'first_name':1, 'last_name': 1})
        .populate('user_id')
        .exec(function(err, clientData) {
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                }) 
            }else if(clientData.length > 0){
                res.json({
                    status: req.config.statusCode.success,
                    data: clientData,
                    message: i18n.__("GET_DATA_SUCCESSFULLY")
                });    
            }else{
                res.json({
                    status: req.config.statusCode.notFound,
                    data: {},
                    message: i18n.__("NO_RECORD_FOUND")
                })
            }
        }).catch(function(err) {
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        });
    },

}
