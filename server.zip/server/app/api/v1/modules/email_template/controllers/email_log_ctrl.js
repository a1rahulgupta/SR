var jwt = require('jsonwebtoken');
var moment = require('moment');
var loader = __rootRequire('app/api/v1/loader');
var EmailLogModel = require('./../models/email_log_model');

var santize = __rootRequire('app/utils/santize');
var i18n = require("i18n");
module.exports = {
    getEmailLogs: function (req, res, next) {
        var options = req.body;
        if (req.user.role.role == req.config.role_type.SUPER_ADMIN.name || req.user.role.role == req.config.role_type.ADMIN_STAFF.name) {

        } else {

        }


        new EmailLogModel()
            .query(function (qb) {

                _filter(qb, options)

            })
            .count('*')
            .then(function (count) {

                new EmailLogModel()
                    .query(function (qb) {
                        qb.columns(['email_logs.*', 'company_profiles.company_name']);
                        qb.joinRaw(`LEFT JOIN company_profiles ON (company_profiles.id = email_logs.company_id)`);
                        _filter(qb, options)

                    })
                    .fetchAll()
                    .then(function (c) {
                        c = c ? c.toJSON() : null;
                        res.json({
                            status: req.config.statusCode.success,
                            data: c,
                            count: parseInt(count)
                        });
                    }).catch(function (err) {
                        __debug(err)
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__('INTERNAL_ERROR')
                        });
                    });
            });

        function _filter(qb, options) {
            if (options.company_id) {
                qb.whereRaw('email_logs.company_id = ?', options.company_id);
            }
            if (options.mail_to) {
                qb.whereRaw('email_logs.mail_to ~* ?', options.mail_to);
            }
            
            if (options.start_datetime && options.end_datetime) {
                options.start_datetime = moment(options.start_datetime.replace(/\\/g, "").toString()).format("YYYY-MM-DD");
                options.end_datetime = moment(options.end_datetime.replace(/\\/g, "").toString()).format("YYYY-MM-DD");
               // __debug("options ", options)
                qb.whereRaw('(date(email_logs.created) >= ? AND date(email_logs.created) <= ?)', [options.start_datetime, options.end_datetime]);
            }
        }

    }
}