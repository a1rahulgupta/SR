var jwt = require('jsonwebtoken');
var moment = require('moment');
var loader = __rootRequire('app/api/v1/loader');
var EmailTemplateModel = require('./../models/email_template_model');
var AgencyModel = loader.loadModel('/agency/models/agency_model');
var santize = __rootRequire('app/utils/santize');
var i18n = require("i18n");

module.exports = {
    getEmailTemplateList: function (req, res, next) {
        var options = santize.escape(req.query);
        if (req.user.role.role == req.config.role_type.COMPANY.name || req.user.role.role == req.config.role_type.COMPANY_STAFF.name)
            var conditions = { company_id: req.user.company_id };
        else {
            var conditions = { user_id: req.user.id }
        }


        new EmailTemplateModel()
            .where(conditions)
            .query(function (qb) {
                if (options.subject) {
                    qb.whereRaw('subject @@ ?', options.subject);
                }
                if (options.email_body) {
                    qb.whereRaw('email_body ~* ?', options.email_body);
                }
            })
            .count('*')
            .then(function (count) {

                new EmailTemplateModel()
                    .where(conditions)
                    .query(function (qb) {
                        if (options.subject) {
                            qb.whereRaw('subject @@ ?', options.subject);
                        }
                        if (options.email_body) {
                            qb.whereRaw('email_body ~* ?', options.email_body);
                        }

                    })
                    .fetchAll({
                        columns: [
                            '*'
                        ]
                    })
                    .then(function (c) {
                        c = c ? c.toJSON() : null;
                        res.json({
                            status: req.config.statusCode.success,
                            data: c,
                            count: parseInt(count)
                        });
                    }).catch(function (err) {
                        __debug(err)
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__('INTERNAL_ERROR')
                        });
                    });
            });

    },
    saveEmailTemplate: function (req, res, next) {
        if (req.params.id && req.user.role.id == req.config.role_type.COMPANY.id || req.user.role.id == req.config.role_type.COMPANY_STAFF.id) {
            req.params = santize.escape(req.params);
            var conditions = { id: req.params.id, company_id: req.user.company_id || null };
            new EmailTemplateModel().where(conditions).save(req.body, { patch: true }).then(function (result) {
                console.log(result, "result")
                return res.status(200).json({
                    status: req.config.statusCode.success,
                    data: result.toJSON(),
                    message: i18n.__("SAVED")
                });
            }).catch(function (err) {
                return res.status(200).json({
                    status: req.config.statusCode.invalid,
                    error: err
                });
            });
        }
        else {
            var conditions = { id: req.params.id, user_id : req.user.id };
            new EmailTemplateModel().where(conditions).save(req.body, { patch: true })
                .then(function (result) {
                    console.log(result, "result")
                    var data = result;
                    return res.status(200).json({
                        status: req.config.statusCode.success,
                        data: data.toJSON(),
                        message: i18n.__("SAVED")
                    });
                }).catch(function (err) {
                    return res.status(200).json({
                        status: req.config.statusCode.invalid,
                        error: err
                    });
                });
        }

        // req.params = santize.escape(req.params);
        // new EmailTemplateModel({ id: req.params.id }).save(req.body, { patch: true }).then(function (result) {
        //     return res.status(200).json({
        //         status: req.config.statusCode.success,
        //         data: result.toJSON(),
        //         message: i18n.__("SAVED")
        //     });
        // }).catch(function (err) {
        //     return res.status(200).json({
        //         status: req.config.statusCode.invalid,
        //         error: err
        //     });
        // });

    },
    getEmailTemplate: function (req, res, next) {
        if (req.user.role.role == req.config.role_type.COMPANY.name || req.user.role.role == req.config.role_type.COMPANY_STAFF.name)
            var conditions = { company_id: req.user.company_id };
        else {
            var conditions = { user_id: req.user.id }
        }
        var id = req.params.id;
        new EmailTemplateModel().where(conditions).where({ id: id }).fetch({}).then(function (result) {
            var data = result.toJSON();
            return res.status(200).json({
                status: req.config.statusCode.success,
                data: data
            });
        }).catch(function (err) {
            __debug(err);
            return res.status(200).json({
                status: req.config.statusCode.error,
                error: i18n.__("INTERNAL_ERROR")
            });
        });
    },
    deleteEmailTemplate: function (req, res, next) {
        req.body = santize.escape(req.body);
        var id = req.body.id[0];
        new EmailTemplateModel().where({ id: id }).fetch({ is_deleted: 0 })
            .then(function (result) {
                if (!result) throw i18n.__("FORBIDDEN");
                new EmailTemplateModel({ id: id })
                    .off("updating")
                    .save({ is_deleted: 1 }, { patch: true })
                    .then(function (result) {
                        return res.status(200).json({
                            data: result.toJSON(),
                            status: req.config.statusCode.success,
                            message: i18n.__("DELETED_SUCCESS")
                        })
                    }).catch(function (err) {
                        return res.status(200).json({
                            status: req.config.statusCode.error,
                            error: err
                        });
                    });

            }).catch(function (err) {
                __debug(err);
                return res.status(200).json({
                    status: req.config.statusCode.error,
                    error: i18n.__("INTERNAL_ERROR")
                });
            });
    }
}