module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");    
    var middlewares = [auth.ensureAuthorized];
    var emailtemplate = require('./controllers/email_template_ctrl')
    var emailLog = require('./controllers/email_log_ctrl')

    //Email templates
    router.get('/emailtemplate/getList',middlewares, emailtemplate.getEmailTemplateList)
    router.get('/emailtemplate/getOne/:id', middlewares,emailtemplate.getEmailTemplate)
    router.post('/emailtemplate/saveEmailTemplate',middlewares, emailtemplate.saveEmailTemplate)
    router.post('/emailtemplate/saveEmailTemplate/:id',middlewares ,emailtemplate.saveEmailTemplate)
    router.post('/emailtemplate/delete', middlewares,emailtemplate.deleteEmailTemplate)

    //Email logs
    router.post('/emailtemplate/getEmailLogs',middlewares, emailLog.getEmailLogs)
    
    
    return router;
}