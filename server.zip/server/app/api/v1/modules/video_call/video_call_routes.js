module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];
    var OpenTok = require('opentok');
    var video_call_ctrl = require('./controllers/video_call_ctrl')

    router.post('/video_call/createTokenAndSessionId',middlewares, video_call_ctrl.createTokenAndSessionId);
    router.post('/video_call/senderStartedVideoCall',middlewares, video_call_ctrl.senderStartedVideoCall);
    router.post('/video_call/listVideoCallBookingByClientId',middlewares, video_call_ctrl.listVideoCallBookingByClientId);
    router.post('/video_call/listVideoCallBookingByInterpreterId',middlewares, video_call_ctrl.listVideoCallBookingByInterpreterId);
    router.get('/video_call/getVideoCallDetailsByIdInInterpreter/:id',middlewares, video_call_ctrl.getVideoCallDetailsByIdInInterpreter);
    router.get('/video_call/getVideoCallDetailsByIdInClient/:id',middlewares, video_call_ctrl.getVideoCallDetailsByIdInClient);
    // router.post('/video_call/saveChat',middlewares, video_call_ctrl.saveChat);
    // // POST /token/generate
    // router.post('/web_call/initializeTwilio', web_call_ctrl.genrateTwilioToken);

    // // POST /calls/connect
    // router.post('/web_call/connect', twilio.webhook({validate: false}), web_call_ctrl.twilioWebhookConnect);
    // router.post('/web_call/recordingTwilioStatusCallback', twilio.webhook({validate: false}), web_call_ctrl.recordingTwilioStatusCallback);

    return router;
}