const _ = require("lodash");
const moment = require('moment');
const i18n = require("i18n");
const util = require('util');
const mongoose = require('mongoose');
const santize = __rootRequire('app/utils/santize');

//Models 
const User = mongoose.model('Users');
const AgencyModel = mongoose.model('Agencies');
const ClientModel = mongoose.model('Clients');
const RoleModel = mongoose.model('Roles');
const InterpreterModel = mongoose.model('Interpreters');
const AgencyUser = mongoose.model('Agency_users');
const Booking = mongoose.model('Bookings');
const VideoCallModel = mongoose.model('Video_calls');
const ChatModel = mongoose.model('Chats');
const uuidV4 = require('uuid/v4');
const emailSend = __rootRequire('app/core/email');
const common = __rootRequire('app/config/common.js');
const fs = require('fs');
const path = require('path');
const async = require('async');
const OpenTok = require('opentok');
const apikey = '46000872';
const apiSecret = '889a51d0cd366b06f1b198f4775cde6342908f41';
const opentok = new OpenTok(apikey, apiSecret);

module.exports = {   

    createTokenAndSessionId: function (req, res, next) {
        if(req.body.video_id){
           // console.log("in getting saved token and session");
            VideoCallModel.findById(req.body.video_id)
            .exec()
            .then((videoData) => {
              videoData.receiver_id = req.user.id;
              videoData.save()
              .then((saveVideoData) => {
                res.json({
                    status: req.config.statusCode.success,
                    data: { sessionConnect:saveVideoData , api_key: apikey },
                    message: i18n.__("Session Id and token fetched successfully")
                });
              })
            })
        }else{
            // console.log("in creating token and session");
            opentok.createSession(function(err, session) {
                if (err) return console.log(err);
                // save the sessionId 
                token = session.generateToken();
                // console.log('session', session.sessionId);
                // console.log("token",token);
                var videoCallModel = new VideoCallModel(req.body);
                videoCallModel.session_id = session.sessionId;
                videoCallModel.token = token;
                videoCallModel.sender_id = req.user.id;
                videoCallModel.save(videoCallModel)
                .then((videoData) => {
                    res.json({
                        status: req.config.statusCode.success,
                        data: { sessionConnect:videoData , api_key: apikey },
                        message: i18n.__("Session Id and token created successfully")
                    });
                })
            }); 
        }
    },
    
    startSocket: function(io,usernames) {
        var connections=[];
        
        // console.log('Start Socket');
        io.on('connection', function(socket){
            socket.on('adduser', function(username) {
              // console.log("adduser :: ", username);
              socket.username = username.id;
              usernames[username.id] = socket.id;
              // console.log("Socket",socket.id);
            });
        
            socket.on('notify', function(notification) {
                // console.log("receiver id",notification.videoData.receiver_id);
                // console.log("Notify",usernames[notification.videoData.receiver_id],notification,usernames);
                io.to(usernames[notification.videoData.receiver_id]).emit('notify_client',notification); 
              // switch(notification.notificationType){
              //   case 'VIDEO_CALL_STARTED': 
              //       io.to(usernames[notification.user]).emit('notify_client',notification);
              //   break;
              //   case 'DENY_VIDEO_CALL': 
              //       io.to(usernames[notification.user]).emit('notify_client',notification);
              //   break;
              // }

            });

            socket.on('notify_disconnect', function(notification) {
                io.to(usernames[notification.videoData.receiver_id]).emit('notify_disconnects',notification); 
              // switch(notification.notificationType){
              //   case 'VIDEO_CALL_STARTED': 
              //       io.to(usernames[notification.user]).emit('notify_client',notification);
              //   break;
              //   case 'DENY_VIDEO_CALL': 
              //       io.to(usernames[notification.user]).emit('notify_client',notification);
              //   break;
              // }

            });


            socket.on('message', function(messageData) {
                function saveChat (messageData){
                    var chatModel = new ChatModel();
                    chatModel.booking_id = messageData.booking_id;
                    chatModel.video_call_id = messageData.video_call_id;
                    chatModel.sender_id = messageData.sentBy;
                    chatModel.receiver_id = messageData.user;
                    chatModel.message = messageData.message;
                    chatModel.interpreter_id = messageData.interpreter_id;
                    chatModel.client_id = messageData.client_id;
                    chatModel.save(chatModel)
                    .then((chatData) => {

                    })
                }
                io.to(usernames[messageData.user]).emit('message_client',messageData);
                saveChat(messageData); 
            });


        });

        
    },

    senderStartedVideoCall: function (req, res, next) {
      // console.log("sender video call",req.body);
      VideoCallModel.findById(req.body.video_id)
      .exec()
      .then((videoData) => {
            videoData.receiver_id = req.body.sender_id;
            videoData.save()
            .then((VideoSavedData) => {
              res.json({
                  status: req.config.statusCode.success,
                  data: VideoSavedData,
                  message: i18n.__("Receiver saved successfully")
              });
            }).catch((err) => {
                __debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            })
      })
        // opentok.createSession(function(err, session) {
        //     if (err) return console.log(err);
        //     // save the sessionId 
        //     token = session.generateToken();
        //     console.log('session', session.sessionId);
        //     console.log("token",token);
        //     var videoCallModel = new VideoCallModel(req.body);
        //     videoCallModel.session_id = session.sessionId;
        //     videoCallModel.token = token;
        //     if(req.user.role == req.config.role_type.CLIENT.name){
        //       videoCallModel.sender_id = req.body.client_id;
        //     }else if(req.user.role == req.config.role_type.INTERPRETER.name){
        //       videoCallModel.sender_id = req.body.interpreter_id;
        //     }
        //     videoCallModel.save(videoCallModel)
        //     .then((VideoData) => {
        //         res.json({
        //             status: req.config.statusCode.success,
        //             data: { sessionConnect:VideoData , api_key: apikey },
        //             message: i18n.__("Session Id and token created successfully")
        //         });
        //     })
        // }); 
    },

    listVideoCallBookingByClientId: function(req, res, next){
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            client_id: mongoose.Types.ObjectId(req.user.client_id)
        }

        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        // var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                    'interpreterInfo.first_name': new RegExp(searchText, 'gi')
                },
                {
                    'interpreterInfo.last_name': new RegExp(searchText, 'gi')
                },
                {
                    'bookingInfo.booking_short_id': new RegExp(searchText, 'gi')
                },
                {
                    'service_title': new RegExp(searchText, 'gi')
                }
            ];
        }

        var aggregateQuery = [{
                $lookup: {
                    from: 'interpreters',
                    localField: "interpreter_id",
                    foreignField: "_id",
                    as: "interpreterInfo"
                }
            },
            {
                $unwind: {
                    path: "$interpreterInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $match: condition
            },  {
                $lookup: {
                    from: 'schedulers',
                    localField: "booking_id",
                    foreignField: "_id",
                    as: "bookingInfo"
                }
            }, {
                $unwind: {
                    path: "$bookingInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $match: condition
            },

        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        VideoCallModel.aggregate(aggregateQuery).exec(function (err, result) {
            // console.log("RESULT aggregate", result);
            if (err) {
                // console.log("ERRRR1", err);
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                VideoCallModel.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    listVideoCallBookingByInterpreterId: function(req, res, next){
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            interpreter_id: mongoose.Types.ObjectId(req.user.interpreter_id)
        }

        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        // var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                    'clientInfo.first_name': new RegExp(searchText, 'gi')
                },
                {
                    'clientInfo.last_name': new RegExp(searchText, 'gi')
                },
                {
                    'bookingInfo.booking_short_id': new RegExp(searchText, 'gi')
                },
                {
                    'bookingInfo.service_title': new RegExp(searchText, 'gi')
                }
            ];
        }

        var aggregateQuery = [{
                $lookup: {
                    from: 'clients',
                    localField: "client_id",
                    foreignField: "_id",
                    as: "clientInfo"
                }
            },
            {
                $unwind: {
                    path: "$clientInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $match: condition
            },  {
                $lookup: {
                    from: 'schedulers',
                    localField: "booking_id",
                    foreignField: "_id",
                    as: "bookingInfo"
                }
            }, {
                $unwind: {
                    path: "$bookingInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $match: condition
            },

        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        VideoCallModel.aggregate(aggregateQuery).exec(function (err, result) {
            // console.log("RESULT aggregate", result);
            if (err) {
                // console.log("ERRRR1", err);
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                VideoCallModel.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    }, 

    getVideoCallDetailsByIdInInterpreter: function (req, res, next) {
        VideoCallModel.findOne({_id: req.params.id, interpreter_id: req.user.interpreter_id})
            .populate('client_id', 'first_name last_name profile_pic')
            .populate('interpreter_id', 'first_name last_name profile_pic')
            .populate('booking_id', 'booking_short_id service_title start_date end_date start_time end_time')
            .then((result) => {
              if(result){
                ChatModel.find({video_call_id:result._id, booking_id: result.booking_id._id})
                .then((chatData)=>{
                    res.json({
                      status: req.config.statusCode.success,
                      data: {result, chatData},
                      message: i18n.__("Get video call details successfully")
                  });
                })
              }
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                })

            });
    },

    getVideoCallDetailsByIdInClient: function (req, res, next) {
        VideoCallModel.findOne({_id: req.params.id, client_id: req.user.client_id})
        .populate('client_id', 'first_name last_name profile_pic')
        .populate('interpreter_id', 'first_name last_name profile_pic')
        .populate('booking_id', 'booking_short_id service_title start_date end_date start_time end_time')
        .then((result) => {
          if(result){
            ChatModel.find({video_call_id:result._id, booking_id: result.booking_id._id})
            .then((chatData)=>{
                res.json({
                  status: req.config.statusCode.success,
                  data: {result, chatData},
                  message: i18n.__("Get video call details successfully")
              });
            })
          }
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            })

        });
    },        


}