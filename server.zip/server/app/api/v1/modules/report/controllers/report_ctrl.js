const _ = require("lodash");
const moment = require('moment');
const i18n = require("i18n");
const util = require('util');
const fs = require('fs');
const path = require('path');
const pdf = require('html-pdf');
const uuidV4 = require('uuid/v4');
const async = require('async');
const asyncEach = require('async-each-series');
const waterfall = require('async-waterfall');
const mongoose = require('mongoose');
const santize = __rootRequire('app/utils/santize');
const emailSend = __rootRequire('app/core/email');
const common = __rootRequire('app/config/common.js');
const utility = __rootRequire('app/utils/utility.js');
//Models 
const User = mongoose.model('Users');
const AgencyModel = mongoose.model('Agencies');
const ClientModel = mongoose.model('Clients');
const RoleModel = mongoose.model('Roles');
const InterpreterModel = mongoose.model('Interpreters');
const AgencyUser = mongoose.model('Agency_users');
const CheckInOutModel = mongoose.model('Check_in_outs');
const SchedulerModel = mongoose.model('Schedulers');
const SchedulerSkipModel = mongoose.model('Languages');
const LanguageModel = mongoose.model('Languages');

module.exports = {   
   
   getInterpreterCompletedBookings: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            interpreter_id: mongoose.Types.ObjectId(req.body.interpreterId),
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            is_deleted: false,
            status: true,
            check_io_approval: 'approved'
        }

        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");

        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                'clientInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'clientInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'bookingInfo.booking_short_id': new RegExp(searchText, 'gi')
            },
            {
                'bookingInfo.service_title': new RegExp(searchText, 'gi')
            }];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'clients',
                localField: "client_id",
                foreignField: "_id",
                as: "clientInfo"
            }
        },
        {
            $unwind: {
                path: "$clientInfo",
                preserveNullAndEmptyArrays: true
            }
        },{
            $lookup: {
                from: 'schedulers',
                localField: "booking_id",
                foreignField: "_id",
                as: "bookingInfo"
            }
        },
        {
            $unwind: {
                path: "$bookingInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $match: condition
        }];
        
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        CheckInOutModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                CheckInOutModel.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var bookingArray = []
                        async.each(result, function(singleBooking, callback) {
                            var singleNewBooking = {};
                            singleNewBooking = singleBooking;
                            var startTime = moment(singleBooking.check_in_time, "HH:mm a");
                            var endTime = moment(singleBooking.check_out_time, "HH:mm a");
                            var duration = moment.duration(endTime.diff(startTime));
                            var hours = parseInt(duration.asHours());
                            var minutes = parseInt(duration.asMinutes())-hours*60;
                            var working_hours =  hours + ' hrs and '+ minutes+' min';
                            singleBooking.working_hours = working_hours;
                            bookingArray.push(singleBooking);
                            callback();
                        }, function(err) {
                            if (err) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: [],
                                    count: 0,
                                    message: i18n.__("ERROR")
                                });
                            } else {
                                var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                                res.json({
                                    status: req.config.statusCode.success,
                                    data: bookingArray,
                                    count: cnt
                                });
                            }
                        })
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    exportInterpreterCompletedBookingsToPdf: function (req, res, next) {
        var logoUrl = req.config.email.base_url+req.config.email.logo_url;
        var timestamp = Number(new Date());
        CheckInOutModel.find({agency_id: mongoose.Types.ObjectId(req.user.agency_id), interpreter_id: mongoose.Types.ObjectId(req.params.id), is_deleted:false, status: true, check_io_approval: 'approved'})
        .populate('client_id', 'first_name last_name')
        .populate('interpreter_id', 'first_name last_name')
        .populate('booking_id')
        .then((result) => {
            if(!result){
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            }else if(result.length > 0){
                AgencyModel.findOne({_id: mongoose.Types.ObjectId(req.user.agency_id), status: true})
                .populate('country_id')
                .exec(function(err, agencyData){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        });
                    }else if(agencyData){
                        var options = { "format": "Letter"};
                        var profileUrl = req.config.email.base_url+ (agencyData.profile_pic ? agencyData.profile_pic: req.config.upload_dir.USER_PROFILE_PIC);
                        var filename = "doc" + timestamp + '_' + common.randomToken(6) +  ".pdf";
                        var path = "./../client/users/assets/uploads/reports/" + filename;
                        var agencyName = agencyData.agency_name;
                        if(agencyName && agencyData.address1!= '' && agencyData.address1 != null && agencyData.address1 != undefined && agencyData.address2 != '' && agencyData.address2 != null && agencyData.address2 != undefined){
                            var agencyAddress = agencyData.address1+', '+agencyData.address2+ ', '+agencyData.city+', '+agencyData.state+', '+agencyData.country_id.country_code.toUpperCase()+', '+agencyData.zip;   
                        }else if(agencyName && agencyData.address1 && !agencyData.address2){
                            var agencyAddress = agencyData.address1+', '+agencyData.city+', '+agencyData.state+', '+agencyData.country_id.country_code.toUpperCase()+', '+agencyData.zip;
                        }else{
                            var agencyAddress = '';
                        } 

                        var headerHtml  = "<!DOCTYPE html><head><meta charset='utf-8' /><meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'/><meta http-equiv='X-UA-Compatible' content='IE=edge' /><meta http-equiv='Content-Type' content='text/html; charset=utf-8'><title>HTML</title></head>"+
                                           "   <body style='float: left; width: 100%; margin: 0px; padding: 0px; height: 100%; font-family: sans-serif,arial; font-size: 11px; color: rgb(85, 85, 85); background: rgb(252, 252, 252) none repeat scroll 0% 0%;'>"+
                                           "    <div style='float: left; width: 100%;  box-sizing: border-box; padding: 20px 5px 0px; overflow: auto; '>"+

                                           "    <div style='float:left;'>"+
                                           "    <img src="+profileUrl+" alt='company logo' style='width:60px;padding-left: 5px;border-radius: 100%; padding-top:1px;'>"+
                                           "    </div>"+

                                           "    <div style='float: right; width: 222px;'>"+
                                           "        <div style='float: left; width: 100%; height: auto; box-sizing: border-box; margin-bottom: 6px; font-size: 15px; color: rgb(51, 51, 51); text-align: left; word-wrap: break-word; '>"+ agencyName +"</div>"+
                                           "        <div style='float: left; width: 222px; height: auto; box-sizing: border-box; text-align: left; word-wrap: break-word;'>"+agencyAddress+"</div>"+
                                           "    </div>"+
                                           "    </div>"+
                                           "    <div style='float: left; padding-left:10px; width: 100%; box-sizing: border-box; margin-top: 21px; padding-top: 10px; border-top: 1px solid #eee;'>"+
                                           "    <div style='float: left; font-weight: bold; font-size: 10px;'>Report Name : Bookings Per Interpreter</div>"+
                                           "    <div style='float: right; box-sizing: border-box; padding-right: 10px;  font-size: 10px; font-weight: bold;'>Account Name : "+result[0].interpreter_id.first_name+" "+result[0].interpreter_id.last_name+"</div>"+
                                           "    </div>"+
                                           "    <div style='float: left; width: calc(100% - 10px;);   margin-left:5px; margin-right:5px; box-sizing: border-box; border: 1px solid rgb(204, 204, 204); margin-top: 15px; background: white none repeat scroll 0% 0%;'>"+
                                           "    <div style='float: left; width: 100%; box-shadow: 0px 0px 7px 2px #ddd; min-height: 615px;'>"+
                                           "    <div style='float: left; width: 100%;'>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Booking Id</div>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Service Title</div>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Account</div>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Date</div>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Time</div>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px; border-right: 0;'>Working Hours</div>"+
                                           "    </div>";

                        var footerHtml =   "    </div>"+
                                           "    </div>"+
                                           "    </div>"+
                                           "    <div style='float: left; position: fixed: bottom: 0; width: 100%; background: #eee; box-sizing: border-box; padding: 4px 0px;'>"+
                                           "    <div style='font-style: italic; width: 100%; max-width: 1200px; text-align: center; float: none; margin: 0px auto; box-sizing: border-box; padding-right: 5px;'>All Rights Reserved &copy; Language Link Corporation</div>"+
                                           "    </div>"+
                                           "    </body>"+
                                           "    </html>";

                          var html = "";

                          async.eachSeries(result, function(bookingObj, next){

                                    var resultOne = {};
                                    resultOne = bookingObj;
                                    var startTime = moment(resultOne.check_in_time, "HH:mm a");
                                    var endTime = moment(resultOne.check_out_time, "HH:mm a");
                                    var duration = moment.duration(endTime.diff(startTime));
                                    var hours = parseInt(duration.asHours());
                                    var minutes = parseInt(duration.asMinutes())-hours*60;
                                    var working_hours =  hours + ' hrs and '+ minutes+' min';
                                    resultOne.working_hours = working_hours;

                                    html += "<div style='width: 100%; position: relative; height: 100%; float: left; border-bottom: 1px solid #ccc;'>"+
                                           "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.booking_id.booking_short_id+"</div>"+
                                           "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.booking_id.service_title+"</div>"+
                                           "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.client_id.first_name+" "+resultOne.client_id.last_name+"</div>"+
                                           "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+moment(resultOne.check_in_date).format("MM/DD/YYYY")+"</div>"+
                                           "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.check_in_time+" - "+resultOne.check_out_time+"</div>"+
                                           "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.working_hours+"</div>"+
                                           "</div>";
                                   var finalHtml = headerHtml+html+footerHtml;
                                    pdf.create(finalHtml, options).toFile(path, function(err, data) {
                                    if(err){
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: {},
                                            message: i18n.__("ERROR")
                                        })
                                    } else{
                                        next();
                                    } 
                                });     
                            },function(err){
                              if(err){
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("ERROR")
                                })
                              }else{
                                res.json({
                                    status: req.config.statusCode.success,
                                    data: path,
                                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                                });
                              }
                            })
                    }else{
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        });
                    }
                })
            }else{
                res.json({
                    status: req.config.statusCode.notFound,
                    data: {},
                    message: i18n.__("NO_RECORD_FOUND")
                });
            }
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            })

        });
    },

    getClientCompletedBookings: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            client_id: mongoose.Types.ObjectId(req.body.clientId),
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            check_io_approval: 'approved',
            is_deleted: false,
            status: true
        }

        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                'interpreterInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'interpreterInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'bookingInfo.booking_short_id': new RegExp(searchText, 'gi')
            },
            {
                'bookingInfo.service_title': new RegExp(searchText, 'gi')
            }
            ];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'schedulers',
                localField: "booking_id",
                foreignField: "_id",
                as: "bookingInfo"
            }
        },
        {
            $unwind: {
                path: "$bookingInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $lookup: {
                from: 'interpreters',
                localField: "interpreter_id",
                foreignField: "_id",
                as: "interpreterInfo"
            }
        }, {
            $unwind: {
                path: "$interpreterInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $match: condition
        }];

        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        CheckInOutModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                CheckInOutModel.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },
    
    exportClientCompletedBookingsToPdf: function (req, res, next) {
        var logoUrl = req.config.email.base_url+req.config.email.logo_url;
        var timestamp = Number(new Date());
        var condition = {
            client_id: mongoose.Types.ObjectId(req.params.id),
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            check_io_approval: 'approved',
            is_deleted: false,
            status: true
        }
        CheckInOutModel.find(condition)
        .populate('interpreter_id', 'first_name last_name')
        .populate('client_id', 'first_name last_name')
        .populate('booking_id')
        .then((result) => {
            if(!result){
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            }else if(result.length > 0){
                AgencyModel.findOne({_id: mongoose.Types.ObjectId(req.user.agency_id), status: true})
                .populate('country_id')
                .exec(function(err, agencyData){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        });
                    }else if(agencyData){
                        var options = { "format": "Letter"};
                        var profileUrl = req.config.email.base_url+ (agencyData.profile_pic ? agencyData.profile_pic: req.config.upload_dir.USER_PROFILE_PIC);
                        var filename = "doc" + timestamp + '_' + common.randomToken(6) +  ".pdf";
                        var path = "./../client/users/assets/uploads/reports/" + filename;
                        var agencyName = agencyData.agency_name;
                        if(agencyName && agencyData.address1!= '' && agencyData.address1 != null && agencyData.address1 != undefined && agencyData.address2 != '' && agencyData.address2 != null && agencyData.address2 != undefined){
                            var agencyAddress = agencyData.address1+', '+agencyData.address2+ ', '+agencyData.city+', '+agencyData.state+', '+agencyData.country_id.country_code.toUpperCase()+', '+agencyData.zip;   
                        }else if(agencyName && agencyData.address1 && !agencyData.address2){
                            var agencyAddress = agencyData.address1+', '+agencyData.city+', '+agencyData.state+', '+agencyData.country_id.country_code.toUpperCase()+', '+agencyData.zip;
                        }else{
                            var agencyAddress = '';
                        } 

                        var headerHtml  = "<!DOCTYPE html><head><meta charset='utf-8' /><meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'/><meta http-equiv='X-UA-Compatible' content='IE=edge' /><meta http-equiv='Content-Type' content='text/html; charset=utf-8'><title>HTML</title></head>"+
                                           "   <body style='float: left; width: 100%; margin: 0px; padding: 0px; height: 100%; font-family: sans-serif,arial; font-size: 11px; color: rgb(85, 85, 85); background: rgb(252, 252, 252) none repeat scroll 0% 0%;'>"+
                                           "    <div style='float: left; width: 100%;  box-sizing: border-box; padding: 20px 5px 0px; overflow: auto; '>"+

                                           "    <div style='float:left;'>"+
                                           "    <img src="+profileUrl+" alt='company logo' style='width:60px;padding-left: 5px;border-radius: 100%; padding-top:1px;'>"+
                                           "    </div>"+

                                           "    <div style='float: right; width: 222px;'>"+
                                           "        <div style='float: left; width: 100%; height: auto; box-sizing: border-box; margin-bottom: 6px; font-size: 15px; color: rgb(51, 51, 51); text-align: left; word-wrap: break-word; '>"+ agencyName +"</div>"+
                                           "        <div style='float: left; width: 222px; height: auto; box-sizing: border-box; text-align: left; word-wrap: break-word;'>"+agencyAddress+"</div>"+
                                           "    </div>"+
                                           "    </div>"+
                                           "    <div style='float: left; padding-left:10px; width: 100%; box-sizing: border-box; margin-top: 21px; padding-top: 10px; border-top: 1px solid #eee;'>"+
                                           "    <div style='float: left; font-weight: bold; font-size: 10px;'>Report Name : Bookings Per Account</div>"+
                                           "    <div style='float: right; box-sizing: border-box; padding-right: 10px;  font-size: 10px; font-weight: bold;'>Account Name : "+result[0].client_id.first_name+" "+result[0].client_id.last_name+"</div>"+
                                           "    </div>"+
                                           "    <div style='float: left; width: calc(100% - 10px;);   margin-left:5px; margin-right:5px; box-sizing: border-box; border: 1px solid rgb(204, 204, 204); margin-top: 15px; background: white none repeat scroll 0% 0%;'>"+
                                           "    <div style='float: left; width: 100%; box-shadow: 0px 0px 7px 2px #ddd; min-height: 615px;'>"+
                                           "    <div style='float: left; width: 100%;'>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Booking Id</div>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Service Title</div>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Interpreter</div>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Date</div>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Time</div>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px; border-right: 0;'>Working Hours</div>"+
                                           "    </div>";

                        var footerHtml =   "    </div>"+
                                           "    </div>"+
                                           "    </div>"+
                                           "    <div style='float: left; position: fixed: bottom: 0; width: 100%; background: #eee; box-sizing: border-box; padding: 4px 0px;'>"+
                                           "    <div style='font-style: italic; width: 100%; max-width: 1200px; text-align: center; float: none; margin: 0px auto; box-sizing: border-box; padding-right: 5px;'>All Rights Reserved &copy; Language Link Corporation</div>"+
                                           "    </div>"+
                                           "    </body>"+
                                           "    </html>";

                          var html = "";

                          async.eachSeries(result, function(bookingObj, next){

                                    var resultOne = {};
                                    resultOne = bookingObj;
                                    var startTime = moment(resultOne.check_in_time, "HH:mm a");
                                    var endTime = moment(resultOne.check_out_time, "HH:mm a");
                                    var duration = moment.duration(endTime.diff(startTime));
                                    var hours = parseInt(duration.asHours());
                                    var minutes = parseInt(duration.asMinutes())-hours*60;
                                    var working_hours =  hours + ' hrs and '+ minutes+' min';
                                    resultOne.working_hours = working_hours;

                                    html += "<div style='width: 100%; position: relative; height: 100%; float: left; border-bottom: 1px solid #ccc;'>"+
                                           "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.booking_id.booking_short_id+"</div>"+
                                           "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.booking_id.service_title+"</div>"+
                                           "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.interpreter_id.first_name+" "+resultOne.interpreter_id.last_name+"</div>"+
                                           "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+moment(resultOne.check_in_date).format("MM/DD/YYYY")+"</div>"+
                                           "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.check_in_time+" - "+resultOne.check_out_time+"</div>"+
                                           "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.working_hours+"</div>"+
                                           "</div>";
                                   var finalHtml = headerHtml+html+footerHtml;
                                    pdf.create(finalHtml, options).toFile(path, function(err, data) {
                                    if(err){
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: {},
                                            message: i18n.__("ERROR")
                                        })
                                    } else{
                                        next();
                                    } 
                                  });
                                     
                            },function(err){
                              if(err){
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("ERROR")
                                })
                              }else{
                                res.json({
                                    status: req.config.statusCode.success,
                                    data: path,
                                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                                });
                              }
                            })
                    }else{
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        });
                    }
                })
            }else{
                res.json({
                    status: req.config.statusCode.notFound,
                    data: {},
                    message: i18n.__("NO_RECORD_FOUND")
                });
            }
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })
        });
    },

    getLanguageCompletedBookings: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            check_io_approval: 'approved',
            is_deleted: false,
            status: true
        }

        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                'interpreterInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'interpreterInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'clientInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'clientInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'schedulerInfo.booking_short_id': new RegExp(searchText, 'gi')
            },
            {
                'schedulerInfo.service_title': new RegExp(searchText, 'gi')
            }
            ];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'clients',
                localField: "client_id",
                foreignField: "_id",
                as: "clientInfo"
            }
        },
        {
            $unwind: {
                path: "$clientInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $lookup: {
                from: 'interpreters',
                localField: "interpreter_id",
                foreignField: "_id",
                as: "interpreterInfo"
            }
        }, {
            $unwind: {
                path: "$interpreterInfo",
                preserveNullAndEmptyArrays: true
            }
        },{
            $lookup: {
                from: 'schedulers',
                localField: "booking_id",
                foreignField: "_id",
                as: "schedulerInfo"
            }
        },{
            $match: condition
        },{    
            $project: {
                check_in_date:1,
                check_in_time:1,
                check_out_time:1,
                interpreterInfo: {
                    first_name: "$interpreterInfo.first_name",
                    last_name: "$interpreterInfo.last_name"
                },
                clientInfo: {
                    first_name: "$clientInfo.first_name",
                    last_name: "$clientInfo.last_name"
                },
                schedulerInfo: {
                    $filter: {
                        input: "$schedulerInfo",        
                        as: "item",        
                        cond: {          
                            $or: [
                                {              
                                    $eq: ["$$item.language_interprete_from", mongoose.Types.ObjectId(req.body.language)]            
                                },            
                                {              
                                    $eq: ["$$item.language_interprete_into", mongoose.Types.ObjectId(req.body.language)]            
                                }                  
                            ]
                        }
                    }
                }, 
            }
        }];

        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });

        CheckInOutModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                CheckInOutModel.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        var resultArray = [];
                        var obj = _.filter(result, function(d) { 
                            if(d.schedulerInfo.length > 0 ){
                                d.bookingInfo = {
                                    service_title: d.schedulerInfo[0].service_title,
                                    booking_short_id: d.schedulerInfo[0].booking_short_id
                                }
                                delete d.schedulerInfo;
                                resultArray.push(d);
                            }
                        });
                        if(resultArray.length > 0){
                            res.json({
                                status: req.config.statusCode.success,
                                data: resultArray,
                                count: cnt
                            });
                        }else{
                            res.json({
                                status: req.config.statusCode.success,
                                data: [],
                                count: 0
                            });
                        }
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    exportPerLanguageToPdf: function (req, res, next) {
        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            check_io_approval: 'approved',
            is_deleted: false,
            status: true
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'clients',
                localField: "client_id",
                foreignField: "_id",
                as: "clientInfo"
            }
        },
        {
            $unwind: {
                path: "$clientInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $lookup: {
                from: 'interpreters',
                localField: "interpreter_id",
                foreignField: "_id",
                as: "interpreterInfo"
            }
        }, {
            $unwind: {
                path: "$interpreterInfo",
                preserveNullAndEmptyArrays: true
            }
        },{
            $lookup: {
                from: 'schedulers',
                localField: "booking_id",
                foreignField: "_id",
                as: "schedulerInfo"
            }
        },{
            $match: condition
        },{    
            $project: {
                check_in_date:1,
                check_in_time:1,
                check_out_time:1,
                interpreterInfo: {
                    first_name: "$interpreterInfo.first_name",
                    last_name: "$interpreterInfo.last_name"
                },
                clientInfo: {
                    first_name: "$clientInfo.first_name",
                    last_name: "$clientInfo.last_name"
                },
                languages: {
                    $filter: {
                        input: "$schedulerInfo",        
                        as: "item",        
                        cond: {          
                            $or: [
                                {              
                                    $eq: ["$$item.language_interprete_from", mongoose.Types.ObjectId(req.params.language)]            
                                },            
                                {              
                                    $eq: ["$$item.language_interprete_into", mongoose.Types.ObjectId(req.params.language)]            
                                }                  
                            ]
                        }
                    }
                }, 
            }
        }];

        CheckInOutModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                var resultArray = [];
                var obj = _.filter(result, function(d) { 
                    if(d.languages.length > 0 ){
                        d.bookingInfo = {
                            service_title: d.languages[0].service_title,
                            booking_short_id: d.languages[0].booking_short_id
                        }
                        delete d.languages;
                        resultArray.push(d);
                    }
                });
                if(resultArray.length > 0){
                    LanguageModel.findOne({_id: mongoose.Types.ObjectId(req.params.language), is_deleted: false, status: true})
                    .exec(function(err, languageData){
                        if(err){
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            });
                        }else if(languageData){
                            var logoUrl = req.config.email.base_url+req.config.email.logo_url;
                            var timestamp = Number(new Date());
                            AgencyModel.findOne({_id: mongoose.Types.ObjectId(req.user.agency_id), status: true})
                            .populate('country_id')
                            .exec(function(err, agencyData){
                                if(err){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("ERROR")
                                    });
                                }else if(agencyData){
                                    var languageName = languageData.language_name.charAt(0).toUpperCase()+languageData.language_name.slice(1).toLowerCase();
                                    var options = { "format": "Letter"};
                                    var profileUrl = req.config.email.base_url+ (agencyData.profile_pic ? agencyData.profile_pic: req.config.upload_dir.USER_PROFILE_PIC);
                                    var filename = "doc" + timestamp + '_' + common.randomToken(6) +  ".pdf";
                                    var path = "./../client/users/assets/uploads/reports/" + filename;
                                    var agencyName = agencyData.agency_name;
                                    if(agencyName && agencyData.address1!= '' && agencyData.address1 != null && agencyData.address1 != undefined && agencyData.address2 != '' && agencyData.address2 != null && agencyData.address2 != undefined){
                                        var agencyAddress = agencyData.address1+', '+agencyData.address2+ ', '+agencyData.city+', '+agencyData.state+', '+agencyData.country_id.country_code.toUpperCase()+', '+agencyData.zip;   
                                    }else if(agencyName && agencyData.address1 && !agencyData.address2){
                                        var agencyAddress = agencyData.address1+', '+agencyData.city+', '+agencyData.state+', '+agencyData.country_id.country_code.toUpperCase()+', '+agencyData.zip;
                                    }else{
                                        var agencyAddress = '';
                                    } 

                                    var headerHtml  = "<!DOCTYPE html><head><meta charset='utf-8' /><meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'/><meta http-equiv='X-UA-Compatible' content='IE=edge' /><meta http-equiv='Content-Type' content='text/html; charset=utf-8'><title>HTML</title></head>"+
                                                       "   <body style='float: left; width: 100%; margin: 0px; padding: 0px; height: 100%; font-family: sans-serif,arial; font-size: 11px; color: rgb(85, 85, 85); background: rgb(252, 252, 252) none repeat scroll 0% 0%;'>"+
                                                       "    <div style='float: left; width: 100%;  box-sizing: border-box; padding: 20px 5px 0px; overflow: auto; '>"+

                                                       "    <div style='float:left;'>"+
                                                       "    <img src="+profileUrl+" alt='company logo' style='width:60px;padding-left: 5px;border-radius: 100%; padding-top:1px;'>"+
                                                       "    </div>"+

                                                       "    <div style='float: right; width: 222px;'>"+
                                                       "        <div style='float: left; width: 100%; height: auto; box-sizing: border-box; margin-bottom: 6px; font-size: 15px; color: rgb(51, 51, 51); text-align: left; word-wrap: break-word; '>"+ agencyName +"</div>"+
                                                       "        <div style='float: left; width: 222px; height: auto; box-sizing: border-box; text-align: left; word-wrap: break-word;'>"+agencyAddress+"</div>"+
                                                       "    </div>"+
                                                       "    </div>"+
                                                       "    <div style='float: left; padding-left:10px; width: 100%; box-sizing: border-box; margin-top: 21px; padding-top: 10px; border-top: 1px solid #eee;'>"+
                                                       "    <div style='float: left; font-weight: bold; font-size: 10px;'>Report Name : Booking Per Language</div>"+
                                                       "    <div style='float: right; box-sizing: border-box; padding-right: 10px;  font-size: 10px; font-weight: bold;'>Language Name : "+languageName+"</div>"+
                                                       "    </div>"+
                                                       "    <div style='float: left; width: calc(100% - 10px;);   margin-left:5px; margin-right:5px; box-sizing: border-box; border: 1px solid rgb(204, 204, 204); margin-top: 15px; background: white none repeat scroll 0% 0%;'>"+
                                                       "    <div style='float: left; width: 100%; box-shadow: 0px 0px 7px 2px #ddd; min-height: 615px;'>"+
                                                       "    <div style='float: left; width: 100%;'>"+
                                                       "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Booking Id</div>"+
                                                       "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Service Title</div>"+
                                                       "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Account</div>"+
                                                       "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Interpreter</div>"+
                                                       "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Date</div>"+
                                                       "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px; border-right: 0;'>Time</div>"+
                                                       "    </div>";

                                    var footerHtml =   "    </div>"+
                                                       "    </div>"+
                                                       "    </div>"+
                                                       "    <div style='float: left; position: fixed: bottom: 0; width: 100%; background: #eee; box-sizing: border-box; padding: 4px 0px;'>"+
                                                       "    <div style='font-style: italic; width: 100%; max-width: 1200px; text-align: center; float: none; margin: 0px auto; box-sizing: border-box; padding-right: 5px;'>All Rights Reserved &copy; Language Link Corporation</div>"+
                                                       "    </div>"+
                                                       "    </body>"+
                                                       "    </html>";

                                    var html = "";

                                    async.eachSeries(resultArray, function(bookingObj, next){
                                        var resultOne = {};
                                        resultOne = bookingObj;
                                        var clientName = resultOne.clientInfo.first_name.charAt(0).toUpperCase()+resultOne.clientInfo.first_name.slice(1).toLowerCase()+ ' '+resultOne.clientInfo.last_name.charAt(0).toUpperCase()+resultOne.clientInfo.last_name.slice(1).toLowerCase();
                                        var interpreterName = resultOne.interpreterInfo.first_name.charAt(0).toUpperCase()+resultOne.interpreterInfo.first_name.slice(1).toLowerCase()+ ' '+resultOne.interpreterInfo.last_name.charAt(0).toUpperCase()+resultOne.interpreterInfo.last_name.slice(1).toLowerCase();
                                        html += "<div style='width: 100%; position: relative; height: 100%; float: left; border-bottom: 1px solid #ccc;'>"+
                                                "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.bookingInfo.booking_short_id+"</div>"+
                                                "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.bookingInfo.service_title+"</div>"+
                                                "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+clientName+"</div>"+
                                                "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+interpreterName+"</div>"+
                                                "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+moment(resultOne.check_in_date).format("MM/DD/YYYY")+"</div>"+
                                                "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.check_in_time+ ' - '+resultOne.check_out_time+"</div>"+
                                                "</div>";
                                        var finalHtml = headerHtml+html+footerHtml;
                                        pdf.create(finalHtml, options).toFile(path, function(err, data) {
                                            if(err){
                                                console.log("error in pdf",err);
                                                res.json({
                                                    status: req.config.statusCode.error,
                                                    data: {},
                                                    message: i18n.__("ERROR")
                                                })
                                            } else{
                                                next();
                                            } 
                                        });       
                                    },function(err){
                                        if(err){
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: {},
                                                message: i18n.__("ERROR")
                                            })
                                        }else{
                                            res.json({
                                                status: req.config.statusCode.success,
                                                data: path,
                                                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                                            });
                                        }
                                    })
                                }else{
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("ERROR")
                                    });
                                }
                            })
                        }else{
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            });
                        }
                    })
                }else{
                    res.json({
                        status: req.config.statusCode.notFound,
                        data: [],
                        count: 0,
                        message: i18n.__("NO_RECORD_FOUND")
                    });
                }
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    getTopTenClients: function (req, res, next) {
        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.agency_id), 
            check_io_approval: 'approved',
            is_deleted: false,
            status: true
        }

        var aggregate = [{
                $lookup: {
                    from: 'clients',
                    localField: "client_id",
                    foreignField: "_id",
                    as: "clientInfo"
                }
            },
            { $unwind: {
                    path: "$clientInfo",
                    preserveNullAndEmptyArrays: true
                } 
            },{ 
                $match: condition
            }, {
                $lookup: {
                    from: 'users',
                    localField: "clientInfo.user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            }, { $unwind: {
                    path: "$userInfo",
                    preserveNullAndEmptyArrays: true
                } 
            },{
                $group: {
                    _id: '$clientInfo._id',
                    count: { "$sum": 1},
                    first_name: { $first : "$clientInfo.first_name"},
                    last_name: { $first : "$clientInfo.last_name"},
                    client_shortid: { $first : "$clientInfo.client_shortid"},
                    mobile_no: { $first : "$clientInfo.mobile_no"},
                    email: { $first : "$userInfo.email"}
                }
            
            },{
                $sort : {count: -1}
            },{
                $limit: 10
            }
        ];

        CheckInOutModel.aggregate(aggregate).exec(function (err, record) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                res.json({
                    status: req.config.statusCode.success,
                    data: record,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    exportTopTenClientsToPdf: function (req, res, next) {
        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.agency_id), 
            check_io_approval: 'approved',
            is_deleted: false,
            status: true
        }

        var aggregate = [{
                $lookup: {
                    from: 'clients',
                    localField: "client_id",
                    foreignField: "_id",
                    as: "clientInfo"
                }
            },
            { $unwind: {
                    path: "$clientInfo",
                    preserveNullAndEmptyArrays: true
                } 
            },{ 
                $match: condition
            }, {
                $lookup: {
                    from: 'users',
                    localField: "clientInfo.user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            }, { $unwind: {
                    path: "$userInfo",
                    preserveNullAndEmptyArrays: true
                } 
            },{
                $group: {
                    _id: '$clientInfo._id',
                    count: { "$sum": 1},
                    first_name: { $first : "$clientInfo.first_name"},
                    last_name: { $first : "$clientInfo.last_name"},
                    client_shortid: { $first : "$clientInfo.client_shortid"},
                    mobile_no: { $first : "$clientInfo.mobile_no"},
                    email: { $first : "$userInfo.email"}
                }
            
            },{
                $sort : {count: -1}
            },{
                $limit: 10
            }
        ];

        CheckInOutModel.aggregate(aggregate).exec(function (err, result) {
            var logoUrl = req.config.email.base_url+req.config.email.logo_url;
            var timestamp = Number(new Date());
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else if(result.length > 0) {
                AgencyModel.findOne({_id: mongoose.Types.ObjectId(req.user.agency_id), status: true})
                .populate('country_id')
                .exec(function(err, agencyData){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        });
                    }else if(agencyData){
                        var options = { "format": "Letter"};
                        var profileUrl = req.config.email.base_url+ (agencyData.profile_pic ? agencyData.profile_pic: req.config.upload_dir.USER_PROFILE_PIC);
                        var filename = "doc" + timestamp + '_' + common.randomToken(6) +  ".pdf";
                        var path = "./../client/users/assets/uploads/reports/" + filename;
                        var agencyName = agencyData.agency_name;
                        if(agencyName && agencyData.address1!= '' && agencyData.address1 != null && agencyData.address1 != undefined && agencyData.address2 != '' && agencyData.address2 != null && agencyData.address2 != undefined){
                            var agencyAddress = agencyData.address1+', '+agencyData.address2+ ', '+agencyData.city+', '+agencyData.state+', '+agencyData.country_id.country_code.toUpperCase()+', '+agencyData.zip;   
                        }else if(agencyName && agencyData.address1 && !agencyData.address2){
                            var agencyAddress = agencyData.address1+', '+agencyData.city+', '+agencyData.state+', '+agencyData.country_id.country_code.toUpperCase()+', '+agencyData.zip;
                        }else{
                            var agencyAddress = '';
                        } 

                        var headerHtml  = "<!DOCTYPE html><head><meta charset='utf-8' /><meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'/><meta http-equiv='X-UA-Compatible' content='IE=edge' /><meta http-equiv='Content-Type' content='text/html; charset=utf-8'><title>HTML</title></head>"+
                                           "   <body style='float: left; width: 100%; margin: 0px; padding: 0px; height: 100%; font-family: sans-serif,arial; font-size: 11px; color: rgb(85, 85, 85); background: rgb(252, 252, 252) none repeat scroll 0% 0%;'>"+
                                           "    <div style='float: left; width: 100%;  box-sizing: border-box; padding: 20px 5px 0px; overflow: auto; '>"+

                                           "    <div style='float:left;'>"+
                                           "    <img src="+profileUrl+" alt='company logo' style='width:60px;padding-left: 5px;border-radius: 100%; padding-top:1px;'>"+
                                           "    </div>"+

                                           "    <div style='float: right; width: 222px;'>"+
                                           "        <div style='float: left; width: 100%; height: auto; box-sizing: border-box; margin-bottom: 6px; font-size: 15px; color: rgb(51, 51, 51); text-align: left; word-wrap: break-word; '>"+ agencyName +"</div>"+
                                           "        <div style='float: left; width: 222px; height: auto; box-sizing: border-box; text-align: left; word-wrap: break-word;'>"+agencyAddress+"</div>"+
                                           "    </div>"+
                                           "    </div>"+
                                           "    <div style='float: left; padding-left:10px; width: 100%; box-sizing: border-box; margin-top: 21px; padding-top: 10px; border-top: 1px solid #eee;'>"+
                                           "    <div style='float: left; font-weight: bold; font-size: 10px;'>Report Name : Top 10 Account</div>"+
                                           "    </div>"+
                                           "    <div style='float: left; width: calc(100% - 10px;);   margin-left:5px; margin-right:5px; box-sizing: border-box; border: 1px solid rgb(204, 204, 204); margin-top: 15px; background: white none repeat scroll 0% 0%;'>"+
                                           "    <div style='float: left; width: 100%; box-shadow: 0px 0px 7px 2px #ddd; min-height: 615px;'>"+
                                           "    <div style='float: left; width: 100%;'>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 20%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Account Id</div>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 20%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Account Name</div>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 20%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>No of Bookings</div>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 20%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Mobile No</div>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 20%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;border-right: 0;'>Email</div>"+
                                           "    </div>";

                        var footerHtml =   "    </div>"+
                                           "    </div>"+
                                           "    </div>"+
                                           "    <div style='float: left; position: fixed: bottom: 0; width: 100%; background: #eee; box-sizing: border-box; padding: 4px 0px;'>"+
                                           "    <div style='font-style: italic; width: 100%; max-width: 1200px; text-align: center; float: none; margin: 0px auto; box-sizing: border-box; padding-right: 5px;'>All Rights Reserved &copy; Language Link Corporation</div>"+
                                           "    </div>"+
                                           "    </body>"+
                                           "    </html>";
                        var html = "";
                        async.eachSeries(result,function(resultOne,next){
                            html += "<div style='width: 100%; position: relative; height: 100%; float: left; border-bottom: 1px solid #ccc;'>"+
                                   "<div style='box-sizing: border-box; width: 20%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.client_shortid+"</div>"+
                                   "<div style='box-sizing: border-box; width: 20%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.first_name+" "+resultOne.last_name+"</div>"+
                                   "<div style='box-sizing: border-box; width: 20%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.count+"</div>"+
                                   "<div style='box-sizing: border-box; width: 20%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.mobile_no+"</div>"+
                                   "<div style='box-sizing: border-box; width: 20%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.email+"</div>"+
                                   "</div>";
                            var finalHtml = headerHtml+html+footerHtml;
                            pdf.create(finalHtml, options).toFile(path, function(err, data) {
                                if(err){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: req.body,
                                        message: i18n.__("ERROR")
                                    })
                                }else{
                                    next();
                                } 
                              });              
                        },function(err){
                            if(err){
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: req.body,
                                    message: i18n.__("ERROR")
                                })
                            }else{
                                res.json({
                                    status: req.config.statusCode.success,
                                    data: path,
                                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                                });
                            }
                        })
                    }else{
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        });
                    }
                })
            }else{
                res.json({
                    status: req.config.statusCode.notFound,
                    data: [],
                    count: 0,
                    message: i18n.__("NO_RECORD_FOUND")
                });    
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    getTopTenLanguageReport: function (req, res, next) {
        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            check_io_approval: 'approved',
            is_deleted: false,
            status: true
        }

        var aggregate = [{
                $lookup: {
                    from: 'schedulers',
                    localField: "booking_id",
                    foreignField: "_id",
                    as: "bookingInfo"
                }
            },{ $unwind: "$bookingInfo"
            },{
                $lookup: {
                    from: 'languages',
                    localField: "bookingInfo.language_interprete_from",
                    foreignField: "_id",
                    as: "languageFromInfo"
                }
            },{ $unwind: "$languageFromInfo"
            },{
                $lookup: {
                    from: 'languages',
                    localField: "bookingInfo.language_interprete_into",
                    foreignField: "_id",
                    as: "languageIntoInfo"
                }
            },{ $unwind: "$languageIntoInfo"
            },{ 
                $match: condition
            },
            {
                $group: {
                    _id: {
                        $and : [ 
                            { $eq: [ '$languageFromInfo._id' , '$languageFromInfo._id'] },
                            { $eq: [ '$languageIntoInfo._id', '$languageIntoInfo._id'] }
                        ] 
                    },
                    count: { "$sum": 1},
                    language_into_name: { $first : "$languageIntoInfo.language_name"},
                    language_from_name: { $first : "$languageFromInfo.language_name"},
                }
            },{
                $sort : {count: -1}
            },{
                $limit: 10
            }
        ];

        CheckInOutModel.aggregate(aggregate).exec(function (err, record) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                console.log("record", record);
                res.json({
                    status: req.config.statusCode.success,
                    data: record,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    exportTopTenLaguageToPdf: function (req, res, next) {
        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            check_io_approval: 'approved',
            is_deleted: false,
            status: true
        }

        var aggregate = [{
                $lookup: {
                    from: 'schedulers',
                    localField: "booking_id",
                    foreignField: "_id",
                    as: "bookingInfo"
                }
            },{ $unwind: "$bookingInfo"
            },{
                $lookup: {
                    from: 'languages',
                    localField: "bookingInfo.language_interprete_from",
                    foreignField: "_id",
                    as: "languageFromInfo"
                }
            },{ $unwind: "$languageFromInfo"
            },{
                $lookup: {
                    from: 'languages',
                    localField: "bookingInfo.language_interprete_into",
                    foreignField: "_id",
                    as: "languageIntoInfo"
                }
            },{ $unwind: "$languageIntoInfo"
            },{ 
                $match: condition
            },
            {
                $group: {
                    _id: {
                        $and : [ 
                            { $eq: [ '$languageFromInfo._id' , '$languageFromInfo._id'] },
                            { $eq: [ '$languageIntoInfo._id', '$languageIntoInfo._id'] }
                        ] 
                    },
                    count: { "$sum": 1},
                    language_from_name: { $first : "$languageFromInfo.language_name"},
                    language_into_name: { $first : "$languageIntoInfo.language_name"},
                }
            },{
                $sort : {count: -1}
            },{
                $limit: 10
            }
        ];

        CheckInOutModel.aggregate(aggregate).exec(function (err, record) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else if(record.length > 0) {
                var logoUrl = req.config.email.base_url+req.config.email.logo_url;
                var timestamp = Number(new Date());
                AgencyModel.findOne({_id: mongoose.Types.ObjectId(req.user.agency_id), status: true})
                .populate('country_id')
                .exec(function(err, agencyData){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        });
                    }else if(agencyData){
                        var options = { "format": "Letter"};
                        var profileUrl = req.config.email.base_url+ (agencyData.profile_pic ? agencyData.profile_pic: req.config.upload_dir.USER_PROFILE_PIC);
                        var filename = "doc" + timestamp + '_' + common.randomToken(6) +  ".pdf";
                        var path = "./../client/users/assets/uploads/reports/" + filename;
                        var agencyName = agencyData.agency_name;
                        if(agencyName && agencyData.address1!= '' && agencyData.address1 != null && agencyData.address1 != undefined && agencyData.address2 != '' && agencyData.address2 != null && agencyData.address2 != undefined){
                            var agencyAddress = agencyData.address1+', '+agencyData.address2+ ', '+agencyData.city+', '+agencyData.state+', '+agencyData.country_id.country_code.toUpperCase()+', '+agencyData.zip;   
                        }else if(agencyName && agencyData.address1 && !agencyData.address2){
                            var agencyAddress = agencyData.address1+', '+agencyData.city+', '+agencyData.state+', '+agencyData.country_id.country_code.toUpperCase()+', '+agencyData.zip;
                        }else{
                            var agencyAddress = '';
                        } 

                        var headerHtml  = "<!DOCTYPE html><head><meta charset='utf-8' /><meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'/><meta http-equiv='X-UA-Compatible' content='IE=edge' /><meta http-equiv='Content-Type' content='text/html; charset=utf-8'><title>HTML</title></head>"+
                                           "   <body style='float: left; width: 100%; margin: 0px; padding: 0px; height: 100%; font-family: sans-serif,arial; font-size: 11px; color: rgb(85, 85, 85); background: rgb(252, 252, 252) none repeat scroll 0% 0%;'>"+
                                           "    <div style='float: left; width: 100%;  box-sizing: border-box; padding: 20px 5px 0px; overflow: auto; '>"+

                                           "    <div style='float:left;'>"+
                                           "    <img src="+profileUrl+" alt='company logo' style='width:60px;padding-left: 5px;border-radius: 100%; padding-top:1px;'>"+
                                           "    </div>"+

                                           "    <div style='float: right; width: 222px;'>"+
                                           "        <div style='float: left; width: 100%; height: auto; box-sizing: border-box; margin-bottom: 6px; font-size: 15px; color: rgb(51, 51, 51); text-align: left; word-wrap: break-word; '>"+ agencyName +"</div>"+
                                           "        <div style='float: left; width: 222px; height: auto; box-sizing: border-box; text-align: left; word-wrap: break-word;'>"+agencyAddress+"</div>"+
                                           "    </div>"+
                                           "    </div>"+
                                           "    <div style='float: left; padding-left:10px; width: 100%; box-sizing: border-box; margin-top: 21px; padding-top: 10px; border-top: 1px solid #eee;'>"+
                                           "    <div style='float: left; font-weight: bold; font-size: 10px;'>Report Name : Top 10 Languages</div>"+
                                           "    </div>"+
                                           "    <div style='float: left; width: 98%;   margin-left:5px; margin-right:5px; box-sizing: border-box; border: 1px solid rgb(204, 204, 204); margin-top: 15px; background: white none repeat scroll 0% 0%;'>"+
                                           "    <div style='float: left; width: 100%; box-shadow: 0px 0px 7px 2px #ddd; min-height: 615px;'>"+
                                           "    <div style='float: left; width: 100%;'>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 50%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Languages</div>"+
                                           "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 50%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px; border-right: 0;'>No of Booking</div>"+
                                           "    </div>";


                        var footerHtml =   "    </div>"+
                                           "    </div>"+
                                           "    </div>"+
                                           "    <div style='float: left; position: fixed: bottom: 0; width: 100%; background: #eee; box-sizing: border-box; padding: 4px 0px;'>"+
                                           "    <div style='font-style: italic; width: 100%; max-width: 1200px; text-align: center; float: none; margin: 0px auto; box-sizing: border-box; padding-right: 5px;'>All Rights Reserved &copy; Language Link Corporation</div>"+
                                           "    </div>"+
                                           "    </body>"+
                                           "    </html>";
                        var html = "";
                        async.eachSeries(record,function(resultOne,next){
                            var languagePair = resultOne.language_from_name.charAt(0).toUpperCase()+resultOne.language_from_name.slice(1).toLowerCase()+ ' - '+resultOne.language_into_name.charAt(0).toUpperCase()+resultOne.language_into_name.slice(1).toLowerCase()  ;
                            html += "<div style='width: 100%; position: relative; height: 100%; float: left; border-bottom: 1px solid #ccc;'>"+
                                   "<div style='box-sizing: border-box; width: 50%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+languagePair+"</div>"+
                                   "<div style='box-sizing: border-box; width: 50%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.count+"</div>"+
                                   "</div>";
                            var finalHtml = headerHtml+html+footerHtml;
                            pdf.create(finalHtml, options).toFile(path, function(err, data) {
                                if(err){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("ERROR")
                                    })
                                }else{
                                    next();
                                } 
                              });              
                        },function(err){
                            if(err){
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("ERROR")
                                })
                            }else{
                                res.json({
                                    status: req.config.statusCode.success,
                                    data: path,
                                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                                });
                            }
                        })
                    }else{
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        });
                    }
                })
            }else{
                res.json({
                    status: req.config.statusCode.notFound,
                    data: {},
                    message: i18n.__("NO_RECORD_FOUND")
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

}