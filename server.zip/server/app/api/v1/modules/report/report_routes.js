module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];
    var report_ctrl = require('./controllers/report_ctrl')

    // router.post('/report/addEventName', middlewares, report_ctrl.addEventName);
    router.post('/report/getInterpreterCompletedBookings', middlewares, report_ctrl.getInterpreterCompletedBookings);
    router.post('/report/getClientCompletedBookings', middlewares, report_ctrl.getClientCompletedBookings);
    router.post('/report/getLanguageCompletedBookings', middlewares, report_ctrl.getLanguageCompletedBookings);
    router.get('/report/getTopTenClients', middlewares, report_ctrl.getTopTenClients);
    router.get('/report/getTopTenLanguageReport', middlewares, report_ctrl.getTopTenLanguageReport);
    router.get('/report/exportTopTenClientsToPdf', middlewares, report_ctrl.exportTopTenClientsToPdf);
    router.get('/report/exportTopTenLaguageToPdf', middlewares, report_ctrl.exportTopTenLaguageToPdf);
    router.get('/report/exportInterpreterCompletedBookingsToPdf/:id', middlewares, report_ctrl.exportInterpreterCompletedBookingsToPdf);
    router.get('/report/exportClientCompletedBookingsToPdf/:id', middlewares, report_ctrl.exportClientCompletedBookingsToPdf);
    router.get('/report/exportPerLanguageToPdf/:language', middlewares, report_ctrl.exportPerLanguageToPdf);
             
    return router;
}