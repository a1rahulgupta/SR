const _ = require("lodash");
const moment = require('moment');
const Joi = require('joi');
const i18n = require("i18n");
const formidable = require('formidable');
const util = require('util');
const mongoose = require('mongoose');
const CronJob = require('cron').CronJob;
const santize = __rootRequire('app/utils/santize');
const image = __rootRequire('app/utils/image');
const text = __rootRequire('app/utils/text');
// const csv = require('csv-parser');
var csv = require("fast-csv");
const uuidV4 = require('uuid/v4');
const emailSend = __rootRequire('app/core/email');
const common = __rootRequire('app/config/common.js');
const fs = require('fs');
const fs_extra= require('fs-extra');
const path = require('path');
const twilioSms = __rootRequire('app/utils/twilioSms');
const async = require('async');
const waterfall = require('async-waterfall');
const validator = __rootRequire('app/config/config.js');
const bcrypt = require('bcrypt');
//Models 
const User = mongoose.model('Users');
const AgencyModel = mongoose.model('Agencies');
const SchedulerModel = mongoose.model('Schedulers');
const ClientModel = mongoose.model('Clients');
const Booking = mongoose.model('Bookings');
const RoleModel = mongoose.model('Roles');
const InterpreterModel = mongoose.model('Interpreters');
const InterpreterUnavailableModel = mongoose.model('Interpreter_unavailabels');
const EmailTemplateModel = mongoose.model('Email_Templates');
const Interpreter_servicesInterpreter_services = mongoose.model('Interpreter_services');
const AgencyUser = mongoose.model('Agency_users');
const InterpreterServiceModel = mongoose.model('Interpreter_services');
const InterpreterLanguageModel = mongoose.model('Interpreter_languages');
const LanguageModel = mongoose.model('Languages');
const InterpreterCertificateModel = mongoose.model('Interpreter_certificates');
const CountryModel = mongoose.model('Countries');
const VideoCallModel = mongoose.model('Video_calls');
const NodeGeocoder = require('node-geocoder');
const options = {
        provider: 'google',
        
        // Optional depending on the providers 
        httpAdapter: 'https', // Default 
        // apiKey: 'AIzaSyAJ37RsuZLLET5oI16rrVFnfJOxYPPY8cg', // for Mapquest, OpenCage, Google Premier 
        apiKey: 'AIzaSyArCVKu0-JXlGx-zTZswDoJECIc8PtNgxw', // for Mapquest, OpenCage, Google Premier 
        formatter: null // 'gpx', 'string', ... 
};

// const geocoder = NodeGeocoder(options);


module.exports = {

    listAgencyInterpreters: function (req, res, next) {
        InterpreterModel.find({
                agency_id: req.user.agency_id,
                is_deleted: false
            }, {
                _id: 1,
                first_name: 1,
                last_name: 1,
                gender: 1,
                profile_pic: 1
            })
            .exec()
            .then((interpreters) => {
                interpreters = image.setImagePath(interpreters, 'profile_pic')

                res.json({
                    status: req.config.statusCode.success,
                    data: interpreters
                });
            })
            .catch((err) => {
                __debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            })
    },

    listInterpreters: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            is_deleted: false
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        // var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                    'first_name': new RegExp(searchText, 'gi')
                },
                {
                    'last_name': new RegExp(searchText, 'gi')
                },
                {
                    'mobile_no': new RegExp(searchText, 'gi')
                },
                {
                    'interpreter_shortid': new RegExp(searchText, 'gi')
                },
                {
                    'userInfo.email': new RegExp(searchText, 'gi')
                },
            ];
        }

        var aggregateQuery = [{
                $lookup: {
                    from: 'users',
                    localField: "user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: {
                    path: "$userInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $match: condition
            }
        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        InterpreterModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                InterpreterModel.aggregate(countQuery).exec(function (err, dataCount) {
                    // console.log("dataCount", dataCount);
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    addInterpreters: function (req, res, next) {
        genId();
        function addData(shortBookingId){
            var form = new formidable.IncomingForm();
            form.parse(req, function (err, fields, files) {
                var interpreter;
                var certificates = {},tmpCertificates={};
                if(fields.interpreter!=undefined && fields.interpreter!=''){
                    try{
                        interpreter = JSON.parse(fields.interpreter);
                    }catch(err){

                    }
                }
                if(typeof interpreter == 'object'){
                    var timestamp = Number(new Date()); // current time as number
                    var fileName='';
                    var fileExt = '';
                    var interpreterCertPath = "./../client/users/assets/uploads/interpreter_certificates/";
                    if(typeof files.court_certified == 'object'){
                        fileExt = files.court_certified.name.split('.');
                        if(fileExt.length>0){
                            fileExt = fileExt[fileExt.length-1];    
                        }else{
                            fileExt = '';
                        }
                        
                        tmpCertificates.court_certified=timestamp+'_'+common.randomToken(6)+"."+fileExt;
                        certificates.court_certified="/assets/uploads/interpreter_certificates/"+tmpCertificates.court_certified;
                        
                        fs_extra.copy(files.court_certified.path, interpreterCertPath + tmpCertificates.court_certified, function(err) {  
                            if (err) {
                            } else {
                            }
                        });

                    }
                    if(typeof files.court_screened == 'object'){
                        fileExt = files.court_screened.name.split('.');
                        if(fileExt.length>0){
                            fileExt = fileExt[fileExt.length-1];    
                        }else{
                            fileExt = '';
                        }
                        tmpCertificates.court_screened=timestamp+'_'+common.randomToken(6)+"."+fileExt;
                        certificates.court_screened="/assets/uploads/interpreter_certificates/"+tmpCertificates.court_screened;
                        

                        fs_extra.copy(files.court_screened.path, interpreterCertPath + tmpCertificates.court_screened, function(err) {  
                            if (err) {
                            } else {
                            }
                        });
                    }

                     function register(_fileName,_certificates) {
                        User.findOne({
                            email: interpreter.email
                        }, function (err, emailData) {
                            if (err) {
                                // console.log("err1",err);
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("ERROR")
                                })
                            } else {
                                if (emailData) {
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("Email Id already exist ! Try with different Email.")
                                    })
                                } else {

                                    RoleModel.findOne({role:req.config.role_type.INTERPRETER.name}).exec(function(err,roleData){
                                        if(err){
                                            // console.log("err2",err);
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: {},
                                                message: i18n.__("ERROR")
                                            })
                                        }else if(roleData){
                                                var user = new User();
                                                user.email = interpreter.email;
                                                user.role_id = roleData._id;
                                                user.activation_key = uuidV4();
                                                user.save()
                                                    .then((userData) => {
                                                        interpreterModel = new InterpreterModel(interpreter);
                                                        interpreterModel.location = {};
                                                        interpreterModel.location.type = "Point";
                                                        interpreterModel.location.coordinates = [];
                                                        interpreterModel.location.coordinates[0] = parseFloat(interpreter.lng);
                                                        interpreterModel.location.coordinates[1] = parseFloat(interpreter.lat);
                                                        interpreterModel.agency_id = req.user.agency_id;
                                                        interpreterModel.user_id = userData._id;
                                                        interpreterModel.interpreter_shortid = shortBookingId
                                                        if (_fileName) {
                                                            interpreterModel.profile_pic = "/assets/uploads/profile/" + _fileName;
                                                        }
                                                        interpreterModel.save()
                                                            .then((interpreterData) => {
                                                                if(interpreter.services != '' && interpreter.services != undefined && interpreter.services != null){
                                                                    console.log("in service1");
                                                                    async.eachSeries(interpreter.services, function(service, next){
                                                                        var interpreterService = new InterpreterServiceModel()
                                                                        interpreterService.agency_id = req.user.agency_id;
                                                                        interpreterService.interpreter_id = interpreterData._id;
                                                                        interpreterService.service_id = service._id;
                                                                        interpreterService.name = service.name; 
                                                                        interpreterService.ticked = service.ticked;
                                                                        interpreterService.save(function(err,servicedata){
                                                                            if(err){
                                                                                res.json({
                                                                                    status: req.config.statusCode.error,
                                                                                    data: req.body,
                                                                                    message: i18n.__("ERROR")
                                                                                })
                                                                            } else{
                                                                                next();
                                                                            } 
                                                                        })     
                                                                    },function(err){
                                                                      if(err){
                                                                        res.json({
                                                                            status: req.config.statusCode.error,
                                                                            data: req.body,
                                                                            message: i18n.__("ERROR")
                                                                        })
                                                                      }else{
                                                                       
                                                                      }
                                                                    })
                                                                }
                                                                    
                                                                if(interpreter.languages != '' && interpreter.languages != undefined && interpreter.languages != null){
                                                                    async.eachSeries(interpreter.languages, function(language, next){
                                                                        var interpreterLanguage = new InterpreterLanguageModel()
                                                                        interpreterLanguage.agency_id = req.user.agency_id;
                                                                        interpreterLanguage.interpreter_id = interpreterData._id;
                                                                        interpreterLanguage.language_id = language.language_id;
                                                                        interpreterLanguage.spoken = language.spoken; 
                                                                        interpreterLanguage.written = language.written;
                                                                        interpreterLanguage.save(function(err,languagedata){
                                                                            if(err){
                                                                                res.json({
                                                                                    status: req.config.statusCode.error,
                                                                                    data: req.body,
                                                                                    message: i18n.__("ERROR")
                                                                                })
                                                                            } else{
                                                                                next();
                                                                            } 
                                                                        })     
                                                                    },function(err){
                                                                        if(err){
                                                                            res.json({
                                                                                status: req.config.statusCode.error,
                                                                                data: req.body,
                                                                                message: i18n.__("ERROR")
                                                                            })
                                                                      }else{

                                                                      }
                                                                    })
                                                                }

                                                                if(Object.keys(_certificates).length>0){
                                                                    var certificate = new InterpreterCertificateModel();
                                                                    certificate.agency_id = req.user.agency_id;
                                                                    certificate.interpreter_id = interpreterData._id;
                                                                    certificate.certificates = _certificates;
                                                                    certificate.save()
                                                                    .then((certificateData) =>{

                                                                    }) 
                                                                }
                                                                if(req.config.env == 'aws'){
                                                                    var baseUrl = 'https://www.interpreting.works';
                                                                }else{
                                                                    var baseUrl = req.config.email.base_url;
                                                                }
                                                                var options = {
                                                                    template: 'set_password.html',
                                                                    from: req.user.email,
                                                                    repalcement: {
                                                                        "{{user.name}}": interpreterData.first_name.charAt(0).toUpperCase()+interpreterData.first_name.slice(1).toLowerCase()+ ' ' +interpreterData.last_name.charAt(0).toUpperCase()+interpreterData.last_name.slice(1).toLowerCase(),
                                                                        "{{user.email}}": userData.email,
                                                                        "{{user.activation_key}}": baseUrl + '/#/setPassword/' + userData.activation_key,
                                                                        "{{logo_url}}": baseUrl + req.config.email.logo_url,
                                                                        "{{copyright}}": req.config.email.copyright,
                                                                        "{{link.abuse_email}}": req.config.email.abuse_email
                                                                    },
                                                                    to: userData.email,
                                                                    subject: 'Complete Registration'
                                                                };
                                                                emailSend.smtp.sendMail(options, function (err, response) {
                                                                    if (err) {
                                                                        //__debug(err)
                                                                        // console.log("err3", err);
                                                                        res.json({
                                                                            status: req.config.statusCode.error,
                                                                            data: {},
                                                                            message: i18n.__("ERROR")
                                                                        })
                                                                    }else{
                                                                        User.findOneAndUpdate({
                                                                            _id: userData._id
                                                                        }, {
                                                                            is_verification_email_send: true
                                                                        }, {
                                                                            new: true
                                                                        }).then((userData) => {

                                                                        })
                                                                    }
                                                                })
                                                                return interpreterData
                                                            }).then((interpreterData) => {
                                                                // var linkTo = req.config.email.base_url+ '/#/setPassword/' + userData.activation_key;
                                                                // var text = "You've registered with this email " + userData.email + "\n to complete your registration click on the provided link below\n" + linkTo + "\n If you didn't request this, you can ignore this email.";
                                                                // var data = { to: '+919990795913', message: text }
                                                                // twilioSms.sendSMS(data, function(returnData) {
                                                                //     console.log('twilio', returnData);
                                                                // });
                                                                res.json({
                                                                    status: req.config.statusCode.success,
                                                                    data: interpreterData,
                                                                    message: i18n.__("Interpreter added succesfully")
                                                                });
                                                            }).catch((err) => {
                                                                // console.log("err4",err);
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: {},
                                                                    message: i18n.__("ERROR")
                                                                })
                                                            });
                                                    }).catch((err) => {
                                                        //__debug(err)
                                                        // console.log("err5", err);
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: {},
                                                            message: i18n.__("ERROR")
                                                        })
                                                    });
                                        }else{
                                            res.json({
                                                status: req.config.statusCode.success,
                                                data: {},
                                                message: i18n.__("No record found")
                                            });
                                        }
                                    })
                                }
                            }
                        })
                    }

                    if (interpreter.imageFile) {
                        fileName = timestamp + '_' + common.randomToken(6) + '.' + 'png';
                        var imagePath = "./../client/users/assets/uploads/profile/" + fileName;
                        var base64Data = interpreter.imageFile.replace(/^data:image\/png;base64,/, "");
                        base64Data += base64Data.replace('+', ' ');
                        binaryData = new Buffer(base64Data, 'base64').toString('binary');
                        fs.writeFile(imagePath, binaryData, "binary", function (err) {
                            if (err) {
                                console.log("error in image upload", err);
                                res.json({
                                    code: 402,
                                    'message': 'Request could not be processed. Please try again.',
                                    data: {}
                                });
                            } else {
                                register(fileName,certificates);
                            }
                        });
                    } else {
                        register(undefined,certificates);
                    }

                }else{
                    res.json({
                        status: req.config.statusCode.badRequest,
                        data: {},
                        message: i18n.__("INVALID_REQUEST")
                    })
                }  
            })
        }

        function genId(){
            var shortBookingId = validator.generateShortId();
            Booking.find({booking_id: shortBookingId}, function(err, bookingData) {
                if(err){
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR")
                    })
                } else if(bookingData.length>0){
                    genId();
                } else{
                    addData(shortBookingId);
                }
            })
        }

    },


    updateInterpreters: function (req, res, next) {
        var form = new formidable.IncomingForm();
        form.parse(req, function (err, fields, files) {
            var interpreter={};
            var certificates = {},tmpCertificates={};
            if(fields.interpreter!=undefined && fields.interpreter!=''){
                try{
                    interpreter = JSON.parse(fields.interpreter);
                    console.log("jkhkjhhkjh",interpreter.certificates);
                }catch(err){

                }
            }
            if(typeof interpreter == 'object'){
                var timestamp = Number(new Date()); // current time as number
                var fileName='';
                var fileExt = '';
                var interpreterCertPath = "./../client/users/assets/uploads/interpreter_certificates/";
                if(typeof files.court_certified == 'object'){
                    fileExt = files.court_certified.name.split('.');
                    if(fileExt.length>0){
                        fileExt = fileExt[fileExt.length-1];    
                    }else{
                        fileExt = '';
                    }
                    
                    tmpCertificates.court_certified=timestamp+'_'+common.randomToken(6)+"."+fileExt;
                    certificates.court_certified="/assets/uploads/interpreter_certificates/"+tmpCertificates.court_certified;
                    
                    fs_extra.copy(files.court_certified.path, interpreterCertPath + tmpCertificates.court_certified, function(err) {  
                        if (err) {
                            console.error(err);
                        } else {
                            console.log("success!")
                        }
                    });

                }
                if(typeof files.court_screened == 'object'){
                    fileExt = files.court_screened.name.split('.');
                    if(fileExt.length>0){
                        fileExt = fileExt[fileExt.length-1];    
                    }else{
                        fileExt = '';
                    }
                    tmpCertificates.court_screened=timestamp+'_'+common.randomToken(6)+"."+fileExt;
                    certificates.court_screened="/assets/uploads/interpreter_certificates/"+tmpCertificates.court_screened;
                    

                    fs_extra.copy(files.court_screened.path, interpreterCertPath + tmpCertificates.court_screened, function(err) {  
                        if (err) {
                            console.error(err);
                        } else {
                            console.log("success!")
                        }
                    });
                }

                 function update(_fileName,_certificates) {
                    User.findOne({
                        email: interpreter.email,
                        _id: {
                            $ne: interpreter.user_id
                        }
                    }, function (err, emailData) {
                        if (err) {
                            console.log("err1",err);
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        } else {
                            if (emailData) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("Email Id already exist ! Try with different Email.")
                                })
                            } else {
                                var updateData = interpreter;
                                updateData.location = {};
                                updateData.location.type = "Point";
                                updateData.location.coordinates = [];
                                updateData.location.coordinates[0] = parseFloat(interpreter.lng);
                                updateData.location.coordinates[1] = parseFloat(interpreter.lat);
                                if (_fileName) {
                                    updateData.profile_pic = "/assets/uploads/profile/" + _fileName;
                                }
                                InterpreterModel.update({
                                    _id: interpreter._id
                                }, {
                                    $set: updateData
                                }, function (err) {
                                    if (err) {
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: req.body,
                                            message: i18n.__("ERROR")
                                        })
                                    } else {
                                        User.update({
                                            _id: interpreter.user_id
                                        }, {
                                            $set: {
                                                email: interpreter.email
                                            }
                                        }, function (err) {
                                            if (err) {
                                                res.json({
                                                    status: req.config.statusCode.error,
                                                    data: req.body,
                                                    message: i18n.__("ERROR")
                                                })
                                            } else {
                                                if(interpreter.services != '' && interpreter.services !=undefined && interpreter.services != null){
                                                    async.eachSeries(interpreter.services,function(data,next){
                                                        var service = {
                                                            agency_id: req.user.agency_id,
                                                            interpreter_id:interpreter._id,
                                                            service_id: data._id,
                                                            name:data.name,
                                                            ticked: data.ticked
                                                        }
                                                        InterpreterServiceModel.update({
                                                            agency_id:req.user.agency_id,
                                                            interpreter_id:interpreter._id,
                                                            service_id: data._id
                                                        },{
                                                            $set: service
                                                        },{
                                                            upsert: true
                                                        },function(err, interpreterServiceData){
                                                            if(err){
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: req.body,
                                                                    message: i18n.__("ERROR")
                                                                })
                                                            } else{
                                                                next();
                                                            }
                                                        })
                                                    }),function(err){
                                                        if(err){
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: req.body,
                                                                message: i18n.__("ERROR")
                                                            })
                                                        }else{
                                                            
                                                        }
                                                    }
                                                }

                                                if(interpreter.languages != '' && interpreter.languages !=undefined && interpreter.languages != null){
                                                    async.eachSeries(interpreter.languages,function(data,next){
                                                        var deleted = data.is_deleted ? data.is_deleted : false;
                                                        var language = {
                                                            agency_id: req.user.agency_id,
                                                            interpreter_id:interpreter._id,
                                                            language_id: data.language_id,
                                                            spoken: data.spoken,
                                                            written: data.written,
                                                            is_deleted: deleted  
                                                        }
                                                        InterpreterLanguageModel.update({
                                                            agency_id:req.user.agency_id,
                                                            interpreter_id:interpreter._id,
                                                            language_id: data.language_id
                                                        },{
                                                            $set: language
                                                        },{
                                                            upsert: true
                                                        },function(err, interpreterLanguageData){
                                                            if(err){
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: req.body,
                                                                    message: i18n.__("ERROR")
                                                                })
                                                            } else{
                                                                next();
                                                            }
                                                        })
                                                    }),function(err){
                                                        if(err){
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: req.body,
                                                                message: i18n.__("ERROR")
                                                            })
                                                        }else{
                                                            
                                                        }
                                                    }
                                                }

                                                if(_certificates.court_screened==undefined){
                                                    if(interpreter.certificates!=undefined && interpreter.certificates.court_screened!=undefined && interpreter.certificates.court_screened!=''){
                                                        _certificates.court_screened = interpreter.certificates.court_screened;
                                                    }
                                                }
                                                if(_certificates.court_certified==undefined){
                                                    if(interpreter.certificates!=undefined && interpreter.certificates.court_certified!=undefined && interpreter.certificates.court_certified!=''){
                                                        _certificates.court_certified = interpreter.certificates.court_certified;
                                                    }
                                                }
                                                if(Object.keys(_certificates).length>0){
                                                    InterpreterCertificateModel.findOne({
                                                    interpreter_id: interpreter._id
                                                    }).then((certificateData) => {
                                                        if(!certificateData){

                                                            var certificate = new InterpreterCertificateModel(); 
                                                            certificate.certificates = _certificates;
                                                            certificate.interpreter_id = interpreter._id;
                                                            certificate.save()
                                                            .then((certificateSaved) => {

                                                            })
                                                        }else{
                                                            certificateData.certificates = _certificates;
                                                            certificateData.save()
                                                            .then((savedData) =>{

                                                            })
                                                        }

                                                    })
                                                }else{
                                                    InterpreterCertificateModel.find({ interpreter_id:interpreter._id }).remove().exec();
                                                }
                                                
                                                res.json({
                                                    status: req.config.statusCode.success,
                                                    data: req.body,
                                                    message: i18n.__("Interpreter updated succesfully")
                                                });
                                            }
                                        })

                                    }
                                })
                            }
                        }
                    })
                }

                if (interpreter.imageFile) {
                    fileName = timestamp + '_' + common.randomToken(6) + '.' + 'png';
                    var imagePath = "./../client/users/assets/uploads/profile/" + fileName;
                    var base64Data = interpreter.imageFile.replace(/^data:image\/png;base64,/, "");
                    base64Data += base64Data.replace('+', ' ');
                    binaryData = new Buffer(base64Data, 'base64').toString('binary');
                    fs.writeFile(imagePath, binaryData, "binary", function (err) {
                        if (err) {
                            res.json({
                                code: 402,
                                'message': 'Request could not be processed. Please try again.',
                                data: {}
                            });
                        } else {
                            update(fileName,certificates);
                        }
                    });
                } else {
                    update(undefined,certificates);
                }

            }else{
                res.json({
                    status: req.config.statusCode.badRequest,
                    data: {},
                    message: i18n.__("INVALID_REQUEST")
                })
            }  
        })

    },

    updateInterpreterProfile: function (req, res, next) {
        var form = new formidable.IncomingForm();
        form.parse(req, function (err, fields, files) {
            var interpreter={};
            var certificates = {},tmpCertificates={};
            if(fields.interpreter!=undefined && fields.interpreter!=''){
                try{
                    interpreter = JSON.parse(fields.interpreter);
                }catch(err){

                }
            }
            if(typeof interpreter == 'object'){
                var timestamp = Number(new Date()); // current time as number
                var fileName='';
                var fileExt = '';
                var interpreterCertPath = "./../client/users/assets/uploads/interpreter_certificates/";
                if(typeof files.court_certified == 'object'){
                    fileExt = files.court_certified.name.split('.');
                    if(fileExt.length>0){
                        fileExt = fileExt[fileExt.length-1];    
                    }else{
                        fileExt = '';
                    }
                    
                    tmpCertificates.court_certified=timestamp+'_'+common.randomToken(6)+"."+fileExt;
                    certificates.court_certified="/assets/uploads/interpreter_certificates/"+tmpCertificates.court_certified;
                    
                    fs_extra.copy(files.court_certified.path, interpreterCertPath + tmpCertificates.court_certified, function(err) {  
                        if (err) {
                            console.error(err);
                        } else {
                            console.log("success!")
                        }
                    });

                }
                if(typeof files.court_screened == 'object'){
                    fileExt = files.court_screened.name.split('.');
                    if(fileExt.length>0){
                        fileExt = fileExt[fileExt.length-1];    
                    }else{
                        fileExt = '';
                    }
                    tmpCertificates.court_screened=timestamp+'_'+common.randomToken(6)+"."+fileExt;
                    certificates.court_screened="/assets/uploads/interpreter_certificates/"+tmpCertificates.court_screened;
                    

                    fs_extra.copy(files.court_screened.path, interpreterCertPath + tmpCertificates.court_screened, function(err) {  
                        if (err) {
                            console.error(err);
                        } else {
                            console.log("success!")
                        }
                    });
                }

                 function update(_fileName,_certificates) {
                    User.findOne({
                        email: interpreter.email,
                        _id: {
                            $ne: interpreter.user_id
                        }
                    }, function (err, emailData) {
                        if (err) {
                            console.log("err1",err);
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        } else {
                            if (emailData) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("Email Id already exist ! Try with different Email.")
                                })
                            } else {
                                var updateData = interpreter;
                                if (_fileName) {
                                    updateData.profile_pic = "/assets/uploads/profile/" + _fileName;
                                }
                                InterpreterModel.update({
                                    _id: interpreter._id
                                }, {
                                    $set: updateData
                                }, function (err) {
                                    if (err) {
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: req.body,
                                            message: i18n.__("ERROR")
                                        })
                                    } else {
                                        User.update({
                                            _id: interpreter.user_id
                                        }, {
                                            $set: {
                                                email: interpreter.email
                                            }
                                        }, function (err) {
                                            if (err) {
                                                res.json({
                                                    status: req.config.statusCode.error,
                                                    data: req.body,
                                                    message: i18n.__("ERROR")
                                                })
                                            } else {
                                                if(interpreter.services != '' && interpreter.services !=undefined && interpreter.services != null){
                                                    async.eachSeries(interpreter.services,function(data,next){
                                                        var service = {
                                                            agency_id: req.user.agency_id,
                                                            interpreter_id:interpreter._id,
                                                            service_id: data._id,
                                                            name:data.name,
                                                            ticked: data.ticked
                                                        }
                                                        InterpreterServiceModel.update({
                                                            agency_id:req.user.agency_id,
                                                            interpreter_id:interpreter._id,
                                                            service_id: data._id
                                                        },{
                                                            $set: service
                                                        },{
                                                            upsert: true
                                                        },function(err, interpreterServiceData){
                                                            if(err){
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: req.body,
                                                                    message: i18n.__("ERROR")
                                                                })
                                                            } else{
                                                                next();
                                                            }
                                                        })
                                                    }),function(err){
                                                        if(err){
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: req.body,
                                                                message: i18n.__("ERROR")
                                                            })
                                                        }else{
                                                            
                                                        }
                                                    }
                                                }

                                                if(interpreter.languages != '' && interpreter.languages !=undefined && interpreter.languages != null){
                                                    async.eachSeries(interpreter.languages,function(data,next){
                                                        var deleted = data.is_deleted ? data.is_deleted : false;
                                                        var language = {
                                                            agency_id: req.user.agency_id,
                                                            interpreter_id:interpreter._id,
                                                            language_id: data.language_id,
                                                            spoken: data.spoken,
                                                            written: data.written,
                                                            is_deleted: deleted  
                                                        }
                                                        InterpreterLanguageModel.update({
                                                            agency_id:req.user.agency_id,
                                                            interpreter_id:interpreter._id,
                                                            language_id: data.language_id
                                                        },{
                                                            $set: language
                                                        },{
                                                            upsert: true
                                                        },function(err, interpreterLanguageData){
                                                            if(err){
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: req.body,
                                                                    message: i18n.__("ERROR")
                                                                })
                                                            } else{
                                                                next();
                                                            }
                                                        })
                                                    }),function(err){
                                                        if(err){
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: req.body,
                                                                message: i18n.__("ERROR")
                                                            })
                                                        }else{
                                                            
                                                        }
                                                    }
                                                }

                                                if(_certificates.court_screened==undefined){
                                                    if(interpreter.certificates!=undefined && interpreter.certificates.court_screened!=undefined && interpreter.certificates.court_screened!=''){
                                                        _certificates.court_screened = interpreter.certificates.court_screened;
                                                    }
                                                }
                                                if(_certificates.court_certified==undefined){
                                                    if(interpreter.certificates!=undefined && interpreter.certificates.court_certified!=undefined && interpreter.certificates.court_certified!=''){
                                                        _certificates.court_certified = interpreter.certificates.court_certified;
                                                    }
                                                }
                                                if(Object.keys(_certificates).length>0){
                                                    InterpreterCertificateModel.findOne({
                                                    interpreter_id: interpreter._id
                                                    }).then((certificateData) => {
                                                        if(!certificateData){
                                                            var certificate = new InterpreterCertificateModel(); 
                                                            certificate.certificates = _certificates;
                                                            certificate.interpreter_id = interpreter._id;
                                                            certificate.save()
                                                            .then((certificateSaved) => {

                                                            })
                                                        }else{
                                                            certificateData.certificates = _certificates;
                                                            certificateData.save()
                                                            .then((savedData) =>{

                                                            })
                                                        }

                                                    })
                                                }else{
                                                    InterpreterCertificateModel.find({ interpreter_id:interpreter._id }).remove().exec();
                                                }
                                                
                                                res.json({
                                                    status: req.config.statusCode.success,
                                                    data: req.body,
                                                    message: i18n.__("Interpreter updated succesfully")
                                                });
                                            }
                                        })

                                    }
                                })
                            }
                        }
                    })
                }

                if (interpreter.imageFile) {
                    fileName = timestamp + '_' + common.randomToken(6) + '.' + 'png';
                    var imagePath = "./../client/users/assets/uploads/profile/" + fileName;
                    var base64Data = interpreter.imageFile.replace(/^data:image\/png;base64,/, "");
                    base64Data += base64Data.replace('+', ' ');
                    binaryData = new Buffer(base64Data, 'base64').toString('binary');
                    fs.writeFile(imagePath, binaryData, "binary", function (err) {
                        if (err) {
                            res.json({
                                code: 402,
                                'message': 'Request could not be processed. Please try again.',
                                data: {}
                            });
                        } else {
                            update(fileName,certificates);
                        }
                    });
                } else {
                    update(undefined,certificates);
                }

            }else{
                res.json({
                    status: req.config.statusCode.badRequest,
                    data: {},
                    message: i18n.__("INVALID_REQUEST")
                })
            }  
        })

    },

    deleteInterpreter: function (req, res, next) {
        InterpreterModel.findOneAndUpdate({
                _id: req.params.id,
                agency_id: req.user.agency_id
            }, {
                is_deleted: true
            }, {
                new: true
            })
            .then((result) => {
                User.findOneAndUpdate({
                    _id: result.user_id
                }, {
                    is_deleted: true
                }, {
                    new: true
                }).then((userDetails) => {
                    res.json({
                        status: req.config.statusCode.success,
                        data: result,
                        message: i18n.__("Interpreter deleted succesfully")
                    });
                }).catch((err) => {
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR")
                    })
                });
            })
    },

    getInterpretersById: function (req, res, next) {
        var condition = {
            _id: mongoose.Types.ObjectId(req.params.id),
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            is_deleted: false
        }

        var aggregateQuery = [
            {
            $lookup: {
                    from: 'users',
                    localField: "user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            { $unwind: "$userInfo"},
            {
                $match: condition
            },{
                $lookup: {
                    from: 'interpreter_languages',
                    localField: "_id",
                    foreignField: "interpreter_id",
                    as: "interpreterLanguageInfo"
                }
            },{
                $lookup: {
                    from: 'interpreter_services',
                    localField: "_id",
                    foreignField: "interpreter_id",
                    as: "interpreterServiceInfo"
                }
            },{
                $lookup: {
                    from: 'interpreter_certificates',
                    localField: "_id",
                    foreignField: "interpreter_id",
                    as: "interpreterCertificateInfo"
                }
            },{ $unwind: {
                    path: "$interpreterCertificateInfo",
                    preserveNullAndEmptyArrays: true
                }
            },{    
                $project: {
                    first_name:1,
                    last_name:1,
                    profile_pic:1,
                    client_shortid:1,
                    mobile_no:1,
                    alternate_no: 1,
                    user_id: 1,
                    gender: 1,
                    city:1,
                    state:1,
                    zip:1,
                    address1:1,
                    address2:1,
                    country_id: 1,
                    working_from: 1,
                    working_to: 1,
                    working_status: 1,
                    working_days: 1,
                    notes: 1,
                    certificate: 1,
                    email: "$userInfo.email",
                    certificates : "$interpreterCertificateInfo",
                    languages: {
                        $filter: {
                            input: "$interpreterLanguageInfo",        
                            as: "item",        
                            cond: {          
                                $and: [
                                    {              
                                        $eq: ["$$item.is_deleted", false]            
                                    },            
                                    {              
                                        $eq: ["$$item.interpreter_id", mongoose.Types.ObjectId(req.params.id)]            
                                    },
                                    {              
                                        $eq: ["$$item.agency_id", mongoose.Types.ObjectId(req.user.agency_id)]            
                                    },                  
                                ]
                            }
                        }
                    },
                    services: {
                        $filter: {
                            input: "$interpreterServiceInfo",        
                            as: "item",        
                            cond: {          
                                $and: [
                                    {              
                                        $eq: ["$$item.ticked", true]            
                                    },            
                                    {              
                                        $eq: ["$$item.interpreter_id", mongoose.Types.ObjectId(req.params.id)]            
                                    },
                                    {              
                                        $eq: ["$$item.agency_id", mongoose.Types.ObjectId(req.user.agency_id)]            
                                    },                  
                                ]
                            }
                        }
                    }
                }
            }
            
        ];
         InterpreterModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                console.log("error", err);
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            } else {
                if(result[0].certificates !='' && result[0].certificates !=null && result[0].certificates !=undefined){
                    result[0].certificates = result[0].certificates.certificates;
                }else{
                    result[0].certificates = {};
                }
                res.json({
                    status: req.config.statusCode.success,
                    data: result[0],
                    message: i18n.__("INTERPRETER_GET_SUCCESSFULLY")
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    getInterpreterViewById: function (req, res, next) {
        var condition = {
            _id: mongoose.Types.ObjectId(req.params.id),
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            is_deleted: false
        }

        var aggregateQuery = [
            {
            $lookup: {
                    from: 'users',
                    localField: "user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            { $unwind: "$userInfo"},
            {
                $match: condition
            },{
                $lookup: {
                    from: 'interpreter_languages',
                    localField: "_id",
                    foreignField: "interpreter_id",
                    as: "interpreterLanguageInfo"
                }
            },{
                $lookup: {
                    from: 'interpreter_services',
                    localField: "_id",
                    foreignField: "interpreter_id",
                    as: "interpreterServiceInfo"
                }
            },{
                $lookup: {
                    from: 'interpreter_certificates',
                    localField: "_id",
                    foreignField: "interpreter_id",
                    as: "interpreterCertificateInfo"
                }
            },{ $unwind: {
                    path: "$interpreterCertificateInfo",
                    preserveNullAndEmptyArrays: true
                }
            },{    
                $project: {
                    first_name:1,
                    last_name:1,
                    profile_pic:1,
                    client_shortid:1,
                    mobile_no:1,
                    alternate_no: 1,
                    user_id: 1,
                    gender: 1,
                    city:1,
                    state:1,
                    zip:1,
                    address1:1,
                    address2:1,
                    country_id: 1,
                    working_from: 1,
                    working_to: 1,
                    working_status: 1,
                    working_days: 1,
                    notes: 1,
                    certificate: 1,
                    email: "$userInfo.email",
                    certificates : "$interpreterCertificateInfo",
                    languages: {
                        $filter: {
                            input: "$interpreterLanguageInfo",        
                            as: "item",        
                            cond: {          
                                $and: [
                                    {              
                                        $eq: ["$$item.is_deleted", false]            
                                    },            
                                    {              
                                        $eq: ["$$item.interpreter_id", mongoose.Types.ObjectId(req.params.id)]            
                                    },
                                    {              
                                        $eq: ["$$item.agency_id", mongoose.Types.ObjectId(req.user.agency_id)]            
                                    },                  
                                ]
                            }
                        }
                    },
                    services: {
                        $filter: {
                            input: "$interpreterServiceInfo",        
                            as: "item",        
                            cond: {          
                                $and: [
                                    {              
                                        $eq: ["$$item.ticked", true]            
                                    },            
                                    {              
                                        $eq: ["$$item.interpreter_id", mongoose.Types.ObjectId(req.params.id)]            
                                    },
                                    {              
                                        $eq: ["$$item.agency_id", mongoose.Types.ObjectId(req.user.agency_id)]            
                                    },                  
                                ]
                            }
                        }
                    }
                }
            }
            
        ];
         InterpreterModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                console.log("error", err);
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            } else {
                if(result[0].certificates !='' && result[0].certificates !=null && result[0].certificates !=undefined){
                    result[0].certificates = result[0].certificates.certificates;
                }else{
                    result[0].certificates = {};
                }
                LanguageModel.populate(result[0], {path: 'languages.language_id', select: {'language_name':1}}, function(err, populatedLanguagesName) {
                    result[0] = populatedLanguagesName;
                    res.json({
                        status: req.config.statusCode.success,
                        data: result[0],
                        message: i18n.__("INTERPRETER_GET_SUCCESSFULLY")
                    });
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    //function is used to change interpreter status
    changeInterpreterStatus: function (req, res, next) {
        InterpreterModel.findOneAndUpdate({
                _id: req.body.id,
                agency_id: req.user.agency_id
            }, {
                status: req.body.status
            }, {
                new: true
            })
            .then((result) => {
                User.findOneAndUpdate({
                    _id: result.user_id
                }, {
                    status: req.body.status
                }, {
                    new: true
                }).then((userDetails) => {
                    res.json({
                        status: req.config.statusCode.success,
                        data: result,
                        message: i18n.__('Interpreter ' + ((req.body.status == true) ? 'activated' : 'deactivated') + ' successfully')
                    });
                }).catch((err) => {
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR")
                    })

                });

            })
    },

    getInterpreterProfileDetailById: function (req, res, next) {
        var condition = {
            _id: mongoose.Types.ObjectId(req.user.interpreter_id),
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            is_deleted: false
        }

        var aggregateQuery = [
            {
            $lookup: {
                    from: 'users',
                    localField: "user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            { $unwind: "$userInfo"},
            {
                $match: condition
            },{
                $lookup: {
                    from: 'interpreter_languages',
                    localField: "_id",
                    foreignField: "interpreter_id",
                    as: "interpreterLanguageInfo"
                }
            },{
                $lookup: {
                    from: 'interpreter_services',
                    localField: "_id",
                    foreignField: "interpreter_id",
                    as: "interpreterServiceInfo"
                }
            },{
                $lookup: {
                    from: 'interpreter_certificates',
                    localField: "_id",
                    foreignField: "interpreter_id",
                    as: "interpreterCertificateInfo"
                }
            },{ $unwind: {
                    path: "$interpreterCertificateInfo",
                    preserveNullAndEmptyArrays: true
                }
            },{    
                $project: {
                    first_name:1,
                    last_name:1,
                    profile_pic:1,
                    client_shortid:1,
                    mobile_no:1,
                    alternate_no: 1,
                    user_id: 1,
                    gender: 1,
                    city:1,
                    state:1,
                    zip:1,
                    address1:1,
                    address2:1,
                    country_id: 1,
                    working_from: 1,
                    working_to: 1,
                    working_status: 1,
                    working_days: 1,
                    agency_id: 1,
                    notes: 1,
                    certificate: 1,
                    email: "$userInfo.email",
                    certificates: "$interpreterCertificateInfo",
                    languages: {
                        $filter: {
                            input: "$interpreterLanguageInfo",        
                            as: "item",        
                            cond: {          
                                $and: [
                                    {              
                                        $eq: ["$$item.is_deleted", false]            
                                    },            
                                    {              
                                        $eq: ["$$item.interpreter_id", mongoose.Types.ObjectId(req.user.interpreter_id)]            
                                    },
                                    {              
                                        $eq: ["$$item.agency_id", mongoose.Types.ObjectId(req.user.agency_id)]            
                                    },                  
                                ]
                            }
                        }
                    },
                    services: {
                        $filter: {
                            input: "$interpreterServiceInfo",        
                            as: "item",        
                            cond: {          
                                $and: [
                                    {              
                                        $eq: ["$$item.ticked", true]            
                                    },            
                                    {              
                                        $eq: ["$$item.interpreter_id", mongoose.Types.ObjectId(req.user.interpreter_id)]            
                                    },
                                    {              
                                        $eq: ["$$item.agency_id", mongoose.Types.ObjectId(req.user.agency_id)]            
                                    },                  
                                ]
                            }
                        }
                    }
                }
            }
            
        ];
         InterpreterModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                console.log("error", err);
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            } else {
                if(result[0].certificates !='' && result[0].certificates !=null && result[0].certificates !=undefined){
                    result[0].certificates = result[0].certificates.certificates;
                }else{
                    result[0].certificates = {};
                }
                AgencyModel.populate(result[0], {path: 'agency_id', select: {'agency_name': 1, 'profile_pic': 1, 'mobile_no': 1}}, function(err, populatedAgencyDetail) {
                    result[0] = populatedAgencyDetail;
                    res.json({
                        status: req.config.statusCode.success,
                        data: result[0],
                        message: i18n.__("INTERPRETER_GET_SUCCESSFULLY")
                    });
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },
    
    getInterpreterDetailForCalendar: function (req, res, next) {
        var finalResponse = {};
        finalResponse.workingDay = [];
        finalResponse.dateArray = [];
        finalResponse.interpreterSchedule = [];
        waterfall([
            function(callback) {
                var currentDate = moment(req.body.startDate);
                var stopDate = moment(req.body.endDate);
                while (currentDate <= stopDate) {
                    finalResponse.dateArray.push(moment(currentDate).format('YYYY-MM-DD'))
                    currentDate = moment(currentDate).add(1, 'days');
                }
                callback(null, finalResponse);
            },
            function(finalResponse,callback){
                InterpreterModel.findOne({ _id: req.user.interpreter_id }, 'working_days').lean().exec(function(err, data) {
                    if (err) {
                        callback(err, null);
                    } else {
                        if (!data) {
                            callback(null, finalResponse);
                        } else {
                            finalResponse.workingDay.push(data.working_days);
                            callback(null, finalResponse);
                        }
                    }
                });
               
            },
            function(finalResponse,callback){
                InterpreterUnavailableModel.find({ interpreter_id: req.user.interpreter_id, leave_status: true }).lean().exec(function(err, interpreterUnavailableData) {
                    if (err) {
                        callback(err, null);
                    }else{
                        if (!interpreterUnavailableData) {
                            callback(null, finalResponse);
                        } else {
                            finalResponse.interpreterUnavailableData = interpreterUnavailableData;
                            callback(null, finalResponse);
                        }
                    }
                })        
               
            },
            function(finalResponse, callback) {
                var count = 0;
                var values = [];
                for(var key in finalResponse.workingDay[0]) {
                    var value = finalResponse.workingDay[0][key];
                    values.push(value);
                }
                async.each(finalResponse.dateArray, function(date, cb) {
                    var startDate = moment(date);
                    var endDate = moment(date);
                    var lowerCaseDayName = moment(date).format('dddd').toLowerCase();
                    if (finalResponse.workingDay[0][lowerCaseDayName] == true) {
                        var obj = { status: finalResponse.workingDay[0][lowerCaseDayName], startDate: startDate, endDate: endDate };
                        for (var i = 0; i <finalResponse.interpreterUnavailableData.length; i++) {                            
                            if (date == moment(finalResponse.interpreterUnavailableData[i].leave_date).format('YYYY-MM-DD')) {
                                obj = {status:false, leave_status: finalResponse.interpreterUnavailableData[i].leave_status, startDate: startDate, endDate: endDate, id:finalResponse.interpreterUnavailableData[i]._id };
                            }
                        }
                        finalResponse.interpreterSchedule.push(obj);
                        cb();
                    } else {
                        finalResponse.interpreterSchedule.push({ status: finalResponse.workingDay[0][lowerCaseDayName], startDate: startDate, endDate: endDate })
                        cb();
                    }
                },function(err) {
                    if (err) {
                        callback(err, false);
                    } else {

                        callback(null, finalResponse);
                    }
            })

            }
        ], function(err, data) {
        if (err) {
            res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            } else {
                res.json({
                    status: req.config.statusCode.success,
                    data: data.interpreterSchedule,
                    message: i18n.__("Get interpreter data succesfully")
                });
            }
        });
    },

    bulkUploadInterpreter: function (req, res, next) {
        req.setTimeout(0);
        var form = new formidable.IncomingForm();
        form.parse(req, function (err, fields, files) {
            if (typeof files.file != 'undefined') {
                var fileExt = files.file.name.split('.');
                if(fileExt.length>0){
                    fileExt = fileExt[fileExt.length-1];
                }else{
                    fileExt="";
                }
                if (fileExt == 'csv') {
                    var csvData = [];
                    var count = 1;
                    var isDocumentValid = true, documentInvalidErr="";
                    var stream = fs.createReadStream(files.file.path);
                    csv
                    .fromStream(stream,{headers :true})    
                    .validate(function(data, next){
                        if(isDocumentValid){
                            count++;
                            if(Object.keys(data).length != 30 || data.first_name==undefined || data.last_name==undefined 
                            || data.mobile_no==undefined || data.gender==undefined || data.email==undefined || data.alternate_no==undefined
                            || data.address1==undefined || data.address2==undefined || data.city==undefined || data.state==undefined 
                            || data.zip==undefined || data.country==undefined || data.language1==undefined || data.written1==undefined
                            || data.spoken1==undefined || data.language2==undefined || data.written2==undefined
                            || data.spoken2==undefined || data.language3==undefined || data.written3==undefined
                            || data.spoken3==undefined || data.language4==undefined || data.written4==undefined
                            || data.spoken4==undefined || data.language5==undefined || data.written5==undefined
                            || data.spoken5==undefined || data.language6==undefined || data.written6==undefined
                            || data.spoken6==undefined){
                                res.json({
                                    status: req.config.statusCode.badRequest,
                                    data: {},
                                    message: i18n.__("INVALID_HEADER")
                                })
                            }else if(!validator.isValidName(data.first_name)){
                                isDocumentValid = false;
                                if(validator.isEmpty(data.first_name)){
                                    documentInvalidErr = "EMPTY_FIRST_NAME";
                                    next();
                                }else{
                                    documentInvalidErr = "INVALID_FIRST_NAME";
                                    next();
                                }
                            }else if(!validator.isValidName(data.last_name)){
                                isDocumentValid = false;
                                if(validator.isEmpty(data.last_name)){
                                    documentInvalidErr = "EMPTY_LAST_NAME";
                                    next();
                                }else{
                                    documentInvalidErr = "INVALID_LAST_NAME";
                                    next();
                                }
                            }else if(!validator.isMobileNumber(data.mobile_no)){
                                isDocumentValid = false;
                                if(validator.isEmpty(data.mobile_no)){
                                    documentInvalidErr = "EMPTY_MOBILE_NUMBER";
                                    next();
                                }else{
                                    documentInvalidErr = "INVALID_MOBILE_NUMBER";
                                    next();
                                }
                            }else if(!validator.isAddress(data.address1)){
                                isDocumentValid = false;
                                if(validator.isEmpty(data.address1)){
                                    documentInvalidErr = "EMPTY_ADDRESS_1";
                                    next();
                                }else{
                                    documentInvalidErr = "INVALID_ADDRESS_1";
                                    next();
                                }
                            }else if(!validator.isAddress(data.city)){
                                isDocumentValid = false;
                                if(validator.isEmpty(data.city)){
                                    documentInvalidErr = "EMPTY_CITY_NAME";
                                    next();
                                }else{
                                    documentInvalidErr = "INVALID_CITY_NAME";
                                    next();
                                }
                            }else if(!validator.isAddress(data.state)){
                                isDocumentValid = false;
                                if(validator.isEmpty(data.state)){
                                    documentInvalidErr = "EMPTY_STATE_NAME";
                                    next();
                                }else{
                                    documentInvalidErr = "INVALID_STATE_NAME";
                                    next();
                                }
                            }else if(!validator.isZipCode(data.zip)){
                                isDocumentValid = false;
                                if(validator.isEmpty(data.zip)){
                                    documentInvalidErr = "EMPTY_ZIP_CODE";
                                    next();
                                }else{
                                    documentInvalidErr = "INVALID_ZIP_CODE";
                                    next();
                                }
                            }else if(!validator.isEmail(data.email)){
                                isDocumentValid = false;
                                if(validator.isEmpty(data.email)){
                                    documentInvalidErr = "EMPTY_EMAIL";
                                    next();
                                }else{
                                    documentInvalidErr = "INVALID_EMAIL";
                                    next();
                                }
                            }else if(!validator.isAddress(data.country)){
                                isDocumentValid = false;
                                if(validator.isEmpty(data.country)){
                                    documentInvalidErr = "EMPTY_COUNTRY";
                                    next();
                                }else{
                                    documentInvalidErr = "INVALID_COUNTRY";
                                    next();
                                }
                            }else if(!validator.isValidName(data.language1)){
                                isDocumentValid = false;data.language3
                                if(validator.isEmpty(data.language1)){
                                    documentInvalidErr = "EMPTY_LANGUAGE1";
                                    next();
                                }else{
                                    documentInvalidErr = "INVALID_LANGUAGE1";
                                    next();
                                }
                            }else if(!validator.isSpokenWritten(data.spoken1)){
                                isDocumentValid = false;
                                if(validator.isEmpty(data.spoken1)){
                                    documentInvalidErr = "EMPTY_SPOKEN1";
                                    next();
                                }else{
                                    documentInvalidErr = "INVALID_SPOKEN1";
                                    next();
                                }
                            }else if(!validator.isSpokenWritten(data.written1)){
                                isDocumentValid = false;
                                if(validator.isEmpty(data.written1)){
                                    documentInvalidErr = "EMPTY_WRITTEN1";
                                    next();
                                }else{
                                    documentInvalidErr = "INVALID_WRITTEN1";
                                    next();
                                }
                            }else if(!validator.isEmpty(data.email)){
                                User.findOne({email:data.email.toLowerCase()}, function(err, userData){
                                    if(err){
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: {},
                                            message: i18n.__("ERROR")
                                        })
                                    }else if(userData){
                                        isDocumentValid = false;
                                        documentInvalidErr = "EMAIL_ALREADY_EXIST";
                                        next();
                                    }else{
                                        if(!validator.isEmpty(data.country)){
                                            CountryModel.findOne({country_name: data.country}, function(err, countryData){
                                                if(err){
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: {},
                                                        message: i18n.__("ERROR")
                                                    })
                                                }else if(countryData){
                                                    var address = data.address1+' '+data.city+' '+ data.state+' '+data.zip;
                                                    var geocoder = NodeGeocoder(options);
                                                    geocoder.geocode(address, function(err, geoDetails) {
                                                        if(err){
                                                            isDocumentValid = false;
                                                            documentInvalidErr = "ERROR";
                                                            next();
                                                        }else if(geoDetails.length>0){
                                                            data.geoDetails = geoDetails;
                                                            console.log("data.language1",data.language1.toLowerCase());
                                                            LanguageModel.findOne({language_name: data.language1.toLowerCase().trim()}, function(err, languageData1){
                                                                if(err){
                                                                    isDocumentValid = false;
                                                                    documentInvalidErr = "ERROR";
                                                                    next();
                                                                }else if(languageData1){
                                                                    if(validator.isEmpty(data.language2)){
                                                                        if(!validator.isEmpty(data.spoken2)){
                                                                            isDocumentValid = false;
                                                                            documentInvalidErr = "SPOKEN2_HAVE_NOT_LANGUAGE2";
                                                                            next();
                                                                        }else if(!validator.isEmpty(data.written2)){
                                                                            isDocumentValid = false;
                                                                            documentInvalidErr = "WRITTEN2_HAVE_NOT_LANGUAGE2";
                                                                            next();
                                                                        }else if(!validator.isEmpty(data.language3) || !validator.isEmpty(data.spoken3) || !validator.isEmpty(data.written3)
                                                                            ||!validator.isEmpty(data.language4) || !validator.isEmpty(data.spoken4) || !validator.isEmpty(data.written4)
                                                                            || !validator.isEmpty(data.language5) || !validator.isEmpty(data.spoken5) || !validator.isEmpty(data.written5) 
                                                                            || !validator.isEmpty(data.language6) || !validator.isEmpty(data.spoken6) || !validator.isEmpty(data.written6)){
                                                                            isDocumentValid = false;
                                                                            documentInvalidErr = "EMPTY_LANGUAGE2_ERROR";
                                                                            next();                                                                                    
                                                                        }else{
                                                                            validateProperLanguage2();
                                                                        }    
                                                                    }else if(!validator.isValidName(data.language2)){
                                                                        isDocumentValid = false;
                                                                        documentInvalidErr = "INVALID_LANGUAGE2";
                                                                        next();  
                                                                    }else if(!validator.isEmpty(data.language2)){
                                                                        if(!validator.isSpokenWritten(data.spoken2)){
                                                                            isDocumentValid = false;
                                                                            if(validator.isEmpty(data.spoken2)){
                                                                                documentInvalidErr = "EMPTY_SPOKEN2";
                                                                                next();
                                                                            }else{
                                                                                documentInvalidErr = "INVALID_SPOKEN2";
                                                                                next();
                                                                            }
                                                                        }else if(!validator.isSpokenWritten(data.written2)){
                                                                            isDocumentValid = false;
                                                                            if(validator.isEmpty(data.written2)){
                                                                                documentInvalidErr = "EMPTY_WRITTEN2";
                                                                                next();
                                                                            }else{
                                                                                documentInvalidErr = "INVALID_WRITTEN2";
                                                                                next();
                                                                            }
                                                                        }else{
                                                                            validateProperLanguage2();
                                                                        }
                                                                    }

                                                                    function validateProperLanguage2(){
                                                                        if(!validator.isEmpty(data.language2)){
                                                                            console.log("data.language2",data.language2.toLowerCase());
                                                                            LanguageModel.findOne({language_name: data.language2.toLowerCase().trim()}, function(err, languageData2){
                                                                                if(err){
                                                                                    isDocumentValid = false;
                                                                                    documentInvalidErr = "ERROR";
                                                                                    next();
                                                                                }else if(languageData2){
                                                                                    if(validator.isEmpty(data.language3)){
                                                                                        if(!validator.isEmpty(data.spoken3)){
                                                                                            isDocumentValid = false;
                                                                                            documentInvalidErr = "SPOKEN3_HAVE_NOT_LANGUAGE3";
                                                                                            next();
                                                                                        }else if(!validator.isEmpty(data.written3)){
                                                                                            isDocumentValid = false;
                                                                                            documentInvalidErr = "WRITTEN3_HAVE_NOT_LANGUAGE3";
                                                                                            next();
                                                                                        }else if(!validator.isEmpty(data.language4) || !validator.isEmpty(data.spoken4) || !validator.isEmpty(data.written4)
                                                                                            || !validator.isEmpty(data.language5) || !validator.isEmpty(data.spoken5) || !validator.isEmpty(data.written5) 
                                                                                            || !validator.isEmpty(data.language6) || !validator.isEmpty(data.spoken6) || !validator.isEmpty(data.written6)){
                                                                                            isDocumentValid = false;
                                                                                            documentInvalidErr = "EMPTY_LANGUAGE3_ERROR";
                                                                                            next();                                                                                    
                                                                                        }else{
                                                                                            validateProper();
                                                                                        }    
                                                                                    }else if(!validator.isValidName(data.language3)){
                                                                                        isDocumentValid = false;
                                                                                        documentInvalidErr = "INVALID_LANGUAGE3";
                                                                                        next();  
                                                                                    }else if(!validator.isEmpty(data.language3)){
                                                                                        if(!validator.isSpokenWritten(data.spoken3)){
                                                                                            isDocumentValid = false;
                                                                                            if(validator.isEmpty(data.spoken3)){
                                                                                                documentInvalidErr = "EMPTY_SPOKEN3";
                                                                                                next();
                                                                                            }else{
                                                                                                documentInvalidErr = "INVALID_SPOKEN3";
                                                                                                next();
                                                                                            }
                                                                                        }else if(!validator.isSpokenWritten(data.written3)){
                                                                                            isDocumentValid = false;
                                                                                            if(validator.isEmpty(data.written3)){
                                                                                                documentInvalidErr = "EMPTY_WRITTEN3";
                                                                                                next();
                                                                                            }else{
                                                                                                documentInvalidErr = "INVALID_WRITTEN3";
                                                                                                next();
                                                                                            }
                                                                                        }else{
                                                                                            validateProper();
                                                                                        }
                                                                                    }

                                                                                    function validateProper(){
                                                                                        if(!validator.isEmpty(data.language3)){
                                                                                            console.log("data.language3",data.language3.toLowerCase());
                                                                                            LanguageModel.findOne({language_name: data.language3.toLowerCase().trim()}, function(err, languageData3){
                                                                                                if(err){
                                                                                                    isDocumentValid = false;
                                                                                                    documentInvalidErr = "ERROR";
                                                                                                    next();
                                                                                                }else if(languageData3){

                                                                                                    if(validator.isEmpty(data.language4)){
                                                                                                        if(!validator.isEmpty(data.spoken4)){
                                                                                                            isDocumentValid = false;
                                                                                                            documentInvalidErr = "SPOKEN4_HAVE_NOT_LANGUAGE4";
                                                                                                            next();
                                                                                                        }else if(!validator.isEmpty(data.written4)){
                                                                                                            isDocumentValid = false;
                                                                                                            documentInvalidErr = "WRITTEN4_HAVE_NOT_LANGUAGE4";
                                                                                                            next();
                                                                                                        }else if(!validator.isEmpty(data.language5) || !validator.isEmpty(data.spoken5) || !validator.isEmpty(data.written5) 
                                                                                                            || !validator.isEmpty(data.language6) || !validator.isEmpty(data.spoken6) || !validator.isEmpty(data.written6)){
                                                                                                            isDocumentValid = false;
                                                                                                            documentInvalidErr = "EMPTY_LANGUAGE4_ERROR";
                                                                                                            next();                                                                                    
                                                                                                        }else{
                                                                                                            validateProper1();
                                                                                                        }    
                                                                                                    }else if(!validator.isValidName(data.language4)){
                                                                                                        isDocumentValid = false;
                                                                                                        documentInvalidErr = "INVALID_LANGUAGE4";
                                                                                                        next();  
                                                                                                    }else if(!validator.isEmpty(data.language4)){
                                                                                                        if(!validator.isSpokenWritten(data.spoken4)){
                                                                                                            isDocumentValid = false;
                                                                                                            if(validator.isEmpty(data.spoken4)){
                                                                                                                documentInvalidErr = "EMPTY_SPOKEN4";
                                                                                                                next();
                                                                                                            }else{
                                                                                                                documentInvalidErr = "INVALID_SPOKEN4";
                                                                                                                next();
                                                                                                            }
                                                                                                        }else if(!validator.isSpokenWritten(data.written4)){
                                                                                                            isDocumentValid = false;
                                                                                                            if(validator.isEmpty(data.written4)){
                                                                                                                documentInvalidErr = "EMPTY_WRITTEN4";
                                                                                                                next();
                                                                                                            }else{
                                                                                                                documentInvalidErr = "INVALID_WRITTEN4";
                                                                                                                next();
                                                                                                            }
                                                                                                        }else{
                                                                                                            validateProper1();
                                                                                                        }
                                                                                                    }

                                                                                                    function validateProper1(){
                                                                                                        if(!validator.isEmpty(data.language4)){
                                                                                                            console.log("data.language4",data.language4.toLowerCase().trim());
                                                                                                            LanguageModel.findOne({language_name: data.language4.toLowerCase()}, function(err, languageData4){
                                                                                                                if(err){
                                                                                                                    isDocumentValid = false;
                                                                                                                    documentInvalidErr = "ERROR";
                                                                                                                    next();
                                                                                                                }else if(languageData4){
                                                                                                                    if(validator.isEmpty(data.language5)){
                                                                                                                        if(!validator.isEmpty(data.spoken5)){
                                                                                                                            isDocumentValid = false;
                                                                                                                            documentInvalidErr = "SPOKEN5_HAVE_NOT_LANGUAGE5";
                                                                                                                            next();
                                                                                                                        }else if(!validator.isEmpty(data.written5)){
                                                                                                                            isDocumentValid = false;
                                                                                                                            documentInvalidErr = "WRITTEN5_HAVE_NOT_LANGUAGE5";
                                                                                                                            next();
                                                                                                                        }else if(!validator.isEmpty(data.language6) || !validator.isEmpty(data.spoken6) || !validator.isEmpty(data.written6)){
                                                                                                                            isDocumentValid = false;
                                                                                                                            documentInvalidErr = "EMPTY_LANGUAGE5_ERROR";
                                                                                                                            next();                                                                                    
                                                                                                                        }else{
                                                                                                                            validateProper2();
                                                                                                                        }    
                                                                                                                    }else if(!validator.isValidName(data.language5)){
                                                                                                                        isDocumentValid = false;
                                                                                                                        documentInvalidErr = "INVALID_LANGUAGE5";
                                                                                                                        next();  
                                                                                                                    }else if(!validator.isEmpty(data.language5)){
                                                                                                                        if(!validator.isSpokenWritten(data.spoken5)){
                                                                                                                            isDocumentValid = false;
                                                                                                                            if(validator.isEmpty(data.spoken5)){
                                                                                                                                documentInvalidErr = "EMPTY_SPOKEN5";
                                                                                                                                next();
                                                                                                                            }else{
                                                                                                                                documentInvalidErr = "INVALID_SPOKEN5";
                                                                                                                                next();
                                                                                                                            }
                                                                                                                        }else if(!validator.isSpokenWritten(data.written5)){
                                                                                                                            isDocumentValid = false;
                                                                                                                            if(validator.isEmpty(data.written5)){
                                                                                                                                documentInvalidErr = "EMPTY_WRITTEN5";
                                                                                                                                next();
                                                                                                                            }else{
                                                                                                                                documentInvalidErr = "INVALID_WRITTEN5";
                                                                                                                                next();
                                                                                                                            }
                                                                                                                        }else{
                                                                                                                            validateProper2();
                                                                                                                        }
                                                                                                                    }

                                                                                                                    function validateProper2(){
                                                                                                                        if(!validator.isEmpty(data.language5)){
                                                                                                                            console.log("data.language5",data.language5.toLowerCase());
                                                                                                                            LanguageModel.findOne({language_name: data.language5.toLowerCase().trim()}, function(err, languageData5){
                                                                                                                                if(err){
                                                                                                                                    isDocumentValid = false;
                                                                                                                                    documentInvalidErr = "ERROR";
                                                                                                                                    next();
                                                                                                                                }else if(languageData5){
                                                                                                                                    if(validator.isEmpty(data.language6)){
                                                                                                                                        if(!validator.isEmpty(data.spoken6)){
                                                                                                                                            isDocumentValid = false;
                                                                                                                                            documentInvalidErr = "SPOKEN6_HAVE_NOT_LANGUAGE6";
                                                                                                                                            next();
                                                                                                                                        }else if(!validator.isEmpty(data.written6)){
                                                                                                                                            isDocumentValid = false;
                                                                                                                                            documentInvalidErr = "WRITTEN6_HAVE_NOT_LANGUAGE6";
                                                                                                                                            next();
                                                                                                                                        }else{
                                                                                                                                            validateProper3();
                                                                                                                                        }    
                                                                                                                                    }else if(!validator.isValidName(data.language6)){
                                                                                                                                        isDocumentValid = false;
                                                                                                                                        documentInvalidErr = "INVALID_LANGUAGE6";
                                                                                                                                        next();  
                                                                                                                                    }else if(!validator.isEmpty(data.language6)){
                                                                                                                                        if(!validator.isSpokenWritten(data.spoken6)){
                                                                                                                                            isDocumentValid = false;
                                                                                                                                            if(validator.isEmpty(data.spoken6)){
                                                                                                                                                documentInvalidErr = "EMPTY_SPOKEN6";
                                                                                                                                                next();
                                                                                                                                            }else{
                                                                                                                                                documentInvalidErr = "INVALID_SPOKEN6";
                                                                                                                                                next();
                                                                                                                                            }
                                                                                                                                        }else if(!validator.isSpokenWritten(data.written6)){
                                                                                                                                            isDocumentValid = false;
                                                                                                                                            if(validator.isEmpty(data.written6)){
                                                                                                                                                documentInvalidErr = "EMPTY_WRITTEN6";
                                                                                                                                                next();
                                                                                                                                            }else{
                                                                                                                                                documentInvalidErr = "INVALID_WRITTEN6";
                                                                                                                                                next();
                                                                                                                                            }
                                                                                                                                        }else{
                                                                                                                                            validateProper3();
                                                                                                                                        }
                                                                                                                                    }

                                                                                                                                    function validateProper3(){
                                                                                                                                        if(!validator.isEmpty(data.language6)){
                                                                                                                                            console.log("data.language6",data.language6.toLowerCase());
                                                                                                                                            LanguageModel.findOne({language_name: data.language6.toLowerCase().trim()}, function(err, languageData6){
                                                                                                                                                if(err){
                                                                                                                                                    isDocumentValid = false;
                                                                                                                                                    documentInvalidErr = "ERROR";
                                                                                                                                                    next();
                                                                                                                                                }else if(languageData6){
                                                                                                                                                    next(null, languageData6);
                                                                                                                                                }else{
                                                                                                                                                    isDocumentValid = false;
                                                                                                                                                    documentInvalidErr = "LANGUAGE6_NAME_NOT_MATCHED";
                                                                                                                                                    next();
                                                                                                                                                }
                                                                                                                                            })
                                                                                                                                        }else{
                                                                                                                                            next(null, languageData5);
                                                                                                                                        }        
                                                                                                                                    }  

                                                                                                                                }else{
                                                                                                                                    isDocumentValid = false;
                                                                                                                                    documentInvalidErr = "LANGUAGE5_NAME_NOT_MATCHED";
                                                                                                                                    next();
                                                                                                                                }
                                                                                                                            })
                                                                                                                        }else{
                                                                                                                            next(null, languageData4);
                                                                                                                        }        
                                                                                                                    }     

                                                                                                                }else{
                                                                                                                    isDocumentValid = false;
                                                                                                                    documentInvalidErr = "LANGUAGE4_NAME_NOT_MATCHED";
                                                                                                                    next();
                                                                                                                }
                                                                                                            })
                                                                                                        }else{
                                                                                                            next(null, languageData3);
                                                                                                        }        
                                                                                                    }    

                                                                                                }else{
                                                                                                    isDocumentValid = false;
                                                                                                    documentInvalidErr = "LANGUAGE3_NAME_NOT_MATCHED";
                                                                                                    next();
                                                                                                }
                                                                                            })
                                                                                        }else{
                                                                                            next(null, languageData2);
                                                                                        }        
                                                                                    }     

                                                                                    
                                                                                }else{
                                                                                    isDocumentValid = false;
                                                                                    documentInvalidErr = "LANGUAGE2_NAME_NOT_MATCHED";
                                                                                    next();
                                                                                }
                                                                            })
                                                                        }else{
                                                                            next(null, languageData1);
                                                                        }        
                                                                    }       
                                                                }else{
                                                                    isDocumentValid = false;
                                                                    documentInvalidErr = "LANGUAGE1_NAME_NOT_MATCHED";
                                                                    next();
                                                                }
                                                            })


                                                        }else{
                                                            isDocumentValid = false;
                                                            documentInvalidErr = "LATITUDE_LONGITUDE_NOT_FOUND_FOR_ADDRESS";
                                                            next();
                                                        }
                                                    });
                                                    
                                                }else{
                                                    isDocumentValid = false;
                                                    documentInvalidErr = "COUNTRY_NAME_NOT_MATCHED";
                                                    next();
                                                }
                                            })
                                        }
                                    }
                                })
                            }
                        }else{
                            res.json({
                                status: req.config.statusCode.badRequest,
                                data: {},
                                message: i18n.__(documentInvalidErr,count)  
                            }) 
                        }
                    })
                    .on("data", function(data){
                        console.log("comes in data",count);
                        csvData.location = {};
                        csvData.location.type = "Point";
                        csvData.location.coordinates = [];
                        if(data.language2 && data.language3 && data.language4 && data.language5 && data.language6){    
                            csvData.push({ 
                                first_name: data.first_name,
                                last_name: data.last_name,
                                mobile_no: data.mobile_no, 
                                gender: data.gender,
                                email: data.email,
                                alternate_no: data.alternate_no,
                                address1: data.address1,
                                address2: data.address2,
                                city: data.city,
                                state: data.state,
                                zip: data.zip,
                                country: data.country,
                                lat: data.geoDetails[0].latitude,
                                lng: data.geoDetails[0].longitude,
                                languageArray : [{
                                    language_name: data.language1,
                                    spoken: data.spoken1,
                                    written: data.written1    
                                },{
                                    language_name: data.language2,
                                    spoken: data.spoken2,
                                    written: data.written2
                                },{
                                    language_name: data.language3,
                                    spoken: data.spoken3,
                                    written: data.written3
                                },{
                                    language_name: data.language4,
                                    spoken: data.spoken4,
                                    written: data.written4
                                },{
                                    language_name: data.language5,
                                    spoken: data.spoken5,
                                    written: data.written5
                                },{
                                    language_name: data.language6,
                                    spoken: data.spoken6,
                                    written: data.written6
                                }],
                                location : {
                                    type : 'Point', 
                                    coordinates : [
                                        data.geoDetails[0].longitude, 
                                        data.geoDetails[0].latitude
                                    ]
                                } 
                            });
                        }else if(data.language2 && data.language3 && data.language4 && data.language5 && !data.language6){    
                            csvData.push({ 
                                first_name: data.first_name,
                                last_name: data.last_name,
                                mobile_no: data.mobile_no, 
                                gender: data.gender,
                                email: data.email,
                                alternate_no: data.alternate_no,
                                address1: data.address1,
                                address2: data.address2,
                                city: data.city,
                                state: data.state,
                                zip: data.zip,
                                country: data.country,
                                lat: data.geoDetails[0].latitude,
                                lng: data.geoDetails[0].longitude,
                                languageArray : [{
                                    language_name: data.language1,
                                    spoken: data.spoken1,
                                    written: data.written1    
                                },{
                                    language_name: data.language2,
                                    spoken: data.spoken2,
                                    written: data.written2
                                },{
                                    language_name: data.language3,
                                    spoken: data.spoken3,
                                    written: data.written3
                                },{
                                    language_name: data.language4,
                                    spoken: data.spoken4,
                                    written: data.written4
                                },{
                                    language_name: data.language5,
                                    spoken: data.spoken5,
                                    written: data.written5
                                }],
                                location : {
                                    type : 'Point', 
                                    coordinates : [
                                        data.geoDetails[0].longitude, 
                                        data.geoDetails[0].latitude
                                    ]
                                } 
                            });
                        }else if(data.language2 && data.language3 && data.language4 && !data.language5 && !data.language6){
                            csvData.push({ 
                                first_name: data.first_name,
                                last_name: data.last_name,
                                mobile_no: data.mobile_no, 
                                gender: data.gender,
                                email: data.email,
                                alternate_no: data.alternate_no,
                                address1: data.address1,
                                address2: data.address2,
                                city: data.city,
                                state: data.state,
                                zip: data.zip,
                                country: data.country,
                                lat: data.geoDetails[0].latitude,
                                lng: data.geoDetails[0].longitude,
                                languageArray : [{
                                    language_name: data.language1,
                                    spoken: data.spoken1,
                                    written: data.written1    
                                },{
                                    language_name: data.language2,
                                    spoken: data.spoken2,
                                    written: data.written2
                                },{
                                    language_name: data.language3,
                                    spoken: data.spoken3,
                                    written: data.written3
                                },{
                                    language_name: data.language4,
                                    spoken: data.spoken4,
                                    written: data.written4
                                }],
                                location : {
                                    type : 'Point', 
                                    coordinates : [
                                        data.geoDetails[0].longitude, 
                                        data.geoDetails[0].latitude
                                    ]
                                }
                            });
                        }else if(data.language2 && data.language3 && !data.language4 && !data.language5 && !data.language6){
                            csvData.push({ 
                                first_name: data.first_name,
                                last_name: data.last_name,
                                mobile_no: data.mobile_no, 
                                gender: data.gender,
                                email: data.email,
                                alternate_no: data.alternate_no,
                                address1: data.address1,
                                address2: data.address2,
                                city: data.city,
                                state: data.state,
                                zip: data.zip,
                                country: data.country,
                                lat: data.geoDetails[0].latitude,
                                lng: data.geoDetails[0].longitude,
                                languageArray : [{
                                    language_name: data.language1,
                                    spoken: data.spoken1,
                                    written: data.written1    
                                },{
                                    language_name: data.language2,
                                    spoken: data.spoken2,
                                    written: data.written2
                                },{
                                    language_name: data.language3,
                                    spoken: data.spoken3,
                                    written: data.written3
                                }],
                                location : {
                                    type : 'Point', 
                                    coordinates : [
                                        data.geoDetails[0].longitude, 
                                        data.geoDetails[0].latitude
                                    ]
                                }
                            });
                        }else if(data.language2 && !data.language3 && !data.language4 && !data.language5 && !data.language6){
                            csvData.push({ 
                                first_name: data.first_name,
                                last_name: data.last_name,
                                mobile_no: data.mobile_no, 
                                gender: data.gender,
                                email: data.email,
                                alternate_no: data.alternate_no,
                                address1: data.address1,
                                address2: data.address2,
                                city: data.city,
                                state: data.state,
                                zip: data.zip,
                                country: data.country,
                                lat: data.geoDetails[0].latitude,
                                lng: data.geoDetails[0].longitude,
                                languageArray : [{
                                    language_name: data.language1,
                                    spoken: data.spoken1,
                                    written: data.written1    
                                },{
                                    language_name: data.language2,
                                    spoken: data.spoken2,
                                    written: data.written2
                                }],
                                location : {
                                    type : 'Point', 
                                    coordinates : [
                                        data.geoDetails[0].longitude, 
                                        data.geoDetails[0].latitude
                                    ]
                                }
                            });
                        }else{
                            csvData.push({ 
                                first_name: data.first_name,
                                last_name: data.last_name,
                                mobile_no: data.mobile_no, 
                                gender: data.gender,
                                email: data.email,
                                alternate_no: data.alternate_no,
                                address1: data.address1,
                                address2: data.address2,
                                city: data.city,
                                state: data.state,
                                zip: data.zip,
                                country: data.country,
                                lat: data.geoDetails[0].latitude,
                                lng: data.geoDetails[0].longitude,
                                languageArray : [{
                                    language_name: data.language1,
                                    spoken: data.spoken1,
                                    written: data.written1    
                                }],
                                location : {
                                    type : 'Point', 
                                    coordinates : [
                                        data.geoDetails[0].longitude, 
                                        data.geoDetails[0].latitude
                                    ]
                                }
                            });
                        }
                    })
                    .on("end", function(){
                        if(isDocumentValid){
                            var cnt = 0;
                            async.eachSeries(csvData, function(data,callback){
                                RoleModel.findOne({role:req.config.role_type.INTERPRETER.name}).exec(function(err,roleData){
                                    if(err){
                                        res.json({
                                            status: req.config.statusCode.error,
                                            message: i18n.__("ERROR")
                                        })
                                    }else if(roleData){
                                        CountryModel.findOne({country_name: data.country}).exec(function(err,countryData){
                                            if(err){
                                                res.json({
                                                    status: req.config.statusCode.error,
                                                    message: i18n.__("ERROR")
                                                })      
                                            }else if(countryData){
                                                var user = new User();
                                                user.email = data.email;
                                                user.role_id = roleData._id;
                                                user.activation_key = uuidV4();
                                                
                                                user.save()
                                                    .then((userData) => {
                                                        genId();
                                                        function addData(shortBookingId){
                                                            interpreter = new InterpreterModel(req.body);
                                                            interpreter.agency_id = req.user.agency_id;
                                                            interpreter.first_name = data.first_name;
                                                            interpreter.last_name = data.last_name;
                                                            if(data.gender){
                                                                interpreter.gender = data.gender;
                                                            }
                                                            interpreter.mobile_no = '+'+data.mobile_no;
                                                            if(data.alternate_no != ''){
                                                                interpreter.alternate_no = '+'+data.alternate_no;
                                                            }
                                                            interpreter.address1 = data.address1;
                                                            interpreter.address2 = data.address2;
                                                            interpreter.city = data.city;
                                                            interpreter.state = data.state;
                                                            interpreter.zip = data.zip;
                                                            interpreter.country_id = mongoose.Types.ObjectId(countryData._id);
                                                            interpreter.interpreter_shortid = shortBookingId;
                                                            interpreter.user_id = userData._id;
                                                            interpreter.location = data.location;
                                                            interpreter.lat = data.lat;
                                                            interpreter.lng = data.lng;
                                                            interpreter.save()
                                                            .then((interpreterData) => {
                                                                if(interpreterData){
                                                                    cnt++;
                                                                    console.log("comes in interpreter data",cnt);
                                                                    async.eachSeries(data.languageArray, function(language, next){
                                                                        LanguageModel.findOne({language_name: language.language_name.toLowerCase().trim()}).exec(function(err,languageInfo){
                                                                            if(err){
                                                                                 res.json({
                                                                                    status: req.config.statusCode.error,
                                                                                    message: i18n.__("ERROR")
                                                                                }) 
                                                                             }else if(languageInfo){
                                                                                var languageObj = new InterpreterLanguageModel();
                                                                                languageObj.language_id = languageInfo._id;
                                                                                languageObj.spoken = language.spoken;
                                                                                languageObj.written = language.written;
                                                                                languageObj.agency_id = req.user.agency_id;
                                                                                languageObj.interpreter_id = interpreterData._id;
                                                                                languageObj.save(function(err,languageData){
                                                                                    if(err){
                                                                                        res.json({
                                                                                            status: req.config.statusCode.error,
                                                                                            data: {},
                                                                                            message: i18n.__("ERROR")
                                                                                        })
                                                                                    }else{
                                                                                        console.log("save interpreter language data",cnt);
                                                                                        next();
                                                                                    } 
                                                                                })
                                                                             }
                                                                        })
                                                                    },function(err){
                                                                        if(err){
                                                                            res.json({
                                                                                status: req.config.statusCode.error,
                                                                                data: {},
                                                                                message: i18n.__("ERROR")
                                                                            })
                                                                        }else{
                                                                            console.log("language array over",cnt);
                                                                            callback();
                                                                        }
                                                                    })
                                                                }
                                                            })   
                                                        }    
                                                        function genId(){
                                                            var shortBookingId = validator.generateShortId();
                                                            InterpreterModel.find({interpreter_shortid: shortBookingId}, function(err, InterpreterShortData) {
                                                                if(err){
                                                                    res.json({
                                                                        status: req.config.statusCode.error,
                                                                        data: req.body,
                                                                        message: i18n.__("ERROR")
                                                                    })
                                                                } else if(InterpreterShortData.length>0){
                                                                    genId();
                                                                } else{
                                                                    addData(shortBookingId);
                                                                }
                                                            })
                                                        }
                                                                                                  
                                                    })
                                                }
                                            })
                                            
                                        }else{
                                            res.json({
                                                status: req.config.statusCode.notFound,
                                                data: {},
                                                message: i18n.__("ERROR")
                                            })
                                        }
                                    })
                            },function(err){
                                if(err){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("ERROR")
                                    })
                                }else{
                                    res.json({
                                        status: req.config.statusCode.success,
                                        data: csvData,
                                        message: i18n.__('INTERPRETER_UPLOADED_SUCCESSFULLY')
                                    });
                                }
                            })
                        }else{
                            res.json({
                                status: req.config.statusCode.badRequest,
                                data: {},
                                message: i18n.__(documentInvalidErr,count)  
                            }) 
                        }
                    });
                }else {
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("SELECT_CSV_FILE")
                    })
                }
            }else {
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("SELECT_CSV_FILE")
                })
            }    
        })   
    },

    addInterpreterLeave: function (req, res, next) {
        var leaveDate = moment(req.body.date).format("DD/MMM/YYYY");
        AgencyModel.findOne({_id: req.user.agency_id})
        .then((agencyData)=>{
            User.findOne({_id: agencyData.user_id})
            .then((userData)=>{
                InterpreterModel.findOne({_id: req.user.interpreter_id})
                .then((interpreterData)=>{
                    var interpreterName = interpreterData.first_name.charAt(0).toUpperCase()+interpreterData.first_name.slice(1).toLowerCase()+ ' ' +interpreterData.last_name.charAt(0).toUpperCase()+interpreterData.last_name.slice(1).toLowerCase();
                    var interpreterUnavailable = new InterpreterUnavailableModel()
                    interpreterUnavailable.agency_id = req.user.agency_id;
                    interpreterUnavailable.interpreter_id = req.user.interpreter_id;
                    interpreterUnavailable.leave_date = req.body.date;
                    interpreterUnavailable.save()
                    .then((interpreterUnavailableData)=>{
                        if(req.config.env == 'aws'){
                            var baseUrl = 'https://www.interpreting.works';
                        }else{
                            var baseUrl = req.config.email.base_url;
                        }
                        var options = {
                            template: 'interpreter_leave.html',
                            from: 'abc@gmail.com',
                            repalcement: {
                                "{{user.name}}": agencyData.agency_name.charAt(0).toUpperCase()+agencyData.agency_name.slice(1).toLowerCase(),
                                "{{user.interpreter_name}}": interpreterName,
                                "{{user.date}}": leaveDate,
                                "{{logo_url}}": baseUrl + req.config.email.logo_url,
                                "{{copyright}}": req.config.email.copyright,
                                "{{link.abuse_email}}": req.config.email.abuse_email
                            },
                            to: userData.email,
                            subject: 'Leave Request'
                        };
                        emailSend.smtp.sendMail(options, function (err, response) {
                            if (err) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: req.body,
                                    message: i18n.__("ERROR")
                                })
                            }else{
                                console.log("response", response);
                                res.json({
                                    status: req.config.statusCode.success,
                                    data: response,
                                    message: i18n.__("WORKING_STATUS_CHANGE")
                                });
                            }
                        })
                    }).catch((err) => {
                        console.log("errr", err);
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })
                    });
                })
            })
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })
        });
            
    },

    updateInterpreterLeave: function (req, res, next) {
        InterpreterUnavailableModel.findOneAndUpdate({
            _id: req.body.id
        },
        {
            leave_status: false
        },{
            new: true
        })
        .then((interpreterUnavailableData)=>{
            res.json({
                status: req.config.statusCode.success,
                data: interpreterUnavailableData,
                message: i18n.__('WORKING_STATUS_CHANGE')
            });
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })
        });

                
    },

    addInterpreterLeaveInAgency: function (req, res, next) {
        var interpreterUnavailable = new InterpreterUnavailableModel()
        interpreterUnavailable.agency_id = req.user.agency_id;
        interpreterUnavailable.interpreter_id = req.body.interpreter_id;
        interpreterUnavailable.leave_date = req.body.date;
        interpreterUnavailable.save()
        .then((interpreterUnavailableData)=>{
            res.json({
                status: req.config.statusCode.success,
                data: interpreterUnavailableData,
                message: i18n.__('WORKING_STATUS_CHANGE')
            });
        }).catch((err) => {
            console.log("errr", err);
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })
        });    
    },

    updateInterpreterLeaveInAgency: function (req, res, next) {
        InterpreterUnavailableModel.findOneAndUpdate({
            _id: req.body.id
        },
        {
            leave_status: false
        },{
            new: true
        })
        .then((interpreterUnavailableData)=>{
            res.json({
                status: req.config.statusCode.success,
                data: interpreterUnavailableData,
                message: i18n.__('WORKING_STATUS_CHANGE')
            });
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })

        });

                
    },

    getInterpreterDetailForCalendarByAgency: function (req, res, next) {
        var finalResponse = {};
        finalResponse.workingDay = [];
        finalResponse.dateArray = [];
        finalResponse.interpreterSchedule = [];
        waterfall([
            function(callback) {
                var currentDate = moment(req.body.startDate);
                var stopDate = moment(req.body.endDate);
                while (currentDate <= stopDate) {
                    finalResponse.dateArray.push(moment(currentDate).format('YYYY-MM-DD'))
                    currentDate = moment(currentDate).add(1, 'days');
                }
                callback(null, finalResponse);
            },
            function(finalResponse,callback){
                InterpreterModel.findOne({ _id: req.body.interpreter_id }, 'working_days').lean().exec(function(err, data) {
                    if (err) {
                        callback(err, null);
                    } else {
                        if (!data) {
                            callback(null, finalResponse);
                        } else {
                            finalResponse.workingDay.push(data.working_days);
                            callback(null, finalResponse);
                        }
                    }
                });
               
            },
            function(finalResponse,callback){
                InterpreterUnavailableModel.find({ interpreter_id: req.body.interpreter_id, leave_status: true }).lean().exec(function(err, interpreterUnavailableData) {
                    if (err) {
                        callback(err, null);
                    }else{
                        if (!interpreterUnavailableData) {
                            callback(null, finalResponse);
                        } else {
                            finalResponse.interpreterUnavailableData = interpreterUnavailableData;
                            callback(null, finalResponse);
                        }
                    }
                })        
               
            },
            function(finalResponse, callback) {
                var count = 0;
                var values = [];
                for(var key in finalResponse.workingDay[0]) {
                    var value = finalResponse.workingDay[0][key];
                    values.push(value);
                }
                async.each(finalResponse.dateArray, function(date, cb) {
                    var startDate = moment(date);
                    var endDate = moment(date);
                    var lowerCaseDayName = moment(date).format('dddd').toLowerCase();
                    if (finalResponse.workingDay[0][lowerCaseDayName] == true) {
                        var obj = { status: finalResponse.workingDay[0][lowerCaseDayName], startDate: startDate, endDate: endDate };
                        for (var i = 0; i <finalResponse.interpreterUnavailableData.length; i++) {                            
                            if (date == moment(finalResponse.interpreterUnavailableData[i].leave_date).format('YYYY-MM-DD')) {
                                obj = {status:false, leave_status: finalResponse.interpreterUnavailableData[i].leave_status, startDate: startDate, endDate: endDate, id:finalResponse.interpreterUnavailableData[i]._id };
                            }
                        }
                        finalResponse.interpreterSchedule.push(obj);
                        cb();
                    } else {
                        finalResponse.interpreterSchedule.push({ status: finalResponse.workingDay[0][lowerCaseDayName], startDate: startDate, endDate: endDate })
                        cb();
                    }
                },function(err) {
                    if (err) {
                        callback(err, false);
                    } else {

                        callback(null, finalResponse);
                    }
            })

            }
        ], function(err, data) {
        if (err) {
            res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            } else {
                res.json({
                    status: req.config.statusCode.success,
                    data: data.interpreterSchedule,
                    message: i18n.__("Get interpreter data succesfully")
                });
            }
        });
    },

    getInterpreterNamesByLanguageId: function(req, res, next){
        InterpreterLanguageModel.find({agency_id:req.user.agency_id ,language_id: req.params.id, is_deleted:false})
        .populate('interpreter_id', 'first_name last_name profile_pic')
        .then((languageData)=>{
            res.json({
                status: req.config.statusCode.success,
                data: languageData,
                message: i18n.__('Get languages successfully')
            });
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })

        });
    },

    getCountOfInterpreter: function(req, res, next) {
        SchedulerModel.find({
            interpreter_id:req.user.interpreter_id, 
            is_deleted:false
        }).then((bookingData) => {
            VideoCallModel.find({
                interpreter_id: req.user.interpreter_id
            }).then((videoData) => {
                res.json({
                    status: req.config.statusCode.success,
                    data: {'countBooking':bookingData.length, 'countVideo':videoData.length},
                    message: i18n.__('Get count successfully')
                });
            })
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            });
        })
    },

    listInterpretersSuperAdmin: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            is_deleted: false
        }

        if(req.body.agency_id){
            condition.agency_id = mongoose.Types.ObjectId(req.body.agency_id);
        }

        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                    'first_name': new RegExp(searchText, 'gi')
                },
                {
                    'last_name': new RegExp(searchText, 'gi')
                },
                {
                    'mobile_no': new RegExp(searchText, 'gi')
                },
                {
                    'interpreter_shortid': new RegExp(searchText, 'gi')
                },
                {
                    'userInfo.email': new RegExp(searchText, 'gi')
                }
            ];
        }

        var aggregateQuery = [{
                $lookup: {
                    from: 'users',
                    localField: "user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: {
                    path: "$userInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $match: condition
            }
        ];

        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        InterpreterModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                InterpreterModel.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    deleteInterpreterSuperAdmin: function (req, res, next) {
        InterpreterModel.findOneAndUpdate({
            _id: req.params.id
        }, {
            is_deleted: true
        }, {
            new: true
        })
        .then((result) => {
            if(!result){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                });
            }else{
                User.findOneAndUpdate({
                    _id: result.user_id
                }, {
                    is_deleted: true
                }, {
                    new: true
                }).then((userDetails) => {
                    if(!userDetails){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        });
                    }else{
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            message: i18n.__("Interpreter deleted succesfully")
                        });    
                    }
                })
            }
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        });
    },

    changeInterpreterStatusSuperAdmin: function (req, res, next) {
        InterpreterModel.findOneAndUpdate({
            _id: req.body.id
        }, {
            status: req.body.status
        }, {
            new: true
        })
        .then((result) => {
            if(!result){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                });
            }else{
                User.findOneAndUpdate({
                    _id: result.user_id
                }, {
                    status: req.body.status
                }, {
                    new: true
                }).then((userDetails) => {
                    if(!userDetails){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        });
                    }else{
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            message: i18n.__('Interpreter ' + ((req.body.status == true) ? 'activated' : 'deactivated') + ' successfully')
                        });
                    }
                })        
            }
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })
        });
    },
    
    getInterpreterViewBySuperAdmin: function (req, res, next) {
        var condition = {
            _id: mongoose.Types.ObjectId(req.params.id),
            is_deleted: false
        }

        var aggregateQuery = [
            {
            $lookup: {
                    from: 'users',
                    localField: "user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            { $unwind: "$userInfo"},
            {
                $match: condition
            },{
                $lookup: {
                    from: 'interpreter_languages',
                    localField: "_id",
                    foreignField: "interpreter_id",
                    as: "interpreterLanguageInfo"
                }
            },{
                $lookup: {
                    from: 'interpreter_services',
                    localField: "_id",
                    foreignField: "interpreter_id",
                    as: "interpreterServiceInfo"
                }
            },{
                $lookup: {
                    from: 'interpreter_certificates',
                    localField: "_id",
                    foreignField: "interpreter_id",
                    as: "interpreterCertificateInfo"
                }
            },{ $unwind: {
                    path: "$interpreterCertificateInfo",
                    preserveNullAndEmptyArrays: true
                }
            },{    
                $project: {
                    first_name:1,
                    last_name:1,
                    profile_pic:1,
                    client_shortid:1,
                    mobile_no:1,
                    alternate_no: 1,
                    user_id: 1,
                    gender: 1,
                    city:1,
                    state:1,
                    zip:1,
                    address1:1,
                    address2:1,
                    country_id: 1,
                    working_from: 1,
                    working_to: 1,
                    working_status: 1,
                    working_days: 1,
                    notes: 1,
                    certificate: 1,
                    email: "$userInfo.email",
                    certificates : "$interpreterCertificateInfo",
                    languages: {
                        $filter: {
                            input: "$interpreterLanguageInfo",        
                            as: "item",        
                            cond: {          
                                $and: [
                                    {              
                                        $eq: ["$$item.is_deleted", false]            
                                    },            
                                    {              
                                        $eq: ["$$item.interpreter_id", mongoose.Types.ObjectId(req.params.id)]            
                                    }                  
                                ]
                            }
                        }
                    },
                    services: {
                        $filter: {
                            input: "$interpreterServiceInfo",        
                            as: "item",        
                            cond: {          
                                $and: [
                                    {              
                                        $eq: ["$$item.ticked", true]            
                                    },            
                                    {              
                                        $eq: ["$$item.interpreter_id", mongoose.Types.ObjectId(req.params.id)]            
                                    }                 
                                ]
                            }
                        }
                    }
                }
            }
            
        ];
         InterpreterModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                console.log("error", err);
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            } else {
                if(result[0].certificates !='' && result[0].certificates !=null && result[0].certificates !=undefined){
                    result[0].certificates = result[0].certificates.certificates;
                }else{
                    result[0].certificates = {};
                }
                LanguageModel.populate(result[0], {path: 'languages.language_id', select: {'language_name':1}}, function(err, populatedLanguagesName) {
                    result[0] = populatedLanguagesName;
                    res.json({
                        status: req.config.statusCode.success,
                        data: result[0],
                        message: i18n.__("INTERPRETER_GET_SUCCESSFULLY")
                    });
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    getInterpreterSchedulingDetailsSuperAdmin: function (req, res, next) {
        var finalResponse = {};
        finalResponse.workingDay = [];
        finalResponse.dateArray = [];
        finalResponse.interpreterSchedule = [];
        waterfall([
            function(callback) {
                var currentDate = moment(req.body.startDate);
                var stopDate = moment(req.body.endDate);
                while (currentDate <= stopDate) {
                    finalResponse.dateArray.push(moment(currentDate).format('YYYY-MM-DD'))
                    currentDate = moment(currentDate).add(1, 'days');
                }
                callback(null, finalResponse);
            },
            function(finalResponse,callback){
                InterpreterModel.findOne({ _id: req.body.interpreter_id }, 'working_days').lean().exec(function(err, data) {
                    if (err) {
                        callback(err, null);
                    } else {
                        if (!data) {
                            callback(null, finalResponse);
                        } else {
                            finalResponse.workingDay.push(data.working_days);
                            callback(null, finalResponse);
                        }
                    }
                });
               
            },
            function(finalResponse,callback){
                InterpreterUnavailableModel.find({ interpreter_id: req.body.interpreter_id, leave_status: true }).lean().exec(function(err, interpreterUnavailableData) {
                    if (err) {
                        callback(err, null);
                    }else{
                        if (!interpreterUnavailableData) {
                            callback(null, finalResponse);
                        } else {
                            finalResponse.interpreterUnavailableData = interpreterUnavailableData;
                            callback(null, finalResponse);
                        }
                    }
                })        
               
            },
            function(finalResponse, callback) {
                var count = 0;
                var values = [];
                for(var key in finalResponse.workingDay[0]) {
                    var value = finalResponse.workingDay[0][key];
                    values.push(value);
                }
                async.each(finalResponse.dateArray, function(date, cb) {
                    var startDate = moment(date);
                    var endDate = moment(date);
                    var lowerCaseDayName = moment(date).format('dddd').toLowerCase();
                    if (finalResponse.workingDay[0][lowerCaseDayName] == true) {
                        var obj = { status: finalResponse.workingDay[0][lowerCaseDayName], startDate: startDate, endDate: endDate };
                        for (var i = 0; i <finalResponse.interpreterUnavailableData.length; i++) {                            
                            if (date == moment(finalResponse.interpreterUnavailableData[i].leave_date).format('YYYY-MM-DD')) {
                                obj = {status:false, leave_status: finalResponse.interpreterUnavailableData[i].leave_status, startDate: startDate, endDate: endDate, id:finalResponse.interpreterUnavailableData[i]._id };
                            }
                        }
                        finalResponse.interpreterSchedule.push(obj);
                        cb();
                    } else {
                        finalResponse.interpreterSchedule.push({ status: finalResponse.workingDay[0][lowerCaseDayName], startDate: startDate, endDate: endDate })
                        cb();
                    }
                },function(err) {
                    if (err) {
                        callback(err, false);
                    } else {

                        callback(null, finalResponse);
                    }
            })

            }
        ], function(err, data) {
        if (err) {
            res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            } else {
                res.json({
                    status: req.config.statusCode.success,
                    data: data.interpreterSchedule,
                    message: i18n.__("Get interpreter data succesfully")
                });
            }
        });
    },

    getInterpreterBySuperAdmin: function (req, res, next) {
        var condition = {
            _id: mongoose.Types.ObjectId(req.params.id),
            is_deleted: false
        }

        var aggregateQuery = [
            {
            $lookup: {
                    from: 'users',
                    localField: "user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            { $unwind: "$userInfo"},
            {
                $match: condition
            },{
                $lookup: {
                    from: 'interpreter_languages',
                    localField: "_id",
                    foreignField: "interpreter_id",
                    as: "interpreterLanguageInfo"
                }
            },{
                $lookup: {
                    from: 'interpreter_services',
                    localField: "_id",
                    foreignField: "interpreter_id",
                    as: "interpreterServiceInfo"
                }
            },{
                $lookup: {
                    from: 'interpreter_certificates',
                    localField: "_id",
                    foreignField: "interpreter_id",
                    as: "interpreterCertificateInfo"
                }
            },{ $unwind: {
                    path: "$interpreterCertificateInfo",
                    preserveNullAndEmptyArrays: true
                }
            },{    
                $project: {
                    first_name:1,
                    last_name:1,
                    profile_pic:1,
                    client_shortid:1,
                    mobile_no:1,
                    alternate_no: 1,
                    user_id: 1,
                    gender: 1,
                    city:1,
                    state:1,
                    zip:1,
                    address1:1,
                    address2:1,
                    country_id: 1,
                    working_from: 1,
                    working_to: 1,
                    working_status: 1,
                    working_days: 1,
                    notes: 1,
                    certificate: 1,
                    agency_id: 1,
                    email: "$userInfo.email",
                    certificates : "$interpreterCertificateInfo",
                    languages: {
                        $filter: {
                            input: "$interpreterLanguageInfo",        
                            as: "item",        
                            cond: {          
                                $and: [
                                    {              
                                        $eq: ["$$item.is_deleted", false]            
                                    },            
                                    {              
                                        $eq: ["$$item.interpreter_id", mongoose.Types.ObjectId(req.params.id)]            
                                    }                 
                                ]
                            }
                        }
                    },
                    services: {
                        $filter: {
                            input: "$interpreterServiceInfo",        
                            as: "item",        
                            cond: {          
                                $and: [
                                    {              
                                        $eq: ["$$item.ticked", true]            
                                    },            
                                    {              
                                        $eq: ["$$item.interpreter_id", mongoose.Types.ObjectId(req.params.id)]            
                                    }                  
                                ]
                            }
                        }
                    }
                }
            }
            
        ];
         InterpreterModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            } else {
                if(result[0].certificates !='' && result[0].certificates !=null && result[0].certificates !=undefined){
                    result[0].certificates = result[0].certificates.certificates;
                }else{
                    result[0].certificates = {};
                }
                res.json({
                    status: req.config.statusCode.success,
                    data: result[0],
                    message: i18n.__("INTERPRETER_GET_SUCCESSFULLY")
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    addInterpreterBySuperAdmin: function (req, res, next) {
        genId();
        function addData(shortBookingId){
            var form = new formidable.IncomingForm();
            form.parse(req, function (err, fields, files) {
                var interpreter;
                var certificates = {},tmpCertificates={};
                if(fields.interpreter!=undefined && fields.interpreter!=''){
                    try{
                        interpreter = JSON.parse(fields.interpreter);
                    }catch(err){

                    }
                }
                if(typeof interpreter == 'object'){
                    var timestamp = Number(new Date()); // current time as number
                    var fileName='';
                    var fileExt = '';
                    var interpreterCertPath = "./../client/users/assets/uploads/interpreter_certificates/";
                    if(typeof files.court_certified == 'object'){
                        fileExt = files.court_certified.name.split('.');
                        if(fileExt.length>0){
                            fileExt = fileExt[fileExt.length-1];    
                        }else{
                            fileExt = '';
                        }
                        
                        tmpCertificates.court_certified=timestamp+'_'+common.randomToken(6)+"."+fileExt;
                        certificates.court_certified="/assets/uploads/interpreter_certificates/"+tmpCertificates.court_certified;
                        
                        fs_extra.copy(files.court_certified.path, interpreterCertPath + tmpCertificates.court_certified, function(err) {  
                            if (err) {
                                console.error(err);
                            } else {
                                console.log("success!")
                            }
                        });

                    }
                    if(typeof files.court_screened == 'object'){
                        fileExt = files.court_screened.name.split('.');
                        if(fileExt.length>0){
                            fileExt = fileExt[fileExt.length-1];    
                        }else{
                            fileExt = '';
                        }
                        tmpCertificates.court_screened=timestamp+'_'+common.randomToken(6)+"."+fileExt;
                        certificates.court_screened="/assets/uploads/interpreter_certificates/"+tmpCertificates.court_screened;
                        

                        fs_extra.copy(files.court_screened.path, interpreterCertPath + tmpCertificates.court_screened, function(err) {  
                            if (err) {
                                console.error(err);
                            } else {
                                console.log("success!")
                            }
                        });
                    }

                    function register(_fileName,_certificates) {
                        User.findOne({
                            email: interpreter.email
                        }, function (err, emailData) {
                            if (err) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("ERROR")
                                })
                            } else {
                                if (emailData) {
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("Email Id already exist ! Try with different Email.")
                                    })
                                } else {

                                    RoleModel.findOne({role:req.config.role_type.INTERPRETER.name}).exec(function(err,roleData){
                                        if(err){
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: {},
                                                message: i18n.__("ERROR")
                                            })
                                        }else if(roleData){
                                                var user = new User();
                                                user.email = interpreter.email;
                                                user.role_id = roleData._id;
                                                user.activation_key = uuidV4();
                                                user.save()
                                                    .then((userData) => {
                                                        interpreterModel = new InterpreterModel(interpreter);
                                                        interpreterModel.location = {};
                                                        interpreterModel.location.type = "Point";
                                                        interpreterModel.location.coordinates = [];
                                                        interpreterModel.location.coordinates[0] = parseFloat(interpreter.lng);
                                                        interpreterModel.location.coordinates[1] = parseFloat(interpreter.lat);
                                                        interpreterModel.agency_id = interpreter.agency_id;
                                                        interpreterModel.user_id = userData._id;
                                                        interpreterModel.interpreter_shortid = shortBookingId
                                                        if (_fileName) {
                                                            interpreterModel.profile_pic = "/assets/uploads/profile/" + _fileName;
                                                        }
                                                        interpreterModel.save()
                                                            .then((interpreterData) => {
                                                                if(interpreter.services != '' && interpreter.services != undefined && interpreter.services != null){
                                                                    console.log("in service1");
                                                                    async.eachSeries(interpreter.services, function(service, next){
                                                                        var interpreterService = new InterpreterServiceModel()
                                                                        interpreterService.agency_id = interpreter.agency_id;
                                                                        interpreterService.interpreter_id = interpreterData._id;
                                                                        interpreterService.service_id = service._id;
                                                                        interpreterService.name = service.name; 
                                                                        interpreterService.ticked = service.ticked;
                                                                        interpreterService.save(function(err,servicedata){
                                                                            if(err){
                                                                                res.json({
                                                                                    status: req.config.statusCode.error,
                                                                                    data: {},
                                                                                    message: i18n.__("ERROR")
                                                                                })
                                                                            } else{
                                                                                next();
                                                                            } 
                                                                        })     
                                                                    },function(err){
                                                                      if(err){
                                                                        res.json({
                                                                            status: req.config.statusCode.error,
                                                                            data: {},
                                                                            message: i18n.__("ERROR")
                                                                        })
                                                                      }else{
                                                                       
                                                                      }
                                                                    })
                                                                }
                                                                    
                                                                if(interpreter.languages != '' && interpreter.languages != undefined && interpreter.languages != null){
                                                                    async.eachSeries(interpreter.languages, function(language, next){
                                                                        var interpreterLanguage = new InterpreterLanguageModel()
                                                                        interpreterLanguage.agency_id = interpreter.agency_id;
                                                                        interpreterLanguage.interpreter_id = interpreterData._id;
                                                                        interpreterLanguage.language_id = language.language_id;
                                                                        interpreterLanguage.spoken = language.spoken; 
                                                                        interpreterLanguage.written = language.written;
                                                                        interpreterLanguage.save(function(err,languagedata){
                                                                            if(err){
                                                                                res.json({
                                                                                    status: req.config.statusCode.error,
                                                                                    data: {},
                                                                                    message: i18n.__("ERROR")
                                                                                })
                                                                            } else{
                                                                                next();
                                                                            } 
                                                                        })     
                                                                    },function(err){
                                                                      if(err){
                                                                        res.json({
                                                                            status: req.config.statusCode.error,
                                                                            data: {},
                                                                            message: i18n.__("ERROR")
                                                                        })
                                                                      }else{

                                                                      }
                                                                    })
                                                                }

                                                                if(Object.keys(_certificates).length>0){
                                                                    var certificate = new InterpreterCertificateModel();
                                                                    certificate.agency_id = interpreter.agency_id;
                                                                    certificate.interpreter_id = interpreterData._id;
                                                                    certificate.certificates = _certificates;
                                                                    certificate.save()
                                                                    .then((certificateData) =>{

                                                                    }) 
                                                                }
                                                                if(req.config.env == 'aws'){
                                                                    var baseUrl = 'https://www.interpreting.works';
                                                                }else{
                                                                    var baseUrl = req.config.email.base_url;
                                                                }
                                                                var options = {
                                                                    template: 'set_password.html',
                                                                    from: req.user.email,
                                                                    repalcement: {
                                                                        "{{user.name}}": interpreterData.first_name.charAt(0).toUpperCase()+interpreterData.first_name.slice(1).toLowerCase()+ ' ' +interpreterData.last_name.charAt(0).toUpperCase()+interpreterData.last_name.slice(1).toLowerCase(),
                                                                        "{{user.email}}": userData.email,
                                                                        "{{user.activation_key}}": baseUrl + '/#/setPassword/' + userData.activation_key,
                                                                        "{{logo_url}}": baseUrl + req.config.email.logo_url,
                                                                        "{{copyright}}": req.config.email.copyright,
                                                                        "{{link.abuse_email}}": req.config.email.abuse_email
                                                                    },
                                                                    to: userData.email,
                                                                    subject: 'Complete Registration'
                                                                };
                                                                emailSend.smtp.sendMail(options, function (err, response) {
                                                                    if (err) {
                                                                        res.json({
                                                                            status: req.config.statusCode.error,
                                                                            data: {},
                                                                            message: i18n.__("ERROR")
                                                                        })
                                                                    }else{
                                                                        User.findOneAndUpdate({
                                                                            _id: userData._id
                                                                        }, {
                                                                            is_verification_email_send: true
                                                                        }, {
                                                                            new: true
                                                                        }).then((userData) => {

                                                                        })
                                                                    }
                                                                })
                                                                return interpreterData
                                                            }).then((interpreterData) => {
                                                                res.json({
                                                                    status: req.config.statusCode.success,
                                                                    data: interpreterData,
                                                                    message: i18n.__("Interpreter added succesfully")
                                                                });
                                                            }).catch((err) => {
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: {},
                                                                    message: i18n.__("ERROR")
                                                                })
                                                            });
                                                    }).catch((err) => {
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: {},
                                                            message: i18n.__("ERROR")
                                                        })
                                                    });
                                        }else{
                                            res.json({
                                                status: req.config.statusCode.success,
                                                data: {},
                                                message: i18n.__("No record found")
                                            });
                                        }
                                    })
                                }
                            }
                        })
                    }

                    if (interpreter.imageFile) {
                        fileName = timestamp + '_' + common.randomToken(6) + '.' + 'png';
                        var imagePath = "./../client/users/assets/uploads/profile/" + fileName;
                        var base64Data = interpreter.imageFile.replace(/^data:image\/png;base64,/, "");
                        base64Data += base64Data.replace('+', ' ');
                        binaryData = new Buffer(base64Data, 'base64').toString('binary');
                        fs.writeFile(imagePath, binaryData, "binary", function (err) {
                            if (err) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("ERROR")
                                });
                            } else {
                                register(fileName,certificates);
                            }
                        });
                    } else {
                        register(undefined,certificates);
                    }

                }else{
                    res.json({
                        status: req.config.statusCode.badRequest,
                        data: {},
                        message: i18n.__("INVALID_REQUEST")
                    })
                }  
            })
        }

        function genId(){
            var shortBookingId = validator.generateShortId();
            Booking.find({booking_id: shortBookingId}, function(err, bookingData) {
                if(err){
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                } else if(bookingData.length>0){
                    genId();
                } else{
                    addData(shortBookingId);
                }
            })
        }
    },

    updateInterpreterBySuperAdmin: function (req, res, next) {
        var form = new formidable.IncomingForm();
        form.parse(req, function (err, fields, files) {
            var interpreter={};
            var certificates = {},tmpCertificates={};
            if(fields.interpreter!=undefined && fields.interpreter!=''){
                try{
                    interpreter = JSON.parse(fields.interpreter);
                }catch(err){

                }
            }
            if(typeof interpreter == 'object'){
                var timestamp = Number(new Date()); // current time as number
                var fileName='';
                var fileExt = '';
                var interpreterCertPath = "./../client/users/assets/uploads/interpreter_certificates/";
                if(typeof files.court_certified == 'object'){
                    fileExt = files.court_certified.name.split('.');
                    if(fileExt.length>0){
                        fileExt = fileExt[fileExt.length-1];    
                    }else{
                        fileExt = '';
                    }
                    
                    tmpCertificates.court_certified=timestamp+'_'+common.randomToken(6)+"."+fileExt;
                    certificates.court_certified="/assets/uploads/interpreter_certificates/"+tmpCertificates.court_certified;
                    
                    fs_extra.copy(files.court_certified.path, interpreterCertPath + tmpCertificates.court_certified, function(err) {  
                        if (err) {
                            console.error(err);
                        } else {
                            console.log("success!")
                        }
                    });

                }
                if(typeof files.court_screened == 'object'){
                    fileExt = files.court_screened.name.split('.');
                    if(fileExt.length>0){
                        fileExt = fileExt[fileExt.length-1];    
                    }else{
                        fileExt = '';
                    }
                    tmpCertificates.court_screened=timestamp+'_'+common.randomToken(6)+"."+fileExt;
                    certificates.court_screened="/assets/uploads/interpreter_certificates/"+tmpCertificates.court_screened;
                    

                    fs_extra.copy(files.court_screened.path, interpreterCertPath + tmpCertificates.court_screened, function(err) {  
                        if (err) {
                            console.error(err);
                        } else {
                            console.log("success!")
                        }
                    });
                }

                 function update(_fileName,_certificates) {
                    User.findOne({
                        email: interpreter.email,
                        _id: {
                            $ne: interpreter.user_id
                        }
                    }, function (err, emailData) {
                        if (err) {
                            console.log("err1",err);
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        } else {
                            if (emailData) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("Email Id already exist ! Try with different Email.")
                                })
                            } else {
                                var updateData = interpreter;
                                updateData.location = {};
                                updateData.location.type = "Point";
                                updateData.location.coordinates = [];
                                updateData.location.coordinates[0] = parseFloat(interpreter.lng);
                                updateData.location.coordinates[1] = parseFloat(interpreter.lat);
                                if (_fileName) {
                                    updateData.profile_pic = "/assets/uploads/profile/" + _fileName;
                                }
                                InterpreterModel.update({
                                    _id: interpreter._id
                                }, {
                                    $set: updateData
                                }, function (err) {
                                    if (err) {
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: req.body,
                                            message: i18n.__("ERROR")
                                        })
                                    } else {
                                        User.update({
                                            _id: interpreter.user_id
                                        }, {
                                            $set: {
                                                email: interpreter.email
                                            }
                                        }, function (err) {
                                            if (err) {
                                                res.json({
                                                    status: req.config.statusCode.error,
                                                    data: req.body,
                                                    message: i18n.__("ERROR")
                                                })
                                            } else {
                                                if(interpreter.services != '' && interpreter.services !=undefined && interpreter.services != null){
                                                    async.eachSeries(interpreter.services,function(data,next){
                                                        var service = {
                                                            agency_id: interpreter.agency_id,
                                                            interpreter_id:interpreter._id,
                                                            service_id: data._id,
                                                            name:data.name,
                                                            ticked: data.ticked
                                                        }
                                                        InterpreterServiceModel.update({
                                                            agency_id:interpreter.agency_id,
                                                            interpreter_id:interpreter._id,
                                                            service_id: data._id
                                                        },{
                                                            $set: service
                                                        },{
                                                            upsert: true
                                                        },function(err, interpreterServiceData){
                                                            if(err){
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: {},
                                                                    message: i18n.__("ERROR")
                                                                })
                                                            } else{
                                                                next();
                                                            }
                                                        })
                                                    }),function(err){
                                                        if(err){
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: {},
                                                                message: i18n.__("ERROR")
                                                            })
                                                        }else{
                                                            
                                                        }
                                                    }
                                                }

                                                if(interpreter.languages != '' && interpreter.languages !=undefined && interpreter.languages != null){
                                                    async.eachSeries(interpreter.languages,function(data,next){
                                                        var deleted = data.is_deleted ? data.is_deleted : false;
                                                        var language = {
                                                            agency_id: interpreter.agency_id,
                                                            interpreter_id:interpreter._id,
                                                            language_id: data.language_id,
                                                            spoken: data.spoken,
                                                            written: data.written,
                                                            is_deleted: deleted  
                                                        }
                                                        InterpreterLanguageModel.update({
                                                            agency_id: interpreter.agency_id,
                                                            interpreter_id:interpreter._id,
                                                            language_id: data.language_id
                                                        },{
                                                            $set: language
                                                        },{
                                                            upsert: true
                                                        },function(err, interpreterLanguageData){
                                                            if(err){
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: {},
                                                                    message: i18n.__("ERROR")
                                                                })
                                                            } else{
                                                                next();
                                                            }
                                                        })
                                                    }),function(err){
                                                        if(err){
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: {},
                                                                message: i18n.__("ERROR")
                                                            })
                                                        }else{
                                                            
                                                        }
                                                    }
                                                }

                                                if(_certificates.court_screened==undefined){
                                                    if(interpreter.certificates!=undefined && interpreter.certificates.court_screened!=undefined && interpreter.certificates.court_screened!=''){
                                                        _certificates.court_screened = interpreter.certificates.court_screened;
                                                    }
                                                }
                                                if(_certificates.court_certified==undefined){
                                                    if(interpreter.certificates!=undefined && interpreter.certificates.court_certified!=undefined && interpreter.certificates.court_certified!=''){
                                                        _certificates.court_certified = interpreter.certificates.court_certified;
                                                    }
                                                }
                                                if(Object.keys(_certificates).length>0){
                                                    InterpreterCertificateModel.findOne({
                                                    interpreter_id: interpreter._id
                                                    }).then((certificateData) => {
                                                        if(!certificateData){

                                                            var certificate = new InterpreterCertificateModel(); 
                                                            certificate.certificates = _certificates;
                                                            certificate.interpreter_id = interpreter._id;
                                                            certificate.save()
                                                            .then((certificateSaved) => {

                                                            })
                                                        }else{
                                                            certificateData.certificates = _certificates;
                                                            certificateData.save()
                                                            .then((savedData) =>{

                                                            })
                                                        }

                                                    })
                                                }else{
                                                    InterpreterCertificateModel.find({ interpreter_id:interpreter._id }).remove().exec();
                                                }
                                                
                                                res.json({
                                                    status: req.config.statusCode.success,
                                                    data: req.body,
                                                    message: i18n.__("Interpreter updated succesfully")
                                                });
                                            }
                                        })

                                    }
                                })
                            }
                        }
                    })
                }

                if (interpreter.imageFile) {
                    fileName = timestamp + '_' + common.randomToken(6) + '.' + 'png';
                    var imagePath = "./../client/users/assets/uploads/profile/" + fileName;
                    var base64Data = interpreter.imageFile.replace(/^data:image\/png;base64,/, "");
                    base64Data += base64Data.replace('+', ' ');
                    binaryData = new Buffer(base64Data, 'base64').toString('binary');
                    fs.writeFile(imagePath, binaryData, "binary", function (err) {
                        if (err) {
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        } else {
                            update(fileName,certificates);
                        }
                    });
                } else {
                    update(undefined,certificates);
                }

            }else{
                res.json({
                    status: req.config.statusCode.badRequest,
                    data: {},
                    message: i18n.__("INVALID_REQUEST")
                })
            }  
        })
    },

    activateInterpreterSuperAdmin: function (req, res, next){
        function sendEmailNotification(obj){
            if(req.config.env == 'aws'){
                var baseUrl = 'https://www.interpreting.works';
            }else{
                var baseUrl = req.config.email.base_url;
            }
            var options = {
                template: 'completeUserRegistration.html',
                from: 'rahul@yopmail.com',
                repalcement: {
                    "{{user.name}}": obj.first_name.charAt(0).toUpperCase()+obj.first_name.slice(1).toLowerCase()+ ' ' + obj.last_name.charAt(0).toUpperCase()+obj.last_name.slice(1).toLowerCase(),
                    "{{user.email}}": obj.email,
                    "{{user.url}}": baseUrl + '/#/login/',
                    "{{user.email}}": obj.email,
                    "{{user.password}}": req.body.password,
                    "{{logo_url}}": baseUrl + req.config.email.logo_url,
                    "{{copyright}}": req.config.email.copyright,
                    "{{link.abuse_email}}": req.config.email.abuse_email
                },
                to: obj.email,
                subject: 'Registration Completed Successfully'
            };
            emailSend.smtp.sendMail(options, function (err, response) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                }else{
                    // var text ="Your Registration completed successfully.";
                    // var data = { to: '+919990795913', message: text }
                    // twilioSms.sendSMS(data, function(returnData) {
                    // });
                    res.json({
                        status: req.config.statusCode.success,
                        data: obj.result,
                        message: i18n.__("Registration completed successfully for this account")
                    });
                }
            })
        }

        bcrypt.genSalt(10, function (err, salt) {
            bcrypt.hash(req.body.password, salt, function (err, hash) {
                if (!err) {
                    User.findOne({_id:req.body.user_id}).exec(function(err,userData){
                        if(err){
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        }else if(userData){
                            userData.password = hash;
                            userData.activation_key = '';
                            userData.is_verified = true;
                            userData.status = true;
                            userData.save(function(err, result){
                                if(err){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("ERROR")
                                    })
                                }else{
                                    InterpreterModel.findOne({user_id:result._id}).exec(function(err,interpreterData){
                                        if(err){
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: {},
                                                message: i18n.__("ERROR")
                                            })
                                        }else if(interpreterData){
                                            interpreterData.status = true;
                                            interpreterData.save(function(err,savedData){
                                                if(err){
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: {},
                                                        message: i18n.__("ERROR")
                                                    })
                                                }else{
                                                    var obj = {
                                                        first_name:interpreterData.first_name,
                                                        last_name:interpreterData.last_name,
                                                        email: result.email,
                                                        result:result
                                                    }
                                                    sendEmailNotification(obj);        
                                                }
                                            })
                                        }else{
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: {},
                                                message: i18n.__("ERROR")
                                            });
                                        }
                                    }) 
                                }
                            })

                        }else{
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        }
                    }).catch(function (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        })
                    })
                }
            })
        })
    },

    activateInterpreterByAgency: function (req, res, next){
        function sendEmailNotification(obj){
            if(req.config.env == 'aws'){
                var baseUrl = 'https://www.interpreting.works';
            }else{
                var baseUrl = req.config.email.base_url;
            }
            var options = {
                template: 'completeUserRegistration.html',
                from: 'rahul@yopmail.com',
                repalcement: {
                    "{{user.name}}": obj.first_name.charAt(0).toUpperCase()+obj.first_name.slice(1).toLowerCase()+ ' ' + obj.last_name.charAt(0).toUpperCase()+obj.last_name.slice(1).toLowerCase(),
                    "{{user.email}}": obj.email,
                    "{{user.url}}": baseUrl + '/#/login/',
                    "{{user.email}}": obj.email,
                    "{{user.password}}": req.body.password,
                    "{{logo_url}}": baseUrl + req.config.email.logo_url,
                    "{{copyright}}": req.config.email.copyright,
                    "{{link.abuse_email}}": req.config.email.abuse_email
                },
                to: obj.email,
                subject: 'Registration Completed Successfully'
            };
            emailSend.smtp.sendMail(options, function (err, response) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                }else{
                    // var text ="Your Registration completed successfully.";
                    // var data = { to: '+919990795913', message: text }
                    // twilioSms.sendSMS(data, function(returnData) {
                    // });
                    res.json({
                        status: req.config.statusCode.success,
                        data: obj.result,
                        message: i18n.__("Registration completed successfully for this account")
                    });
                }
            })
        }

        bcrypt.genSalt(10, function (err, salt) {
            bcrypt.hash(req.body.password, salt, function (err, hash) {
                if (!err) {
                    User.findOne({_id:req.body.user_id}).exec(function(err,userData){
                        if(err){
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        }else if(userData){
                            userData.password = hash;
                            userData.activation_key = '';
                            userData.is_verified = true;
                            userData.status = true;
                            userData.save(function(err, result){
                                if(err){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("ERROR")
                                    })
                                }else{
                                    InterpreterModel.findOne({user_id:result._id}).exec(function(err,interpreterData){
                                        if(err){
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: {},
                                                message: i18n.__("ERROR")
                                            })
                                        }else if(interpreterData){
                                            interpreterData.status = true;
                                            interpreterData.save(function(err,savedData){
                                                if(err){
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: {},
                                                        message: i18n.__("ERROR")
                                                    })
                                                }else{
                                                    var obj = {
                                                        first_name:interpreterData.first_name,
                                                        last_name:interpreterData.last_name,
                                                        email: result.email,
                                                        result:result
                                                    }
                                                    sendEmailNotification(obj);        
                                                }
                                            })
                                        }else{
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: {},
                                                message: i18n.__("ERROR")
                                            });
                                        }
                                    }) 
                                }
                            })

                        }else{
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        }
                    }).catch(function (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        })
                    })
                }
            })
        })
    },

    listAgencyInterpretersInReports: function (req, res, next) {
        InterpreterModel.find({
            agency_id: req.user.agency_id,
            is_deleted: false,
            status: true
        }, {
            first_name: 1,
            last_name: 1
        })
        .populate('user_id')
        .exec(function(err, interpreters) {
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                })
            }else if(interpreters.length > 0){
                res.json({
                    status: req.config.statusCode.success,
                    data: interpreters,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }else{
                res.json({
                    status: req.config.statusCode.notFound,
                    data: [],
                    message: i18n.__("NO_RECORD_FOUND")
                })    
            }
        }).catch(function(err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    getInterpreterNameByInterpreterIdInReport: function(req, res, next){
        InterpreterModel.findOne({
            agency_id:req.user.agency_id,
            _id: req.params.id, 
            is_deleted:false,
            status: true
        })
        .exec(function(err, interpreterData) {
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                });
            }else{
                res.json({
                    status: req.config.statusCode.success,
                    data: interpreterData,
                    message: i18n.__('DATA_FOUND_SUCCESSFULLY')
                });
            }
        }).catch(function(err) {
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        });
    },

    
}
