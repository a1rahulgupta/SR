var crypto = __rootRequire('app/utils/crypto');
module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];

    var interpreter_ctrl = require('./controllers/interpreter_ctrl')
    router.get('/interpreters/listAgencyInterpreters', middlewares, interpreter_ctrl.listAgencyInterpreters);
    router.get('/interpreters/getCountOfInterpreter', middlewares, interpreter_ctrl.getCountOfInterpreter);
    router.post('/interpreters/listInterpreters', middlewares, interpreter_ctrl.listInterpreters);
    router.post('/interpreters/addInterpreter', middlewares, interpreter_ctrl.addInterpreters);
    router.post('/interpreters/updateInterpreter', middlewares, interpreter_ctrl.updateInterpreters);
    router.delete('/interpreters/deleteInterpreter/:id', middlewares, interpreter_ctrl.deleteInterpreter);
    router.get('/interpreters/getInterpreter/:id', middlewares, interpreter_ctrl.getInterpretersById);
    router.get('/interpreters/getInterpreterViewById/:id', middlewares, interpreter_ctrl.getInterpreterViewById);
    router.post('/interpreters/changeInterpreterStatus', middlewares, interpreter_ctrl.changeInterpreterStatus);
    router.post('/interpreters/bulkUploadInterpreter', middlewares, interpreter_ctrl.bulkUploadInterpreter);
    router.get('/interpreters/getInterpreterProfile', middlewares, interpreter_ctrl.getInterpreterProfileDetailById);
    router.post('/interpreters/getInterpreterDetailForCalendar', middlewares, interpreter_ctrl.getInterpreterDetailForCalendar);
    router.post('/interpreters/addInterpreterLeave', middlewares, interpreter_ctrl.addInterpreterLeave);
    router.post('/interpreters/updateInterpreterLeave', middlewares, interpreter_ctrl.updateInterpreterLeave);
    router.post('/interpreters/addInterpreterLeaveInAgency', middlewares, interpreter_ctrl.addInterpreterLeaveInAgency);
    router.post('/interpreters/updateInterpreterLeaveInAgency', middlewares, interpreter_ctrl.updateInterpreterLeaveInAgency);
    router.post('/interpreters/updateInterpreterProfile', middlewares, interpreter_ctrl.updateInterpreterProfile);
    router.post('/interpreters/getInterpreterDetailForCalendarByAgency', middlewares, interpreter_ctrl.getInterpreterDetailForCalendarByAgency);
    router.get('/interpreters/getInterpreterNamesByLanguageId/:id', middlewares, interpreter_ctrl.getInterpreterNamesByLanguageId);
    router.post('/interpreters/listInterpretersSuperAdmin', middlewares, interpreter_ctrl.listInterpretersSuperAdmin);
    router.delete('/interpreters/deleteInterpreterSuperAdmin/:id', middlewares, interpreter_ctrl.deleteInterpreterSuperAdmin);
    router.post('/interpreters/changeInterpreterStatusSuperAdmin', middlewares, interpreter_ctrl.changeInterpreterStatusSuperAdmin);
    router.get('/interpreters/getInterpreterViewBySuperAdmin/:id', middlewares, interpreter_ctrl.getInterpreterViewBySuperAdmin);
    router.post('/interpreters/getInterpreterSchedulingDetailsSuperAdmin', middlewares, interpreter_ctrl.getInterpreterSchedulingDetailsSuperAdmin);
    router.get('/interpreters/getInterpreterBySuperAdmin/:id', middlewares, interpreter_ctrl.getInterpreterBySuperAdmin);
    router.post('/interpreters/addInterpreterBySuperAdmin', middlewares, interpreter_ctrl.addInterpreterBySuperAdmin);
    router.post('/interpreters/updateInterpreterBySuperAdmin', middlewares, interpreter_ctrl.updateInterpreterBySuperAdmin);
    router.post('/interpreters/activateInterpreterSuperAdmin', middlewares, interpreter_ctrl.activateInterpreterSuperAdmin);
    router.post('/interpreters/activateInterpreterByAgency', middlewares, interpreter_ctrl.activateInterpreterByAgency);
    router.get('/interpreters/listAgencyInterpretersInReports', middlewares, interpreter_ctrl.listAgencyInterpretersInReports);
    router.get('/interpreters/getInterpreterNameByInterpreterIdInReport/:id', middlewares, interpreter_ctrl.getInterpreterNameByInterpreterIdInReport);
    
    return router;
}