const jwt = require('jsonwebtoken');
const Joi = require('joi');
const moment = require('moment');
const bcrypt = require('bcrypt');
const i18n = require("i18n");
const _ = require("lodash");
const mongoose = require('mongoose');
const common = __rootRequire('app/config/common.js');
const crypto = __rootRequire('app/utils/crypto');
const santize = __rootRequire('app/utils/santize');
const file = __rootRequire('app/core/file');
const fs = require('fs');
const AdminModel = mongoose.model('Admin');
const LanguageModel = mongoose.model('Languages');
const CountriesModel = mongoose.model('Countries');
const SubscribeModel = mongoose.model('Subscribe_email');
const ServiceModel = mongoose.model('Services');
const SubscriptionModel = mongoose.model('Subscriptions');
const User = mongoose.model('Users');
const EmailTemplate = mongoose.model('Email_Templates');
const AgencyModel = mongoose.model('Agencies');
const ClientModel = mongoose.model('Clients');
const InterpreterModel = mongoose.model('Interpreters');
const StripeKeysModel = mongoose.model('Stripe_keys');
const OpentokKeysModel = mongoose.model('Opentok_keys');
const TwilioKeysModel = mongoose.model('Twilio_keys');
var nodemailer = require('nodemailer');
var async = require("async");
const emailSend = __rootRequire('app/core/email');
var path = require('path');
const twilioSms = __rootRequire('app/utils/twilioSms');


module.exports = {
	getSuperAdminProfileById: function(req, res, next){
        AdminModel.findOne({user_id: req.user.id})
            .populate('user_id', 'email')
            .then((result) => {
                res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    message: i18n.__("Get admin data succesfully")
                });
            }).catch((err) => {
                //__debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });
    },

    updateSuperAdminProfile: function (req, res, next) {
        if (req.body.imageFile) {
            var timestamp = Number(new Date()); // current time as number
            var imageFile =     req.body.imageFile;
            var filename = +timestamp + '_' + common.randomToken(6) + '.' + 'png';
            var imagePath = "./../client/users/assets/uploads/profile/" + filename;
        }

        function update() {
            User.findOne({
                email: req.body.email,
                _id: {
                    $ne: req.body.user_id._id
                }
            }, function (err, email) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR")
                    })
                } else {
                    if (email) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("Email Id already exist ! Try with different Email.")
                        })
                    } else {
                        var updateData = req.body;
                        if (filename) {
                            updateData.profile_pic = "/assets/uploads/profile/" + filename;
                        }
                        AdminModel.update({
                            _id: req.body._id
                        }, {
                            $set: updateData
                        }, function (err) {
                            if (err) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: req.body,
                                    message: i18n.__("ERROR")
                                })
                            } else {
                                User.update({
                                    _id: req.body.user_id._id
                                }, {
                                    $set: {
                                        email: req.body.email
                                    }
                                }, function (err) {
                                    if (err) {
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: req.body,
                                            message: i18n.__("ERROR")
                                        })
                                    } else {
                                        res.json({
                                            status: req.config.statusCode.success,
                                            data: req.body,
                                            message: i18n.__("Admin profile details updated succesfully")
                                        });
                                    }
                                })

                            }
                        })
                    }
                }
            });
        }


        if (req.body.imageFile) {
            // console.log("INSIDE req.body.imageFile", req.body.imageFile);
            var base64Data = req.body.imageFile.replace(/^data:image\/png;base64,/, "");
            base64Data += base64Data.replace('+', ' ');
            binaryData = new Buffer(base64Data, 'base64').toString('binary');
            fs.writeFile(imagePath, binaryData, "binary", function (err) {
                if (err) {
                    res.json({
                        code: 402,
                        'message': 'Request could not be processed. Please try again.',
                        data: {}
                    });
                } else {
                    update();
                }
            });
        } else {
            update();
        }
    },

    addLanguages: function(req, res, next){
        var data = {}
        data.language_name = req.body.language_name.toLowerCase();
        console.log("data.language_name", data.language_name);
        var language = new LanguageModel();
        language.language_name = data.language_name;
        language.save()
        .then((languageData)=>{
            res.json({
                status: req.config.statusCode.success,
                data: languageData,
                message: i18n.__("Language saved successfully")
            });
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("Error while adding language")
            })

        });
    },

    addCountries: function(req, res, next){
        var data = {}
        data.country_name = req.body.country_name.toLowerCase();
        data.country_code = req.body.country_code.toLowerCase();
        var countries = new CountriesModel();
        countries.country_name = data.country_name;
        countries.country_code = data.country_code;
        countries.save()
        .then((countryData)=>{
            res.json({
                status: req.config.statusCode.success,
                data: countryData,
                message: i18n.__("Country saved successfully")
            });
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("Error while adding country")
            })

        });
    },

    getAllLanguages: function(req, res, next){
        LanguageModel.find({is_deleted: false})
        .sort({language_name: 1})
        .then((languageData)=>{
            res.json({
                status: req.config.statusCode.success,
                data: languageData,
                message: i18n.__("Get all languages successfully")
            });
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("Error while getting languages")
            })

        });
    },

    getAllLanguagesForMultiselect: function(req, res, next){
        LanguageModel.find({is_deleted: false})
        .sort({language_name: 1})
        .then((languageData)=>{
            var obj = [];
            async.eachSeries(languageData,function(data,next){
                obj.push({
                    _id: data._id,
                    name: data.language_name.charAt(0).toUpperCase()+data.language_name.slice(1).toLowerCase(),
                    ticked: false
                })
                next();
                },function(err){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })
                    }else{
                        res.json({
                            status: req.config.statusCode.success,
                            data: obj,
                            message: i18n.__("Get languages successfully")
                        });
                    }
                })
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("Error while getting languages")
            })

        });
    },

    getAllCountries: function(req, res, next){
        CountriesModel.find({is_deleted: false})
        .sort({country_name: 1})
        .then((countryData)=>{
            res.json({
                status: req.config.statusCode.success,
                data: countryData,
                message: i18n.__("Get all countries successfully")
            });
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("Error while getting countries")
            })

        });
    },

    addServices: function(req, res, next){
        var service = new ServiceModel(req.body);
        service.save()
        .then((serviceData)=>{
            res.json({
                status: req.config.statusCode.success,
                data: serviceData,
                message: i18n.__("Service saved successfully")
            });
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("Error while adding service")
            })

        });
    },

    getAllServicesForMultiselect: function(req, res, next){
        ServiceModel.find({is_deleted: false,status: true})
        .sort({name: 1})
        .then((serviceData)=>{
            var obj = [];
            async.eachSeries(serviceData,function(data,next){
                obj.push({
                    _id: data._id,
                    name: data.name,
                    ticked: false
                })
                next();
                },function(err){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })
                    }else{
                        res.json({
                            status: req.config.statusCode.success,
                            data: obj,
                            message: i18n.__("Get services successfully")
                        });
                    }
                })
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("Error while getting services")
            })

        });
    },

    getAllLanguagesInInterpreter: function(req, res, next){
        LanguageModel.find({is_deleted: false})
        .sort({language_name: 1})
        .then((languageData)=>{
            res.json({
                status: req.config.statusCode.success,
                data: languageData,
                message: i18n.__("GET_LANGUAGE_SUCCESSFULLY")
            });            
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            })

        });
    },

    subscribe: function(req, res, next){
        SubscribeModel.findOne({email: req.body.email.toLowerCase(), is_deleted: false})
        .then((subscribeEmail) => {
            if(subscribeEmail){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("Email Id already subscribed! Try with different Email.")
                })
            }else{
                var subscribeModel = new SubscribeModel(req.body);
                subscribeModel.save()
                .then((subscribeData)=>{
                    if(!subscribeData){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        })
                    }else{
                        res.json({
                            status: req.config.statusCode.success,
                            data: subscribeData,
                            message: i18n.__("Email subscribe successfully.")
                        });
                    }
                })
            }    
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        });
    },

    getCountOfSuperAdmin: function(req, res, next) {
        SubscriptionModel.find({
            is_deleted:false
        }).count().then((subscriptionCount) => {
            if(!subscriptionCount){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                });
            }else{
                AgencyModel.find({
                    is_deleted:false
                }).count().then((agencyCount) => {
                    if(!agencyCount){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        });
                    }else{
                        ClientModel.find({
                            is_deleted: false
                        }).count().then((clientCount) => {
                            if(!clientCount){
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("ERROR")
                                });
                            }else{
                                InterpreterModel.find({
                                    is_deleted: false
                                }).count().then((interpreterCount) => {
                                    if(!interpreterCount){
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: {},
                                            message: i18n.__("ERROR")
                                        });
                                    }else{
                                        res.json({
                                            status: req.config.statusCode.success,
                                            data: {'countSubscription': subscriptionCount,
                                                   'countAgencies': agencyCount,
                                                   'countClient': clientCount,
                                                   'countInterpreter': interpreterCount
                                            },
                                            message: i18n.__('GET_COUNT_SUCCESSFULLY')
                                        });
                                    }       
                                })        
                            }
                        })
                    }
                })
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            });
        })
    },

    addStripeKeys: function(req, res, next){
        StripeKeysModel.findOneAndUpdate({status: true, is_deleted: false},{$set: {status:false}},function(err,data){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                }) 
            } else{
                var stripeKeys = new StripeKeysModel(req.body);
                stripeKeys.status = true;
                stripeKeys.save(function(err,stripeKeyData){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        })    
                    }else {
                        res.json({
                            status: req.config.statusCode.success,
                            data: stripeKeyData,
                            message: i18n.__("STRIPE_KEY_SAVE_SUCCESSFULLY")
                        });
                    }
                }).catch(function(err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })

                });
            }
        })
    },

    getStripeKeys: function(req, res, next){
        StripeKeysModel.findOne({status: true, is_deleted: false},function(err,stripeKeyData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })    
            }else {
                res.json({
                    status: req.config.statusCode.success,
                    data: stripeKeyData,
                    message: i18n.__("GET_STRIPE_KEY_SUCCESSFULLY")
                });
            }
        }).catch(function(err) {
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })

        });
    },

    updateStripeKeys: function(req, res, next){
        StripeKeysModel.findOneAndUpdate({_id: req.body.id, status: true, is_deleted: false},{status:false},{new: true},function(err,stripeKeyData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })    
            } else if(!stripeKeyData){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            } else {
                var stripeKeys = new StripeKeysModel();
                stripeKeys.publishable_key =  req.body.publishable_key;
                stripeKeys.secret_key =  req.body.secret_key;
                stripeKeys.save(function(err, savedData){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        })
                    }else{
                        res.json({
                            status: req.config.statusCode.success,
                            data: savedData,
                            message: i18n.__("STRIPE_KEY_UPDATED_SUCCESSFULLY")
                        });
                    }
                })

            }
        })
    },

    addTwilioKeys: function(req, res, next){
        TwilioKeysModel.findOneAndUpdate({status: true, is_deleted: false},{$set: {status:false}},function(err,data){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                }) 
            } else{
                var twilioKeys = new TwilioKeysModel(req.body);
                twilioKeys.status = true;
                twilioKeys.save(function(err,twilioKeyData){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        })    
                    }else {
                        res.json({
                            status: req.config.statusCode.success,
                            data: twilioKeyData,
                            message: i18n.__("TWILIO_KEY_SAVE_SUCCESSFULLY")
                        });
                    }
                }).catch(function(err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })

                });
            }
        })
    },

    getTwilioKeys: function(req, res, next){
        TwilioKeysModel.findOne({status: true, is_deleted: false},function(err,twilioKeyData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })    
            }else {
                res.json({
                    status: req.config.statusCode.success,
                    data: twilioKeyData,
                    message: i18n.__("GET_TWILIO_KEY_SUCCESSFULLY")
                });
            }
        }).catch(function(err) {
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })

        });
    },

    updateTwilioKeys: function(req, res, next){
        TwilioKeysModel.findOneAndUpdate({_id: req.body.id, status: true, is_deleted: false},{status:false},{new: true},function(err,twilioKeyData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })    
            } else if(!twilioKeyData){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            } else {
                var twilioKeys = new TwilioKeysModel();
                twilioKeys.accountSid =  req.body.accountSid;
                twilioKeys.authToken =  req.body.authToken;
                twilioKeys.application_sid =  req.body.application_sid;
                twilioKeys.toll_free_number =  req.body.toll_free_number;
                twilioKeys.save(function(err, savedData){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        })
                    }else{
                        res.json({
                            status: req.config.statusCode.success,
                            data: savedData,
                            message: i18n.__("TWILIO_KEY_UPDATED_SUCCESSFULLY")
                        });
                    }
                })
            }
        })
    },

    addOpentokKeys: function(req, res, next){
        OpentokKeysModel.findOneAndUpdate({status: true, is_deleted: false},{$set: {status:false}},function(err,data){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                }) 
            } else{
                var opentokKeys = new OpentokKeysModel(req.body);
                opentokKeys.status = true;
                opentokKeys.save(function(err,opentokKeyData){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        })    
                    }else {
                        res.json({
                            status: req.config.statusCode.success,
                            data: opentokKeyData,
                            message: i18n.__("OPENTOK_KEY_SAVE_SUCCESSFULLY")
                        });
                    }
                }).catch(function(err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })

                });
            }
        })
    },

    getOpentokKeys: function(req, res, next){
        OpentokKeysModel.findOne({status: true, is_deleted: false},function(err,opentokKeyData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })    
            }else {
                res.json({
                    status: req.config.statusCode.success,
                    data: opentokKeyData,
                    message: i18n.__("GET_OPENTOK_KEY_SUCCESSFULLY")
                });
            }
        }).catch(function(err) {
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })

        });
    },

    getOpentokKeysById: function(req, res, next){
        OpentokKeysModel.findOne({_id: req.params.id, status: true, is_deleted: false},function(err,opentokKeyData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })    
            }else {
                res.json({
                    status: req.config.statusCode.success,
                    data: opentokKeyData,
                    message: i18n.__("GET_OPENTOK_KEY_SUCCESSFULLY")
                });
            }
        }).catch(function(err) {
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })

        });
    },

    getTwilioKeysById: function(req, res, next){
        TwilioKeysModel.findOne({_id: req.params.id, status: true, is_deleted: false},function(err,twilioKeyData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })    
            }else {
                res.json({
                    status: req.config.statusCode.success,
                    data: twilioKeyData,
                    message: i18n.__("GET_TWILIO_KEY_SUCCESSFULLY")
                });
            }
        }).catch(function(err) {
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })

        });
    },

    getStripeKeysById: function(req, res, next){
        StripeKeysModel.findOne({_id: req.params.id, status: true, is_deleted: false},function(err,stripeKeyData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })    
            }else {
                res.json({
                    status: req.config.statusCode.success,
                    data: stripeKeyData,
                    message: i18n.__("GET_STRIPE_KEY_SUCCESSFULLY")
                });
            }
        }).catch(function(err) {
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })

        });
    },

    updateOpentokKeys: function(req, res, next){
        OpentokKeysModel.findOneAndUpdate({_id: req.body.id, status: true, is_deleted: false},{status:false},{new: true},function(err,opentokKeyData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })    
            } else if(!opentokKeyData){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            } else {
                var opentokKeys = new OpentokKeysModel();
                opentokKeys.apiKey =  req.body.apiKey;
                opentokKeys.apiSecret =  req.body.apiSecret;
                opentokKeys.save(function(err, savedData){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("ERROR")
                        })
                    }else{
                        res.json({
                            status: req.config.statusCode.success,
                            data: savedData,
                            message: i18n.__("OPENTOK_KEY_UPDATED_SUCCESSFULLY")
                        });
                    }
                })

            }
        })
    },

}