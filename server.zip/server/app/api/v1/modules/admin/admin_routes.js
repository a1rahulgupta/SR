module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];

    var admin_ctrl = require('./controllers/admin_ctrl');
    var user_ctrl = require('../user/controllers/user_ctrl');
    router.post('/admin/login', user_ctrl.login);

    //User Controller
    router.post('/admin/forgotPassword', user_ctrl.forgotPassword);
    router.post('/admin/setNewPassword', user_ctrl.setNewPassword);
    router.get('/admin/getEmailUsingPassword/:id', user_ctrl.getEmailUsingPassword);
    
    //Admin Controller
    router.get('/admin/getSuperAdminProfileById', middlewares, admin_ctrl.getSuperAdminProfileById);
    router.post('/admin/updateSuperAdminProfile', middlewares, admin_ctrl.updateSuperAdminProfile);
    router.post('/admin/addLanguages', middlewares, admin_ctrl.addLanguages);
    router.post('/admin/addCountries', middlewares, admin_ctrl.addCountries);
    router.get('/admin/getAllLanguages', middlewares, admin_ctrl.getAllLanguages);
    router.get('/admin/getAllCountries', middlewares, admin_ctrl.getAllCountries);
    router.post('/admin/addServices', middlewares, admin_ctrl.addServices);
    router.get('/admin/getAllLanguagesForMultiselect', middlewares, admin_ctrl.getAllLanguagesForMultiselect);
    router.get('/admin/getAllLanguagesInInterpreter', middlewares, admin_ctrl.getAllLanguagesInInterpreter);
    router.get('/admin/getAllServicesForMultiselect', middlewares, admin_ctrl.getAllServicesForMultiselect);
    router.post('/admin/subscribe',middlewares, admin_ctrl.subscribe);
    router.get('/admin/getCountOfSuperAdmin', middlewares, admin_ctrl.getCountOfSuperAdmin);

    router.post('/admin/addStripeKeys', middlewares, admin_ctrl.addStripeKeys);
    router.get('/admin/getStripeKeys', middlewares, admin_ctrl.getStripeKeys);
    router.post('/admin/updateStripeKeys', middlewares, admin_ctrl.updateStripeKeys);
    router.post('/admin/addTwilioKeys', middlewares, admin_ctrl.addTwilioKeys);
    router.get('/admin/getTwilioKeys', middlewares, admin_ctrl.getTwilioKeys);
    router.post('/admin/updateTwilioKeys', middlewares, admin_ctrl.updateTwilioKeys);
    router.post('/admin/addOpentokKeys', middlewares, admin_ctrl.addOpentokKeys);
    router.get('/admin/getOpentokKeys', middlewares, admin_ctrl.getOpentokKeys);
    router.post('/admin/updateOpentokKeys', middlewares, admin_ctrl.updateOpentokKeys);
    router.get('/admin/getStripeKeysById/:id', middlewares, admin_ctrl.getStripeKeysById);
    router.get('/admin/getTwilioKeysById/:id', middlewares, admin_ctrl.getTwilioKeysById);
    router.get('/admin/getOpentokKeysById/:id', middlewares, admin_ctrl.getOpentokKeysById);
    

}