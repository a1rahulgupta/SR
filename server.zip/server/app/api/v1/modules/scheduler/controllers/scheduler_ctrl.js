const _ = require("lodash");
const moment = require('moment');
const i18n = require("i18n");
const mongoose = require('mongoose');
const shortid = require('shortid');
const validator = __rootRequire('app/config/config.js');
const async = require('async');
var asyncEach = require('async-each-series');
const common = __rootRequire('app/config/common.js');
const waterfall = require('async-waterfall');
const uuidV4 = require('uuid/v4');
const fs = require('fs');   
const pdf = require('html-pdf');
const twilioSms = __rootRequire('app/utils/twilioSms');
const utility = __rootRequire('app/utils/utility');
//Models 
const User = mongoose.model('Users');
const AgencyModel = mongoose.model('Agencies');
const ClientModel = mongoose.model('Clients');
const InterpreterModel = mongoose.model('Interpreters');
const SubscriptionModel = mongoose.model('Subscriptions');
const AgencySubscriptionModel = mongoose.model('Agency_subscriptions');
const PaymentModel = mongoose.model('Payments');
const EmailTemplateModel = mongoose.model('Email_Templates');
const Booking = mongoose.model('Bookings');
const EventModel = mongoose.model('Events');
const SchedulerModel = mongoose.model('Schedulers');
const CheckInOutModel = mongoose.model('Check_in_outs');
const InterpreterLanguageModel = mongoose.model('Interpreter_languages');
const ReviewRatingModel = mongoose.model('ReviewRatings');
const BookingRequestModel = mongoose.model('Booking_request');
const SchedulerSkipModel = mongoose.model('Schedule_skips');
require('moment-recur');

module.exports = {
    listBookings: function (req, res, next) {
        req.query = santize.escape(req.query);

        var page = parseInt(req.query.page) - 1 || 0;
        var limit = parseInt(req.query.limit) || req.config.page.limit;
        var conditions = {};
        if(req.user.role == 'interpreter'){
         conditions = { is_deleted: false, interpreter_id: req.user.interpreter_id };
     }else if(req.user.role == 'client'){
         conditions = { is_deleted: false, client_id: req.user.client_id };
     }else{
        conditions = { agency_id: req.user.id, is_deleted: false };
    }

    Booking.where(conditions).count().exec().then((count) => {
            // __debug(count)
            Booking.find(conditions)
            .sort({ createdAt: -1 })
            .populate('client_id', 'first_name last_name _id')
            .populate('interpreter_id', 'first_name last_name _id')
            .exec()
            .then((bookings) => {
                return bookings
            }).then((bookings) => {
                res.json({
                    status: req.config.statusCode.success,
                    data: bookings,
                    count: count
                });
            })
            .catch((err) => {
                // __debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            })
        }).catch((err) => {
            // __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        });
    },

    addBooking: function (req, res, next) {
        AgencySubscriptionModel.findOne({agency_id: req.user.agency_id, status: true})
            .then((agencySubscriptionData)=>{
                SubscriptionModel.findOne({_id: agencySubscriptionData.subscription_id})
                    .then((subscriptionData)=>{
                        Booking.find({agency_id: req.user.id})
                            .then((bookingData)=>{
                                if(bookingData.length >= subscriptionData.booking_limit){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: req.body,
                                        message: i18n.__("BOOKING_LIMIT_REACHED")
                                    })
                                } else{
                                    genId();
                                    function addData(shortBookingId){
                                        req.body.booking_id = shortBookingId;
                                        booking = new Booking(req.body);
                                        booking.agency_id = req.user.id;
                                        booking.save()
                                        .then((result) => {
                                            res.json({
                                                status: req.config.statusCode.success,
                                                data: result,
                                                message: i18n.__("BOOKED_SUCCESSFULLY")
                                            });
                                        }).catch((err) => {
                                                //__debug(err)
                                                res.json({
                                                    status: req.config.statusCode.error,
                                                    data: req.body,
                                                    message: i18n.__("ERROR")
                                                })

                                            });
                                    }

                                    function genId(){
                                        var shortBookingId = validator.generateShortId();
                                        Booking.find({booking_id: shortBookingId}, function(err, bookingData) {
                                            if(err){
                                                res.json({
                                                    status: req.config.statusCode.error,
                                                    data: req.body,
                                                    message: i18n.__("ERROR")
                                                })
                                            } else if(bookingData.length>0){
                                                genId();
                                            } else{
                                                addData(shortBookingId);
                                            }
                                        })
                                    }
                                }
                            })
                    })
            }).catch((err) => {
                    //__debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })
            })
        
    },

    getBooking: function (req, res, next) {
        // console.log("inside getBooking", req.user);
        var conditions = {};
        if(req.user.role == 'interpreter'){
            conditions = { 
                _id: req.params.id
                // agency_id: req.user.agency_id,
                // interpreter_id: req.user.interpreter_id
            }
        }else{
            conditions = {
                _id: req.params.id,
                agency_id: req.user.id 
            }
        }
        Booking.findOne(conditions)
        .exec()
        .then((booking) => {
            res.json({
                status: req.config.statusCode.success,
                data: booking
            });
        })
        .catch((err) => {
            // __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    addEventName: function (req, res, next){
        console.log("Event Name");
        var event = new EventModel();
        event.event_name = req.body.event_name.toLowerCase();
        event.description = req.body.description.toLowerCase();
        event.save(function(err,eventData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                });      
            }else{
                res.json({
                    status: req.config.statusCode.success,
                    data: eventData,
                    message: i18n.__("EVENT_NAME_SAVED_SUCCESSFULLY")
                });
            }
        }).catch(function(err) {
            res.json({
                status: req.config.statusCode.error,
                data: {}, 
                message: i18n.__("ERROR")
            })

        });
    },

    getEventName: function (req, res, next) {
        EventModel.find({}).exec(function(err,eventData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });    
            }else if(eventData.length > 0){
                res.json({
                    status: req.config.statusCode.success,
                    data: eventData,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY") 
                });    
            }else{
                res.json({
                    status: req.config.statusCode.notFound,
                    data: [],
                    message: i18n.__("NO_RECORD_FOUND")
                });
            }
        }).catch(function(err){
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    addSchedule: function (req, res, next) {
        console.log("comes in addSchedule");
        AgencySubscriptionModel.findOne({agency_id: req.user.agency_id, status: true})
            .then((agencySubscriptionData)=>{
                SubscriptionModel.findOne({_id: agencySubscriptionData.subscription_id})
                    .then((subscriptionData)=>{
                        SchedulerModel.find({agency_id: req.user.agency_id})
                            .then((scheduleData)=>{
                                if(scheduleData.length >= subscriptionData.booking_limit){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("BOOKING_LIMIT_REACHED")
                                    })
                                } else{
                                    genId();
                                    function addData(shortBookingId){
                                        req.body.booking_short_id = shortBookingId;
                                        schedule = new SchedulerModel(req.body);
                                        schedule.agency_id = req.user.agency_id;
                                        if(req.body.is_recurring == true){
                                            console.log("found recurrence rule")

                                            EventModel.findOne({_id: req.body.event_id}).exec(function(err, eventData){
                                                if(err){
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: {},
                                                        message: i18n.__("ERROR")
                                                    });
                                                }else if(eventData) {
                                                    schedule.recurrence_rule = eventData.event_name;
                                                    schedule.save(function(err,saveSchedule) {
                                                        if(err){
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: {},
                                                                message: i18n.__("ERROR")
                                                            });     
                                                        }else{
                                                            console.log("saved schedule");

                                                            res.json({
                                                                status: req.config.statusCode.success,
                                                                data: req.body,
                                                                message: i18n.__("BOOKED_SUCCESSFULLY")
                                                            });
                                                        }
                                                    }).catch(function(err) {
                                                        res.json({ 
                                                            status: req.config.statusCode.error,
                                                            data: {},
                                                            message: i18n.__("ERROR")
                                                        })
                                                    });
                                                }else{
                                                    res.json({
                                                        status: req.config.statusCode.notFound,
                                                        data: {},
                                                        message: i18n.__("REPEAT_NAME_IS_MISSING")
                                                    });
                                                }
                                            })
                                        }else{
                                            schedule.save(function(err,saveSchedule) {
                                                if(err){
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: {},
                                                        message: i18n.__("ERROR")
                                                    });     
                                                }else{
                                                    res.json({
                                                        status: req.config.statusCode.success,
                                                        data: saveSchedule,
                                                        message: i18n.__("BOOKED_SUCCESSFULLY")
                                                    });
                                                }
                                            }).catch(function(err) {
                                                res.json({ 
                                                    status: req.config.statusCode.error,
                                                    data: {},
                                                    message: i18n.__("ERROR")
                                                })
                                            });
                                        }   
                                    }

                                    function genId(){
                                        var shortBookingId = validator.generateShortId();
                                        EventModel.find({booking_short_id: shortBookingId}, function(err, eventData) {
                                            if(err){
                                                res.json({
                                                    status: req.config.statusCode.error,
                                                    data: {},
                                                    message: i18n.__("ERROR")
                                                })
                                            } else if(eventData.length>0){
                                                genId();
                                            } else{
                                                addData(shortBookingId);
                                            }
                                        })
                                    }
                                }
                            })
                    })
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            })
        
    },


    getAllBookings: function (req, res, next) {
        var finalResponse = {};
        finalResponse.dateArray = [];
        finalResponse.currentMonthEvents = [];
        finalResponse.events = [];
        finalResponse.tempArr = [];

        var currentDate = moment(req.body.month_start_date);
        var stopDate = moment(req.body.month_end_date);
        var month_start_date = moment(req.body.month_start_date).startOf('day');
        var month_end_date = moment(req.body.month_end_date).startOf('day');
        // console.log("month_start_date",month_start_date);
        // console.log("month_end_date",month_end_date);
        var momentObjFrom = new Date(moment(month_start_date));
        var momentObjTo = new Date(moment(month_end_date));
        var schedulerObj = {
            month_start_date: momentObjFrom,
            month_end_date: momentObjTo
        }

        waterfall([
            function(callback) {
                while (currentDate <= stopDate) {
                    finalResponse.dateArray.push(moment(currentDate))
                    currentDate = moment(currentDate).add(1, 'days');
                }
                callback(null, finalResponse);
            },
            function(finalResponse, callback) {
                var condition = {};
                if(req.user.role == 'interpreter'){
                    condition = { 
                        agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                        interpreter_id: mongoose.Types.ObjectId(req.user.interpreter_id),
                        is_deleted:false,
                        $or:[
                            {$and:[
                                {start_date: {$gte: momentObjFrom}}, 
                                {start_date: {$lte: momentObjTo}}
                            ]},
                            {event_end_date: {$gte: momentObjFrom}}
                        ]
                    };
                }else if(req.user.role == 'client'){
                    condition = { 
                        agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                        client_id: mongoose.Types.ObjectId(req.user.client_id),
                        is_deleted:false,
                        $or:[
                            {$and:[
                                {start_date: {$gte: momentObjFrom}}, 
                                {start_date: {$lte: momentObjTo}}
                            ]},
                            {event_end_date: {$gte: momentObjFrom}}
                        ]
                    };
                }else{
                    condition = { 
                        agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                        is_deleted:false,
                        $or:[
                            {$and:[
                                {start_date: {$gte: momentObjFrom}}, 
                                {start_date: {$lte: momentObjTo}}
                            ]},
                            {event_end_date: {$gte: momentObjFrom}}
                        ]
                    };
                }

                if(req.body.client_id !=null && req.body.client_id !=undefined && req.body.client_id !=''){
                    condition.client_id = mongoose.Types.ObjectId(req.body.client_id);
                }

                // console.log(condition.$or[0])
                
                var aggregateQuery = [{
                    $match: condition
                },{
                    $lookup: {
                        from: 'schedule_skips',
                        localField: "_id",
                        foreignField: "scheduler_id",
                        as: "schedulerInfo"
                    }
                }
                ];
                
                SchedulerModel.aggregate(aggregateQuery).exec(function (err, result) {
                    if (err) {
                        callback(err, false);
                    } else if(result.length > 0) {
                        // console.log("get result in scheduler",result);
                        for (var i = result.length - 1; i >= 0; i--) {
                            finalResponse.currentMonthEvents.push(result[i])
                        }
                        callback(null, finalResponse);
                    }else{
                        console.log("result",result);
                        callback(null, finalResponse);
                    }
                })
            },
            function(finalResponse,callback){
                function getRandomColor (){
                    var letters = '0123456789ABCDEF';
                    var color = '#';
                    for (var i = 0; i < 6; i++) {
                        color += letters[Math.floor(Math.random() * 16)];
                    }
                    return color;
                }

                async.each(finalResponse.currentMonthEvents, function(value, callbackEvent) {
                    if(value.is_recurring == false){
                        // console.log("value", value);
                        var colorName = getRandomColor();
                        finalResponse.events.push({
                            start: moment(value.start_date), //$filter('dateFilter')(hol.HOLIDAY_START),
                            end: moment(value.end_date), //$filter('dateFilter')(hol.HOLIDAY_END),
                            title: value.service_title, //hol.HOLIDAY_TITLE,
                            color: colorName,//'#c23333', //$filter('colorEventFilter')(hol.HOLIDAY_EVENT_STATE_ID)
                            // EndsOn : moment(value.event_end_date),
                            parentId : "",
                            bookingDetail: value
                        });
                        callbackEvent();
                    }else{
                        if(value.recurrence_rule == 'daily'){
                            var colorName = getRandomColor();
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "daily", repeating_every_no, "");
                            if(recurringEventStartEndInterval.length > 0){
                                for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                    var dateExist = false;
                                    for(var x = 0; x < value.schedulerInfo.length; x++){

                                        if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                            dateExist = true;
                                            break;
                                        }else{
                                             dateExist = false;   
                                        }
                                    }
                                    if(dateExist){

                                    }else{
                                        if(recurringEventStartEndInterval[z].endEvent == ""){

                                        }else{
                                            finalResponse.events.push({
                                                start: recurringEventStartEndInterval[z].startEvent, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end: recurringEventStartEndInterval[z].endEvent, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                title: value.service_title, //hol.HOLIDAY_TITLE,
                                                color: colorName,//'#c23333', //$filter('colorEventFilter')(hol.HOLIDAY_EVENT_STATE_ID)
                                                EndsOn : value.event_end_date,
                                                parentId : value._id,
                                                bookingDetail: value
                                            });
                                        }
                                    }                                                                                                                                     
                               } 
                            }
                          
                        }else if(value.recurrence_rule == 'weekly'){
                            var colorName = getRandomColor();
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "weekly" , repeating_every_no, "");                    
                                if(recurringEventStartEndInterval.length > 0){
                                    for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                        var dateExist = false;
                                        for(var x = 0; x < value.schedulerInfo.length; x++){
                                            if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                                dateExist = true;
                                                break;
                                            }else{
                                                 dateExist = false;   
                                            }
                                        }
                                        if(dateExist){

                                        }else{
                                            if(recurringEventStartEndInterval[z].endEvent == ""){
                                        }else{
                                            finalResponse.events.push({
                                                start: recurringEventStartEndInterval[z].startEvent, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end: recurringEventStartEndInterval[z].endEvent,
                                                title: value.service_title, //hol.HOLIDAY_TITLE,
                                                color: colorName,//'#c23333', //$filter('colorEventFilter')(hol.HOLIDAY_EVENT_STATE_ID)
                                                EndsOn : value.event_end_date,
                                                parentId : value._id,
                                                bookingDetail: value                                
                                            });
                                        }
                                   
                                    }                                                                                                                                     
                               } 
                            } 

                        }
                        else if(value.recurrence_rule == 'monthly'){
                            var colorName = getRandomColor();
                            // console.log("colorName in months", colorName);
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "monthly", repeating_every_no, "");                    
                            if(recurringEventStartEndInterval.length > 0){
                                for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                    var dateExist = false;
                                    for(var x = 0; x < value.schedulerInfo.length; x++){

                                        if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                            dateExist = true;
                                            break;
                                        }else{
                                             dateExist = false;   
                                        }
                                    }
                                    if(dateExist){

                                    }else{
                                        if(recurringEventStartEndInterval[z].endEvent == ""){

                                        }else{
                                            finalResponse.events.push({
                                                start: recurringEventStartEndInterval[z].startEvent, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end: recurringEventStartEndInterval[z].endEvent,
                                                title: value.service_title, //hol.HOLIDAY_TITLE,
                                                color: colorName,//'#c23333', //$filter('colorEventFilter')(hol.HOLIDAY_EVENT_STATE_ID)
                                                EndsOn : value.event_end_date,
                                                parentId : value._id,
                                                bookingDetail: value                                   
                                            });
                                        }
                                   
                                    }                                                                                                                                     
                                } 
                            } 

                        }else if(value.recurrence_rule == 'yearly'){
                            var colorName = getRandomColor();
                            // console.log("colorName in yearly", colorName);
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "yearly", repeating_every_no, "");                    
                            if(recurringEventStartEndInterval.length > 0){
                                for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                    var dateExist = false;
                                    for(var x = 0; x < value.schedulerInfo.length; x++){
                                        if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                            dateExist = true;
                                            break;
                                        }else{
                                             dateExist = false;   
                                        }
                                    }
                                    if(dateExist){

                                    }else{
                                        if(recurringEventStartEndInterval[z].endEvent == ""){

                                        }else{
                                            finalResponse.events.push({
                                                start: recurringEventStartEndInterval[z].startEvent, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end: recurringEventStartEndInterval[z].endEvent, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                title: value.service_title, //hol.HOLIDAY_TITLE,
                                                color: colorName,//'#c23333', //$filter('colorEventFilter')(hol.HOLIDAY_EVENT_STATE_ID)
                                                EndsOn : value.event_end_date,
                                                parentId : value._id,
                                                bookingDetail: value
                                            });
                                        }
                                    }                                                                                                                                     
                               } 
                            }
                        }else if(value.recurrence_rule == 'custom (weekly)'){
                            var colorName = getRandomColor();
                            // console.log("in custom weekly",value.custom_weekly_repeat_on);
                            var weekArray = [];
                            for (var key in value.custom_weekly_repeat_on) {
                                // console.log("check", key, '->',value.custom_weekly_repeat_on[key]);
                                if(value.custom_weekly_repeat_on[key] == true){
                                    weekArray.push(key);
                                }
                            }
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "custom (weekly)", repeating_every_no, weekArray);                    
                            // console.log("recurringEventStartEndInterval of custom weekly", recurringEventStartEndInterval);
                            if(recurringEventStartEndInterval.length > 0){
                                for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                    var dateExist = false;
                                    for(var x = 0; x < value.schedulerInfo.length; x++){
                                        if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                            dateExist = true;
                                            break;
                                        }else{
                                             dateExist = false;   
                                        }
                                    }
                                    if(dateExist){

                                    }else{
                                        if(recurringEventStartEndInterval[z].endEvent == ""){

                                        }else{
                                            finalResponse.events.push({
                                                start: recurringEventStartEndInterval[z].startEvent, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end: recurringEventStartEndInterval[z].endEvent, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                title: value.service_title, //hol.HOLIDAY_TITLE,
                                                color: colorName,//'#c23333', //$filter('colorEventFilter')(hol.HOLIDAY_EVENT_STATE_ID)
                                                EndsOn : value.event_end_date,
                                                parentId : value._id,
                                                bookingDetail: value
                                            });
                                        }
                                    }                                                                                                                                     
                               } 
                            }
                        }
                        callbackEvent()

                        function getDayString(day){
                            var dayString = ""
                            switch (day) {
                                case 0:
                                    dayString = "Sunday";
                                    break;
                                case 1:
                                    dayString = "Monday";
                                    break;
                                case 2:
                                    dayString = "Tuesday";
                                    break;
                                case 3:
                                    dayString = "Wednesday";
                                    break;
                                case 4:
                                    dayString = "Thursday";
                                    break;
                                case 5:
                                    dayString = "Friday";
                                    break;
                                case 6:
                                    dayString = "Saturday";
                            }
                            return dayString;
                        }

                        function getMonthString(month_no){
                          var monthString = ""
                            switch (month_no) {
                                case 0:
                                    monthString = "January";
                                    break;
                                case 1:
                                    monthString = "February";
                                    break;
                                case 2:
                                    monthString = "March";
                                    break;
                                case 3:
                                    monthString = "April";
                                    break;
                                case 4:
                                    monthString = "May";
                                    break;
                                case 5:
                                    monthString = "June";
                                    break;
                                case 6:
                                    monthString = "July";
                                    break;
                                case 7:
                                    monthString = "August";
                                    break;
                                case 8:
                                    monthString = "September";
                                    break;
                                case 9:
                                    monthString = "October";
                                    break;
                                case 10:
                                    monthString = "November";
                                    break;
                                case 11:
                                    monthString = "December";
                                    break;    
                            }
                            return monthString;
                        }

                        function addHoursInDate(recurringWeeklyDateOnly, startHours, startMinutes){
                            var newRecurringWeeklyDateOnly = new Date(recurringWeeklyDateOnly);
                            newRecurringWeeklyDateOnly.setHours(startHours);
                            newRecurringWeeklyDateOnly.setMinutes(startMinutes);
                            return moment(newRecurringWeeklyDateOnly);
                        }

                        function convertVirtualEventsDateIntoDateTime(startTime,endTime,stopTimeDateTime,startTimeOnly,endTimeOnly, month_start_date, month_end_date, interval, repeating_every_no, weekArray){    //function to find the recurring inetrvals:start/end            
                            var recurringDateTimeStartEndOfEvent = [];      
                              
                            //start Event Calculation//
                            var eventStartTime = startTimeOnly;
                            var eventEndTime = endTimeOnly;

                            var month_start_date = moment(month_start_date).startOf('day');
                            var month_end_date = moment(month_end_date).startOf('day');
                            var momentObjMonth_start_date = new Date(moment(month_start_date));
                            var momentObjMonth_end_date = new Date(moment(month_end_date));

                            var tmpStartTime = convertTo24Format(startTimeOnly);
                            var tmpEndTime = convertTo24Format(endTimeOnly);
                              
                            var localStartDateTime =  moment(startTime).utc();
                            var localEndDateTime = moment(endTime).utc();

                            var localTimeStopTime =  moment(stopTimeDateTime).utc();                                         
                            var startHours = new Date(localStartDateTime).getHours();
                            var startMinutes = new Date(localStartDateTime).getMinutes();
                            var startDayString = getDayString(new Date(localStartDateTime).getDay());
                            var startDateOfMonth = new Date(localStartDateTime).getDate();
                            var startMonthOfYear = getMonthString(new Date(localStartDateTime).getMonth());
                            //end of event Calculation//

                            var endHours = new Date(localEndDateTime).getHours();
                            var endMinutes = new Date(localEndDateTime).getMinutes();
                            var endDayString = getDayString(new Date(localEndDateTime).getDay());
                            var endDateOfMonth = new Date(localEndDateTime).getDate();
                            var endMonthOfYear = getMonthString(new Date(localEndDateTime).getMonth());

                            if(interval == "daily"){
                                var recurringDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(1).days();
                                var recurringDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(1).days();
                                if(recurringDatesForStart.all().length > 0){
                                    for(var i = 0 ; i<recurringDatesForStart.all().length; i++){ 
                                        if(i%repeating_every_no == 0){
                                            var recurringDateOnly =  recurringDatesForStart.all()[i]
                                            var isafter = moment(recurringDateOnly).isAfter(momentObjMonth_end_date);
                                            if(isafter == true){
                                                break;
                                            }else{
                                                recurringDateTimeStartEndOfEvent.push({
                                                    startEvent : addHoursInDate(recurringDateOnly, startHours, startMinutes),
                                                    endEvent : ""
                                                });
                                                recurringDateOnly = "";
                                            }
                                        }else{
                                            continue;
                                        }
                                    }
                                }

                                if(recurringDatesForEnd.all().length > 0){
                                    var z = 0;
                                    for(var j = 0 ; j<recurringDatesForEnd.all().length; j++){
                                        if(j%repeating_every_no == 0){
                                            var recurringDateEndOnly =  recurringDatesForEnd.all()[j]
                                            var isafter = moment(recurringDateEndOnly).isAfter(momentObjMonth_end_date);
                                                if(isafter == true){
                                                break;
                                            }else{
                                                recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringDateEndOnly, endHours, endMinutes),
                                                recurringDateEndOnly = "";
                                                z++;
                                            }
                                        }else{
                                            continue;
                                        }
                                    }
                                }

                            }else if(interval == "weekly"){
                                var weekDayStartString = [];
                                var weekDayEndString = [];
                                weekDayStartString.push(startDayString);
                                weekDayEndString.push(endDayString)
                                
                                // var numb = 1;                                        
                                var recurringWeeklyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(weekDayStartString).daysOfWeek();
                                var recurringWeeklyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(weekDayEndString).daysOfWeek(); 
                                if(recurringWeeklyDatesForStart.all().length > 0){
                                    for(var i = 0; i<recurringWeeklyDatesForStart.all().length; i++){
                                        if(i%repeating_every_no == 0){
                                            var recurringWeeklyDateOnly =  recurringWeeklyDatesForStart.all()[i];
                                            var isafter = moment(recurringWeeklyDateOnly).isAfter(momentObjMonth_end_date);
                                          
                                            if(isafter == true){
                                                break;
                                            }else{
                                                recurringDateTimeStartEndOfEvent.push({
                                                    startEvent : addHoursInDate(recurringWeeklyDateOnly, startHours, startMinutes),
                                                    endEvent : ""
                                                });
                                                recurringWeeklyDateOnly = "";
                                            }
                                        }else{
                                            continue;
                                        }
                                    }
                                }
                                if(recurringWeeklyDatesForEnd.all().length > 0){
                                    var z = 0;
                                    for(var j = 0 ; j<recurringWeeklyDatesForEnd.all().length; j++){
                                        if(j%repeating_every_no == 0){
                                            var recurringWeeklyDateEndOnly =  recurringWeeklyDatesForEnd.all()[j]
                                            var isafter = moment(recurringWeeklyDateEndOnly).isAfter(momentObjMonth_end_date);
                                            if(isafter == true){
                                                break;
                                            }else{
                                                recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringWeeklyDateEndOnly, endHours, endMinutes),
                                                recurringWeeklyDateEndOnly = "";
                                                z++;
                                            }
                                        }else{
                                            continue;
                                        }
                                    }
                                } 
                            }else if(interval == "custom (weekly)"){
                                var weekDayStartString = weekArray;
                                var weekDayEndString = weekArray;
                                var arr = [];
                                var array1d = [];
                                var arr1d = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
                                for(var u=0; u<arr1d.length; u++){
                                    if(weekArray.indexOf(arr1d[u]) != -1){
                                        array1d.push(arr1d[u]);
                                    }
                                }

                                arr['sunday'] = 0;
                                arr['monday'] = 1;
                                arr['tuesday'] = 2;
                                arr['wednesday'] = 3;
                                arr['thursday'] = 4;
                                arr['friday'] = 5;
                                arr['saturday'] = 6;
                                var len = weekArray.length;
                                var recurringWeeklyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(weekDayStartString).daysOfWeek();
                                var recurringWeeklyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(weekDayEndString).daysOfWeek(); 
                                if(recurringWeeklyDatesForStart.all().length > 0){
                                    var t2,t3 = 0;
                                    // console.log("revWeekArray",weekArray);
                                    for(var p=0; p < weekArray.length; p++){
                                        t2 = getDayString(new Date(recurringWeeklyDatesForStart.all()[0]).getDay());
                                        // console.log("sdfshfgjhgjhhfjhd",arr[t2.toLowerCase()], arr[array1d[p].toLowerCase()]);

                                        // console.log("sdfshfgjhgjhhfjhd",t)
                                        t3++;
                                        if(arr[t2.toLowerCase()] <= arr[array1d[p].toLowerCase()] ){
                                            break;
                                        }
                                    }
                                    // console.log("@@@@@@@@@@@recurringWeeklyDatesForStart.all()", t3 );
                                    for(var i = t3; i <= recurringWeeklyDatesForStart.all().length; i++){
                                        var recurringWeeklyDateOnly =  recurringWeeklyDatesForStart.all()[i-t3];
                                        var isafter = moment(recurringWeeklyDateOnly).isAfter(momentObjMonth_end_date);
                                        if(isafter == true){
                                            break;
                                        }else{
                                            recurringDateTimeStartEndOfEvent.push({
                                                startEvent : addHoursInDate(recurringWeeklyDateOnly, startHours, startMinutes),
                                                endEvent : ""
                                            });
                                            recurringWeeklyDateOnly = "";
                                        }
                                        if( i%len  == 0 ){
                                            var skip  = len*repeating_every_no - len;
                                            i = i + skip; 
                                        }
                                    }
                                }
                                if(recurringWeeklyDatesForEnd.all().length > 0){
                                    var t2,t3 = 0;
                                    for(var p=0; p < weekArray.length; p++){
                                        t2 = getDayString(new Date(recurringWeeklyDatesForStart.all()[0]).getDay());
                                        // console.log("sdfshfgjhgjhhfjhd",arr[t2.toLowerCase()], arr[array1d[p].toLowerCase()]);
                                        // console.log("sdfshfgjhgjhhfjhd",t)
                                        t3++;
                                        if(arr[t2.toLowerCase()] <= arr[array1d[p].toLowerCase()] ){
                                            break;
                                        }
                                    }
                                    var z = 0;
                                    for(var j = t3 ; j <= recurringWeeklyDatesForEnd.all().length; j++){
                                        // console.log("z@@@@@@",recurringDateTimeStartEndOfEvent);
                                            var recurringWeeklyDateEndOnly =  recurringWeeklyDatesForEnd.all()[j-t3]
                                            var isafter = moment(recurringWeeklyDateEndOnly).isAfter(momentObjMonth_end_date);
                                            if(isafter == true){
                                                break;
                                            }else{
                                                recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringWeeklyDateEndOnly, endHours, endMinutes),
                                                recurringWeeklyDateEndOnly = "";
                                                z++;
                                            }
                                        if(j%len  == 0 ){
                                            var skip  = len*repeating_every_no - len;
                                            j = j + skip;
                                        }
                                    }
                                } 
                            }else if(interval == "monthly"){
                                var recurringMonthlyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(startDateOfMonth).dayOfMonth();
                                var recurringMonthlyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(endDateOfMonth).dayOfMonth();
                                if(recurringMonthlyDatesForStart.all().length > 0){
                                    for(var i = 0 ; i<recurringMonthlyDatesForStart.all().length; i++){
                                        if(i%repeating_every_no == 0){
                                            var recurringMonthDateOnly =  recurringMonthlyDatesForStart.all()[i]
                                            var isafter = moment(recurringMonthDateOnly).isAfter(momentObjMonth_end_date);
                                            if(isafter == true){
                                                break;
                                            }else{
                                                recurringDateTimeStartEndOfEvent.push({
                                                    startEvent :  addHoursInDate(recurringMonthDateOnly, startHours, startMinutes),
                                                    endEvent : ""
                                                });
                                                recurringMonthDateOnly = "";
                                            }
                                        }else{
                                            continue;
                                        }

                                    }
                                }
                                if(recurringMonthlyDatesForEnd.all().length > 0){
                                    var z = 0;
                                    for(var j = 0 ; j<recurringMonthlyDatesForEnd.all().length; j++){
                                        if(j%repeating_every_no == 0){
                                            var recurringMonthDateEndOnly =  recurringMonthlyDatesForEnd.all()[j];
                                            var isafter = moment(recurringMonthDateEndOnly).isAfter(momentObjMonth_end_date);
                                            if(isafter == true){
                                                break;
                                            }else{
                                                recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringMonthDateEndOnly, endHours, endMinutes),
                                                recurringMonthDateEndOnly = "";
                                                z++;
                                            }
                                        }else{
                                            continue;
                                        }
                                    }
                                }
                            }else if(interval == "yearly"){ 
                                var recurringYearlyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(startDateOfMonth).daysOfMonth().every(startMonthOfYear).monthsOfYear();
                                var recurringYearlyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(endDateOfMonth).daysOfMonth().every(endMonthOfYear).monthsOfYear();
                                if(recurringYearlyDatesForStart.all().length > 0){
                                    for(var i = 0 ; i<recurringYearlyDatesForStart.all().length; i++){
                                        if(i%repeating_every_no == 0){
                                            var recurringYearlyDateOnly =  recurringYearlyDatesForStart.all()[i]
                                            var isafter = moment(recurringYearlyDateOnly).isAfter(momentObjMonth_end_date);
                                            if(isafter == true){
                                                break;
                                            }else{
                                                recurringDateTimeStartEndOfEvent.push({
                                                  startEvent : addHoursInDate(recurringYearlyDateOnly, startHours, startMinutes),
                                                  endEvent : ""
                                                });
                                                recurringYearlyDateOnly = "";
                                            }
                                        }else{
                                            continue;
                                        }
                                    }
                                }
                                if(recurringYearlyDatesForEnd.all().length > 0){
                                    var z = 0;
                                    for(var j = 0 ; j<recurringYearlyDatesForEnd.all().length; j++){
                                        if(j%repeating_every_no == 0){
                                            var recurringYearlyDateEndOnly =  recurringYearlyDatesForEnd.all()[j]
                                            var isafter = moment(recurringYearlyDateEndOnly).isAfter(momentObjMonth_end_date);
                                            if(isafter == true){
                                                break;
                                            }else{
                                                recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringYearlyDateEndOnly, endHours, endMinutes),
                                                recurringYearlyDateEndOnly = "";
                                                z++;
                                            }
                                        }else{
                                            continue;
                                        }
                                    }
                                }  
                            }
                            return recurringDateTimeStartEndOfEvent;          
                        }

                        function convertTo24Format(timeStr){
                            var tmp=timeStr;
                            var tmpArr = tmp.split(':');
                            var t = tmpArr[1].split(' ')[1];
                            var hour= tmpArr[0].trim();
                            var minute= tmpArr[1].split(' ')[0];
                            if(t=='PM'){
                                if(hour!=12){
                                    hour = parseInt(hour) + 12;
                                }
                            } else if(t=='AM'){
                                if(hour==12){
                                    hour=0;
                                }
                            }
                            return { 'hour': hour, 'minute': minute};
                        }
                    }
                },function(err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        // console.log(finalResponse.events,'=======================================')
                        callback(null, finalResponse);
                    }
                });
            },
            function(finalResponse,callback){
                async.each(finalResponse.dateArray, function(date, cb) {
                    var obj = _.filter(finalResponse.events, function(d) { 
                        // console.log(d.start,'d.start',date)
                        return moment(date.format('YYYY-MM-DD')).isSame(d.start.format('YYYY-MM-DD')) 
                    });
                    if(obj.length > 0){
                        for (var i = obj.length - 1; i >= 0; i--) {
                            finalResponse.tempArr.push(obj[i]);
                        }
                        cb(null,finalResponse);
                    }else{
                        cb(null,finalResponse)
                    }
                }, function(err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            },

        ], function(err, data) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            } else {
                // console.log(data.events.length,'datadatadata')
                // console.log(data.tempArr.length,'tempArr length')
                // console.log(data.tempArr,'tempArr')
                res.json({
                    status: req.config.statusCode.success,
                    data: data.tempArr,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }
        });
    },

    updateCurrentOccurenceEvent: function(req, res, next){
        // console.log("update current occurence body", req.body);
        
        function updateRecord(newEventRecord){
            SchedulerModel.findOneAndUpdate({
                _id: req.body._id,
                agency_id: req.body.agency_id
            }, newEventRecord, {
                new: true
            }).exec(function(err,updateSchedule) {
                if(err){
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    });     
                }else{
                    res.json({
                        status: req.config.statusCode.success,
                        data: req.body,
                        message: i18n.__("EVENT_UPDATED_SUCCESSFULLY")
                    });
                }
            }).catch(function(err) {
                res.json({ 
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            });
        }

        function updateRecurringCommonRecord(newEventRecord){
            EventModel.findOne({_id: req.body.event_id}).exec(function(err, eventData){
                if(err){
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    });
                }else if(eventData) {
                    if(eventData.event_name == 'custom (weekly)'){
                        newEventRecord.custom_weekly_repeat_on = req.body.custom_weekly_repeat_on;
                    }
                    newEventRecord.recurrence_rule = eventData.event_name;
                    updateRecord(newEventRecord);
                }else{
                    res.json({
                        status: req.config.statusCode.notFound,
                        data: {},
                        message: i18n.__("REPEAT_NAME_IS_MISSING")
                    });
                }
            })   
        }

        AgencySubscriptionModel.findOne({agency_id: req.user.agency_id, status: true})
            .then((agencySubscriptionData)=>{
                SubscriptionModel.findOne({_id: agencySubscriptionData.subscription_id})
                    .then((subscriptionData)=>{
                        SchedulerModel.find({agency_id: req.user.agency_id})
                            .then((scheduleData)=>{
                                if(scheduleData.length >= subscriptionData.booking_limit){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("BOOKING_LIMIT_REACHED")
                                    })
                                } else{
                                    genId();
                                    function addData(shortBookingId){
                                        var newEventRecord = {
                                            agency_id: req.body.agency_id,
                                            start_time: req.body.start_time,
                                            end_time: req.body.end_time,
                                            service_title: req.body.service_title,
                                            client_id: req.body.client_id,
                                            address: req.body.address,
                                            start_date: req.body.start_date,
                                            end_date: req.body.end_date,
                                            language_interprete_from: req.body.language_interprete_from,
                                            language_interprete_into: req.body.language_interprete_into,
                                            booking_description: req.body.booking_description,
                                            lat: req.body.lat,
                                            lng: req.body.lng,
                                            is_recurring: req.body.is_recurring
                                        }

                                        if(req.body.contact_info != '' || req.body.contact_info !=null || req.body.contact_info !=undefined){
                                            newEventRecord.contact_info = req.body.contact_info;
                                        }

                                        if(req.body.notes != '' || req.body.notes !=null || req.body.notes !=undefined){
                                            newEventRecord.notes = req.body.notes;
                                        }

                                        if(req.body.is_recurring == true){
                                            newEventRecord.event_end_date = req.body.event_end_date;
                                            newEventRecord.event_id = req.body.event_id;
                                            newEventRecord.repeating_every_no = req.body.repeating_every_no;
                                        }else{
                                            delete newEventRecord["event_end_date"];
                                            delete newEventRecord["event_id"];
                                            delete newEventRecord["repeating_every_no"];
                                        }

                                        if(req.body.editEventName == 'series'){
                                            if(newEventRecord.is_recurring == true){
                                                updateRecurringCommonRecord(newEventRecord);  
                                            }else{
                                                updateRecord(newEventRecord);
                                            }
                                        }else if(req.body.editEventName == 'single'){
                                            if(newEventRecord.is_recurring == true){
                                                updateRecurringCommonRecord(newEventRecord);
                                            }else{
                                                updateRecord(newEventRecord);
                                            }
                                        }else if(req.body.editEventName == 'following'){
                                            if(newEventRecord.is_recurring == true){
                                                var parent_start_date = new Date(req.body.parent_start_date);
                                                var event_end_date = new Date(req.body.old_start_date);
                                                var end_date = new Date(req.body.old_end_date);
                                                event_end_date.setDate(event_end_date.getDate()-1);
                                                event_end_date.setHours(end_date.getHours());
                                                event_end_date.setMinutes(end_date.getMinutes());
                                                newEventRecord.booking_short_id = shortBookingId;
                                                schedule = new SchedulerModel(newEventRecord);
                                                if(event_end_date.getTime() < parent_start_date.getTime()){
                                                    EventModel.findOne({_id: req.body.event_id}).exec(function(err, eventData){
                                                        if(err){
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: {},
                                                                message: i18n.__("ERROR")
                                                            });
                                                        }else if(eventData) {
                                                            if(eventData.event_name == 'custom (weekly)'){
                                                                schedule.custom_weekly_repeat_on = req.body.custom_weekly_repeat_on;
                                                            }
                                                            schedule.recurrence_rule = eventData.event_name;
                                                            schedule.save(function(err,saveSchedule) {
                                                                if(err){
                                                                    res.json({
                                                                        status: req.config.statusCode.error,
                                                                        data: {},
                                                                        message: i18n.__("ERROR")
                                                                    });     
                                                                }else{
                                                                    SchedulerModel.findOneAndUpdate({
                                                                        _id: req.body._id
                                                                    }, {
                                                                        is_deleted: true
                                                                    }, {
                                                                        new: true
                                                                    })
                                                                    .exec(function(err, eventResult) {
                                                                        if(err){
                                                                            res.json({
                                                                                status: req.config.statusCode.error,
                                                                                data: {},
                                                                                message: i18n.__("ERROR")
                                                                            })
                                                                        }else{ 
                                                                            res.json({
                                                                                status: req.config.statusCode.success,
                                                                                data: req.body,
                                                                                message: i18n.__("EVENT_UPDATED_SUCCESSFULLY")
                                                                            });
                                                                        }
                                                                    }).catch(function(err) {
                                                                        res.json({
                                                                            status: req.config.statusCode.error,
                                                                            data: req.body,
                                                                            message: i18n.__("ERROR")
                                                                        })
                                                                    });   
                                                                }
                                                            }).catch(function(err) {
                                                                res.json({ 
                                                                    status: req.config.statusCode.error,
                                                                    data: {},
                                                                    message: i18n.__("ERROR")
                                                                })
                                                            });
                                                        }else{
                                                            res.json({
                                                                status: req.config.statusCode.notFound,
                                                                data: {},
                                                                message: i18n.__("REPEAT_NAME_IS_MISSING")
                                                            });
                                                        }
                                                    })
                                                }else{
                                                    EventModel.findOne({_id: req.body.event_id}).exec(function(err, eventData){
                                                        if(err){
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: {},
                                                                message: i18n.__("ERROR")
                                                            });
                                                        }else if(eventData) {
                                                            if(eventData.event_name == 'custom (weekly)'){
                                                                schedule.custom_weekly_repeat_on = req.body.custom_weekly_repeat_on;
                                                            }
                                                            schedule.recurrence_rule = eventData.event_name;
                                                            schedule.save(function(err,saveSchedule) {
                                                                if(err){
                                                                    res.json({
                                                                        status: req.config.statusCode.error,
                                                                        data: {},
                                                                        message: i18n.__("ERROR")
                                                                    });     
                                                                }else{
                                                                    SchedulerModel.findOneAndUpdate({
                                                                        _id: req.body._id
                                                                    }, {
                                                                        event_end_date: event_end_date
                                                                    }, {
                                                                        new: true
                                                                    })
                                                                    .exec(function(err, eventResult) {
                                                                        if(err){
                                                                            res.json({
                                                                                status: req.config.statusCode.error,
                                                                                data: {},
                                                                                message: i18n.__("ERROR")
                                                                            })
                                                                        }else{ 
                                                                            res.json({
                                                                                status: req.config.statusCode.success,
                                                                                data: req.body,
                                                                                message: i18n.__("EVENT_UPDATED_SUCCESSFULLY")
                                                                            });
                                                                        }
                                                                    }).catch(function(err) {
                                                                        res.json({
                                                                            status: req.config.statusCode.error,
                                                                            data: req.body,
                                                                            message: i18n.__("ERROR")
                                                                        })
                                                                    });   
                                                                }
                                                            }).catch(function(err) {
                                                                res.json({ 
                                                                    status: req.config.statusCode.error,
                                                                    data: {},
                                                                    message: i18n.__("ERROR")
                                                                })
                                                            });
                                                        }else{
                                                            res.json({
                                                                status: req.config.statusCode.notFound,
                                                                data: {},
                                                                message: i18n.__("REPEAT_NAME_IS_MISSING")
                                                            });
                                                        }
                                                    })    
                                                }                                                
                                            }else{
                                                var parent_start_date = new Date(req.body.parent_start_date);
                                                var event_end_date = new Date(req.body.old_start_date);
                                                var end_date = new Date(req.body.old_end_date);
                                                event_end_date.setDate(event_end_date.getDate()-1);
                                                event_end_date.setHours(end_date.getHours());
                                                event_end_date.setMinutes(end_date.getMinutes());
                                                newEventRecord.booking_short_id = shortBookingId;
                                                if(event_end_date.getTime() < parent_start_date.getTime()){
                                                    schedule = new SchedulerModel(newEventRecord);
                                                    schedule.save(function(err,saveSchedule) {
                                                        if(err){
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: {},
                                                                message: i18n.__("ERROR")
                                                            });     
                                                        }else{
                                                            SchedulerModel.findOneAndUpdate({
                                                                _id: req.body._id
                                                            }, {
                                                                is_deleted: true
                                                            }, {
                                                                new: true
                                                            })
                                                            .exec(function(err, eventResult) {
                                                                if(err){
                                                                    res.json({
                                                                        status: req.config.statusCode.error,
                                                                        data: {},
                                                                        message: i18n.__("ERROR")
                                                                    })
                                                                }else{    
                                                                    res.json({
                                                                        status: req.config.statusCode.success,
                                                                        data: req.body,
                                                                        message: i18n.__("EVENT_UPDATED_SUCCESSFULLY")
                                                                    });
                                                                }
                                                            }).catch(function(err) {
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: req.body,
                                                                    message: i18n.__("ERROR")
                                                                })
                                                            });
                                                        }
                                                    }).catch(function(err) {
                                                        res.json({ 
                                                            status: req.config.statusCode.error,
                                                            data: {},
                                                            message: i18n.__("ERROR")
                                                        })
                                                    });
                                                }else{
                                                    schedule = new SchedulerModel(newEventRecord);
                                                    schedule.save(function(err,saveSchedule) {
                                                        if(err){
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: {},
                                                                message: i18n.__("ERROR")
                                                            });     
                                                        }else{
                                                            SchedulerModel.findOneAndUpdate({
                                                                _id: req.body._id
                                                            }, {
                                                                event_end_date: event_end_date
                                                            }, {
                                                                new: true
                                                            })
                                                            .exec(function(err, eventResult) {
                                                                if(err){
                                                                    res.json({
                                                                        status: req.config.statusCode.error,
                                                                        data: {},
                                                                        message: i18n.__("ERROR")
                                                                    })
                                                                }else{    
                                                                    res.json({
                                                                        status: req.config.statusCode.success,
                                                                        data: req.body,
                                                                        message: i18n.__("EVENT_UPDATED_SUCCESSFULLY")
                                                                    });
                                                                }
                                                            }).catch(function(err) {
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: req.body,
                                                                    message: i18n.__("ERROR")
                                                                })
                                                            });
                                                        }
                                                    }).catch(function(err) {
                                                        res.json({ 
                                                            status: req.config.statusCode.error,
                                                            data: {},
                                                            message: i18n.__("ERROR")
                                                        })
                                                    });
                                                }
                                                
                                            }
                                        }else{
                                            if(newEventRecord.is_recurring == true){
                                                newEventRecord.booking_short_id = shortBookingId;
                                                schedule = new SchedulerModel(newEventRecord);

                                                EventModel.findOne({_id: req.body.event_id}).exec(function(err, eventData){
                                                    if(err){
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: {},
                                                            message: i18n.__("ERROR")
                                                        });
                                                    }else if(eventData) {
                                                        if(eventData.event_name == 'custom (weekly)'){
                                                            schedule.custom_weekly_repeat_on = req.body.custom_weekly_repeat_on;
                                                        }
                                                        schedule.recurrence_rule = eventData.event_name;
                                                        schedule.save(function(err,saveSchedule) {
                                                            if(err){
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: {},
                                                                    message: i18n.__("ERROR")
                                                                });     
                                                            }else{
                                                                var skipData = SchedulerSkipModel();
                                                                skipData.agency_id = saveSchedule.agency_id;
                                                                skipData.scheduler_id = req.body._id;
                                                                skipData.start_date = req.body.parent_start_date;
                                                                skipData.end_date = req.body.parent_end_date;
                                                                skipData.save(function(err,skipData){
                                                                    if(err){
                                                                        res.json({
                                                                            status: req.config.statusCode.error,
                                                                            data: {},
                                                                            message: i18n.__("ERROR")
                                                                        });
                                                                    }else{
                                                                        res.json({
                                                                            status: req.config.statusCode.success,
                                                                            data: req.body,
                                                                            message: i18n.__("EVENT_UPDATED_SUCCESSFULLY")
                                                                        });
                                                                    }
                                                                })
                                                            }
                                                        }).catch(function(err) {
                                                            res.json({ 
                                                                status: req.config.statusCode.error,
                                                                data: {},
                                                                message: i18n.__("ERROR")
                                                            })
                                                        });
                                                    }else{
                                                        res.json({
                                                            status: req.config.statusCode.notFound,
                                                            data: {},
                                                            message: i18n.__("REPEAT_NAME_IS_MISSING")
                                                        });
                                                    }
                                                })
                                            }else{
                                                newEventRecord.booking_short_id = shortBookingId;
                                                schedule = new SchedulerModel(newEventRecord);
                                                schedule.save(function(err,saveSchedule) {
                                                    if(err){
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: {},
                                                            message: i18n.__("ERROR")
                                                        });     
                                                    }else{
                                                        var skipData = SchedulerSkipModel();
                                                        skipData.agency_id = saveSchedule.agency_id;
                                                        skipData.scheduler_id = req.body._id;
                                                        skipData.start_date = req.body.parent_start_date;
                                                        skipData.end_date = req.body.parent_end_date;
                                                        skipData.save(function(err,skipData){
                                                            if(err){
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: {},
                                                                    message: i18n.__("ERROR")
                                                                });
                                                            }else{
                                                                res.json({
                                                                    status: req.config.statusCode.success,
                                                                    data: req.body,
                                                                    message: i18n.__("EVENT_UPDATED_SUCCESSFULLY")
                                                                });
                                                            }
                                                        })
                                                    }
                                                }).catch(function(err) {
                                                    res.json({ 
                                                        status: req.config.statusCode.error,
                                                        data: {},
                                                        message: i18n.__("ERROR")
                                                    })
                                                });
                                            }     
                                        }
                                        
                                    }

                                    function genId(){
                                        var shortBookingId = validator.generateShortId();
                                        EventModel.find({booking_short_id: shortBookingId}, function(err, eventData) {
                                            if(err){
                                                res.json({
                                                    status: req.config.statusCode.error,
                                                    data: {},
                                                    message: i18n.__("ERROR")
                                                })
                                            } else if(eventData.length>0){
                                                genId();
                                            } else{
                                                addData(shortBookingId);
                                            }
                                        })
                                    }
                                }
                            })
                    })
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            })
    },

    deleteAllEvent: function (req, res, next) {
        SchedulerModel.findOneAndUpdate({
            _id: req.body.id
        }, {
            is_deleted: true
        }, {
            new: true
        })
        .exec(function(err, eventResult) {
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            }else{ 
                res.json({
                    status: req.config.statusCode.success,
                    data: req.body,
                    message: i18n.__("EVENT_DELETED_SUCCESSFULLY")
                });
            }
        }).catch(function(err) {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })
        });

    },

    deleteCurrentEvent: function (req, res, next) {
        var skipData = SchedulerSkipModel();
        skipData.agency_id = req.body.agency_id;
        skipData.scheduler_id = req.body._id;
        skipData.start_date = req.body.start_date;
        skipData.end_date = req.body.end_date;
        skipData.save(function(err,skipData){
            if(err){
                console.log(err);
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                });
            }else{
                res.json({
                    status: req.config.statusCode.success,
                    data: req.body,
                    message: i18n.__("EVENT_DELETED_SUCCESSFULLY")
                });
            }
        }).catch(function(err) {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })
        });
    },

    deleteEvent: function (req, res, next) {
        SchedulerModel.findOneAndUpdate({
            _id: req.params.id,
            agency_id: req.user.agency_id
        }, {
            is_deleted: true
        }, {
            new: true
        })
        .exec(function(err, result) {
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            }else{
                res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    message: i18n.__("EVENT_DELETED_SUCCESSFULLY")
                });
            }
        }).catch(function(err) {
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        });
    },

    deleteCurrentAndFollowingEvents: function (req, res, next) {
        var parent_start_date = new Date(req.body.parent_start_date); 
        var event_end_date = new Date(req.body.start_date);
        var end_date = new Date(req.body.end_date);
        event_end_date.setDate(event_end_date.getDate()-1);
        event_end_date.setHours(end_date.getHours());
        event_end_date.setMinutes(end_date.getMinutes());
        if(event_end_date.getTime() < parent_start_date.getTime()){
            SchedulerModel.findOneAndUpdate({
                _id: req.body._id
            }, {
                is_deleted: true
            }, {
                new: true
            })
            .exec(function(err, eventResult) {
                if(err){
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                }else{ 
                    res.json({
                        status: req.config.statusCode.success,
                        data: req.body,
                        message: i18n.__("EVENT_DELETED_SUCCESSFULLY")
                    });
                }
            }).catch(function(err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })
            });    
        }else{
            SchedulerModel.findOneAndUpdate({
                _id: req.body._id
            }, {
                event_end_date: event_end_date
            }, {
                new: true
            })
            .exec(function(err, eventResult) {
                if(err){
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                }else{ 
                    console.log("eventResult***********", eventResult)
                    res.json({
                        status: req.config.statusCode.success,
                        data: req.body,
                        message: i18n.__("EVENT_DELETED_SUCCESSFULLY")
                    });
                }
            }).catch(function(err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })
            });
        }
    },

    getAgencyEventList: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            is_deleted: false
        }

        if(req.body.client_id){
            condition.client_id = mongoose.Types.ObjectId(req.body.client_id);
        }
        
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                    'service_title': new RegExp(searchText, 'gi')
                },
                {
                    'booking_short_id': new RegExp(searchText, 'gi')
                },
                {
                    'clientInfo.first_name': new RegExp(searchText, 'gi')
                },
                {
                    'clientInfo.last_name': new RegExp(searchText, 'gi')
                }
            ];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'clients',
                localField: "client_id",
                foreignField: "_id",
                as: "clientInfo"
            }
        },
        {
            $unwind: {
                path: "$clientInfo",
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $match: condition
        }, {
            $lookup: {
                from: 'interpreters',
                localField: "interpreter_id",
                foreignField: "_id",
                as: "interpreterInfo"
            }
        }, {
            $unwind: {
                path: "$interpreterInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $match: condition
        }

        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        SchedulerModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                SchedulerModel.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    searchBookingByDateScheduler: function (req, res, next) {
        var dateFrom = moment(req.body.searchFrom).startOf('day');
        var dateTo = moment(req.body.searchTo).endOf('day');
        var momentObjFrom = new Date(moment(dateFrom));
        var momentObjTo = new Date(moment(dateTo));
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        if(req.user.role == 'interpreter'){
            condition = { 
                interpreter_id: mongoose.Types.ObjectId(req.user.interpreter_id), 
                agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                is_deleted: false,
                $and:[
                    {start_date: {$gte: momentObjFrom}}, 
                    {end_date: {$lte: momentObjTo}}
                ]
            };
        }else if(req.user.role == 'client'){
            condition = {
                client_id: mongoose.Types.ObjectId(req.user.client_id), 
                agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                is_deleted: false,
                $and:[
                    {start_date: {$gte: momentObjFrom}}, 
                    {end_date: {$lte: momentObjTo}}
                ]
            };
        }else{
            condition = { 
                agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                is_deleted: false,
                $and:[
                    {start_date: {$gte: momentObjFrom}}, 
                    {end_date: {$lte: momentObjTo}}
                ]
            };
        }


        var aggregateQuery = [{
            $lookup: {
                from: 'clients',
                localField: "client_id",
                foreignField: "_id",
                as: "clientInfo"
            }
        },
        {
            $unwind: {
                path: "$clientInfo",
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $match: condition
        }, {
            $lookup: {
                from: 'interpreters',
                localField: "interpreter_id",
                foreignField: "_id",
                as: "interpreterInfo"
            }
        }, {
            $unwind: {
                path: "$interpreterInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $match: condition
        }

        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        SchedulerModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                SchedulerModel.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

     getEventViewById: function (req, res, next) {
        SchedulerModel.findOne({_id: req.params.id})
        .populate('interpreter_id', 'first_name last_name mobile_no profile_pic')
        .populate('client_id', 'first_name last_name mobile_no profile_pic')
        .populate('language_interprete_from', 'language_name')
        .populate('language_interprete_into', 'language_name')
        .exec()
        .then((booking) => {
            res.json({
                status: req.config.statusCode.success,
                data: booking
            });
        })
        .catch((err) => {
            __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    getEventById: function (req, res, next) {
        if(mongoose.Types.ObjectId.isValid(req.params.id)){
            var conditions = {};
            if(req.user.role == 'interpreter'){
                conditions = { 
                    _id: req.params.id
                }
            }else{
                conditions = {
                    _id: req.params.id,
                    agency_id: req.user.agency_id 
                }
            }
            SchedulerModel.findOne(conditions)
            .exec()
            .then((booking) => {
                res.json({
                    status: req.config.statusCode.success,
                    data: booking
                });
            })
            .catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            })
        }else{
            res.json({
                status: req.config.statusCode.invalid,
                data: [],
                message: i18n.__("INVALID_ID")
            });
        }
    },

    deleteEvent: function (req, res, next) {
        SchedulerModel.findOneAndUpdate({
            _id: req.params.id,
            agency_id: req.user.agency_id
        }, {
            is_deleted: true
        }, {
            new: true
        })
        .then((result) => {
            res.json({
                status: req.config.statusCode.success,
                data: result,
                message: i18n.__("BOOKING_DELETED_SUCCESSFULLY")
            });
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })
        });
    },

    getEventInterpretersLocation: function (req, res, next) {
        SchedulerModel.findOne({_id: req.body.id})
        .populate('interpreter_id', 'first_name last_name')
        .populate('client_id', 'first_name last_name')
        .populate('language_interprete_from', 'language_name')
        .populate('language_interprete_into', 'language_name')
        .exec()
        .then((booking) => {
            var bookingStartTime = moment(booking.start_time, "HH:mm a");
            var bookingEndTime = moment(booking.end_time, "HH:mm a");
            var booking_from_day = moment(booking.start_date).format('dddd').toLowerCase();
            // console.log("booking_from_day",booking_from_day);
            // console.log("bookingStartTime",bookingStartTime);
            // console.log("bookingEndTime",bookingEndTime);
            var interpreterCondition = {
                agency_id: req.user.agency_id,
                status: true
            };
            InterpreterModel.find(interpreterCondition,{lat: 1, lng: 1, first_name: 1, last_name: 1, working_from: 1, working_to: 1, working_days: 1 }).exec(function(err, interpretersArray){
                if(err){
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        interpretersArray: [],
                        interpretersData: [],
                        message: i18n.__("ERROR")
                    });
                }else if(interpretersArray){          
                    var languageMatchedInterpretersArray = [];
                    async.eachSeries(interpretersArray, function(iterativeInterpreter, firstNext){
                        console.log("in async series");
                        InterpreterLanguageModel.findOne({
                            agency_id: req.user.agency_id,
                            interpreter_id: iterativeInterpreter._id,
                            language_id: booking.language_interprete_from._id,
                            is_deleted: false
                         }).exec(function(err,iterativeInterpreterLanguageMatched){
                            if(err){
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("ERROR")
                                });
                            }else if(iterativeInterpreterLanguageMatched){
                                if(iterativeInterpreter.working_days[booking_from_day] == true){
                                    var interpreterStartTime = moment(iterativeInterpreter.working_from, "HH:mm a");
                                    var interpreterEndTime = moment(iterativeInterpreter.working_to, "HH:mm a");
                                    console.log("interpreterStartTime", interpreterStartTime);
                                    console.log("interpreterEndTime", interpreterEndTime);
                                    if(bookingStartTime.hour() >= interpreterStartTime.hour() && bookingEndTime.hour() <= interpreterEndTime.hour()){
                                        if(bookingEndTime.minutes() <= interpreterEndTime.minutes()){
                                            console.log("found in booking time");
                                            var interpreterlanguageMatch = {};
                                            interpreterlanguageMatch = iterativeInterpreter;
                                            languageMatchedInterpretersArray.push(interpreterlanguageMatch); 
                                            firstNext();
                                        }else{
                                            firstNext();
                                        }    
                                    }else{
                                        firstNext();
                                    }
                                }else{
                                    firstNext();
                                }
                            }else{
                                console.log("not found marker interpreter language");
                                firstNext();
                            }
                         })    
                           
                    },function(err){
                        if(err){
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        }else{
                            console.log("languageMatchedInterpretersArray",languageMatchedInterpretersArray);
                            BookingRequestModel.find({booking_id: booking._id,status: true}).populate('interpreter_id').exec(function(err,selectedInterpreters){
                                if(err){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        interpretersArray: [],
                                        interpretersData: [],
                                        message: i18n.__("ERROR")
                                    });     
                                }else if(selectedInterpreters){
                                    var selectedInterpretersArray = [];
                                    async.eachSeries(selectedInterpreters, function(selectedInterpreter, next){
                                        //Start Rating
                                        var selectedNewInterpreter = {};
                                        selectedNewInterpreter = selectedInterpreter.toObject();
                                        ReviewRatingModel.aggregate([
                                            { $match: { interpreter_id: mongoose.Types.ObjectId(selectedNewInterpreter._id), is_deleted: false } }, {
                                                "$group": {
                                                    "_id": '$rating_to',
                                                    "avgRating": { "$avg": { "$ifNull": ["$rating", 0] } }
                                                }
                                            }
                                        ], function(err, rating) {
                                            var rate = 0;
                                            if (rating[0]) {
                                                if (rating[0].avgRating) {
                                                    rate = rating[0].avgRating;
                                                }
                                            }
                                            selectedNewInterpreter.rate = rate;
                                            selectedInterpretersArray.push(selectedNewInterpreter);
                                            next();     
                                        });
                                        //End rating   
                                    },function(err){
                                      if(err){
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: {},
                                            message: i18n.__("ERROR")
                                        })
                                      }else{
                                            var current_lng = parseFloat(booking.lng),
                                            current_lat = parseFloat(booking.lat);
                                            maxDistance = req.body.radiusInMeter; // 1 Mile = 1609.34 Meter
                                            var condition = {agency_id: req.user.agency_id};
                                            condition.location = {
                                                $near: {
                                                    $geometry: {
                                                        type: "Point",
                                                        coordinates: [current_lng, current_lat]
                                                    },
                                                    $minDistance: 0,
                                                    $maxDistance: maxDistance
                                                }
                                            };
                                            condition.status = true;
                                            InterpreterModel.find(condition).exec(function(err,interpretersDetails){
                                                if(err){
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: {},
                                                        message: i18n.__("ERROR")
                                                    });
                                                }else if(interpretersDetails){
                                                    console.log("interpretersDetails########",interpretersDetails);
                                                    var interpretersData = [];
                                                    async.eachSeries(interpretersDetails, function(singleInterpreter, next){
                                                        
                                                        InterpreterLanguageModel.findOne({
                                                            agency_id: req.user.agency_id,
                                                            interpreter_id: singleInterpreter._id,
                                                            language_id: booking.language_interprete_from._id,
                                                            is_deleted: false
                                                         }).exec(function(err,interpreterLanguageMatched){
                                                            if(err){
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: {},
                                                                    message: i18n.__("ERROR")
                                                                });
                                                            }else if(interpreterLanguageMatched){
                                                                if(singleInterpreter.working_days[booking_from_day] == true){
                                                                    console.log("singleInterpreter",singleInterpreter);

                                                                    var availableInterpreterStartTime = moment(singleInterpreter.working_from, "HH:mm a");
                                                                    var availableInterpreterEndTime = moment(singleInterpreter.working_to, "HH:mm a");
                                                                    console.log("availableInterpreterStartTime", availableInterpreterStartTime );
                                                                    console.log("availableInterpreterEndTime", availableInterpreterEndTime);
                                                                    if(bookingStartTime.hour() >= availableInterpreterStartTime.hour() && bookingEndTime.hour() <= availableInterpreterEndTime.hour()){
                                                                        console.log("bookingEndTime.minutes()",bookingEndTime.minutes());
                                                                        console.log("availableInterpreterEndTime.minutes()",availableInterpreterEndTime.minutes());
                                                                        if(bookingEndTime.minutes() <= availableInterpreterEndTime.minutes()){
                                                                            console.log("found in available booking time");
                                                                            //Start Rating
                                                                            var singleNewInterpreter = {};
                                                                            singleNewInterpreter = singleInterpreter.toObject();
                                                                            ReviewRatingModel.aggregate([
                                                                                { $match: { interpreter_id: mongoose.Types.ObjectId(singleInterpreter._id), is_deleted: false } }, {
                                                                                    "$group": {
                                                                                        "_id": '$rating_to',
                                                                                        "avgRating": { "$avg": { "$ifNull": ["$rating", 0] } }
                                                                                    }
                                                                                }
                                                                            ], function(err, rating) {
                                                                                var rate = 0;
                                                                                if (rating[0]) {
                                                                                    if (rating[0].avgRating) {
                                                                                        rate = rating[0].avgRating;
                                                                                    }
                                                                                }
                                                                                singleNewInterpreter.rate = rate;
                                                                                singleNewInterpreter.selected = false;
                                                                                async.eachSeries(selectedInterpretersArray, function(checkedInterpreter, next){
                                                                                    if(_.isEqual(singleNewInterpreter._id,checkedInterpreter.interpreter_id._id)){
                                                                                        singleNewInterpreter.selected = true;
                                                                                        next();
                                                                                    }else{
                                                                                        next();
                                                                                    }
                                                                                },function(err){
                                                                                  if(err){
                                                                                    res.json({
                                                                                        status: req.config.statusCode.error,
                                                                                        data: {},
                                                                                        message: i18n.__("ERROR")
                                                                                    })
                                                                                  }else{
                                                                                    interpretersData.push(singleNewInterpreter);
                                                                                    next(); 
                                                                                  }
                                                                                })  
                                                                            });
                                                                            //End rating
                                                                        }else{
                                                                            console.log("comes in founddddd");
                                                                            next();
                                                                        }
                                                                    }else{
                                                                        next();
                                                                    }
                                                                }else{
                                                                    next();
                                                                }    
                                                            }else{
                                                                console.log("not found matched language");
                                                                next();
                                                            }
                                                        })    
                                                    },function(err){
                                                        if(err){
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: {},
                                                                message: i18n.__("ERROR")
                                                            })
                                                        }else{
                                                            if(languageMatchedInterpretersArray.length>0){
                                                                res.json({
                                                                    status: req.config.statusCode.success,
                                                                    data: booking,
                                                                    interpretersArray: languageMatchedInterpretersArray,
                                                                    interpretersData: interpretersData,
                                                                    selectedInterpretersArray: selectedInterpretersArray, 
                                                                    message: i18n.__("Record found") 
                                                                });
                                                            }else{
                                                                res.json({
                                                                    status: req.config.statusCode.success,
                                                                    data: booking,
                                                                    interpretersArray: languageMatchedInterpretersArray,
                                                                    interpretersData: interpretersData,
                                                                    selectedInterpretersArray: selectedInterpretersArray, 
                                                                    message: i18n.__("INTERPRETERS_NOT_AVAILABLE_FOR_THIS_BOOKING") 
                                                                });
                                                            }
                                                        }
                                                    })
                                                }else{
                                                   res.json({
                                                        status: req.config.statusCode.notFound,
                                                        data: {},
                                                        interpretersArray: [],
                                                        interpretersData: [],
                                                        selectedInterpretersArray: [],
                                                        message: i18n.__("NO_RECORD_FOUND")
                                                    });
                                                }
                                            })      
                                        }
                                    })
                                }else{
                                    res.json({
                                        status: req.config.statusCode.notFound,
                                        data: {},
                                        interpretersArray: [],
                                        interpretersData: [],
                                        selectedInterpretersArray: [],
                                        message: i18n.__("NO_RECORD_FOUND")
                                    });        
                                }
                            })
                        }
                    })


                    
                    
                }else{
                    res.json({
                        status: req.config.statusCode.notFound,
                        data: {},
                        interpretersArray: [],
                        interpretersData: [],
                        selectedInterpretersArray: [],
                        message: i18n.__("NO_RECORD_FOUND")
                    });
                }
            })
        })
        .catch(function(err){
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            });
        })
    },

    sendEventRequestToInterpreters: function (req, res, next) {
        var booking = req.body.booking;
        var interpreterSelectedArray = req.body.interpreterSelectedArray;
        async.eachSeries(req.body.interpreterSelectedArray, function(selectedInterpreter, next){
            if(req.config.env == 'aws'){
                var baseUrl = 'https://www.interpreting.works';
            }else{
                var baseUrl = req.config.email.base_url;
            }
            var request_token = uuidV4();
            if(booking.is_recurring == true){
                var repeating_interval = ''; 
                if(booking.recurrence_rule == 'daily'){
                    repeating_interval = 'Day'
                }else if(booking.recurrence_rule == 'weekly' ||  booking.recurrence_rule == 'custom (weekly)'){
                    repeating_interval = 'Week'
                }else if(booking.recurrence_rule == 'monthly'){
                    repeating_interval = 'Month'
                }else if(booking.recurrence_rule == 'yearly'){
                    repeating_interval = 'Year'
                }
                var text = "You received a new recurring booking request for service title:"+ ' ' + booking.service_title+ ', Start Date: '+moment(booking.start_date).format("MM-DD-YYYY")+ ', End Date: '+ moment(booking.end_date).format("MM-DD-YYYY")+ ', End On: '+ moment(booking.event_end_date).format("MM-DD-YYYY")+ ', Time: '+booking.start_time+ ' to '+booking.end_time +', language from: '+  booking.language_interprete_from.language_name.charAt(0).toUpperCase()+booking.language_interprete_from.language_name.slice(1).toLowerCase()+', language into: '+  booking.language_interprete_into.language_name.charAt(0).toUpperCase()+booking.language_interprete_into.language_name.slice(1).toLowerCase()+', repeating: '+booking.recurrence_rule+' and repeat every: '+booking.repeating_every_no+' '+repeating_interval+' at address: '+booking.address+ '. If you want to accept this booking kindly visit to the provided link: ' +baseUrl+ '/#/acceptRequest/' + request_token;
            }else{    
                var text = "You received a new booking request for service title:"+ ' ' + booking.service_title+ ', Start Date: '+moment(booking.start_date).format("MM-DD-YYYY")+ ', End Date: '+ moment(booking.end_date).format("MM-DD-YYYY")+ ', Time: '+booking.start_time+ ' to '+booking.end_time +', language from: '+  booking.language_interprete_from.language_name.charAt(0).toUpperCase()+booking.language_interprete_from.language_name.slice(1).toLowerCase()+', language into: '+  booking.language_interprete_into.language_name.charAt(0).toUpperCase()+booking.language_interprete_into.language_name.slice(1).toLowerCase()+' at address: '+booking.address+ '. If you want to accept this booking kindly visit to the provided link: ' +baseUrl+ '/#/acceptRequest/' + request_token;
            }
            var data = { to: selectedInterpreter.mobile_no, message: text }
            var request = {
                agency_id: req.user.agency_id,
                booking_id: booking._id,
                interpreter_id: selectedInterpreter._id,
                sent_to: selectedInterpreter.mobile_no ? selectedInterpreter.mobile_no : data.to,
                text:  selectedInterpreter.text ? selectedInterpreter.text : data.message,
                request_token: selectedInterpreter.request_token ? selectedInterpreter.request_token : request_token,
                accept: false
            }
            if(selectedInterpreter.selected == true){
                request.status = true;
            }else{
                request.status = false;
            }
            var condition = {
                agency_id:req.user.agency_id,
                interpreter_id:selectedInterpreter._id,
                booking_id: booking._id
            }
            BookingRequestModel.update(condition,{
                $set: request
            },{
                upsert: true
            },function(err, requestData){
                if(err){
                    console.log("error1",err);
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                } else{
                    if(selectedInterpreter.selected == true){
                        twilioSms.sendSMS(data, function(returnData) {
                            next();
                        });
                    }else{
                        next();
                    }
                }
            })
        },function(err){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })
            }else{
                res.json({
                    status: req.config.statusCode.success,
                    data: {},
                    message: i18n.__("Request sent succesfully")
                });
            }
        })        
    },

    getInterpreterBookingList: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            interpreter_id: mongoose.Types.ObjectId(req.user.interpreter_id),
            is_deleted: false
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                'clientInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'clientInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'status': new RegExp(searchText, 'gi')
            },
            {
                'booking_short_id': new RegExp(searchText, 'gi')
            },
            {
                'service_title': new RegExp(searchText, 'gi')
            }
            ];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'clients',
                localField: "client_id",
                foreignField: "_id",
                as: "clientInfo"
            }
        },
        {
            $unwind: {
                path: "$clientInfo",
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $match: condition
        }
        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        SchedulerModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                SchedulerModel.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

    getBookingViewByInterpreterId: function (req, res, next) {
        if(mongoose.Types.ObjectId.isValid(req.params.id)){
            SchedulerModel.findOne({
                _id:req.params.id,
                is_deleted:false
            })
            .populate('client_id')
            .populate('interpreter_id')
            .populate('language_interprete_from')
            .populate('language_interprete_into')
            .exec()
            .then((booking) => {
                if(!booking){
                    res.json({
                        status: req.config.statusCode.notFound,
                        data: [],
                        message: i18n.__("NO_RECORD_FOUND")
                    });
                }else{
                    res.json({
                        status: req.config.statusCode.success,
                        data: booking,
                        message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                    });
                }
            })
            .catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            })
        }else{
            res.json({
                status: req.config.statusCode.invalid,
                data: [],
                message: i18n.__("INVALID_ID")
            });
        }
    },

    getBookingViewByBookingId: function (req, res, next) {
        if(mongoose.Types.ObjectId.isValid(req.params.id)){
            SchedulerModel.findOne({
                _id:req.params.id,
                is_deleted:false
            })
            .populate('client_id')
            .populate('interpreter_id')
            .populate('language_interprete_from')
            .populate('language_interprete_into')
            .exec()
            .then((booking) => {
                if(!booking){
                    res.json({
                        status: req.config.statusCode.notFound,
                        data: [],
                        message: i18n.__("NO_RECORD_FOUND")
                    });
                }else{
                    res.json({
                        status: req.config.statusCode.success,
                        data: booking,
                        message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                    });
                }
            })
            .catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            })
        }else{
            res.json({
                status: req.config.statusCode.invalid,
                data: [],
                message: i18n.__("INVALID_ID")
            });
        }
    },

    getClientBookingList: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.agency_id),
            client_id: mongoose.Types.ObjectId(req.user.client_id),
            is_deleted: false
        }

        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                'interpreterInfo.first_name': new RegExp(searchText, 'gi')
            },
            {
                'interpreterInfo.last_name': new RegExp(searchText, 'gi')
            },
            {
                'status': new RegExp(searchText, 'gi')
            },
            {
                'booking_short_id': new RegExp(searchText, 'gi')
            },
            {
                'service_title': new RegExp(searchText, 'gi')
            }
            ];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'interpreters',
                localField: "interpreter_id",
                foreignField: "_id",
                as: "interpreterInfo"
            }
        },
        {
            $unwind: {
                path: "$interpreterInfo",
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $match: condition
        }
        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        SchedulerModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                SchedulerModel.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

     getBookingViewByClientId: function (req, res, next) {
        if(mongoose.Types.ObjectId.isValid(req.params.id)){
            SchedulerModel.findOne({
                _id:req.params.id,
                is_deleted:false
            })
            .populate('interpreter_id')
            .populate('client_id')
            .populate('language_interprete_from')
            .populate('language_interprete_into')
            .exec()
            .then((booking) => {
                if(!booking){
                    res.json({
                        status: req.config.statusCode.notFound,
                        data: [],
                        message: i18n.__("NO_RECORD_FOUND")
                    });
                }else{
                    res.json({
                        status: req.config.statusCode.success,
                        data: booking,
                        message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                    });
                }
            })
            .catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            })
        }else{
            res.json({
                status: req.config.statusCode.invalid,
                data: [],
                message: i18n.__("INVALID_ID")
            });
        }
    },

    addEventByClient: function (req, res, next) {
        console.log("comes in addSchedule");
        AgencySubscriptionModel.findOne({agency_id: req.user.agency_id, status: true})
            .then((agencySubscriptionData)=>{
                SubscriptionModel.findOne({_id: agencySubscriptionData.subscription_id})
                    .then((subscriptionData)=>{
                        SchedulerModel.find({agency_id: req.user.agency_id})
                            .then((scheduleData)=>{
                                if(scheduleData.length >= subscriptionData.booking_limit){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("BOOKING_LIMIT_REACHED")
                                    })
                                } else{
                                    genId();
                                    function addData(shortBookingId){
                                        req.body.booking_short_id = shortBookingId;
                                        schedule = new SchedulerModel(req.body);
                                        schedule.agency_id = req.user.agency_id;
                                        schedule.client_id = req.user.client_id;
                                        if(req.body.is_recurring == true){
                                            console.log("found recurrence rule")

                                            EventModel.findOne({_id: req.body.event_id}).exec(function(err, eventData){
                                                if(err){
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: {},
                                                        message: i18n.__("ERROR")
                                                    });
                                                }else if(eventData) {
                                                    schedule.recurrence_rule = eventData.event_name;
                                                    schedule.save(function(err,saveSchedule) {
                                                        if(err){
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: {},
                                                                message: i18n.__("ERROR")
                                                            });     
                                                        }else{
                                                            console.log("saved schedule");

                                                            res.json({
                                                                status: req.config.statusCode.success,
                                                                data: req.body,
                                                                message: i18n.__("BOOKED_SUCCESSFULLY")
                                                            });
                                                        }
                                                    }).catch(function(err) {
                                                        res.json({ 
                                                            status: req.config.statusCode.error,
                                                            data: {},
                                                            message: i18n.__("ERROR")
                                                        })
                                                    });
                                                }else{
                                                    res.json({
                                                        status: req.config.statusCode.notFound,
                                                        data: {},
                                                        message: i18n.__("REPEAT_NAME_IS_MISSING")
                                                    });
                                                }
                                            })
                                        }else{
                                            schedule.save(function(err,saveSchedule) {
                                                if(err){
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: {},
                                                        message: i18n.__("ERROR")
                                                    });     
                                                }else{
                                                    res.json({
                                                        status: req.config.statusCode.success,
                                                        data: saveSchedule,
                                                        message: i18n.__("BOOKED_SUCCESSFULLY")
                                                    });
                                                }
                                            }).catch(function(err) {
                                                res.json({ 
                                                    status: req.config.statusCode.error,
                                                    data: {},
                                                    message: i18n.__("ERROR")
                                                })
                                            });
                                        }   
                                    }

                                    function genId(){
                                        var shortBookingId = validator.generateShortId();
                                        EventModel.find({booking_short_id: shortBookingId}, function(err, eventData) {
                                            if(err){
                                                res.json({
                                                    status: req.config.statusCode.error,
                                                    data: {},
                                                    message: i18n.__("ERROR")
                                                })
                                            } else if(eventData.length>0){
                                                genId();
                                            } else{
                                                addData(shortBookingId);
                                            }
                                        })
                                    }
                                }
                            })
                    })
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            })
    },

    getTodaysBookingList: function (req, res, next) {
        // var count = parseInt(req.body.count ? req.body.count : 0);
        // var skip = parseInt(req.body.count * (req.body.page - 1));

        var finalResponse = {};
        finalResponse.dateArray = [];
        finalResponse.currentMonthEvents = [];
        finalResponse.events = [];
        finalResponse.tempArr = [];
        finalResponse.tempArry = [];

        var currentDate = moment(req.body.todays_date);
        var stopDate = moment(req.body.todays_date);
        var month_start_date = moment(req.body.todays_date).startOf('day');
        var month_end_date = moment(req.body.todays_date).endOf('day');

        // var currentDate = moment(req.body.todays_date).add(2, 'days');
        // var stopDate = moment(req.body.todays_date).add(2, 'days');
        // var month_start_date = moment(req.body.todays_date).startOf('day').add(2, 'days');
        // var month_end_date = moment(req.body.todays_date).endOf('day').add(2, 'days');

        var momentObjFrom = new Date(moment(month_start_date));
        var momentObjTo = new Date(moment(month_end_date));
        var schedulerObj = {
            month_start_date: momentObjFrom,
            month_end_date: momentObjTo
        }

        waterfall([
            function(callback) {
                while (currentDate <= stopDate) {
                    finalResponse.dateArray.push(moment(currentDate))
                    currentDate = moment(currentDate).add(1, 'days');
                }
                callback(null, finalResponse);
            },
            function(finalResponse, callback) {
                var condition = {};
                if(req.user.role == 'interpreter'){
                    condition = { 
                        agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                        interpreter_id: mongoose.Types.ObjectId(req.user.interpreter_id),
                        is_deleted:false,
                        $and:[
                            {$or:[
                                {status: 'in_process'}, 
                                {status: 'scheduled'},
                                {status: 'completed'}
                            ]}
                        ],
                        $or:[
                            {$and:[
                                {start_date: {$lte: momentObjTo}}, 
                                {end_date: {$gte: momentObjFrom}},
                            ]},
                            {event_end_date: {$gte: momentObjFrom}}
                        ]
                    };
                }else if(req.user.role == 'client'){
                    condition = { 
                        agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                        client_id: mongoose.Types.ObjectId(req.user.client_id),
                        is_deleted:false,
                        $and:[
                            {$or:[
                                {status: 'in_process'}, 
                                {status: 'scheduled'},
                                {status: 'completed'}
                            ]}
                        ],
                        $or:[
                            {$and:[
                                {start_date: {$lte: momentObjTo}}, 
                                {end_date: {$gte: momentObjFrom}},
                            ]},
                            {event_end_date: {$gte: momentObjFrom}}
                        ]
                    };
                }else{
                    condition = { 
                        agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                        is_deleted:false,
                        $and:[
                            {$or:[
                                {status: 'in_process'}, 
                                {status: 'scheduled'},
                                {status: 'completed'}
                            ]}
                        ],
                        $or:[
                            {$and:[
                                {start_date: {$lte: momentObjTo}}, 
                                {end_date: {$gte: momentObjFrom}},
                            ]},
                            {event_end_date: {$gte: momentObjFrom}}
                        ]
                    };

                }

                if(req.body.client_id !=null && req.body.client_id !=undefined && req.body.client_id !=''){
                    condition.client_id = mongoose.Types.ObjectId(req.body.client_id);
                }

                // console.log("event start_date",condition.$or[1].$and[0]);
                
                var aggregateQuery = [{
                    $match: condition
                },{
                    $lookup: {
                        from: 'schedule_skips',
                        localField: "_id",
                        foreignField: "scheduler_id",
                        as: "schedulerInfo"
                    }
                },{
                    $lookup: {
                        from: 'clients',
                        localField: "client_id",
                        foreignField: "_id",
                        as: "clientInfo"
                    }
                },
                {
                    $unwind: {
                        path: "$clientInfo",
                        preserveNullAndEmptyArrays: true
                    }
                },{
                    $lookup: {
                        from: 'interpreters',
                        localField: "interpreter_id",
                        foreignField: "_id",
                        as: "interpreterInfo"
                    }
                },
                {
                    $unwind: {
                        path: "$interpreterInfo",
                        preserveNullAndEmptyArrays: true
                    }
                },{
                    $lookup: {
                        from: 'languages',
                        localField: "language_interprete_from",
                        foreignField: "_id",
                        as: "languageFromInfo"
                    }
                },
                {
                    $unwind: {
                        path: "$languageFromInfo",
                        preserveNullAndEmptyArrays: true
                    }
                },{
                    $lookup: {
                        from: 'languages',
                        localField: "language_interprete_into",
                        foreignField: "_id",
                        as: "languageIntoInfo"
                    }
                },
                {
                    $unwind: {
                        path: "$languageIntoInfo",
                        preserveNullAndEmptyArrays: true
                    }
                }
                ];

                // var countQuery = [].concat(aggregateQuery);
                // aggregateQuery.push({
                //     $skip: skip
                // });
                // aggregateQuery.push({
                //     $limit: count
                // });

                SchedulerModel.aggregate(aggregateQuery).exec(function (err, result) {
                    if (err) {
                        callback(err, false);
                    } else if(result.length > 0) {
                        // console.log("get result in scheduler",result.length);
                        // console.log("get result in scheduler",result);
                        for (var i = result.length - 1; i >= 0; i--) {
                            finalResponse.currentMonthEvents.push(result[i])
                        }
                        callback(null, finalResponse);
                    }else{
                        console.log("result",result);
                        callback(null, finalResponse);
                    }
                })
            },
            function(finalResponse,callback){
                function getRandomColor (){
                    var letters = '0123456789ABCDEF';
                    var color = '#';
                    for (var i = 0; i < 6; i++) {
                        color += letters[Math.floor(Math.random() * 16)];
                    }
                    return color;
                }

                async.each(finalResponse.currentMonthEvents, function(value, callbackEvent) {
                    if(value.is_recurring == false){
                        // console.log("value", value);
                        var colorName = getRandomColor();
                        finalResponse.events.push({
                            _id: value._id,
                            booking_short_id: value.booking_short_id,
                            start_date: moment(value.start_date),
                            end_date: moment(value.end_date),
                            start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                            end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                            service_title: value.service_title, //hol.HOLIDAY_TITLE,
                            status: value.status,
                            is_recurring: value.is_recurring,
                            todays_status: false,
                            clientInfo: value.clientInfo,
                            interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : ''),
                            bookingDetail: value
                        });
                        callbackEvent();
                    }else{
                        if(value.recurrence_rule == 'daily'){
                            var colorName = getRandomColor();
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "daily", repeating_every_no, "");
                            if(recurringEventStartEndInterval.length > 0){
                                for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                    var dateExist = false;
                                    for(var x = 0; x < value.schedulerInfo.length; x++){

                                        if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                            dateExist = true;
                                            break;
                                        }else{
                                             dateExist = false;   
                                        }
                                    }
                                    if(dateExist){

                                    }else{
                                        if(recurringEventStartEndInterval[z].endEvent == ""){

                                        }else{
                                            finalResponse.events.push({
                                                _id: value._id,
                                                booking_short_id: value.booking_short_id,
                                                start_date: recurringEventStartEndInterval[z].startEvent,
                                                end_date: recurringEventStartEndInterval[z].endEvent,
                                                start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                service_title: value.service_title, //hol.HOLIDAY_TITLE,
                                                status: value.status,
                                                is_recurring: value.is_recurring,
                                                todays_status: false,
                                                clientInfo: value.clientInfo,
                                                interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : ''),
                                                bookingDetail: value
                                            });
                                        }
                                    }                                                                                                                                     
                               } 
                            }
                        }else if(value.recurrence_rule == 'weekly'){
                            var colorName = getRandomColor();
                            // console.log("colorName in weekly", colorName);
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "weekly" , repeating_every_no, "");                    
                                if(recurringEventStartEndInterval.length > 0){
                                    for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                        var dateExist = false;
                                        for(var x = 0; x < value.schedulerInfo.length; x++){
                                            if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                                dateExist = true;
                                                break;
                                            }else{
                                                 dateExist = false;   
                                            }
                                        }
                                        if(dateExist){

                                        }else{
                                            if(recurringEventStartEndInterval[z].endEvent == ""){
                                        }else{
                                            finalResponse.events.push({
                                                _id: value._id,
                                                booking_short_id: value.booking_short_id,
                                                start_date: recurringEventStartEndInterval[z].startEvent,
                                                end_date: recurringEventStartEndInterval[z].endEvent,
                                                start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                service_title: value.service_title, //hol.HOLIDAY_TITLE,
                                                status: value.status,
                                                is_recurring: value.is_recurring,
                                                todays_status: false,
                                                clientInfo: value.clientInfo,
                                                interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : ''),                                
                                                bookingDetail: value
                                            });
                                        }
                                   
                                    }                                                                                                                                     
                               } 
                            } 

                        }
                        else if(value.recurrence_rule == 'monthly'){
                            var colorName = getRandomColor();
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "monthly", repeating_every_no, "");                    
                            if(recurringEventStartEndInterval.length > 0){
                                for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                    var dateExist = false;
                                    for(var x = 0; x < value.schedulerInfo.length; x++){

                                        if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                            dateExist = true;
                                            break;
                                        }else{
                                             dateExist = false;   
                                        }
                                    }
                                    if(dateExist){

                                    }else{
                                        if(recurringEventStartEndInterval[z].endEvent == ""){

                                        }else{
                                            finalResponse.events.push({
                                                _id: value._id,
                                                booking_short_id: value.booking_short_id,
                                                start_date: recurringEventStartEndInterval[z].startEvent,
                                                end_date: recurringEventStartEndInterval[z].endEvent,
                                                start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                service_title: value.service_title, //hol.HOLIDAY_TITLE,
                                                status: value.status,
                                                is_recurring: value.is_recurring,
                                                todays_status: false,
                                                clientInfo: value.clientInfo,
                                                interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : ''),                                   
                                                bookingDetail: value
                                            });
                                        }
                                   
                                    }                                                                                                                                     
                                } 
                            } 

                        }else if(value.recurrence_rule == 'yearly'){
                            var colorName = getRandomColor();
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "yearly", repeating_every_no, "");                    
                            if(recurringEventStartEndInterval.length > 0){
                                for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                    var dateExist = false;
                                    for(var x = 0; x < value.schedulerInfo.length; x++){
                                        if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                            dateExist = true;
                                            break;
                                        }else{
                                             dateExist = false;   
                                        }
                                    }
                                    if(dateExist){

                                    }else{
                                        if(recurringEventStartEndInterval[z].endEvent == ""){

                                        }else{
                                            finalResponse.events.push({
                                                _id: value._id,
                                                booking_short_id: value.booking_short_id,
                                                start_date: recurringEventStartEndInterval[z].startEvent,
                                                end_date: recurringEventStartEndInterval[z].endEvent,
                                                start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                service_title: value.service_title, //hol.HOLIDAY_TITLE,
                                                status: value.status,
                                                is_recurring: value.is_recurring,
                                                todays_status: false,
                                                clientInfo: value.clientInfo,
                                                interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : ''),
                                                bookingDetail: value
                                            });
                                        }
                                    }                                                                                                                                     
                               } 
                            }
                        }else if(value.recurrence_rule == 'custom (weekly)'){
                            var colorName = getRandomColor();
                            var weekArray = [];
                            for (var key in value.custom_weekly_repeat_on) {
                                if(value.custom_weekly_repeat_on[key] == true){
                                    weekArray.push(key);
                                }
                            }
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "custom (weekly)", repeating_every_no, weekArray);                    
                            if(recurringEventStartEndInterval.length > 0){
                                for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                    var dateExist = false;
                                    for(var x = 0; x < value.schedulerInfo.length; x++){
                                        if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                            dateExist = true;
                                            break;
                                        }else{
                                             dateExist = false;   
                                        }
                                    }
                                    if(dateExist){

                                    }else{
                                        if(recurringEventStartEndInterval[z].endEvent == ""){

                                        }else{
                                            finalResponse.events.push({
                                                _id: value._id,
                                                booking_short_id: value.booking_short_id,
                                                start_date: recurringEventStartEndInterval[z].startEvent,
                                                end_date: recurringEventStartEndInterval[z].endEvent,
                                                start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                service_title: value.service_title, //hol.HOLIDAY_TITLE,
                                                status: value.status,
                                                is_recurring: value.is_recurring,
                                                todays_status: false,
                                                clientInfo: value.clientInfo,
                                                interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : ''),
                                                bookingDetail: value
                                            });
                                        }
                                    }                                                                                                                                     
                               } 
                            }
                        }
                        callbackEvent()

                        function getDayString(day){
                            var dayString = ""
                            switch (day) {
                                case 0:
                                    dayString = "Sunday";
                                    break;
                                case 1:
                                    dayString = "Monday";
                                    break;
                                case 2:
                                    dayString = "Tuesday";
                                    break;
                                case 3:
                                    dayString = "Wednesday";
                                    break;
                                case 4:
                                    dayString = "Thursday";
                                    break;
                                case 5:
                                    dayString = "Friday";
                                    break;
                                case 6:
                                    dayString = "Saturday";
                            }
                            return dayString;
                        }

                        function getMonthString(month_no){
                          var monthString = ""
                            switch (month_no) {
                                case 0:
                                    monthString = "January";
                                    break;
                                case 1:
                                    monthString = "February";
                                    break;
                                case 2:
                                    monthString = "March";
                                    break;
                                case 3:
                                    monthString = "April";
                                    break;
                                case 4:
                                    monthString = "May";
                                    break;
                                case 5:
                                    monthString = "June";
                                    break;
                                case 6:
                                    monthString = "July";
                                    break;
                                case 7:
                                    monthString = "August";
                                    break;
                                case 8:
                                    monthString = "September";
                                    break;
                                case 9:
                                    monthString = "October";
                                    break;
                                case 10:
                                    monthString = "November";
                                    break;
                                case 11:
                                    monthString = "December";
                                    break;    
                            }
                            return monthString;
                        }

                        function addHoursInDate(recurringWeeklyDateOnly, startHours, startMinutes){
                            var newRecurringWeeklyDateOnly = new Date(recurringWeeklyDateOnly);
                            newRecurringWeeklyDateOnly.setHours(startHours);
                            newRecurringWeeklyDateOnly.setMinutes(startMinutes);
                            return moment(newRecurringWeeklyDateOnly);
                        }

                        function convertVirtualEventsDateIntoDateTime(startTime,endTime,stopTimeDateTime,startTimeOnly,endTimeOnly, month_start_date, month_end_date, interval, repeating_every_no, weekArray){    //function to find the recurring inetrvals:start/end            
                            var recurringDateTimeStartEndOfEvent = [];      
                              
                            //start Event Calculation//
                            var eventStartTime = startTimeOnly;
                            var eventEndTime = endTimeOnly;

                            var month_start_date = moment(month_start_date).startOf('day');
                            var month_end_date = moment(month_end_date).startOf('day');
                            var momentObjMonth_start_date = new Date(moment(month_start_date));
                            var momentObjMonth_end_date = new Date(moment(month_end_date));

                            var tmpStartTime = convertTo24Format(startTimeOnly);
                            var tmpEndTime = convertTo24Format(endTimeOnly);
                              
                            var localStartDateTime =  moment(startTime).utc();
                            var localEndDateTime = moment(endTime).utc();

                            var localTimeStopTime =  moment(stopTimeDateTime).utc();                                         
                            var startHours = new Date(localStartDateTime).getHours();
                            var startMinutes = new Date(localStartDateTime).getMinutes();
                            var startDayString = getDayString(new Date(localStartDateTime).getDay());
                            var startDateOfMonth = new Date(localStartDateTime).getDate();
                            var startMonthOfYear = getMonthString(new Date(localStartDateTime).getMonth());
                            //end of event Calculation//

                            var endHours = new Date(localEndDateTime).getHours();
                            var endMinutes = new Date(localEndDateTime).getMinutes();
                            var endDayString = getDayString(new Date(localEndDateTime).getDay());
                            var endDateOfMonth = new Date(localEndDateTime).getDate();
                            var endMonthOfYear = getMonthString(new Date(localEndDateTime).getMonth());

                            if(interval == "daily"){
                                var recurringDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(1).days();
                                var recurringDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(1).days();
                                if(recurringDatesForStart.all().length > 0){
                                    for(var i = 0 ; i<recurringDatesForStart.all().length; i++){ 
                                        if(i%repeating_every_no == 0){
                                            var recurringDateOnly =  recurringDatesForStart.all()[i]
                                            var isafter = moment(recurringDateOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent.push({
                                                startEvent : addHoursInDate(recurringDateOnly, startHours, startMinutes),
                                                endEvent : ""
                                            });
                                            recurringDateOnly = "";
                                        }else{
                                            continue;
                                        }
                                    }
                                }

                                if(recurringDatesForEnd.all().length > 0){
                                    var z = 0;
                                    for(var j = 0 ; j<recurringDatesForEnd.all().length; j++){
                                        if(j%repeating_every_no == 0){
                                            var recurringDateEndOnly =  recurringDatesForEnd.all()[j]
                                            var isafter = moment(recurringDateEndOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringDateEndOnly, endHours, endMinutes),
                                            recurringDateEndOnly = "";
                                            z++;
                                        }else{
                                            continue;
                                        }
                                    }
                                }

                            }else if(interval == "weekly"){
                                var weekDayStartString = [];
                                var weekDayEndString = [];
                                weekDayStartString.push(startDayString);
                                weekDayEndString.push(endDayString)
                                                                    
                                var recurringWeeklyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(weekDayStartString).daysOfWeek();
                                var recurringWeeklyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(weekDayEndString).daysOfWeek(); 
                                if(recurringWeeklyDatesForStart.all().length > 0){

                                    for(var i = 0; i<recurringWeeklyDatesForStart.all().length; i++){
                                        if(i%repeating_every_no == 0){
                                            var recurringWeeklyDateOnly =  recurringWeeklyDatesForStart.all()[i];
                                            var isafter = moment(recurringWeeklyDateOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent.push({
                                                startEvent : addHoursInDate(recurringWeeklyDateOnly, startHours, startMinutes),
                                                endEvent : ""
                                            });
                                            recurringWeeklyDateOnly = "";
                                        }else{
                                            continue;
                                        }
                                    }
                                }
                                if(recurringWeeklyDatesForEnd.all().length > 0){
                                    var z = 0;
                                    for(var j = 0 ; j<recurringWeeklyDatesForEnd.all().length; j++){
                                        if(j%repeating_every_no == 0){
                                            var recurringWeeklyDateEndOnly =  recurringWeeklyDatesForEnd.all()[j]
                                            var isafter = moment(recurringWeeklyDateEndOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringWeeklyDateEndOnly, endHours, endMinutes),
                                            recurringWeeklyDateEndOnly = "";
                                            z++;
                                        }else{
                                            continue;
                                        }
                                    }
                                } 
                            }else if(interval == "custom (weekly)"){
                                var weekDayStartString = weekArray;
                                var weekDayEndString = weekArray;
                                var arr = [];
                                var array1d = [];
                                var arr1d = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
                                for(var u=0; u<arr1d.length; u++){
                                    if(weekArray.indexOf(arr1d[u]) != -1){
                                        array1d.push(arr1d[u]);
                                    }
                                }

                                arr['sunday'] = 0;
                                arr['monday'] = 1;
                                arr['tuesday'] = 2;
                                arr['wednesday'] = 3;
                                arr['thursday'] = 4;
                                arr['friday'] = 5;
                                arr['saturday'] = 6;
                                var len = weekArray.length;
                                var recurringWeeklyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(weekDayStartString).daysOfWeek();
                                var recurringWeeklyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(weekDayEndString).daysOfWeek(); 
                                if(recurringWeeklyDatesForStart.all().length > 0){
                                    var t2,t3 = 0;
                                    for(var p=0; p < weekArray.length; p++){
                                        t2 = getDayString(new Date(recurringWeeklyDatesForStart.all()[0]).getDay());
                                        t3++;
                                        if(arr[t2.toLowerCase()] <= arr[array1d[p].toLowerCase()] ){
                                            break;
                                        }
                                    }
                                    for(var i = t3; i <= recurringWeeklyDatesForStart.all().length; i++){
                                        var recurringWeeklyDateOnly =  recurringWeeklyDatesForStart.all()[i-t3];
                                        var isafter = moment(recurringWeeklyDateOnly).isAfter(momentObjMonth_end_date);
                                        recurringDateTimeStartEndOfEvent.push({
                                            startEvent : addHoursInDate(recurringWeeklyDateOnly, startHours, startMinutes),
                                            endEvent : ""
                                        });
                                        recurringWeeklyDateOnly = "";
                                        if( i%len  == 0 ){
                                            var skip  = len*repeating_every_no - len;
                                            i = i + skip; 
                                        }
                                    }
                                }
                                if(recurringWeeklyDatesForEnd.all().length > 0){
                                    var t2,t3 = 0;
                                    for(var p=0; p < weekArray.length; p++){
                                        t2 = getDayString(new Date(recurringWeeklyDatesForStart.all()[0]).getDay());
                                        t3++;
                                        if(arr[t2.toLowerCase()] <= arr[array1d[p].toLowerCase()] ){
                                            break;
                                        }
                                    }
                                    var z = 0;
                                    for(var j = t3 ; j <= recurringWeeklyDatesForEnd.all().length; j++){
                                            var recurringWeeklyDateEndOnly =  recurringWeeklyDatesForEnd.all()[j-t3]
                                            var isafter = moment(recurringWeeklyDateEndOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringWeeklyDateEndOnly, endHours, endMinutes),
                                            recurringWeeklyDateEndOnly = "";
                                            z++;
                                        if(j%len  == 0 ){
                                            var skip  = len*repeating_every_no - len;
                                            j = j + skip;
                                        }
                                    }
                                } 
                            }else if(interval == "monthly"){
                                var recurringMonthlyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(startDateOfMonth).dayOfMonth();
                                var recurringMonthlyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(endDateOfMonth).dayOfMonth();
                                if(recurringMonthlyDatesForStart.all().length > 0){
                                    for(var i = 0 ; i<recurringMonthlyDatesForStart.all().length; i++){
                                        if(i%repeating_every_no == 0){
                                            var recurringMonthDateOnly =  recurringMonthlyDatesForStart.all()[i]
                                            recurringDateTimeStartEndOfEvent.push({
                                                startEvent :  addHoursInDate(recurringMonthDateOnly, startHours, startMinutes),
                                                endEvent : ""
                                            });
                                            recurringMonthDateOnly = "";
                                        }else{
                                            continue;
                                        }

                                    }
                                }
                                if(recurringMonthlyDatesForEnd.all().length > 0){
                                    var z = 0;
                                    for(var j = 0 ; j<recurringMonthlyDatesForEnd.all().length; j++){
                                        if(j%repeating_every_no == 0){
                                            var recurringMonthDateEndOnly =  recurringMonthlyDatesForEnd.all()[j];
                                            recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringMonthDateEndOnly, endHours, endMinutes),
                                            recurringMonthDateEndOnly = "";
                                            z++;
                                        }else{
                                            continue;
                                        }
                                    }
                                }
                            }else if(interval == "yearly"){ 
                                var recurringYearlyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(startDateOfMonth).daysOfMonth().every(startMonthOfYear).monthsOfYear();
                                var recurringYearlyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(endDateOfMonth).daysOfMonth().every(endMonthOfYear).monthsOfYear();
                                if(recurringYearlyDatesForStart.all().length > 0){
                                    for(var i = 0 ; i<recurringYearlyDatesForStart.all().length; i++){
                                        if(i%repeating_every_no == 0){
                                            var recurringYearlyDateOnly =  recurringYearlyDatesForStart.all()[i]
                                            recurringDateTimeStartEndOfEvent.push({
                                              startEvent : addHoursInDate(recurringYearlyDateOnly, startHours, startMinutes),
                                              endEvent : ""
                                            });
                                            recurringYearlyDateOnly = "";
                                        }else{
                                            continue;
                                        }
                                    }
                                }
                                if(recurringYearlyDatesForEnd.all().length > 0){
                                    var z = 0;
                                    for(var j = 0 ; j<recurringYearlyDatesForEnd.all().length; j++){
                                        if(j%repeating_every_no == 0){
                                            var recurringYearlyDateEndOnly =  recurringYearlyDatesForEnd.all()[j]
                                            var isafter = moment(recurringYearlyDateEndOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringYearlyDateEndOnly, endHours, endMinutes),
                                            recurringYearlyDateEndOnly = "";
                                            z++;
                                        }else{
                                            continue;
                                        }
                                    }
                                }  
                            }
                            return recurringDateTimeStartEndOfEvent;          
                        }

                        function convertTo24Format(timeStr){
                            var tmp=timeStr;
                            var tmpArr = tmp.split(':');
                            var t = tmpArr[1].split(' ')[1];
                            var hour= tmpArr[0].trim();
                            var minute= tmpArr[1].split(' ')[0];
                            if(t=='PM'){
                                if(hour!=12){
                                    hour = parseInt(hour) + 12;
                                }
                            } else if(t=='AM'){
                                if(hour==12){
                                    hour=0;
                                }
                            }
                            return { 'hour': hour, 'minute': minute};
                        }
                    }
                },function(err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            },
            function(finalResponse,callback){
                // console.log("before finalResponse.events",finalResponse.events.length);
                // console.log("before finalResponse.events",finalResponse.events);
                async.each(finalResponse.dateArray, function(date, cb) {
                    var obj = _.filter(finalResponse.events, function(d) { 
                        if(moment(date.format('YYYY-MM-DD')).isSameOrAfter(d.start_date.format('YYYY-MM-DD')) && moment(date.format('YYYY-MM-DD')).isSameOrBefore(d.end_date.format('YYYY-MM-DD'))){
                            console.log("moment(date.format('YYYY-MM-DD'))", moment(date.format('YYYY-MM-DD')));
                            var startHours = new Date(d.start_date).getHours();
                            var startMinutes = new Date(d.start_date).getMinutes();
                            var start_date = moment(date.format('YYYY-MM-DD'));
                            var endHours = new Date(d.end_date).getHours();
                            var endMinutes = new Date(d.end_date).getMinutes();
                            var end_date = moment(date.format('YYYY-MM-DD'));
                            d.start_date = utility.addHoursInDate(start_date, startHours, startMinutes); 
                            d.end_date = utility.addHoursInDate(end_date, endHours, endMinutes); 
                            return d;
                        } 
                    });
                       if(obj.length > 0){
                        // console.log("object@2222", obj);
                        for (var i = obj.length - 1; i >= 0; i--) {
                            finalResponse.tempArr.push(obj[i]);
                        }
                        cb(null,finalResponse);
                    }else{
                        cb(null,finalResponse)
                    }
                }, function(err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        // console.log("finalResponse", finalResponse.tempArr);
                        callback(null, finalResponse);
                    }
                });
            },
            function(finalResponse,callback){
                // console.log("before finalResponse.events",finalResponse.events.length);
                // console.log("before finalResponse.events",finalResponse.events);
                async.each(finalResponse.tempArr, function(todayRecord, cbt) {
                    CheckInOutModel.findOne({
                        booking_id : mongoose.Types.ObjectId(todayRecord._id),
                        is_deleted: false,
                        status: true,
                        $and:[
                            {check_in_date: {$gte: momentObjFrom}}, 
                            {check_out_date: {$lte: momentObjTo}}
                        ]
                    }).exec(function(err, check_in_out_record){
                        if(err){
                            callback(err, false);
                        }else {
                            // console.log("check_in_out_record", check_in_out_record);
                            if(check_in_out_record == null){
                                finalResponse.tempArry.push(todayRecord);
                            }else{
                                todayRecord.todays_status = true;
                                finalResponse.tempArry.push(todayRecord);
                            }
                            cbt();
                        }
                    })
                }, function(err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        // console.log("finalResponse", finalResponse.tempArry);
                        callback(null, finalResponse);
                    }
                });
            },

        ], function(err, data) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            } else {

                res.json({
                    status: req.config.statusCode.success,
                    data: data.tempArry,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }
        });
        
    },

    getCompletedBookings: function (req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {};
        if(req.user.role == 'interpreter'){
            condition = { 
                agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                interpreter_id: mongoose.Types.ObjectId(req.user.interpreter_id),
                is_deleted: false,
                check_io_approval: 'approved'
            };
        }else if(req.user.role == 'client'){
            condition = { 
                agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                client_id: mongoose.Types.ObjectId(req.user.client_id),
                is_deleted: false,
                check_io_approval: 'approved'
            };
        }else{
            condition = { 
                agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                is_deleted: false,
                check_io_approval: 'approved'
            };
        }

        if(req.body.client_id !=null && req.body.client_id !=undefined && req.body.client_id !=''){
            condition.client_id = mongoose.Types.ObjectId(req.body.client_id);
        }

        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                    'service_title': new RegExp(searchText, 'gi')
                },
                {
                    'booking_short_id': new RegExp(searchText, 'gi')
                },
                {
                    'clientInfo.first_name': new RegExp(searchText, 'gi')
                },
                {
                    'clientInfo.last_name': new RegExp(searchText, 'gi')
                }
            ];
        }

        var aggregateQuery = [{
            $lookup: {
                from: 'schedulers',
                localField: "booking_id",
                foreignField: "_id",
                as: "bookingInfo"
            }
        },
        {
            $unwind: {
                path: "$bookingInfo",
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $match: condition
        },{
            $lookup: {
                from: 'languages',
                localField: "bookingInfo.language_interprete_from",
                foreignField: "_id",
                as: "languageFromInfo"
            }
        },
        {
            $unwind: {
                path: "$languageFromInfo",
                preserveNullAndEmptyArrays: true
            }
        },{
            $lookup: {
                from: 'languages',
                localField: "bookingInfo.language_interprete_into",
                foreignField: "_id",
                as: "languageIntoInfo"
            }
        },
        {
            $unwind: {
                path: "$languageIntoInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $lookup: {
                from: 'clients',
                localField: "client_id",
                foreignField: "_id",
                as: "clientInfo"
            }
        }, {
            $unwind: {
                path: "$clientInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $lookup: {
                from: 'interpreters',
                localField: "interpreter_id",
                foreignField: "_id",
                as: "interpreterInfo"
            }
        }, {
            $unwind: {
                path: "$interpreterInfo",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $match: condition
        }

        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        CheckInOutModel.aggregate(aggregateQuery).exec(function (err, result) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                CheckInOutModel.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },

     getPendingBookings: function (req, res, next) {
        // var count = parseInt(req.body.count ? req.body.count : 0);
        // var skip = parseInt(req.body.count * (req.body.page - 1));

        var finalResponse = {};
        finalResponse.dateArray = [];
        finalResponse.currentMonthEvents = [];
        finalResponse.events = [];
        finalResponse.tempArr = [];
        finalResponse.tempArry = [];

        var currentDate = moment(req.body.before_week_date);
        var stopDate = moment(req.body.yesterday_date);
        var month_start_date = moment(req.body.before_week_date).startOf('day');
        var month_end_date = moment(req.body.yesterday_date).endOf('day');

        // var currentDate = moment(req.body.todays_date).add(2, 'days');
        // var stopDate = moment(req.body.todays_date).add(2, 'days');
        // var month_start_date = moment(req.body.todays_date).startOf('day').add(2, 'days');
        // var month_end_date = moment(req.body.todays_date).endOf('day').add(2, 'days');

        var momentObjFrom = new Date(moment(month_start_date));
        var momentObjTo = new Date(moment(month_end_date));
        var schedulerObj = {
            month_start_date: momentObjFrom,
            month_end_date: momentObjTo
        }

        waterfall([
            function(callback) {
                while (currentDate <= stopDate) {
                    finalResponse.dateArray.push(moment(currentDate))
                    currentDate = moment(currentDate).add(1, 'days');
                }
                callback(null, finalResponse);
            },
            function(finalResponse, callback) {
                var condition = {};
                if(req.user.role == 'interpreter'){
                    condition = { 
                        agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                        interpreter_id: mongoose.Types.ObjectId(req.user.interpreter_id),
                        is_deleted:false,
                        $and:[
                            {$or:[
                                {status: 'in_process'}, 
                                {status: 'scheduled'},
                                {status: 'completed'}
                            ]},
                            {$or:[
                                {$and:[
                                    {start_date: {$lte: momentObjTo}}, 
                                    {end_date: {$gte: momentObjFrom}},
                                ]},
                                {$and:[
                                    {end_date: {$lte: momentObjFrom}}, 
                                    {event_end_date: {$gte: momentObjFrom}}    
                                ]}
                            ]}
                        ]
                    };
                }else if(req.user.role == 'client'){
                    condition = { 
                        agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                        client_id: mongoose.Types.ObjectId(req.user.client_id),
                        is_deleted:false,
                        $and:[
                            {$or:[
                                {status: 'in_process'}, 
                                {status: 'scheduled'},
                                {status: 'completed'}
                            ]},
                            {$or:[
                                {$and:[
                                    {start_date: {$lte: momentObjTo}}, 
                                    {end_date: {$gte: momentObjFrom}},
                                ]},
                                {$and:[
                                    {end_date: {$lte: momentObjFrom}}, 
                                    {event_end_date: {$gte: momentObjFrom}}    
                                ]}
                            ]}
                        ]
                    };
                }else{
                    condition = { 
                        agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                        is_deleted:false,
                        $and:[
                            {$or:[
                                {status: 'in_process'}, 
                                {status: 'scheduled'},
                                {status: 'completed'}
                            ]},
                            {$or:[
                                {$and:[
                                    {start_date: {$lte: momentObjTo}}, 
                                    {end_date: {$gte: momentObjFrom}},
                                ]},
                                {$and:[
                                    {end_date: {$lte: momentObjFrom}}, 
                                    {event_end_date: {$gte: momentObjFrom}}    
                                ]}
                            ]}
                        ]
                    };

                }

                if(req.body.client_id !=null && req.body.client_id !=undefined && req.body.client_id !=''){
                    condition.client_id = mongoose.Types.ObjectId(req.body.client_id);
                }
                
                var aggregateQuery = [{
                    $match: condition
                },{
                    $lookup: {
                        from: 'schedule_skips',
                        localField: "_id",
                        foreignField: "scheduler_id",
                        as: "schedulerInfo"
                    }
                },{
                    $lookup: {
                        from: 'clients',
                        localField: "client_id",
                        foreignField: "_id",
                        as: "clientInfo"
                    }
                },
                {
                    $unwind: {
                        path: "$clientInfo",
                        preserveNullAndEmptyArrays: true
                    }
                },{
                    $lookup: {
                        from: 'interpreters',
                        localField: "interpreter_id",
                        foreignField: "_id",
                        as: "interpreterInfo"
                    }
                },
                {
                    $unwind: {
                        path: "$interpreterInfo",
                        preserveNullAndEmptyArrays: true
                    }
                },{
                    $lookup: {
                        from: 'languages',
                        localField: "language_interprete_from",
                        foreignField: "_id",
                        as: "languageFromInfo"
                    }
                },
                {
                    $unwind: {
                        path: "$languageFromInfo",
                        preserveNullAndEmptyArrays: true
                    }
                },{
                    $lookup: {
                        from: 'languages',
                        localField: "language_interprete_into",
                        foreignField: "_id",
                        as: "languageIntoInfo"
                    }
                },
                {
                    $unwind: {
                        path: "$languageIntoInfo",
                        preserveNullAndEmptyArrays: true
                    }
                }
                ];
                // var countQuery = [].concat(aggregateQuery);
                // aggregateQuery.push({
                //     $skip: skip
                // });
                // aggregateQuery.push({
                //     $limit: count
                // });

                SchedulerModel.aggregate(aggregateQuery).exec(function (err, result) {
                    if (err) {
                        callback(err, false);
                    } else if(result.length > 0) {
                        // console.log("get result in scheduler",result.length);
                        // console.log("get result in scheduler",result);
                        for (var i = result.length - 1; i >= 0; i--) {
                            finalResponse.currentMonthEvents.push(result[i])
                        }
                        callback(null, finalResponse);
                    }else{
                        console.log("result",result);
                        callback(null, finalResponse);
                    }
                })
            },
            function(finalResponse,callback){
                function getRandomColor (){
                    var letters = '0123456789ABCDEF';
                    var color = '#';
                    for (var i = 0; i < 6; i++) {
                        color += letters[Math.floor(Math.random() * 16)];
                    }
                    return color;
                }

                async.each(finalResponse.currentMonthEvents, function(value, callbackEvent) {
                    if(value.is_recurring == false){
                        // console.log("value", value);
                        var colorName = getRandomColor();
                        finalResponse.events.push({
                            _id: value._id,
                            booking_short_id: value.booking_short_id,
                            start_date: moment(value.start_date),
                            end_date: moment(value.end_date),
                            start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                            end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                            service_title: value.service_title, //hol.HOLIDAY_TITLE,
                            status: value.status,
                            is_recurring: value.is_recurring,
                            todays_status: false,
                            clientInfo: value.clientInfo,
                            interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : ''),
                            bookingDetail: value
                        });
                        callbackEvent();
                    }else{
                        if(value.recurrence_rule == 'daily'){
                            var colorName = getRandomColor();
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "daily", repeating_every_no, "");
                            if(recurringEventStartEndInterval.length > 0){
                                for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                    var dateExist = false;
                                    for(var x = 0; x < value.schedulerInfo.length; x++){

                                        if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                            dateExist = true;
                                            break;
                                        }else{
                                             dateExist = false;   
                                        }
                                    }
                                    if(dateExist){

                                    }else{
                                        if(recurringEventStartEndInterval[z].endEvent == ""){

                                        }else{
                                            finalResponse.events.push({
                                                _id: value._id,
                                                booking_short_id: value.booking_short_id,
                                                start_date: recurringEventStartEndInterval[z].startEvent,
                                                end_date: recurringEventStartEndInterval[z].endEvent,
                                                start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                service_title: value.service_title, //hol.HOLIDAY_TITLE,
                                                status: value.status,
                                                is_recurring: value.is_recurring,
                                                todays_status: false,
                                                clientInfo: value.clientInfo,
                                                interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : ''),
                                                bookingDetail: value
                                            });
                                        }
                                    }                                                                                                                                     
                               } 
                            }
                        }else if(value.recurrence_rule == 'weekly'){
                            var colorName = getRandomColor();
                            // console.log("colorName in weekly", colorName);
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "weekly" , repeating_every_no, "");                    
                                if(recurringEventStartEndInterval.length > 0){
                                    for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                        var dateExist = false;
                                        for(var x = 0; x < value.schedulerInfo.length; x++){
                                            if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                                dateExist = true;
                                                break;
                                            }else{
                                                 dateExist = false;   
                                            }
                                        }
                                        if(dateExist){

                                        }else{
                                            if(recurringEventStartEndInterval[z].endEvent == ""){
                                        }else{
                                            finalResponse.events.push({
                                                _id: value._id,
                                                booking_short_id: value.booking_short_id,
                                                start_date: recurringEventStartEndInterval[z].startEvent,
                                                end_date: recurringEventStartEndInterval[z].endEvent,
                                                start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                service_title: value.service_title, //hol.HOLIDAY_TITLE,
                                                status: value.status,
                                                is_recurring: value.is_recurring,
                                                todays_status: false,
                                                clientInfo: value.clientInfo,
                                                interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : ''),
                                                bookingDetail: value                                
                                            });
                                        }
                                   
                                    }                                                                                                                                     
                               } 
                            } 

                        }
                        else if(value.recurrence_rule == 'monthly'){
                            var colorName = getRandomColor();
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "monthly", repeating_every_no, "");                    
                            if(recurringEventStartEndInterval.length > 0){
                                for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                    var dateExist = false;
                                    for(var x = 0; x < value.schedulerInfo.length; x++){

                                        if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                            dateExist = true;
                                            break;
                                        }else{
                                             dateExist = false;   
                                        }
                                    }
                                    if(dateExist){

                                    }else{
                                        if(recurringEventStartEndInterval[z].endEvent == ""){

                                        }else{
                                            finalResponse.events.push({
                                                _id: value._id,
                                                booking_short_id: value.booking_short_id,
                                                start_date: recurringEventStartEndInterval[z].startEvent,
                                                end_date: recurringEventStartEndInterval[z].endEvent,
                                                start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                service_title: value.service_title, //hol.HOLIDAY_TITLE,
                                                status: value.status,
                                                is_recurring: value.is_recurring,
                                                todays_status: false,
                                                clientInfo: value.clientInfo,
                                                interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : ''),
                                                bookingDetail: value                                   
                                            });
                                        }
                                   
                                    }                                                                                                                                     
                                } 
                            } 

                        }else if(value.recurrence_rule == 'yearly'){
                            var colorName = getRandomColor();
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "yearly", repeating_every_no, "");                    
                            if(recurringEventStartEndInterval.length > 0){
                                for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                    var dateExist = false;
                                    for(var x = 0; x < value.schedulerInfo.length; x++){
                                        if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                            dateExist = true;
                                            break;
                                        }else{
                                             dateExist = false;   
                                        }
                                    }
                                    if(dateExist){

                                    }else{
                                        if(recurringEventStartEndInterval[z].endEvent == ""){

                                        }else{
                                            finalResponse.events.push({
                                                _id: value._id,
                                                booking_short_id: value.booking_short_id,
                                                start_date: recurringEventStartEndInterval[z].startEvent,
                                                end_date: recurringEventStartEndInterval[z].endEvent,
                                                start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                service_title: value.service_title, //hol.HOLIDAY_TITLE,
                                                status: value.status,
                                                is_recurring: value.is_recurring,
                                                todays_status: false,
                                                clientInfo: value.clientInfo,
                                                interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : ''),
                                                bookingDetail: value
                                            });
                                        }
                                    }                                                                                                                                     
                               } 
                            }
                        }else if(value.recurrence_rule == 'custom (weekly)'){
                            var colorName = getRandomColor();
                            var weekArray = [];
                            for (var key in value.custom_weekly_repeat_on) {
                                if(value.custom_weekly_repeat_on[key] == true){
                                    weekArray.push(key);
                                }
                            }
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "custom (weekly)", repeating_every_no, weekArray);                    
                            if(recurringEventStartEndInterval.length > 0){
                                for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                    var dateExist = false;
                                    for(var x = 0; x < value.schedulerInfo.length; x++){
                                        if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                            dateExist = true;
                                            break;
                                        }else{
                                             dateExist = false;   
                                        }
                                    }
                                    if(dateExist){

                                    }else{
                                        if(recurringEventStartEndInterval[z].endEvent == ""){

                                        }else{
                                            finalResponse.events.push({
                                                _id: value._id,
                                                booking_short_id: value.booking_short_id,
                                                start_date: recurringEventStartEndInterval[z].startEvent,
                                                end_date: recurringEventStartEndInterval[z].endEvent,
                                                start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                service_title: value.service_title, //hol.HOLIDAY_TITLE,
                                                status: value.status,
                                                is_recurring: value.is_recurring,
                                                todays_status: false,
                                                clientInfo: value.clientInfo,
                                                interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : ''),
                                                bookingDetail: value
                                            });
                                        }
                                    }                                                                                                                                     
                               } 
                            }
                        }
                        callbackEvent()

                        function getDayString(day){
                            var dayString = ""
                            switch (day) {
                                case 0:
                                    dayString = "Sunday";
                                    break;
                                case 1:
                                    dayString = "Monday";
                                    break;
                                case 2:
                                    dayString = "Tuesday";
                                    break;
                                case 3:
                                    dayString = "Wednesday";
                                    break;
                                case 4:
                                    dayString = "Thursday";
                                    break;
                                case 5:
                                    dayString = "Friday";
                                    break;
                                case 6:
                                    dayString = "Saturday";
                            }
                            return dayString;
                        }

                        function getMonthString(month_no){
                          var monthString = ""
                            switch (month_no) {
                                case 0:
                                    monthString = "January";
                                    break;
                                case 1:
                                    monthString = "February";
                                    break;
                                case 2:
                                    monthString = "March";
                                    break;
                                case 3:
                                    monthString = "April";
                                    break;
                                case 4:
                                    monthString = "May";
                                    break;
                                case 5:
                                    monthString = "June";
                                    break;
                                case 6:
                                    monthString = "July";
                                    break;
                                case 7:
                                    monthString = "August";
                                    break;
                                case 8:
                                    monthString = "September";
                                    break;
                                case 9:
                                    monthString = "October";
                                    break;
                                case 10:
                                    monthString = "November";
                                    break;
                                case 11:
                                    monthString = "December";
                                    break;    
                            }
                            return monthString;
                        }

                        function addHoursInDate(recurringWeeklyDateOnly, startHours, startMinutes){
                            var newRecurringWeeklyDateOnly = new Date(recurringWeeklyDateOnly);
                            newRecurringWeeklyDateOnly.setHours(startHours);
                            newRecurringWeeklyDateOnly.setMinutes(startMinutes);
                            return moment(newRecurringWeeklyDateOnly);
                        }

                        function convertVirtualEventsDateIntoDateTime(startTime,endTime,stopTimeDateTime,startTimeOnly,endTimeOnly, month_start_date, month_end_date, interval, repeating_every_no, weekArray){    //function to find the recurring inetrvals:start/end            
                            var recurringDateTimeStartEndOfEvent = [];      
                              
                            //start Event Calculation//
                            var eventStartTime = startTimeOnly;
                            var eventEndTime = endTimeOnly;

                            var month_start_date = moment(month_start_date).startOf('day');
                            var month_end_date = moment(month_end_date).startOf('day');
                            var momentObjMonth_start_date = new Date(moment(month_start_date));
                            var momentObjMonth_end_date = new Date(moment(month_end_date));

                            var tmpStartTime = convertTo24Format(startTimeOnly);
                            var tmpEndTime = convertTo24Format(endTimeOnly);
                              
                            var localStartDateTime =  moment(startTime).utc();
                            var localEndDateTime = moment(endTime).utc();

                            var localTimeStopTime =  moment(stopTimeDateTime).utc();                                         
                            var startHours = new Date(localStartDateTime).getHours();
                            var startMinutes = new Date(localStartDateTime).getMinutes();
                            var startDayString = getDayString(new Date(localStartDateTime).getDay());
                            var startDateOfMonth = new Date(localStartDateTime).getDate();
                            var startMonthOfYear = getMonthString(new Date(localStartDateTime).getMonth());
                            //end of event Calculation//

                            var endHours = new Date(localEndDateTime).getHours();
                            var endMinutes = new Date(localEndDateTime).getMinutes();
                            var endDayString = getDayString(new Date(localEndDateTime).getDay());
                            var endDateOfMonth = new Date(localEndDateTime).getDate();
                            var endMonthOfYear = getMonthString(new Date(localEndDateTime).getMonth());

                            if(interval == "daily"){
                                var recurringDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(1).days();
                                var recurringDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(1).days();
                                if(recurringDatesForStart.all().length > 0){
                                    for(var i = 0 ; i<recurringDatesForStart.all().length; i++){ 
                                        if(i%repeating_every_no == 0){
                                            var recurringDateOnly =  recurringDatesForStart.all()[i]
                                            var isafter = moment(recurringDateOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent.push({
                                                startEvent : addHoursInDate(recurringDateOnly, startHours, startMinutes),
                                                endEvent : ""
                                            });
                                            recurringDateOnly = "";
                                        }else{
                                            continue;
                                        }
                                    }
                                }

                                if(recurringDatesForEnd.all().length > 0){
                                    var z = 0;
                                    for(var j = 0 ; j<recurringDatesForEnd.all().length; j++){
                                        if(j%repeating_every_no == 0){
                                            var recurringDateEndOnly =  recurringDatesForEnd.all()[j]
                                            var isafter = moment(recurringDateEndOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringDateEndOnly, endHours, endMinutes),
                                            recurringDateEndOnly = "";
                                            z++;
                                        }else{
                                            continue;
                                        }
                                    }
                                }

                            }else if(interval == "weekly"){
                                var weekDayStartString = [];
                                var weekDayEndString = [];
                                weekDayStartString.push(startDayString);
                                weekDayEndString.push(endDayString)
                                                                    
                                var recurringWeeklyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(weekDayStartString).daysOfWeek();
                                var recurringWeeklyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(weekDayEndString).daysOfWeek(); 
                                if(recurringWeeklyDatesForStart.all().length > 0){

                                    for(var i = 0; i<recurringWeeklyDatesForStart.all().length; i++){
                                        if(i%repeating_every_no == 0){
                                            var recurringWeeklyDateOnly =  recurringWeeklyDatesForStart.all()[i];
                                            var isafter = moment(recurringWeeklyDateOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent.push({
                                                startEvent : addHoursInDate(recurringWeeklyDateOnly, startHours, startMinutes),
                                                endEvent : ""
                                            });
                                            recurringWeeklyDateOnly = "";
                                        }else{
                                            continue;
                                        }
                                    }
                                }
                                if(recurringWeeklyDatesForEnd.all().length > 0){
                                    var z = 0;
                                    for(var j = 0 ; j<recurringWeeklyDatesForEnd.all().length; j++){
                                        if(j%repeating_every_no == 0){
                                            var recurringWeeklyDateEndOnly =  recurringWeeklyDatesForEnd.all()[j]
                                            var isafter = moment(recurringWeeklyDateEndOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringWeeklyDateEndOnly, endHours, endMinutes),
                                            recurringWeeklyDateEndOnly = "";
                                            z++;
                                        }else{
                                            continue;
                                        }
                                    }
                                } 
                            }else if(interval == "custom (weekly)"){
                                var weekDayStartString = weekArray;
                                var weekDayEndString = weekArray;
                                var arr = [];
                                var array1d = [];
                                var arr1d = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
                                for(var u=0; u<arr1d.length; u++){
                                    if(weekArray.indexOf(arr1d[u]) != -1){
                                        array1d.push(arr1d[u]);
                                    }
                                }

                                arr['sunday'] = 0;
                                arr['monday'] = 1;
                                arr['tuesday'] = 2;
                                arr['wednesday'] = 3;
                                arr['thursday'] = 4;
                                arr['friday'] = 5;
                                arr['saturday'] = 6;
                                var len = weekArray.length;
                                var recurringWeeklyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(weekDayStartString).daysOfWeek();
                                var recurringWeeklyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(weekDayEndString).daysOfWeek(); 
                                if(recurringWeeklyDatesForStart.all().length > 0){
                                    var t2,t3 = 0;
                                    for(var p=0; p < weekArray.length; p++){
                                        t2 = getDayString(new Date(recurringWeeklyDatesForStart.all()[0]).getDay());
                                        t3++;
                                        if(arr[t2.toLowerCase()] <= arr[array1d[p].toLowerCase()] ){
                                            break;
                                        }
                                    }
                                    for(var i = t3; i <= recurringWeeklyDatesForStart.all().length; i++){
                                        var recurringWeeklyDateOnly =  recurringWeeklyDatesForStart.all()[i-t3];
                                        var isafter = moment(recurringWeeklyDateOnly).isAfter(momentObjMonth_end_date);
                                        recurringDateTimeStartEndOfEvent.push({
                                            startEvent : addHoursInDate(recurringWeeklyDateOnly, startHours, startMinutes),
                                            endEvent : ""
                                        });
                                        recurringWeeklyDateOnly = "";
                                        if( i%len  == 0 ){
                                            var skip  = len*repeating_every_no - len;
                                            i = i + skip; 
                                        }
                                    }
                                }
                                if(recurringWeeklyDatesForEnd.all().length > 0){
                                    var t2,t3 = 0;
                                    for(var p=0; p < weekArray.length; p++){
                                        t2 = getDayString(new Date(recurringWeeklyDatesForStart.all()[0]).getDay());
                                        t3++;
                                        if(arr[t2.toLowerCase()] <= arr[array1d[p].toLowerCase()] ){
                                            break;
                                        }
                                    }
                                    var z = 0;
                                    for(var j = t3 ; j <= recurringWeeklyDatesForEnd.all().length; j++){
                                            var recurringWeeklyDateEndOnly =  recurringWeeklyDatesForEnd.all()[j-t3]
                                            var isafter = moment(recurringWeeklyDateEndOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringWeeklyDateEndOnly, endHours, endMinutes),
                                            recurringWeeklyDateEndOnly = "";
                                            z++;
                                        if(j%len  == 0 ){
                                            var skip  = len*repeating_every_no - len;
                                            j = j + skip;
                                        }
                                    }
                                } 
                            }else if(interval == "monthly"){
                                var recurringMonthlyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(startDateOfMonth).dayOfMonth();
                                var recurringMonthlyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(endDateOfMonth).dayOfMonth();
                                if(recurringMonthlyDatesForStart.all().length > 0){
                                    for(var i = 0 ; i<recurringMonthlyDatesForStart.all().length; i++){
                                        if(i%repeating_every_no == 0){
                                            var recurringMonthDateOnly =  recurringMonthlyDatesForStart.all()[i]
                                            recurringDateTimeStartEndOfEvent.push({
                                                startEvent :  addHoursInDate(recurringMonthDateOnly, startHours, startMinutes),
                                                endEvent : ""
                                            });
                                            recurringMonthDateOnly = "";
                                        }else{
                                            continue;
                                        }

                                    }
                                }
                                if(recurringMonthlyDatesForEnd.all().length > 0){
                                    var z = 0;
                                    for(var j = 0 ; j<recurringMonthlyDatesForEnd.all().length; j++){
                                        if(j%repeating_every_no == 0){
                                            var recurringMonthDateEndOnly =  recurringMonthlyDatesForEnd.all()[j];
                                            recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringMonthDateEndOnly, endHours, endMinutes),
                                            recurringMonthDateEndOnly = "";
                                            z++;
                                        }else{
                                            continue;
                                        }
                                    }
                                }
                            }else if(interval == "yearly"){ 
                                var recurringYearlyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(startDateOfMonth).daysOfMonth().every(startMonthOfYear).monthsOfYear();
                                var recurringYearlyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(endDateOfMonth).daysOfMonth().every(endMonthOfYear).monthsOfYear();
                                if(recurringYearlyDatesForStart.all().length > 0){
                                    for(var i = 0 ; i<recurringYearlyDatesForStart.all().length; i++){
                                        if(i%repeating_every_no == 0){
                                            var recurringYearlyDateOnly =  recurringYearlyDatesForStart.all()[i]
                                            recurringDateTimeStartEndOfEvent.push({
                                              startEvent : addHoursInDate(recurringYearlyDateOnly, startHours, startMinutes),
                                              endEvent : ""
                                            });
                                            recurringYearlyDateOnly = "";
                                        }else{
                                            continue;
                                        }
                                    }
                                }
                                if(recurringYearlyDatesForEnd.all().length > 0){
                                    var z = 0;
                                    for(var j = 0 ; j<recurringYearlyDatesForEnd.all().length; j++){
                                        if(j%repeating_every_no == 0){
                                            var recurringYearlyDateEndOnly =  recurringYearlyDatesForEnd.all()[j]
                                            var isafter = moment(recurringYearlyDateEndOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringYearlyDateEndOnly, endHours, endMinutes),
                                            recurringYearlyDateEndOnly = "";
                                            z++;
                                        }else{
                                            continue;
                                        }
                                    }
                                }  
                            }
                            return recurringDateTimeStartEndOfEvent;          
                        }

                        function convertTo24Format(timeStr){
                            var tmp=timeStr;
                            var tmpArr = tmp.split(':');
                            var t = tmpArr[1].split(' ')[1];
                            var hour= tmpArr[0].trim();
                            var minute= tmpArr[1].split(' ')[0];
                            if(t=='PM'){
                                if(hour!=12){
                                    hour = parseInt(hour) + 12;
                                }
                            } else if(t=='AM'){
                                if(hour==12){
                                    hour=0;
                                }
                            }
                            return { 'hour': hour, 'minute': minute};
                        }
                    }
                },function(err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            },
            function(finalResponse,callback){
                // console.log("before finalResponse.events",finalResponse.events.length);
                // console.log("before finalResponse.events",finalResponse.events);
                async.each(finalResponse.dateArray, function(date, cb) {
                    var obj = _.filter(finalResponse.events, function(d) {
                        if(moment(date.format('YYYY-MM-DD')).isSameOrAfter(d.start_date.format('YYYY-MM-DD')) && moment(date.format('YYYY-MM-DD')).isSameOrBefore(d.end_date.format('YYYY-MM-DD'))){
                            var startHours = new Date(d.start_date).getHours();
                            var startMinutes = new Date(d.start_date).getMinutes();
                            var start_date = moment(date.format('YYYY-MM-DD'));
                            var endHours = new Date(d.end_date).getHours();
                            var endMinutes = new Date(d.end_date).getMinutes();
                            var end_date = moment(date.format('YYYY-MM-DD'));
                            d.start_date = utility.addHoursInDate(start_date, startHours, startMinutes); 
                            d.end_date = utility.addHoursInDate(end_date, endHours, endMinutes); 
                            return d;
                        } 
                        // return (moment(date.format('YYYY-MM-DD')).isSameOrAfter(d.start_date.format('YYYY-MM-DD')) && moment(date.format('YYYY-MM-DD')).isSameOrBefore(d.end_date.format('YYYY-MM-DD'))) 
                    });
                    if(obj.length > 0){
                        for (var i = obj.length - 1; i >= 0; i--) {
                            finalResponse.tempArr.push(obj[i]);
                        }
                        cb(null,finalResponse);
                    }else{
                        cb(null,finalResponse)
                    }
                }, function(err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        // console.log("finalResponse", finalResponse.tempArr);
                        callback(null, finalResponse);
                    }
                });
            },
            function(finalResponse,callback){
                // console.log("before finalResponse.events",finalResponse.events.length);
                // console.log("before finalResponse.events",finalResponse.events);
                async.each(finalResponse.tempArr, function(todayRecord, cbt) {

                    var currentFrom = moment(todayRecord.start_date).startOf('day');
                    var currentTo = moment(todayRecord.end_date).endOf('day');

                    var currentMomentObjFrom = new Date(moment(currentFrom));
                    var currentMomentObjTo = new Date(moment(currentTo));
                    console.log("currentMomentObjFrom",currentMomentObjFrom);
                    console.log("currentMomentObjTo",currentMomentObjTo);
                    CheckInOutModel.findOne({
                        booking_id : mongoose.Types.ObjectId(todayRecord._id),
                        is_deleted: false,
                        status: true,
                        check_io_approval: 'approved',
                        $and:[
                            {check_in_date: {$gte: currentMomentObjFrom}}, 
                            {check_in_date: {$lte: currentMomentObjTo}}
                        ]
                    }).exec(function(err, check_in_out_record){
                        if(err){
                            callback(err, false);
                        }else {
                            // console.log("check_in_out_record", check_in_out_record);
                            if(check_in_out_record == null){
                                finalResponse.tempArry.push(todayRecord);
                            }
                            cbt();
                        }
                    })
                }, function(err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        console.log("finalResponse", finalResponse.tempArry);
                        callback(null, finalResponse);
                    }
                });
            },

        ], function(err, data) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            } else {

                res.json({
                    status: req.config.statusCode.success,
                    data: data.tempArry,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }
        });  
    },

    downloadPaperVoucherByInterpreter: function (req, res, next) {
        var start_date = req.body.start_date;
        var end_date = req.body.end_date;
        console.log(end_date);
        SchedulerModel.findOne({_id: req.body.id, is_deleted:false})
            .populate('interpreter_id', 'first_name last_name profile_pic')
            .populate('client_id', 'first_name last_name')
            .populate('language_interprete_from', 'language_name')
            .populate('language_interprete_into', 'language_name')
            .then((result) => {
                AgencyModel.findOne({_id: result.agency_id, status: true}).exec(function(err,agencyData){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })
                    }else if(agencyData){

                        var logoUrl = req.config.email.base_url+ (agencyData.profile_pic ? agencyData.profile_pic :req.config.email.logo_url);
                        var profileUrl = req.config.email.base_url+ (result.interpreter_id.profile_pic ? result.interpreter_id.profile_pic: req.config.upload_dir.USER_PROFILE_PIC);
                        var timestamp = Number(new Date());
                        var options = { "format": "Letter"};
                        var filename = "doc" + timestamp + '_' + common.randomToken(6) +  ".pdf";
                        var path = "./../client/users/assets/uploads/reports/" + filename;
                       
                        var headerHtml = "<!DOCTYPE html><head><meta charset='utf-8' /><meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'/><meta http-equiv='X-UA-Compatible' content='IE=edge' /><meta http-equiv='Content-Type' content='text/html; charset=utf-8'><title>HTML</title></head>"+
                                           "    <div style='font-size: 9px; margin:0 auto;width:100%; min-height: 611px;'>"+
                                           "    <img src="+logoUrl+" alt='company logo' style='position: absolute;height:350px;padding-left: 5px; opacity: 0.1;  margin-left: 120px; margin-top: 200px; width: 350px; z-index: -1;border-radius: 100%; padding-top:5px;'>"+
                                           "    <div style='float:left;width:100%;border:1px solid #88191c;'>"+
                                           "    <div style='float:left;width:100%;border-bottom:1px solid #88191c;'>"+
                                           "    <div style='float:left;'>"+
                                           "    <img src="+logoUrl+" alt='company logo' style='width:50px;padding-left: 2px;border-radius: 100%; padding-top:1px;'>"+
                                           "    </div>"+
                                           "    <div style='float:left;padding-top: 18px;padding-left: 20px;color:#602826;font-weight:bold;'>"+agencyData.agency_name+"</div>"+
                                           "    <div style='float: right;'>"+ 
                                           "    <div style='float:left;padding-top: 18px;'><span style='float:left; font-weight:bold;  padding-right: 5px;'>Interpreter’s name:</span>"+result.interpreter_id.first_name.charAt(0).toUpperCase()+result.interpreter_id.first_name.slice(1).toLowerCase()+ ' ' +result.interpreter_id.last_name.charAt(0).toUpperCase()+result.interpreter_id.last_name.slice(1).toLowerCase()+"</div>"+
                                           "    <img src="+profileUrl+" alt='Interpreter profile' style='float: left; margin-left: 5px; margin-top:3px; border: 1px solid #777; margin-right: 4px; width: 36px; height:36px; border-radius: 100%; padding-bottom: 1px;'>"+
                                           "    </div>"+
                                           "    </div>";

                        var footerHtml =   "";

                        var html = "    <div style='float:left;width:100%;'>"+
                                           "    <div style='float:left;width:100%;text-align:center;font-weight:bold;padding:10px 0; margin-bottom:10px;'>Event Description</div>"+
                                           "    <div style='width:100%;float:left;margin-bottom:10px;'>"+
                                           "    <div style='float:left;width:50%;'><span style='font-weight:bold;float: left;width: 90px;padding-left: 5px;'>Service Title:</span>"+result.service_title+"</div>"+
                                           "    <div style='float:left;width:50%;'><span style='font-weight:bold;float: left;width: 90px;'>Date:</span>"+moment(start_date).format('ddd DD-MMM-YYYY')+"</div>"+
                                           "    <div style='float:left;width:50%;'><span style='font-weight:bold;float: left;width: 90px;padding-left: 5px;'>Time:</span>"+result.start_time+ ' - '+result.end_time+"</div>"+
                                           "    <div style='float:left;width:50%;'><span style='font-weight:bold;float: left;width: 90px;'>Contact Info:</span>"+result.client_id.first_name.charAt(0).toUpperCase()+result.client_id.first_name.slice(1).toLowerCase()+ ' ' +result.client_id.last_name.charAt(0).toUpperCase()+result.client_id.last_name.slice(1).toLowerCase()+"</div>"+
                                           "    <div style='float:left;width:50%;'><span style='font-weight:bold;float: left;width: 90px;padding-left: 5px;'>From Language:</span>"+result.language_interprete_from.language_name.charAt(0).toUpperCase()+result.language_interprete_from.language_name.slice(1).toLowerCase()+"</div>"+
                                           "    <div style='float:left;width:50%;'><span style='font-weight:bold;float: left;width: 90px;'>Into Language:</span>"+result.language_interprete_into.language_name.charAt(0).toUpperCase()+result.language_interprete_into.language_name.slice(1).toLowerCase()+"</div>"+
                                           "    <div style='float:left;width:50%;'><span style='font-weight:bold;float: left;width: 90px;padding-left: 5px;'>Address:</span>"+result.address+"</div>"+
                                           "    </div>"+
                                           "    </div>"+
                                  
                                           "    <div style='float:left;width:100%;border-bottom:1px solid #88191c;'>"+
                                           "    <table style='float:left;width:100%;'>"+
                                           "    <thead style='background:#a6b6cb;'>"+
                                           "    <tr>"+
                                           "    <th style='text-align:center;padding:5px;'>Case Name/LEP Name</th>"+
                                           "    <th style='text-align:center;padding:5px;'>Case#</th>"+
                                           "    <th style='text-align:center;padding:5px;'>Comments</th>"+
                                           "    </tr>"+
                                           "    </thead>"+
                                           "    <tbody style='background:#eee;'>"+
                                           "    <tr>"+
                                           "    <td style='text-align:center;'> - </td>"+
                                           "    <td style='text-align:center;'> - </td>"+
                                           "    <td style='text-align:center;'> - </td>"+
                                           "    </tr>"+
                                           "    </tbody>"+
                                           "    </table>"+
                                           "    </div>"+

                                           "    <div style='float:left;width:100%;border-bottom:1px solid #88191c;'>"+
           
                                           "    <div style='width:30%;float:left;border-right:1px solid #88191c;height:100px;padding:5px;'>Stamp In/Time in</div>"+
                                           "     <div style='width:30%;float:left;border-right:1px solid #88191c;height:100px;padding:5px;'>Stamp Out/Time out</div>"+
                                           "     <div style='width:30%;float:left;padding:5px;'>Report:</div>"+
                                           "    </div>"+
                                               
                                           "    <div style='float:left;width:100%;'>"+
                                               
                                           "     <div style='width:48.15%;float:left;border-right:1px solid #88191c;height:100px;padding:5px;'>Authorizing Signature</div>"+
                                           "     <div style='width:48.15%;float:left;height:100px;padding:5px;'>Authorizing Name</div>"+
                                               
                                           "    </div>"+

                                           "    </div>"+
                                           "    </div>";
                        var finalHtml = headerHtml + html + footerHtml;
                        pdf.create(finalHtml, options).toFile(path, function(err, data) {
                            if(err){
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("ERROR")
                                })
                            } else{
                                 res.json({
                                    status: req.config.statusCode.success,
                                    data: path,
                                    message: i18n.__("Get file path successfully")
                                });
                            } 
                        });
                    }
                })
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("NO_RECORD_FOUND")
                })
            });
    },

}   

