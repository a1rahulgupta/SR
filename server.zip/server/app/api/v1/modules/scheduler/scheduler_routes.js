module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];

    var scheduler_ctrl = require('./controllers/scheduler_ctrl')

    router.get('/scheduler/listBookings', middlewares, scheduler_ctrl.listBookings)
    router.get('/scheduler/getBooking/:id', middlewares, scheduler_ctrl.getBooking)
    // router.get('/bookings/getBookingViewById/:id', middlewares, booking_ctrl.getBookingViewById)
    router.post('/scheduler/addBooking', middlewares, scheduler_ctrl.addBooking)
    // router.post('/bookings/updateBooking', middlewares, booking_ctrl.updateBooking)

    //scheduler work start
    router.post('/scheduler/addEventName', middlewares, scheduler_ctrl.addEventName);
    router.get('/scheduler/getEventName', middlewares, scheduler_ctrl.getEventName);
    router.post('/scheduler/addSchedule', middlewares, scheduler_ctrl.addSchedule);
    router.post('/scheduler/getAllBookings', middlewares, scheduler_ctrl.getAllBookings);
    router.post('/scheduler/updateCurrentOccurenceEvent', middlewares, scheduler_ctrl.updateCurrentOccurenceEvent);
    router.post('/scheduler/deleteCurrentEvent', middlewares, scheduler_ctrl.deleteCurrentEvent);
    router.post('/scheduler/deleteAllEvent', middlewares, scheduler_ctrl.deleteAllEvent);
    router.delete('/scheduler/deleteEvent/:id', middlewares, scheduler_ctrl.deleteEvent);
    router.post('/scheduler/deleteCurrentAndFollowingEvents', middlewares, scheduler_ctrl.deleteCurrentAndFollowingEvents);
    router.post('/scheduler/getAgencyEventList', middlewares, scheduler_ctrl.getAgencyEventList);
    router.post('/scheduler/searchBookingByDateScheduler', middlewares, scheduler_ctrl.searchBookingByDateScheduler);
    router.get('/scheduler/getEventViewById/:id', middlewares, scheduler_ctrl.getEventViewById);
    router.get('/scheduler/getEventById/:id', middlewares, scheduler_ctrl.getEventById);
    router.delete('/scheduler/deleteEvent/:id', middlewares, scheduler_ctrl.deleteEvent);
    router.post('/scheduler/getEventInterpretersLocation', middlewares, scheduler_ctrl.getEventInterpretersLocation);
    router.post('/scheduler/sendEventRequestToInterpreters', middlewares, scheduler_ctrl.sendEventRequestToInterpreters);
    router.post('/scheduler/getInterpreterBookingList', middlewares, scheduler_ctrl.getInterpreterBookingList);
    router.get('/scheduler/getBookingViewByInterpreterId/:id', middlewares, scheduler_ctrl.getBookingViewByInterpreterId)
    router.get('/scheduler/getBookingViewByBookingId/:id', middlewares, scheduler_ctrl.getBookingViewByBookingId)
    router.post('/scheduler/getClientBookingList', middlewares, scheduler_ctrl.getClientBookingList);
    router.get('/scheduler/getBookingViewByClientId/:id', middlewares, scheduler_ctrl.getBookingViewByClientId)
    router.post('/scheduler/addEventByClient', middlewares, scheduler_ctrl.addEventByClient);
    router.post('/scheduler/getTodaysAgencyBookingList', middlewares, scheduler_ctrl.getTodaysBookingList);
    router.post('/scheduler/getTodaysInterpreterBookingList', middlewares, scheduler_ctrl.getTodaysBookingList);
    router.post('/scheduler/getTodaysClientBookingList', middlewares, scheduler_ctrl.getTodaysBookingList);
    router.post('/scheduler/getInterpreterCompletedBooking', middlewares, scheduler_ctrl.getCompletedBookings);
    router.post('/scheduler/getClientCompletedBooking', middlewares, scheduler_ctrl.getCompletedBookings);
    router.post('/scheduler/getAgencyCompletedBookings', middlewares, scheduler_ctrl.getCompletedBookings);
    router.post('/scheduler/getAgencyPendingBookings', middlewares, scheduler_ctrl.getPendingBookings);
    router.post('/scheduler/getInterpreterPendingBookings', middlewares, scheduler_ctrl.getPendingBookings);
    router.post('/scheduler/getClientPendingBookings', middlewares, scheduler_ctrl.getPendingBookings);
    router.post('/scheduler/downloadPaperVoucherByInterpreter', middlewares, scheduler_ctrl.downloadPaperVoucherByInterpreter);
             
    return router;
}