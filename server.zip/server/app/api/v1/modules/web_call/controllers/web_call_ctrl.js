const _ = require("lodash");
const moment = require('moment');
const i18n = require("i18n");
const util = require('util');
const mongoose = require('mongoose');
const santize = __rootRequire('app/utils/santize');

//Models 
const User = mongoose.model('Users');
const AgencyModel = mongoose.model('Agencies');
const ClientModel = mongoose.model('Clients');
const RoleModel = mongoose.model('Roles');
const InterpreterModel = mongoose.model('Interpreters');
const AgencyUser = mongoose.model('Agency_users');
const TwilioKeysModel = mongoose.model('Twilio_keys');
const SchedulerModel = mongoose.model('Schedulers');
const uuidV4 = require('uuid/v4');
const emailSend = __rootRequire('app/core/email');
const common = __rootRequire('app/config/common.js');
const fs = require('fs');
const path = require('path');
const twilioSms = __rootRequire('app/utils/twilioSms');
const config = __rootRequire('app/config/config.js');
const async = require('async');
const twilio = require('twilio');
const accountSid = 'ACe4bca396fcc625235348318d2be36508';
const authToken = '9c03c854c5643dd1651462f316ea88d8';
const applicationSid = 'APc60bd72b36cb4b38ba62bc26403ccad2';
const toll_free_number = '+12342035097';
const VoiceResponse = require('twilio').twiml.VoiceResponse;
var ClientCapability = require('twilio').jwt.ClientCapability;



module.exports = {   

    webCallToInterpreter: function (req, res, next) {
        console.log("it comes in webCallToInterpreter");
        // SchedulerModel.findOne({_id: id})
        res.json({
            status: req.config.statusCode.success,
            data: req.body,
            message: i18n.__("DATA_FOUND_SUCCESSFULLY")
        });
    },

    genrateTwilioToken: function(req, res, next){
        TwilioKeysModel.findOne({
            status: true,
            is_deleted: false 
        }).exec(function(err, twilioKeys){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            }else if(twilioKeys){
                var capability = new ClientCapability({
                    accountSid: twilioKeys.accountSid,
                    authToken: twilioKeys.authToken        
                });
                
                capability.addScope(
                    new ClientCapability.OutgoingClientScope({
                        applicationSid: twilioKeys.application_sid
                    })
                );
                capability.addScope(new ClientCapability.IncomingClientScope(req.body.page));
                var token = capability.toJwt();
                res.json({
                    status: req.config.statusCode.success,
                    data: { token: token },
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });      
            }else{
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("TWILIO_KEYS_NOT_FOUND")
                })
            }
        })
    },

    twilioWebhookConnect :function(req, res, next) {
        if(req.config.env == 'aws'){
            var baseUrl = 'https://www.interpreting.works';
        }else{
            var baseUrl = req.config.email.base_url;
        }

        var phoneNumber = req.body.phoneNumber;
        var callerId = toll_free_number;
        var twiml = new VoiceResponse();
    
        var dial = twiml.dial({
            callerId : callerId,
            record: 'record-from-ringing',
            recordingStatusCallback: 'http://3d946ba1.ngrok.io/api/v1/web_call/recordingTwilioStatusCallback'  
        });

        // var dial = twiml.dial({
        //     callerId : callerId,
        //     record: 'record-from-ringing',
        //     recordingStatusCallback: baseUrl+'/api/v1/web_call/recordingTwilioStatusCallback'  
        // });

        if (phoneNumber != null) {
            dial.number(phoneNumber);
        } else {
            dial.client("support_agent");
        }
        res.send(twiml.toString());
    },

    recordingTwilioStatusCallback: function(req,res, next) {
        console.log('asdf',req.body);
    }


}