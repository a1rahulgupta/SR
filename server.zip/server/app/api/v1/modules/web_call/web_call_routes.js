module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];
    var twilio = require('twilio');
    var web_call_ctrl = require('./controllers/web_call_ctrl')

    router.post('/web_call/webCallToInterpreter', middlewares, web_call_ctrl.webCallToInterpreter);

    // POST /token/generate
    router.post('/web_call/initializeTwilio', web_call_ctrl.genrateTwilioToken);

    // POST /calls/connect
    router.post('/web_call/connect', twilio.webhook({validate: false}), web_call_ctrl.twilioWebhookConnect);
    router.post('/web_call/recordingTwilioStatusCallback', twilio.webhook({validate: false}), web_call_ctrl.recordingTwilioStatusCallback);

    return router;
}