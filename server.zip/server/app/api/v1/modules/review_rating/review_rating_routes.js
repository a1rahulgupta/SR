module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];

    var review_rating_ctrl = require('./controllers/review_rating_ctrl');
    router.post('/review/addReviewRatingByClient',middlewares, review_rating_ctrl.addReviewRatingByClient);
    router.get('/review/getInterpreterRatingById',middlewares, review_rating_ctrl.getInterpreterRatingById);
    router.get('/review/getReviewRatingByBookingId/:id',middlewares, review_rating_ctrl.getReviewRatingByBookingId);

}