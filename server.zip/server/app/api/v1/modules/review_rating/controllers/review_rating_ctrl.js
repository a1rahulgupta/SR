const _ = require("lodash");
const moment = require('moment');
const Joi = require('joi');
const i18n = require("i18n");
const formidable = require('formidable');
const bcrypt = require('bcrypt');
const util = require('util');
const mongoose = require('mongoose');
const waterfall = require('async-waterfall');
const santize = __rootRequire('app/utils/santize');
const image = __rootRequire('app/utils/image');
const text = __rootRequire('app/utils/text');
const ReviewRatingModel = mongoose.model('ReviewRatings');
const InterpreterModel = mongoose.model('Interpreters');
const ClientModel = mongoose.model('Clients');
const Booking = mongoose.model('Bookings');
const AgencyModel = mongoose.model('Agencies');
const SchedulerModel = mongoose.model('Schedulers');
const CheckInOutModel = mongoose.model('Check_in_outs');

module.exports = {
	// addReviewRatingByClient : function(req, res, next){
	// 	console.log("Inside addReviewAdnRating", req.body);
	// 	Booking.findById({_id: req.body.bookingId, is_deleted:false}, function(err, bookingData){
	// 		if(err){
	// 			res.json({
 //                    status: req.config.statusCode.error,
 //                    data: [],
 //                    message: i18n.__("ERROR")
 //                });
	// 		} else{
	// 			if(bookingData){
	// 				InterpreterModel.findById({_id: bookingData.interpreter_id, is_deleted:false}, function(err, interpreterData){
	// 					if(err){
	// 						res.json({
	// 		                    status: req.config.statusCode.error,
	// 		                    data: req.body,
	// 		                    message: i18n.__("ERROR")
	// 		                })
	// 					} else{
	// 						if(interpreterData){
	// 							var addData = {
	// 								agency_id: req.user.agency_id,
	// 								booking_id: bookingData._id,
	// 								client_id: bookingData.client_id,
	// 								interpreter_id: bookingData.interpreter_id,
	// 								review: req.body.review,
	// 								rating: req.body.rating,
	// 								rating_from: req.user.id,
	// 								rating_to: interpreterData.user_id
	// 							}
	// 							 ReviewRating = new ReviewRatingModel(addData)
	// 							 ReviewRating.save()
	// 							 	.then((reviewData)=>{
	// 							 		bookingData.status = 'closed';
	// 							 		bookingData.save()
	// 							 			.then((newBookingData)=> {
	// 							 				console.log("newBookingData", newBookingData);
	// 							 				res.json({
	// 							                    status: req.config.statusCode.success,
	// 							                    data: reviewData,
	// 							                    message: i18n.__("Review data added successfully")
	// 							                });
	// 							 			})
	// 							 	})
	// 							 	.catch((err) => {
	// 					                res.json({
	// 					                    status: req.config.statusCode.error,
	// 					                    data: req.body,
	// 					                    message: i18n.__("Error while adding review details")
	// 					                })

	// 					            });
	// 						} else{
	// 							res.json({
	// 			                    status: req.config.statusCode.error,
	// 			                    data: req.body,
	// 			                    message: i18n.__("Error while finding interpreter data")
	// 			                })
	// 						}
	// 					}
	// 				})
	// 			} else{
	// 				res.json({
	//                     status: req.config.statusCode.error,
	//                     data: [],
	//                     message: i18n.__("ERROR")
 //                	});
	// 			}
	// 		}
	// 	})

	// },

	getReviewRatingByBookingId: function(req, res, next){
        ReviewRatingModel.findOne({booking_id:req.params.id, is_deleted:false})
            .then((result) => {
                res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    message: i18n.__("Review get successfully")
                });
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });
	},

	getInterpreterRatingById: function(req, res, next){
        ReviewRatingModel.aggregate([
            { $match: { rating_to: mongoose.Types.ObjectId(req.user.id), is_deleted: false } }, {
                "$group": {
                    "_id": '$rating_to',
                    "avgRating": { "$avg": { "$ifNull": ["$rating", 0] } }
                }
            }
        ], function(err, rating) {
            var rate = 0;
            if (rating[0]) {
                if (rating[0].avgRating) {
                    rate = rating[0].avgRating;
                }
            }
            res.json({
                status: req.config.statusCode.success,
                data: rate,
                message: i18n.__("Review get successfully")
            });	
        });
	},

	addReviewRatingByClient : function(req, res, next){
		console.log("Inside addReviewAdnRating", req.body);
		var finalResponse = {};
		finalResponse.reviewData = {};
        waterfall([
            function(callback) {
            	CheckInOutModel.findById({
					_id: req.body.bookingId,
					is_deleted:false, 
					status: true
				}, function(err, bookingData){
					if(err){
						callback(err, null);
					} else{
						bookingData.review = req.body.review;
						bookingData.rating = req.body.rating;
						bookingData.is_review_rating_done = true;
						bookingData.save(function(err, updateRecord){
							if(err){
								callback(err, null);		
							}else{
								finalResponse.reviewData = updateRecord;
								callback(null, finalResponse);
							}
						})
					}
				})
            }
        ], function(err, data) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                });
            } else {
                res.json({
                    status: req.config.statusCode.success,
                    data: finalResponse.reviewData,
                    message: i18n.__("REVIEW_RATING_ADDED")
                });
            }
        });
	},

}