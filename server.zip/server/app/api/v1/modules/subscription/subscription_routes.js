module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];
    var subscription_ctrl = require('./controllers/subscription_ctrl');

    router.post('/subscription',middlewares, subscription_ctrl.getAllSubscription);
    router.get('/subscription',subscription_ctrl.getAllSubscriptionData);
    router.post('/subscription/add',middlewares, subscription_ctrl.addSubscription);
    router.post('/subscription/updatesubscription',middlewares, subscription_ctrl.updateSubscription);
    router.delete('/subscription/deletesubscription/:id',middlewares, subscription_ctrl.deleteSubscription);
    router.post('/subscription/changeSubscriptionStatus', middlewares, subscription_ctrl.changeSubscriptionStatus);
    router.get('/subscription/getAllSubscriptionsBySuperAdmin',middlewares, subscription_ctrl.getAllSubscriptionData);
    router.get('/subscription/getAllSubscriptionPlanByAgency',middlewares, subscription_ctrl.getAllSubscriptionData);
    router.get('/subscription/:id',middlewares, subscription_ctrl.getSubscriptionById);


    return router;
}