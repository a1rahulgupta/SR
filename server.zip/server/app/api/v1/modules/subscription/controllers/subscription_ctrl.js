const _ = require("lodash");
const moment = require('moment');
const Joi = require('joi');
const i18n = require("i18n");
const mongoose = require('mongoose');
const santize = __rootRequire('app/utils/santize');
var shortid = require('shortid');
//Models
const SubscriptionModel = mongoose.model('Subscriptions'); 
const User = mongoose.model('Users');
const AgencyModel = mongoose.model('Agencies');
const ClientModel = mongoose.model('Clients');
const InterpreterModel = mongoose.model('Interpreters');
const EmailTemplateModel = mongoose.model('Email_Templates');
const AgencyUser = mongoose.model('Agency_users');
const Services = mongoose.model('Services');

module.exports = {

    getAllSubscription(req, res, next) {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            is_deleted: false
        }
        // var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                'subscription_id': new RegExp(searchText, 'gi')
            },
            {
                'plan_name': new RegExp(searchText, 'gi')
            },
            {
                'interval': new RegExp(searchText, 'gi')
            }
            ];
        }
        SubscriptionModel.find(condition)
        .sort(sorting)
        .skip(parseInt(skip))
        .limit(parseInt(count))
        .lean().exec(function(err, subscription) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else if (subscription) {
                SubscriptionModel.find(condition)
                .count()
                .exec(function(err, totalCount) {
                    if (err) {
                        res.json({
                            code: 404,
                            message: 'TotalCount Not Correct'
                        })
                    } else {
                        res.json({
                            status: req.config.statusCode.success,
                            data: subscription,
                            count: totalCount
                        });
                    }
                });
            } else {
                res.json({
                    code: 404,
                    message: "No data found"
                })
            }
        }).catch(function(err) {
           res.json({
            status: req.config.statusCode.error,
            data: [],
            count: 0,
            message: i18n.__("ERROR")
        });
       })
    },

    getAllSubscriptionData: function (req, res, next) {
        SubscriptionModel.find({is_deleted:false})
        .then((result)=>{
            res.json({
                status: req.config.statusCode.success,
                data: result,
                message: i18n.__("Get subscription data succesfully")
            });
        }).catch((err)=>{
            res.json({
                status: req.config.statusCode.success,
                data: {},
                message: i18n.__("ERROR")
            });
        })
    },

    getSubscriptionById: function (req, res, next) {
        SubscriptionModel.findOne({_id: req.params.id})
        .then((result)=>{
            res.json({
                status: req.config.statusCode.success,
                data: result,
                message: i18n.__("Get subscription data succesfully")
            });
        }).catch((err)=>{
            res.json({
                status: req.config.statusCode.success,
                data: {},
                message: i18n.__("ERROR")
            });
        })
    },

    addSubscription: function (req, res, next) {
        var subscription_id = shortid.generate();
        req.body.subscription_id = subscription_id;
        subscription = new SubscriptionModel(req.body);
        subscription.status = true;
        subscription.save()
        .then((subscriptionData) => {
            res.json({
                status: req.config.statusCode.success,
                data: subscriptionData,
                message: i18n.__("Subscription details saved successfully")
            });
        }).catch((err) => {
            console.log("ERR", err);
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("Error while adding subscription details")
            })

        });
    },

    updateSubscription: function (req, res, next) {
        var updateData = req.body;
        SubscriptionModel.findOneAndUpdate({
            _id: req.body._id,

        }, {
            $set: updateData

        })
        .then((result) => {
            res.json({
                status: req.config.statusCode.success,
                data: result,
                message: i18n.__("Subscription details updated successfully")
            });
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })

        });

    },



    deleteSubscription: function (req, res, next) {
        SubscriptionModel.findOneAndUpdate({
            _id: req.params.id,
        }, {
            $set: {
                is_deleted: true
            }
        }, {
            new: true
        })
        .then((result) => {
            res.json({
                status: req.config.statusCode.success,
                data: result,
                message: i18n.__("Subscription details deleted successfully")
            });
        }).catch((err) => {

            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })

        });

    },

    changeSubscriptionStatus: function (req, res, next) {
        SubscriptionModel.findOneAndUpdate({
            _id:req.body.id
        },{
            status:req.body.status
        })
        .then((result)=>{
            res.json({
                status: req.config.statusCode.success,
                data: result,
                message: i18n.__('Subscription ' + ((req.body.status == true) ? 'activated' : 'deactivated') + ' successfully')
            });
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })

        });
    }
}