const _ = require("lodash");
const moment = require('moment');
const i18n = require("i18n");
const util = require('util');
const mongoose = require('mongoose');
const shortid = require('shortid');
const santize = __rootRequire('app/utils/santize');
const geolib = require('geolib');

//Models 
const User = mongoose.model('Users');
const AgencyModel = mongoose.model('Agencies');
const ClientModel = mongoose.model('Clients');
const RoleModel = mongoose.model('Roles');
const InterpreterModel = mongoose.model('Interpreters');
const AgencyUser = mongoose.model('Agency_users');
const BookingModel = mongoose.model('Bookings');
const CheckInOutModel = mongoose.model('Check_in_outs');
const VideoCallModel = mongoose.model('Video_calls');
const uuidV4 = require('uuid/v4');
const emailSend = __rootRequire('app/core/email');
const common = __rootRequire('app/config/common.js');
const fs = require('fs');
const path = require('path');
const async = require('async');

module.exports = {
	// saveChat: function(req, res, next){
	// 	console.log("in savechat");
	// }
}