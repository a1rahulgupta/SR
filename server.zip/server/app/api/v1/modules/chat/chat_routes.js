module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];
    var chat_ctrl = require('./controllers/chat_ctrl')

    // router.post('/chat/saveChat', middlewares, chat_ctrl.saveChat);


    return router;
}