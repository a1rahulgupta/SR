module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];

    var user = require('./controllers/user_ctrl');
    router.get('/user', user.index);
    router.get('/user/checklogin', user.checklogin);
    router.post('/user/login', user.login);
    router.post('/user/loginByOffice', user.loginByOffice);

    router.post('/user/forgot_pw', user.forgot_pw);
    router.post('/user/reset_pw', user.reset_pw);
    router.post('/user/activate_account', user.activate_account);
    router.get('/user/validate_link', user.validate_link);
    router.post('/user/saveProfile', middlewares, user.save_profile);
    router.get('/user/getProfile', middlewares, user.get_profile);
    router.get('/user/checkEmailAddress', middlewares, user.check_email_address);
    router.get('/user/checkProfileEmailAddress', middlewares, user.check_profile_email_address);

    router.post('/user/change_email', middlewares, user.change_email);

    router.get('/user/checkSubDomain', middlewares, user.check_sub_domain);
    router.get('/user/checkCompanyName', middlewares, user.check_agency_name);
    router.post('/user/change_password', middlewares, user.change_password);


    /* Admin forgot password */
    router.post('/user/forgotPassword', user.forgotPassword);

    router.post('/user/setNewPassword', user.setNewPassword);

    router.get('/user/enterPassword', user.enterPassword);

    /* Admin reset password */
    router.put('/user/resetPassword', user.resetPassword);
    router.post('/user/changePassword', middlewares, user.changePassword);
    router.get('/user/getEmailUsingKey/:id', user.getEmailUsingKey);
    router.get('/user/getBookingDetails/:id', user.getBookingDetails);

    router.post('/user/completeUserRegistration', user.completeUserRegistration);
    router.get('/user/getEmailUsingPassword/:id', user.getEmailUsingPassword);
    router.post('/user/saveBookingRequest', user.saveBookingRequest);
    router.post('/user/saveEventRequest', user.saveEventRequest);
    

    return router;
}