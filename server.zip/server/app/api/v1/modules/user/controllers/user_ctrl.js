const jwt = require('jsonwebtoken');
const Joi = require('joi');
const moment = require('moment');
const bcrypt = require('bcrypt');
const i18n = require("i18n");
const _ = require("lodash");
const mongoose = require('mongoose');

const crypto = __rootRequire('app/utils/crypto');
const santize = __rootRequire('app/utils/santize');
const file = __rootRequire('app/core/file');

const User = mongoose.model('Users');
const Agency = mongoose.model('Agencies');
const AgencyUser = mongoose.model('Agency_users');
const ClientModel = mongoose.model('Clients');
const InterpreterModel = mongoose.model('Interpreters');
const RoleModel = mongoose.model('Roles');
const AdminModel = mongoose.model('Admin');
const EmailTemplate = mongoose.model('Email_Templates');
const BookingRequestModel = mongoose.model('Booking_request');
const Booking = mongoose.model('Bookings');
const SchedulerModel = mongoose.model('Schedulers');
var nodemailer = require('nodemailer');
var async = require("async");
const emailSend = __rootRequire('app/core/email');
var path = require('path');
const twilioSms = __rootRequire('app/utils/twilioSms');

module.exports = {  
    index: function (req, res, next) {
        User.find({
            email: req.body.email,
            password: req.body.password
        }, (err, docs) => {
            res.json({
                status: req.config.statusCode.success,
                user: req.user
            });
        })

    },
    checklogin: function (req, res, next) {
        crypto.ensureAuthorized(req, res, function () {
            res.json({
                status: req.config.statusCode.success,
                user: req.user
            });
        });
    },

    login: function (req, res, next) {
        req.body = santize.escape(req.body);
        var Data = {
            "email": req.body.email,
            "password": req.body.password
        };
        var schema = Joi.object().keys({
            "email": Joi.string().required(),
            "password": Joi.string().required()
        });
        Joi.validate(Data, schema, (err, value) => {
            if (err) {
                res.status(200).send({
                    status: req.config.statusCode.invalid,
                    error: err
                });
            } else {
                User
                    .findOne({
                        email: Data.email.toLowerCase()
                    })
                    .populate('role_id')
                    .exec()
                    .then((result) => {
                        var rs = result;
                        if (!rs) {
                            res.status(200).json({
                                status: req.config.statusCode.invalid,
                                data: {
                                    'isLoggedIn': false,
                                    'user': null,
                                    'token': null
                                },
                                error: i18n.__("AUTH_ERROR")
                            });
                        } else if (rs.is_deleted == 1) {
                            res.status(200).json({
                                status: req.config.statusCode.invalid,
                                data: {
                                    'isLoggedIn': false,
                                    'user': null,
                                    'token': null
                                },
                                error: i18n.__("IS_DELETED_ERROR")
                            });
                        } else if (rs.activation_key && !rs.password) {
                            res.status(200).json({
                                status: req.config.statusCode.invalid,
                                data: {
                                    'isLoggedIn': false,
                                    'user': null,
                                    'token': null
                                },
                                error: i18n.__("ACCOUNT_ACTIVATION_ERROR")
                            });
                        } else {
                            bcrypt.compare(Data.password, rs.password)
                                .then((result) => {
                                    if (result == true) {
                                        var resUser = {
                                            "id": rs._id,
                                            "email": rs.email,
                                            "role": rs.role_id.role,
                                            "activation_key": rs.activation_key,
                                        };
                                        switch (resUser.role) {
                                            case req.config.role_type.INTERPRETER.name:
                                                InterpreterModel
                                                    .findOne({
                                                        user_id: resUser.id,
                                                        is_deleted: false,
                                                        status:true
                                                    })
                                                    .exec()
                                                    .then(function (interpreter) {
                                                        if (interpreter) {
                                                            resUser.is_deleted = interpreter.is_deleted;
                                                            resUser.interpreter_id = interpreter._id;
                                                            resUser.agency_id = interpreter.agency_id;
                                                            resUser.profile_pic = (interpreter.profile_pic) ?
                                                            interpreter.profile_pic :
                                                            req.config.upload_dir.DEFAULT_MALE_PIC ;
                                                            render();    
                                                        } else {
                                                            res.status(200).json({
                                                                status: req.config.statusCode.invalid,
                                                                error: i18n.__("AUTH_ERROR")
                                                            });
                                                        }
                                                    }).catch(function (err) {
                                                        res.status(200).json({
                                                            status: req.config.statusCode.invalid,
                                                            error: i18n.__("AUTH_ERROR")
                                                        });
                                                    });;
                                                break;
                                                
                                                case req.config.role_type.AGENCY_ADMIN.name:
                                                case req.config.role_type.AGENCY_USER.name:

                                                if (resUser.role == req.config.role_type.AGENCY_ADMIN.name) {
                                                    Agency
                                                        .findOne({
                                                            user_id: resUser.id,
                                                            is_deleted: false,
                                                            status: true
                                                        })
                                                        .exec()
                                                        .then(function (agency) {
                                                            if (agency) {
                                                                //   co
                                                                // resUser.activation_key = agency.ac
                                                                resUser.agency_id = agency._id;
                                                                resUser.is_deleted = agency.is_deleted;
                                                                resUser.profile_pic = (agency.profile_pic) ?
                                                                agency.profile_pic :
                                                                req.config.upload_dir.DEFAULT_MALE_PIC ;
                                                                render();
                                                            } else {
                                                                res.status(200).json({
                                                                    status: req.config.statusCode.invalid,
                                                                    error: i18n.__("AUTH_ERROR")
                                                                });
                                                            }
                                                        }).catch(function (err) {
                                                            res.status(200).json({
                                                                status: req.config.statusCode.invalid,
                                                                error: i18n.__("AUTH_ERROR")
                                                            });
                                                        });

                                                } else if (resUser.role == req.config.role_type.AGENCY_USER.name) {
                                                    Agency.findOne({
                                                            id: rs.agency_id,
                                                            is_deleted: 0
                                                        }).exec()
                                                        .then(function (agency) {
                                                            agency = agency ? agency.toJSON() : null;
                                                            if (!agency) throw i18n.__("FORBIDDEN");
                                                            resUser.agency_id = agency.id;
                                                            resUser.is_deleted = agency.is_deleted;
                                                            resUser.profile_pic = (rs.profile_pic) ?
                                                                req.config.server_url + req.config.upload_dir.USER_PROFILE_PIC + rs.profile_pic :
                                                                req.config.server_url + req.config.upload_dir.DEFAULT_MALE_PIC
                                                            render();
                                                        }).catch(function (err) {
                                                            res.status(200).json({
                                                                status: req.config.statusCode.invalid,
                                                                error: i18n.__("AUTH_ERROR")
                                                            });
                                                        });
                                                }

                                                break;
                                                case req.config.role_type.CLIENT.name:
                                                ClientModel.findOne({
                                                    user_id: resUser.id,
                                                    is_deleted: false,
                                                    status:true
                                                }).exec()
                                                    .then(function (client) {
                                                        if (client) {
                                                            resUser.is_deleted = client.is_deleted;
                                                            resUser.client_id = client._id;
                                                            resUser.agency_id = client.agency_id;
                                                            resUser.profile_pic = (client.profile_pic) ?
                                                                client.profile_pic :
                                                                req.config.upload_dir.DEFAULT_MALE_PIC ;
                                                            render();
                                                        } else {
                                                            res.status(200).json({
                                                                status: req.config.statusCode.invalid,
                                                                error: i18n.__("AUTH_ERROR")
                                                            });

                                                        }
                                                    }).catch(function (err) {   
                                                        res.status(200).json({
                                                            status: req.config.statusCode.invalid,
                                                            error: i18n.__("AUTH_ERROR")
                                                        });
                                                    });
                                                break;
                                                case req.config.role_type.SUPER_ADMIN.name:
                                                AdminModel.findOne({
                                                    user_id: resUser.id,
                                                    is_deleted: false,
                                                    status:true
                                                }).exec()
                                                    .then(function (admin) {
                                                        if (admin) {
                                                            resUser.admin_id = admin._id;
                                                            resUser.is_deleted = admin.is_deleted;
                                                            resUser.profile_pic = (admin.profile_pic) ?
                                                                admin.profile_pic :
                                                                req.config.upload_dir.DEFAULT_MALE_PIC;
                                                            render();
                                                        } else {
                                                            res.status(200).json({
                                                                status: req.config.statusCode.invalid,
                                                                error: i18n.__("AUTH_ERROR")
                                                            });

                                                        }
                                                    }).catch(function (err) {
                                                        res.status(200).json({
                                                            status: req.config.statusCode.invalid,
                                                            error: i18n.__("AUTH_ERROR")
                                                        });
                                                    });
                                            default:
                                                resUser.profile_pic = req.config.server_url + req.config.upload_dir.DEFAULT_MALE_PIC
                                                render();
                                        }

                                        function render() {
                                            var tokenData = resUser;
                                            tokenData.id = rs._id;
                                            if (tokenData.is_deleted == true) {
                                                return res.status(200).json({
                                                    status: req.config.statusCode.invalid,
                                                    data: {
                                                        'isLoggedIn': false,
                                                    },
                                                    error: i18n.__("IS_DELETED_ERROR")
                                                });
                                            } else {
                                                if (tokenData.activation_key) {
                                                    return res.status(200).json({
                                                        status: req.config.statusCode.invalid,
                                                        data: {
                                                            'isLoggedIn': false,
                                                        },
                                                        error: i18n.__("ACCOUNT_ACTIVATION_ERROR")
                                                    });
                                                } else {
                                                    var token = jwt.sign(tokenData, req.config.secretKey, {
                                                        expiresIn: req.config.tokenExpiryTime
                                                    });

                                                    res.status(200).json({

                                                        status: req.config.statusCode.success,
                                                        data: {
                                                            'isLoggedIn': true,
                                                            'user': resUser,
                                                            'token': token,
                                                            'acl': req.modulesArray
                                                        },
                                                        message: i18n.__("LOGGED_IN_SUCCESS"),
                                                        code: 200
                                                    });
                                                }
                                            }
                                        }
                                    } else {
                                        res.status(200).json({
                                            status: req.config.statusCode.invalid,
                                            data: {
                                                'isLoggedIn': false,
                                                'user': null,
                                                'token': null
                                            },
                                            error: i18n.__("AUTH_PW")
                                        });
                                    }
                                }).catch(function (err) {
                                    __debug(err);
                                    res.status(200).json({
                                        status: req.config.statusCode.invalid,
                                        error: err
                                    });
                                });
                        }

                    }).catch(function (err) {
                        __debug(err);
                        res.status(200).json({
                            status: req.config.statusCode.invalid,
                            error: i18n.__("AUTH_ERROR")
                        });
                    });
            }
        });

    },
    
    loginByOffice: function (req, res, next) {
        req.body = santize.escape(req.body);
        var Data = {
            "email": req.body.email,
            "password": req.body.password,
            "agency_id": req.body.agency_id
        };
        var schema = Joi.object().keys({
            "email": Joi.string().required(),
            "password": Joi.string().required(),
            "agency_id": Joi.string().required()
        });
        Joi.validate(Data, schema, function (err, value) {
            if (err) {
                res.status(200).send({
                    status: req.config.statusCode.invalid,
                    error: err
                });
            } else {
                new User()
                    .where('email', Data.email.toLowerCase())
                    .query(function (qb) {
                        qb.orderBy("id", 'desc');
                    })
                    .fetch({
                        columns: ['id', 'email', 'password', 'first_name', 'last_name', 'profile_pic', 'agency_id', 'created', 'role_id', 'activation_key', 'is_deleted'],
                        withRelated: [{
                            role: function (qb) {
                                qb.column('id', 'role', 'role_description', 'permissions');
                            }
                        }]
                    })
                    .then(function (result) {
                        var rs = result ? result.toJSON() : null;
                        if (rs.activation_key && !rs.password) {
                            res.status(200).json({
                                status: req.config.statusCode.invalid,
                                data: {
                                    'isLoggedIn': false,
                                    'user': null,
                                    'token': null
                                },
                                error: i18n.__("ACCOUNT_ACTIVATION_ERROR")
                            });
                        } else {
                            var rs = result.toJSON();

                            bcrypt.compare(Data.password, rs.password)
                                .then(function (result) {


                                    if (result == true) {
                                        var resUser = {
                                            "id": rs.id,
                                            "email": rs.email,
                                            "first_name": rs.first_name,
                                            "last_name": rs.last_name,
                                            "role": rs.role,
                                            "created": rs.created,
                                            "activation_key": rs.activation_key

                                        };

                                        switch (resUser.role.role) {
                                            case req.config.role_type.INTERPRETER.name:

                                                Interpreter
                                                    .findOne({
                                                        user_id: resUser.id,
                                                        agency_id: Data.agency_id
                                                    })
                                                    .exec()
                                                    .then(function (interpreter) {
                                                        if (interpreter) {

                                                            resUser.is_deleted = interpreter.is_deleted;
                                                            resUser.interpreter_id = interpreter.id;
                                                            resUser.agency_id = interpreter.agency_id;
                                                            resUser.profile_pic = (interpreter.profile_pic) ?
                                                                req.config.server_url + req.config.upload_dir.USER_PROFILE_PIC + interpreter.profile_pic :
                                                                req.config.server_url + req.config.upload_dir.DEFAULT_MALE_PIC

                                                            render();

                                                        } else {
                                                            res.status(200).json({
                                                                status: req.config.statusCode.invalid,
                                                                error: i18n.__("AUTH_ERROR")
                                                            });
                                                        }
                                                    }).catch(function (err) {
                                                        res.status(200).json({
                                                            data: {},
                                                            status: req.config.statusCode.invalid,
                                                            error: i18n.__("AUTH_ERROR")
                                                        });
                                                    });;
                                                break;
                                        }

                                        function render() {
                                            var tokenData = resUser;
                                            tokenData.id = rs.id;
                                            if (tokenData.is_deleted == 1) {
                                                return res.status(200).json({
                                                    status: req.config.statusCode.invalid,
                                                    data: {
                                                        'isLoggedIn': false,
                                                    },
                                                    error: i18n.__("IS_DELETED_ERROR")
                                                });
                                            } else {
                                                if (tokenData.activation_key != null) {
                                                    return res.status(200).json({
                                                        status: req.config.statusCode.invalid,
                                                        data: {
                                                            'isLoggedIn': false,
                                                        },
                                                        error: i18n.__("ACCOUNT_ACTIVATION_ERROR")
                                                    });
                                                } else {
                                                    var token = jwt.sign(tokenData, req.config.secretKey, {
                                                        expiresIn: req.config.tokenExpiryTime
                                                    });
                                                    res.status(200).json({
                                                        status: req.config.statusCode.success,
                                                        data: {
                                                            'isLoggedIn': true,
                                                            'user': resUser,
                                                            'token': token,
                                                            'acl': req.modulesArray
                                                        },
                                                        message: i18n.__("LOGGED_IN_SUCCESS")
                                                    });
                                                }
                                            }
                                        }
                                    } else {
                                        res.status(200).json({
                                            status: req.config.statusCode.invalid,
                                            data: {
                                                'isLoggedIn': false,
                                                'user': null,
                                                'token': null
                                            },
                                            error: i18n.__("AUTH_PW")
                                        });
                                    }
                                }).catch(function (err) {
                                    __debug(err);
                                    res.status(200).json({
                                        status: req.config.statusCode.invalid,
                                        error: err
                                    });
                                });
                        }

                    }).catch(function (err) {
                        __debug(err);
                        res.status(200).json({
                            status: req.config.statusCode.invalid,
                            error: i18n.__("AUTH_ERROR")
                        });
                    });
            }
        });
    },
    registration: function (req, res, next) {
        var Data = {
            "f_name": req.body.f_name,
            "l_name": req.body.l_name,
            "user_name": req.body.user_name,
            "password": req.body.password,
            "email": req.body.email
        };
        var schema = Joi.object().keys({
            "f_name": Joi.string().required(),
            "l_name": Joi.string().required(),
            "user_name": Joi.string().required(),
            "password": Joi.string().required(),
            "email": Joi.string().email().required()
        });
        Joi.validate(Data, schema, function (err, value) {
            if (err) {
                res.status(200).send({
                    status: req.config.statusCode.invalid,
                    error: err
                });
            } else {
                new User(Data).save().then(function (result) {
                    return res.status(200).json({
                        data: result.toJSON(),
                        message: "You have registered successfully",
                    });
                }).catch(function (err) {

                    return res.status(200).json({
                        error: err,
                        message: "Registration process failed! Please try again later"
                    });
                });
            }
        });
    },

    forgot_pw: function (req, res, next) {
        var Data = santize.escape(req.body);
        var schema = Joi.object().keys({
            "email": Joi.string().email().required(),
        });
        var user = {},
        forgot_pw_key = null;
        Joi.validate(req.body, schema, function (err, value) {

            if (err) return res.status(200).send({
                status: req.config.statusCode.invalid,
                error: err
            });

            var uuidV4 = require('uuid/v4');
            forgot_pw_key = uuidV4();
            new User()
                .where('email', Data.email)
                .fetch({
                    columns: ['id', 'email', 'first_name', 'last_name', 'role_id'],
                    withRelated: [{
                        role: function (qb) {
                            qb.column('id', 'role');
                        }
                    }]
                })
                .then(function (result) {
                    if (!result) throw i18n.__('INVALID_EMAIL', req.body.email);
                    user = result.toJSON();

                    return new User()
                        .off('updating') //This will remove updating event listeners
                        .where({
                            id: user.id,
                            email: user.email
                        })
                        .save({
                            forgot_pw_key: forgot_pw_key,
                            key_expiration: moment.utc().add(3, 'days').format(req.config.MOMENT_DATE_TIME_FORMAT)
                        }, {
                            patch: true
                        });

                }).then(function (result) {
                    if (!result) throw new Error(i18n.__('INTERNAL_ERROR'))
                    return _.assign(result.toJSON(), user);

                }).then(function (user) {

                    if (user.role.role == req.config.role_type.INTERPRETER.name) {

                        return new Interpreter()
                            .where({
                                user_id: user.id
                            }) //, is_deleted: 0
                            .fetch()
                            .then(function (interpreter) {
                                if (!interpreter) throw i18n.__("ERROR");
                                return interpreter

                            }).then(function (interpreter) {
                                var agency_id = interpreter.agency_id;
                                return new EmailTemplate()
                                    .query(function (qb) {
                                        qb.whereRaw("user_id  = (select user_id from agency_profiles where id = ? limit 1) and template_name = ? ", [agency_id, req.config.email_templates.FORGOT_EMAIL_SENT.id])
                                            .then(function (email_template) {

                                                return email_template;

                                            });
                                    })
                                    .fetch()
                            });
                    } else if (user.role.role == req.config.role_type.CLIENT.name) {

                        return new Client()
                            .where({
                                user_id: user.id
                            }) //, is_deleted: 0
                            .fetch()
                            .then(function (client) {
                                if (!client) throw i18n.__("ERROR");
                                return client = client.toJSON();

                            }).then(function (client) {
                                var agency_id = client.agency_id;
                                return new EmailTemplate()
                                    .query(function (qb) {
                                        qb.whereRaw("user_id  = (select user_id from agency_profiles where id = ? limit 1) and template_name = ? ", [agency_id, req.config.email_templates.FORGOT_EMAIL_SENT.id])
                                            .then(function (email_template) {

                                                return email_template;
                                            });
                                    })
                                    .fetch()
                            });
                    } else if (user.role.role == req.config.role_type.AGENCY_ADMIN.name) {

                        return new Agency()
                            .where({
                                user_id: user.id
                            })
                            .fetch()
                            .then(function (agency) {
                                if (!agency) throw i18n.__("ERROR");
                                return agency = agency.toJSON();
                            }).then(function (agency) {
                                var agency_id = agency.user_id;
                                return new EmailTemplate()
                                    .where({
                                        user_id: agency_id
                                    })
                                    .fetch()
                                    .then(function (email_template) {
                                        return email_template;
                                    })
                            })
                    }

                }).then(function (email_template) {
                    if (email_template) {
                        return email_template;
                    } else {
                        return new EmailTemplate()
                            .where({
                                user_id: req.config.role_type.SUPER_ADMIN.id,
                                template_name: req.config.email_templates.FORGOT_EMAIL_SENT.template_name
                            })
                            .fetch();
                    }


                }).then(function (email_template) {
                    if (email_template) email_template = email_template.toJSON();
                    else throw i18n.__("ERROR");
                    var email = __rootRequire('app/core/email');
                    var baseUrl = req.config.email.base_url;
                    var options = {
                        from: email_template.from,
                        body: email_template.email_body,
                        repalcement: {
                            "{{user.name}}": user.first_name,
                            "{{user.email}}": user.email,
                            "{{user.forgot_pw_key}}": baseUrl + '/reset_pw/' + forgot_pw_key,
                            "{{logo_url}}": baseUrl + req.config.email.logo_url,
                            "{{copyright}}": req.config.email.copyright,
                            "{{link.abuse_email}}": req.config.email.abuse_email
                        },
                        to: user.email,
                        subject: email_template.subject
                    };
                    email.smtp.sendMail(options, function (error, response) {
                        if (error) __debug(error);
                    });
                    return user;
                }).then(function (user) {

                    res.status(200).json({
                        status: req.config.statusCode.success,
                        message: i18n.__("FORGOT_EMAIL_SENT", user.email)
                    });
                }).catch(function (err) {
                    __debug(err);
                    res.status(200).send({
                        status: req.config.statusCode.invalid,
                        error: err
                    });
                }); //end Model


        }); //end Joi Validation



    },
    reset_pw: function (req, res, next) {
        req.body = santize.escape(req.body);
        var forgot_pw_key = santize.escape(req.query.resetKey);
        var email = __rootRequire('app/core/email');
        bcrypt.genSalt(10, function (err, salt) {
            bcrypt.hash(req.body.cpassword, salt, function (err, hash) {

                if (!err) {
                    new User()
                        .where({
                            forgot_pw_key: forgot_pw_key
                        })
                        .fetch()
                        .then(function (result) {
                            if (!result) throw i18n.__('LINK_EXPIRED')
                            return result;
                        }).then(function (result) {
                            var user = result.toJSON();
                            new User()
                                .off('updating') //This will remove updating event listeners
                                .where({
                                    forgot_pw_key: forgot_pw_key
                                })
                                .save({
                                    password: hash,
                                    forgot_pw_key: ''
                                }, {
                                    patch: true
                                })
                                .then(function (result) {
                                    var baseUrl = req.config.email.base_url;
                                    var options = {
                                        template: 'reset_password_confirmation.html',
                                        repalcement: {
                                            "{{user.name}}": user.first_name,
                                            "{{user.email}}": user.email,
                                            "{{logo_url}}": baseUrl + req.config.email.logo_url,
                                            "{{copyright}}": req.config.email.copyright,
                                            "{{link.abuse_email}}": req.config.email.abuse_email
                                        },
                                        to: user.email,
                                        subject: i18n.__("EMAIL_SUBJECT_RESET_PASSWORD_CONFIRMATION", "FHS SeniorCare")
                                    };
                                    email.smtp.sendMail(options, function (error, response) {
                                        if (error) __debug(error);
                                    });
                                    res.json({
                                        status: req.config.statusCode.success,
                                        forgot_pw_key: forgot_pw_key,
                                        message: i18n.__("EMAIL_SUBJECT_RESET_PASSWORD_CONFIRMATION", "FHS SeniorCare")
                                    });
                                })
                        })
                        .catch(function (err) {
                            res.status(200).send({
                                status: req.config.statusCode.invalid,
                                error: err
                            });

                        });
                }
            });
        });
    },
    activate_account: function (req, res, next) {

        req.body = santize.escape(req.body);
        var activation_key = santize.escape(req.query.activationKey);

        bcrypt.genSalt(10, function (err, salt) {
            bcrypt.hash(req.body.cpassword, salt, function (err, hash) {

                if (!err) {
                    new User()
                        .off('updating') //This will remove updating event listeners
                        .where({
                            activation_key: activation_key
                        })
                        .save({
                            password: hash,
                            activation_key: null
                        }, {
                            patch: true
                        })
                        .then(function (result) {
                            if (!result) throw i18n.__('LINK_EXPIRED')
                            res.json({
                                status: req.config.statusCode.success,
                                data: {
                                    activation_key: activation_key
                                },
                                message: i18n.__("ACCOUNT_ACTIVATED")
                            });
                        })
                        .catch(function (err) {
                            res.status(200).send({
                                status: req.config.statusCode.invalid,
                                error: err
                            });

                        });
                }
            });
        });



    },
    validate_link: function (req, res, next) {

        req.query = santize.escape(req.query);

        var activation_key = req.query.activationKey;
        new User()
            .query(function (qb) {
                qb.whereRaw(
                    'activation_key = ? and key_expiration > now() ', [activation_key]
                )
            })
            .fetch({
                columns: ['email', 'activation_key', 'key_expiration'],
            })
            .then(function (result) {

                if (!result)
                    return res.status(200).send({
                        status: req.config.statusCode.invalid,
                        error: i18n.__('LINK_EXPIRED')
                    });

                return res.json({
                    status: req.config.statusCode.success,
                    user: result.toJSON()
                });
            });
    },
    save_profile: function (req, res, next) {
        var base64Image = req.body.profile_pic;
        req.body = santize.striptags(req.body);
        delete req.body.email;
        file.local.writeBuffer("." + req.config.upload_dir.USER_PROFILE_PIC + '/' + req.user.id, base64Image)
            .then(function (result) {
                var path = result.data,
                    message = result.message;
                var conditions = {
                    user_id: req.user.id
                };
                switch (req.user.role.role) {
                    case req.config.role_type.AGENCY_ADMIN.name:
                        var modelObj = new Agency();
                        req.body.agency_address_1 = req.body.address_1;
                        req.body.agency_address_2 = req.body.address_2;
                        req.body.agency_city = req.body.city;
                        req.body.agency_state = req.body.state;
                        req.body.agency_phone = req.body.phone;
                        req.body.agency_postal_code = req.body.postal_code;
                        delete req.body.address_1;
                        delete req.body.address_2;
                        delete req.body.city;
                        delete req.body.state;
                        delete req.body.phone;
                        delete req.body.postal_code;
                        break;
                    case req.config.role_type.CLIENT.name:
                        var modelObj = new Client();
                        break;
                    case req.config.role_type.INTERPRETER.name:
                        var modelObj = new Interpreter();
                        break;
                    default:
                        var modelObj = new User();
                        conditions = {
                            id: req.user.id
                        };
                        break;
                }

                if (path)
                    req.body.profile_pic = req.user.id + '/' + path;
                modelObj
                    .where(conditions)
                    .off('updating')
                    .save(req.body, {
                        patch: true
                    })
                    .then(function (result) {
                        if (!result) throw i18n.__("ERROR");
                        return new User()
                            .where({
                                id: req.user.id
                            })
                            .off('updating')
                            .save({
                                first_name: req.body.first_name,
                                last_name: req.body.last_name
                            }, {
                                patch: true
                            });

                    }).then(function (user) {
                        if (!user) throw i18n.__("ERROR");
                        res.json({
                            status: req.config.statusCode.success,
                            message: i18n.__("SAVED"),
                            data: user.toJSON()
                        });
                    })
                    .catch(function (err) {
                        __debug(err)
                        res.json({
                            status: req.config.statusCode.error,
                            message: i18n.__('INTERNAL_ERROR')
                        });
                    });
            });


    },
    get_profile: function (req, res, next) {

        var conditions = {
            user_id: req.user.id
        };
        var modelObj = null;
        switch (req.user.role.role) {
            case req.config.role_type.AGENCY_ADMIN.name:
            case req.config.role_type.AGENCY_USER.name:
                modelObj = new Agency();
                _getProfile(modelObj);
                break;
            case req.config.role_type.CLIENT.name:
                modelObj = new Client();
                _getProfile(modelObj);
                break;
            case req.config.role_type.INTERPRETER.name:
                modelObj = new Interpreter();
                _getProfile(modelObj);
                break;
            default:
                conditions = {
                    id: req.user.id
                };
                _getUserProfile(modelObj)

                break;
        }


        function _getProfile(modelObj) {
            modelObj
                .where(conditions)
                .fetch({
                    withRelated: [{
                            user: function (qb) {
                                qb.column('id', 'email', 'first_name', 'last_name', 'profile_pic', 'city', 'state', 'address_1', 'country_code', 'phone', 'gender')
                            }
                        }

                    ]

                })
                .then(function (result) {

                    if (!result) throw i18n.__("FORBIDDEN");
                    result = result.toJSON();
                    result.profile_pic = result.profile_pic ? req.config.server_url + req.config.upload_dir.USER_PROFILE_PIC + '/' + result.profile_pic :
                        req.config.server_url + req.config.upload_dir.USER_PROFILE_PIC + '/male_avatar.png'


                    return res.json({
                        status: req.config.statusCode.success,
                        data: result
                    });
                }).catch(function (err) {
                    __debug(err)
                    if (!res.headersSent)
                        res.json({
                            status: req.config.statusCode.error,
                            message: i18n.__('INTERNAL_ERROR')
                        });
                });
        }

        function _getUserProfile() {
            new User()
                .where(conditions)
                .fetch()
                .then(function (result) {
                    if (!result) throw i18n.__("FORBIDDEN");
                    result = result.toJSON();
                    result.profile_pic = result.profile_pic ? req.config.server_url + req.config.upload_dir.USER_PROFILE_PIC + '/' + result.profile_pic :
                        req.config.server_url + req.config.upload_dir.USER_PROFILE_PIC + '/male_avatar.png'


                    return res.json({
                        status: req.config.statusCode.success,
                        data: result
                    });
                }).catch(function (err) {
                    __debug(err)
                    if (!res.headersSent)
                        res.json({
                            status: req.config.statusCode.error,
                            message: i18n.__('INTERNAL_ERROR')
                        });
                });
        }


    },
    check_email_address: function (req, res, next) {
        req.query = santize.escape(req.query);
        new User().where({
                email: req.query['email'],
                is_deleted: 0
            })
            .count("*")
            .then(function (cnt) {
                cnt = parseInt(cnt);
                res.json({
                    status: req.config.statusCode.success,
                    count: cnt
                });
            }).catch(function (err) {
                __debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    message: i18n.__('INTERNAL_ERROR')
                });
            });
    },
    check_profile_email_address: function (req, res, next) {
        req.query = santize.escape(req.query);
        new User()
            .query(function (qb) {
                qb.whereRaw("email =  ?  and id <> ?  and is_deleted = 0", [req.query['email'], req.user.id])
            })
            .count("*")
            .then(function (cnt) {
                cnt = parseInt(cnt);
                res.json({
                    status: req.config.statusCode.success,
                    count: cnt
                });
            }).catch(function (err) {
                __debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    message: i18n.__('INTERNAL_ERROR')
                });
            });
    },
    check_sub_domain: function (req, res, next) {
        req.query = santize.escape(req.query);
        new Agency().where({
                agency_sub_domain: req.query['agency_sub_domain'],
                is_deleted: 0
            })
            .count("*")
            .then(function (cnt) {
                cnt = parseInt(cnt);
                res.json({
                    status: req.config.statusCode.success,
                    count: cnt,
                    message: i18n.__('INTERNAL_ERROR')
                });
            }).catch(function (err) {
                __debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    message: i18n.__('INTERNAL_ERROR')
                });
            });
    },
    check_agency_name: function (req, res, next) {
        req.query = santize.escape(req.query);
        new Agency().where({
                agency_name: req.query['agency_name'],
                is_deleted: 0
            })
            .count("*")
            .then(function (cnt) {
                cnt = parseInt(cnt);
                res.json({
                    status: req.config.statusCode.success,
                    count: cnt,
                });
            }).catch(function (err) {
                __debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    message: i18n.__('INTERNAL_ERROR')
                });
            });
    },
    change_password: function (req, res, next) {

        var forgot_pw_key = santize.escape(req.query.resetKey);
        var email = __rootRequire('app/core/email');
        req.body.id = req.body.id ? req.body.id : req.user.id;
        bcrypt.genSalt(10, function (err, salt) {
            bcrypt.hash(req.body.cpassword, salt, function (err, hash) {

                if (!err) {
                    new User()
                        .where({
                            id: req.body.id
                        })
                        .fetch()
                        .then(function (result) {
                            if (!result) throw i18n.__('FORBIDDEN')
                            return result;
                        }).then(function (result) {
                            var user = result.toJSON();
                            new User()
                                .off('updating') //This will remove updating event listeners
                                .where({
                                    id: req.body.id
                                })
                                .save({
                                    password: hash
                                }, {
                                    patch: true
                                })
                                .then(function (result) {
                                    var baseUrl = req.config.email.base_url;
                                    var options = {
                                        template: 'reset_password_confirmation.html',
                                        repalcement: {
                                            "{{user.name}}": user.first_name,
                                            "{{user.email}}": user.email,
                                            "{{logo_url}}": baseUrl + req.config.email.logo_url,
                                            "{{copyright}}": req.config.email.copyright,
                                            "{{link.abuse_email}}": req.config.email.abuse_email
                                        },
                                        to: user.email,
                                        subject: i18n.__("EMAIL_SUBJECT_RESET_PASSWORD_CONFIRMATION", " ")
                                    };
                                    email.smtp.sendMail(options, function (error, response) {
                                        if (error) __debug(error);
                                    });
                                    res.json({
                                        status: req.config.statusCode.success,
                                        forgot_pw_key: forgot_pw_key,
                                        message: i18n.__("EMAIL_SUBJECT_RESET_PASSWORD_CONFIRMATION", " ")
                                    });
                                })
                        })
                        .catch(function (err) {
                            __debug(err)
                            res.status(200).send({
                                status: req.config.statusCode.invalid,
                                error: err
                            });

                        });
                }
            });
        });
    },
    change_email: function (req, res, next) {
        var forgot_pw_key = santize.escape(req.query.resetKey);
        var email = __rootRequire('app/core/email');
        req.body.id = req.body.id ? req.body.id : req.user.id;
        new User()
            .query(function (qb) {
                qb.whereRaw(" email  = ? and id <> ? and is_deleted = 0 ", [req.body.email, req.body.id])
            })
            .fetch()
            .then(function (result) {
                if (result) throw i18n.__('EMAIL_ALREADY_EXISTS')
                else
                    return result;
            }).then(function (result) {
                new User()
                    .off('updating') //This will remove updating event listeners
                    .where({
                        id: req.body.id
                    })
                    .save({
                        email: req.body.email
                    }, {
                        patch: true
                    })
                    .then(function (result) {
                        res.json({
                            status: req.config.statusCode.success,
                            forgot_pw_key: forgot_pw_key,
                            message: i18n.__("EMAIL_CHANGED_SUCCESS", req.body.email)
                        });
                    })
            })
            .catch(function (err) {
                __debug(err)
                res.status(200).send({  
                    status: req.config.statusCode.invalid,
                    error: err
                });

            });



    },

     forgotPassword: function (req, res) {
        User.findOne({email: req.body.email, is_deleted: false, status: true, is_verified:true}).populate('role_id', 'role').exec(function (err, userData) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })
            } else if(userData){
                var uuidV4 = require('uuid/v4');
                userData.forgot_token = uuidV4();
                userData.forgot_request = Date.now();
                userData.save()
                .then((userDataSave) => {
                    if(userDataSave){
                            if (userData.role_id.role == req.config.role_type.SUPER_ADMIN.name) {
                                AdminModel.findOne({user_id:userData._id}, function(err, adminData){
                                    if(err){
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: req.body,
                                            message: i18n.__("ERROR")
                                        })
                                    } else{
                                        if(req.config.env == 'aws'){
                                            var baseUrl = 'https://www.interpreting.works';
                                        }else{
                                            var baseUrl = req.config.email.base_url;
                                        }
                                        var options = {
                                            template: 'forgot_password.html',
                                            from: 'abc@gmail.com',
                                            repalcement: {
                                                "{{user.name}}": adminData.first_name.charAt(0).toUpperCase()+adminData.first_name.slice(1).toLowerCase()+ ' ' +adminData.last_name.charAt(0).toUpperCase()+adminData.last_name.slice(1).toLowerCase(),
                                                "{{user.email}}": userDataSave.email,
                                                "{{user.forgot_token}}": baseUrl + '/admin/#/forgot_password/' + userDataSave.forgot_token,
                                                "{{logo_url}}": baseUrl + req.config.email.logo_url,
                                                "{{copyright}}": req.config.email.copyright,
                                                "{{link.abuse_email}}": req.config.email.abuse_email
                                            },
                                            to: userData.email,
                                            subject: 'Forgot Password'
                                        };
                                        emailSend.smtp.sendMail(options, function (err, response) {
                                            if (err) {
                                                res.json({
                                                    status: req.config.statusCode.error,
                                                    data: req.body,
                                                    message: i18n.__("ERROR")
                                                })
                                            }else{
                                                res.json({
                                                    status: req.config.statusCode.success,
                                                    data: response,
                                                    message: i18n.__("Please check your email to set a new password")
                                                });
                                            }
                                        })
                                    }
                                })
                                

                            } else if(userData.role_id.role == req.config.role_type.AGENCY_ADMIN.name){

                                Agency.findOne({user_id:userData._id}, function(err, agencyData){
                                    if(err){
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: req.body,
                                            message: i18n.__("ERROR")
                                        })
                                    } else{
                                        if(req.config.env == 'aws'){
                                            var baseUrl = 'https://www.interpreting.works';
                                        }else{
                                            var baseUrl = req.config.email.base_url;
                                        }
                                        var options = {
                                            template: 'forgot_password.html',
                                            from: 'abc@gmail.com',
                                            repalcement: {
                                                "{{user.name}}": agencyData.agency_name ? agencyData.agency_name.charAt(0).toUpperCase()+agencyData.agency_name.slice(1).toLowerCase() : agencyData.first_name.charAt(0).toUpperCase()+agencyData.first_name.slice(1).toLowerCase()+ ' ' + agencyData.last_name.charAt(0).toUpperCase()+agencyData.last_name.slice(1).toLowerCase(),
                                                "{{user.email}}": userData.email,
                                                "{{user.forgot_token}}": baseUrl + '/#/forgot_password/' + userDataSave.forgot_token,
                                                "{{logo_url}}": baseUrl + req.config.email.logo_url,
                                                "{{copyright}}": req.config.email.copyright,
                                                "{{link.abuse_email}}": req.config.email.abuse_email
                                            },
                                            to: userData.email,
                                            subject: 'Forgot Password'
                                        };
                                        emailSend.smtp.sendMail(options, function (err, response) {
                                            if (err) {
                                                res.json({
                                                    status: req.config.statusCode.error,
                                                    data: req.body,
                                                    message: i18n.__("ERROR")
                                                })
                                            }else{
                                                res.json({
                                                    status: req.config.statusCode.success,
                                                    data: response,
                                                    message: i18n.__("Please check your email to set a new password")
                                                });
                                            }
                                        })
                                    }
                                })
                                
                            } else if(userData.role_id.role == req.config.role_type.INTERPRETER.name){
                            InterpreterModel.findOne({user_id:userData._id}, function(err, interpreterData){
                                if (err) {
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: req.body,
                                        message: i18n.__("ERROR")
                                    })
                                }
                                else{
                                    if(req.config.env == 'aws'){
                                        var baseUrl = 'https://www.interpreting.works';
                                    }else{
                                        var baseUrl = req.config.email.base_url;
                                    }
                                    var options = {
                                        template: 'forgot_password.html',
                                        from: 'abc@gmail.com',
                                        repalcement: {
                                            "{{user.name}}": interpreterData.first_name.charAt(0).toUpperCase()+interpreterData.first_name.slice(1).toLowerCase()+ ' ' +interpreterData.last_name.charAt(0).toUpperCase()+interpreterData.last_name.slice(1).toLowerCase(),
                                            "{{user.email}}": userData.email,
                                            "{{user.forgot_token}}": baseUrl + '/#/forgot_password/' + userDataSave.forgot_token,
                                            "{{logo_url}}": baseUrl + req.config.email.logo_url,
                                            "{{copyright}}": req.config.email.copyright,
                                            "{{link.abuse_email}}": req.config.email.abuse_email
                                        },
                                        to: userData.email,
                                        subject: 'Forgot Password'
                                    };
                                    emailSend.smtp.sendMail(options, function (err, response) {
                                        if (err) {
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: req.body,
                                                message: i18n.__("ERROR")
                                            })
                                        }else{
                                            res.json({
                                                status: req.config.statusCode.success,
                                                data: response,
                                                message: i18n.__("Please check your email to set a new password")
                                            });
                                        }
                                    })
                                }
                            })

                        } else if(userData.role_id.role == req.config.role_type.CLIENT.name){
                            ClientModel.findOne({user_id:userData._id}, function(err, clientData){
                                if(err){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: req.body,
                                        message: i18n.__("ERROR")
                                    })
                                } else{
                                    if(req.config.env == 'aws'){
                                        var baseUrl = 'https://www.interpreting.works';
                                    }else{
                                        var baseUrl = req.config.email.base_url;
                                    }
                                    var options = {
                                        template: 'forgot_password.html',
                                        from: 'abc@gmail.com',
                                        repalcement: {
                                            "{{user.name}}": clientData.first_name.charAt(0).toUpperCase()+clientData.first_name.slice(1).toLowerCase()+ ' ' +clientData.last_name.charAt(0).toUpperCase()+clientData.last_name.slice(1).toLowerCase(),
                                            "{{user.email}}": userData.email,
                                            "{{user.forgot_token}}": baseUrl + '/#/forgot_password/' + userDataSave.forgot_token,
                                            "{{logo_url}}": baseUrl + req.config.email.logo_url,
                                            "{{copyright}}": req.config.email.copyright,
                                            "{{link.abuse_email}}": req.config.email.abuse_email
                                        },
                                        to: userData.email,
                                        subject: 'Forgot Password'
                                    };
                                    emailSend.smtp.sendMail(options, function (err, response) {
                                        if (err) {
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: req.body,
                                                message: i18n.__("ERROR")
                                            })
                                        }else{
                                            res.json({
                                                status: req.config.statusCode.success,
                                                data: response,
                                                message: i18n.__("Please check your email to set a new password")
                                            });
                                        }
                                    })
                                }
                            })
                            
                        }
                    } else{
                          res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })   
                    }
                    

                }).catch((err) => {
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR")
                    })

                });
                
            } else{
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("No record found to this email")
                })
            }
        });
    },



    enterPassword: function (req, res) {
        res.sendFile(path.join(__dirname, '../../../../../../../client/src/app/forgetPassword/component/forgetPassword.html'));
    },


    resetPassword: function (req, res, next) {
        User.findOneAndUpdate({
                email: req.body.email
            }, {
                password: req.body.password
            })
            .then((result) => {
                res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    message: i18n.__("PASSWORD_UPDATED_SUCCESSFULLY")
                });
            }).catch((err) => {
                //__debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });

    },

    getEmailUsingKey: function (req, res, next) {
        User.findOne({activation_key:req.params.id},{'email':1})
            .then((result) => {
                if(!result){
                    res.json({
                        status: req.config.statusCode.error,
                        data: result,
                        message: i18n.__("ERROR")
                    })
                }else if(result){
                    res.json({
                        status: req.config.statusCode.success,
                        data: result,
                        message: i18n.__("Get email successfully")
                    });
                }else{
                    res.json({
                        status: req.config.statusCode.notFound,
                        data: result,
                        message: i18n.__("No record found")
                    })    
                }
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });
    },

    completeUserRegistration: function (req, res, next){
        function sendEmailNotification(obj){
                if(req.config.env == 'aws'){
                    var baseUrl = 'https://www.interpreting.works';
                }else{
                    var baseUrl = req.config.email.base_url;
                }
                var options = {
                    template: 'completeUserRegistration.html',
                    from: 'rahul@yopmail.com',
                    repalcement: {
                        "{{user.name}}": obj.agency_name ? obj.agency_name.charAt(0).toUpperCase()+obj.agency_name.slice(1).toLowerCase() : obj.first_name.charAt(0).toUpperCase()+obj.first_name.slice(1).toLowerCase()+ ' ' + obj.last_name.charAt(0).toUpperCase()+obj.last_name.slice(1).toLowerCase(),
                        "{{user.email}}": obj.email,
                        "{{user.url}}": baseUrl + '/#/login/',
                        "{{user.email}}": obj.email,
                        "{{user.password}}": req.body.password,
                        "{{logo_url}}": baseUrl + req.config.email.logo_url,
                        "{{copyright}}": req.config.email.copyright,
                        "{{link.abuse_email}}": req.config.email.abuse_email
                    },
                    to: obj.email,
                    subject: 'Registration Completed Successfully'
                };
                emailSend.smtp.sendMail(options, function (err, response) {
                    if (err) {
                        //__debug(err)
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })
                    }else{
                        // var text ="You have successfully completed your registration.";
                        // var data = { to: '+919990795913', message: text }
                        // twilioSms.sendSMS(data, function(returnData) {
                        // });
                        res.json({
                            status: req.config.statusCode.success,
                            data: obj.result,
                            message: i18n.__("Your Registration completed successfully")
                        });
                    }
                })
        }

        bcrypt.genSalt(10, function (err, salt) {
            bcrypt.hash(req.body.password, salt, function (err, hash) {
                if (!err) {

                    User.findOne({activation_key:req.body.activation_key}).exec(function(err,userData){
                        if(err){
                            res.json({
                                status: req.config.statusCode.error,
                                data: req.body,
                                message: i18n.__("ERROR")
                            })
                        }else if(userData){
                            userData.password = hash;
                            userData.activation_key = '';
                            userData.is_verified = true;
                            userData.status = true;
                            userData.save(function(err, result){
                                if(err){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: req.body,
                                        message: i18n.__("ERROR")
                                    })
                                }else{
                                    RoleModel.findOne({_id:result.role_id}).exec(function(err,roleData){
                                        if(err){
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: req.body,
                                                message: i18n.__("ERROR")
                                            })
                                        }else if(roleData){
                                            if(roleData.role == req.config.role_type.AGENCY_ADMIN.name){
                                                Agency.findOne({user_id:result._id}).exec(function(err,agencyData){
                                                    if(err){
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: req.body,
                                                            message: i18n.__("ERROR")
                                                        })
                                                    }else if(agencyData){
                                                        agencyData.status = true;
                                                        agencyData.save(function(err,savedData){
                                                            if(err){
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: req.body,
                                                                    message: i18n.__("ERROR")
                                                                })
                                                            }else{
                                                                var obj = {
                                                                    agency_name:agencyData.agency_name,
                                                                    email: result.email,
                                                                    result:result
                                                                }
                                                                sendEmailNotification(obj);
                                                            }
                                                        })
                                                    }else{
                                                        res.json({
                                                            status: req.config.statusCode.success,
                                                            data: {},
                                                            message: i18n.__("No record found")
                                                        });
                                                    }
                                                })  
                                            }else if(roleData.role == req.config.role_type.INTERPRETER.name){
                                                InterpreterModel.findOne({user_id:result._id}).exec(function(err,interpreterData){
                                                    if(err){
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: req.body,
                                                            message: i18n.__("ERROR")
                                                        })
                                                    }else if(interpreterData){
                                                        interpreterData.status = true;
                                                        interpreterData.save(function(err,savedData){
                                                            if(err){
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: req.body,
                                                                    message: i18n.__("ERROR")
                                                                })
                                                            }else{
                                                                var obj = {
                                                                    first_name:interpreterData.first_name,
                                                                    last_name:interpreterData.last_name,
                                                                    email: result.email,
                                                                    result:result
                                                                }
                                                                sendEmailNotification(obj);
                                                            }
                                                        })
                                                    }else{
                                                        res.json({
                                                            status: req.config.statusCode.success,
                                                            data: {},
                                                            message: i18n.__("No record found")
                                                        });
                                                    }
                                                })    
                                            }else if(roleData.role == req.config.role_type.CLIENT.name){
                                                ClientModel.findOne({user_id:result._id}).exec(function(err,clientData){
                                                    if(err){
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: req.body,
                                                            message: i18n.__("ERROR")
                                                        })
                                                    }else if(clientData){
                                                        clientData.status = true;
                                                        clientData.save(function(err,savedData){
                                                            if(err){
                                                                res.json({
                                                                    status: req.config.statusCode.error,
                                                                    data: req.body,
                                                                    message: i18n.__("ERROR")
                                                                })
                                                            }else{
                                                                var obj = {
                                                                    first_name:clientData.first_name,
                                                                    last_name:clientData.last_name,
                                                                    email: result.email,
                                                                    result:result
                                                                }
                                                                sendEmailNotification(obj);        
                                                            }
                                                        })
                                                    }else{
                                                        res.json({
                                                            status: req.config.statusCode.success,
                                                            data: {},
                                                            message: i18n.__("No record found")
                                                        });
                                                    }
                                                }) 
                                            }
                                        }else{
                                            res.json({
                                                status: req.config.statusCode.success,
                                                data: {},
                                                message: i18n.__("No record found")
                                            });
                                        }
                                    })
                                    
                                }
                            })

                        }else{
                            res.json({
                                status: req.config.statusCode.error,
                                data: userData,
                                message: i18n.__("ERROR")
                            })
                        }
                    }).catch(function (err) {
                            res.json({
                                status: req.config.statusCode.error,
                                data: req.body,
                                message: i18n.__("ERROR")
                            })
                    })
                }
            })
        })
    },

    setNewPassword: function (req, res, next){
        bcrypt.genSalt(10, function (err, salt) {
            bcrypt.hash(req.body.password, salt, function (err, hash) {
                if (!err) {

                    User.findOne({forgot_token:req.body.forgot_token}).exec(function(err,userData){
                        if(err){
                            res.json({
                                status: req.config.statusCode.error,
                                data: req.body,
                                message: i18n.__("ERROR")
                            })
                        } else{
                            userData.password = hash;
                            userData.forgot_token = '';
                            userData.is_verified = true;
                            userData.status = true;
                            userData.save(function(err, result){
                                if(err){
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: req.body,
                                        message: i18n.__("ERROR")
                                    })
                                }else{
                                    res.json({
                                        status: req.config.statusCode.success,
                                        data: result,
                                        message: i18n.__("Your password change successfully")
                                    })
                                }
                            })
                        }
                    }).catch(function (err) {
                            res.json({
                                status: req.config.statusCode.error,
                                data: req.body,
                                message: i18n.__("ERROR")
                            })
                    })
                }
            })
        })
    },

    getEmailUsingPassword: function (req, res, next) {
        User.findOne({forgot_token:req.params.id},{'email':1})
            .then((result) => {
                if(!result){
                    res.json({
                        status: req.config.statusCode.error,
                        data: result,
                        message: i18n.__("ERROR")
                    })
                }else if(result){
                    res.json({
                        status: req.config.statusCode.success,
                        data: result,
                        message: i18n.__("Get email successfully")
                    });
                }else{
                    res.json({
                        status: req.config.statusCode.error,
                        data: result,
                        message: i18n.__("No record found")
                    })    
                }
            }).catch((err) => {
                //__debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });
    }, 

    changePassword: function (req, res, next) {
        User.findOne({_id: req.user.id, is_deleted:false, is_verified:true})
        .populate('role_id', 'role')
        .then((userData)=>{
            bcrypt.compare(req.body.oldPassword, userData.password)
                .then((result)=>{
                    if(result == true){
                        bcrypt.genSalt(10, function (err, salt){
                            bcrypt.hash(req.body.newPassword, salt, function (err, hash){
                                switch(userData.role_id.role){
                                    case req.config.role_type.AGENCY_ADMIN.name:
                                    case req.config.role_type.AGENCY_USER.name:
                                    userData.password = hash;
                                    userData.change_request = Date.now();
                                    userData.save(function(err, data){
                                        if(err){
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: req.body,
                                                message: i18n.__("ERROR")
                                            })
                                        } else{
                                            res.json({
                                                status: req.config.statusCode.success,
                                                data: data,
                                                message: i18n.__("Password changed successfully")
                                            });
                                        }
                                    })
                                    break;
                                    case req.config.role_type.CLIENT.name:
                                    userData.password = hash;
                                    userData.change_request = Date.now();
                                    userData.save(function(err, data){
                                        if(err){
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: req.body,
                                                message: i18n.__("ERROR")
                                            })
                                        } else{
                                            res.json({
                                                status: req.config.statusCode.success,
                                                data: data,
                                                message: i18n.__("Password changed successfully")
                                            });
                                        }
                                    })
                                    break;
                                    case req.config.role_type.INTERPRETER.name:
                                    userData.password = hash;
                                    userData.change_request = Date.now();
                                    userData.save(function(err, data){
                                        if(err){
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: req.body,
                                                message: i18n.__("ERROR")
                                            })
                                        } else{
                                            res.json({
                                                status: req.config.statusCode.success,
                                                data: data,
                                                message: i18n.__("Password changed successfully")
                                            });
                                        }
                                    })
                                    break;
                                    case req.config.role_type.SUPER_ADMIN.name:
                                    userData.password = hash;
                                    userData.change_request = Date.now();
                                    userData.save(function(err, data){
                                        if(err){
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: req.body,
                                                message: i18n.__("ERROR")
                                            })
                                        } else{
                                            res.json({
                                                status: req.config.statusCode.success,
                                                data: data,
                                                message: i18n.__("Password changed successfully")
                                            });
                                        }
                                    })
                                    break;
                                }
                            })
                        })
                        
                    } else{
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("Please enter correct old password")
                        })
                    }
                }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });
            
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })

        });
        
    },

    // getBookingDetails: function (req, res, next) {
    //     BookingRequestModel.findOne({request_token:req.params.id, accept: false})
    //         .exec(function(err,requestData){
    //             if(err){
    //                 res.json({
    //                     status: req.config.statusCode.error,
    //                     data: {},
    //                     message: i18n.__("ERROR")
    //                 })
    //             }else if(requestData){
    //                 BookingRequestModel.find({booking_id: requestData.booking_id,accept:true}).count().exec(function(err,requestCount){
    //                     if(err){
    //                         res.json({
    //                             status: req.config.statusCode.error,
    //                             data: {},
    //                             message: i18n.__("ERROR")
    //                         })      
    //                     }else {
    //                         if(requestCount>0){
    //                            res.json({
    //                                 status: req.config.statusCode.error,
    //                                 data: {},
    //                                 message: i18n.__("BOOKING_ASSIGNED_TO_ANOTHER_INTERPRETER")
    //                             })   
    //                         }else{
    //                             Booking.findOne({_id: requestData.booking_id},{'service_title': 1, 'booking_from': 1, 'booking_to': 1, 'working_from': 1, 'working_to': 1, 'address': 1 })
    //                                 .then((bookingData)=>{
    //                                     if(!bookingData){
    //                                         res.json({
    //                                             status: req.config.statusCode.error,
    //                                             data: {},
    //                                             message: i18n.__("ERROR")
    //                                         })
    //                                     }else{
    //                                         InterpreterModel.findOne({_id: requestData.interpreter_id, status: 1},{'first_name': 1, 'last_name': 1})
    //                                             .then((interpreterData)=>{
    //                                                 if(!interpreterData){
    //                                                     res.json({
    //                                                         status: req.config.statusCode.error,
    //                                                         data: {},
    //                                                         message: i18n.__("ERROR")
    //                                                     })
    //                                                 }else{
    //                                                     var result = {
    //                                                         booking_request_id: requestData._id,
    //                                                         booking_id: bookingData._id,
    //                                                         service_title: bookingData.service_title,
    //                                                         booking_date: moment(bookingData.booking_from).format("DD-MM-YYYY")+' to '+moment(bookingData.booking_to).format("DD-MM-YYYY"), 
    //                                                         booking_time: bookingData.working_from+' - '+bookingData.working_to,
    //                                                         address: bookingData.address,
    //                                                         interpreter_full_name: interpreterData.first_name.charAt(0).toUpperCase()+interpreterData.first_name.slice(1).toLowerCase()+ ' '+interpreterData.last_name.charAt(0).toUpperCase()+interpreterData.last_name.slice(1).toLowerCase()
    //                                                     }
    //                                                     res.json({
    //                                                         status: req.config.statusCode.success,
    //                                                         data: result,
    //                                                         message: i18n.__("Get request details successfully")
    //                                                     });                        
    //                                                 }
    //                                         })                                       
    //                                     }
    //                             })
    //                         }
    //                     }
    //                 })
    //             }else{
    //                 BookingRequestModel.findOne({request_token:req.params.id, accept: true}).exec(function(err,record){
    //                     if(err){
    //                         res.json({
    //                             status: req.config.statusCode.error,
    //                             data: req.body,
    //                             message: i18n.__("ERROR")
    //                         })
    //                     }else if(record){
    //                         res.json({
    //                             status: req.config.statusCode.unauthorized,
    //                             data: req.body,
    //                             message: i18n.__("ALREADY_ASSIGNED_BOOKING")
    //                         })            
    //                     }else{
    //                         res.json({
    //                             status: req.config.statusCode.invalid,
    //                             data: req.body,
    //                             message: i18n.__("INVALID_URL")
    //                         })       
    //                     }
    //                 })  
    //             }
    //     }).catch((err) => {
    //         res.json({
    //             status: req.config.statusCode.error,
    //             data: req.body,
    //             message: i18n.__("ERROR")
    //         })
    //     });
    // },

    getBookingDetails: function (req, res, next) {
        BookingRequestModel.findOne({request_token:req.params.id, accept: false})
            .exec(function(err,requestData){
                if(err){
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                }else if(requestData){
                    BookingRequestModel.find({booking_id: requestData.booking_id,accept:true}).count().exec(function(err,requestCount){
                        if(err){
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })      
                        }else {
                            if(requestCount>0){
                               res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("BOOKING_ASSIGNED_TO_ANOTHER_INTERPRETER")
                                })   
                            }else{
                                SchedulerModel.findOne({_id: requestData.booking_id},{'service_title': 1, 'start_date': 1, 'end_date': 1, 'start_time': 1, 'end_time': 1, 'address': 1 })
                                    .then((bookingData)=>{
                                        if(!bookingData){
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: {},
                                                message: i18n.__("ERROR")
                                            })
                                        }else{
                                            InterpreterModel.findOne({_id: requestData.interpreter_id, status: 1},{'first_name': 1, 'last_name': 1})
                                                .then((interpreterData)=>{
                                                    if(!interpreterData){
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: {},
                                                            message: i18n.__("ERROR")
                                                        })
                                                    }else{
                                                        var result = {
                                                            booking_request_id: requestData._id,
                                                            booking_id: bookingData._id,
                                                            service_title: bookingData.service_title,
                                                            booking_date: moment(bookingData.start_date).format("DD-MM-YYYY")+' to '+moment(bookingData.end_date).format("DD-MM-YYYY"), 
                                                            booking_time: bookingData.start_time+' - '+bookingData.end_time,
                                                            address: bookingData.address,
                                                            interpreter_full_name: interpreterData.first_name.charAt(0).toUpperCase()+interpreterData.first_name.slice(1).toLowerCase()+ ' '+interpreterData.last_name.charAt(0).toUpperCase()+interpreterData.last_name.slice(1).toLowerCase()
                                                        }
                                                        res.json({
                                                            status: req.config.statusCode.success,
                                                            data: result,
                                                            message: i18n.__("Get request details successfully")
                                                        });                        
                                                    }
                                            })                                       
                                        }
                                })
                            }
                        }
                    })
                }else{
                    BookingRequestModel.findOne({request_token:req.params.id, accept: true}).exec(function(err,record){
                        if(err){
                            res.json({
                                status: req.config.statusCode.error,
                                data: req.body,
                                message: i18n.__("ERROR")
                            })
                        }else if(record){
                            res.json({
                                status: req.config.statusCode.unauthorized,
                                data: req.body,
                                message: i18n.__("ALREADY_ASSIGNED_BOOKING")
                            })            
                        }else{
                            res.json({
                                status: req.config.statusCode.invalid,
                                data: req.body,
                                message: i18n.__("INVALID_URL")
                            })       
                        }
                    })  
                }
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })
        });
    },

    saveBookingRequest: function (req, res, next){
        BookingRequestModel.findOneAndUpdate({
                _id: req.body.booking_request_id,
                request_token: req.body.request_token
            }, {
                accept: true
            })
            .then((requestData) => {
                if(!requestData){
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR")
                    })
                }else{
                    Booking.findOneAndUpdate({
                            _id: requestData.booking_id
                        },{
                            interpreter_id: requestData.interpreter_id
                        })
                        .then((bookingData)=>{
                            if(!bookingData){
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: req.body,
                                    message: i18n.__("ERROR")
                                })      
                            }else{
                                console.log("comes in interpreter saved");
                                res.json({
                                    status: req.config.statusCode.success,
                                    data: req.body,
                                    message: i18n.__("Booking request saved successfully.")
                                });  
                            }
                    })
                }
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });
    },

    saveEventRequest: function (req, res, next){
        BookingRequestModel.findOneAndUpdate({
                _id: req.body.booking_request_id,
                request_token: req.body.request_token
            }, {
                accept: true
            })
            .then((requestData) => {
                if(!requestData){
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR")
                    })
                }else{
                    SchedulerModel.findOneAndUpdate({
                            _id: requestData.booking_id
                        },{
                            interpreter_id: requestData.interpreter_id,
                            status: 'scheduled'
                        })
                        .then((bookingData)=>{
                            if(!bookingData){
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: req.body,
                                    message: i18n.__("ERROR")
                                })      
                            }else{
                                console.log("comes in interpreter saved");
                                res.json({
                                    status: req.config.statusCode.success,
                                    data: req.body,
                                    message: i18n.__("Booking request saved successfully.")
                                });  
                            }
                    })
                }
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });
    },


}