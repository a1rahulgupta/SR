const _ = require("lodash");
const moment = require('moment');
const i18n = require("i18n");
const util = require('util');
const mongoose = require('mongoose');
const shortid = require('shortid');
const santize = __rootRequire('app/utils/santize');
const geolib = require('geolib');
const waterfall = require('async-waterfall');

//Models 
const User = mongoose.model('Users');
const AgencyModel = mongoose.model('Agencies');
const ClientModel = mongoose.model('Clients');
const RoleModel = mongoose.model('Roles');
const InterpreterModel = mongoose.model('Interpreters');
const AgencyUser = mongoose.model('Agency_users');
const BookingModel = mongoose.model('Bookings');
const CheckInOutModel = mongoose.model('Check_in_outs');
const SchedulerModel = mongoose.model('Schedulers');
const SchedulerSkipModel = mongoose.model('Schedule_skips');

const uuidV4 = require('uuid/v4');
const emailSend = __rootRequire('app/core/email');
const common = __rootRequire('app/config/common.js');
const utility = __rootRequire('app/utils/utility.js');
const fs = require('fs');
const path = require('path');
const async = require('async');

module.exports = {   
   
    getBookindIdsByInterpreterId: function (req, res, next) {
        BookingModel.find({ 
            interpreter_id: req.user.interpreter_id,
            is_deleted:false,
            status: 'pending'
        },{
            booking_id:1,
            service_title: 1,
            booking_from: 1,
            booking_to: 1
        }).exec(function(err, bookingIds){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data:[],
                    message: i18n.__("ERROR")
                })
            } else{
                res.json({
                    status: req.config.statusCode.success,
                    data: bookingIds,
                    message: i18n.__("GET_BOOKING_ID_BY_INTERPRETER_ID")
                });
            }
        }).catch((err) => {
            __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        });
    },

    getBookingDetailByBookingId: function (req, res, next) {
        BookingModel.findOne({
            _id: req.params.id,
            is_deleted: false,
            status: 'pending'
        },{
            client_id: 1
        })
        .populate('client_id', 'first_name last_name')
        .exec()
        .then((booking) => {
            res.json({
                status: req.config.statusCode.success,
                data: booking,
                message: i18n.__("GET_BOOKING_DETAIL")
            });
        })
        .catch((err) => {
            __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    getCheckInOutDetailByBookingId: function (req, res, next) {
        CheckInOutModel.findOne({
            booking_id: req.params.id,
            status: true
        })
        .populate('booking_id', 'booking_id')
        .populate('interpreter_id', 'first_name last_name profile_pic')
        .populate('client_id', 'first_name last_name profile_pic')
        .exec(function(err,checkInOutRecord){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });    
            }else if(checkInOutRecord){
                res.json({
                    status: req.config.statusCode.success,
                    data: checkInOutRecord,
                    message: i18n.__("GET_CHECK_IN_OUT_DETAIL")
                });
            }else{
                res.json({
                    status: req.config.statusCode.notFound,
                    data: [],
                    message: i18n.__("NO_RECORD_FOUND")
                });
            }
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    checkInOutApproval: function (req, res, next) {
        CheckInOutModel.findOne({
            _id: req.body.checkInOutId,
            status: true
        })
        .exec(function(err,checkInOutRecord){
            checkInOutRecord.approval = req.body.approval;
            checkInOutRecord.save(function(err,recordSaved){
                if(err){
                    res.json({
                        status: req.config.statusCode.error,
                        data: [],
                        message: i18n.__("ERROR")
                    });
                }else{
                    if(req.body.approval == 'approved'){
                        BookingModel.findOneAndUpdate({
                            _id: checkInOutRecord.booking_id
                        }, {
                            status: 'completed'
                        }, {
                            new: true
                        })
                        .then((result) => {
                            res.json({
                                status: req.config.statusCode.success,
                                data: result,
                                message: i18n.__("BOOKING_APPROVED_SUCCESFULLY")
                            });
                        })
                    }else if(req.body.approval == 'disapproved'){
                        res.json({
                            status: req.config.statusCode.success,
                            data: {},
                            message: i18n.__("BOOKING_DISAPPROVED_SUCCESFULLY")
                        });
                    }else{
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            message: i18n.__("ERROR")
                        });            
                    }
                }
            })            
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    addGeoCheckIn:  function(req, res, next) {
        var saveObject = {
            agency_id: req.user.agency_id,
            interpreter_id: req.user.interpreter_id,
            booking_id: req.body.booking_id,
            client_id: req.body.client_id,
            verification_type: "GPS",
            time_confirmation: req.body.time_confirmation,
            lat: req.body.latitude,
            long: req.body.longitude,
            booking_lat: req.body.booking_lat,
            booking_long: req.body.booking_long,
            check_in_time: req.body.check_in_time,
            check_in_date: req.body.check_in_date,
            radius: req.body.radius
        };

        var dateFrom = moment(saveObject.check_in_date).startOf('day');
        var dateTo = moment(saveObject.check_in_date).endOf('day');
        var momentObjFrom = new Date(moment(dateFrom));
        var momentObjTo = new Date(moment(dateTo));

        CheckInOutModel.findOne({
            booking_id: saveObject.booking_id,
            status: true,
            $and:[
                {check_in_date: {$gte: momentObjFrom}}, 
                {check_in_date: {$lte: momentObjTo}}
            ]
        }).exec(function(err,checkResult){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })    
            }else if(checkResult !='' && checkResult != undefined && checkResult != null ){
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ALREADY_CHECKED_GPS")
                })
            }else{
                checkIn();
            }
        })

        function checkIn() {
            if (!req.body.time_confirmation) {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR_CERTIFY_GPS_TIME")
                })
            }    
            else if (!req.body.booking_lat && !req.body.booking_long) {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR_BOOKING_LOCATION_LATLNG")
                })
            }
            else if (!req.body.latitude || !req.body.longitude || !req.body.radius){
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("GPS_INVALID_INTERPRETER_POSITION_ERROR")
                })
            }else{
                var  isPointInCircle = geolib.isPointInCircle({ latitude: req.body.latitude, longitude: req.body.longitude },
                    { latitude: req.body.booking_lat, longitude: req.body.booking_long }, saveObject.radius);
                if(isPointInCircle == true){
                    checkInOutModel = new CheckInOutModel(saveObject);
                    checkInOutModel.save()
                    .then((gpsCheckInData) => {
                        SchedulerModel.findOneAndUpdate({
                            _id: saveObject.booking_id
                        }, {
                            status: 'in_process'
                        }, {
                            new: true
                        })
                        .then((result) => {
                            res.json({
                                status: req.config.statusCode.success,
                                data: saveObject,
                                message: i18n.__("GPS_CHECK_IN_SUCCESSFULLY")
                            });
                        })
                    }).catch((err) => {
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })
                    });      
                }else{
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("GPS_OUTBOUND_ERROR")
                    })
                }
            }
        }

    },

    addGeoCheckOut:  function(req, res, next) {
        var finalResponse = {};
        finalResponse.gpsCheckOutData = {};
        finalResponse.events = [];

        var saveObject = {
            verification_type_out: "GPS",
            time_confirmation_out: req.body.time_confirmation,
            lat_in: req.body.latitude,
            long_out: req.body.longitude,
            radius: req.body.radius,
            check_out_time: req.body.check_out_time,
            check_out_date: req.body.check_out_date,
        };

        var dateFrom = moment(saveObject.check_out_date).startOf('day');
        var dateTo = moment(saveObject.check_out_date).endOf('day');
        var momentObjFrom = new Date(moment(dateFrom));
        var momentObjTo = new Date(moment(dateTo));
        var skipToNext = false;
        waterfall([
            function(callback) {
                CheckInOutModel.findOne({
                    booking_id: req.body.booking_id,
                    status: true,
                    $and:[
                        {check_in_date: {$gte: momentObjFrom}}, 
                        {check_in_date: {$lte: momentObjTo}}
                    ]
                }).exec(function(err,checkResult){
                    if(err){
                        callback(err, null);    
                    }else if(checkResult !='' && checkResult != undefined && checkResult != null ){
                        if (!req.body.time_confirmation_out) {
                            res.json({
                                status: req.config.statusCode.error,
                                data: req.body,
                                message: i18n.__("ERROR_CERTIFY_GPS_OUT_TIME")
                            })
                        }    
                        else if (!req.body.booking_lat && !req.body.booking_long) {
                            res.json({
                                status: req.config.statusCode.error,
                                data: req.body,
                                message: i18n.__("ERROR_BOOKING_LOCATION_LATLNG")
                            })
                        }
                        else if (!req.body.latitude || !req.body.longitude || !req.body.radius){
                            res.json({
                                status: req.config.statusCode.error,
                                data: req.body,
                                message: i18n.__("GPS_OUT_INVALID_INTERPRETER_POSITION_ERROR")
                            })
                        }else{
                            var  isPointInCircle = geolib.isPointInCircle({ latitude: req.body.latitude, longitude: req.body.longitude },
                                { latitude: req.body.booking_lat, longitude: req.body.booking_long }, saveObject.radius);
                            if(isPointInCircle == true){
                                checkResult.verification_type_out = saveObject.verification_type_out;
                                checkResult.time_confirmation_out = saveObject.time_confirmation_out;
                                checkResult.lat_out = saveObject.lat_out;
                                checkResult.check_out_time = saveObject.check_out_time;
                                checkResult.check_out_date = saveObject.check_out_date;
                                checkResult.lat_in = saveObject.lat_in;
                                checkResult.check_io_approval = 'approved';
                                checkResult.save()
                                .then((gpsCheckOutData) => {
                                    finalResponse.gpsCheckOutData = gpsCheckOutData;
                                    callback(null, finalResponse);
                                })      
                            }else{
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: {},
                                    message: i18n.__("GPS_OUTBOUND_ERROR")
                                })
                            }
                        }
                    }else{
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("NOT_CHECKED_IN_GPS")
                        })
                    }
                })
            },
            function(finalResponse,callback){
                SchedulerModel.findOne({
                    _id: finalResponse.gpsCheckOutData.booking_id
                })
                .then((result) => {

                    if(result.is_recurring == false){
                        var checkout_start_date = moment(saveObject.check_out_date).startOf('day');
                        var checkout_end_date = moment(saveObject.check_out_date).endOf('day');
                        var momentObjFrom = new Date(moment(checkout_start_date));
                        var momentObjTo = new Date(moment(checkout_end_date));
                        var end_date = moment(result.end_date);
                        if(end_date >= momentObjFrom && end_date <= momentObjTo){
                            result.status = 'completed';
                            result.save(function(err, savedObj){
                                if(err){
                                    callback(err, null);    
                                }else{
                                    skipToNext = true;      
                                    callback(null, finalResponse);      
                                }
                            })
                        }else{
                            result.status = 'scheduled';
                            result.save(function(err, savedObj){
                                if(err){
                                    callback(err, null);    
                                }else{  
                                    skipToNext = true;    
                                    callback(null, finalResponse);      
                                }
                            })      
                        }
                    }else{ // booking is_recurring == true
                        var checkout_start_date = moment(saveObject.check_out_date).startOf('day');
                        var checkout_end_date = moment(saveObject.check_out_date).endOf('day');
                        var momentObjFrom = new Date(moment(checkout_start_date));
                        var momentObjTo = new Date(moment(checkout_end_date));
                        var end_date = moment(result.end_date);
                        var schedulerObj = {
                            month_start_date: momentObjFrom,
                            month_end_date: momentObjTo
                        }

                        SchedulerSkipModel.find({scheduler_id: result._id, event_skip_status: true}).exec(function(err, skipRecords){
                            if(err){
                                callback(err, null);
                            }else{
                                if(result.recurrence_rule == 'custom (weekly)'){
                                    var weekArray = [];
                                    for (var key in result.custom_weekly_repeat_on) {
                                        if(result.custom_weekly_repeat_on[key] == true){
                                            weekArray.push(key);
                                        }
                                    }
                                    var repeating_every_no = (result.repeating_every_no && result.repeating_every_no !=null) ?  parseInt(result.repeating_every_no): 1;
                                    var recurringEventStartEndInterval = utility.convertVirtualEventsDateIntoDateTime(result.start_date, result.end_date, result.event_end_date, result.start_time, result.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, result.recurrence_rule, repeating_every_no, weekArray);                    
                                    if(recurringEventStartEndInterval.length > 0){
                                        for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                            var dateExist = false;
                                            for(var x = 0; x < skipRecords.length; x++){
                                                if(moment(recurringEventStartEndInterval[z].startEvent).isSame(skipRecords[x].start_date)){
                                                    dateExist = true;
                                                    break;
                                                }else{
                                                     dateExist = false;   
                                                }
                                            }
                                            if(dateExist){

                                            }else{
                                                if(recurringEventStartEndInterval[z].endEvent == ""){

                                                }else{
                                                    finalResponse.events.push({
                                                        start_date: recurringEventStartEndInterval[z].startEvent, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                        end_date: recurringEventStartEndInterval[z].endEvent, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                        event_end_date : moment(result.event_end_date),
                                                        service_title: result.service_title
                                                    });
                                                }
                                            }                                                                                                                                     
                                       } 
                                    }
                                    callback(null, finalResponse);
                                }else{
                                    var repeating_every_no = (result.repeating_every_no && result.repeating_every_no !=null) ?  parseInt(result.repeating_every_no): 1;
                                    var recurringEventStartEndInterval = utility.convertVirtualEventsDateIntoDateTime(result.start_date, result.end_date, result.event_end_date, result.start_time, result.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, result.recurrence_rule, repeating_every_no, "");
                                    if(recurringEventStartEndInterval.length > 0){
                                        for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                            var dateExist = false;
                                            for(var x = 0; x < skipRecords.length; x++){

                                                if(moment(recurringEventStartEndInterval[z].startEvent).isSame(skipRecords[x].start_date)){
                                                    dateExist = true;
                                                    break;
                                                }else{
                                                     dateExist = false;   
                                                }
                                            }
                                            if(dateExist){

                                            }else{
                                                if(recurringEventStartEndInterval[z].endEvent == ""){

                                                }else{
                                                    finalResponse.events.push({
                                                        start_date: recurringEventStartEndInterval[z].startEvent, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                        end_date: recurringEventStartEndInterval[z].endEvent, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                        event_end_date : moment(result.event_end_date),
                                                        service_title: result.service_title
                                                    });
                                                }
                                            }                                                                                                                                     
                                       } 
                                    }
                                  callback(null, finalResponse);
                                }                              

                            }
                        })       
                    }
                })
            },
            function(finalResponse,callback){
                if(skipToNext){
                    callback(null, finalResponse);
                }else{
                    var obj = _.filter(finalResponse.events, function(d) { 
                        return (momentObjTo < d.start_date); 
                    });
                    if(obj.length > 0){
                        SchedulerModel.findOneAndUpdate({
                            _id: finalResponse.gpsCheckOutData.booking_id
                        }, {
                            status: 'scheduled'
                        }, {
                            new: true
                        })
                        .then((result) => {
                            callback(null,finalResponse);
                        })
                    }else{
                        SchedulerModel.findOneAndUpdate({
                            _id: finalResponse.gpsCheckOutData.booking_id
                        }, {
                            status: 'completed'
                        }, {
                            new: true
                        })
                        .then((result) => {
                            callback(null,finalResponse)
                        })
                    }
                }
            }
        ], function(err, data) {
        if (err) {
            res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            } else {
                res.json({
                    status: req.config.statusCode.success,
                    data: req.body,
                    message: i18n.__("GPS_CHECK_OUT_SUCCESSFULLY")
                });
            }
        });
    },

    addManualCheckInOut: function(req, res, next){

        var finalResponse = {};
        finalResponse.manualCheckInOutData = {};
        finalResponse.events = [];

        var dateFrom = moment(req.body.check_in_date).startOf('day');
        var dateTo = moment(req.body.check_in_date).endOf('day');
        var momentObjFrom = new Date(moment(dateFrom));
        var momentObjTo = new Date(moment(dateTo));
        
        var skipToNext = false;
        
        waterfall([
            function(callback) {
                if (!req.body.time_confirmation) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR_CERTIFY_MANUAL_TIME")
                    })
                }else{
                    CheckInOutModel.findOne({
                        booking_id: req.body.booking_id,
                        status: true,
                        $and:[
                            {$or:[
                                {$and:[
                                    {check_in_date: {$gte: momentObjFrom}}, 
                                    {check_out_date: {$lte: momentObjTo}}
                                ]},
                                {$and:[
                                    {check_in_date: {$gte: momentObjFrom}}, 
                                    {check_in_date: {$lte: momentObjTo}},
                                    {check_io_approval: 'disapproved'} 
                                ]}
                            ]}
                        ]
                    }).exec(function(err,checkResult){
                        if(err){
                            callback(err, null);    
                        }else if(checkResult !='' && checkResult != undefined && checkResult != null ){
                            if(checkResult.check_io_approval == 'disapproved'){
                                checkResult.status = false;
                                checkResult.save(function(err, disapprovedStatus){
                                    if(err){
                                        callback(err, null); 
                                    }else{
                                        callback(null, finalResponse);
                                    }
                                })
                            }else{
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: req.body,
                                    message: i18n.__("ALREADY_CHECKED_MANUALLY")
                                })
                            }
                        }else{
                            callback(null, finalResponse);
                        }
                    })
                } 
            },
            function(finalResponse,callback){
                checkInOutModel = new CheckInOutModel(req.body);
                checkInOutModel.agency_id = req.user.agency_id;
                checkInOutModel.interpreter_id = req.user.interpreter_id;
                checkInOutModel.time_confirmation = true;
                checkInOutModel.time_confirmation_out = true;
                checkInOutModel.check_io_approval = 'approved';
                checkInOutModel.save(function(err, manualCheckInOutData){
                    if(err){
                        callback(err, null);
                    }else{
                        finalResponse.manualCheckInOutData = manualCheckInOutData;
                        callback(null, finalResponse);
                    }    
                })
            },
            function(finalResponse,callback){
                SchedulerModel.findOne({
                    _id: finalResponse.manualCheckInOutData.booking_id
                })
                .then((result) => {
                    if(result.is_recurring == false){
                        var checkout_start_date = moment(finalResponse.manualCheckInOutData.check_out_date).startOf('day');
                        var checkout_end_date = moment(finalResponse.manualCheckInOutData.check_out_date).endOf('day');
                        var momentObjFrom = new Date(moment(checkout_start_date));
                        var momentObjTo = new Date(moment(checkout_end_date));
                        var end_date = moment(result.end_date);
                        if(end_date >= momentObjFrom && end_date <= momentObjTo){
                            result.status = 'completed';
                            result.save(function(err, savedObj){
                                if(err){
                                    callback(err, null);    
                                }else{
                                    skipToNext = true;      
                                    callback(null, finalResponse);      
                                }
                            })
                        }else{
                            result.status = 'scheduled';
                            result.save(function(err, savedObj){
                                if(err){
                                    callback(err, null);    
                                }else{  
                                    skipToNext = true;    
                                    callback(null, finalResponse);      
                                }
                            })      
                        }
                    }else{ // booking is_recurring == true
                        var checkout_start_date = moment(finalResponse.manualCheckInOutData.check_out_date).startOf('day');
                        var checkout_end_date = moment(finalResponse.manualCheckInOutData.check_out_date).endOf('day');
                        var momentObjFrom = new Date(moment(checkout_start_date));
                        var momentObjTo = new Date(moment(checkout_end_date));
                        var end_date = moment(result.end_date);
                        var schedulerObj = {
                            month_start_date: momentObjFrom,
                            month_end_date: momentObjTo
                        }

                        SchedulerSkipModel.find({scheduler_id: result._id, event_skip_status: true}).exec(function(err, skipRecords){
                            if(err){
                                callback(err, null);
                            }else{
                                if(result.recurrence_rule == 'custom (weekly)'){
                                    var weekArray = [];
                                    for (var key in result.custom_weekly_repeat_on) {
                                        if(result.custom_weekly_repeat_on[key] == true){
                                            weekArray.push(key);
                                        }
                                    }
                                    var repeating_every_no = (result.repeating_every_no && result.repeating_every_no !=null) ?  parseInt(result.repeating_every_no): 1;
                                    var recurringEventStartEndInterval = utility.convertVirtualEventsDateIntoDateTime(result.start_date, result.end_date, result.event_end_date, result.start_time, result.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, result.recurrence_rule, repeating_every_no, weekArray);                    
                                    if(recurringEventStartEndInterval.length > 0){
                                        for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                            var dateExist = false;
                                            for(var x = 0; x < skipRecords.length; x++){
                                                if(moment(recurringEventStartEndInterval[z].startEvent).isSame(skipRecords[x].start_date)){
                                                    dateExist = true;
                                                    break;
                                                }else{
                                                     dateExist = false;   
                                                }
                                            }
                                            if(dateExist){

                                            }else{
                                                if(recurringEventStartEndInterval[z].endEvent == ""){

                                                }else{
                                                    finalResponse.events.push({
                                                        start_date: recurringEventStartEndInterval[z].startEvent, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                        end_date: recurringEventStartEndInterval[z].endEvent, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                        event_end_date : moment(result.event_end_date),
                                                        service_title: result.service_title
                                                    });
                                                }
                                            }                                                                                                                                     
                                       } 
                                    }
                                    callback(null, finalResponse);
                                }else{
                                    var repeating_every_no = (result.repeating_every_no && result.repeating_every_no !=null) ?  parseInt(result.repeating_every_no): 1;
                                    var recurringEventStartEndInterval = utility.convertVirtualEventsDateIntoDateTime(result.start_date, result.end_date, result.event_end_date, result.start_time, result.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, result.recurrence_rule, repeating_every_no, "");
                                    if(recurringEventStartEndInterval.length > 0){
                                        for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                            var dateExist = false;
                                            for(var x = 0; x < skipRecords.length; x++){

                                                if(moment(recurringEventStartEndInterval[z].startEvent).isSame(skipRecords[x].start_date)){
                                                    dateExist = true;
                                                    break;
                                                }else{
                                                     dateExist = false;   
                                                }
                                            }
                                            if(dateExist){

                                            }else{
                                                if(recurringEventStartEndInterval[z].endEvent == ""){

                                                }else{
                                                    finalResponse.events.push({
                                                        start_date: recurringEventStartEndInterval[z].startEvent, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                        end_date: recurringEventStartEndInterval[z].endEvent, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                        event_end_date : moment(result.event_end_date),
                                                        service_title: result.service_title
                                                    });
                                                }
                                            }                                                                                                                                     
                                       } 
                                    }
                                  callback(null, finalResponse);
                                }                              

                            }
                        })       
                    }
                })
            },
            function(finalResponse,callback){
                if(skipToNext){
                    callback(null, finalResponse);
                }else{
                    var obj = _.filter(finalResponse.events, function(d) { 
                        return (momentObjTo < d.start_date); 
                    });
                    if(obj.length > 0){
                        SchedulerModel.findOneAndUpdate({
                            _id: finalResponse.manualCheckInOutData.booking_id
                        }, {
                            status: 'scheduled'
                        }, {
                            new: true
                        })
                        .then((result) => {
                            callback(null,finalResponse);
                        })
                    }else{
                        SchedulerModel.findOneAndUpdate({
                            _id: finalResponse.manualCheckInOutData.booking_id
                        }, {
                            status: 'completed'
                        }, {
                            new: true
                        })
                        .then((result) => {
                            callback(null,finalResponse)
                        })
                    }
                }
            }
        ],function(err, data) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            } else {
                res.json({
                    status: req.config.statusCode.success,
                    data: req.body,
                    message: i18n.__("MANUAL_CHECK_IN_OUT_SUCCESSFULLY")
                });
            }
        });
    },

    getTodaysBookingForManualCheckInOut: function (req, res, next) {
        var finalResponse = {};
        finalResponse.dateArray = [];
        finalResponse.currentMonthEvents = [];
        finalResponse.events = [];
        finalResponse.tempArr = [];
        finalResponse.tempArry = [];

        var currentDate = moment(req.body.todays_date);
        var stopDate = moment(req.body.todays_date);
        var month_start_date = moment(req.body.todays_date).startOf('day');
        var month_end_date = moment(req.body.todays_date).endOf('day');

        // var currentDate = moment(req.body.todays_date).add(2, 'days');
        // var stopDate = moment(req.body.todays_date).add(2, 'days');
        // var month_start_date = moment(req.body.todays_date).startOf('day').add(2, 'days');
        // var month_end_date = moment(req.body.todays_date).endOf('day').add(2, 'days');

        var momentObjFrom = new Date(moment(month_start_date));
        var momentObjTo = new Date(moment(month_end_date));
        var schedulerObj = {
            month_start_date: momentObjFrom,
            month_end_date: momentObjTo
        }

        waterfall([
            function(callback) {
                while (currentDate <= stopDate) {
                    finalResponse.dateArray.push(moment(currentDate))
                    currentDate = moment(currentDate).add(1, 'days');
                }
                callback(null, finalResponse);
            },
            function(finalResponse, callback) {
                var condition = { 
                    agency_id: mongoose.Types.ObjectId(req.user.agency_id),
                    interpreter_id: mongoose.Types.ObjectId(req.user.interpreter_id),
                    is_deleted:false,
                    $and:[
                        {$or:[
                            {status: 'in_process'}, 
                            {status: 'scheduled'}
                        ]},
                        {$or:[
                            {$and:[
                                {start_date: {$lte: momentObjTo}}, 
                                {end_date: {$gte: momentObjFrom}},
                            ]},
                            {$and:[
                                {end_date: {$lte: momentObjFrom}}, 
                                {event_end_date: {$gte: momentObjFrom}}    
                            ]}
                        ]}
                    ]    
                }

                // console.log("event start_date",condition.$or[1].$and[0]);
                
                var aggregateQuery = [{
                    $match: condition
                },{
                    $lookup: {
                        from: 'schedule_skips',
                        localField: "_id",
                        foreignField: "scheduler_id",
                        as: "schedulerInfo"
                    }
                },{
                    $lookup: {
                        from: 'clients',
                        localField: "client_id",
                        foreignField: "_id",
                        as: "clientInfo"
                    }
                },
                {
                    $unwind: {
                        path: "$clientInfo",
                        preserveNullAndEmptyArrays: true
                    }
                },{
                    $lookup: {
                        from: 'interpreters',
                        localField: "interpreter_id",
                        foreignField: "_id",
                        as: "interpreterInfo"
                    }
                },
                {
                    $unwind: {
                        path: "$interpreterInfo",
                        preserveNullAndEmptyArrays: true
                    }
                }
                ];
                // var countQuery = [].concat(aggregateQuery);
                // aggregateQuery.push({
                //     $skip: skip
                // });
                // aggregateQuery.push({
                //     $limit: count
                // });

                SchedulerModel.aggregate(aggregateQuery).exec(function (err, result) {
                    if (err) {
                        callback(err, false);
                    } else if(result.length > 0) {
                        console.log("get result in scheduler",result.length);
                        console.log("get result in scheduler",result);
                        for (var i = result.length - 1; i >= 0; i--) {
                            finalResponse.currentMonthEvents.push(result[i])
                        }
                        callback(null, finalResponse);
                    }else{
                        console.log("result",result);
                        callback(null, finalResponse);
                    }
                })
            },
            function(finalResponse,callback){
                function getRandomColor (){
                    var letters = '0123456789ABCDEF';
                    var color = '#';
                    for (var i = 0; i < 6; i++) {
                        color += letters[Math.floor(Math.random() * 16)];
                    }
                    return color;
                }

                async.each(finalResponse.currentMonthEvents, function(value, callbackEvent) {
                    if(value.is_recurring == false){
                        // console.log("value", value);
                        var colorName = getRandomColor();
                        finalResponse.events.push({
                            _id: value._id,
                            booking_short_id: value.booking_short_id,
                            start_date: moment(value.start_date),
                            end_date: moment(value.end_date),
                            start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                            end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                            service_title: value.service_title, //hol.HOLIDAY_TITLE,
                            status: value.status,
                            is_recurring: value.is_recurring,
                            todays_status: false,
                            clientInfo: value.clientInfo,
                            interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : '')
                        });
                        callbackEvent();
                    }else{
                        if(value.recurrence_rule == 'daily'){
                            var colorName = getRandomColor();
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "daily", repeating_every_no, "");
                            if(recurringEventStartEndInterval.length > 0){
                                for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                    var dateExist = false;
                                    for(var x = 0; x < value.schedulerInfo.length; x++){

                                        if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                            dateExist = true;
                                            break;
                                        }else{
                                             dateExist = false;   
                                        }
                                    }
                                    if(dateExist){

                                    }else{
                                        if(recurringEventStartEndInterval[z].endEvent == ""){

                                        }else{
                                            finalResponse.events.push({
                                                _id: value._id,
                                                booking_short_id: value.booking_short_id,
                                                start_date: recurringEventStartEndInterval[z].startEvent,
                                                end_date: recurringEventStartEndInterval[z].endEvent,
                                                start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                service_title: value.service_title, //hol.HOLIDAY_TITLE,
                                                status: value.status,
                                                is_recurring: value.is_recurring,
                                                todays_status: false,
                                                clientInfo: value.clientInfo,
                                                interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : '')
                                            });
                                        }
                                    }                                                                                                                                     
                               } 
                            }
                        }else if(value.recurrence_rule == 'weekly'){
                            var colorName = getRandomColor();
                            // console.log("colorName in weekly", colorName);
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "weekly" , repeating_every_no, "");                    
                                if(recurringEventStartEndInterval.length > 0){
                                    for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                        var dateExist = false;
                                        for(var x = 0; x < value.schedulerInfo.length; x++){
                                            if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                                dateExist = true;
                                                break;
                                            }else{
                                                 dateExist = false;   
                                            }
                                        }
                                        if(dateExist){

                                        }else{
                                            if(recurringEventStartEndInterval[z].endEvent == ""){
                                        }else{
                                            finalResponse.events.push({
                                                _id: value._id,
                                                booking_short_id: value.booking_short_id,
                                                start_date: recurringEventStartEndInterval[z].startEvent,
                                                end_date: recurringEventStartEndInterval[z].endEvent,
                                                start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                service_title: value.service_title, //hol.HOLIDAY_TITLE,
                                                status: value.status,
                                                is_recurring: value.is_recurring,
                                                todays_status: false,
                                                clientInfo: value.clientInfo,
                                                interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : '')                                
                                            });
                                        }
                                   
                                    }                                                                                                                                     
                               } 
                            } 

                        }
                        else if(value.recurrence_rule == 'monthly'){
                            var colorName = getRandomColor();
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "monthly", repeating_every_no, "");                    
                            if(recurringEventStartEndInterval.length > 0){
                                for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                    var dateExist = false;
                                    for(var x = 0; x < value.schedulerInfo.length; x++){

                                        if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                            dateExist = true;
                                            break;
                                        }else{
                                             dateExist = false;   
                                        }
                                    }
                                    if(dateExist){

                                    }else{
                                        if(recurringEventStartEndInterval[z].endEvent == ""){

                                        }else{
                                            finalResponse.events.push({
                                                _id: value._id,
                                                booking_short_id: value.booking_short_id,
                                                start_date: recurringEventStartEndInterval[z].startEvent,
                                                end_date: recurringEventStartEndInterval[z].endEvent,
                                                start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                service_title: value.service_title, //hol.HOLIDAY_TITLE,
                                                status: value.status,
                                                is_recurring: value.is_recurring,
                                                todays_status: false,
                                                clientInfo: value.clientInfo,
                                                interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : '')                                   
                                            });
                                        }
                                   
                                    }                                                                                                                                     
                                } 
                            } 

                        }else if(value.recurrence_rule == 'yearly'){
                            var colorName = getRandomColor();
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "yearly", repeating_every_no, "");                    
                            if(recurringEventStartEndInterval.length > 0){
                                for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                    var dateExist = false;
                                    for(var x = 0; x < value.schedulerInfo.length; x++){
                                        if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                            dateExist = true;
                                            break;
                                        }else{
                                             dateExist = false;   
                                        }
                                    }
                                    if(dateExist){

                                    }else{
                                        if(recurringEventStartEndInterval[z].endEvent == ""){

                                        }else{
                                            finalResponse.events.push({
                                                _id: value._id,
                                                booking_short_id: value.booking_short_id,
                                                start_date: recurringEventStartEndInterval[z].startEvent,
                                                end_date: recurringEventStartEndInterval[z].endEvent,
                                                start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                service_title: value.service_title, //hol.HOLIDAY_TITLE,
                                                status: value.status,
                                                is_recurring: value.is_recurring,
                                                todays_status: false,
                                                clientInfo: value.clientInfo,
                                                interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : '')
                                            });
                                        }
                                    }                                                                                                                                     
                               } 
                            }
                        }else if(value.recurrence_rule == 'custom (weekly)'){
                            var colorName = getRandomColor();
                            var weekArray = [];
                            for (var key in value.custom_weekly_repeat_on) {
                                if(value.custom_weekly_repeat_on[key] == true){
                                    weekArray.push(key);
                                }
                            }
                            var repeating_every_no = (value.repeating_every_no && value.repeating_every_no !=null) ?  parseInt(value.repeating_every_no): 1;
                            var recurringEventStartEndInterval = convertVirtualEventsDateIntoDateTime(value.start_date, value.end_date, value.event_end_date, value.start_time, value.end_time, schedulerObj.month_start_date, schedulerObj.month_end_date, "custom (weekly)", repeating_every_no, weekArray);                    
                            if(recurringEventStartEndInterval.length > 0){
                                for(var z = 0; z < recurringEventStartEndInterval.length; z++){   
                                    var dateExist = false;
                                    for(var x = 0; x < value.schedulerInfo.length; x++){
                                        if(moment(recurringEventStartEndInterval[z].startEvent).isSame(value.schedulerInfo[x].start_date)){
                                            dateExist = true;
                                            break;
                                        }else{
                                             dateExist = false;   
                                        }
                                    }
                                    if(dateExist){

                                    }else{
                                        if(recurringEventStartEndInterval[z].endEvent == ""){

                                        }else{
                                            finalResponse.events.push({
                                                _id: value._id,
                                                booking_short_id: value.booking_short_id,
                                                start_date: recurringEventStartEndInterval[z].startEvent,
                                                end_date: recurringEventStartEndInterval[z].endEvent,
                                                start_time: value.start_time, //$filter('dateFilter')(hol.HOLIDAY_START),
                                                end_time: value.end_time, //$filter('dateFilter')(hol.HOLIDAY_END),
                                                service_title: value.service_title, //hol.HOLIDAY_TITLE,
                                                status: value.status,
                                                is_recurring: value.is_recurring,
                                                todays_status: false,
                                                clientInfo: value.clientInfo,
                                                interpreterInfo: (value.interpreterInfo ? value.interpreterInfo : '')
                                            });
                                        }
                                    }                                                                                                                                     
                               } 
                            }
                        }
                        callbackEvent()

                        function getDayString(day){
                            var dayString = ""
                            switch (day) {
                                case 0:
                                    dayString = "Sunday";
                                    break;
                                case 1:
                                    dayString = "Monday";
                                    break;
                                case 2:
                                    dayString = "Tuesday";
                                    break;
                                case 3:
                                    dayString = "Wednesday";
                                    break;
                                case 4:
                                    dayString = "Thursday";
                                    break;
                                case 5:
                                    dayString = "Friday";
                                    break;
                                case 6:
                                    dayString = "Saturday";
                            }
                            return dayString;
                        }

                        function getMonthString(month_no){
                          var monthString = ""
                            switch (month_no) {
                                case 0:
                                    monthString = "January";
                                    break;
                                case 1:
                                    monthString = "February";
                                    break;
                                case 2:
                                    monthString = "March";
                                    break;
                                case 3:
                                    monthString = "April";
                                    break;
                                case 4:
                                    monthString = "May";
                                    break;
                                case 5:
                                    monthString = "June";
                                    break;
                                case 6:
                                    monthString = "July";
                                    break;
                                case 7:
                                    monthString = "August";
                                    break;
                                case 8:
                                    monthString = "September";
                                    break;
                                case 9:
                                    monthString = "October";
                                    break;
                                case 10:
                                    monthString = "November";
                                    break;
                                case 11:
                                    monthString = "December";
                                    break;    
                            }
                            return monthString;
                        }

                        function addHoursInDate(recurringWeeklyDateOnly, startHours, startMinutes){
                            var newRecurringWeeklyDateOnly = new Date(recurringWeeklyDateOnly);
                            newRecurringWeeklyDateOnly.setHours(startHours);
                            newRecurringWeeklyDateOnly.setMinutes(startMinutes);
                            return moment(newRecurringWeeklyDateOnly);
                        }

                        function convertVirtualEventsDateIntoDateTime(startTime,endTime,stopTimeDateTime,startTimeOnly,endTimeOnly, month_start_date, month_end_date, interval, repeating_every_no, weekArray){    //function to find the recurring inetrvals:start/end            
                            var recurringDateTimeStartEndOfEvent = [];      
                              
                            //start Event Calculation//
                            var eventStartTime = startTimeOnly;
                            var eventEndTime = endTimeOnly;

                            var month_start_date = moment(month_start_date).startOf('day');
                            var month_end_date = moment(month_end_date).startOf('day');
                            var momentObjMonth_start_date = new Date(moment(month_start_date));
                            var momentObjMonth_end_date = new Date(moment(month_end_date));

                            var tmpStartTime = convertTo24Format(startTimeOnly);
                            var tmpEndTime = convertTo24Format(endTimeOnly);
                              
                            var localStartDateTime =  moment(startTime).utc();
                            var localEndDateTime = moment(endTime).utc();

                            var localTimeStopTime =  moment(stopTimeDateTime).utc();                                         
                            var startHours = new Date(localStartDateTime).getHours();
                            var startMinutes = new Date(localStartDateTime).getMinutes();
                            var startDayString = getDayString(new Date(localStartDateTime).getDay());
                            var startDateOfMonth = new Date(localStartDateTime).getDate();
                            var startMonthOfYear = getMonthString(new Date(localStartDateTime).getMonth());
                            //end of event Calculation//

                            var endHours = new Date(localEndDateTime).getHours();
                            var endMinutes = new Date(localEndDateTime).getMinutes();
                            var endDayString = getDayString(new Date(localEndDateTime).getDay());
                            var endDateOfMonth = new Date(localEndDateTime).getDate();
                            var endMonthOfYear = getMonthString(new Date(localEndDateTime).getMonth());

                            if(interval == "daily"){
                                var recurringDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(1).days();
                                var recurringDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(1).days();
                                if(recurringDatesForStart.all().length > 0){
                                    for(var i = 0 ; i<recurringDatesForStart.all().length; i++){ 
                                        if(i%repeating_every_no == 0){
                                            var recurringDateOnly =  recurringDatesForStart.all()[i]
                                            var isafter = moment(recurringDateOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent.push({
                                                startEvent : addHoursInDate(recurringDateOnly, startHours, startMinutes),
                                                endEvent : ""
                                            });
                                            recurringDateOnly = "";
                                        }else{
                                            continue;
                                        }
                                    }
                                }

                                if(recurringDatesForEnd.all().length > 0){
                                    var z = 0;
                                    for(var j = 0 ; j<recurringDatesForEnd.all().length; j++){
                                        if(j%repeating_every_no == 0){
                                            var recurringDateEndOnly =  recurringDatesForEnd.all()[j]
                                            var isafter = moment(recurringDateEndOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringDateEndOnly, endHours, endMinutes),
                                            recurringDateEndOnly = "";
                                            z++;
                                        }else{
                                            continue;
                                        }
                                    }
                                }

                            }else if(interval == "weekly"){
                                var weekDayStartString = [];
                                var weekDayEndString = [];
                                weekDayStartString.push(startDayString);
                                weekDayEndString.push(endDayString)
                                                                    
                                var recurringWeeklyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(weekDayStartString).daysOfWeek();
                                var recurringWeeklyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(weekDayEndString).daysOfWeek(); 
                                if(recurringWeeklyDatesForStart.all().length > 0){

                                    for(var i = 0; i<recurringWeeklyDatesForStart.all().length; i++){
                                        if(i%repeating_every_no == 0){
                                            var recurringWeeklyDateOnly =  recurringWeeklyDatesForStart.all()[i];
                                            var isafter = moment(recurringWeeklyDateOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent.push({
                                                startEvent : addHoursInDate(recurringWeeklyDateOnly, startHours, startMinutes),
                                                endEvent : ""
                                            });
                                            recurringWeeklyDateOnly = "";
                                        }else{
                                            continue;
                                        }
                                    }
                                }
                                if(recurringWeeklyDatesForEnd.all().length > 0){
                                    var z = 0;
                                    for(var j = 0 ; j<recurringWeeklyDatesForEnd.all().length; j++){
                                        if(j%repeating_every_no == 0){
                                            var recurringWeeklyDateEndOnly =  recurringWeeklyDatesForEnd.all()[j]
                                            var isafter = moment(recurringWeeklyDateEndOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringWeeklyDateEndOnly, endHours, endMinutes),
                                            recurringWeeklyDateEndOnly = "";
                                            z++;
                                        }else{
                                            continue;
                                        }
                                    }
                                } 
                            }else if(interval == "custom (weekly)"){
                                var weekDayStartString = weekArray;
                                var weekDayEndString = weekArray;
                                var arr = [];
                                var array1d = [];
                                var arr1d = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
                                for(var u=0; u<arr1d.length; u++){
                                    if(weekArray.indexOf(arr1d[u]) != -1){
                                        array1d.push(arr1d[u]);
                                    }
                                }

                                arr['sunday'] = 0;
                                arr['monday'] = 1;
                                arr['tuesday'] = 2;
                                arr['wednesday'] = 3;
                                arr['thursday'] = 4;
                                arr['friday'] = 5;
                                arr['saturday'] = 6;
                                var len = weekArray.length;
                                var recurringWeeklyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(weekDayStartString).daysOfWeek();
                                var recurringWeeklyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(weekDayEndString).daysOfWeek(); 
                                if(recurringWeeklyDatesForStart.all().length > 0){
                                    var t2,t3 = 0;
                                    for(var p=0; p < weekArray.length; p++){
                                        t2 = getDayString(new Date(recurringWeeklyDatesForStart.all()[0]).getDay());
                                        t3++;
                                        if(arr[t2.toLowerCase()] <= arr[array1d[p].toLowerCase()] ){
                                            break;
                                        }
                                    }
                                    for(var i = t3; i <= recurringWeeklyDatesForStart.all().length; i++){
                                        var recurringWeeklyDateOnly =  recurringWeeklyDatesForStart.all()[i-t3];
                                        var isafter = moment(recurringWeeklyDateOnly).isAfter(momentObjMonth_end_date);
                                        recurringDateTimeStartEndOfEvent.push({
                                            startEvent : addHoursInDate(recurringWeeklyDateOnly, startHours, startMinutes),
                                            endEvent : ""
                                        });
                                        recurringWeeklyDateOnly = "";
                                        if( i%len  == 0 ){
                                            var skip  = len*repeating_every_no - len;
                                            i = i + skip; 
                                        }
                                    }
                                }
                                if(recurringWeeklyDatesForEnd.all().length > 0){
                                    var t2,t3 = 0;
                                    for(var p=0; p < weekArray.length; p++){
                                        t2 = getDayString(new Date(recurringWeeklyDatesForStart.all()[0]).getDay());
                                        t3++;
                                        if(arr[t2.toLowerCase()] <= arr[array1d[p].toLowerCase()] ){
                                            break;
                                        }
                                    }
                                    var z = 0;
                                    for(var j = t3 ; j <= recurringWeeklyDatesForEnd.all().length; j++){
                                            var recurringWeeklyDateEndOnly =  recurringWeeklyDatesForEnd.all()[j-t3]
                                            var isafter = moment(recurringWeeklyDateEndOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringWeeklyDateEndOnly, endHours, endMinutes),
                                            recurringWeeklyDateEndOnly = "";
                                            z++;
                                        if(j%len  == 0 ){
                                            var skip  = len*repeating_every_no - len;
                                            j = j + skip;
                                        }
                                    }
                                } 
                            }else if(interval == "monthly"){
                                var recurringMonthlyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(startDateOfMonth).dayOfMonth();
                                var recurringMonthlyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(endDateOfMonth).dayOfMonth();
                                if(recurringMonthlyDatesForStart.all().length > 0){
                                    for(var i = 0 ; i<recurringMonthlyDatesForStart.all().length; i++){
                                        if(i%repeating_every_no == 0){
                                            var recurringMonthDateOnly =  recurringMonthlyDatesForStart.all()[i]
                                            recurringDateTimeStartEndOfEvent.push({
                                                startEvent :  addHoursInDate(recurringMonthDateOnly, startHours, startMinutes),
                                                endEvent : ""
                                            });
                                            recurringMonthDateOnly = "";
                                        }else{
                                            continue;
                                        }

                                    }
                                }
                                if(recurringMonthlyDatesForEnd.all().length > 0){
                                    var z = 0;
                                    for(var j = 0 ; j<recurringMonthlyDatesForEnd.all().length; j++){
                                        if(j%repeating_every_no == 0){
                                            var recurringMonthDateEndOnly =  recurringMonthlyDatesForEnd.all()[j];
                                            recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringMonthDateEndOnly, endHours, endMinutes),
                                            recurringMonthDateEndOnly = "";
                                            z++;
                                        }else{
                                            continue;
                                        }
                                    }
                                }
                            }else if(interval == "yearly"){ 
                                var recurringYearlyDatesForStart =  moment().recur(localStartDateTime, localTimeStopTime).every(startDateOfMonth).daysOfMonth().every(startMonthOfYear).monthsOfYear();
                                var recurringYearlyDatesForEnd =  moment().recur(localEndDateTime, localTimeStopTime).every(endDateOfMonth).daysOfMonth().every(endMonthOfYear).monthsOfYear();
                                if(recurringYearlyDatesForStart.all().length > 0){
                                    for(var i = 0 ; i<recurringYearlyDatesForStart.all().length; i++){
                                        if(i%repeating_every_no == 0){
                                            var recurringYearlyDateOnly =  recurringYearlyDatesForStart.all()[i]
                                            recurringDateTimeStartEndOfEvent.push({
                                              startEvent : addHoursInDate(recurringYearlyDateOnly, startHours, startMinutes),
                                              endEvent : ""
                                            });
                                            recurringYearlyDateOnly = "";
                                        }else{
                                            continue;
                                        }
                                    }
                                }
                                if(recurringYearlyDatesForEnd.all().length > 0){
                                    var z = 0;
                                    for(var j = 0 ; j<recurringYearlyDatesForEnd.all().length; j++){
                                        if(j%repeating_every_no == 0){
                                            var recurringYearlyDateEndOnly =  recurringYearlyDatesForEnd.all()[j]
                                            var isafter = moment(recurringYearlyDateEndOnly).isAfter(momentObjMonth_end_date);
                                            recurringDateTimeStartEndOfEvent[z].endEvent = addHoursInDate(recurringYearlyDateEndOnly, endHours, endMinutes),
                                            recurringYearlyDateEndOnly = "";
                                            z++;
                                        }else{
                                            continue;
                                        }
                                    }
                                }  
                            }
                            return recurringDateTimeStartEndOfEvent;          
                        }

                        function convertTo24Format(timeStr){
                            var tmp=timeStr;
                            var tmpArr = tmp.split(':');
                            var t = tmpArr[1].split(' ')[1];
                            var hour= tmpArr[0].trim();
                            var minute= tmpArr[1].split(' ')[0];
                            if(t=='PM'){
                                if(hour!=12){
                                    hour = parseInt(hour) + 12;
                                }
                            } else if(t=='AM'){
                                if(hour==12){
                                    hour=0;
                                }
                            }
                            return { 'hour': hour, 'minute': minute};
                        }
                    }
                },function(err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            },
            function(finalResponse,callback){
                // console.log("before finalResponse.events",finalResponse.events.length);
                // console.log("before finalResponse.events",finalResponse.events);
                async.each(finalResponse.dateArray, function(date, cb) {
                    var obj = _.filter(finalResponse.events, function(d) { 
                        if(moment(date.format('YYYY-MM-DD')).isSameOrAfter(d.start_date.format('YYYY-MM-DD')) && moment(date.format('YYYY-MM-DD')).isSameOrBefore(d.end_date.format('YYYY-MM-DD'))){
                            console.log("moment(date.format('YYYY-MM-DD'))", moment(date.format('YYYY-MM-DD')));
                            var startHours = new Date(d.start_date).getHours();
                            var startMinutes = new Date(d.start_date).getMinutes();
                            var start_date = moment(date.format('YYYY-MM-DD'));
                            var endHours = new Date(d.end_date).getHours();
                            var endMinutes = new Date(d.end_date).getMinutes();
                            var end_date = moment(date.format('YYYY-MM-DD'));
                            d.start_date = utility.addHoursInDate(start_date, startHours, startMinutes); 
                            d.end_date = utility.addHoursInDate(end_date, endHours, endMinutes); 
                            return d;
                        } 
                    });
                    if(obj.length > 0){
                        // console.log("object@2222", obj);
                        for (var i = obj.length - 1; i >= 0; i--) {
                            finalResponse.tempArr.push(obj[i]);
                        }
                        cb(null,finalResponse);
                    }else{
                        cb(null,finalResponse)
                    }
                }, function(err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        // console.log("finalResponse", finalResponse.tempArr);
                        callback(null, finalResponse);
                    }
                });
            },
            function(finalResponse,callback){
                // console.log("before finalResponse.events",finalResponse.events.length);
                // console.log("before finalResponse.events",finalResponse.events);
                async.each(finalResponse.tempArr, function(todayRecord, cbt) {
                    CheckInOutModel.findOne({
                        booking_id : mongoose.Types.ObjectId(todayRecord._id),
                        is_deleted: false,
                        status: true,
                        $and:[
                            {$or:[
                                {$and:[
                                    {check_in_date: {$gte: momentObjFrom}}, 
                                    {check_out_date: {$lte: momentObjTo}}
                                ]},
                                {$and:[
                                    {check_in_date: {$gte: momentObjFrom}}, 
                                    {check_in_date: {$lte: momentObjTo}},
                                    {check_io_approval: 'disapproved'} 
                                ]}
                            ]}
                        ]
                    }).exec(function(err, check_in_out_record){
                        if(err){
                            callback(err, false);
                        }else {
                            // console.log("check_in_out_record", check_in_out_record);
                            if(check_in_out_record == null){
                                finalResponse.tempArry.push(todayRecord);
                            }else{
                                todayRecord.todays_status = true;
                                finalResponse.tempArry.push(todayRecord);
                            }
                            cbt();
                        }
                    })
                }, function(err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        // console.log("finalResponse", finalResponse.tempArry);
                        callback(null, finalResponse);
                    }
                });
            },

        ], function(err, data) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    message: i18n.__("ERROR")
                });
            } else {

                res.json({
                    status: req.config.statusCode.success,
                    data: data.tempArry,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }
        });
        
    },

    getBookingForManualCheckInOut: function (req, res, next) {
        SchedulerModel.findOne({
            _id: req.params.id,
            is_deleted: false
        })
        .populate('client_id', 'first_name last_name')
        .exec()
        .then((booking) => {
            res.json({
                status: req.config.statusCode.success,
                data: booking,
                message: i18n.__("GET_BOOKING_DETAIL")
            });
        })
        .catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

}