module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];
    var check_in_out_ctrl = require('./controllers/check_in_out_ctrl')

    router.get('/check_in_out/getBookindIdsByInterpreterId', middlewares, check_in_out_ctrl.getBookindIdsByInterpreterId);
    router.post('/check_in_out/addManualCheckInOut', middlewares, check_in_out_ctrl.addManualCheckInOut);
    router.post('/check_in_out/addGeoCheckIn', middlewares, check_in_out_ctrl.addGeoCheckIn);
    router.post('/check_in_out/addGeoCheckOut', middlewares, check_in_out_ctrl.addGeoCheckOut);
    router.post('/check_in_out/checkInOutApproval', middlewares, check_in_out_ctrl.checkInOutApproval);
    router.get('/check_in_out/getBookingDetailByBookingId/:id', middlewares, check_in_out_ctrl.getBookingDetailByBookingId);
    router.get('/check_in_out/getCheckInOutDetailByBookingId/:id', middlewares, check_in_out_ctrl.getCheckInOutDetailByBookingId);
    router.get('/check_in_out/getTodaysBookingForManualCheckInOut', middlewares, check_in_out_ctrl.getTodaysBookingForManualCheckInOut);
    router.get('/check_in_out/getBookingForManualCheckInOut/:id', middlewares, check_in_out_ctrl.getBookingForManualCheckInOut);


    return router;
}