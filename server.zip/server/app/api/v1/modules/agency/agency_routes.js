module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];

    var agency_ctrl = require('./controllers/agency_ctrl')
    // router.get('/agency/getAllBookings', middlewares, agency_ctrl.getAllBooking);   
    router.post('/agency/registration', agency_ctrl.agencyRegistration);
    router.post('/agency/agencyRegisterEmailCheck', agency_ctrl.agencyRegistrationEmailCheck);
    router.post('/agency/addAgencyBySuperAdmin', middlewares, agency_ctrl.addAgencyBySuperAdmin);
    router.post('/agency/listAgencyBySuperAdmin', middlewares, agency_ctrl.listAgencyBySuperAdmin);
    router.get('/agency/getAgencyByIdBySuperAdmin/:id', middlewares, agency_ctrl.getAgencyByIdBySuperAdmin);
    router.post('/agency/updateAgencyBySuperAdmin', middlewares, agency_ctrl.updateAgencyBySuperAdmin);
    router.delete('/agency/deleteAgencyBySuperAdmin/:id', middlewares, agency_ctrl.deleteAgencyBySuperAdmin);
    router.post('/agency/changeAgencyStatusBySuperAdmin', middlewares, agency_ctrl.changeAgencyStatusBySuperAdmin);

    router.get('/agency/listAgencyClients', middlewares, agency_ctrl.listAgencyClients);
    router.get('/agency/getCountOfAgency', middlewares, agency_ctrl.getCountOfAgency);
    // router.get('/agency/getAllBookings', middlewares, agency_ctrl.getAllBookings);
    router.post('/agency/listComplaintByAgency', middlewares, agency_ctrl.listComplaintByAgency);
    router.get('/agency/getAllBookings', middlewares, agency_ctrl.getAllBookings);
    router.get('/agency/getAgencyProfileById', middlewares, agency_ctrl.getAgencyProfileById);
    router.post('/agency/updateAgencyProfile', middlewares, agency_ctrl.updateAgencyProfile);
    router.get('/agency/exportToPdfForTopTenCustomers', middlewares, agency_ctrl.exportToPdfForTopTenCustomers);
    router.get('/agency/exportToPdfByClientIdInReports/:id', middlewares, agency_ctrl.exportToPdfByClientIdInReports);
    router.get('/agency/exportToPdfByLanguageInReport/:language', middlewares, agency_ctrl.exportToPdfByLanguageInReport);
    router.get('/agency/getLanguageNameByLanguageIdInReport/:id', middlewares, agency_ctrl.getLanguageNameByLanguageIdInReport);
    router.get('/agency/listAgencySuperAdmin', middlewares, agency_ctrl.listAgencySuperAdmin);
    router.post('/agency/agencySubscriptionActivateSuperAdmin', agency_ctrl.agencySubscriptionActivateSuperAdmin);
    router.post('/agency/activateAgencyWithSubscription', agency_ctrl.activateAgencyWithSubscription);
    router.post('/agency/upgradeSubscriptionPlan', agency_ctrl.upgradeSubscriptionPlan);
    
    return router;
}