const _ = require("lodash");
const moment = require('moment');
const Joi = require('joi');
const bcrypt = require('bcrypt');
const i18n = require("i18n");
const mongoose = require('mongoose');
const santize = __rootRequire('app/utils/santize');
const fs = require('fs');
const pdf = require('html-pdf');
const uuidV4 = require('uuid/v4');
const common = __rootRequire('app/config/common.js');
const emailSend = __rootRequire('app/core/email');
const voucher_codes = require('voucher-code-generator');
const async = require('async');

//Models 
const User = mongoose.model('Users');
const AgencyModel = mongoose.model('Agencies');
const ClientModel = mongoose.model('Clients');
const RoleModel = mongoose.model('Roles');
const InterpreterModel = mongoose.model('Interpreters');
const EmailTemplateModel = mongoose.model('Email_Templates');
const LanguageModel = mongoose.model('Languages');
const AgencyUser = mongoose.model('Agency_users');
const SubscriptionModel = mongoose.model('Subscriptions');
const CardDetailModel = mongoose.model('Card_details');
const ClientLanguagesModel = mongoose.model('Client_languages');
const Booking = mongoose.model('Bookings');
const PaymentModel = mongoose.model('Payments');
const AgencySubscriptionModel = mongoose.model('Agency_subscriptions');
const CustomerComplaintModel = mongoose.model('Customercomplaint');
const AdminModel = mongoose.model('Admin');
const stripe = require("stripe")('sk_test_v8sGUiDgrCVhulcdhOBLaedx');
const SchedulerModel = mongoose.model('Schedulers');

module.exports = {
    listAgencyClients: function (req, res, next) {
        AgencyUser.find({
            role_id: req.user.role_id
        })
        .populate('role_id', 'role group -_id')
        .exec()
        .then((clients) => {
            res.json({
                status: req.config.statusCode.success,
                data: clients
            });
        })
        .catch((err) => {
            __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                message: i18n.__("ERROR")
            });
        })
    },

    listAgencyBySuperAdmin: function(req, res, next) {

        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        // var sorting = utility.getSortObj(req.body);
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        var condition = {};
        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        condition.is_deleted = false;
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (req.body.searchText) {
            condition.$or = [
                { 'agency_name': new RegExp(searchText, 'gi') },
                { 'agencySubscriptionInfo.plan_name': new RegExp(searchText, 'gi') },
                { 'mobile_no': new RegExp(searchText, 'gi') },
                { 'userInfo.email': new RegExp(searchText, 'gi') },
            ];
        }

        var aggregate = [{
                $lookup: {
                    from: 'users',
                    localField: "user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: {
                    path: "$userInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $match: condition
            },
            {
                $lookup: {
                    from: 'agency_subscriptions',
                    localField: "_id",
                    foreignField: "agency_id",
                    as: "agencySubscriptionInfo"
                }
            },
        ];
        var project = {
            $project: {
                agency_name: 1,
                mobile_no: 1,
                status:1,
                email: '$userInfo.email',
                activation_key: "$userInfo.activation_key",
                user_id: "$userInfo._id",
                is_verified: '$userInfo.is_verified',
                agencySubscription: {
                    $filter: {
                        input: "$agencySubscriptionInfo",
                        as: "item",
                        cond: { $eq: ["$$item.status", true] }

                    }
                },
            }
        };
        var countQuery = [].concat(aggregate);
        aggregate.push(project);
        aggregate.push({ $sort: sorting });
        aggregate.push({ $skip: parseInt(skip) });
        aggregate.push({ $limit: parseInt(count) });
        AgencyModel.aggregate(aggregate).then(function(result) {
            countQuery.push({ $group: { _id: null, count: { $sum: 1 } } });
            AgencyModel.aggregate(countQuery).then(function(dataCount) {
                var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                console.log("result",result);
                res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    count: cnt
                });
            });
        }).catch(function(err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        });
    },

    // listAgencyBySuperAdmin: function (req, res, next) {
    //     console.log("ahsjhdjkahsdjh")
    //     var count = parseInt(req.body.count ? req.body.count : 0);
    //     var skip = parseInt(req.body.count * (req.body.page - 1));
    //     var sorting = req.body.sorting ? req.body.sorting : {
    //         _id: -1
    //     };

    //     for (var key in req.body) {
    //         var reg = new RegExp("sorting", 'gi');
    //         if (reg.test(key)) {
    //             var value = req.body[key];
    //             key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
    //             var sorting = {};
    //             if (value == 1 || value == -1) {
    //                 sorting[key] = value;
    //             } else {
    //                 sorting[key] = (value == 'desc') ? -1 : 1;
    //             }
    //         }
    //     }

    //     var condition = {
    //         is_deleted: false
    //     }
    //     var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
    //     // var searchText = req.body.searchText;
    //     if (searchText != undefined && searchText != 'undefined') {
    //         condition.$or = [{
    //                 'agency_name': new RegExp(searchText, 'gi')
    //             },
    //             {
    //                 'mobile_no': new RegExp(searchText, 'gi')
    //             },
    //             {
    //                 'userInfo.email': new RegExp(searchText, 'gi')
    //             }
    //         ];
    //     }

    //     var aggregateQuery = [{
    //             $lookup: {
    //                 from: 'users',
    //                 localField: "user_id",
    //                 foreignField: "_id",
    //                 as: "userInfo"
    //             }
    //         },
    //         {
    //             $unwind: {
    //                 path: "$userInfo",
    //                 preserveNullAndEmptyArrays: true
    //             }
    //         },
    //         {
    //             $match: condition
    //         }
    //     ];
    //     var countQuery = [].concat(aggregateQuery);
    //     aggregateQuery.push({
    //         $sort: sorting
    //     });
    //     aggregateQuery.push({
    //         $skip: skip
    //     });
    //     aggregateQuery.push({
    //         $limit: count
    //     });
    //     AgencyModel.aggregate(aggregateQuery).exec(function (err, result) {
    //         if (err) {
    //             res.json({
    //                 status: req.config.statusCode.error,
    //                 data: [],
    //                 count: 0,
    //                 message: i18n.__("ERROR")
    //             });
    //         } else {
    //             countQuery.push({
    //                 $group: {
    //                     _id: null,
    //                     count: {
    //                         $sum: 1
    //                     }
    //                 }
    //             });
    //             AgencyModel.aggregate(countQuery).exec(function (err, dataCount) {
    //                 if (err) {
    //                     res.json({
    //                         status: req.config.statusCode.error,
    //                         data: [],
    //                         count: 0,
    //                         message: i18n.__("ERROR")
    //                     });
    //                 } else {
    //                     var cnt = (dataCount[0]) ? dataCount[0].count : 0;
    //                     res.json({
    //                         status: req.config.statusCode.success,
    //                         data: result,
    //                         count: cnt
    //                     });
    //                 }
    //             });
    //         }
    //     }).catch(function (err) {
    //         res.json({
    //             status: req.config.statusCode.error,
    //             data: [],
    //             count: 0,
    //             message: i18n.__("ERROR")
    //         });
    //     })
    // },



    addAgencyBySuperAdmin: function (req, res, next) {
        if (req.body.imageFile) {
            var timestamp = Number(new Date()); // current time as number
            var imageFile = req.body.imageFile;
            var filename = +timestamp + '_' + common.randomToken(6) + '.' + 'png';
            var imagePath = "./../client/users/assets/uploads/profile/" + filename;
        }

        function register() {
            User.findOne({
                email: req.body.email
            }, function (err, emailData) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR")
                    })
                } else {
                    if (emailData) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: {},
                            message: i18n.__("Email Id already exist ! Try with different Email.")
                        })
                    } else {
                        RoleModel.findOne({role:req.config.role_type.AGENCY_ADMIN.name}).exec(function(err,roleData){
                            if(err){
                                // console.log("roleerr",err);
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: req.body,
                                    message: i18n.__("ERROR")
                                })
                            }else if(roleData){
                                    var user = new User();
                                    user.email = req.body.email;
                                    user.role_id = roleData._id;
                                    user.activation_key = uuidV4();
                                    user.save()
                                        .then((userData) => {
                                            agency = new AgencyModel(req.body);
                                            agency.user_id = userData._id;
                                            if (filename) {
                                                agency.profile_pic = "/assets/uploads/profile/" + filename;
                                            }
                                            agency.save()
                                                .then((agencyData) => {
                                                    if(req.config.env == 'dev'){
                                                        var baseUrl = 'http://52.34.207.5084:';
                                                    }
                                                    else if(req.config.env == 'aws'){
                                                        var baseUrl = 'https://www.interpreting.works';
                                                    }else{
                                                        var baseUrl = req.config.email.base_url;
                                                    }
                                                    var options = {
                                                        template: 'set_password.html',
                                                        from: req.user.email,
                                                        repalcement: {
                                                            "{{user.name}}": agencyData.agency_name.charAt(0).toUpperCase()+agencyData.agency_name.slice(1).toLowerCase(),
                                                            "{{user.email}}": userData.email,
                                                            "{{user.activation_key}}": baseUrl + '/#/activateAgency/' + userData.activation_key,
                                                            "{{logo_url}}": baseUrl + req.config.email.logo_url,
                                                            "{{copyright}}": req.config.email.copyright,
                                                            "{{link.abuse_email}}": req.config.email.abuse_email
                                                        },
                                                        to: userData.email,
                                                        subject: 'Complete Registration'
                                                    };
                                                    emailSend.smtp.sendMail(options, function (err, response) {
                                                        if (err) {
                                                            //__debug(err)
                                                            console.log("error",err);
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: {},
                                                                message: i18n.__("ERROR")
                                                            })
                                                        }else{
                                                            User.findOneAndUpdate({
                                                                _id: userData._id
                                                            }, {
                                                                is_verification_email_send: true
                                                            }, {
                                                                new: true
                                                            }).then((userData) => {

                                                            })
                                                        }
                                                    })
                                                    return agencyData
                                                }).then((agencyData) => {
                                                    // var linkTo = req.config.email.base_url+ '/#/setPassword/' + userData.activation_key;
                                                    // var text = "You've registered with this email " + userData.email + "\n to complete your registration click on the provided link below\n" + linkTo + "\n If you didn't request this, you can ignore this email.";
                                                    // var data = { to: '+919990795913', message: text }
                                                    // twilioSms.sendSMS(data, function(returnData) {
                                                    //     console.log('twilio', returnData);
                                                    // });
                                                    res.json({
                                                        status: req.config.statusCode.success,
                                                        data: agencyData,
                                                        message: i18n.__("Agency added succesfully")
                                                    });                                            
                                                }).catch((err) => { 
                                                    // console.log("catch",err);
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: req.body,
                                                        message: i18n.__("ERROR")
                                                    })
                                                });
                                        }).catch((err) => {
                                            //__debug(err)
                                            // console.log("catch2",err);
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: req.body,
                                                message: i18n.__("ERROR")
                                            })
                                        });
                            }else{
                                // console.log("no record",err);
                                res.json({
                                    status: req.config.statusCode.success,
                                    data: {},
                                    message: i18n.__("No record found")
                                });
                            }
                        })
                    }
                }
            })
        }

        if (req.body.imageFile) {
            var base64Data = req.body.imageFile.replace(/^data:image\/png;base64,/, "");
            base64Data += base64Data.replace('+', ' ');
            binaryData = new Buffer(base64Data, 'base64').toString('binary');
            fs.writeFile(imagePath, binaryData, "binary", function (err) {
                if (err) {
                    res.json({
                        code: 402,
                        'message': 'Request could not be processed. Please try again.',
                        data: {}
                    });
                } else {
                    register();
                }
            });
        } else {
            register();
        }

    },

    updateAgencyBySuperAdmin: function (req, res, next) {
        if (req.body.imageFile) {
            var timestamp = Number(new Date()); // current time as number
            var imageFile = req.body.imageFile;
            var filename = +timestamp + '_' + common.randomToken(6) + '.' + 'png';
            var imagePath = "./../client/users/assets/uploads/profile/" + filename;
        }

        function update() {
            User.findOne({
                email: req.body.email,
                _id: {
                    $ne: req.body.user_id._id
                }
            }, function (err, email) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR")
                    })
                } else {
                    if (email) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("Email Id already exist ! Try with different Email.")
                        })
                    } else {
                        var updateData = req.body;
                        if (filename) {
                            updateData.profile_pic = "/assets/uploads/profile/" + filename;
                        }
                        AgencyModel.update({
                            _id: req.body._id
                        }, {
                            $set: updateData
                        }, function (err) {
                            if (err) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: req.body,
                                    message: i18n.__("ERROR")
                                })
                            } else {
                                User.update({
                                    _id: req.body.user_id._id
                                }, {
                                    $set: {
                                        email: req.body.email
                                    }
                                }, function (err) {
                                    if (err) {
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: req.body,
                                            message: i18n.__("ERROR")
                                        })
                                    } else {
                                        res.json({
                                            status: req.config.statusCode.success,
                                            data: req.body,
                                            message: i18n.__("Agency updated succesfully")
                                        });
                                    }
                                })

                            }
                        })
                    }
                }
            });
        }


        if (req.body.imageFile) {
            var base64Data = req.body.imageFile.replace(/^data:image\/png;base64,/, "");
            base64Data += base64Data.replace('+', ' ');
            binaryData = new Buffer(base64Data, 'base64').toString('binary');
            fs.writeFile(imagePath, binaryData, "binary", function (err) {
                if (err) {
                    res.json({
                        code: 402,
                        'message': 'Request could not be processed. Please try again.',
                        data: {}
                    });
                } else {
                    update();
                }
            });
        } else {
            update();
        }
    },


    deleteAgencyBySuperAdmin: function (req, res, next) {
        AgencyModel.findOneAndUpdate({
            _id: req.params.id,
        }, {
            is_deleted: true
        }, {
            new: true
        })
        .then((result) => {
            User.findOneAndUpdate({
                _id: result.user_id
            }, {
                is_deleted: true
            }, {
                new: true
            }).then((userDetails) => {
                res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    message: i18n.__("Agency deleted succesfully")
                });
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });

        })
    },


    getAgencyByIdBySuperAdmin: function(req, res, next) {
        AgencyModel.findById(req.params.id)
            .populate('user_id', 'email')
            .then((result) => {
                if(!result){
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                } else{
                    AgencySubscriptionModel.findOne({agency_id: result._id, status: true})
                    .then((agencySubscriptionData) =>{
                        if(!agencySubscriptionData){
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        } else{
                          res.json({
                                status: req.config.statusCode.success,
                                data: {result, agencySubscriptionData},
                                message: i18n.__("Get agency data succesfully")
                            });  
                        }
                    })
                    
                }
                
            }).catch((err) => {
                //__debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })

            });
    },

    agencyRegistration: function (req, res, next) {
        function sendEmailNotification(obj){
            if(req.config.env == 'dev'){
                var baseUrl = 'http://52.34.207.5084:';
            }
            else if(req.config.env == 'aws'){
                var baseUrl = 'https://www.interpreting.works';
            }else{
                var baseUrl = req.config.email.base_url;
            }
            var options = {
                template: 'completeUserRegistration.html',
                from: 'rahul@yopmail.com',
                repalcement: {
                    "{{user.name}}": obj.agency_name,
                    "{{user.email}}": obj.email,
                    "{{user.url}}": baseUrl + '/#/login/',
                    "{{user.email}}": obj.email,
                    "{{user.password}}": req.body.password,
                    "{{logo_url}}": baseUrl + req.config.email.logo_url,
                    "{{copyright}}": req.config.email.copyright,
                    "{{link.abuse_email}}": req.config.email.abuse_email
                },
                to: obj.email,
                subject: 'Registration Completed Successfully'
            };
            emailSend.smtp.sendMail(options, function (err, response) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                }else{
                    // var text ="You have successfully completed your registration.";
                    // var data = { to: '+919990795913', message: text }
                    // twilioSms.sendSMS(data, function(returnData) {
                    // });
                    res.json({
                        status: req.config.statusCode.success,
                        data: req.body,
                        message: i18n.__('Agency registered successfully.')
                    });
                }
            })
        }

        User.findOne({
            email: req.body.email
        }).then((result) =>{
            if(result){
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("Email Id already exist ! Try with different Email.")
                })
            }else{
                RoleModel.findOne({
                    role:req.config.role_type.AGENCY_ADMIN.name
                })
                .then((roleData) => {
                    bcrypt.genSalt(10, function (err, salt) {
                        bcrypt.hash(req.body.password, salt, function (err, hash) {
                            if (!err) {
                                user = new User();
                                user.email = req.body.email;
                                user.password = hash;
                                user.status=true;
                                user.is_verified=true;
                                user.role_id = roleData._id; 
                                user.is_verification_email_send=true;  
                                user.save()
                                .then((userData) => {
                                    var agency = new AgencyModel(req.body);
                                    agency.status = true;
                                    agency.user_id = userData._id;
                                    agency.save()
                                        .then((agencyData)=>{
                                            SubscriptionModel.findOne({
                                                _id: req.body.subscription_id,
                                                is_deleted: false
                                            })
                                            .then((subscriptionData) => {
                                                stripe.customers.create({
                                                    email: userData.email,
                                                    source: req.body.token
                                                }).then(function(cardSaved) {
                                                    var accountObj = {
                                                        agency_id: agencyData._id,
                                                        card_holder_name : req.body.card_holder_name,
                                                        card_no: cardSaved.sources.data[0].last4,
                                                        brand_name: cardSaved.sources.data[0].brand,
                                                        customer_id: cardSaved.id,
                                                        customer_response: cardSaved,
                                                        token: req.body.token
                                                    }
                                                    var CardRecord = new CardDetailModel(accountObj);
                                                    CardRecord.save(function(err, cardData) {
                                                        if (err) {
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: {},
                                                                message: i18n.__("ERROR")
                                                            })
                                                            // res.json({ code: 402, message: 'Request could not be processed. Please try again.', data: {} });
                                                        } else {
                                                            var invoiceCode = voucher_codes.generate({
                                                                    prefix: "INV",
                                                                    length: 4,
                                                                    count: 1,
                                                                    charset: "0123456789"
                                                                }),
                                                                txt = "Subscription Plan Payment: Plan Name- " + subscriptionData.plan_name;
                                                            stripe.charges.create({
                                                                amount: parseFloat(subscriptionData.amount*100),
                                                                // amount: parseFloat("100.00"), //Amount in cents i.e. 100.00 == $1.00
                                                                currency: 'USD',
                                                                description: txt,
                                                                customer: cardData.customer_id
                                                            }).then(function(cardPayment) {
                                                                var paymentData = {};
                                                                if (cardPayment.status == 'succeeded' || cardPayment.status == 'pending') {
                                                                    paymentData.status = cardPayment.status;
                                                                    paymentData = {
                                                                        agency_id: agencyData._id,
                                                                        subscription_id: subscriptionData._id,
                                                                        card_detail_id: cardData._id,
                                                                        customer_id: cardData.customer_id,
                                                                        total_amount: subscriptionData.amount,
                                                                        card_number: cardData.card_no,
                                                                        card_brand_name: cardData.brand_name,
                                                                        payment_date: moment().format(),
                                                                        stripe_payment_id: cardPayment.id,
                                                                        stripe_response_message: cardPayment.failure_message,
                                                                        stripe_response_code: cardPayment.failure_code,
                                                                        stripe_response_json: cardPayment,
                                                                        payment_unique_id: invoiceCode[0]
                                                                    }

                                                                    var PaymentRecord = new PaymentModel(paymentData);
                                                                    PaymentRecord.save(function(err, paymentData) {
                                                                        if (err) {
                                                                            res.json({
                                                                                status: req.config.statusCode.error,
                                                                                data: {},
                                                                                message: i18n.__("ERROR")
                                                                            })
                                                                            // res.json({ code: 402, message: 'Request could not be processed. Please try again.', data: {} });
                                                                        } else {
                                                                            if(subscriptionData.interval == 'Monthly'){
                                                                                var expiryDate = moment().add(1, 'months').format();
                                                                            } else if (subscriptionData.interval == 'Quarterly'){
                                                                                var expiryDate = moment().add(3, 'months').format();
                                                                            } else if (subscriptionData.interval == 'Half-Yearly'){
                                                                                var expiryDate = moment().add(6, 'months').format();
                                                                            } else{
                                                                                var expiryDate = moment().add(12, 'months').format();
                                                                            }
                                                                            var userPlanObj = {
                                                                                agency_id: agencyData._id,
                                                                                subscription_id: subscriptionData._id,
                                                                                plan_name: subscriptionData.plan_name,
                                                                                plan_duration: subscriptionData.interval,
                                                                                plan_amount: subscriptionData.amount,
                                                                                video_service_charge: subscriptionData.video_service_charge,
                                                                                charge_after_minutes: subscriptionData.charge_after_minutes,
                                                                                booking_limit: subscriptionData.booking_limit,
                                                                                subscription_expiry_date: expiryDate,
                                                                                is_renewable: subscriptionData.is_renewable
                                                                            };
                                                                            var PlanRecord = new AgencySubscriptionModel(userPlanObj);
                                                                            PlanRecord.save(function(err, userPlanData) {
                                                                                if (err) {
                                                                                    res.json({
                                                                                        status: req.config.statusCode.error,
                                                                                        data: {},
                                                                                        message: i18n.__("ERROR")
                                                                                    })
                                                                                } else {
                                                                                    var updatePayment = { 
                                                                                        agency_subscription_id: userPlanData._id
                                                                                    };
                                                                                    PaymentModel.findOneAndUpdate({ _id: paymentData._id }, { $set: updatePayment }, { new: true }, function(err, isPaymentUpdated) {
                                                                                        if (err) {
                                                                                            res.json({
                                                                                                status: req.config.statusCode.error,
                                                                                                data: {},
                                                                                                message: i18n.__("ERROR")
                                                                                            })
                                                                                        } else {
                                                                                        AgencySubscriptionModel.findOneAndUpdate({ _id: userPlanData._id }, { $set: { payment_id: paymentData._id } }, { new: true })
                                                                                        .lean()
                                                                                        .exec(function(err, isPaymentDetailsUpdated) {
                                                                                            if (err) {
                                                                                                res.json({
                                                                                                    status: req.config.statusCode.error,
                                                                                                    data: {},
                                                                                                    message: i18n.__("ERROR")
                                                                                                })
                                                                                            } else {    
                                                                                                var obj = {
                                                                                                    agency_name:agencyData.agency_name,
                                                                                                    email: userData.email,
                                                                                                    result:userData
                                                                                                }
                                                                                                sendEmailNotification(obj);
                                                                                                }
                                                                                            });
                                                                                        }
                                                                                    });
                                                                                    }
                                                                                });
                                                                            }
                                                                 
                                                            });
                                                        } else {
                                                            paymentData.status = 'failed';
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: req.body,
                                                                message: i18n.__("ERROR")
                                                            })
                                                            // res.json({ code: 402, message: constant.messages.transactionFailed, data: {} });
                                                        }
                                                    }).catch(function(err) {
                                                        res.json({
                                                            status: req.config.statusCode.error,
                                                            data: req.body,
                                                            message: i18n.__("ERROR")
                                                        })
                                                                // res.json({ code: 402, message: 'Request could not be processed. Please try again.', data: {} });
                                                            });
                                                        }
                                                    });
                                                }).catch(function(err) {
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: req.body,
                                                        message: i18n.__("ERROR")
                                                    })
                                                    // res.json({ code: 402, message: 'Request could not be processed. Please try again.', data: {} });
                                                });
                                            })
                                        });
                                }).catch((err) => {
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: req.body,
                                        message: i18n.__("ERROR")
                                    })
                                });    
                            }
                        });
                    });   
                })
            }
        })
        
    },

    agencyRegistrationEmailCheck: function (req, res, next) {
        User.findOne({
            email: req.body.email,
            is_deleted:false
        }).then((result) =>{
            if(result){
                res.json({
                    status: req.config.statusCode.success,
                    data: req.body,
                    message: i18n.__("Email Id already exist ! Try with different Email.")
                })
            } else{
                res.json({
                    status: req.config.statusCode.notFound,
                    data: req.body,
                    message: i18n.__("Email Id not found.")
                })
            }
            
        })
        
    },

    changeAgencyStatusBySuperAdmin: function (req, res, next) {
        AgencyModel.findOneAndUpdate({
            _id: req.body.id
        }, {
            status: req.body.status
        }, {
            new: true
        })
        .then((result) => {
            User.findOneAndUpdate({
                _id: result.user_id
            }, {
                status: req.body.status
            }, {
                new: true
            }).then((userDetails) => {
                res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    message: i18n.__('Agency ' + ((req.body.status == true) ? 'activated' : 'deactivated') + ' successfully')
                });
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });

        })
    },

    getCountOfAgency: function(req, res, next) {
        console.log("user id", req.user);
        AgencyModel.findOne({
            _id:req.user.agency_id , 
            is_deleted:false
        }).then((agencyData) => {
            SchedulerModel.find({
                agency_id:agencyData._id,
                is_deleted:false
            }).then((bookingData) => {
                var countBooking = bookingData.length;
                ClientModel.find({
                    agency_id:agencyData._id,
                    is_deleted:false
                }).then((clientData) => {
                    var countClient = clientData.length;
                    InterpreterModel.find({
                        agency_id:agencyData._id,
                        is_deleted:false
                    }).then((interpreterData) => {
                        var countInterpreter = interpreterData.length;
                        res.json({
                            status: req.config.statusCode.success,
                            data: {'countBooking':countBooking, 'countClient':countClient, 'countInterpreter':countInterpreter},
                            message: i18n.__('Get count successfully')
                        });
                    })
                })
            })
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            });
        })

    },

    listComplaintByAgency: function(req, res, next){
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }

        var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.id),
            is_deleted: false
        }

        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        // var searchText = req.body.searchText;
        if (searchText != undefined && searchText != 'undefined') {
            condition.$or = [{
                    'interpreterInfo.first_name': new RegExp(searchText, 'gi')
                },
                {
                    'interpreterInfo.last_name': new RegExp(searchText, 'gi')
                },
                {
                    'bookingInfo.booking_id': new RegExp(searchText, 'gi')
                },
                // {
                //     'booking_id': new RegExp(searchText, 'gi')
                // },
                {
                    'service_title': new RegExp(searchText, 'gi')
                }
            ];
        }

        var aggregateQuery = [{
                $lookup: {
                    from: 'interpreters',
                    localField: "interpreter_id",
                    foreignField: "_id",
                    as: "interpreterInfo"
                }
            },
            {
                $unwind: {
                    path: "$interpreterInfo",
                    preserveNullAndEmptyArrays: true
                }
            },{
                $lookup: {
                    from: 'bookings',
                    localField: "booking_id",
                    foreignField: "_id",
                    as: "bookingInfo"
                }
            }, {
                $unwind: {
                    path: "$bookingInfo",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $match: condition
            },

        ];
        var countQuery = [].concat(aggregateQuery);
        aggregateQuery.push({
            $sort: sorting
        });
        aggregateQuery.push({
            $skip: skip
        });
        aggregateQuery.push({
            $limit: count
        });
        CustomerComplaintModel.aggregate(aggregateQuery).exec(function (err, result) {
            // console.log("RESULT aggregate", result);
            if (err) {
                // console.log("ERRRR1", err);
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                CustomerComplaintModel.aggregate(countQuery).exec(function (err, dataCount) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: [],
                            count: 0,
                            message: i18n.__("ERROR")
                        });
                    } else {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        res.json({
                            status: req.config.statusCode.success,
                            data: result,
                            count: cnt
                        });
                    }
                });
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        })
    },


    getAllBookings: function (req, res, next) {
        Booking.find({is_deleted:false},{booking_id:1}).exec(function(err, bookingData){
            if(err){
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })
            } else{
                res.json({
                    status: req.config.statusCode.success,
                    data: bookingData,
                    message: i18n.__("Get all bookings successfully")
                });
            }
        })
    },

    getAgencyProfileById: function(req, res, next){
        // console.log("getAgencyProfileById", req.user);
        AgencyModel.findById(req.user.agency_id)
            .populate('user_id', 'email')
            .then((result) => {
                res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    message: i18n.__("Get agency data succesfully")
                });
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });
    },

    updateAgencyProfile: function (req, res, next) {
        if (req.body.imageFile) {
            var timestamp = Number(new Date()); // current time as number
            var imageFile = req.body.imageFile;
            var filename = +timestamp + '_' + common.randomToken(6) + '.' + 'png';
            var imagePath = "./../client/users/assets/uploads/profile/" + filename;
        }

        function update() {
            User.findOne({
                email: req.body.email,
                _id: {
                    $ne: req.body.user_id._id
                }
            }, function (err, email) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR")
                    })
                } else {
                    if (email) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("Email Id already exist ! Try with different Email.")
                        })
                    } else {
                        var updateData = req.body;
                        if (filename) {
                            updateData.profile_pic = "/assets/uploads/profile/" + filename;
                        }
                        // console.log("updateData", updateData);
                        AgencyModel.update({
                            _id: req.body._id
                        }, {
                            $set: updateData
                        }, function (err) {
                            if (err) {
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: req.body,
                                    message: i18n.__("ERROR")
                                })
                            } else {
                                User.update({
                                    _id: req.body.user_id._id
                                }, {
                                    $set: {
                                        email: req.body.email
                                    }
                                }, function (err) {
                                    if (err) {
                                        res.json({
                                            status: req.config.statusCode.error,
                                            data: req.body,
                                            message: i18n.__("ERROR")
                                        })
                                    } else {
                                        res.json({
                                            status: req.config.statusCode.success,
                                            data: req.body,
                                            message: i18n.__("Agency profile details updated succesfully")
                                        });
                                    }
                                })

                            }
                        })
                    }
                }
            });
        }


        if (req.body.imageFile) {
            var base64Data = req.body.imageFile.replace(/^data:image\/png;base64,/, "");
            base64Data += base64Data.replace('+', ' ');
            binaryData = new Buffer(base64Data, 'base64').toString('binary');
            fs.writeFile(imagePath, binaryData, "binary", function (err) {
                if (err) {
                    res.json({
                        code: 402,
                        'message': 'Request could not be processed. Please try again.',
                        data: {}
                    });
                } else {
                    update();
                }
            });
        } else {
            update();
        }
    },

    exportToPdfByClientIdInReports: function (req, res, next) {
        var logoUrl = req.config.email.base_url+req.config.email.logo_url;
        var timestamp = Number(new Date());
        Booking.find({agency_id: req.user.id, client_id: req.params.id, is_deleted:false})
            .populate('interpreter_id', 'first_name last_name')
            .populate('client_id', 'first_name last_name')
            .then((result) => {
                // var options = { "height": "10.5in", "width": "20in"};
                var options = { "format": "Letter"};
                var filename = "doc" + timestamp + '_' + common.randomToken(6) +  ".pdf";
                  var path = "./../client/users/assets/uploads/reports/" + filename;

                  var headerHtml = "<!DOCTYPE html><head><meta charset='utf-8' /><meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'/><meta http-equiv='X-UA-Compatible' content='IE=edge' /><meta http-equiv='Content-Type' content='text/html; charset=utf-8'><title>HTML</title></head>"+
                                   "   <body style='float: left; width: 100%; margin: 0px; padding: 0px; height: 100%; font-family: sans-serif,arial; font-size: 11px; color: rgb(85, 85, 85); background: rgb(252, 252, 252) none repeat scroll 0% 0%;'>"+
                                   "    <div style='float: left; width: 100%;  box-sizing: border-box; padding: 20px 5px 0px; overflow: auto; '>"+
                                   "    <div style='float: left; width: 81px;'>"+
                                   "        <img src="+logoUrl+" alt='company logo' style='max-width: 100%; margin-left: 10px; display: block; width: 81px; float: left; '>"+
                                   "    </div>"+
                                   "    <div style='float: right; width: 222px;'>"+
                                   "        <div style='float: left; width: 100%; height: auto; box-sizing: border-box; margin-bottom: 6px; font-size: 15px; color: rgb(51, 51, 51); text-align: left; word-wrap: break-word; '>Language Link Corporation</div>"+
                                   "        <div style='float: left; width: 222px; height: auto; box-sizing: border-box; text-align: left; word-wrap: break-word;'>900 Chapel St. 10th Floor, New Haven, CT 06510</div>"+
                                   "    </div>"+
                                   "    </div>"+
                                   "    <div style='float: left; padding-left:10px; width: 100%; box-sizing: border-box; margin-top: 21px; padding-top: 10px; border-top: 1px solid #eee;'>"+
                                   "    <div style='float: left; font-weight: bold; font-size: 10px;'>Report Name : Booking Per Customer</div>"+
                                   "    <div style='float: right; box-sizing: border-box; padding-right: 10px;  font-size: 10px; font-weight: bold;'>Account Name : "+result[0].client_id.first_name+" "+result[0].client_id.last_name+"</div>"+
                                   "    </div>"+
                                   "    <div style='float: left; width: calc(100% - 10px;);   margin-left:5px; margin-right:5px; box-sizing: border-box; border: 1px solid rgb(204, 204, 204); margin-top: 15px; background: white none repeat scroll 0% 0%;'>"+
                                   "    <div style='float: left; width: 100%; box-shadow: 0px 0px 7px 2px #ddd; min-height: 615px;'>"+
                                   "    <div style='float: left; width: 100%;'>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Booking Id</div>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Service Title</div>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Account Name</div>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Interpreter Name</div>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Booking Date</div>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px; border-right: 0;'>Booking Time</div>"+
                                   "    </div>";

                var footerHtml =   "    </div>"+
                                   "    </div>"+
                                   "    </div>"+
                                   "    <div style='float: left; position: fixed: bottom: 0; width: 100%; background: #eee; box-sizing: border-box; padding: 4px 0px;'>"+
                                   "    <div style='font-style: italic; width: 100%; max-width: 1200px; text-align: center; float: none; margin: 0px auto; box-sizing: border-box; padding-right: 5px;'>All Rights Reserved &copy; Language Link Corporation</div>"+
                                   "    </div>"+
                                   "    </body>"+
                                   "    </html>";

                  var html = "";

                  async.eachSeries(result, function(resultOne, next){
                            html += "<div style='width: 100%; position: relative; height: 100%; float: left; border-bottom: 1px solid #ccc;'>"+
                                   "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.booking_id+"</div>"+
                                   "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.service_title+"</div>"+
                                   "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.client_id.first_name+" "+resultOne.client_id.last_name+"</div>"+
                                   "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.interpreter_id.first_name+" "+resultOne.interpreter_id.last_name+"</div>"+
                                   "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+moment(resultOne.booking_from).format("DD/MMM/YYYY")+" - "+moment(resultOne.booking_from).format("DD/MMM/YYYY")+"</div>"+
                                   "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.working_from+" - "+resultOne.working_to+"</div>"+
                                   "</div>";
                           var finalHtml = headerHtml+html+footerHtml;
                             pdf.create(finalHtml, options).toFile(path, function(err, data) {
                            if(err){
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: req.body,
                                    message: i18n.__("ERROR")
                                })
                            } else{
                                next();
                            } 
                          });
                             
                    },function(err){
                      if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })
                      }else{
                        res.json({
                            status: req.config.statusCode.success,
                            data: path,
                            message: i18n.__("Get file path successfully")
                        });
                      }
                    })
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("No record found.")
                })

            });
    },

    exportToPdfByLanguageInReport: function (req, res, next) {
        var logoUrl = req.config.email.base_url+req.config.email.logo_url;
        var timestamp = Number(new Date());
        Booking.find({agency_id: req.user.id, language_id: req.params.language, is_deleted:false})
            .populate('interpreter_id', 'first_name last_name')
            .populate('client_id', 'first_name last_name')
            .populate('language_id', 'language_name')
            .then((result) => {
                var languageName = result[0].language_id.language_name.charAt(0).toUpperCase()+result[0].language_id.language_name.slice(1).toLowerCase();
                var options = { "format": "Letter"};
                var filename = "doc" + timestamp + '_' + common.randomToken(6) +  ".pdf";
                  var path = "./../client/users/assets/uploads/reports/" + filename;

                  var headerHtml = "<!DOCTYPE html><head><meta charset='utf-8' /><meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'/><meta http-equiv='X-UA-Compatible' content='IE=edge' /><meta http-equiv='Content-Type' content='text/html; charset=utf-8'><title>HTML</title></head>"+
                                   "   <body style='float: left; width: 100%; margin: 0px; padding: 0px; height: 100%; font-family: sans-serif,arial; font-size: 11px; color: rgb(85, 85, 85); background: rgb(252, 252, 252) none repeat scroll 0% 0%;'>"+
                                   "    <div style='float: left; width: 100%;  box-sizing: border-box; padding: 20px 5px 0px; overflow: auto; '>"+
                                   "    <div style='float: left; width: 81px;'>"+
                                   "        <img src="+logoUrl+" alt='company logo' style='max-width: 100%; margin-left: 10px; display: block; width: 81px; float: left; '>"+
                                   "    </div>"+
                                   "    <div style='float: right; width: 222px;'>"+
                                   "        <div style='float: left; width: 100%; height: auto; box-sizing: border-box; margin-bottom: 6px; font-size: 15px; color: rgb(51, 51, 51); text-align: left; word-wrap: break-word; '>Language Link Corporation</div>"+
                                   "        <div style='float: left; width: 222px; height: auto; box-sizing: border-box; text-align: left; word-wrap: break-word;'>900 Chapel St. 10th Floor, New Haven, CT 06510</div>"+
                                   "    </div>"+
                                   "    </div>"+
                                   "    <div style='float: left; padding-left:10px; width: 100%; box-sizing: border-box; margin-top: 21px; padding-top: 10px; border-top: 1px solid #eee;'>"+
                                   "    <div style='float: left; font-weight: bold; font-size: 10px;'>Report Name : Booking Per Language</div>"+
                                   "    <div style='float: right; box-sizing: border-box; padding-right: 10px;  font-size: 10px; font-weight: bold;'>Language Name : "+languageName+"</div>"+
                                   "    </div>"+
                                   "    <div style='float: left; width: calc(100% - 10px;);   margin-left:5px; margin-right:5px; box-sizing: border-box; border: 1px solid rgb(204, 204, 204); margin-top: 15px; background: white none repeat scroll 0% 0%;'>"+
                                   "    <div style='float: left; width: 100%; box-shadow: 0px 0px 7px 2px #ddd; min-height: 615px;'>"+
                                   "    <div style='float: left; width: 100%;'>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Booking Id</div>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Service Title</div>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Account Name</div>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Interpreter Name</div>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Booking Date</div>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 16.66%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px; border-right: 0;'>Booking Time</div>"+
                                   "    </div>";

                var footerHtml =   "    </div>"+
                                   "    </div>"+
                                   "    </div>"+
                                   "    <div style='float: left; position: fixed: bottom: 0; width: 100%; background: #eee; box-sizing: border-box; padding: 4px 0px;'>"+
                                   "    <div style='font-style: italic; width: 100%; max-width: 1200px; text-align: center; float: none; margin: 0px auto; box-sizing: border-box; padding-right: 5px;'>All Rights Reserved &copy; Language Link Corporation</div>"+
                                   "    </div>"+
                                   "    </body>"+
                                   "    </html>";
                  var html = "";
                  async.eachSeries(result, function(resultOne, next){
                            html += "<div style='width: 100%; position: relative; height: 100%; float: left; border-bottom: 1px solid #ccc;'>"+
                                   "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.booking_id+"</div>"+
                                   "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.service_title+"</div>"+
                                   "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.client_id.first_name+" "+resultOne.client_id.last_name+"</div>"+
                                   "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.interpreter_id.first_name+" "+resultOne.interpreter_id.last_name+"</div>"+
                                   "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+moment(resultOne.booking_from).format("DD/MMM/YYYY")+" - "+moment(resultOne.booking_from).format("DD/MMM/YYYY")+"</div>"+
                                   "<div style='box-sizing: border-box; width: 16.66%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.working_from+" - "+resultOne.working_to+"</div>"+
                                   "</div>";
                            
                            var finalHtml = headerHtml+html+footerHtml;
                             pdf.create(finalHtml, options).toFile(path, function(err, data) {
                            if(err){
                                res.json({
                                    status: req.config.statusCode.error,
                                    data: req.body,
                                    message: i18n.__("ERROR")
                                })
                            } else{
                                next();    
                            }
                          });
                    },function(err){
                      if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })
                      }else{
                        res.json({
                            status: req.config.statusCode.success,
                            data: path,
                            message: i18n.__("Get file path successfully")
                        });
                      }
                    })
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("No record found.")
                })

            });
    },

    exportToPdfForTopTenCustomers: function (req, res, next) {
         var condition = {
            agency_id: mongoose.Types.ObjectId(req.user.id), 
            is_deleted: false
         }
        var aggregate = [{
                $lookup: {
                    from: 'clients',
                    localField: "client_id",
                    foreignField: "_id",
                    as: "clientInfo"
                }
            },
            { $unwind: "$clientInfo"},
            { 
                $match: condition
            }, {
                $lookup: {
                    from: 'users',
                    localField: "clientInfo.user_id",
                    foreignField: "_id",
                    as: "userInfo"
                }
            }, { $unwind: '$userInfo' },
            {
                $group: {
                    _id: '$clientInfo._id',
                    count: { "$sum": 1},
                    first_name: { $first : "$clientInfo.first_name"},
                    last_name: { $first : "$clientInfo.last_name"},
                    client_shortid: { $first : "$clientInfo.client_shortid"},
                    mobile_no: { $first : "$clientInfo.mobile_no"},
                    email: { $first : "$userInfo.email"}
                }
            
            },{
                $sort : {count: -1}
            },{
                $limit: 10
            }
        ];

        Booking.aggregate(aggregate).exec(function (err, result) {
            var logoUrl = req.config.email.base_url+req.config.email.logo_url;
            var timestamp = Number(new Date());
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: [],
                    count: 0,
                    message: i18n.__("ERROR")
                });
            } else {
                var options = { "format": "Letter"};
                var filename = "doc" + timestamp + '_' + common.randomToken(6) +  ".pdf";
                var path = "./../client/users/assets/uploads/reports/" + filename;
                var headerHtml = "<!DOCTYPE html><head><meta charset='utf-8' /><meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'/><meta http-equiv='X-UA-Compatible' content='IE=edge' /><meta http-equiv='Content-Type' content='text/html; charset=utf-8'><title>HTML</title></head>"+
                                   "   <body style='float: left; width: 100%; margin: 0px; padding: 0px; height: 100%; font-family: sans-serif,arial; font-size: 11px; color: rgb(85, 85, 85); background: rgb(252, 252, 252) none repeat scroll 0% 0%;'>"+
                                   "    <div style='float: left; width: 100%;  box-sizing: border-box; padding: 20px 5px 0px; overflow: auto; '>"+
                                   "    <div style='float: left; width: 81px;'>"+
                                   "        <img src="+logoUrl+" alt='company logo' style='max-width: 100%; margin-left: 10px; display: block; width: 81px; float: left; '>"+
                                   "    </div>"+
                                   "    <div style='float: right; width: 222px;'>"+
                                   "        <div style='float: left; width: 100%; height: auto; box-sizing: border-box; margin-bottom: 6px; font-size: 15px; color: rgb(51, 51, 51); text-align: left; word-wrap: break-word; '>Language Link Corporation</div>"+
                                   "        <div style='float: left; width: 222px; height: auto; box-sizing: border-box; text-align: left; word-wrap: break-word;'>900 Chapel St. 10th Floor, New Haven, CT 06510</div>"+
                                   "    </div>"+
                                   "    </div>"+
                                   "    <div style='float: left; padding-left:10px; width: 100%; box-sizing: border-box; margin-top: 21px; padding-top: 10px; border-top: 1px solid #eee;'>"+
                                   "    <div style='float: left; font-weight: bold; font-size: 10px;'>Report Name : Top 10 Account</div>"+
                                   "    </div>"+
                                   "    <div style='float: left; width: calc(100% - 10px;);   margin-left:5px; margin-right:5px; box-sizing: border-box; border: 1px solid rgb(204, 204, 204); margin-top: 15px; background: white none repeat scroll 0% 0%;'>"+
                                   "    <div style='float: left; width: 100%; box-shadow: 0px 0px 7px 2px #ddd; min-height: 615px;'>"+
                                   "    <div style='float: left; width: 100%;'>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 20%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Account Id</div>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 20%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Account Name</div>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 20%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>No of Bookings</div>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 20%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;'>Mobile No</div>"+
                                   "    <div style='float: left; padding: 5px; box-sizing: border-box; border-right: 1px solid #ccc; width: 20%; border-bottom: 1px solid #ccc; font-weight: bold; font-size: 9px;border-right: 0;'>Email</div>"+
                                   "    </div>";

                var footerHtml =   "    </div>"+
                                   "    </div>"+
                                   "    </div>"+
                                   "    <div style='float: left; position: fixed: bottom: 0; width: 100%; background: #eee; box-sizing: border-box; padding: 4px 0px;'>"+
                                   "    <div style='font-style: italic; width: 100%; max-width: 1200px; text-align: center; float: none; margin: 0px auto; box-sizing: border-box; padding-right: 5px;'>All Rights Reserved &copy; Language Link Corporation</div>"+
                                   "    </div>"+
                                   "    </body>"+
                                   "    </html>";
                  var html = "";
                  async.eachSeries(result,function(resultOne,next){
                    html += "<div style='width: 100%; position: relative; height: 100%; float: left; border-bottom: 1px solid #ccc;'>"+
                           "<div style='box-sizing: border-box; width: 20%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.client_shortid+"</div>"+
                           "<div style='box-sizing: border-box; width: 20%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.first_name+" "+resultOne.last_name+"</div>"+
                           "<div style='box-sizing: border-box; width: 20%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.count+"</div>"+
                           "<div style='box-sizing: border-box; width: 20%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.mobile_no+"</div>"+
                           "<div style='box-sizing: border-box; width: 20%; word-wrap: break-word; float: left; padding: 5px; font-size: 9px;'>"+resultOne.email+"</div>"+
                           "</div>";
                    var finalHtml = headerHtml+html+footerHtml;
                    pdf.create(finalHtml, options).toFile(path, function(err, data) {
                        if(err){
                            res.json({
                                status: req.config.statusCode.error,
                                data: req.body,
                                message: i18n.__("ERROR")
                            })
                        }else{
                            next();
                        } 
                      });              
                },function(err){
                    if(err){
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })
                    }else{
                        res.json({
                            status: req.config.statusCode.success,
                            data: path,
                            message: i18n.__("Get file path successfully")
                        });
                    }
                })
            }
        }).catch(function (err) {
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("No record found.")
            });
        })
    },

    getLanguageNameByLanguageIdInReport: function(req, res, next){
        LanguageModel.findOne({_id: req.params.id, is_deleted:false})
        .then((languageData)=>{
            if(languageData){
                res.json({
                    status: req.config.statusCode.success,
                    data: languageData,
                    message: i18n.__('Get language name successfully')
                });
            }else{
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })    
            }
        }).catch((err) => {
            res.json({
                status: req.config.statusCode.error,
                data: req.body,
                message: i18n.__("ERROR")
            })

        });
    },


    listAgencySuperAdmin: function (req, res, next) {
        AgencyModel.find({status: true, is_deleted: false},{'agency_name':1})
            .then((result) => {
                if(result){
                    res.json({
                        status: req.config.statusCode.success,
                        data: result,
                        message: i18n.__("Get agencies succesfully")
                    });
                }else{
                    res.json({
                        status: req.config.statusCode.error,
                        data: req.body,
                        message: i18n.__("ERROR")
                    })    
                }
                
            }).catch((err) => {
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });
    },

    agencySubscriptionActivateSuperAdmin: function (req, res, next) {
        function sendEmailNotification(obj){
                if(req.config.env == 'dev'){
                    var baseUrl = 'http://52.34.207.5084:';
                }
                else if(req.config.env == 'aws'){
                    var baseUrl = 'https://www.interpreting.works';
                }else{
                    var baseUrl = req.config.email.base_url;
                }
                var options = {
                    template: 'completeUserRegistration.html',
                    from: 'rahul@yopmail.com',
                    repalcement: {
                        "{{user.name}}": obj.agency_name,
                        "{{user.email}}": obj.email,
                        "{{user.url}}": baseUrl + '/#/login/',
                        "{{user.email}}": obj.email,
                        "{{user.password}}": req.body.password,
                        "{{logo_url}}": baseUrl + req.config.email.logo_url,
                        "{{copyright}}": req.config.email.copyright,
                        "{{link.abuse_email}}": req.config.email.abuse_email
                    },
                    to: obj.email,
                    subject: 'Registration Completed Successfully'
                };
                emailSend.smtp.sendMail(options, function (err, response) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })
                    }else{
                        // var text ="You have successfully completed your registration.";
                        // var data = { to: '+919990795913', message: text }
                        // twilioSms.sendSMS(data, function(returnData) {
                        // });
                        res.json({
                            status: req.config.statusCode.success,
                            data: obj.result,
                            message: i18n.__("Agency activated and select subscription plan successfully.")
                        });
                    }
                })
        }

        bcrypt.genSalt(10, function (err, salt) {
            bcrypt.hash(req.body.password, salt, function (err, hash) {
                if (!err) {
                    var userRecord = {
                        password: hash,
                        status: true,
                        is_verified: true,
                        is_verification_email_send:true,
                        activation_key: ''
                    }

                    User.findOneAndUpdate({ _id: req.body.user_id }, { $set: userRecord }, { new: true }, function(err, isUserUpdated) {
                        if (err) {
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        } else {
                            var agencyRecord = {
                                status : true,
                                user_id : isUserUpdated._id    
                            }
                            AgencyModel.findOneAndUpdate({ _id: req.body._id }, { $set: agencyRecord }, { new: true }, function(err, isAgencyUpdated) {
                                if (err) {
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("ERROR")
                                    })
                                } else {
                                    SubscriptionModel.findOne({
                                        _id: req.body.subscription_id,
                                        is_deleted: false
                                    })
                                    .then((subscriptionData) => {
                                        stripe.customers.create({
                                            email: isUserUpdated.email,
                                            source: req.body.token
                                        }).then(function(cardSaved) {
                                            var accountObj = {
                                                agency_id: isAgencyUpdated._id,
                                                card_holder_name : req.body.card_holder_name,
                                                card_no: cardSaved.sources.data[0].last4,
                                                brand_name: cardSaved.sources.data[0].brand,
                                                customer_id: cardSaved.id,
                                                customer_response: cardSaved,
                                                token: req.body.token
                                            }
                                            var CardRecord = new CardDetailModel(accountObj);
                                            CardRecord.save(function(err, cardData) {
                                                if (err) {
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: {},
                                                        message: i18n.__("ERROR")
                                                    })
                                                } else {
                                                    var invoiceCode = voucher_codes.generate({
                                                        prefix: "INV",
                                                        length: 4,
                                                        count: 1,
                                                        charset: "0123456789"
                                                    }),
                                                    txt = "Subscription Plan Payment: Plan Name- " + subscriptionData.plan_name;
                                                    stripe.charges.create({
                                                        amount: parseFloat(subscriptionData.amount*100),
                                                        // amount: parseFloat("100.00"), //Amount in cents i.e. 100.00 == $1.00
                                                        currency: 'USD',
                                                        description: txt,
                                                        customer: cardData.customer_id
                                                    }).then(function(cardPayment) {
                                                        var paymentData = {};
                                                        if (cardPayment.status == 'succeeded' || cardPayment.status == 'pending') {
                                                            paymentData.status = cardPayment.status;
                                                            paymentData = {
                                                                agency_id: isAgencyUpdated._id,
                                                                subscription_id: subscriptionData._id,
                                                                card_detail_id: cardData._id,
                                                                customer_id: cardData.customer_id,
                                                                total_amount: subscriptionData.amount,
                                                                card_number: cardData.card_no,
                                                                card_brand_name: cardData.brand_name,
                                                                payment_date: moment().format(),
                                                                stripe_payment_id: cardPayment.id,
                                                                stripe_response_message: cardPayment.failure_message,
                                                                stripe_response_code: cardPayment.failure_code,
                                                                stripe_response_json: cardPayment,
                                                                payment_unique_id: invoiceCode[0]
                                                            }

                                                            var PaymentRecord = new PaymentModel(paymentData);
                                                            PaymentRecord.save(function(err, paymentData) {
                                                                if (err) {
                                                                    res.json({
                                                                        status: req.config.statusCode.error,
                                                                        data: {},
                                                                        message: i18n.__("ERROR")
                                                                    })
                                                                } else {
                                                                    if(subscriptionData.interval == 'Monthly'){
                                                                        var expiryDate = moment().add(1, 'months').format();
                                                                    } else if (subscriptionData.interval == 'Quarterly'){
                                                                        var expiryDate = moment().add(3, 'months').format();
                                                                    } else if (subscriptionData.interval == 'Half-Yearly'){
                                                                        var expiryDate = moment().add(6, 'months').format();
                                                                    } else{
                                                                        var expiryDate = moment().add(12, 'months').format();
                                                                    }
                                                                    var userPlanObj = {
                                                                        agency_id: isAgencyUpdated._id,
                                                                        subscription_id: subscriptionData._id,
                                                                        plan_name: subscriptionData.plan_name,
                                                                        plan_duration: subscriptionData.interval,
                                                                        plan_amount: subscriptionData.amount,
                                                                        video_service_charge: subscriptionData.video_service_charge,
                                                                        charge_after_minutes: subscriptionData.charge_after_minutes,
                                                                        booking_limit: subscriptionData.booking_limit,
                                                                        subscription_expiry_date: expiryDate,
                                                                        is_renewable: subscriptionData.is_renewable
                                                                    };
                                                                    var PlanRecord = new AgencySubscriptionModel(userPlanObj);
                                                                    PlanRecord.save(function(err, userPlanData) {
                                                                        if (err) {
                                                                            res.json({
                                                                                status: req.config.statusCode.error,
                                                                                data: {},
                                                                                message: i18n.__("ERROR")
                                                                            })
                                                                        } else {
                                                                            var updatePayment = { 
                                                                                agency_subscription_id: userPlanData._id
                                                                            };
                                                                            PaymentModel.findOneAndUpdate({ _id: paymentData._id }, { $set: updatePayment }, { new: true }, function(err, isPaymentUpdated) {
                                                                                if (err) {
                                                                                    res.json({
                                                                                        status: req.config.statusCode.error,
                                                                                        data: {},
                                                                                        message: i18n.__("ERROR")
                                                                                    })
                                                                                } else {
                                                                                    AgencySubscriptionModel.findOneAndUpdate({ _id: userPlanData._id }, { $set: { payment_id: paymentData._id } }, { new: true })
                                                                                    .lean()
                                                                                    .exec(function(err, isPaymentDetailsUpdated) {
                                                                                        if (err) {
                                                                                            res.json({
                                                                                                status: req.config.statusCode.error,
                                                                                                data: {},
                                                                                                message: i18n.__("ERROR")
                                                                                            })
                                                                                        } else {   
                                                                                            var obj = {
                                                                                                agency_name:isAgencyUpdated.agency_name,
                                                                                                email: isUserUpdated.email,
                                                                                                result:isUserUpdated
                                                                                            }
                                                                                            sendEmailNotification(obj);
                                                                                        }
                                                                                    });
                                                                                }
                                                                            });
                                                                        }
                                                                    });
                                                                }    
                                                            });
                                                        } else {
                                                            paymentData.status = 'failed';
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: {},
                                                                message: i18n.__("ERROR")
                                                            })
                                                        }
                                                    })
                                                }
                                            });
                                        })
                                    })
                                }
                            })          
                        }
                    })  
                }
            });
        });
    },

    activateAgencyWithSubscription: function (req, res, next) {
        function sendEmailNotification(obj){
                if(req.config.env == 'dev'){
                    var baseUrl = 'http://52.34.207.5084:';
                }
                else if(req.config.env == 'aws'){
                    var baseUrl = 'https://www.interpreting.works';
                }else{
                    var baseUrl = req.config.email.base_url;
                }
                var options = {
                    template: 'completeUserRegistration.html',
                    from: 'rahul@yopmail.com',
                    repalcement: {
                        "{{user.name}}": obj.agency_name,
                        "{{user.email}}": obj.email,
                        "{{user.url}}": baseUrl + '/#/login/',
                        "{{user.email}}": obj.email,
                        "{{user.password}}": req.body.password,
                        "{{logo_url}}": baseUrl + req.config.email.logo_url,
                        "{{copyright}}": req.config.email.copyright,
                        "{{link.abuse_email}}": req.config.email.abuse_email
                    },
                    to: obj.email,
                    subject: 'Registration Completed Successfully'
                };
                emailSend.smtp.sendMail(options, function (err, response) {
                    if (err) {
                        res.json({
                            status: req.config.statusCode.error,
                            data: req.body,
                            message: i18n.__("ERROR")
                        })
                    }else{
                        // var text ="You have successfully completed your registration.";
                        // var data = { to: '+919990795913', message: text }
                        // twilioSms.sendSMS(data, function(returnData) {
                        // });
                        res.json({
                            status: req.config.statusCode.success,
                            data: obj.result,
                            message: i18n.__("Agency activated and select subscription plan successfully.")
                        });
                    }
                })
        }

        bcrypt.genSalt(10, function (err, salt) {
            bcrypt.hash(req.body.password, salt, function (err, hash) {
                if (!err) {
                    var userRecord = {
                        password: hash,
                        status: true,
                        is_verified: true,
                        is_verification_email_send:true,
                        activation_key: ''
                    }

                    User.findOneAndUpdate({ _id: req.body._id }, { $set: userRecord }, { new: true }, function(err, isUserUpdated) {
                        if (err) {
                            res.json({
                                status: req.config.statusCode.error,
                                data: {},
                                message: i18n.__("ERROR")
                            })
                        } else {
                            var agencyRecord = {
                                status : true,
                                user_id : isUserUpdated._id    
                            }
                            AgencyModel.findOneAndUpdate({ user_id: req.body._id }, { $set: agencyRecord }, { new: true }, function(err, isAgencyUpdated) {
                                if (err) {
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("ERROR")
                                    })
                                } else {
                                    SubscriptionModel.findOne({
                                        _id: req.body.subscription_id,
                                        is_deleted: false
                                    })
                                    .then((subscriptionData) => {
                                        stripe.customers.create({
                                            email: isUserUpdated.email,
                                            source: req.body.token
                                        }).then(function(cardSaved) {
                                            var accountObj = {
                                                agency_id: isAgencyUpdated._id,
                                                card_holder_name : req.body.card_holder_name,
                                                card_no: cardSaved.sources.data[0].last4,
                                                brand_name: cardSaved.sources.data[0].brand,
                                                customer_id: cardSaved.id,
                                                customer_response: cardSaved,
                                                token: req.body.token
                                            }
                                            var CardRecord = new CardDetailModel(accountObj);
                                            CardRecord.save(function(err, cardData) {
                                                if (err) {
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: {},
                                                        message: i18n.__("ERROR")
                                                    })
                                                } else {
                                                    var invoiceCode = voucher_codes.generate({
                                                        prefix: "INV",
                                                        length: 4,
                                                        count: 1,
                                                        charset: "0123456789"
                                                    }),
                                                    txt = "Subscription Plan Payment: Plan Name- " + subscriptionData.plan_name;
                                                    stripe.charges.create({
                                                        amount: parseFloat(subscriptionData.amount*100),
                                                        // amount: parseFloat("100.00"), //Amount in cents i.e. 100.00 == $1.00
                                                        currency: 'USD',
                                                        description: txt,
                                                        customer: cardData.customer_id
                                                    }).then(function(cardPayment) {
                                                        var paymentData = {};
                                                        if (cardPayment.status == 'succeeded' || cardPayment.status == 'pending') {
                                                            paymentData.status = cardPayment.status;
                                                            paymentData = {
                                                                agency_id: isAgencyUpdated._id,
                                                                subscription_id: subscriptionData._id,
                                                                card_detail_id: cardData._id,
                                                                customer_id: cardData.customer_id,
                                                                total_amount: subscriptionData.amount,
                                                                card_number: cardData.card_no,
                                                                card_brand_name: cardData.brand_name,
                                                                payment_date: moment().format(),
                                                                stripe_payment_id: cardPayment.id,
                                                                stripe_response_message: cardPayment.failure_message,
                                                                stripe_response_code: cardPayment.failure_code,
                                                                stripe_response_json: cardPayment,
                                                                payment_unique_id: invoiceCode[0]
                                                            }

                                                            var PaymentRecord = new PaymentModel(paymentData);
                                                            PaymentRecord.save(function(err, paymentData) {
                                                                if (err) {
                                                                    res.json({
                                                                        status: req.config.statusCode.error,
                                                                        data: {},
                                                                        message: i18n.__("ERROR")
                                                                    })
                                                                } else {
                                                                    if(subscriptionData.interval == 'Monthly'){
                                                                        var expiryDate = moment().add(1, 'months').format();
                                                                    } else if (subscriptionData.interval == 'Quarterly'){
                                                                        var expiryDate = moment().add(3, 'months').format();
                                                                    } else if (subscriptionData.interval == 'Half-Yearly'){
                                                                        var expiryDate = moment().add(6, 'months').format();
                                                                    } else{
                                                                        var expiryDate = moment().add(12, 'months').format();
                                                                    }
                                                                    var userPlanObj = {
                                                                        agency_id: isAgencyUpdated._id,
                                                                        subscription_id: subscriptionData._id,
                                                                        plan_name: subscriptionData.plan_name,
                                                                        plan_duration: subscriptionData.interval,
                                                                        plan_amount: subscriptionData.amount,
                                                                        video_service_charge: subscriptionData.video_service_charge,
                                                                        charge_after_minutes: subscriptionData.charge_after_minutes,
                                                                        booking_limit: subscriptionData.booking_limit,
                                                                        subscription_expiry_date: expiryDate,
                                                                        is_renewable: subscriptionData.is_renewable
                                                                    };
                                                                    var PlanRecord = new AgencySubscriptionModel(userPlanObj);
                                                                    PlanRecord.save(function(err, userPlanData) {
                                                                        if (err) {
                                                                            res.json({
                                                                                status: req.config.statusCode.error,
                                                                                data: {},
                                                                                message: i18n.__("ERROR")
                                                                            })
                                                                        } else {
                                                                            var updatePayment = { 
                                                                                agency_subscription_id: userPlanData._id
                                                                            };
                                                                            PaymentModel.findOneAndUpdate({ _id: paymentData._id }, { $set: updatePayment }, { new: true }, function(err, isPaymentUpdated) {
                                                                                if (err) {
                                                                                    res.json({
                                                                                        status: req.config.statusCode.error,
                                                                                        data: {},
                                                                                        message: i18n.__("ERROR")
                                                                                    })
                                                                                } else {
                                                                                    AgencySubscriptionModel.findOneAndUpdate({ _id: userPlanData._id }, { $set: { payment_id: paymentData._id } }, { new: true })
                                                                                    .lean()
                                                                                    .exec(function(err, isPaymentDetailsUpdated) {
                                                                                        if (err) {
                                                                                            res.json({
                                                                                                status: req.config.statusCode.error,
                                                                                                data: {},
                                                                                                message: i18n.__("ERROR")
                                                                                            })
                                                                                        } else {   
                                                                                            var obj = {
                                                                                                agency_name:isAgencyUpdated.agency_name,
                                                                                                email: isUserUpdated.email,
                                                                                                result:isUserUpdated
                                                                                            }
                                                                                            sendEmailNotification(obj);
                                                                                        }
                                                                                    });
                                                                                }
                                                                            });
                                                                        }
                                                                    });
                                                                }    
                                                            });
                                                        } else {
                                                            paymentData.status = 'failed';
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: {},
                                                                message: i18n.__("ERROR")
                                                            })
                                                        }
                                                    })
                                                }
                                            });
                                        })
                                    })
                                }
                            })          
                        }
                    })  
                }
            });
        });
    },

    upgradeSubscriptionPlan: function(req, res, next){
        function sendEmailNotification(obj){
            if(req.config.env == 'dev'){
                var baseUrl = 'http://52.34.207.5084:';
            }
            else if(req.config.env == 'aws'){
                var baseUrl = 'https://www.interpreting.works';
            }else{
                var baseUrl = req.config.email.base_url;
            }
            var options = {
                template: 'upgradeSubscriptionPlan.html',
                from: 'rahul@yopmail.com',
                repalcement: {
                    "{{user.name}}": obj.agency_name,
                    "{{user.invoice_id}}": obj.invoice_id,
                    "{{user.subscription_plan_name}}": obj.subscription_plan_name,
                    "{{user.amount}}": obj.amount,
                    "{{user.subscription_start_date}}": obj.subscription_start_date,
                    "{{user.subscription_expiry_date}}": obj.subscription_expiry_date,
                    "{{logo_url}}": baseUrl + req.config.email.logo_url,
                    "{{copyright}}": req.config.email.copyright,
                    "{{link.abuse_email}}": req.config.email.abuse_email
                },
                to: obj.email,
                subject: 'Subscription Plan Upgraded Successfully'
            };
            emailSend.smtp.sendMail(options, function (err, response) {
                if (err) {
                    res.json({
                        status: req.config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                }else{
                    // var text ="You have successfully completed your registration.";
                    // var data = { to: '+919990795913', message: text }
                    // twilioSms.sendSMS(data, function(returnData) {
                    // });
                    res.json({
                        status: req.config.statusCode.success,
                        data: req.body,
                        message: i18n.__('Subscription plan upgraded successfully.')
                    });
                }
            })
        }
        // console.log("req.body------------------>", req.body);
        User.findOne({_id:req.body.user_id, is_deleted:false}, function(err, userData) {
            if (err) {
                res.json({
                    status: req.config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            } else {
                SubscriptionModel.findOne({
                        _id: req.body.subscription_id,
                        is_deleted: false
                    })
                    .then((subscriptionData) => {
                        stripe.customers.create({
                            email: userData.email, //finout the email
                            source: req.body.token
                        }).then(function(cardSaved) {
                            var accountObj = {
                                agency_id: req.body._id, //req.body.agency_id
                                card_holder_name: req.body.card_holder_name,
                                card_no: cardSaved.sources.data[0].last4,
                                brand_name: cardSaved.sources.data[0].brand,
                                customer_id: cardSaved.id,
                                customer_response: cardSaved,
                                token: req.body.token
                            }
                            var CardRecord = new CardDetailModel(accountObj);
                            CardRecord.save(function(err, cardData) {
                                if (err) {
                                    res.json({
                                        status: req.config.statusCode.error,
                                        data: {},
                                        message: i18n.__("ERROR")
                                    })
                                } else {
                                    var invoiceCode = voucher_codes.generate({
                                            prefix: "INV",
                                            length: 4,
                                            count: 1,
                                            charset: "0123456789"
                                        }),
                                        txt = "Upgrade Subscription Plan Payment: Plan Name- " + subscriptionData.plan_name;
                                    stripe.charges.create({
                                        amount: parseFloat(subscriptionData.amount * 100),
                                        // amount: parseFloat("100.00"), //Amount in cents i.e. 100.00 == $1.00
                                        currency: 'USD',
                                        description: txt,
                                        customer: cardData.customer_id
                                    }).then(function(cardPayment) {
                                        var paymentData = {};
                                        if (cardPayment.status == 'succeeded' || cardPayment.status == 'pending') {
                                            paymentData.status = cardPayment.status;
                                            paymentData = {
                                                agency_id: req.body._id,
                                                subscription_id: subscriptionData._id,
                                                card_detail_id: cardData._id,
                                                customer_id: cardData.customer_id,
                                                total_amount: subscriptionData.amount,
                                                card_number: cardData.card_no,
                                                card_brand_name: cardData.brand_name,
                                                payment_date: moment().format(),
                                                stripe_payment_id: cardPayment.id,
                                                stripe_response_message: cardPayment.failure_message,
                                                stripe_response_code: cardPayment.failure_code,
                                                stripe_response_json: cardPayment,
                                                payment_unique_id: invoiceCode[0]
                                            }

                                            var PaymentRecord = new PaymentModel(paymentData);
                                            PaymentRecord.save(function(err, paymentData) {
                                                if (err) {
                                                    res.json({
                                                        status: req.config.statusCode.error,
                                                        data: {},
                                                        message: i18n.__("ERROR")
                                                    })
                                                } else {
                                                    if (subscriptionData.interval == 'Monthly') {
                                                        var expiryDate = moment().add(1, 'months').format();
                                                    } else if (subscriptionData.interval == 'Quarterly') {
                                                        var expiryDate = moment().add(3, 'months').format();
                                                    } else if (subscriptionData.interval == 'Half-Yearly') {
                                                        var expiryDate = moment().add(6, 'months').format();
                                                    } else {
                                                        var expiryDate = moment().add(12, 'months').format();
                                                    }
                                                    var userPlanObj = {
                                                        agency_id: req.body._id,
                                                        subscription_id: subscriptionData._id,
                                                        plan_name: subscriptionData.plan_name,
                                                        plan_duration: subscriptionData.interval,
                                                        plan_amount: subscriptionData.amount,
                                                        video_service_charge: subscriptionData.video_service_charge,
                                                        charge_after_minutes: subscriptionData.charge_after_minutes,
                                                        booking_limit: subscriptionData.booking_limit,
                                                        subscription_expiry_date: expiryDate,
                                                        is_renewable: subscriptionData.is_renewable
                                                    };
                                                    var PlanRecord = new AgencySubscriptionModel(userPlanObj);
                                                    PlanRecord.save(function(err, userPlanData) {
                                                        if (err) {
                                                            res.json({
                                                                status: req.config.statusCode.error,
                                                                data: {},
                                                                message: i18n.__("ERROR")
                                                            })
                                                        } else {
                                                            var updatePayment = {
                                                                agency_subscription_id: userPlanData._id
                                                            };
                                                            PaymentModel.findOneAndUpdate({ _id: paymentData._id }, { $set: updatePayment }, { new: true }, function(err, isPaymentUpdated) {
                                                                if (err) {
                                                                    res.json({
                                                                        status: req.config.statusCode.error,
                                                                        data: {},
                                                                        message: i18n.__("ERROR")
                                                                    })
                                                                } else {
                                                                    AgencySubscriptionModel.findOneAndUpdate({ _id: userPlanData._id }, { $set: { payment_id: paymentData._id } }, { new: true })
                                                                        .lean()
                                                                        .exec(function(err, isPaymentDetailsUpdated) {
                                                                            if (err) {
                                                                                res.json({
                                                                                    status: req.config.statusCode.error,
                                                                                    data: {},
                                                                                    message: i18n.__("ERROR")
                                                                                })
                                                                            } else {
                                                                                AgencySubscriptionModel.findOneAndUpdate({agency_id:req.body._id, subscription_id: req.body.previous_subscription_plan_id, status: true , is_renewable: true}, { $set: { status: false, is_renewable: false } }, { new: true })
                                                                                  .lean()
                                                                                  .exec(function(err, data) {
                                                                                    if (err) {
                                                                                        res.json({
                                                                                            status: req.config.statusCode.error,
                                                                                            data: {},
                                                                                            message: i18n.__("ERROR")
                                                                                        })
                                                                                    } else {
                                                                                        var startDate = moment(isPaymentDetailsUpdated.createdAt).format("DD MMM YYYY");
                                                                                        var endDate = moment(isPaymentDetailsUpdated.subscription_expiry_date).format("DD MMM YYYY");
                                                                                        var obj = {
                                                                                            agency_name: req.body.agency_name,
                                                                                            email: userData.email,
                                                                                            invoice_id: paymentData.payment_unique_id,
                                                                                            subscription_plan_name: isPaymentDetailsUpdated.plan_name,
                                                                                            amount: isPaymentDetailsUpdated.plan_amount,
                                                                                            subscription_start_date: startDate,
                                                                                            subscription_expiry_date: endDate
                                                                                        }
                                                                                        sendEmailNotification(obj);
                                                                                    }
                                                                                });
                                                                            }
                                                                        });
                                                                }
                                                            });
                                                        }
                                                    });
                                                }
                                            });
                                        } else {
                                            paymentData.status = 'failed';
                                            res.json({
                                                status: req.config.statusCode.error,
                                                data: {},
                                                message: i18n.__("ERROR")
                                            })
                                        }
                                    })
                                }
                            });
                        })
                    })
            }
        })

    }
}