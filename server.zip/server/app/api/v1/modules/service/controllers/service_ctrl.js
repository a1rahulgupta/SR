const _ = require("lodash");
const moment = require('moment');
const Joi = require('joi');
const i18n = require("i18n");
const mongoose = require('mongoose');
const santize = __rootRequire('app/utils/santize');
//Models 
const User = mongoose.model('Users');
const AgencyModel = mongoose.model('Agencies');
const ClientModel = mongoose.model('Clients');
const InterpreterModel = mongoose.model('Interpreters');
const EmailTemplateModel = mongoose.model('Email_Templates');
const AgencyUser = mongoose.model('Agency_users');
const Services = mongoose.model('Services');

module.exports = {

    listServices: function (req, res, next) {
        let conditions = {
            is_deleted: false
        };
        Services.where(conditions).count().exec().then((count) => {
            //  __debug(count)
            Services.find()
                .then((service) => {
                    return service
                }).then((service) => {

                    res.json({
                        status: req.config.statusCode.success,
                        data: service,
                        count: count
                    });
                })
                .catch((err) => {
                    __debug(err)
                    res.json({
                        status: req.config.statusCode.error,
                        data: [],
                        count: 0,
                        message: i18n.__("ERROR")
                    });
                })
        }).catch((err) => {
            __debug(err)
            res.json({
                status: req.config.statusCode.error,
                data: [],
                count: 0,
                message: i18n.__("ERROR")
            });
        });
    },


    addServices: function (req, res, next) {
        service = new Services(req.body);
        service.save()
            .then((result) => {
                res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    message: i18n.__("NEW_SERVICES_ADDED_SUCCESSFULLY")
                });
            }).catch((err) => {
                //__debug(err)
                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });
    },

    deleteServices: function (req, res, next) {
        Services.findOneAndUpdate({
                _id: req.body.id,
            }, {
                $set: {
                    is_deleted: "true"
                }
            }, {
                new: true
            })
            .then((result) => {
                res.json({
                    status: req.config.statusCode.success,
                    data: result,
                    message: i18n.__("SERVICE_DETAILS_DELETED_SUCCESSFULLY")
                });
            }).catch((err) => {

                res.json({
                    status: req.config.statusCode.error,
                    data: req.body,
                    message: i18n.__("ERROR")
                })

            });

    },



}