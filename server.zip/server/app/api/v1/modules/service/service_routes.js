module.exports = function (router) {
    var auth = __rootRequire("app/utils/crypto");
    var middlewares = [auth.ensureAuthorized];
    var service_ctrl = require('./controllers/service_ctrl')

    router.get('/service/listservices', service_ctrl.listServices);
    router.post('/service/addservices', service_ctrl.addServices);
    router.delete('/service/deleteservices', service_ctrl.deleteServices);

    
    return router;
}