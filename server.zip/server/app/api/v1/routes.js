module.exports = function (express) {
    var router = express.Router()
    
    //User
    require('./modules/agency/agency_routes')(router);
    require('./modules/interpreter/interpreter_routes')(router);
    require('./modules/user/user_routes')(router);
    require('./modules/client/client_routes')(router);
    require('./modules/booking/booking_routes')(router);
    require('./modules/service/service_routes')(router);
    require('./modules/customer/customer_routes')(router);
    require('./modules/web_call/web_call_routes')(router);
    require('./modules/video_call/video_call_routes')(router);
    require('./modules/admin/admin_routes')(router);
    require('./modules/subscription/subscription_routes')(router);
    require('./modules/invoice/invoice_routes')(router);
    require('./modules/review_rating/review_rating_routes')(router);
    require('./modules/check_in_out/check_in_out_routes')(router);
    require('./modules/chat/chat_routes')(router);
    require('./modules/scheduler/scheduler_routes')(router);
    require('./modules/cms/cms_routes')(router);
    require('./modules/report/report_routes')(router);

    return router;
}