'use strict';

var SwaggerExpress = require('swagger-express-mw');
var express = require('express');
var path = require('path');
var app = express();
var cookieParser = require('cookie-parser');
var session = require('express-session');
var bodyParser = require('body-parser');
var fs = require('fs');
var http = require('http');
var https = require('https');
var twilio = require('twilio');
var configVideo = require('./config/config');
var AccessToken = require('twilio').jwt.AccessToken;
var VideoGrant = AccessToken.VideoGrant;
var randomName = require('./randomname');
//to remove-------
var credentials = require('./credentials.json');
var TokenProvider = require('./api/controllers/tokenprovider');
var tokenProvider = new TokenProvider(credentials);
module.exports = app; // for testing
require('./config/db');

var utils = require('./api/lib/util');

var withings = require('./api/controllers/withings');
var fitbit = require('./api/controllers/fitbit');

var ivr = require('./api/controllers/ivr');
app.use(bodyParser.json());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'videochat')));
//app.use(express.static(path.join(__dirname, 'videochat/swf/preloader.swf')));
app.use(express.static(path.join(__dirname, 'public/users')));
app.use(express.static(path.join(__dirname, 'public/admin')));
app.use(express.static(path.join(__dirname, 'public/hospital')));
app.use(express.static(path.join(__dirname, 'public/careCoordinator')));
app.use(express.static(path.join(__dirname, 'public/ambulance')));
app.use(express.static(path.join(__dirname, 'public/towing')));
app.use(express.static(path.join(__dirname, 'bower_components')));
var sess = {
    secret: 'bigSecret_iotied',
    resave: true,
    saveUninitialized: true
}
app.use(session(sess));

var config = {
    appRoot: __dirname // required config
};

//All 7 modules routing
//to remove-----------------------
if (credentials.authToken) {
    console.warn('WARNING: The "authToken" field is deprecated. Please use "signingKeySecret".');
}

if (credentials.instanceSid) {
    console.warn('WARNING: The "instanceSid" field is deprecated. Please use "serviceSid".');
}

// app.get('/getToken', function(req, res) {
//   var identity = req.query && req.query.identity;
//   var endpointId = req.query && req.query.endpointId;
//   var userId = req.query && req.query.userId;

//   if (!identity || !endpointId || !userId) {
//     res.status(400).send('getToken requires both an Identity and an Endpoint ID');
//   }

//   var token = tokenProvider.getToken(identity, endpointId, userId);
//   console.log("token---------------->", token);
//   res.send(token);
// });
app.get('/getToken', function (req, res) {
    tokenProvider.getToken(req, res);
});
//----------------------------------

app.get('/', function (req, res, next) {
    res.sendFile(path.join(__dirname, 'public/users/index.html'));
});

app.get('/admin', function (req, res, next) {
    res.sendFile(path.join(__dirname, 'public/admin/index.html'));
});
app.get('/hospital', function (req, res, next) {
    res.sendFile(path.join(__dirname, 'public/hospital/index.html'));
});
app.get('/careCoordinator', function (req, res, next) {
    res.sendFile(path.join(__dirname, 'public/careCoordinator/index.html'));
});
app.get('/clinician', function (req, res, next) {
    res.sendFile(path.join(__dirname, 'public/clinician/index.html'));
});
app.get('/ambulance', function (req, res, next) {
    res.sendFile(path.join(__dirname, 'public/ambulance/index.html'));
});
app.get('/towing', function (req, res, next) {
    res.sendFile(path.join(__dirname, 'public/towing/index.html'));
});
//Withing callback url after first time connect
app.get('/callback', function (req, res, next) {
    withings.oauth_callback(req, res);
});
//All 4 kind of instant notification url
app.get('/notifyScaleActivity', function (req, res, next) {
    withings.notifyScaleActivity(req, res);
});
app.get('/notifyBpActivity', function (req, res, next) {
    withings.notifyBpActivity(req, res);
});
app.get('/notifySleepActivity', function (req, res, next) {
    withings.notifySleepActivity(req, res);
});
app.get('/notifyBodyActivity', function (req, res, next) {
    withings.notifyBodyActivity(req, res);
});

app.post('/notifyScaleActivity', function (req, res, next) {
    withings.notifyScaleActivity(req, res);
});
app.post('/notifyBpActivity', function (req, res, next) {
    withings.notifyBpActivity(req, res);
});
app.post('/notifySleepActivity', function (req, res, next) {
    withings.notifySleepActivity(req, res);
});
app.post('/notifyBodyActivity', function (req, res, next) {
    withings.notifyBodyActivity(req, res);
});

app.get('/oauth_callbackfitbit', function (req, res, next) {
    fitbit.oauth_fitbit_callback(req, res);
});

app.get('/fitbit-notifications', function (req, res, next) {
    console.log('checking verfication code in app js fitbit', req.query);
    fitbit.verifyCode(req, res);
});

app.get('/videochat', function (req, res, next) {
    res.sendFile(path.join(__dirname, 'videochat/chat.htm'));
});
app.get('/videochat/swf/preloader.swf', function (req, res, next) {
    res.sendFile(path.join(__dirname, 'videochat/swf/preloader.swf'));
});
app.get('/videochat/swf/chat71.swf', function (req, res, next) {
    res.sendFile(path.join(__dirname, 'videochat/swf/chat71.swf'));
});
app.get('/videochat/swf/debug.swf', function (req, res, next) {
    res.sendFile(path.join(__dirname, 'videochat/swf/debug.swf'));
});
app.get('/videochat/admin', function (req, res, next) {
    res.sendFile(path.join(__dirname, 'videochat/admin/admin.htm'));
});
app.get('/videochat/whiteboard', function (req, res, next) {
    res.sendFile(path.join(__dirname, 'videochat/swf/whiteboard.swf'));
});
app.get('/videochat/admin/admintool', function (req, res, next) {
    res.sendFile(path.join(__dirname, 'videochat/admin/swf/admintool.swf'));
});
app.get('/videochat/admin/preloader', function (req, res, next) {
    res.sendFile(path.join(__dirname, 'videochat/admin/swf/preloader.swf'));
});

app.get('/token', function (request, response) {
    var identity = randomName();

    // Create an access token which we will sign and return to the client,
    // containing the grant we just created.
    var token = new AccessToken(
        configVideo.V_TWILIO_ACCOUNT_SID,
        configVideo.V_TWILIO_API_KEY,
        configVideo.V_TWILIO_API_SECRET
        // process.env.TWILIO_ACCOUNT_SID,
        // process.env.TWILIO_API_KEY,
        // process.env.TWILIO_API_SECRET
    );
    // Assign the generated identity to the token.
    // console.log("")
    token.identity = identity;

    // Grant the access token Twilio Video capabilities.
    var grant = new VideoGrant();
    token.addGrant(grant);

    // Serialize the token to a JWT string and include it in a JSON response.
    response.send({
        identity: identity,
        token: token.toJwt()
    });
});


app.post('/ivr/welcome', twilio.webhook({ validate: false }), ivr.welcome);
app.post('/ivr/menu', twilio.webhook({ validate: false }), ivr.menu);
app.post('/ivr/record-system-id', twilio.webhook({ validate: false }), ivr.recordSystemId);
app.post('/ivr/checkedSSN', twilio.webhook({ validate: false }), ivr.checkedSSN);
app.post('/ivr/dial', twilio.webhook({ validate: false }), ivr.dial);
app.post('/ivr/record', twilio.webhook({ validate: false }), ivr.record);
/*app.post('/ivr/record', function(req, res, next) {
    ivr.record(req, res);
});*/

SwaggerExpress.create(config, function (err, swaggerExpress) {
    if (err) {
        throw err;
    }
    // All api requests
    app.use(function (req, res, next) {
        // CORS headers
        res.header("Access-Control-Allow-Origin", "*"); // restrict it to the required domain
        res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
        // Set custom headers for CORS
        res.header('Access-Control-Allow-Headers', 'Content-type,Accept,X-Access-Token,X-Key,If-Modified-Since,Authorization');

        if (req.method == 'OPTIONS') {
            res.status(200).end();
        } else {
            next();
        }
    });

    //Check to call web services where token is not required//
    app.use('/api/v1/*', function (req, res, next) {
        var freeAuthPath = [
            '/api/v1/auth/login',
            '/api/v1/auth/forgotpass',
            '/api/v1/auth/checkResetToken',
            '/api/v1/auth/resetPassword',
            '/api/v1/notifyScaleActivity',
            '/api/v1/notifyBpActivity',
            '/api/v1/notifyBodyActivity',
            '/api/v1/notifySleepActivity',
            '/api/v1/auth/hospitalSignUp',
            '/api/v1/auth/patientSignUp',
            '/api/v1/auth/careCoordinatorSignUp',
            '/api/v1/auth/clinicianSignUp',
            '/api/v1/auth/ambulanceSignUp',
            '/api/v1/auth/towingSignUp',
            '/api/v1/auth/getCountry',
            '/api/v1/auth/getHospitalForReg',

            '/api/v1/auth/getServiceType',
            '/api/v1/ivr/welcome',
            '/api/v1/ivr/menu',
        ];
        var available = false;
        for (var i = 0; i < freeAuthPath.length; i++) {
            if (freeAuthPath[i] == req.baseUrl) {
                available = true;
                break;
            }
        }
        if (!available) {
            utils.ensureAuthorized(req, res, next);
        } else {
            next();
        }
    });
    // enable SwaggerUI
    app.use(swaggerExpress.runner.swaggerTools.swaggerUi());
    // install middleware
    swaggerExpress.register(app);

    /*********************************************** Added by Sourav Das *****************************/
    //Use it when the live server have port 80 for http and port 443 for https is open.
    /* var httpPort = process.env.PORT || ((process.env.NODE_ENV == 'production')?80:5063);
    var httpsPort = process.env.PORT || 443; */
    var httpPort = process.env.PORT || 5063;
    var httpsPort = process.env.PORT || 5063;

    // if (process.env.NODE_ENV == 'production') {

    //     //HTTP Connection
    //     /* var http_app = express();
    //     http_app.set('port', httpPort);
    //     http_app.all('/*', function (req, res, next) {
    //         if (/^http$/.test(req.protocol)) {
    //             //var host = req.headers.host.replace(/:[0-9]+$/g, ""); // strip the port # if any
    //             var host = req.headers.host;
    //             return res.redirect(301, "https://" + host + req.url);
    //         } else {
    //             return next();
    //         }
    //     });
    //     var httpServer = http.createServer(http_app).listen(httpPort, function () {
    //         console.log("http server started at port " + httpPort);
    //     }); */

    //     //HTTPS Connection
    //     const options = {
    //         key: fs.readFileSync('/home/iotied/sslstagingsdei_21Feb2018/stagingsdei_com.key', 'utf8'),
    //         cert: fs.readFileSync('/home/iotied/sslstagingsdei_21Feb2018/ed44c8303428078f.crt', 'utf8')
    //     };


    //     var httpsServer = https.createServer(options, app).listen(httpsPort, function () {
    //         console.log("https server started at port " + httpsPort);
    //     });

    //     //For production socket
    //     var io = require('socket.io').listen(httpsServer);
    //     require('./socket')(io);
    //     //End

    //     httpsServer.on('error', function (e) {
    //         // Handle error 
    //         console.log('Https error: ', e);
    //     });


    // } else {
        var httpServer = http.createServer(app).listen(httpPort, function () {
            console.log("http server started at port " + httpPort);
        });

        //For localhost socket
        var io = require('socket.io').listen(httpServer);
        require('./socket')(io);
        //End

        httpServer.on('error', function (e) {
            // Handle error 
            console.log('Http error: ', e);
        });
    // }


    /*********************************************** Added by Sourav Das *****************************/

    /*********************************************** Old Code *****************************/

    //client server

    //  var port = process.env.PORT || 5065;
    //  app.listen(port); // comment when site is live 

    //var port = process.env.PORT || 5063;
    // var port = process.env.PORT || 5066;
    // app.listen(port); // comment when site is live 
    // var port = process.env.PORT || 5065;
    //app.listen(port); // comment when site is live 

    // SDN staging 
    /* var privateKey = fs.readFileSync('/home/iotied/stagingsdeissl/stagingsdei_com.key', 'utf8');
    var certificate = fs.readFileSync('/home/iotied/stagingsdeissl/c86aaff33f318ca4.crt', 'utf8');
    var credentials = { key: privateKey, cert: certificate };
    var httpsServer = https.createServer(credentials, app);
    httpsServer.listen(port); // comment when site is on local */
    /*********************************************** Old Code *****************************/




    if (swaggerExpress.runner.swagger.paths['/hello']) {
        console.log('try this:\ncurl http://localhost:' + port + '/hello?name=Scott');
    }
   // var server = http.createServer(app);
   
   
});


