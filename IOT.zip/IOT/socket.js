module.exports = function (io) {
  'use strict';
  // var visitCtrl = require('./api/controllers/visit_ctrl');
  // var mongoose = require('mongoose');
  // var Alert = mongoose.model('Alert');
  // var co = require('co');
  var socketArray = [];
  var onlineArray = [];

  io.on('connection', function (socket) {

    // console.log('connectedSocketID', socket.client.conn.id);
    console.log('connection');

    io.sockets.connected[socket.client.conn.id].emit("connect");

    socket.on('registerSocket', function (username) {
      // console.log('registerSocket', username);
      // console.log('id', socket.client.conn.id);
    });

    socket.on('join', function (username) {
      console.log("------new socket joined--------;" + "username--->" + username + "---------Socket Id------->" + socket.client.conn.id);
      var found = 0;
      console.log('-----before join: socketArray: ', socketArray);
      socketArray.forEach(function (client) {
        if (client.name == username) {
          var index = socketArray.indexOf(client);
          if (index > -1) {
            socketArray.splice(index, 1);
          }
          socketArray.push({
            name: username,
            socket: socket.client.conn.id
          });
          found = 1;
        }
      });
      if (found == 0) {
        if (username) {
          socketArray.push({
            name: username,
            socket: socket.client.conn.id
          });
        }
      }
      console.log('----- after join: socketArray: ', socketArray);
      allOnline(socketArray);

    });

      function allOnline(socketArray) {
        console.log("onlineArray",socketArray);
         var arr = [];
         arr = socketArray;
        socket.emit('online',arr);
      }     

    socket.on('leave', function () {
      // console.log("-------socket leaved-------;", socket.client.conn.id);
      socketArray.forEach(function (client) {
        if (client.socket == socket.client.conn.id) {
          var index = socketArray.indexOf(client);
          if (index > -1) {
            socketArray.splice(index, 1);
          }
        }
      });
      console.log('-----leave: socketArray: ', socketArray);
    });

    socket.on('socketid', function (socketid) {
      socket.join(socketid);
      console.log('user connected');
    });

    socket.on('disconnect', function () {
      var connectionId = socket.client.conn.id;
      //  console.log('-----disconnect: socketArray: ', socketArray);
      // console.log('connectionId', connectionId);
      socketArray.forEach(function (client) {
        if (client.socket == socket.client.conn.id) {
          var index = socketArray.indexOf(client);
          if (index > -1) {
            socketArray.splice(index, 1);
          }
        }
      });
      // console.log('user disconnected');
    });

    socket.on('addUser', function (username) {
      console.log("username------------------>>>>>>>>>>", username);
    });

    socket.on('accept_call', function (Acceptdata) {
      console.log('Join Alert-------------------->>>>>>>>>>>', Acceptdata);
      socket.broadcast.emit('acceptAlert', Acceptdata);
    });
    socket.on('reject_call', function (rejectdata) {
      console.log('Join Alert-------------------->>>>>>>>>>>', rejectdata);
      socket.broadcast.emit('rejectAlert', rejectdata);
    });

    
    
    
    
    
    
    
    socket.on('roomName', function (data) {
      console.log('Alert-------------------->>>>>>>>>>>', data);
      socket.broadcast.emit('testAlert', data);
      // var diseaseList = data.diseases;
      // console.log('diseaseList', diseaseList);
      // var list = [];
      // var minAlertFreq = Math.min.apply(null, diseaseList.map(function (item) {
      //   console.log("val:  ", item.alertInterval);
      //   return item.alertInterval;
      // }));
      // console.log('minAlertFreq', minAlertFreq);
      //io.emit('showDiseaseAlert', {  data: data });
      //Send on alert creation
      // for (var i = 0; i < socketArray.length; i++) {
      //   console.log("Emitting to:----->", socketArray[i]);
      //   if(socketArray[i] && socketArray[i].name !== null && socketArray[i].name !== '' ){
      //        io.sockets.connected[socketArray[i].socket].emit("showDiseaseAlert", { data: data });
      //   }
      // }

      // var diseaseTimer = setInterval(() => {
      //   co(function* () {
      //     let alertInfo = yield Alert.findById(data.alertId).exec();
      //     console.log('alertInfo:', alertInfo);
      //     if (alertInfo && alertInfo.status == 1) {
      //       console.log("Broadcasting Disease Alert..........");

      //       for (var i = 0; i < socketArray.length; i++) {
      //         console.log("Emitting to:----->", socketArray[i]);
      //          if(socketArray[i] && socketArray[i].name !== null && socketArray[i].name !== '' ){
      //               io.sockets.connected[socketArray[i].socket].emit("showDiseaseAlert", { data: data });
      //          }
      //       }
      //       //  io.emit('showDiseaseAlert', {  data: data });
      //     }
      //     else {
      //       console.log("Nedd to clear timer");
      //       clearInterval(diseaseTimer);
      //     }
      //   });
      // }, minAlertFreq * 60000);


    });

  });
};
    // socket.on('triageAlert', function (data) {
    //   console.log('---------------------triageAlert------------->', data);
    //   var triageList = data.triages;
    //   console.log('triageList', triageList);
    //   var list = [];
    //   var minAlertFreq = Math.min.apply(null, triageList.map(function (item) {
    //     console.log("val:  ", item.alertInterval);
    //     return item.alertInterval;
    //   }));
    //   console.log('minAlertFreq', minAlertFreq);

    //   for (var i = 0; i < socketArray.length; i++) {
    //     console.log("Emitting to 1st:----->", socketArray[i]);
    //     if(socketArray[i] && socketArray[i].name !== null && socketArray[i].name !== '' ){
    //         io.sockets.connected[socketArray[i].socket].emit("showTriageAlert", { data: data });
    //     }
    //   }

    //   var timer = setInterval(() => {
    //     co(function* () {
    //       let alertInfo = yield Alert.findById(data.alertId).exec();
    //       if (alertInfo && alertInfo.status == 1) {
    //         console.log("Broadcasting Triage Alert..........");

    //         for (var i = 0; i < socketArray.length; i++) {
    //           console.log("Emitting to:----->", socketArray[i]);
    //            if(socketArray[i] && socketArray[i].name !== null && socketArray[i].name !== '' ){
    //                   io.sockets.connected[socketArray[i].socket].emit("showTriageAlert", { data: data });
    //            }
    //         }
    //       }
    //       else {
    //         console.log("Nedd to clear timer");
    //         clearInterval(timer);
    //       }
    //     });
    //   }, minAlertFreq * 60000);
    // });




// module.exports = function (io) {
//   'use strict';
//   var visitCtrl = require('./api/controllers/visit_ctrl');
//   var mongoose = require('mongoose');
//   var Alert = mongoose.model('Alert');
//   var co = require('co');
//   var socketArray = [];

//   io.on('connection', function (socket) {

//     console.log('connectedSocketID', socket.client.conn.id);
//     console.log('a user connected');

//     socket.on('join', function () {
//       console.log("------new socket joined--------;", socket.client.conn.id);
//       socketArray.push(socket.client.conn.id);
//       console.log('-----join: socketArray: ', socketArray);
//     });

//     socket.on('leave', function () {
//       console.log("-------socket leaved-------;", socket.client.conn.id);
//       var index = socketArray.indexOf(socket.client.conn.id);
//       if (index > -1) {
//          socketArray.splice(index, 1);
//       }
//      // socket.disconnect();

//        console.log('-----leave: socketArray: ', socketArray);
//     });

//     socket.on('socketid', function (socketid) {
//       socket.join(socketid);
//       console.log('user connected');
//     });

//     socket.on('disconnect', function () {
//       var connectionId = socket.client.conn.id;
//       console.log('connectionId', connectionId);
//       var index = socketArray.indexOf(socket.client.conn.id);
//       if (index > -1) {
//          socketArray.splice(index, 1);
//       }
//       console.log('user disconnected');
//     });

//     socket.on('diseaseAlert', function (data) {
//       console.log('diseaseAlert', data);
//       var diseaseList = data.diseases;
//       console.log('diseaseList', diseaseList);
//       var list = [];
//       var minAlertFreq = Math.min.apply(null, diseaseList.map(function (item) {
//         console.log("val:  ", item.alertInterval);
//         return item.alertInterval;
//       }));
//       console.log('minAlertFreq', minAlertFreq);
//       //io.emit('showDiseaseAlert', {  data: data });
//       //Send on alert creation
//       for(var i = 0; i < socketArray.length; i++){
//                console.log("Emitting to:----->", socketArray[i]);
//                io.sockets.connected[socketArray[i]].emit("showDiseaseAlert", {  data: data });
//       }

//       var diseaseTimer = setInterval(() => {
//         co(function* () {
//           let alertInfo = yield Alert.findById(data.alertId).exec();
//           console.log('alertInfo:', alertInfo);
//           if (alertInfo && alertInfo.status == 1) {
//             console.log("Broadcasting Disease Alert..........");

//              for(var i = 0; i < socketArray.length; i++){
//                console.log("Emitting to:----->", socketArray[i]);
//                io.sockets.connected[socketArray[i]].emit("showDiseaseAlert", {  data: data });
//              }
//           //  io.emit('showDiseaseAlert', {  data: data });
//           }
//           else {
//             console.log("Nedd to clear timer");
//             clearInterval(diseaseTimer);
//           }
//         });
//       }, minAlertFreq * 60000);
//     });

//     socket.on('triageAlert', function (data) {
//       console.log('---------------------triageAlert------------->', data);
//       var triageList = data.triages;
//       console.log('triageList', triageList);
//       var list = [];
//       var minAlertFreq = Math.min.apply(null, triageList.map(function (item) {
//         console.log("val:  ", item.alertInterval);
//         return item.alertInterval;
//       }));
//       console.log('minAlertFreq', minAlertFreq);

//       for(var i = 0; i < socketArray.length; i++){
//         console.log("Emitting to 1st:----->", socketArray[i]);
//         io.sockets.connected[socketArray[i]].emit("showTriageAlert", {  data: data });
//       }

//       var timer = setInterval(() => {
//         co(function* () {
//           let alertInfo = yield Alert.findById(data.alertId).exec();
//           if (alertInfo && alertInfo.status == 1) {
//            console.log("Broadcasting Triage Alert..........");

//              for(var i = 0; i < socketArray.length; i++){
//                console.log("Emitting to:----->", socketArray[i]);
//                io.sockets.connected[socketArray[i]].emit("showTriageAlert", {  data: data });
//              }
//           }
//           else {
//             console.log("Nedd to clear timer");
//             clearInterval(timer);
//           }
//         });
//       }, minAlertFreq * 60000);
//     });
//   });
// };
