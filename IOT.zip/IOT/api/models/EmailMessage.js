'use strict';

var mongoose = require('mongoose');


var EmailMessageSchema = mongoose.Schema({
    hospital_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Hospital'
    },
    title:{
        type: String,
        required:true
    },
    subject: {
        type: String,
        required:true
    },
    emailMsg: {
        type: String,
        required:true
    },
    status: {
        type: Boolean,
        default:false
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var EmailMessage = mongoose.model('EmailMessage', EmailMessageSchema);
