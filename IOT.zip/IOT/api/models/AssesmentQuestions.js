'use strict';

var mongoose = require('mongoose');

var AssesmentQuestionSchema = mongoose.Schema({
    question: {
        type: String
    },
    question_type: { 
        type: String,
        enum: ['radio', 'checkbox', 'text','fileType'],
        default: 'text'
    }, 
    options:{
        type:Array,
        default:[]
    },
    file_upload:{
        type:String
    },
    status: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var AssesmentQuestion = mongoose.model('AssesmentQuestion', AssesmentQuestionSchema);