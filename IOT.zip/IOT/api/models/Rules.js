'use strict';

var mongoose = require('mongoose');

var RuleSchema = mongoose.Schema({
    heart_rate_from: {
        type: Number
    },
    heart_rate_to: {
        type: Number
    },
    blood_pressure: {
        diastolic:{
            low : { type: Number},
            high : { type: Number},
        },
        systolic:{
            low : { type: Number},
            high : { type: Number},  
        }
    },
    cholesterol: {
        total_cholesterol_lr: { type: Number},
        total_cholesterol_hr: { type: Number},
        HDL_lr: { type: Number},
        HDL_hr: { type: Number},
    },
    weight: {
        bmi: {
            underweight: { type: Number},
            normal: { type: Number},
            overweight: { type: Number},
            obesity: { type: Number}
        }
    },
    status: {
        type: Boolean,
        default:false
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var Rule = mongoose.model('Rule', RuleSchema);