'use strict';

var mongoose = require('mongoose');

var PatientSurgerySchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    surgeries: [
        {
            surgery: { type: String},
            surgery_date: { type: Date},
            physician: { type: String},
            condition: { type: String}
        }
    ],
    status:{
        type:Boolean,
        default:true
    },
    pSflag:{
        type:Boolean,
        default:false
    },
    is_deleted:{
        type: Boolean,
        default:false
    }
}, {
    timestamps: true
});

var  PatientSurgery = mongoose.model('PatientSurgery', PatientSurgerySchema);