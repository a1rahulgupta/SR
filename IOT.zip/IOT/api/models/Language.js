'use strict';

var mongoose = require('mongoose');

var LanguageSchema = mongoose.Schema({
    language_name: {
        type: String,
        required:true
    },
    status: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var Language = mongoose.model('Language', LanguageSchema);