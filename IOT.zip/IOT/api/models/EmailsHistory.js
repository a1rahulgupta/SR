'use strict';

var mongoose = require('mongoose');

var EmailHistorySchema = mongoose.Schema({
    from_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    to: {  type: String },
    cc: {  type: String },
    bcc: {  type: String },
    message: {
        type: String
    },
    subject: {
        type: String
    },
    is_read: {
        type: Array,
        default: []
    },
    is_deleted: {
        type: Array,
        default: []
    },
    is_attachement: {
         type: Boolean,
        default: false
    },
    from_email: {
        type: String
    },
    from_name: {
        type: String
    }
}, {
    timestamps: true
});

var Email = mongoose.model('EmailsHistory', EmailHistorySchema);