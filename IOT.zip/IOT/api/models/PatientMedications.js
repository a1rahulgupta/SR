'use strict';

var mongoose = require('mongoose');

var PatientMedicationSchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    medication: {
        type: Array,
        default:[]
    },
    start_date: {
        type: Date
    },
    stop_date: {
        type: Date
    },
    condition: {
        type: String
    },
    prescribed_by: {
        type: String
    },
    refill_date: {
        type: Date
    },
    pMflag:{
        type:Boolean,
        default:false
    },
    status:{
        type:Boolean,
        default:true
    },
    is_deleted:{
        type:Boolean,
        default:false
    }
}, {
    timestamps: true
});

var PatientMedication = mongoose.model('PatientMedication', PatientMedicationSchema);