'use strict';

var mongoose = require('mongoose');

var PatientAllergicReactionSchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    allergies: [
        {
            substance: { type: String ,required:true },
            reaction: { type: String, required:true },
            severity: { type: String, required:true },
            condition: { type: String }
        }
    ],
    aRflag:{
        type:Boolean,
        default:false
    },
    status:{
        type:Boolean,
        default:true
    },
    is_deleted:{
        type:Boolean,
        default:false
    }
}, {
    timestamps: true
});

var PatientAllergicReaction = mongoose.model('PatientAllergicReaction', PatientAllergicReactionSchema);