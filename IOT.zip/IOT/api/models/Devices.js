'use strict';

var mongoose = require('mongoose');

var DeviceSchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    coordinator_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Coordinator'
    },
    clinician_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Clinician'
    },
    hospital_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Hospital'
    },
    added_by: {
        type: String
    }, 
    deviceName: {
        type: String,
        required:true
    },
    wearable:{
         type: String,
         required:true
    },
    
    deviceType: {
         type: mongoose.Schema.Types.ObjectId, 
         ref: 'DeviceManagement'},
    make: {
        type: String,
        required:true
    },
    model: {
        type: String,
        required:true
    },
    description: {
        type: String
    },
    location: {
        type: String
    },
    DateDevice_Added: {
        type: Date
    },
    DataDevice_Deleted: {
        type: Date
    },
    DataDevice_Edited: {
        type: Date
    },
    reason: {
        type: String
    },
    status: {
        type: Boolean,
        default:false
    },
    is_deleted: {
        type: Boolean,
        default:false
    }
}, {
    timestamps: true
});

var Device = mongoose.model('Device', DeviceSchema);