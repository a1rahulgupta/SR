'use strict';

var mongoose = require('mongoose');

var EcgfileSchema = mongoose.Schema({
    filename: {
        type: String
    },
    filetype:{
        type: String
    },
    filepath:{
        type: String
    },
    status: {
        type: Boolean,
        default:true
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var Ecgfile = mongoose.model('Ecgfile', EcgfileSchema);