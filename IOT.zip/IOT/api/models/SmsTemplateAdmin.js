'use strict';

var mongoose = require('mongoose');


var SmsTemplateAdminSchema = mongoose.Schema({
    title:{
        type: String,
        required:true
    },
    smsMessage: {
        type: String,
        required:true
    },
    status: {
        type: Boolean,
        default:false
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var SmsTemplateAdmin = mongoose.model('SmsTemplateAdmin', SmsTemplateAdminSchema);
