'use strict';

var mongoose = require('mongoose');

var IvrSettingSchema = mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    user_type: {
        type: String,
    },
    ivr_label: {
        type: String,
    },
   language: {
        type: String
    },
    welcome_message: {
        type: String
    },
    verification_message: {
        type: String
    },
    thankyou_message: {
        type: String
    },
    toll_free_number: {
        type: String
    },
    ccoo_thankyou_message:{
        type: String
    }
}, {
    timestamps: true
});

var IvrSetting = mongoose.model('IvrSetting', IvrSettingSchema);