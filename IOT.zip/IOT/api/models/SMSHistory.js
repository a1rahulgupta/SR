'use strict';

var mongoose = require('mongoose');

var SMSHistorySchema = mongoose.Schema({
    from_id: {
        type: Object,
        default: {}
    },
    to: {
        type: Object,
        default: {}
    },
    message: {
        type: String
    },
    is_read: {
        type: Boolean,
        default: false
    },
    is_deleted: {
        type: Boolean,
        default: false
    },
}, {
    timestamps: true
});

var SmsHistory = mongoose.model('SmsHistory', SMSHistorySchema);