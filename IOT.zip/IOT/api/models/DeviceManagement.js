'use strict';

var mongoose = require('mongoose');

var DeviceManagementSchema = mongoose.Schema({
    deviceName: {
        type: String,
        required:true
    },
    status: {
        type: Boolean,
        default:true
    },
    deviceUrl: {
        type: String,
        required:true
    }
}, {
    timestamps: true
});

var DeviceManagement = mongoose.model('DeviceManagement', DeviceManagementSchema);