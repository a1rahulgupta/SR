'use strict';

var mongoose = require('mongoose');

var PatientActivitySchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    device_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Device'
    },
    grpid: {
        type: String
    },
    attrib : {
        type: String
    },
    measures_date: {
        type: Date
    },
    category: {
        type: String
    },
    measures:{
        type: Array
    },
    fitbit_measures_date : {
        type: String
    },                         

    /*value: {     
        type: String
    },
    type: {
        type: String,
        required:true
    },
    unit: {
        type: String
    }*/
}, {
    timestamps: true
});

var PatientActivity = mongoose.model('PatientActivity', PatientActivitySchema);