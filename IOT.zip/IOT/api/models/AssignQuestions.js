'use strict';

var mongoose = require('mongoose');

var AssignQuestionsSchema = mongoose.Schema({
    patient_id:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    question_id: { 
        type: mongoose.Schema.Types.ObjectId,
        ref: 'AssesmentQuestion'
    }, 
    status: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var AssignQuestions = mongoose.model('AssignQuestions', AssignQuestionsSchema);