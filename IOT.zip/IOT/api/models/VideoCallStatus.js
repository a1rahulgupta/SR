'use strict';

var mongoose = require('mongoose');

var VideoCallStatusSchema = mongoose.Schema({ 
    receive_person : {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    call_date:{
        type: String
    },
    name:{
        type: String
    },
     is_view: {
        type: Boolean,
        default: false
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var VideoCallStatus = mongoose.model('VideoCallStatus', VideoCallStatusSchema);