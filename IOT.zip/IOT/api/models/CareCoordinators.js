'use strict';

var mongoose = require('mongoose');

var CareCoordinatorSchema = mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    hospital_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Hospital'
    },
    careCoordinator_npi_no: {
        type: String,
        required: true
    },
    first_name: {
        type: String,
        required: true
    },
    last_name: {
        type: String,
        required: true
    },
    SSN: {
        type: String,
        required: true
    },
    address: {
        type: String,
        required: true
    },
    city: {
        type: String,
        required: true
    },
    state: {
        type: String,
        required: true
    },
    zip_code: {
        type: String,
        required: true
    },
    country: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Country'
    },
    mobile_no: {
        type: String,
        required: true
    },
    is_verified: {
        type: Boolean,
        default: false
    },
    status: {
        type: Boolean,
        default: true
    },
    image: {
        type: String
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var CareCoordinator = mongoose.model('CareCoordinator', CareCoordinatorSchema);
