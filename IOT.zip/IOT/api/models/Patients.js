'use strict';

var mongoose = require('mongoose');


var PatientSchema = mongoose.Schema({
    SSN: {
        type: String
    },
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    clinician_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Clinician'
    },
    coordinator_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Coordinator'
    },
    hospital_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Hospital'
    },
    title: {
        type: String
    },
    first_name: {
        type: String
    },
    last_name: {
        type: String
    },
    age: {
        type: String
    },
    gender: {
        type: String
    },
    primary_provider: {
        type: String
    },
    suffix: {
        type: String
    },
    image: {
        type: String
    },
    reports_documents: {
        type: Array,
        default: []
    },
    phone_no: {
        type: String
    },
    address: {
        type: String
    },
    city:{
        type:String
    },
    state:{
        type: String
    },
    country:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Country'
    },
    zip_code:{
        type: String
    },
    mobile_no: {
        type: String
    },
    DOB: {
        type: Date
    },
    status: {
        type: Boolean,
        default: true
    },
    smoker: {
        type: Boolean,
        default: false
    },
    diabetes: {
        type: Boolean,
        default: false
    },
    bp_treatment: {
        type: Boolean,
        default: false
    },
    pflag:{
        type: Boolean,
        default: false
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var Patient = mongoose.model('Patient', PatientSchema);
