'use strict';

var mongoose = require('mongoose');

var PatientEncounterSchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    encounter_date: {
        type: Date
    },
    hospital: {
        type: String
    },
    address: {
        type: String
    },
    state: {
        type: String
    },
    city: {
        type: String
    },
    zip_code: {
        type: String
    },
    country: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Country'
    },
    diagnosis: {
        type: Array,
        default:[]  
    },
    provider: {
        type: String
    },
    pEflag:{
        type:Boolean,
        default:false
    },
    status:{
        type:Boolean,
        default:true
    },
    is_deleted:{
        type:Boolean,
        default:false
    }
}, {
    timestamps: true
});

var PatientEncounter = mongoose.model('PatientEncounter', PatientEncounterSchema);