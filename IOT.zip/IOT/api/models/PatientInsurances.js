'use strict';

var mongoose = require('mongoose');

var PatientInsuranceSchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    insurance_company: {
        type: String
    },
    insurance_id_no: {
        type: String
    },
    group_number: {
        type: String
    },
    group_name: {
        type: String
    },
    plan_name: {
        type: String
    },
    plan_type: {
        type: String
    },
    card_issue_date: {
        type: Date
    },
    card_expiry_date: {
        type: Date
    },
    pIflag:{
        type: Boolean,
        default: false
    },
    status:{
        type:Boolean,
        default:true
    },
    is_deleted:{
        type:Boolean,
        default:false
    }
}, {
    timestamps: true
});

var PatientInsurance = mongoose.model('PatientInsurance', PatientInsuranceSchema);