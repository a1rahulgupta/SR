'use strict';

var mongoose = require('mongoose');

var ServiceTypeSchema = mongoose.Schema({
    serviceType_name: {
        type: String,
        required:true
    },
    status: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var ServiceType = mongoose.model('ServiceType', ServiceTypeSchema);