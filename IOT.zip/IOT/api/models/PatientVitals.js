'use strict';

var mongoose = require('mongoose');

var PatientVitalSchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    body_temperature: {
        type: Number,
        required: true
    },
    pulse_rate: {
        type: Number,
        required: true
    },
    blood_pressure: {
        diastolic: { type: Number, required: true },
        systolic: { type: Number, required: true }
    },
    body_mass: {
        height: { type: Number, default: 0, required: true },
        weight: { type: Number, default: 0, required: true },
    },
    cholesterol: {
        total_cholesterol: { type: Number, default: 0, required: true },
        HDL: { type: Number, default: 0, required: true },
    },
    po2: {
        type: Number,
        required: true
    },
    is_device: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var PatientVital = mongoose.model('PatientVital', PatientVitalSchema);
