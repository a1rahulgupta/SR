'use strict';

var mongoose = require('mongoose');


var SmsTemplateSchema = mongoose.Schema({
    hospital_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Hospital'
    },
    title:{
        type: String,
        required:true
    },
    smsMessage: {
        type: String,
        required:true
    },
    status: {
        type: Boolean,
        default:false
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var SmsTemplate = mongoose.model('SmsTemplate', SmsTemplateSchema);
