'use strict';

var mongoose = require('mongoose');

var PatientAssesmentSchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    question_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Question'
    },
    answer:{
        type:String
    },
    status:{
        type:String,
        default:true
    },
    is_deleted: {
        type: Boolean,
        default:false
    }
}, {
    timestamps: true
});

var PatientAssessment = mongoose.model('PatientAssessment', PatientAssesmentSchema);