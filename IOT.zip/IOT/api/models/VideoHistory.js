'use strict';

var mongoose = require('mongoose');

var VideoHistorySchema = mongoose.Schema({
    joinId: {
        type: mongoose.Schema.Types.ObjectId
    }, 
    calling_Person : {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    name:{
        type: String
    },
    status: {
        type: String
    }
}, {
    timestamps: true
});

var VideoHistory = mongoose.model('VideoHistory', VideoHistorySchema);