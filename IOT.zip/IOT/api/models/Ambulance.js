'use strict';

var mongoose = require('mongoose');

var AmbulatorySchema = mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    company_name: {
        type: String
    },
    hospital_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Hospital'
    },
    vehicles: {
        type: String
    },
    vehicle_type: {
        type: String
    },
    mobile_no: {
        type: String
    },
    helpline_number: {
        type: String
    },
    service_time: {
        type: Date
    },
    service_type: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ServiceType'
    },
    address: {
        type: String
    },
    zip_code: {
        type: String
    },
    city: {
        type: String
    },
    country: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Country'
    },
    state: {
        type: String
    },
    status: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    },
    image: {
        type: String
    }
}, {
    timestamps: true
});

var Ambulance = mongoose.model('Ambulance', AmbulatorySchema);
