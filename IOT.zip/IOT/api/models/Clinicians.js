'use strict';

var mongoose = require('mongoose');

var ClinicianSchema = mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    hospital_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Hospital'
    },
    clinician_npi_no: {
        type: String
    },
    first_name: {
        type: String
    },
    last_name: {
        type: String
    },
    SSN: {
        type: String
    },
    address: {
        type: String
    },
    city: {
        type: String
    },
    state: {
        type: String
    },
    zip_code: {
        type: String
    },
    country: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Country'
    },
    mobile_no: {
        type: String
    },
    specialization: {
        type: String
    },
    status: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    },
    image: {
        type: String
    },
    is_verified: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var Clinician = mongoose.model('Clinician', ClinicianSchema);
