'use strict';

var mongoose = require('mongoose');

var PatientChronicDiseaseSchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    disease_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Disease'
    },
    start_date: {
        type: Date
    },
    condition: {
        type: String
    },
    pCflag:{
        type:Boolean,
        default:false
    },
    status: {
        type: Boolean,
        default: false
    },
    is_deleted:{
        type: Boolean,
        default:false
    }
}, {
    timestamps: true
});

var PatientChronicDisease = mongoose.model('PatientChronicDisease', PatientChronicDiseaseSchema);