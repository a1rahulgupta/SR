'use strict';

var mongoose = require('mongoose');

var PatientFamilyHistorySchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    disease_id: {
        type:  mongoose.Schema.Types.ObjectId,
        ref: 'Disease'
    },
    start_date: {
        type: Date
    },
    stop_date: {
        type: Date
    },
    member_name: {
        type: String
    },
    relation: {
        type: String
    },
    type: {
        type: String,
        required:true
    },
    cause: {
        type: String
    },
    cause_of_death: {
        type: String
    },
    pFflag:{
        type:Boolean,
        default:false
    },
    status:{
        type: Boolean,
        default:true
    },
    is_deleted:{
        type: Boolean,
        default:false
    }
}, {
    timestamps: true
});

var PatientFamilyHistory = mongoose.model('PatientFamilyHistory', PatientFamilyHistorySchema);