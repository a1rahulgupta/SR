'use strict';

var mongoose = require('mongoose');

var AssesQuestionFileSchema = mongoose.Schema({
    file_upload:{
        type:String
    },
    question_type: { 
        type: String,
        default: 'fileType'
    }, 
    status: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var AssesQuestionFile = mongoose.model('AssesQuestionFile', AssesQuestionFileSchema);