'use strict';

var mongoose = require('mongoose');


var HospitalAssignSchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    role_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Role'
    },
    assign_id: {
        type: mongoose.Schema.Types.ObjectId
    },
    
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var HospitalAssign = mongoose.model('HospitalAssign', HospitalAssignSchema);
