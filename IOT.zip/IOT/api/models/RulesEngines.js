'use strict';

var mongoose = require('mongoose');

var RulesEngineSchema = mongoose.Schema({
    rulesEngine_name: {
        type: String,
        required:true
    },
    hospitalMsg: {
        type: String,
        required:true
    },
    clinicianMsg: {
        type: String,
        required:true
    },
    ambulenceMsg: {
        type: String,
        required:true
    },
    towingMsg:{
        type: String,
        required: true
    },
    careMsg:{
        type: String,
        required: true
    },
     heart_rate_from: {
        type: Number
    },
    heart_rate_to: {
        type: Number
    },
    blood_pressure: {
        diastolic:{
            low : { type: Number},
            high : { type: Number},
        },
        systolic:{
            low : { type: Number},
            high : { type: Number},  
        }
    },
    cholesterol: {
        total_cholesterol_lr: { type: Number},
        total_cholesterol_hr: { type: Number},
        HDL_lr: { type: Number},
        HDL_hr: { type: Number},
    },
    weight: {
        bmi: {
            underweight: { type: Number},
            normal: { type: Number},
            overweight: { type: Number},
            obesity: { type: Number}
        }
    },
    status: {
        type: Boolean,
        default:true
    },
    is_deleted: {
        type: Boolean,
        default: false
    },
    is_default:{
        type: Boolean,
        default:false
    }
}, {
    timestamps: true
});

var RulesEngines = mongoose.model('RulesEngines', RulesEngineSchema);