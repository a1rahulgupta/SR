'use strict';

var mongoose = require('mongoose');

var PatientReportSchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    upload_report:{
        type:String
    }, 
    status: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var PatientReport = mongoose.model('PatientReport', PatientReportSchema);