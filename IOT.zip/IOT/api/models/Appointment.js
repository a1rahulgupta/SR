'use strict';

var mongoose = require('mongoose');


var AppointmentSchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    clinician_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Clinician'
    },
    coordinator_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Coordinator'
    },
    hospital_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Hospital'
    },
    room_id: {
        type: String,
    },
    title: {
        type: String
    },
    description: {
        type: String
    },
    response_message: {
        type: String
    },
    appointmentate: {
        type: Date
    },
    is_video_call:{
        type: Boolean,
        default: false
    },
    status: {
        type: Boolean,
        default: false
    },
    appointment_status: {
        type: Number,
        default: 1 // 1-pending, 2-confirmed, 3-denied, 4 -complete 
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var Appointment = mongoose.model('Appointment', AppointmentSchema);
