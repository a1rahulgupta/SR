'use strict';

var mongoose = require('mongoose');

var PatientDemographicSchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    race: {
        type: String,
        required:true
    },
    ethnicity: {
        type: String
    },
    language: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Language'
    },
    pDflag:{
        type: Boolean,
        default: false
    },
    status:{
        type:Boolean,
        default: true
    },
    is_deleted:{
        type:Boolean,
        default:false
    }
}, {
    timestamps: true
});

var PatientDemographic = mongoose.model('PatientDemographic', PatientDemographicSchema);