'use strict';

var mongoose = require('mongoose');

var RiskAssessmentsSchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    age: {
        type: String
    },
    gender: {
        type: String
    },
    ethnicity_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Ethnicities'
    },
    smoking_status_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'SmokingStatus'
    },
    diabetes_status_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'DiabetesStatus'
    },
    smoker: {
        type: Boolean,
        default: false
    },
    diabetes: {
        type: Boolean,
        default: false
    },
    bp_treatment: {
        type: Boolean,
        default: false
    },
    heart_attack_disease: {
        type: Boolean,
        default: false
    },
    chronic_kidney_disease: {
        type: Boolean,
        default: false
    },
    atrial_fibrillation_disease: {
        type: Boolean,
        default: false
    },
    blood_pressure_disease: {
        type: Boolean,
        default: false
    },
    rheumatoid_arthritis_disease: {
        type: Boolean,
        default: false
    },
    cholesterol: {
        total_cholesterol: { type: Number, default: 0, required: true },
        HDL: { type: Number, default: 0, required: true },
    },
    blood_pressure: {
        diastolic: { type: Number, default: 0, required: true },
        systolic: { type: Number, default: 0, required: true },
    },
    body_mass: {
        height: { type: Number, default: 0 },
        weight: { type: Number, default: 0 },
    },
    risk: { type: Number },
    status: {
        type: Boolean,
        default: false
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var RiskAssessments = mongoose.model('RiskAssessments', RiskAssessmentsSchema);
