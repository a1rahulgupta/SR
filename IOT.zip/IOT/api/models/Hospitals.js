'use strict';

var mongoose = require('mongoose');

var HospitalSchema = mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    hospital_npi_no: {
        type: String
    },
    hospital_name: {
        type: String
    },
    hospital_mobile_no: {
        type: String
    },
    hospital_address: {
        type: String
    },
    hospital_city: {
        type: String
    },
    hospital_state: {
        type: String
    },
    hospital_zip_code: {
        type: String
    },
    hospital_country: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Country'
    },
    status: {
        type: Boolean,
        default: true
    },
    image: {
        type: String
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var Hospital = mongoose.model('Hospital', HospitalSchema);
