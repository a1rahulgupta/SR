'use strict';

var mongoose = require('mongoose');

var CountrySchema = mongoose.Schema({
    country_name: {
        type: String,
        required:true
    },
    status: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var Country = mongoose.model('Country', CountrySchema);