'use strict';

var mongoose = require('mongoose');

var TowingSchema = mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    company_name: {
        type: String
    },
    hospital_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Hospital'
    },
    mobile_no: {
        type: String
    },
    helpline_number: {
        type: String
    },
    number_of_vehicles: {
        type: String
    },
    service_type: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ServiceType'
    },
    owner_name: {
        type: String
    },
    address: {
        type: String
    },
    city: {
        type: String
    },
    state: {
        type: String
    },
    country: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Country'
    },
    zip_code: {
        type: String
    },
    status: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    },
    image: {
        type: String
    }
}, {
    timestamps: true
});

var Towing = mongoose.model('Towing', TowingSchema);
