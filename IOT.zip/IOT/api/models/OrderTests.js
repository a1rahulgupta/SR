'use strict';

var mongoose = require('mongoose');

var OrderTestSchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    test_name: {
        type: String
    },
    ionic_code: {
        type: String
    },
    lab_address: {
        type: String
    },
    order_date: {
        type: Date
    },
    status: {
        type: Boolean,
        default: false
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var OrderTest = mongoose.model('OrderTest', OrderTestSchema);
