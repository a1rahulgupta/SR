'use strict';

var mongoose = require('mongoose');

var EcgmeasureSchema = mongoose.Schema({
    ecgfile_id :{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Ecgfile'
    },
    time: {
        type: Number
    },
    sign0: {
        type: Number
    },
    sign1: {
        type: Number
    },
    type: {
        type: String
    },
}, {
    timestamps: true
});

var Ecgmeasure = mongoose.model('Ecgmeasure', EcgmeasureSchema);