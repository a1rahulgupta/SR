'use strict';

var mongoose = require('mongoose');

var CarePlanSchema = mongoose.Schema({
    patient_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    dosage: {
        type: String
    },
    medicine: {
        type: String
    },
    jogging: {
        type: String
    },
    walking: {
        type: String
    },
    issue_date: {
        type: Date
    },
    status: {
        type: Boolean,
        default: false
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var CarePlan = mongoose.model('CarePlan', CarePlanSchema);
