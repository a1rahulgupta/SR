'use strict';

var mongoose = require('mongoose');

var PatientDiseaseSchema = mongoose.Schema({
    patient_id: {
        type:  mongoose.Schema.Types.ObjectId,
        ref: 'Patient'
    },
    disease_id: {
        type:  mongoose.Schema.Types.ObjectId,
        ref: 'Disease'
    },
    datetime_diagnosed: {
        type: Date
    },
    condition: {
        type: String,
    },
    pDflag:{
        type:Boolean,
        default:false
    },
    status:{
        type: Boolean,
        default:true
    },
    is_deleted:{
        type: Boolean,
        default:false
    }
}, {
    timestamps: true
});

var PatientDisease = mongoose.model('PatientDisease', PatientDiseaseSchema);