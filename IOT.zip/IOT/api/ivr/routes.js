module.exports = function(router) {
    var twilio = require('twilio');
    
    var ivr = require('../controllers/ivr');
    router.post('/ivr/welcome', twilio.webhook({ validate: false }), ivr.welcome);
    router.post('/ivr/menu', twilio.webhook({ validate: false }), ivr.menu);
    /*router.post('/ivr/record-system-id', twilio.webhook({ validate: false }), ivr.recordSystemId);
    router.post('/ivr/record-client-id', twilio.webhook({ validate: false }), ivr.recordClientId);
    router.post('/ivr/client-notes', twilio.webhook({ validate: false }), ivr.clientNotes);
    router.post('/ivr/task-completed', twilio.webhook({ validate: false }), ivr.taskCompleted);
    router.post('/ivr/select-task', twilio.webhook({ validate: false }), ivr.tasks);
    router.post('/ivr/confirm-time',twilio.webhook({ validate: false }), ivr.confirm);
    router.post('/ivr/setup', ivr.setup);
    router.get('/ivr/setup', ivr.get_ivr);
    router.post('/admin/ivr/save-ivrconfig', ivr.saveIvrConfig);
    router.get('/admin/ivr/get-ivrconfig', ivr.getIvrConfig);*/
    return router;
}


function chk(req, res, next) {
    console.log('chk')
    next();
}
