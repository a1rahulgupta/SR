'use strict';


var mongoose = require('mongoose'),
    config = require('../../config/config.js'),
    RiskAssessments = mongoose.model('RiskAssessments'),
    Ethnicities = mongoose.model('Ethnicities'),
    Role = mongoose.model('Role'),
    Rule = mongoose.model('Rule'),
    Patient = mongoose.model('Patient'),
    User = mongoose.model('User'),
    co = require('co'),
    DiabetesStatus = mongoose.model('DiabetesStatus'),
    SmokingStatus = mongoose.model('SmokingStatus'),
    co = require('co'),
    User = mongoose.model('User'),
    crypto = require('crypto'),
    utility = require('../lib/utility.js'),
    async = require('async'),
    constantsObj = require('../lib/constants');
var kmeans = require('kmeans-node');

module.exports = {
    addRiskAssessment: addRiskAssessment,
    addEthinicity: addEthinicity,
    getEthinicity: getEthinicity,
    addDiabetesStatus: addDiabetesStatus,
    getDiabetesStatus: getDiabetesStatus,
    addSmokingStatus: addSmokingStatus,
    getSmokingStatus: getSmokingStatus,
    updateRules: updateRules,
    getRules: getRules,
    kmeanstest: kmeanstest
};

/**
 * Function is use to Add Patient 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 6-June-2017
 */
function addRiskAssessment(req, res) {
    console.log("------------------------------------------", req.body);

    //console.log(""req.body);
    co(function*() {
        var RiskAssessmentsObj = {};
        var field = ['patient_id', 'ethnicity_id', 'smoking_status_id', 'diabetes_status_id', 'cholesterol', 'body_mass', 'blood_pressure', 'risk'];
        var obj = req.body;
        var risk;
        var cholesterol = req.body.cholesterol.total_cholesterol;
        var systolicBloodPressure = req.body.blood_pressure.systolic;
        var age = req.body.age;
        var hdl = req.body.cholesterol.HDL;
        var meds = req.body.bp_treatment;
        var diabetes = req.body.diabetes;
        var smoking = req.body.smoker;
        var gender = req.body.gender;

        console.log("age", req.body.age);
        console.log("gender", req.body.gender);
        console.log("smoking", req.body.smoker);
        console.log("diabetes", req.body.diabetes);
        console.log("cholesterol", req.body.cholesterol.total_cholesterol);
        console.log("hdl", req.body.cholesterol.HDL);
        console.log("systolicBloodPressure", req.body.blood_pressure.systolic);

        if (gender == 'Male') { // For Male
            var dm = diabetes ? 0.57367 : 0;
            var smoke = smoking ? 0.65451 : 0;
            var medications = meds ? 1.99881 : 1.93303;
            console.log(dm, smoke, medications);
            var riskfactor = (Math.log(age) * 3.06117) + (Math.log(cholesterol) * 1.12370) - (Math.log(hdl) * 0.93263) + (Math.log(systolicBloodPressure) * medications + smoke + dm - 23.9802);
            risk = 100 * (1 - Math.pow(0.88936, riskfactor));
            console.log("risk1", risk);
        } else { // For Female
            var dm = diabetes ? 0.69154 : 0;
            var smoke = smoking ? 0.52873 : 0;
            var medications = meds ? 2.82263 : 2.76157;
            var riskfactor = (Math.log(age) * 2.32888) + (Math.log(cholesterol) * 1.20904) - (Math.log(hdl) * 0.70833) + (Math.log(systolicBloodPressure) * medications + smoke + dm - 26.1931);
            risk = 100 * (1 - Math.pow(0.95012, riskfactor));
        }

        obj.risk = risk;

        //console.log("risk3", risk);
        utility.encryptedRecord(obj, field, function(RiskAssessmentsObj) {
            //console.log("RiskAssessmentsObj-----", RiskAssessmentsObj);
            var riskAssessments = new RiskAssessments(RiskAssessmentsObj);
            riskAssessments.save(function(err, RiskAssessment) {
                if (err) {
                    res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
                    console.log(err)
                } else {
                    //console.log("data---------------", data)
                    res.json({
                        code: 200,
                        message: constantsObj.messages.riskAssessmentSucess,
                        data: RiskAssessment
                    });
                }

            });
        })
    }).catch(function(err) {
        console.log("err++++++++++++++", err);
        res.json({
            code: 404,
            message: utility.validationErrorHandler(err)
        });
    });
}


function framingham(req, res) {
    var cholesterol = 210;
    var systolicBloodPressure = 140;
    var age = 70;
    var hdl = 40;
    var meds = false;
    var diabetes = false;
    var smoking = true;
    var gender = true;

    var answer = iframingham(cholesterol, age, systolicBloodPressure, hdl, meds, diabetes, smoking, gender);
    console.log("Risk 10 year", answer.risk, "%");


}


function iframingham(cholesterol, age, systolicBloodPressure, hdl, meds, diabetes, smoking, gender) {
    var risk;
    if (gender) {
        var dm = diabetes ? 0.57367 : 0;
        var smoke = smoking ? 0.65451 : 0;
        var medications = meds ? 1.99881 : 1.93303;
        var riskfactor = (Math.log(age) * 3.06117) + (Math.log(cholesterol) * 1.12370) - (Math.log(hdl) * 0.93263) + (Math.log(systolicBloodPressure) * medications + smoke + dm - 23.9802);
        risk = 100 * (1 - Math.pow(0.88936, Math.pow(E, riskfactor)));
        risk = (risk * 10).Math.round() / 10;
    } else {
        var dm = diabetes ? 0.69154 : 0;
        var smoke = smoking ? 0.52873 : 0;
        var medications = meds ? 2.82263 : 2.76157;
        var riskfactor = (Math.log(age) * 2.32888) + (Math.log(cholesterol) * 1.20904) - (Math.log(hdl) * 0.70833) + (Math.log(systolicBloodPressure) * medications + smoke + dm - 26.1931);
        risk = 100 * (1 - Math.pow(0.88936, Math.pow(E, riskfactor)));
        risk = (risk * 10).Math.round() / 10;
    }
    return risk;
}




function addEthinicity(req, res) {
    Ethnicities.save(function(err, data) {
        if (err) {
            console.log(err, "errerrerrerrerrerrerr");
        } else {
            console.log(data, "datadatadatadata");
        }
    });
}


function getEthinicity(req, res) {
    Ethnicities.find({ is_deleted: false }).exec(function(err, data) {
        if (err) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Ethnicity data not found'
            });
        } else {
            res.json({
                'code': config.httpSuccess,
                'data': data
            });
        }
    });
}

function getRuleEngine(req, res) {
    Rule.find({}).exec(function(err, data) {
        if (err) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Rule data not found'
            });
        } else {
            res.json({
                'code': config.httpSuccess,
                'data': data
            });
        }
    });
}

// function addDiabetesStatus(req, res) {
//     DiabetesStatus.save(function(err, data) {
//         if (err) {
//             console.log(err, "errerrerrerrerrerrerr");
//         } else {
//             console.log(data, "datadatadatadata");
//         }
//     });
// }

/**
 * Function is use to Add Diabetes Status  
 * @access private
 * @return json
 * Created by Akshay
 * @smartData Enterprises (I) Ltd
 * Created Date 15-June-2017
 */
function addDiabetesStatus(req, res) {

    console.log('gagfasg-------', req.user.id);
    co(function*() {

        let userData = yield User.findById(req.user.id);
        console.log('userData---', userData);
        if (userData) {
            console.log('gagfasg----1111---', req.body);
            var diabetes = new DiabetesStatus(req.body)
            diabetes.save(function(err, diabetesdata) {
                if (err) {
                    res.json({ code: 400, message: 'DiabetesStatusNotAdded' });
                } else {
                    res.json({ code: 200, message: 'DiabetesStatusAddedSuccessfully' });
                }
            })

        } else {
            return res.json({ code: 402, message: 'Not valid user 1' });
        }
    }).catch(function(err) {
        console.log(err, 'Error')
        return res.json({ code: 402, message: 'Internal Error' });
    });
}

function getDiabetesStatus(req, res) {
    DiabetesStatus.find({ is_deleted: false }).exec(function(err, data) {
        if (err) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Ethnicity data not found'
            });
        } else {
            res.json({
                'code': config.httpSuccess,
                'data': data
            });
        }
    });
}

function addSmokingStatus(req, res) {

}

function getSmokingStatus(req, res) {
    SmokingStatus.find({ is_deleted: false }).exec(function(err, data) {
        if (err) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Ethnicity data not found'
            });
        } else {
            res.json({
                'code': config.httpSuccess,
                'data': data
            });
        }
    });

}


function updateRules(req, res) {
    console.log(req.body);
    co(function*() {
        let ruleData = yield Rule.findById(req.body._id);
        if (ruleData) {
            ruleData.heart_rate_from = req.body.heart_rate_from;
            ruleData.heart_rate_to = req.body.heart_rate_to;
            ruleData.blood_glucose = req.body.blood_glucose;
            ruleData.blood_pressure = req.body.blood_pressure;
            ruleData.weight = req.body.weight;
            let savedData = yield ruleData.save();
            res.json({
                code: 200,
                message: constantsObj.messages.ruleUpdatedSuccess,
                data: savedData
            });
        } else {
            var rule = new Rule(req.body);
            rule.save(function(err, ruleData) {
                console.log('2', err);
                if (err) {
                    res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
                } else {
                    res.json({
                        code: 200,
                        message: constantsObj.messages.ruleUpdatedSuccess,
                        data: ruleData
                    });
                }

            });
        }
    }).catch(function(err) {
        res.json({
            code: 404,
            message: utility.validationErrorHandler(err)
        });
    });
}


function getRules(req, res) {
    Rule.findOne({ status: true, is_deleted: false }).exec(function(err, data) {
        if (err) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Rules data not found'
            });
        } else {
            res.json({
                'code': config.httpSuccess,
                'data': data
            });
        }
    });
}

function kmeanstest() {
    var list = [];
    for (var i = 1; i <= 1000; i++) {
        list.push(i);
    }
    //console.log("List-->",list);

    //var data = [1,2,3,4,5,6,7,8,9,10,11,12];
    var kMeansObject = kmeans.array(list, 3);
    console.log("Single Dimensional Array", kMeansObject);
    // var data1 = [[1,2],[3,4],[7,8],[9,10],[13,14],[15,16],[22,23],[24,25]];
    //var kMeansObject1 = kmeans.array2d(data1,2);
    //console.log("Multi Dimensional Array",kMeansObject1);
    // for(i=1;i<2;i++)
    // {
    //  console.log("Multi Dimensional Array Pointsloop==>",kMeansObject1[i].points);
    // }

    /*console.log("JJJJJJJJJJJJJ");
  var data = [[1, 2, 3],[45,65,23], [69, 10, 25]];

  var km = new kMeans({  K: 8 });

  km.cluster(data);
  while (km.step()) {
      km.findClosestCentroids();
      km.moveCentroids();
.
      console.log(km.centroids);

      if(km.hasConverged()) break;
  }

  console.log('Finished in:', km.currentIteration, ' iterations');
  console.log(km.centroids, km.clusters);
  */
}
// new Role({
//     name: "Clinician",
//     description: "Clinician Portal",
//     status: true,
//     is_deleted: false
// }).save(function(err, data) {
//     console.log(err, 'Error');
//     console.log(data, 'Data');
// });
