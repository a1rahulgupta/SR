'use strict';

var mongoose = require('mongoose'),
    config = require('../../config/config.js'),
    crypto = require('crypto'),
    validator = require('../../config/validator.js'),
    utility = require('../lib/utility.js'),
    async = require('async'),
    EmailTemplate = mongoose.model('EmailTemplate'),
    fs = require('fs'),
    path = require('path'),
    twilio = require('../lib/twilio'),
    constantsObj = require('../lib/constants'),
    common = require('../../config/common.js');


module.exports = {
    getAllEmailTemplates: getAllEmailTemplates,
    getEmailTemplateById: getEmailTemplateById,
    updateEmailTemplate: updateEmailTemplate
};

function getAllEmailTemplates(req, res) {
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
    var condition = { is_deleted: false };
    var condition = {};
    var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
    if (req.body.searchText) {
        condition.$or = [{ 'unique_keyword': new RegExp(searchText, 'gi') },
            { 'subject': new RegExp(searchText, 'gi') },
            { 'title': new RegExp(searchText, 'gi') },
        ];
    }
    condition.is_deleted = false;
    console.log(condition, "condition");
    EmailTemplate.find(condition).count().exec(function(err, totalCount) {
        if (err) {
            res.json({
                'code': 402,
                'message': 'Email Template data not found'
            })
        } else {
            EmailTemplate.find(condition)
                .limit(parseInt(count))
                .skip(parseInt(skip))
                .sort(sorting)
                .lean().exec(function(err, data) {
                    if (err) {
                        res.json({
                            'code': 402,
                            'message': 'Email Template data not found'
                        })
                    } else {
                        res.json({
                            'code': 200,
                            'data': data,
                            'totalCount': totalCount
                        })
                    }
                })
        }
    })
}

function getEmailTemplateById(req, res) {
    var id = req.swagger.params.id.value;
    EmailTemplate.findOne({ _id: id }).exec(function(err, data) {
        if (err) {
            console.log("err", err);
            res.json({
                'code': 402,
                'message': 'No record found'
            });
        } else {
            res.json({
                code: 200,
                data: data
            });
        }
    })

}

function updateEmailTemplate(req, res) {
    var body = req.body;
    console.log("body", body);
    if (!validator.isValid(body.title)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        EmailTemplate.findOne({ _id: body._id }).exec(function(err, emailTemplate) {
            if (err) {
                res.json({
                    'code': 402,
                    'message': 'EmailTemplate data not found'
                })
            } else {
                emailTemplate.title = body.title;
                emailTemplate.subject = body.subject;
                emailTemplate.description = body.description;
                emailTemplate.save(function(err, appointmentData) {
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Unable to save user'
                        });
                    } else {
                        res.json({
                            'code': 200,
                            'message': 'Email Template updated successfully'
                        })
                    }
                });
            }
        });
    }
}


// new EmailTemplate({
//     title: "Confirm Appointment",
//     unique_keyword: "103",
//     subject: "Confirm Appointment",
//     description: "Confirm Appointment",
//     status: true,
//     is_deleted: false
// }).save(function(err, data) {
//     console.log(err, 'Error');
//     console.log(data, 'Data');
// });
