'use strict';

var mongoose = require('mongoose'),
    co = require('co'),
    config = require('../../config/config.js'),
    validator = require('../../config/validator.js'),
    constantsObj = require('../lib/constants'),
    algorithm = constantsObj.config.cryptoAlgorithm,
    password = constantsObj.config.cryptoPassword,
    Device = mongoose.model('Device'),
    Patient = mongoose.model('Patient'),
    Role = mongoose.model('Role'),
    User = mongoose.model('User'),
    Hospital = mongoose.model('Hospital'),
    Clinician = mongoose.model('Clinician'),
    HospitalAssign = mongoose.model('HospitalAssign'),
    CareCoordinator = mongoose.model('CareCoordinator'),
    EmailMessage = mongoose.model('EmailMessage'),
    SmsTemplate = mongoose.model('SmsTemplate'),
    Towing = mongoose.model('Towing'),
    Ambulance = mongoose.model('Ambulance'),
    co = require('co'),
    crypto = require('crypto'),
    utility = require('../lib/utility.js'),
    async = require('async'),
    fs = require('fs'),
    constant = require('../lib/constants'),
    mailer = require('../lib/mailer'),
    path = require('path'),
    common = require('../../config/common.js');

var moment = require('moment');

module.exports = {
    getAllHospital: getAllHospital,
    deleteHospitalById: deleteHospitalById,
    addHospitalByAdmin: addHospitalByAdmin,
    updateHospitalByAdmin: updateHospitalByAdmin,
    getHospitalByAdminId: getHospitalByAdminId,
    enableDisableHospital: enableDisableHospital,
    getHospitalDetails: getHospitalDetails,
    updateHospitalProfile: updateHospitalProfile,
    getHospital: getHospital,
    getAllPatientByHospital: getAllPatientByHospital,
    addPatientByHospital: addPatientByHospital,
    addClinicianByHospital: addClinicianByHospital,
    getAllClinicianByHospital: getAllClinicianByHospital,
    addCareCoordinatorByHospital: addCareCoordinatorByHospital,
    getAllCareCoordinatorByHospital: getAllCareCoordinatorByHospital,
    getAllRoleList: getAllRoleList,
    getUserListbyRole: getUserListbyRole,
    assignUsers: assignUsers,
    getAssignUsersByHospital: getAssignUsersByHospital,
    deleteAssignUsersByHospital: deleteAssignUsersByHospital,
    addAmbulanceByHospital: addAmbulanceByHospital,
    getAllAmbulanceByHospital: getAllAmbulanceByHospital,
    addTowingByHospital: addTowingByHospital,
    getAllTowingByHospital: getAllTowingByHospital,
    getAllEntitiesLinkedToHospital: getAllEntitiesLinkedToHospital,
    getPatientListForDevice: getPatientListForDevice,
    addPatientDeviceByHospital: addPatientDeviceByHospital,
    getDeviceListForHospital: getDeviceListForHospital,
    viewDeviceListForPatient: viewDeviceListForPatient,
    addEmailMessage: addEmailMessage,
    getEmailMesssageList: getEmailMesssageList,
    getEmailMesssageById: getEmailMesssageById,
    deleteEmailMessage: deleteEmailMessage,

    addSmsTemplate: addSmsTemplate,
    getSmsTemplateList: getSmsTemplateList,
    getSmsTemplateById: getSmsTemplateById,
    deleteSmsTemplate: deleteSmsTemplate,

    getSmsTemplateListforPatient: getSmsTemplateListforPatient,
    getSmsTemplateListforClinician: getSmsTemplateListforClinician,
    getSmsTemplateListforCareCoordinator: getSmsTemplateListforCareCoordinator,
    getSmsTemplateListforAmbulance: getSmsTemplateListforAmbulance,
    getSmsTemplateListforTowing: getSmsTemplateListforTowing,

    getEmailMesssageListforPatient: getEmailMesssageListforPatient,
    getEmailMesssageListforClinician: getEmailMesssageListforClinician,
    getEmailMesssageListforCareCoordinator: getEmailMesssageListforCareCoordinator,
    getEmailMesssageListforTowing: getEmailMesssageListforTowing,
    getEmailMesssageListforAmbulance: getEmailMesssageListforAmbulance,
    reAssignUsers: reAssignUsers,
    getHospitalCount:getHospitalCount

};


/**
 * Function is use to Get Hospital List
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 21-june-2017
 */
function getAllHospital(req, res) {
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
    for (var key in req.body) {
        var reg = new RegExp("sorting", 'gi');
        if (reg.test(key)) {
            var value = req.body[key];
            key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
            var sorting = {};
            if (value == 1 || value == -1) {
                sorting[key] = value;
            } else {
                sorting[key] = (value == 'desc') ? -1 : 1;
            }
        }
    }
    var condition = {};
    var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");

    console.log("searchText", searchText);
    if (req.body.searchText) {
        condition.$or = [{ 'hospital_npi_no': new RegExp(searchText, 'gi') },
        { 'hospital_name': new RegExp(searchText, 'gi') },
        { 'hospital_address': new RegExp(searchText, 'gi') },
        { 'hospital_mobile_no': new RegExp(searchText, 'gi') },
        ];
    }
    condition.is_deleted = false;
    Hospital.find(condition)
        .sort(sorting)
        .skip(parseInt(skip))
        .limit(parseInt(count))
        .lean().exec(function (err, hospital) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (hospital) {
                Hospital.find(condition)
                    .count()
                    .exec(function (err, totalCount) {
                        if (err) {
                            res.json({
                                code: 404,
                                message: 'TotalCount Not Correct'
                            })
                        } else {
                            console.log("totalCount", totalCount)
                            res.json({
                                code: 200,
                                message: constantsObj.messages.hospitalsGetSuccessfully,
                                data: hospital,
                                totalCount: totalCount
                            })

                        }
                    });
            } else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        }).catch(function (err) {
            return res.json(Response(402, utility.validationErrorHandler(err), err));
        })
}


function getHospitalCount(req, res) {
    co(function* () {
        let hospitalCount = yield Hospital.find({ is_deleted: false }).count().exec();
        res.json({
            code: 200,
            data: hospitalCount
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));

    })
}

/**
 * Function is use to Delete Hospital By Id 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 24-June-2017
 */
function deleteHospitalById(req, res) {
    console.log("req.swagger.params.id.value", req.swagger.params.id.value);
    var id = req.swagger.params.id.value;
    co(function* () {
        let hospitalData = yield Hospital.findById(id);
        if (hospitalData) {
            var hospitalInfo = hospitalData;
            console.log("hospitaldelete");
            hospitalData.is_deleted = true;
            let hospitalDelete = yield hospitalData.save();
            let userData = yield User.findById(hospitalInfo.user_id);
            if (userData) {
                console.log("userdelete");
                userData.is_deleted = true;
                let userDelete = yield userData.save();
            } else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.userDeletedFailed
                })
            }
            console.log("response delete");
            res.json({
                code: 200,
                message: constantsObj.messages.userDeletedSuccess
            })
        } else {
            return res.json(Response(402, constantsObj.messages.noRecordFound, err));
        }
    }).catch(function (err) {
        return res.json(Response(404, utility.validationErrorHandler(err), err));
    });
}


function addHospitalByAdmin(req, res) {
    var body = req.body;
    console.log("body", body);
    if (!validator.isValid(body.hospital_name) || !validator.isValid(body.hospital_address) || !validator.isValid(body.hospital_city) || !validator.isValid(body.hospital_state) || !validator.isValid(body.hospital_zip_code) || !validator.isValid(body.hospital_mobile_no) || !validator.isValid(body.email)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        Role.findOne({ name: 'Hospital', is_deleted: false, status: true }).exec(function (err, group) {
            console.log("group", group);
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Something went wrong please try again!'
                });
            } else if (group) {
                console.log("group", group);

                User.findOne({ email: body.email, is_deleted: false }).exec(function (err, exist) {
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Something went wrong please try again!'
                        });
                    } else {
                        if (exist) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Hospital Name with this email already exist please try another!'
                            });
                        } else {

                            var user = new User();
                            user.email = body.email;
                            var randompass = common.randomToken(8);
                            user.role_id = group._id;
                            user.setPassword(randompass);
                            user.save(function (err, userData) {
                                if (err) {
                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Unable to save user'
                                    });
                                } else {

                                    console.log("in user save");
                                    var hospital = new Hospital();
                                    hospital.hospital_npi_no = body.hospital_npi_no;
                                    hospital.user_id = userData._id;
                                    hospital.hospital_name = body.hospital_name;
                                    hospital.hospital_address = body.hospital_address;
                                    hospital.hospital_city = body.hospital_city;
                                    hospital.hospital_state = body.hospital_state;
                                    hospital.hospital_zip_code = body.hospital_zip_code;
                                    hospital.hospital_country = body.hospital_country;
                                    hospital.hospital_mobile_no = body.hospital_mobile_no;
                                    hospital.save(function (err) {
                                        if (err) {
                                            res.json({
                                                'code': config.httpUnauthorize,
                                                'message': 'Unable to save user'
                                            });
                                        } else {
                                            var userMailData = {
                                                hospital_name: body.hospital_name,
                                                email: body.email,
                                                password: randompass,
                                            };

                                            mailer.sendMail(body.email, constant.emailKeyword.WelComeEmailHospital, userMailData, function (err, resp) {
                                                if (err) {
                                                    res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                                } else {
                                                    res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                }
                                            });
                                            console.log("in hospital save");
                                            res.json({
                                                'code': config.httpSuccess,
                                                'message': 'Hospital saved successfully'
                                            });
                                        }
                                    })


                                }
                            });
                        }
                    }
                });
            } else {
                res.json({
                    'code': 402,
                    'message': 'No record found'
                });
            };
        })
    }
}

function updateHospitalByAdmin(req, res) {
    console.log("body", req.body);
    var body = req.body;
    if (!validator.isValid(body.hospital_name) || !validator.isValid(body.hospital_address) || !validator.isValid(body.hospital_city) || !validator.isValid(body.hospital_state) || !validator.isValid(body.hospital_zip_code) || !validator.isValid(body.hospital_mobile_no) || !validator.isValid(body.email)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        Role.findOne({ name: 'Hospital', is_deleted: false, status: true }).exec(function (err, group) {
            console.log("group", group);
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Something went wrong please try again!'
                });
            } else if (group) {
                console.log("group", group);

                User.findOne({ email: body.email, _id: { $ne: body.userId }, is_deleted: false }).exec(function (err, exist) {
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Something went wrong please try again!'
                        });
                    } else {
                        if (exist) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Hospital Name with this email already exist please try another!'
                            });
                        } else {

                            User.findOne({ email: body.email, is_deleted: false }).exec(function (err, user) {
                                if (err) {
                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Unable to get user'
                                    });
                                } else {
                                    Hospital.findOne({ _id: body._id }).exec(function (err, hospital) {
                                        if (err) {
                                            res.json({
                                                'code': config.httpUnauthorize,
                                                'message': 'Unable to get user'
                                            });
                                        } else {


                                            user.email = body.email;
                                            user.role_id = group._id;
                                            user.save(function (err, userData) {
                                                if (err) {
                                                    res.json({
                                                        'code': config.httpUnauthorize,
                                                        'message': 'Unable to save user'
                                                    });
                                                } else {

                                                    console.log("in user save");
                                                    hospital.hospital_npi_no = body.hospital_npi_no;
                                                    hospital.user_id = userData._id;
                                                    hospital.hospital_name = body.hospital_name;
                                                    hospital.hospital_address = body.hospital_address;
                                                    hospital.hospital_city = body.hospital_city;
                                                    hospital.hospital_state = body.hospital_state;
                                                    hospital.hospital_zip_code = body.hospital_zip_code;
                                                    hospital.hospital_country = body.hospital_country;
                                                    hospital.hospital_mobile_no = body.hospital_mobile_no;
                                                    hospital.save(function (err) {
                                                        if (err) {
                                                            res.json({
                                                                'code': config.httpUnauthorize,
                                                                'message': 'Unable to save user'
                                                            });
                                                        } else {
                                                            console.log("in hospital save");
                                                            res.json({
                                                                'code': config.httpSuccess,
                                                                'message': 'Hospital saved successfully'
                                                            });
                                                        }
                                                    })


                                                }
                                            });
                                        }
                                    });
                                }
                            });
                        }
                    }
                });
            } else {
                res.json({
                    'code': 402,
                    'message': 'No record found'
                });
            };
        })
    }
}

function getHospitalByAdminId(req, res) {
    var id = req.swagger.params.id.value;
    Hospital.findOne({ _id: id }).populate('user_id').exec(function (err, data) {
        if (err) {
            res.json({
                'code': 402,
                'message': 'No record found'
            });
        } else {
            res.json({
                code: 200,
                data: data
            });
        }
    })
}
/**
 * Function is use to Enable Disable Hospital
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-June-2017
 */
function enableDisableHospital(req, res) {
    if (!req.body.userId || req.body.status == null) {
        res.json({
            code: 402,
            status: 'failed',
            message: constantsObj.validationMessages.requiredFieldsMissing
        });
    } else {
        Hospital.findById(req.body.userId).exec(function (err, data) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else {
                if (!data) {
                    res.json({ 'code': 402, status: 'failed', message: constantsObj.validationMessages.userNotFound });
                } else {
                    data.status = req.body.status;
                    data.save(function (err) {
                        if (err) {
                            res.json({
                                code: 404,
                                message: utility.validationErrorHandler(err)
                            });
                        } else {
                            User.findById(data.user_id).exec(function (err, userData) {
                                if (err) {
                                    res.json({
                                        code: 404,
                                        message: utility.validationErrorHandler(err)
                                    });
                                } else if (userData) {
                                    userData.status = req.body.status;
                                    userData.save(function (err) {
                                        if (err) {
                                            res.json({
                                                code: 404,
                                                message: utility.validationErrorHandler(err)
                                            });
                                        } else {
                                            res.json({ 'code': 200, status: 'success', "message": 'Patient ' + ((req.body.status == true) ? 'activated' : 'deactivated') + ' successfully' })
                                        }
                                    })

                                } else {
                                    res.json({ 'code': 402, status: 'failed', message: constantsObj.validationMessages.userNotFound });
                                }
                            })
                        }
                    })

                }
            }
        })
    }
}

function getHospitalDetails(req, res) {
    console.log("-------", req.user.id);
    Hospital.findOne({ user_id: req.user.id }).populate('user_id').lean().exec(function (err, data) {
        if (err) {
            res.json({
                'code': 402,
                'message': 'Hospital data not found'
            })
        } else {
            res.json({
                'code': 200,
                'data': data
            })
        }
    })
}


function updateHospitalProfile(req, res) {
    var timestamp = Number(new Date()); // current time as number
    console.log(req.body);
    var file = req.swagger.params.file.value;
    var hospital_npi_no = req.swagger.params.hospital_npi_no.value;
    var hospital_name = req.swagger.params.hospital_name.value;
    var hospital_address = req.swagger.params.hospital_address.value;
    var hospital_city = req.swagger.params.hospital_city.value;
    var hospital_state = req.swagger.params.hospital_state.value;
    var hospital_zip_code = req.swagger.params.hospital_zip_code.value;
    var hospital_country = req.swagger.params.hospital_country.value;
    var hospital_mobile_no = req.swagger.params.hospital_mobile_no.value;
    //console.log("first_name", first_name);
    var user_id = req.user.id;
    if (file) {
        var splitFile = file.originalname.split('.');
        var filename = +timestamp + '_' + common.randomToken(6) + '.' + ((splitFile.length > 0) ? splitFile[splitFile.length - 1] : file.originalname);
        var imagePath = "./public/assets/uploads/profile/" + filename;
    }
    var obj = {};
    obj.hospital_npi_no = hospital_npi_no;
    obj.hospital_name = hospital_name;
    obj.hospital_address = hospital_address;
    obj.hospital_city = hospital_city;
    obj.hospital_state = hospital_state;
    obj.hospital_zip_code = hospital_zip_code;
    obj.hospital_country = hospital_country;
    obj.hospital_mobile_no = hospital_mobile_no;
    obj.file = file;
    // utility.fileUpload(imagePath, file.buffer).then(function() {
    function update() {
        Hospital.findOne({ user_id: user_id }).then(function (hospital) {
            if (filename) {
                hospital.image = "assets/uploads/profile/" + filename;
            }
            hospital.hospital_npi_no = hospital_npi_no;
            hospital.hospital_name = hospital_name;
            hospital.hospital_address = hospital_address;
            hospital.hospital_city = hospital_city;
            hospital.hospital_state = hospital_state;
            hospital.hospital_zip_code = hospital_zip_code;
            hospital.hospital_country = hospital_country;
            hospital.hospital_mobile_no = hospital_mobile_no;
            if (hospital.image) {
                hospital.image = hospital.image;
            }
            hospital.save(function (err, ItemImage) {
                if (err) {
                    res.json({ code: 500, message: constantsObj.validationMessages.internalError });
                } else {
                    res.json({ code: 200, message: 'Profile updated successfully' });
                }
            });

        }).catch(function (err) {
            console.log("err", err);
            res.json({ code: 500, message: constantsObj.validationMessages.internalError, data: err });
        });
    }
    if (file) {
        fs.writeFile(path.resolve(imagePath), file.buffer, function (err) {
            if (err) {
                res.json({ code: 402, 'message': 'Request could not be processed. Please try again.', data: {} });
            } else {
                update();
            }
        });
    } else {
        update();
    }
}

function getHospital(req, res) {
    Hospital.find({ is_deleted: false, status: true }).lean().exec(function (err, hospitalData) {
        if (err) {
            res.json({
                code: 402,
                message: 'internal Error'
            })
        } else if (hospitalData) {
            res.json({
                code: 200,
                message: 'Hospitals get successfully',
                data: hospitalData
            })
        } else {
            res.json({
                code: 200,
                message: 'No record found'
            })
        }
    })
}

function encrypt(encText) {
    var cipher = crypto.createCipher(algorithm, password)
    var encText = cipher.update(encText, 'utf8', 'hex')
    encText += cipher.final('hex');
    return encText;
}

/**
 * Function is use to Get Patient List
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 6-june-2017
 */
function getAllPatientByHospital(req, res) {
    co(function* () {
        console.log("bjhghghb", req.user);
        console.log("req.user.id", req.user.id);
        let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
        console.log("-----hospitalInfo----", hospitalInfo);
        var count = req.body.count ? req.body.count : 0;
        var skip = req.body.count * (req.body.page - 1);
        var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        var condition = {};
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");

        console.log("searchText", searchText);
        if (req.body.searchText) {
            var searchText = encrypt(searchText);
            condition.$or = [{ 'SSN': new RegExp(searchText, 'gi') },
            { 'first_name': new RegExp(searchText, 'gi') },
            { 'last_name': new RegExp(searchText, 'gi') },
            { 'mobile_no': new RegExp(searchText, 'gi') },
            ];
        }
        condition.is_deleted = false;
        if (hospitalInfo) {
            condition.hospital_id = hospitalInfo._id;
        }
        console.log("condition", condition);
        Patient.find(condition)
            .sort(sorting)
            .skip(parseInt(skip))
            .limit(parseInt(count))
            .lean().exec(function (err, patient) {
                if (err) {
                    res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
                } else if (patient) {
                    Patient.find(condition)
                        .count()
                        .exec(function (err, totalCount) {
                            if (err) {
                                res.json({
                                    code: 404,
                                    message: 'TotalCount Not Correct'
                                })
                            } else {
                                console.log("totalCount", totalCount);
                                var newArr = [];
                                var filed = ['user_id', 'clinician_id', 'coordinator_id', 'DOB', 'image', 'country', 'hospital_id'];
                                utility.decryptedRecord(patient, filed, function (newArr) {
                                    console.log("newArr", newArr);
                                    res.json({
                                        code: 200,
                                        message: constantsObj.messages.patientsGetSuccessfully,
                                        data: newArr,
                                        totalCount: totalCount
                                    })
                                })
                            }
                        });
                } else {
                    res.json({
                        code: 404,
                        message: constantsObj.messages.noDataFound
                    })
                }
            }).catch(function (err) {
                return res.json(Response(402, utility.validationErrorHandler(err), err));
            })

    }).catch(function (err) {
        console.log("getVisitById Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}

/**
 * Function is use to Get Patient List
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 6-june-2017
 */
function addPatientByHospital(req, res) {
    co(function* () {
        var body = req.body;
        if (!validator.isValid(body.first_name) || !validator.isValid(body.last_name) || !validator.isValid(body.mobile_no) || !validator.isValid(body.email)) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Required fields are missing'
            });
        } else {
            let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
            Role.findOne({ name: 'Patient', is_deleted: false, status: true }).exec(function (err, group) {
                if (err) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Something went wrong please try again!'
                    });
                } else if (group) {
                    User.findOne({ email: body.email, is_deleted: false }).exec(function (err, exist) {
                        console.log("--------------------->>>>>>", exist);
                        if (err) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Something went wrong please try again!'
                            });
                        } else {
                            if (exist) {
                                res.json({
                                    'code': config.httpUnauthorize,
                                    'message': 'Patient Name with this email already exist please try another!'
                                });
                            } else {
                                console.log("aaaaaaaa", body);
                                //return;

                                var user = new User();
                                var randompass = common.randomToken(8);
                                user.email = body.email;
                                user.role_id = group._id;
                                user.setPassword(randompass);
                                user.save(function (err, userData) {
                                    if (err) {
                                        res.json({
                                            'code': config.httpUnauthorize,
                                            'message': 'Unable to save user'
                                        });
                                    } else {
                                        var patientObj = {};
                                        var field = ['user_id', 'clinician_id', 'coordinator_id', 'DOB', 'hospital_id', 'smoker', 'diabetes', 'bp_treatment']
                                        var obj = req.body;
                                        obj.user_id = userData._id;
                                        utility.encryptedRecord(obj, field, function (patientObj) {
                                            var patient = new Patient(patientObj);
                                            if (hospitalInfo) {
                                                patient.hospital_id = hospitalInfo._id;
                                            }
                                            patient.save(function (err, patientData) {
                                                if (err) {
                                                    res.json({
                                                        code: 404,
                                                        message: utility.validationErrorHandler(err)
                                                    });
                                                    console.log(err)
                                                } else {
                                                    var userMailData = {
                                                        first_name: body.first_name,
                                                        last_name: body.last_name,
                                                        password: randompass,
                                                        email: body.email
                                                    };
                                                    co(function* () {
                                                        let roleInfo = yield Role.findOne({ "name": "Hospital", is_deleted: false, status: true }).exec();
                                                        if (roleInfo) {
                                                            var assignHospitalData = {
                                                                "role_id": roleInfo._id,
                                                                "assign_id": req.body.hospital_id,
                                                                "patient_id": patientData._id,
                                                            }
                                                            console.log("assignHospitalData--->", assignHospitalData);
                                                            var assign = new HospitalAssign(assignHospitalData);
                                                            assign.save(function (err, data) {
                                                                if (err) {

                                                                } else {

                                                                }
                                                            });
                                                        }
                                                    });
                                                    mailer.sendMail(body.email, constant.emailKeyword.WelComeEmail, userMailData, function (err, resp) {
                                                        if (err) {
                                                            res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                                        } else {
                                                            res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                        }
                                                    });
                                                    res.json({
                                                        code: 200,
                                                        message: constantsObj.messages.patientCreatedSuccess,
                                                        data: patientData
                                                    });
                                                }

                                            });
                                        })
                                    }
                                });
                            }
                        }
                    });
                } else {
                    res.json({
                        'code': 402,
                        'message': 'No record found'
                    });
                };
            })
        }
    }).catch(function (err) {
        console.log("getVisitById Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}



/**
 * Function is use to add Clinician
 * @access private
 * @return json
 * Created by Akshay
 * @smartData Enterprises (I) Ltd
 * Created Date 17-July-2017
 */
function addClinicianByHospital(req, res) {
    co(function* () {
        var body = req.body;
        console.log("body", body);
        if (!validator.isValid(body.first_name) || !validator.isValid(body.last_name) || !validator.isValid(body.address) || !validator.isValid(body.city) || !validator.isValid(body.state) || !validator.isValid(body.country) || !validator.isValid(body.zip_code) || !validator.isValid(body.mobile_no) || !validator.isValid(body.SSN) || !validator.isValid(body.email) || !validator.isValid(body.clinician_npi_no)) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Required fields are missing'
            });
        } else if (req.body.id) {
            Clinician.findOne({ _id: req.body.id, is_deleted: false }).exec(function (err, group) {
                if (err) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Something went wrong please try again!'
                    });
                } else if (group) {
                    User.findOne({ _id: group.user_id }).exec(function (err, exist) {
                        if (err) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Something went wrong please try again!'
                            });
                        } else {
                            if (exist) {
                                exist.email = body.email;
                                exist.save(function (err, userData) {
                                    if (err) {
                                        res.json({
                                            'code': config.httpUnauthorize,
                                            'message': 'Unable to Update clinician'
                                        });
                                    } else {
                                        group.clinician_npi_no = body.clinician_npi_no;
                                        group.first_name = body.first_name;
                                        group.last_name = body.last_name;
                                        group.SSN = body.SSN;
                                        group.address = body.address;
                                        group.city = body.city;
                                        group.state = body.state;
                                        group.zip_code = body.zip_code;
                                        group.country = body.country;
                                        group.hospital_id = body.hospital_id;
                                        group.mobile_no = body.mobile_no;
                                        group.save(function (err) {
                                            if (err) {
                                                res.json({
                                                    'code': config.httpUnauthorize,
                                                    'message': 'Unable to Update clinician'
                                                });
                                            } else {
                                                console.log("in Clinician Update");
                                                res.json({
                                                    'code': config.httpSuccess,
                                                    'message': 'Clinician Update successfully'
                                                });
                                            }
                                        })
                                    }
                                })
                            }
                        }
                    })
                } else {
                    res.json({
                        'code': 402,
                        'message': 'No record found'
                    });
                };
            })
        } else {
            let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
            Role.findOne({ name: 'Clinician', is_deleted: false, status: true }).exec(function (err, group) {
                console.log("group", group);
                if (err) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Something went wrong please try again!'
                    });
                } else if (group) {
                    console.log("group", group);

                    User.findOne({ email: body.email }).exec(function (err, exist) {
                        if (err) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Something went wrong please try again!'
                            });
                        } else {
                            if (exist) {
                                res.json({
                                    'code': config.httpUnauthorize,
                                    'message': 'Clinician Name with this email already exist please try another!'
                                });
                            } else {

                                var user = new User();
                                var randompass = common.randomToken(8);
                                user.email = body.email;
                                user.role_id = group._id;
                                user.setPassword(randompass);

                                user.save(function (err, userData) {
                                    if (err) {
                                        res.json({
                                            'code': config.httpUnauthorize,
                                            'message': 'Unable to save clinician'
                                        });
                                    } else {

                                        console.log("in user save");
                                        var clinician = new Clinician();
                                        clinician.clinician_npi_no = body.clinician_npi_no;
                                        clinician.user_id = userData._id;
                                        clinician.first_name = body.first_name;
                                        clinician.last_name = body.last_name;
                                        clinician.SSN = body.SSN;
                                        clinician.address = body.address;
                                        clinician.city = body.city;
                                        clinician.state = body.state;
                                        clinician.zip_code = body.zip_code;
                                        clinician.country = body.country;
                                        clinician.mobile_no = body.mobile_no;
                                        if (hospitalInfo) {
                                            clinician.hospital_id = hospitalInfo._id;
                                        }
                                        clinician.save(function (err) {
                                            if (err) {
                                                res.json({
                                                    'code': config.httpUnauthorize,
                                                    'message': 'Unable to save clinician'
                                                });
                                            } else {
                                                var userMailData = {
                                                    first_name: body.first_name,
                                                    last_name: body.last_name,
                                                    email: body.email,
                                                    password: randompass,
                                                };

                                                mailer.sendMail(body.email, constant.emailKeyword.WelComeEmail, userMailData, function (err, resp) {
                                                    if (err) {
                                                        res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                                    } else {
                                                        res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                    }
                                                });
                                                console.log("in Clinician save");
                                                res.json({
                                                    'code': config.httpSuccess,
                                                    'message': 'Clinician saved successfully'
                                                });
                                            }
                                        })


                                    }
                                });
                            }
                        }
                    });
                } else {
                    res.json({
                        'code': 402,
                        'message': 'No record found'
                    });
                };
            })
        }
    }).catch(function (err) {
        console.log("getVisitById Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}



/**
 * Function is use to Get Clinician List
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 05-Feb-2018
 */

function getAllClinicianByHospital(req, res) {
    co(function* () {
        let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
        var count = req.body.count ? req.body.count : 0;
        var skip = req.body.count * (req.body.page - 1);
        var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        var condition = {};
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (req.body.searchText) {
            condition.$or = [{ 'SSN': new RegExp(searchText, 'gi') },
            { 'clinician_npi_no': new RegExp(searchText, 'gi') },
            { 'first_name': new RegExp(searchText, 'gi') },
            { 'last_name': new RegExp(searchText, 'gi') },
            { 'mobile_no': new RegExp(searchText, 'gi') },
            ];
        }
        condition.is_deleted = false;
        if (hospitalInfo) {
            condition.hospital_id = hospitalInfo._id;
        }
        console.log(condition, "condition");
        Clinician.find(condition).count().exec(function (err, totalCount) {
            if (err) {
                res.json({
                    'code': 402,
                    'message': 'Email Template data not found'
                })
            } else {
                Clinician.find(condition)
                    .sort(sorting)
                    .skip(parseInt(skip))
                    .limit(parseInt(count))
                    .lean().exec(function (err, data) {
                        if (err) {
                            res.json({
                                'code': 402,
                                'message': 'Email Template data not found'
                            })
                        } else {
                            res.json({
                                'code': 200,
                                'data': data,
                                'totalCount': totalCount
                            })
                        }
                    })
            }
        })
    }).catch(function (err) {
        console.log("getVisitById Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}



/**
 * Function is use to Get Care Coordinator List
 * @access private
 * @return json
 * Created by Akshay
 * @smartData Enterprises (I) Ltd
 * Created Date 17-july-2017
 */
function getAllCareCoordinatorByHospital(req, res) {
    co(function* () {
        let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
        var count = req.body.count ? req.body.count : 0;
        var skip = req.body.count * (req.body.page - 1);
        var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        var condition = {};
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");

        console.log("searchText", searchText);
        if (req.body.searchText) {
            condition.$or = [{ 'SSN': new RegExp(searchText, 'gi') },
            { 'careCoordinator_npi_no': new RegExp(searchText, 'gi') },
            { 'first_name': new RegExp(searchText, 'gi') },
            { 'last_name': new RegExp(searchText, 'gi') },
            { 'mobile_no': new RegExp(searchText, 'gi') },
            ];
        }
        condition.is_deleted = false;
        if (hospitalInfo) {
            condition.hospital_id = hospitalInfo._id;
        }
        CareCoordinator.find(condition)
            .sort(sorting)
            .skip(parseInt(skip))
            .limit(parseInt(count))
            .lean().exec(function (err, careCoordinator) {
                if (err) {
                    res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
                } else if (careCoordinator) {
                    CareCoordinator.find(condition)
                        .count()
                        .exec(function (err, totalCount) {
                            if (err) {
                                res.json({
                                    code: 404,
                                    message: utility.validationErrorHandler(err)
                                });
                            } else {
                                console.log("totalCount", totalCount)
                                res.json({
                                    code: 200,
                                    message: constantsObj.messages.careCoordinatorGetSuccessfully,
                                    data: careCoordinator,
                                    totalCount: totalCount
                                })

                            }
                        });
                } else {
                    res.json({
                        code: 404,
                        message: constantsObj.messages.noDataFound
                    })
                }
            })
    }).catch(function (err) {
        console.log("getVisitById Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}


/**
 * Function is use to Add care Coordinator 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 24-June-2017
 */
function addCareCoordinatorByHospital(req, res) {
    co(function* () {
        var body = req.body;
        console.log("body", body);
        if (!validator.isValid(body.first_name) || !validator.isValid(body.last_name) || !validator.isValid(body.address) || !validator.isValid(body.city) || !validator.isValid(body.state) || !validator.isValid(body.country) || !validator.isValid(body.zip_code) || !validator.isValid(body.mobile_no) || !validator.isValid(body.SSN) || !validator.isValid(body.email) || !validator.isValid(body.careCoordinator_npi_no)) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Required fields are missing'
            });
        } else if (req.body.id) {
            CareCoordinator.findOne({ _id: req.body.id, is_deleted: false }).exec(function (err, group) {
                if (err) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Something went wrong please try again!'
                    });
                } else if (group) {
                    User.findOne({ _id: group.user_id }).exec(function (err, exist) {
                        if (err) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Something went wrong please try again!'
                            });
                        } else {
                            if (exist) {
                                exist.email = body.email;
                                exist.save(function (err, userData) {
                                    if (err) {
                                        res.json({
                                            'code': config.httpUnauthorize,
                                            'message': 'Unable to Update Care Coordinator'
                                        });
                                    } else {
                                        group.careCoordinator_npi_no = body.careCoordinator_npi_no;
                                        group.first_name = body.first_name;
                                        group.last_name = body.last_name;
                                        group.SSN = body.SSN;
                                        group.address = body.address;
                                        group.city = body.city;
                                        group.state = body.state;
                                        group.zip_code = body.zip_code;
                                        group.country = body.country;
                                        group.mobile_no = body.mobile_no;
                                        group.save(function (err) {
                                            if (err) {
                                                res.json({
                                                    'code': config.httpUnauthorize,
                                                    'message': 'Unable to Update Care Coordinator'
                                                });
                                            } else {
                                                console.log("in Care Coordinator Update");
                                                res.json({
                                                    'code': config.httpSuccess,
                                                    'message': 'Care Coordinator Update successfully'
                                                });
                                            }
                                        })
                                    }
                                })
                            }
                        }
                    })
                } else {
                    res.json({
                        'code': 402,
                        'message': 'No record found'
                    });
                };
            })
        } else {
            let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
            Role.findOne({ name: 'CareCoordinator', is_deleted: false, status: true }).exec(function (err, group) {
                console.log("group", group);
                if (err) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Something went wrong please try again!'
                    });
                } else if (group) {
                    console.log("group", group);

                    User.findOne({ email: body.email }).exec(function (err, exist) {
                        if (err) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Something went wrong please try again!'
                            });
                        } else {
                            if (exist) {
                                res.json({
                                    'code': config.httpUnauthorize,
                                    'message': 'Care Coordinator Name with this email already exist please try another!'
                                });
                            } else {

                                var user = new User();
                                var randompass = common.randomToken(8);
                                user.email = body.email;
                                user.role_id = group._id;
                                user.setPassword(randompass);

                                user.save(function (err, userData) {
                                    if (err) {
                                        res.json({
                                            'code': config.httpUnauthorize,
                                            'message': 'Unable to save user'
                                        });
                                    } else {

                                        console.log("in user save");
                                        var careCoordinator = new CareCoordinator();
                                        careCoordinator.careCoordinator_npi_no = body.careCoordinator_npi_no;
                                        careCoordinator.user_id = userData._id;
                                        careCoordinator.first_name = body.first_name;
                                        careCoordinator.last_name = body.last_name;
                                        careCoordinator.SSN = body.SSN;
                                        careCoordinator.address = body.address;
                                        careCoordinator.city = body.city;
                                        careCoordinator.state = body.state;
                                        careCoordinator.zip_code = body.zip_code;
                                        careCoordinator.country = body.country;
                                        careCoordinator.mobile_no = body.mobile_no;
                                        if (hospitalInfo) {
                                            careCoordinator.hospital_id = hospitalInfo._id;
                                        }
                                        careCoordinator.save(function (err) {
                                            if (err) {
                                                res.json({
                                                    'code': config.httpUnauthorize,
                                                    'message': 'Unable to save user'
                                                });
                                            } else {
                                                var userMailData = {
                                                    first_name: body.first_name,
                                                    last_name: body.last_name,
                                                    email: body.email,
                                                    password: randompass
                                                };

                                                mailer.sendMail(body.email, constant.emailKeyword.WelComeEmail, userMailData, function (err, resp) {
                                                    if (err) {
                                                        res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                                    } else {
                                                        res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                    }
                                                });
                                                console.log("in CareCoordinator save");
                                                res.json({
                                                    'code': config.httpSuccess,
                                                    'message': 'Care Coordinator saved successfully'
                                                });
                                            }
                                        })


                                    }
                                });
                            }
                        }
                    });
                } else {
                    res.json({
                        'code': 402,
                        'message': 'No record found'
                    });
                };
            })
        }
    }).catch(function (err) {
        console.log("getVisitById Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}


/**
 * Function is use to Get Role
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 24-June-2017
 */
function getAllRoleList(req, res) {
    Role.find({ is_deleted: false, is_valid: true }).exec(function (err, result) {
        if (err) {
            res.json({
                code: 404,
                'message': 'unable to retrive'
            });
        } else if (result) {
            res.json({
                code: 200,
                'message': 'Get Role successfully',
                data: result
            });
        } else {
            res.json({
                code: 200,
                'message': 'No Data Found'
            });
        }
    }).catch(function (err) {
        console.log("error-------------->", err);
        return res.json({ code: 402, message: err, data: {} });
    });
}

/**
 * Function is use to Get Role
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 01-Feb-2018
 */

function getUserListbyRole(req, res) {
    console.log("swagger", req.swagger.params.id.value);
    var roleId = req.swagger.params.id.value;
    Role.findOne({ _id: roleId, is_deleted: false, status: true }).exec(function (err, roleData) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });

        } else if (roleData) {
            if (roleData.name == 'Clinician') {
                Hospital.findOne({ user_id: req.user.id }).exec(function (err, hospitalData) {
                    if (err) {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        });
                    } else if (hospitalData) {
                        Clinician.find({ hospital_id: hospitalData._id, status: true, is_deleted: false })
                            .exec(function (err, clinicianArray) {
                                if (err) {
                                    res.json({
                                        code: 404,
                                        message: utility.validationErrorHandler(err)
                                    });
                                } else if (clinicianArray) {
                                    console.log("clinicianArray", clinicianArray);
                                    return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": clinicianArray });
                                } else {
                                    res.json({
                                        code: 404,
                                        message: utility.validationErrorHandler(err)
                                    });
                                }
                            })
                    } else {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        });
                    }
                });
            } else if (roleData.name == 'Towing') {
                Hospital.findOne({ user_id: req.user.id }).exec(function (err, hospitalData) {
                    if (err) {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        });
                    } else if (hospitalData) {
                        Towing.find({ hospital_id: hospitalData._id, status: true, is_deleted: false })
                            .exec(function (err, clinicianArray) {
                                if (err) {
                                    res.json({
                                        code: 404,
                                        message: utility.validationErrorHandler(err)
                                    });
                                } else if (clinicianArray) {
                                    console.log("clinicianArray", clinicianArray);
                                    return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": clinicianArray });
                                } else {
                                    res.json({
                                        code: 404,
                                        message: utility.validationErrorHandler(err)
                                    });
                                }
                            })
                    } else {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        });
                    }
                });
            } else if (roleData.name == 'CareCoordinator') {
                Hospital.findOne({ user_id: req.user.id }).exec(function (err, hospitalData) {
                    if (err) {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        });
                    } else if (hospitalData) {
                        CareCoordinator.find({ hospital_id: hospitalData._id, status: true, is_deleted: false })
                            .exec(function (err, clinicianArray) {
                                if (err) {
                                    res.json({
                                        code: 404,
                                        message: utility.validationErrorHandler(err)
                                    });
                                } else if (clinicianArray) {
                                    console.log("clinicianArray", clinicianArray);
                                    return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": clinicianArray });
                                } else {
                                    res.json({
                                        code: 404,
                                        message: utility.validationErrorHandler(err)
                                    });
                                }
                            })
                    } else {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        });
                    }
                });
            } if (roleData.name == 'Ambulance') {
                Hospital.findOne({ user_id: req.user.id }).exec(function (err, hospitalData) {
                    if (err) {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        });
                    } else if (hospitalData) {
                        Ambulance.find({ hospital_id: hospitalData._id, status: true, is_deleted: false })
                            .exec(function (err, AmbulanceArray) {
                                if (err) {
                                    res.json({
                                        code: 404,
                                        message: utility.validationErrorHandler(err)
                                    });
                                } else if (AmbulanceArray) {
                                    console.log("AmbulanceArray", AmbulanceArray);
                                    return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": AmbulanceArray });
                                } else {
                                    res.json({
                                        code: 404,
                                        message: utility.validationErrorHandler(err)
                                    });
                                }
                            })
                    } else {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        });
                    }
                });
            }
        } else {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        }
    });

}


/**
 * Function is use to assign Users
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 01-Feb-2018
 */
function assignUsers(req, res) {
    var body = req.body;
    console.log("body", body)

    if (!validator.isValid(body.assign_id) || !validator.isValid(body.role_id) || !validator.isValid(body.patient_id)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        Hospital.findOne({ user_id: req.user.id }).lean().exec(function (err, hospitalData) {
            if (err) {
                console.log("err", err);
            } else {

                HospitalAssign.findOne({ role_id: body.role_id, patient_id: body.patient_id, is_deleted: false }).exec(function (err, exist) {
                    console.log("2121", exist);
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Something went wrong please try again!'
                        });
                    } else {
                        if (exist) {
                            res.json({
                                'code': config.httpBadRequest,
                                'message': 'Already Assign!',
                                data: exist
                            });
                        } else {
                            var assign = new HospitalAssign(body);
                            assign.user_id = hospitalData._id;
                            assign.save(function (err, data) {
                                if (err) {
                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Unable to assign Users'
                                    });
                                } else {
                                    res.json({
                                        'code': 200,
                                        'message': ' Assign successfully',
                                        data: data
                                    });
                                }
                            });
                        }
                    }
                })
            }
        });

    }
}

/**
 * Function is use to Update assignment of User
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 23-Feb-2018
 */
function reAssignUsers(req, res) {
    var body = req.body;


    if (!validator.isValid(body.role_id) || !validator.isValid(body.patient_id)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        Hospital.findOne({ user_id: req.user.id }).lean().exec(function (err, hospitalData) {
            if (err) {
                console.log("err", err);
            } else {

                HospitalAssign.findOne({ role_id: body.role_id, patient_id: body.patient_id, is_deleted: false }).exec(function (err, exist) {

                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Something went wrong please try again!',
                            data: exist
                        });
                    } else {
                        if (exist) {
                            exist.role_id = body.role_id;
                            exist.patient_id = body.patient_id;
                            exist.assign_id = body.assign_id;
                            exist.save(function (err, exist111) {
                                if (err) {

                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Unable to assign Users'
                                    });
                                } else {

                                    res.json({
                                        'code': 200,
                                        'message': ' Assign update successfully',
                                        data: exist111
                                    });
                                }
                            });
                        } else {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Unable to assign Users'
                            });
                        }
                    }
                })
            }
        });

    }
}

/**
 * Function is use to get Assign Users By Hospital
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 01-Feb-2018
 */

function getAssignUsersByHospital(req, res) {
    console.log("req.swagger.params.id.value);", req.swagger.params.id.value);
    co(function* () {
        let assignedUserList = yield HospitalAssign.find({ patient_id: req.swagger.params.id.value, is_deleted: false }).populate('role_id').lean().exec();
        console.log("before assignedUserList-->", assignedUserList);
        for (var i = 0; i < assignedUserList.length; i++) {
            console.log("assignedUserList[i]-->", assignedUserList[i]);
            if (assignedUserList[i].role_id && assignedUserList[i].role_id.name) {
                let roleType = assignedUserList[i].role_id.name;
                let assign_id = assignedUserList[i].assign_id;
                let userInfo = {};
                let info = {};
                let assignName = '';
                let assignMobileNo = '';
                let email = '';
                if (roleType == 'Clinician') {
                    userInfo = yield Clinician.findOne({ _id: assign_id }).lean();
                    if (userInfo) {
                        info = yield User.findOne({ _id: userInfo.user_id }).lean();
                        email = info.email;
                        userInfo.assignName = userInfo.first_name + "  " + userInfo.last_name;
                    }
                }
                else if (roleType == 'CareCoordinator') {
                    userInfo = yield CareCoordinator.findOne({ _id: assign_id }).lean();
                    console.log(" CareCoordinator fromUserInfo-->", userInfo);
                    if (userInfo) {
                        info = yield User.findOne({ _id: userInfo.user_id }).lean();
                        email = info.email;
                        userInfo.assignName = userInfo.first_name + "  " + userInfo.last_name;
                    }
                }
                else if (roleType == 'Ambulance') {
                    userInfo = yield Ambulance.findOne({ _id: assign_id }).lean();
                    console.log(" Ambulance fromUserInfo-->", userInfo);
                    if (userInfo) {
                        info = yield User.findOne({ _id: userInfo.user_id }).lean();
                        email = info.email;
                        userInfo.assignName = userInfo.company_name;
                    }
                }
                else if (roleType == 'Towing') {
                    userInfo = yield Towing.findOne({ _id: assign_id }).lean();
                    console.log(" Towing fromUserInfo-->", userInfo);
                    if (userInfo) {
                        info = yield User.findOne({ _id: userInfo.user_id }).lean();
                        email = info.email;
                        userInfo.assignName = userInfo.company_name;
                    }
                }
                else if (roleType == 'Hospital') {
                    userInfo = yield Hospital.findOne({ _id: assign_id }).lean();
                    console.log(" Hospital userInfo-->", userInfo);
                    if (userInfo) {
                        info = yield User.findOne({ _id: userInfo.user_id }).lean();
                        email = info.email;
                        userInfo.assignName = userInfo.hospital_name;
                        // userInfo.mobile_no = userInfo.hospital_mobile_no;
                    }
                }
                assignedUserList[i].assignInfo = userInfo;
                // if(userInfo.mobile_no){
                // assignedUserList[i].assignMobileNo = userInfo.mobile_no;
                // }
                assignedUserList[i].email = email;
            }
            console.log("assignedUserList[i]--->", assignedUserList[i]);
        }
        // console.log("assignedUserList--->", assignedUserList);
        return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": assignedUserList });
    }).catch(function (err) {
        console.log("getVisitById Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}
/**
 * Function is use to delete Assign Users By Hospital
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 5-Feb-2017
 */
function deleteAssignUsersByHospital(req, res) {
    var assignId = req.swagger.params.id.value;
    HospitalAssign.update({ _id: assignId }, { $set: { is_deleted: true } }, function (err) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else {
            res.json({
                code: 200,
                message: constantsObj.messages.assignUsersDeleteSuccess,
            })
        }
    })
}

/**
 * Function is use to add Ambulance
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 05-Feb-2018
 */

function addAmbulanceByHospital(req, res) {
    co(function* () {
        var body = req.body;
        console.log("body", body);
        if (!validator.isValid(body.address) || !validator.isValid(body.city) || !validator.isValid(body.state) || !validator.isValid(body.country) || !validator.isValid(body.zip_code) || !validator.isValid(body.mobile_no) || !validator.isValid(body.company_name) || !validator.isValid(body.email) || !validator.isValid(body.service_type)) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Required fields are missing'
            });
        } else if (req.body.id) {
            Ambulance.findOne({ _id: req.body.id, is_deleted: false }).exec(function (err, group) {
                if (err) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Something went wrong please try again!'
                    });
                } else if (group) {
                    User.findOne({ _id: group.user_id }).exec(function (err, exist) {
                        if (err) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Something went wrong please try again!'
                            });
                        } else {
                            if (exist) {
                                exist.email = body.email;
                                exist.save(function (err, userData) {
                                    if (err) {
                                        res.json({
                                            'code': config.httpUnauthorize,
                                            'message': 'Unable to Update Ambulance'
                                        });
                                    } else {
                                        group.company_name = body.company_name;
                                        group.service_type = body.service_type;
                                        group.address = body.address;
                                        group.city = body.city;
                                        group.state = body.state;
                                        group.zip_code = body.zip_code;
                                        group.country = body.country;
                                        group.mobile_no = body.mobile_no;
                                        group.hospital_id = body.hospital_id;
                                        group.save(function (err) {
                                            if (err) {
                                                res.json({
                                                    'code': config.httpUnauthorize,
                                                    'message': 'Unable to Update Ambulance'
                                                });
                                            } else {
                                                var userMailData = {
                                                    company_name: body.company_name,
                                                    email: body.email,
                                                    // password: body.password
                                                };

                                                mailer.sendMail(body.email, constant.emailKeyword.WelComeEmailTowing, userMailData, function (err, resp) {
                                                    if (err) {
                                                        res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                                    } else {
                                                        res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                    }
                                                });
                                                console.log("in Care Coordinator Update");
                                                res.json({
                                                    'code': config.httpSuccess,
                                                    'message': 'Ambulance Update successfully'
                                                });
                                            }
                                        })
                                    }
                                })
                            }
                        }
                    })
                } else {
                    res.json({
                        'code': 402,
                        'message': 'No record found'
                    });
                };
            })
        } else {
            let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
            Role.findOne({ name: 'Ambulance', is_deleted: false, status: true }).exec(function (err, group) {
                console.log("group", group);
                if (err) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Something went wrong please try again!'
                    });
                } else if (group) {
                    console.log("group", group);

                    User.findOne({ email: body.email }).exec(function (err, exist) {
                        if (err) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Something went wrong please try again!'
                            });
                        } else {
                            if (exist) {
                                res.json({
                                    'code': config.httpUnauthorize,
                                    'message': 'Ambulance Name with this email already exist please try another!'
                                });
                            } else {

                                var user = new User();
                                var randompass = common.randomToken(8);
                                user.email = body.email;
                                user.role_id = group._id;
                                user.setPassword(randompass);

                                user.save(function (err, userData) {
                                    if (err) {
                                        res.json({
                                            'code': config.httpUnauthorize,
                                            'message': 'Unable to save ambulance'
                                        });
                                    } else {

                                        console.log("in user save");
                                        var ambulance = new Ambulance();
                                        ambulance.company_name = body.company_name;
                                        ambulance.user_id = userData._id;
                                        ambulance.service_type = body.service_type;
                                        ambulance.address = body.address;
                                        ambulance.city = body.city;
                                        ambulance.state = body.state;
                                        ambulance.zip_code = body.zip_code;
                                        ambulance.country = body.country;
                                        ambulance.mobile_no = body.mobile_no;
                                        if (hospitalInfo) {
                                            ambulance.hospital_id = hospitalInfo._id;
                                        }
                                        ambulance.save(function (err) {
                                            if (err) {
                                                res.json({
                                                    'code': config.httpUnauthorize,
                                                    'message': 'Unable to save ambulance'
                                                });
                                            } else {
                                                var userMailData = {
                                                    company_name: body.company_name,
                                                    email: body.email,
                                                    password: randompass
                                                };

                                                mailer.sendMail(body.email, constant.emailKeyword.WelComeEmailTowing, userMailData, function (err, resp) {
                                                    if (err) {
                                                        res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                                    } else {
                                                        res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                    }
                                                });
                                                console.log("in ambulance save");
                                                res.json({
                                                    'code': config.httpSuccess,
                                                    'message': 'Ambulance saved successfully'
                                                });
                                            }
                                        })


                                    }
                                });
                            }
                        }
                    });
                } else {
                    res.json({
                        'code': 402,
                        'message': 'No record found'
                    });
                };
            })
        }
    }).catch(function (err) {
        console.log("getVisitById Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}

/**
 * Function is use to Get Ambulance List
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 05-Feb-2018
 */

function getAllAmbulanceByHospital(req, res) {
    co(function* () {
        let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
        var condition = {};
        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        condition.is_deleted = false;
        if (hospitalInfo) {
            condition.hospital_id = hospitalInfo._id;
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (req.body.searchText) {
            condition.$or = [{ 'company_name': new RegExp(searchText, 'gi') }, { 'serviceInfo.serviceType_name': new RegExp(searchText, 'gi') }, { 'address': new RegExp(searchText, 'gi') }, { 'mobile_no': new RegExp(searchText, 'gi') }];
        }
        let aggregate = [{
            $lookup: {
                from: 'servicetypes',
                localField: "service_type",
                foreignField: "_id",
                as: "serviceInfo"
            }
        },
        { $unwind: { path: "$serviceInfo" } },
        { $match: condition },
        { $sort: sorting }
        ];
        // var aggregateCnt = lodash.clone(aggregate, true);
        var aggregateCnt = [].concat(aggregate);
        if (req.body.count && req.body.page) {
            aggregate.push({ $sort: sorting });
            aggregate.push({ $skip: skip });
            aggregate.push({ $limit: count });
        }
        let ambulanceData = yield Ambulance.aggregate(aggregate);
        aggregateCnt.push({ $group: { _id: null, count: { $sum: 1 } } });
        let ambulanceDataCount = yield Ambulance.aggregate(aggregateCnt);
        return res.json({ code: 200, message: 'Data retrieved successfully', data: ambulanceData, totalCount: ((ambulanceDataCount[0]) ? ambulanceDataCount[0].count : 0) });

    }).catch(function (err) {
        console.log('Error', err);
        return res.json({ code: 400, message: 'Internal server error', data: {} });
    });
}

/**
 * Function is use to add Ambulance
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 05-Feb-2018
 */

function addTowingByHospital(req, res) {
    co(function* () {
        var body = req.body;
        console.log("body", body);
        if (!validator.isValid(body.address) || !validator.isValid(body.city) || !validator.isValid(body.state) || !validator.isValid(body.country) || !validator.isValid(body.zip_code) || !validator.isValid(body.mobile_no) || !validator.isValid(body.company_name) || !validator.isValid(body.email) || !validator.isValid(body.service_type)) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Required fields are missing'
            });
        } else if (req.body.id) {
            Towing.findOne({ _id: req.body.id, is_deleted: false }).exec(function (err, group) {
                if (err) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Something went wrong please try again!'
                    });
                } else if (group) {
                    User.findOne({ _id: group.user_id }).exec(function (err, exist) {
                        if (err) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Something went wrong please try again!'
                            });
                        } else {
                            if (exist) {
                                exist.email = body.email;
                                exist.save(function (err, userData) {
                                    if (err) {
                                        res.json({
                                            'code': config.httpUnauthorize,
                                            'message': 'Unable to Update Towing'
                                        });
                                    } else {
                                        group.company_name = body.company_name;
                                        group.service_type = body.service_type;
                                        group.address = body.address;
                                        group.city = body.city;
                                        group.state = body.state;
                                        group.zip_code = body.zip_code;
                                        group.country = body.country;
                                        group.mobile_no = body.mobile_no;
                                        group.hospital_id = body.hospital_id;
                                        group.save(function (err) {
                                            if (err) {
                                                res.json({
                                                    'code': config.httpUnauthorize,
                                                    'message': 'Unable to Update Towing'
                                                });
                                            } else {
                                                console.log("in Towing Update");
                                                res.json({
                                                    'code': config.httpSuccess,
                                                    'message': 'Towing Update successfully'
                                                });
                                            }
                                        })
                                    }
                                })
                            }
                        }
                    })
                } else {
                    res.json({
                        'code': 402,
                        'message': 'No record found'
                    });
                };
            })
        } else {
            let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
            Role.findOne({ name: 'Towing', is_deleted: false, status: true }).exec(function (err, group) {
                console.log("group", group);
                if (err) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Something went wrong please try again!'
                    });
                } else if (group) {
                    console.log("group", group);

                    User.findOne({ email: body.email }).exec(function (err, exist) {
                        if (err) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Something went wrong please try again!'
                            });
                        } else {
                            if (exist) {
                                res.json({
                                    'code': config.httpUnauthorize,
                                    'message': 'Towing Company Name with this email already exist please try another!'
                                });
                            } else {

                                var user = new User();
                                user.email = body.email;
                                var randompass = common.randomToken(8);
                                user.role_id = group._id;
                                user.setPassword(randompass);

                                user.save(function (err, userData) {
                                    if (err) {
                                        res.json({
                                            'code': config.httpUnauthorize,
                                            'message': 'Unable to save towing'
                                        });
                                    } else {

                                        console.log("in user save");
                                        var towing = new Towing();
                                        towing.company_name = body.company_name;
                                        towing.user_id = userData._id;
                                        towing.service_type = body.service_type;
                                        towing.address = body.address;
                                        towing.city = body.city;
                                        towing.state = body.state;
                                        towing.zip_code = body.zip_code;
                                        towing.country = body.country;
                                        towing.mobile_no = body.mobile_no;
                                        if (hospitalInfo) {
                                            towing.hospital_id = hospitalInfo._id;
                                        }
                                        towing.save(function (err) {
                                            if (err) {
                                                res.json({
                                                    'code': config.httpUnauthorize,
                                                    'message': 'Unable to save towing'
                                                });
                                            } else {
                                                var userMailData = {
                                                    company_name: body.company_name,
                                                    email: body.email,
                                                    password: randompass
                                                };

                                                mailer.sendMail(body.email, constant.emailKeyword.WelComeEmailTowing, userMailData, function (err, resp) {
                                                    if (err) {
                                                        res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                                    } else {
                                                        res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                    }
                                                });
                                                console.log("in towing save");
                                                res.json({
                                                    'code': config.httpSuccess,
                                                    'message': 'Towing saved successfully'
                                                });
                                            }
                                        })


                                    }
                                });
                            }
                        }
                    });
                } else {
                    res.json({
                        'code': 402,
                        'message': 'No record found'
                    });
                };
            })
        }
    }).catch(function (err) {
        console.log('Error', err);
        return res.json({ code: 400, message: 'Internal server error', data: {} });
    });
}



/**
 * Function is use to Get Towing List
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 05-Feb-2018
 */
function getAllTowingByHospital(req, res) {
    co(function* () {
        let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
        var condition = {};
        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        condition.is_deleted = false;
        if (hospitalInfo) {
            condition.hospital_id = hospitalInfo._id;
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (req.body.searchText) {
            condition.$or = [{ 'company_name': new RegExp(searchText, 'gi') }, { 'serviceInfo.serviceType_name': new RegExp(searchText, 'gi') }, { 'address': new RegExp(searchText, 'gi') }, { 'mobile_no': new RegExp(searchText, 'gi') }];
        }
        let aggregate = [{
            $lookup: {
                from: 'servicetypes',
                localField: "service_type",
                foreignField: "_id",
                as: "serviceInfo"
            }
        },
        { $unwind: { path: "$serviceInfo" } },
        { $match: condition },
        { $sort: sorting }
        ];
        // var aggregateCnt = lodash.clone(aggregate, true);
        var aggregateCnt = [].concat(aggregate);
        if (req.body.count && req.body.page) {
            aggregate.push({ $sort: sorting });
            aggregate.push({ $skip: skip });
            aggregate.push({ $limit: count });
        }
        let towingData = yield Towing.aggregate(aggregate);
        aggregateCnt.push({ $group: { _id: null, count: { $sum: 1 } } });
        let towingDataCount = yield Towing.aggregate(aggregateCnt);
        return res.json({ code: 200, message: 'Data retrieved successfully', data: towingData, totalCount: ((towingDataCount[0]) ? towingDataCount[0].count : 0) });

    }).catch(function (err) {
        console.log('Error', err);
        return res.json({ code: 400, message: 'Internal server error', data: {} });
    });
}

function decrypt(decText) {
    var decipher = crypto.createDecipher(algorithm, password)
    var decText = decipher.update(decText, 'hex', 'utf8')
    decText += decipher.final('utf8');
    return decText;
}

/**
 * Function is use to All entites linked to hospital
 * @access private
 * @return json
 * Created by Swapnali Jare
 * @smartData Enterprises (I) Ltd
 * Created Date 06-Feb-2018
 */
function getAllEntitiesLinkedToHospital(req, res) {
    co(function* () {
        let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
        let list = [];
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
        var condition = {};
        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        condition.is_deleted = false;
        if (hospitalInfo) {
            condition.hospital_id = hospitalInfo._id;
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (req.body.searchText) {
            condition.$or = [{ 'company_name': new RegExp(searchText, 'gi') }, { 'serviceInfo.serviceType_name': new RegExp(searchText, 'gi') }, { 'address': new RegExp(searchText, 'gi') }, { 'mobile_no': new RegExp(searchText, 'gi') }];
        }
        let aggregate = [{
            $lookup: {
                from: 'users',
                localField: "user_id",
                foreignField: "_id",
                as: "userInfo"
            }
        },
        { $unwind: { path: "$userInfo" } },
        { $match: condition },
        ];

        let patients = yield Patient.aggregate(aggregate);
        //console.log("Patient---->", patients);
        patients.forEach(function (patient) {
            patient.first_name = decrypt(patient.first_name);
            patient.last_name = decrypt(patient.last_name);
            patient.mobile_no = decrypt(patient.mobile_no);
            patient.name = patient.first_name + "  " + patient.last_name;
            patient.email = patient.userInfo.email;
            patient.type = 'Patient';
        });
        console.log("patients length---->", patients.length);

        let ambulances = yield Ambulance.aggregate(aggregate);
        //console.log("ambulances---->", ambulances);
        ambulances.forEach(function (ambulance) {
            ambulance.name = ambulance.company_name;
            ambulance.email = ambulance.userInfo.email;
            ambulance.type = 'Ambulance';
        });
        console.log("ambulances length---->", ambulances.length);

        let towings = yield Towing.aggregate(aggregate);
        //console.log("towings---->", towings);
        console.log("towings length---->", towings.length);
        towings.forEach(function (towing) {
            towing.name = towing.company_name;
            towing.email = towing.userInfo.email;
            towing.type = 'Towing';
        });
        let clinicians = yield Clinician.aggregate(aggregate);
        //console.log("clinicians---->", clinicians);
        console.log("clinicians length---->", clinicians.length);
        clinicians.forEach(function (clinician) {
            clinician.name = clinician.first_name + "  " + clinician.last_name;
            clinician.email = clinician.userInfo.email;
            clinician.type = 'Clinician';
        });

        let careCoordinators = yield CareCoordinator.aggregate(aggregate);
        //console.log("careCoordinators---->", careCoordinators);
        console.log("careCoordinators length---->", careCoordinators.length);
        careCoordinators.forEach(function (careCoordinator) {
            careCoordinator.name = careCoordinator.first_name + "  " + careCoordinator.last_name;
            careCoordinator.email = careCoordinator.userInfo.email;
            careCoordinator.type = 'CareCoordinator';
        });

        list = list.concat(patients, ambulances, towings, clinicians, careCoordinators);
        // console.log("list---->", list);
        console.log("list length---->", list.length);

        //  var aggregateCnt = [].concat(aggregate);
        // if (req.body.count && req.body.page) {
        //     aggregate.push({ $sort: sorting });
        //     aggregate.push({ $skip: skip });
        //     aggregate.push({ $limit: count });
        // }
        //  list = yield list.aggregate(aggregate);
        //  aggregateCnt.push({ $group: { _id: null, count: { $sum: 1 } } });
        //  let ambulanceDataCount = yield list.aggregate(aggregateCnt);
        //return res.json({ code: 200, message: 'Data retrieved successfully', data: list, totalCount: ((ambulanceDataCount[0]) ? ambulanceDataCount[0].count : 0) });
        return res.json({ code: 200, message: 'Data retrieved successfully', data: list, totalCount: 0 });

    }).catch(function (err) {
        console.log("------getAllEntitiesLinkedToHospital ERR----->", err);
        return res.json({ code: 400, message: 'Internal server error', data: {} });
    });
}

// function getPatientListForDevice(req, res) {
//     Patient.find({ is_deleted: false }, { first_name: 1, last_name: 1 }).lean().exec(function (err, patient) {
//         if (err) {
//             res.json({
//                 code: 404,
//                 message: utility.validationErrorHandler(err)
//             });
//         } else if (patient) {
//             var newArr = [];
//             var filed = ['user_id', 'clinician_id', 'coordinator_id', 'DOB', 'image', 'country', 'hospital_id'];
//             utility.decryptedRecord(patient, filed, function (newArr) {
//                 res.json({
//                     code: 200,
//                     message: constantsObj.messages.patientsGetSuccessfully,
//                     data: newArr
//                 })
//             })
//         } else {
//             res.json({
//                 code: 404,
//                 message: constantsObj.messages.noDataFound
//             })
//         }
//     }).catch(function (err) {
//         return res.json(Response(402, utility.validationErrorHandler(err), err));
//     })
// }

/**
 * Function is use to Get Patient List for Device
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 6-june-2017
 */
function getPatientListForDevice(req, res) {
    co(function* () {
        console.log("req.user.id", req.user.id);
        let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
        console.log("-----hospitalInfo----", hospitalInfo);
        var condition = {};
        condition.is_deleted = false;
        if (hospitalInfo) {
            condition.hospital_id = hospitalInfo._id;
        }
        console.log("condition", condition);
        Patient.find(condition).lean().exec(function (err, patient) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (patient) {
                var newArr = [];
                var filed = ['user_id', 'clinician_id', 'coordinator_id', 'DOB', 'image', 'country', 'hospital_id'];
                utility.decryptedRecord(patient, filed, function (newArr) {
                    console.log("newArr-------------->>>>>>>>>", newArr);
                    res.json({
                        code: 200,
                        message: constantsObj.messages.patientsGetSuccessfully,
                        data: newArr
                    })
                })
            } else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

/**
 * Function is use to Add Patient Device By Hospital
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 08-Feb-2018
 */
function addPatientDeviceByHospital(req, res) {
    co(function* () {
        let savedData = yield Device.findById(req.body._id);
        if (savedData) {
            savedData.deviceName = req.body.deviceName;
            savedData.deviceType = req.body.deviceType;
            savedData.make = req.body.make;
            savedData.model = req.body.model;
            savedData.description = req.body.description;
            savedData.wearable = req.body.wearable;
            savedData.patient_id = req.body.patient_id;
            let savedDataNew = yield savedData.save();
            res.json({
                code: 200,
                message: constantsObj.messages.patientDeviceUpdatedSuccess,
            });
        } else if (!savedData) {
            let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
            var deviceObj = req.body;
            console.log("req.body-------->>>>>", deviceObj);
            deviceObj.status = true;
            if (hospitalInfo) {
                deviceObj.hospital_id = hospitalInfo._id;
            }
            var device = new Device(deviceObj);
            device.save(function (err, device) {
                if (err) {
                    res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
                } else {
                    res.json({
                        code: 200,
                        message: constantsObj.messages.DeviceAddedSuccess,
                        data: device
                    });
                }
            });
        } else {
            return res.json(Response(402, constantsObj.validationMessages.patientMedicationAddedFailed, err));
        }
    }).catch(function (err) {
        console.log("err-------->>", err);
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    });
}

/**
 * Function is use to Add Email Message
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 13-Feb-2018
 */
function addEmailMessage(req, res) {
    co(function* () {
        let savedData = yield EmailMessage.findById(req.body._id);
        if (savedData) {
            savedData.title = req.body.title;
            savedData.subject = req.body.subject;
            savedData.emailMsg = req.body.emailMsg;
            let savedDataNew = yield savedData.save();
            res.json({
                code: 200,
                message: 'Update Email Message Succesfully',
            });
        } else if (!savedData) {
            let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
            var emailObj = req.body;
            console.log("req.body-------->>>>>", emailObj);
            emailObj.status = true;
            if (hospitalInfo) {
                emailObj.hospital_id = hospitalInfo._id;
            }
            var emailData = new EmailMessage(emailObj);
            emailData.save(function (err, emailData) {
                if (err) {
                    res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
                } else {
                    res.json({
                        code: 200,
                        message: 'Add Email Message Succesfully',
                        data: emailData
                    });
                }
            });
        } else {
            return res.json(Response(402, constantsObj.validationMessages.patientMedicationAddedFailed, err));
        }
    }).catch(function (err) {
        console.log("err-------->>", err);
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    });
}

/**
 * Function is use to Get Email Message
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 13-Feb-2018
 */
function getEmailMesssageList(req, res) {
    co(function* () {
        console.log("req.user.id", req.user.id);
        let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
        console.log("-----hospitalInfo----", hospitalInfo);
        var condition = {};
        condition.is_deleted = false;
        if (hospitalInfo) {
            condition.hospital_id = hospitalInfo._id;
        }
        console.log("condition", condition);
        EmailMessage.find(condition).exec(function (err, emailData) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (emailData) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientsGetSuccessfully,
                    data: emailData
                })
            }
            else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

/**
 * Function is use to Get Email Message
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 13-Feb-2018
 */
function getEmailMesssageListforPatient(req, res) {
    co(function* () {
        let patientInfo = yield Patient.findOne({ user_id: req.user.id }).lean();
        var condition = {};
        condition.is_deleted = false;
        if (patientInfo) {
            condition.hospital_id = patientInfo.hospital_id;
        }
        console.log("condition", condition);
        EmailMessage.find(condition).exec(function (err, emailData) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (emailData) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientsGetSuccessfully,
                    data: emailData
                })
            }
            else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}
/**
 * Function is use to Get Email Message
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 13-Feb-2018
 */
function getEmailMesssageById(req, res) {
    var id = req.swagger.params.id.value;
    EmailMessage.findOne({ _id: id }).exec(function (err, data) {
        if (err) {
            res.json({
                'code': 402,
                'message': 'No record found'
            });
        } else {
            res.json({
                code: 200,
                data: data
            });
        }
    })
}
/**
 * Function is use to delete message 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 14-feb-2018
 */
function deleteEmailMessage(req, res) {
    var msgId = req.swagger.params.id.value;
    EmailMessage.update({ _id: msgId }, { $set: { is_deleted: true } }, function (err) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else {
            res.json({
                code: 200,
                message: 'Message Delete Successfully',
            })
        }
    })
}



/**
 * Function is use to Get Device By Hospital
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 08-Feb-2018
 */
function getDeviceListForHospital(req, res) {
    co(function* () {
        console.log("req.user.id", req.user.id);
        let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
        console.log("-----hospitalInfo----", hospitalInfo);
        var condition = {};
        condition.is_deleted = false;
        if (hospitalInfo) {
            condition.hospital_id = hospitalInfo._id;
        }
        console.log("condition", condition);
        Device.find(condition).populate('patient_id').populate('deviceType').exec(function (err, deviceData) {

            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (deviceData) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientsGetSuccessfully,
                    data: deviceData
                })
            }
            else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}
/**
 * Function is use Device List
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 13-Feb-2018
 */
function viewDeviceListForPatient(req, res) {
    var id = req.swagger.params.id.value;
    Device.find({ patient_id: id, is_deleted: false }).populate('deviceType').exec(function (err, data) {
        if (err) {
            res.json({
                'code': 402,
                'message': 'No record found'
            });
        } else {
            res.json({
                code: 200,
                data: data
            });
        }
    })
}

/**
 * Function is use to Add SMS Template 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 14-Feb-2018
 */
function addSmsTemplate(req, res) {
    co(function* () {
        let savedData = yield SmsTemplate.findById(req.body._id);
        if (savedData) {
            savedData.title = req.body.title;
            savedData.smsMessage = req.body.smsMessage;
            let savedDataNew = yield savedData.save();
            res.json({
                code: 200,
                message: 'Update SMS Template Succesfully',
            });
        } else if (!savedData) {
            let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
            var smsObj = req.body;
            console.log("req.body-------->>>>>", smsObj);
            smsObj.status = true;
            if (hospitalInfo) {
                smsObj.hospital_id = hospitalInfo._id;
            }
            var smsData = new SmsTemplate(smsObj);
            smsData.save(function (err, smsData) {
                if (err) {
                    res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
                } else {
                    res.json({
                        code: 200,
                        message: 'Add SMS Template Succesfully',
                        data: smsData
                    });
                }
            });
        } else {
            return res.json(Response(402, constantsObj.validationMessages.patientMedicationAddedFailed, err));
        }
    }).catch(function (err) {
        console.log("err-------->>", err);
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    });
}

/**
 * Function is use to Get SMS Template 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 14-Feb-2018
 */
function getSmsTemplateList(req, res) {
    co(function* () {
        console.log("req.user.id", req.user.id);
        let hospitalInfo = yield Hospital.findOne({ user_id: req.user.id }).lean();
        console.log("-----hospitalInfo----", hospitalInfo);
        var condition = {};
        condition.is_deleted = false;
        if (hospitalInfo) {
            condition.hospital_id = hospitalInfo._id;
        }
        console.log("condition", condition);
        SmsTemplate.find(condition).exec(function (err, emailData) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (emailData) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientsGetSuccessfully,
                    data: emailData
                })
            }
            else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

/**
 * Function is use to Get SMS Template 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 14-Feb-2018
 */
function getSmsTemplateListforPatient(req, res) {

    co(function* () {
        let patientInfo = yield Patient.findOne({ user_id: req.user.id }).lean();
        var condition = {};
        condition.is_deleted = false;
        if (patientInfo) {
            condition.hospital_id = patientInfo.hospital_id;
        }
        console.log("condition", condition);
        SmsTemplate.find(condition).exec(function (err, smsData) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (smsData) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientsGetSuccessfully,
                    data: smsData
                })
            }
            else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}
/**
 * Function is use to Get Email Message
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 14-Feb-2018
 */
function getSmsTemplateById(req, res) {
    var id = req.swagger.params.id.value;
    SmsTemplate.findOne({ _id: id }).exec(function (err, data) {
        if (err) {
            res.json({
                'code': 402,
                'message': 'No record found'
            });
        } else {
            res.json({
                code: 200,
                data: data
            });
        }
    })
}
/**
 * Function is use to delete Template
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 14-Feb-2018
 */
function deleteSmsTemplate(req, res) {
    var smsId = req.swagger.params.id.value;
    SmsTemplate.update({ _id: smsId }, { $set: { is_deleted: true } }, function (err) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else {
            res.json({
                code: 200,
                message: 'SMS Template Delete Successfully',
            })
        }
    })
}

/**
 * Function is use to Get SMS Template for Clinician
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 15-Feb-2018
 */
function getSmsTemplateListforClinician(req, res) {

    co(function* () {
        let clinicianInfo = yield Clinician.findOne({ user_id: req.user.id }).lean();
        var condition = {};
        condition.is_deleted = false;
        if (clinicianInfo) {
            condition.hospital_id = clinicianInfo.hospital_id;
        }
        console.log("condition", condition);
        SmsTemplate.find(condition).exec(function (err, smsData) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (smsData) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientsGetSuccessfully,
                    data: smsData
                })
            }
            else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

/**
 * Function is use to Get Email Template for Clinician
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 15-Feb-2018
 */
function getEmailMesssageListforClinician(req, res) {
    co(function* () {
        let clinicianInfo = yield Clinician.findOne({ user_id: req.user.id }).lean();
        var condition = {};
        condition.is_deleted = false;
        if (clinicianInfo) {
            condition.hospital_id = clinicianInfo.hospital_id;
        }
        console.log("condition", condition);
        EmailMessage.find(condition).exec(function (err, emailData) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (emailData) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientsGetSuccessfully,
                    data: emailData
                })
            }
            else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}
/**
 * Function is use to Get SMS Template for Care-Coordinator
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 15-Feb-2018
 */
function getSmsTemplateListforCareCoordinator(req, res) {

    co(function* () {
        let careCoordinatorInfo = yield CareCoordinator.findOne({ user_id: req.user.id }).lean();
        var condition = {};
        condition.is_deleted = false;
        if (careCoordinatorInfo) {
            condition.hospital_id = careCoordinatorInfo.hospital_id;
        }
        console.log("condition", condition);
        SmsTemplate.find(condition).exec(function (err, smsData) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (smsData) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientsGetSuccessfully,
                    data: smsData
                })
            }
            else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

/**
 * Function is use to Get Email Message for Care- Coordiantor
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 15-Feb-2018
 */
function getEmailMesssageListforCareCoordinator(req, res) {
    co(function* () {
        let careCoordinatorInfo = yield CareCoordinator.findOne({ user_id: req.user.id }).lean();
        var condition = {};
        condition.is_deleted = false;
        if (careCoordinatorInfo) {
            condition.hospital_id = careCoordinatorInfo.hospital_id;
        }
        console.log("condition", condition);
        EmailMessage.find(condition).exec(function (err, emailData) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (emailData) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientsGetSuccessfully,
                    data: emailData
                })
            }
            else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}
/**
 * Function is use to Get SMS Template for Ambulance
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 15-Feb-2018
 */
function getSmsTemplateListforAmbulance(req, res) {

    co(function* () {
        let ambulanceInfo = yield Ambulance.findOne({ user_id: req.user.id }).lean();
        var condition = {};
        condition.is_deleted = false;
        if (ambulanceInfo) {
            condition.hospital_id = ambulanceInfo.hospital_id;
        }
        console.log("condition", condition);
        SmsTemplate.find(condition).exec(function (err, smsData) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (smsData) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientsGetSuccessfully,
                    data: smsData
                })
            }
            else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

/**
 * Function is use to Get Email Message for ambulance
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 15-Feb-2018
 */
function getEmailMesssageListforAmbulance(req, res) {
    co(function* () {
        let ambulanceInfo = yield Ambulance.findOne({ user_id: req.user.id }).lean();
        var condition = {};
        condition.is_deleted = false;
        if (ambulanceInfo) {
            condition.hospital_id = ambulanceInfo.hospital_id;
        }
        console.log("condition", condition);
        EmailMessage.find(condition).exec(function (err, emailData) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (emailData) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientsGetSuccessfully,
                    data: emailData
                })
            }
            else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}
/**
 * Function is use to Get SMS Template for Towing
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 15-Feb-2018
 */
function getSmsTemplateListforTowing(req, res) {

    co(function* () {
        let towingInfo = yield Towing.findOne({ user_id: req.user.id }).lean();
        var condition = {};
        condition.is_deleted = false;
        if (towingInfo) {
            condition.hospital_id = towingInfo.hospital_id;
        }
        console.log("condition", condition);
        SmsTemplate.find(condition).exec(function (err, smsData) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (smsData) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientsGetSuccessfully,
                    data: smsData
                })
            }
            else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

/**
 * Function is use to Get Email Message Towing
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 15-Feb-2018
 */
function getEmailMesssageListforTowing(req, res) {
    co(function* () {
        let towingInfo = yield Towing.findOne({ user_id: req.user.id }).lean();
        var condition = {};
        condition.is_deleted = false;
        if (towingInfo) {
            condition.hospital_id = towingInfo.hospital_id;
        }
        console.log("condition", condition);
        EmailMessage.find(condition).exec(function (err, emailData) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (emailData) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientsGetSuccessfully,
                    data: emailData
                })
            }
            else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}