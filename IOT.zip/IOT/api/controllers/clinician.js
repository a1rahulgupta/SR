'use strict';

var mongoose = require('mongoose'),
    Patient = mongoose.model('Patient'),
    Role = mongoose.model('Role'),
    User = mongoose.model('User'),
    Clinician = mongoose.model('Clinician'),
    OrderTest = mongoose.model('OrderTest'),
    CarePlan = mongoose.model('CarePlan'),
    Appointment = mongoose.model('Appointment'),
    HospitalAssign = mongoose.model('HospitalAssign'),
    co = require('co'),
    config = require('../../config/config.js'),
    constantsObj = require('../lib/constants'),
    algorithm = constantsObj.config.cryptoAlgorithm,
    password = constantsObj.config.cryptoPassword,
    validator = require('../../config/validator.js'),
    crypto = require('crypto'),
    utility = require('../lib/utility.js'),
    async = require('async'),
    fs = require('fs'),
    path = require('path'),
    constant = require('../lib/constants'),
    mailer = require('../lib/mailer'),
    constantsObj = require('../lib/constants'),
    common = require('../../config/common.js'),
    _ = require('underscore'),
    lodash = require('lodash');


module.exports = {
    getAllClinicianName: getAllClinicianName,
    getAllClinician: getAllClinician,
    deleteClinicianById: deleteClinicianById,
    addClinician: addClinician,
    getClinicianById: getClinicianById,
    enableDisableClinician: enableDisableClinician,
    getClinicianDetails: getClinicianDetails,
    updateClinicianProfile: updateClinicianProfile,
    addCarePlan: addCarePlan,
    addOrderTest: addOrderTest,
    getClinicianByHospitalId: getClinicianByHospitalId,
    getAllAppointmentByClinicianId: getAllAppointmentByClinicianId,
    getAllOrderTestByPatientId: getAllOrderTestByPatientId,
    getAllCarePlanByPatientId: getAllCarePlanByPatientId,
    viewTestOrderById: viewTestOrderById,
    viewCarePlanById: viewCarePlanById,
    getAssignPatientForClinician: getAssignPatientForClinician,
    getAllEntitiesLinkedToClinician: getAllEntitiesLinkedToClinician

};

function decrypt(decText) {
    var decipher = crypto.createDecipher(algorithm, password)
    var decText = decipher.update(decText, 'hex', 'utf8')
    decText += decipher.final('utf8');
    return decText;
}

function addCarePlan(req, res) {
    var body = req.body;
    console.log("body", body);
    if (!validator.isValid(body.dosage) || !validator.isValid(body.medicine) || !validator.isValid(body.jogging) || !validator.isValid(body.walking) || !validator.isValid(body.issue_date)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        var carePlan = new CarePlan(body);
        carePlan.save(function (err) {
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Unable to save clinician'
                });
            } else {
                res.json({
                    'code': 200,
                    'message': 'Care Plan Added successfully'
                });
            }
        });
    }
}

function addOrderTest(req, res) {
    var body = req.body;
    console.log("body", body);
    if (!validator.isValid(body.test_name) || !validator.isValid(body.ionic_code) || !validator.isValid(body.lab_address) || !validator.isValid(body.order_date)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        var orderTest = new OrderTest(body);
        orderTest.save(function (err) {
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Unable to save clinician'
                });
            } else {
                res.json({
                    'code': 200,
                    'message': 'Order Test Added successfully'
                });
            }
        });
    }
}


function getAllClinicianName(req, res) {
    Role.findOne({
        is_deleted: false,
        name: 'Clinician'
    }).exec(function (rolerr, roldata) {
        if (rolerr) {
            res.json({
                'code': 401,
                'message': 'Unable to get Role'
            });
        } else {
            var roleId = roldata._id
            console.log("Role data ", roleId);
            User.find({
                role_id: roleId
            }, {}).exec(function (err, data) {
                if (err) {
                    console.log(err, "err")
                    res.json({
                        'code': 401,
                        'message': 'Unable to get getClinician'
                    });
                } else {
                    console.log("data", data)
                    res.json({
                        'code': 200,
                        'data': data
                    });
                }

            });

        }
    })
}

/**
 * Function is use to Get Clinician List
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 21-june-2017
 */
// function getAllClinician(req, res) {
//     var count = req.body.count ? req.body.count : 0;
//     var skip = req.body.count * (req.body.page - 1);
//     var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
//     var condition = { is_deleted: false };
//     var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
//     if (req.query.searchText) {
//         condition.$or = [{ 'first_name': new RegExp(searchText, 'gi') }, { 'last_name': new RegExp(searchText, 'gi') }, { 'clinician_npi_no': new RegExp(searchText, 'gi') }, { 'SSN': new RegExp(searchText, 'gi') }, { 'mobile_no': new RegExp(searchText, 'gi')];
//     }
//     if (!req.body.searchObj) {
//             req.body.searchObj = {};
//     }
//     let aggregate = [
//             {
//                 $lookup: {
//                     from: 'hospitals',
//                     localField: "hospital_id",
//                     foreignField: "_id",
//                     as: "hospitalInfo"
//                 }
//             },
//             { $match: condition }, {
//                 $project: {
//                     clinician_npi_no: 1,
//                     first_name: 1,
//                     last_name: 1,
//                     SSN: 1,
//                     address: 1,
//                     city: 1,
//                     state: 1,
//                     zip_code: 1,
//                     country: 1,
//                     mobile_no: 1,
//                     specialization: 1,
//                     hospital_id: {
//                         hospital_name: 1
//                     }
//                 }
//             }
//     ];
//     var aggregateCnt = lodash.clone(aggregate, true);
//     if (sorting) {
//             if (sorting.hasOwnProperty('_id')) {
//                 aggregate.push({ $sort: { 'submitted_date': -1 } });
//                 console.log('++++++');
//             } else {
//                 console.log(sorting, '-------');
//                 aggregate.push({ $sort: sorting });
//             }
//         }
//         if (req.body.count && req.body.page) {
//             aggregate.push({ $skip: skip });
//             aggregate.push({ $limit: count });
//         }
//      clinician.aggregate(aggregate);
//      aggregateCnt.push({ $group: { _id: null, count: { $sum: 1 } } });
//      let totalCount = yield AuditReport.aggregate(aggregateCnt);

//         aggregate.push(project);
//         aggregate.push({ $limit: 5 });
//         aggregate.push({ $limit: count });    
//         Clinician.find(condition)
//             .limit(parseInt(count))
//             .skip(parseInt(skip))
//         .sort(sorting).populate('hospital_id').lean().exec(function(err, clinician) {
//             if (err) {
//                 res.json({
//                     code: 404,
//                     message: utility.validationErrorHandler(err)
//                 });
//             } else if (clinician) {
//                 Clinician.find(condition)
//                     .count()
//                     .exec(function(err, totalCount) {
//                         if (err) {
//                             res.json({
//                                 code: 404,
//                                 message: 'TotalCount Not Correct'
//                             })
//                         } else {
//                             res.json({
//                                 code: 200,
//                                 message: constantsObj.messages.cliniciansGetSuccessfully,
//                                 data: clinician,
//                                 totalCount: totalCount
//                             })
//                         }
//                     });
//             } else {
//                 res.json({
//                     code: 404,
//                     message: constantsObj.messages.noDataFound
//                 })
//             }
//         }).catch(function(err) {
//             return res.json(Response(402, utility.validationErrorHandler(err), err));
//         })
// }

function getAllClinician(req, res) {
    co(function* () {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : {
            _id: -1
        };
        var condition = {
            is_deleted: false
        };
        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (req.body.searchText) {
            condition.$or = [{
                'first_name': new RegExp(searchText, 'gi')
            }, {
                'last_name': new RegExp(searchText, 'gi')
            }, {
                'clinician_npi_no': new RegExp(searchText, 'gi')
            }, {
                'SSN': new RegExp(searchText, 'gi')
            }, {
                'mobile_no': new RegExp(searchText, 'gi')
            }, {
                'hospitalInfo.hospital_name': new RegExp(searchText, 'gi')
            }];
        }
        let aggregate = [{
            $lookup: {
                from: 'hospitals',
                localField: "hospital_id",
                foreignField: "_id",
                as: "hospitalInfo"
            }
        },
        {
            $unwind: {
                path: "$hospitalInfo",
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $match: condition
        },
        {
            $sort: sorting
        }, {
            $project: {
                clinician_npi_no: 1,
                first_name: 1,
                last_name: 1,
                SSN: 1,
                address: 1,
                city: 1,
                state: 1,
                zip_code: 1,
                country: 1,
                mobile_no: 1,
                specialization: 1,
                status: 1,
                hospitalInfo: {
                    hospital_name: 1
                }
            }
        }
        ];
        // var aggregateCnt = lodash.clone(aggregate, true);
        var aggregateCnt = [].concat(aggregate);
        if (req.body.count && req.body.page) {
            aggregate.push({
                $sort: sorting
            });
            aggregate.push({
                $skip: skip
            });
            aggregate.push({
                $limit: count
            });
        }
        let clinicianData = yield Clinician.aggregate(aggregate);
        aggregateCnt.push({
            $group: {
                _id: null,
                count: {
                    $sum: 1
                }
            }
        });
        let clinicianDataCount = yield Clinician.aggregate(aggregateCnt);
        return res.json({
            code: 200,
            message: 'Data retrieved successfully',
            data: clinicianData,
            totalCount: ((clinicianDataCount[0]) ? clinicianDataCount[0].count : 0)
        });

    }).catch(function (err) {
        console.log('Error', err);
        return res.json({
            code: 400,
            message: 'Internal server error',
            data: {}
        });
    });
}

/**
 * Function is use to Delete Clinician By Id 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 24-June-2017
 */
function deleteClinicianById(req, res) {
    console.log("req.swagger.params.id.value", req.swagger.params.id.value);
    var id = req.swagger.params.id.value;
    co(function* () {
        let clinicianData = yield Clinician.findById(id);
        if (clinicianData) {
            var clinicianInfo = clinicianData;
            clinicianData.is_deleted = true;
            let clinicianDelete = yield clinicianData.save();
            console.log("in clinician");
            let userData = yield User.findById(clinicianInfo.user_id);
            if (userData) {
                console.log("in user");
                userData.is_deleted = true;
                let userDelete = yield userData.save();
            } else {
                console.log("in delete response failed");
                res.json({
                    code: 404,
                    message: constantsObj.messages.userDeletedFailed
                })
            }
            console.log("in delete response success");
            res.json({
                code: 200,
                message: constantsObj.messages.userDeletedSuccess
            })
        } else {
            res.json({
                code: 402,
                message: constantsObj.messages.noRecordFound,
                data: err
            });
        }
    }).catch(function (err) {
        res.json({
            code: 404,
            message: utility.validationErrorHandler(err),
            data: err
        });
    });
}

/**
 * Function is use to add Clinician
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 24-June-2017
 */
function addClinician(req, res) {
    var body = req.body;
    console.log("body", body);
    if (!validator.isValid(body.first_name) || !validator.isValid(body.last_name) || !validator.isValid(body.address) || !validator.isValid(body.city) || !validator.isValid(body.state) || !validator.isValid(body.country) || !validator.isValid(body.zip_code) || !validator.isValid(body.mobile_no) || !validator.isValid(body.SSN) || !validator.isValid(body.email) || !validator.isValid(body.clinician_npi_no)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else if (req.body.id) {
        Clinician.findOne({
            _id: req.body.id,
            is_deleted: false
        }).exec(function (err, group) {
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Something went wrong please try again!'
                });
            } else if (group) {
                User.findOne({
                    _id: group.user_id
                }).exec(function (err, exist) {
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Something went wrong please try again!'
                        });
                    } else {
                        if (exist) {
                            exist.email = body.email;
                            exist.save(function (err, userData) {
                                if (err) {
                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Unable to Update clinician'
                                    });
                                } else {
                                    group.clinician_npi_no = body.clinician_npi_no;
                                    group.first_name = body.first_name;
                                    group.last_name = body.last_name;
                                    group.SSN = body.SSN;
                                    group.address = body.address;
                                    group.city = body.city;
                                    group.state = body.state;
                                    group.zip_code = body.zip_code;
                                    group.country = body.country;
                                    group.hospital_id = body.hospital_id;
                                    group.mobile_no = body.mobile_no;
                                    group.save(function (err) {
                                        if (err) {
                                            res.json({
                                                'code': config.httpUnauthorize,
                                                'message': 'Unable to Update clinician'
                                            });
                                        } else {
                                            console.log("in Clinician Update");
                                            res.json({
                                                'code': config.httpSuccess,
                                                'message': 'Clinician Update successfully'
                                            });
                                        }
                                    })
                                }
                            })
                        }
                    }
                })
            } else {
                res.json({
                    'code': 402,
                    'message': 'No record found'
                });
            };
        })
    } else {
        Role.findOne({
            name: 'Clinician',
            is_deleted: false,
            status: true
        }).exec(function (err, group) {
            console.log("group", group);
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Something went wrong please try again!'
                });
            } else if (group) {
                console.log("group", group);

                User.findOne({
                    email: body.email,
                    is_deleted: false
                }).exec(function (err, exist) {
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Something went wrong please try again!'
                        });
                    } else {
                        if (exist) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Clinician Name with this email already exist please try another!'
                            });
                        } else {

                            var user = new User();
                            var randompass = common.randomToken(8);
                            user.email = body.email;
                            user.role_id = group._id;
                            user.setPassword(randompass);

                            user.save(function (err, userData) {
                                if (err) {
                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Unable to save clinician'
                                    });
                                } else {

                                    console.log("in user save");
                                    var clinician = new Clinician();
                                    clinician.clinician_npi_no = body.clinician_npi_no;
                                    clinician.user_id = userData._id;
                                    clinician.first_name = body.first_name;
                                    clinician.last_name = body.last_name;
                                    clinician.SSN = body.SSN;
                                    clinician.address = body.address;
                                    clinician.city = body.city;
                                    clinician.state = body.state;
                                    clinician.zip_code = body.zip_code;
                                    clinician.country = body.country;
                                    clinician.hospital_id = body.hospital_id;
                                    clinician.mobile_no = body.mobile_no;
                                    clinician.save(function (err) {
                                        if (err) {
                                            res.json({
                                                'code': config.httpUnauthorize,
                                                'message': 'Unable to save clinician'
                                            });
                                        } else {
                                            var userMailData = {
                                                first_name: body.first_name,
                                                last_name: body.last_name,
                                                email: body.email,
                                                password: randompass,
                                            };

                                            mailer.sendMail(body.email, constant.emailKeyword.WelComeEmail, userMailData, function (err, resp) {
                                                if (err) {
                                                    res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                                } else {
                                                    res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                }
                                            });
                                            console.log("in Clinician save");
                                            res.json({
                                                'code': config.httpSuccess,
                                                'message': 'Clinician saved successfully'
                                            });
                                        }
                                    })


                                }
                            });
                        }
                    }
                });
            } else {
                res.json({
                    'code': 402,
                    'message': 'No record found'
                });
            };
        })
    }
}

/**
 * Function is use to Get Clinician By Id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 24-June-2017
 */
function getClinicianById(req, res) {
    console.log("in get clinician");
    co(function* () {
        var id = req.swagger.params.id.value;
        let clinicianInfo = yield Clinician.findById(id).populate('user_id').exec();
        res.json({
            'code': 200,
            status: 'success',
            "message": constantsObj.messages.dataRetrievedSuccess,
            "data": clinicianInfo
        });
    }).catch(function (err) {
        res.json({
            'code': 402,
            status: 'failed',
            "message": utility.validationErrorHandler(err),
            "data": {}
        });
    });
}

/**
 * Function is use to Enable Disable Clinician
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-June-2017
 */
function enableDisableClinician(req, res) {
    if (!req.body.userId || req.body.status == null) {
        res.json({
            code: 402,
            status: 'failed',
            message: constantsObj.validationMessages.requiredFieldsMissing
        });
    } else {
        Clinician.findById(req.body.userId).exec(function (err, data) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else {
                if (!data) {
                    res.json({
                        'code': 402,
                        status: 'failed',
                        message: constantsObj.validationMessages.userNotFound
                    });
                } else {
                    data.status = req.body.status;
                    data.save(function (err) {
                        if (err) {
                            res.json({
                                code: 404,
                                message: utility.validationErrorHandler(err)
                            });
                        } else {
                            User.findById(data.user_id).exec(function (err, userData) {
                                if (err) {
                                    res.json({
                                        code: 404,
                                        message: utility.validationErrorHandler(err)
                                    });
                                } else if (userData) {
                                    userData.status = req.body.status;
                                    userData.save(function (err) {
                                        if (err) {
                                            res.json({
                                                code: 404,
                                                message: utility.validationErrorHandler(err)
                                            });
                                        } else {
                                            res.json({
                                                'code': 200,
                                                status: 'success',
                                                "message": 'Clinician ' + ((req.body.status == true) ? 'activated' : 'deactivated') + ' successfully'
                                            })
                                        }
                                    })

                                } else {
                                    res.json({
                                        'code': 402,
                                        status: 'failed',
                                        message: constantsObj.validationMessages.userNotFound
                                    });
                                }
                            })
                        }
                    })

                }
            }
        })
    }
}

function getClinicianDetails(req, res) {
    Clinician.findOne({
        user_id: req.user.id
    }).populate('user_id').lean().exec(function (err, data) {
        if (err) {
            res.json({
                'code': 402,
                'message': 'Clinician data not found'
            })
        } else {
            res.json({
                code: 200,
                data: data
            })
        }
    })
}

function updateClinicianProfile(req, res) {
    var timestamp = Number(new Date()); // current time as number
    console.log(req.body);
    var file = req.swagger.params.file.value;
    var first_name = req.swagger.params.first_name.value;
    var last_name = req.swagger.params.last_name.value;
    var SSN = req.swagger.params.SSN.value;
    var address = req.swagger.params.address.value;
    var mobile_no = req.swagger.params.mobile_no.value;
    var city = req.swagger.params.city.value;
    var state = req.swagger.params.state.value;
    var zip_code = req.swagger.params.zip_code.value;
    var country = req.swagger.params.country.value;
    var hospital_id = req.swagger.params.hospital_id.value;
    var clinician_npi_no = req.swagger.params.clinician_npi_no.value;
    //console.log("first_name", first_name);
    var user_id = req.user.id;
    if (file) {
        var splitFile = file.originalname.split('.');
        var filename = +timestamp + '_' + common.randomToken(6) + '.' + ((splitFile.length > 0) ? splitFile[splitFile.length - 1] : file.originalname);
        var imagePath = "./public/assets/uploads/profile/" + filename;
    }
    var obj = {};
    obj.first_name = first_name;
    obj.last_name = last_name;
    obj.SSN = SSN;
    obj.address = address;
    obj.mobile_no = mobile_no;
    obj.city = city;
    obj.state = state;
    obj.zip_code = zip_code;
    obj.country = country;
    obj.hospital_id = hospital_id;
    obj.clinician_npi_no = clinician_npi_no;
    if (file) {
        obj.file = file;
    }
    // utility.fileUpload(imagePath, file.buffer).then(function() {
    function update() {
        Clinician.findOne({
            user_id: user_id
        }).then(function (clinician) {
            if (filename) {
                clinician.image = "assets/uploads/profile/" + filename;
            }
            clinician.first_name = first_name;
            clinician.last_name = last_name;
            clinician.SSN = SSN;
            clinician.address = address;
            clinician.mobile_no = mobile_no;
            clinician.city = city;
            clinician.state = state;
            clinician.zip_code = zip_code;
            clinician.country = country;
            clinician.hospital_id = hospital_id;
            clinician.clinician_npi_no = clinician_npi_no;
            if (clinician.image) {
                clinician.image = clinician.image;
            }
            clinician.save(function (err, ItemImage) {
                if (err) {
                    res.json({
                        code: 500,
                        message: constantsObj.validationMessages.internalError
                    });
                } else {
                    res.json({
                        code: 200,
                        message: 'Profile updated successfully'
                    });
                }
            });

        }).catch(function (err) {
            console.log("err", err);
            res.json({
                code: 500,
                message: constantsObj.validationMessages.internalError,
                data: err
            });
        });
    }
    if (file) {
        fs.writeFile(path.resolve(imagePath), file.buffer, function (err) {
            if (err) {
                res.json({
                    code: 402,
                    'message': 'Request could not be processed. Please try again.',
                    data: {}
                });
            } else {
                update();
            }
        });
    } else {
        update();
    }
}

/**
 * Function is use to Get Clinician By Hospital Id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 05-July-2017
 */
function getClinicianByHospitalId(req, res) {
    console.log("in get clinician by hospital id");
    co(function* () {
        var id = req.swagger.params.id.value;
        let clinicianInfo = yield Clinician.find({
            hospital_id: id
        }).populate('user_id').exec();
        res.json({
            'code': 200,
            status: 'success',
            "message": constantsObj.messages.dataRetrievedSuccess,
            "data": clinicianInfo
        });
    }).catch(function (err) {
        res.json({
            'code': 402,
            status: 'failed',
            "message": utility.validationErrorHandler(err),
            "data": {}
        });
    });
}


/*function getAllAppointmentByClinicianId(req, res) {
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
    for (var key in req.body) {
        var reg = new RegExp("sorting", 'gi');
        if (reg.test(key)) {
            var value = req.body[key];
            key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
            var sorting = {};
            if (value == 1 || value == -1) {
                sorting[key] = value;
            } else {
                sorting[key] = (value == 'desc') ? -1 : 1;
            }
        }
    }
    Clinician.findOne({ user_id: req.user.id }).lean().exec(function(clinicianErr, clinicianData) {
        if (clinicianErr) {
            res.json({
                code: 404,
                message: 'Clinician Data Not Found'
            })
        } else {
            var condition = { is_deleted: false, clinician_id: clinicianData._id };
            console.log(condition, "condition");
            Appointment.find(condition)
                .limit(parseInt(count))
                .skip(parseInt(skip))
                .sort(sorting).populate({
                    path: 'hospital_id',
                    select: 'hospital_name'
                }).populate({
                    path: 'clinician_id',
                    select: 'first_name last_name'
                }).lean().exec(function(err, hospital) {
                    if (err) {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        });
                    } else if (hospital) {
                        Appointment.find(condition)
                            .count()
                            .exec(function(err, totalCount) {
                                if (err) {
                                    res.json({
                                        code: 404,
                                        message: 'TotalCount Not Correct'
                                    })
                                } else {
                                    console.log("totalCount", totalCount)
                                    res.json({
                                        code: 200,
                                        data: hospital,
                                        totalCount: totalCount
                                    })

                                }
                            });
                    } else {
                        res.json({
                            code: 404,
                            message: constantsObj.messages.noDataFound
                        })
                    }
                }).catch(function(err) {
                    return res.json(Response(402, utility.validationErrorHandler(err), err));
                })
        }
    })
}*/


function getAllAppointmentByClinicianId(req, res) {
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = req.body.sorting ? req.body.sorting : {
        _id: -1
    };

    for (var key in req.body) {
        var reg = new RegExp("sorting", 'gi');
        if (reg.test(key)) {
            var value = req.body[key];
            key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
            var sorting = {};
            if (value == 1 || value == -1) {
                sorting[key] = value;
            } else {
                sorting[key] = (value == 'desc') ? -1 : 1;
            }
        }
    }

    Clinician.findOne({
        user_id: req.user.id
    }).lean().exec(function (clinicianErr, clinicianData) {
        if (clinicianErr) {
            res.json({
                code: 404,
                message: 'Clinician Data Not Found'
            })
        } else {
            var condition = {};
            var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            console.log("searchText", searchText);
            if (req.body.searchText) {
                condition.$or = [{
                    'title': new RegExp(searchText, 'gi')
                },
                {
                    'first_name': new RegExp(searchText, 'gi')
                },
                {
                    'last_name': new RegExp(searchText, 'gi')
                },
                {
                    'mobile_no': new RegExp(searchText, 'gi')
                },
                ];
            }
            condition.is_deleted = false;
            condition.clinician_id = clinicianData._id;
            console.log(condition, "condition");
            var aggregateQuery = [{ //Service details
                $lookup: {
                    from: "patients",
                    localField: "patient_id",
                    foreignField: "_id",
                    as: "patentInfo"
                }
            },
            {
                $unwind: "$patentInfo"
            },
            {
                $match: condition
            }, {
                $project: {
                    title: 1,
                    description: 1,
                    createdAt: 1,
                    appointment_status: 1,
                    patentInfo: {
                        first_name: 1,
                        last_name: 1,
                    }
                }
            }
            ];

            var countQuery = [].concat(aggregateQuery);
            aggregateQuery.push({
                $sort: sorting
            });
            aggregateQuery.push({
                $skip: parseInt(skip)
            });
            aggregateQuery.push({
                $limit: parseInt(count)
            });
            Appointment.aggregate(aggregateQuery).then(function (result) {
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                Appointment.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    // data.totalCount = cnt;
                    var newArr = [];
                    var filed = ['title', 'description', 'appointment_status'];
                    utility.decryptedRecord(result, filed, function (newArr) {
                        res.json({
                            code: 200,
                            data: newArr,
                            totalCount: cnt
                        })
                    });
                });
            }).catch(function (err) {
                console.log("err", err);
                return res.json({
                    code: 404,
                    message: 'internal Error'
                });
            });




        }
    })
}

function getAllOrderTestByPatientId(req, res) {
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = req.body.sorting ? req.body.sorting : {
        _id: -1
    };
    for (var key in req.body) {
        var reg = new RegExp("sorting", 'gi');
        if (reg.test(key)) {
            var value = req.body[key];
            key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
            var sorting = {};
            if (value == 1 || value == -1) {
                sorting[key] = value;
            } else {
                sorting[key] = (value == 'desc') ? -1 : 1;
            }
        }
    }

    var condition = {
        is_deleted: false,
        patient_id: req.body.id
    };
    console.log(condition, "condition");
    OrderTest.find(condition)
        .limit(parseInt(count))
        .skip(parseInt(skip))
        .sort(sorting).lean().exec(function (err, data) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (data) {
                OrderTest.find(condition)
                    .count()
                    .exec(function (err, totalCount) {
                        if (err) {
                            res.json({
                                code: 404,
                                message: 'TotalCount Not Correct'
                            })
                        } else {
                            console.log("data", data);
                            console.log("totalCount", totalCount)
                            res.json({
                                code: 200,
                                data: data,
                                totalCount: totalCount
                            })

                        }
                    });
            } else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        }).catch(function (err) {
            return res.json(Response(402, utility.validationErrorHandler(err), err));
        })

}

function viewTestOrderById(req, res) {
    var id = req.swagger.params.id.value;
    OrderTest.findOne({
        _id: id
    }).exec(function (err, data) {
        if (err) {
            res.json({
                'code': 402,
                'message': 'Order Test Data Not Found'
            })
        } else {
            res.json({
                'code': 200,
                'data': data
            })
        }
    })
}

function getAllCarePlanByPatientId(req, res) {
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = req.body.sorting ? req.body.sorting : {
        _id: -1
    };
    for (var key in req.body) {
        var reg = new RegExp("sorting", 'gi');
        if (reg.test(key)) {
            var value = req.body[key];
            key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
            var sorting = {};
            if (value == 1 || value == -1) {
                sorting[key] = value;
            } else {
                sorting[key] = (value == 'desc') ? -1 : 1;
            }
        }
    }
    var condition = {};
    var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
    console.log("searchText", searchText);
    if (req.body.searchText) {
        condition.$or = [{
            'dosage': new RegExp(searchText, 'gi')
        }, {
            'medicine': new RegExp(searchText, 'gi')
        }];
    }
    condition.is_deleted = false;
    condition.patient_id = req.body.id;
    console.log(condition, "condition");
    CarePlan.find(condition)
        .limit(parseInt(count))
        .skip(parseInt(skip))
        .sort(sorting).lean().exec(function (err, data) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (data) {
                CarePlan.find(condition)
                    .count()
                    .exec(function (err, totalCount) {
                        if (err) {
                            res.json({
                                code: 404,
                                message: 'TotalCount Not Correct'
                            })
                        } else {
                            res.json({
                                code: 200,
                                data: data,
                                totalCount: totalCount
                            })

                        }
                    });
            } else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        }).catch(function (err) {
            return res.json(Response(402, utility.validationErrorHandler(err), err));
        })

}



function viewCarePlanById(req, res) {
    var id = req.swagger.params.id.value;
    CarePlan.findOne({
        _id: id
    }).exec(function (err, data) {
        if (err) {
            res.json({
                'code': 402,
                'message': 'Care Plan Data Not Found'
            })
        } else {
            res.json({
                'code': 200,
                'data': data
            })
        }
    })
}
/**
 * Function is use to Get Assign Patient By Hospital
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 06-Feb-2018
 **/

function getAssignPatientForClinician(req, res) {
    co(function* () {
        let clinicianUserId = yield User.find({
            _id: req.user.id,
            is_deleted: false
        }).exec();
        let clinicianId = yield Clinician.find({
            user_id: clinicianUserId,
            is_deleted: false
        }).exec();
        let assignUsers = yield HospitalAssign.find({
            assign_id: clinicianId,
            is_deleted: false
        }).populate('patient_id').exec();
        for (var i = 0; i < assignUsers.length; i++) {
            assignUsers[i].patient_id.first_name = decrypt(assignUsers[i].patient_id.first_name);
            assignUsers[i].patient_id.last_name = decrypt(assignUsers[i].patient_id.last_name);
            assignUsers[i].patient_id.mobile_no = decrypt(assignUsers[i].patient_id.mobile_no);
        }
        return res.json({
            'code': 200,
            status: 'success',
            "data": assignUsers
        });
    }).catch(function (err) {
        res.json({
            'code': 402,
            status: 'failed',
            "message": utility.validationErrorHandler(err),
            "data": {}
        });
    });
}

/**
 * Function is use to All entites linked to hospital
 * @access private
 * @return json
 * Created by Swapnali Jare
 * @smartData Enterprises (I) Ltd
 * Created Date 06-Feb-2018
 */
function getAllEntitiesLinkedToClinician(req, res) {
    co(function* () {
        let clinicianInfo = yield Clinician.findOne({
            user_id: req.user.id,
            is_deleted: false
        }).populate('hospital_id').lean().exec();

        clinicianInfo = yield Clinician.populate(clinicianInfo, {
            path: 'hospital_id.user_id',
            model: 'User'
        });

        // console.log("before clinicianInfo-->", clinicianInfo);
        let assignedPatientList = yield HospitalAssign.find({
            assign_id: clinicianInfo._id,
            is_deleted: false
        }).populate('patient_id').populate('role_id').lean().exec();
        assignedPatientList = yield HospitalAssign.populate(assignedPatientList, {
            path: 'patient_id.user_id',
            model: 'User'
        });
        //console.log("before assignedPatientList-->", assignedPatientList);
        for (var i = 0; i < assignedPatientList.length; i++) {
            //  console.log("assignedPatientList[i]-->", i, assignedPatientList[i]);
            assignedPatientList[i].name = decrypt(assignedPatientList[i].patient_id.first_name) + ' ' + decrypt(assignedPatientList[i].patient_id.last_name);
            assignedPatientList[i].mobile_no = decrypt(assignedPatientList[i].patient_id.mobile_no);
            assignedPatientList[i].email = assignedPatientList[i].patient_id.user_id.email;
            assignedPatientList[i].userid = assignedPatientList[i].patient_id.user_id._id;
            assignedPatientList[i].userType = 'Patient';
            //  console.log("assignedPatientList[i]--->", assignedPatientList[i]);
        }
        if (clinicianInfo) {
            let hosptalInfo = clinicianInfo.hospital_id;
            console.log("hosptalInfo--->", hosptalInfo);
            hosptalInfo.role = 'Hospital';
            hosptalInfo.name = hosptalInfo.hospital_name;
            hosptalInfo.mobile_no = hosptalInfo.hospital_mobile_no;
            hosptalInfo.email = hosptalInfo.user_id.email;
            hosptalInfo.userid = hosptalInfo.user_id._id;
            assignedPatientList.push(hosptalInfo);
        }
        // console.log("assignedUserList--->", assignedPatientList);
        return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": assignedPatientList });
    }).catch(function (err) {
        console.log("getAllEntitiesLinkedToClinician Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}