'use strict';

var twilio = require('twilio');
var AccessToken = twilio.jwt.AccessToken;
var ChatGrant = AccessToken.ChatGrant;
var co = require('co');

function TokenProvider(credentials) {
  Object.defineProperties(this, {
    accountSid: {
      enumerable: true,
      value: credentials.accountSid
    },
    signingKeySid: {
      enumerable: true,
      value: credentials.signingKeySid
    },
    signingKeySecret: {
      enumerable: true,
      value: credentials.signingKeySecret || credentials.authToken
    },
    serviceSid: {
      enumerable: true,
      value: credentials.serviceSid || credentials.instanceSid
    },
    pushCredentialSid: {
      enumerable: true,
      value: credentials.pushCredentialSid
    }
  });
}

//var token = tokenProvider.getToken(identity, endpointId, userId);
//console.log("token---------------->", token);


TokenProvider.prototype.getToken = function (req, res) {
  var self = this;
  var identity = req.query && req.query.identity;
  var endpointId = req.query && req.query.endpointId;
  var userId = req.query && req.query.userId;
   console.log("req.query--->", req.query);
  if (!identity || !endpointId || !userId) {
    res.status(400).send('getToken requires both an Identity and an Endpoint ID and userid');
  } else {
    User.findOne({ _id: userId }).exec(function (err, userInfo) {
      if (err) {
        res.json({
          code: 404,
          message: utility.validationErrorHandler(err)
        });
      } else {
        if (userInfo) {
          console.log("-----this.accountSid------", self.accountSid);
          console.log("-----userInfo------", userInfo);
          var token = new AccessToken(self.accountSid, self.signingKeySid, self.signingKeySecret, {
            identity: userInfo.email,
            ttl: 40000
          });

          var grant = new ChatGrant({ pushCredentialSid: self.pushCredentialSid });

          grant.serviceSid = self.serviceSid;
          grant.endpointId = self.serviceSid + identity + endpointId;
          token.addGrant(grant);
          res.send(token.toJwt()); 
        }
      }
    });
  }
};

module.exports = TokenProvider;
