'use strict';

var mongoose = require('mongoose'),
    config = require('../../config/config.js'),
    RiskAssessments = mongoose.model('RiskAssessments'),
    Ethnicities = mongoose.model('Ethnicities'),
    Role = mongoose.model('Role'),
    DeviceManagement = mongoose.model('DeviceManagement'),
    Rule = mongoose.model('Rule'),
    RulesEngine = mongoose.model("RulesEngines"),
    SmsTemplateAdmin = mongoose.model("SmsTemplateAdmin"),
    Patient = mongoose.model('Patient'),
    Hospital = mongoose.model('Hospital'),
    User = mongoose.model('User'),
    Ecgmeasure = mongoose.model('Ecgmeasure'),
    Ecgfile = mongoose.model('Ecgfile'),
    co = require('co'),
    DiabetesStatus = mongoose.model('DiabetesStatus'),
    SmokingStatus = mongoose.model('SmokingStatus'),
    User = mongoose.model('User'),
    Country = mongoose.model('Country'),
    Language = mongoose.model('Language'),
    ServiceType = mongoose.model('ServiceType'),
    crypto = require('crypto'),
    utility = require('../lib/utility.js'),
    async = require('async'),
    fs = require('fs'),
    path = require('path'),
    twilio = require('../lib/twilio'),
    constantsObj = require('../lib/constants'),
    common = require('../../config/common.js');
var kmeans = require('kmeans-node');
var kmeancluster = require('kmeans-js');
var path = require('path');
var csv = require('fast-csv');


module.exports = {
    addRiskAssessment: addRiskAssessment,
    addEthinicity: addEthinicity,
    getEthinicity: getEthinicity,
    addDiabetesStatus: addDiabetesStatus,
    getDiabetesStatus: getDiabetesStatus,
    addSmokingStatus: addSmokingStatus,
    addCountry: addCountry,
    addServiceType: addServiceType,
    getCountry: getCountry,
    getServiceType: getServiceType,
    getSmokingStatus: getSmokingStatus,
    updateRules: updateRules,
    getRules: getRules,
    kmeansfactor: kmeansfactor,
    uploadcsv: uploadcsv,
    getCsvlist: getCsvlist,
    getAdminDetails: getAdminDetails,
    updateAdminProfile: updateAdminProfile,
    kmeansData: kmeansData,
    addLanguage: addLanguage,
    getLanguage: getLanguage,
    getDeviceManagementList: getDeviceManagementList,
    getDeviceManagementById: getDeviceManagementById,
    editDeviceManagement: editDeviceManagement,
    enableDisableDevice: enableDisableDevice,
    getdeviceType: getdeviceType,
    addRulesEngines: addRulesEngines,
    getAllRulesEngines: getAllRulesEngines,
    getRulesEnginesById: getRulesEnginesById,
    deleteRulesEngine: deleteRulesEngine,
    enableDisableRules: enableDisableRules,
    setDefault: setDefault,
    getDefaultRulesEngine: getDefaultRulesEngine,
    getRulesEnginesforRisk: getRulesEnginesforRisk,
    getHospitalForReg: getHospitalForReg,

    addSmsTemplateByAdmin: addSmsTemplateByAdmin,
    getSmsTemplateListByAdmin: getSmsTemplateListByAdmin,
    getSmsTemplateByIdAdmin: getSmsTemplateByIdAdmin,
    deleteSmsTemplateByAdmin: deleteSmsTemplateByAdmin
};

/**
 * Function is use to Add Patient 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 6-June-2017
 */
function addRiskAssessment(req, res) {
    console.log("------------------------------------------", req.body);
    co(function* () {
        var RiskAssessmentsObj = {};
        var field = ['patient_id', 'ethnicity_id', 'smoking_status_id', 'diabetes_status_id', 'cholesterol', 'body_mass', 'blood_pressure', 'risk'];
        var obj = req.body;
        var risk;
        var cholesterol = req.body.cholesterol.total_cholesterol;
        var systolicBloodPressure = req.body.blood_pressure.systolic;
        var distolic = req.body.blood_pressure.diastolic;
        var age = req.body.age;
        var hdl = req.body.cholesterol.HDL;
        var meds = req.body.bp_treatment;
        var diabetes = req.body.diabetes;
        var smoking = req.body.smoker;
        var gender = req.body.gender;
        var mobile_no = req.body.mobile_no;

        console.log("age", req.body.age);
        console.log("gender", req.body.gender);
        console.log("smoking", req.body.smoker);
        console.log("diabetes", req.body.diabetes);
        console.log("cholesterol", req.body.cholesterol.total_cholesterol);
        console.log("hdl", req.body.cholesterol.HDL);
        console.log("systolicBloodPressure", req.body.blood_pressure.systolic);

        if (gender == 'Male') { // For Male
            var dm = diabetes ? 0.57367 : 0;
            var smoke = smoking ? 0.65451 : 0;
            var medications = meds ? 1.99881 : 1.93303;
            console.log(dm, smoke, medications);
            var riskfactor = (Math.log(age) * 3.06117) + (Math.log(cholesterol) * 1.12370) - (Math.log(hdl) * 0.93263) + (Math.log(systolicBloodPressure) * medications + smoke + dm - 23.9802);
            risk = 100 * (1 - Math.pow(0.88936, riskfactor));
            console.log("risk1", risk);
        } else { // For Female
            var dm = diabetes ? 0.69154 : 0;
            var smoke = smoking ? 0.52873 : 0;
            var medications = meds ? 2.82263 : 2.76157;
            var riskfactor = (Math.log(age) * 2.32888) + (Math.log(cholesterol) * 1.20904) - (Math.log(hdl) * 0.70833) + (Math.log(systolicBloodPressure) * medications + smoke + dm - 26.1931);
            risk = 100 * (1 - Math.pow(0.95012, riskfactor));
        }

        obj.risk = risk;

        utility.encryptedRecord(obj, field, function (RiskAssessmentsObj) {
            //console.log("RiskAssessmentsObj-----", RiskAssessmentsObj);
            var riskAssessments = new RiskAssessments(RiskAssessmentsObj);
            riskAssessments.save(function (err, RiskAssessment) {
                if (err) {
                    res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
                    console.log(err)
                } else {
                    var text = "Total Cholesterol: " + cholesterol + " Normal : 130-320 \n" + "HDL Cholesterol: " + hdl + " Normal: 20-100 \n " + " Systolic BP: " + systolicBloodPressure + " Normal: 90-200 \n" + "Distolic BP: " + distolic + " Normal: 30-140";
                    // var data = { to: '+918789858844', message: text }
                     var data = { to:  mobile_no , message: text }
                    twilio.sendSMS(data, function (returnData) {
                        console.log('twilio', returnData);
                    });
                    //console.log("data---------------", data)
                    res.json({
                        code: 200,
                        message: constantsObj.messages.riskAssessmentSucess,
                        data: RiskAssessment
                    });
                }

            });
        })
    }).catch(function (err) {
        console.log("err++++++++++++++", err);
        res.json({
            code: 404,
            message: utility.validationErrorHandler(err)
        });
    });
}

function addEthinicity(req, res) {
    Ethnicities.save(function (err, data) {
        if (err) {
            console.log(err, "errerrerrerrerrerrerr");
        } else {
            console.log(data, "datadatadatadata");
        }
    });
}


function getEthinicity(req, res) {
    Ethnicities.find({ is_deleted: false }).exec(function (err, data) {
        if (err) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Ethnicity data not found'
            });
        } else {
            res.json({
                'code': config.httpSuccess,
                'data': data
            });
        }
    });
}

/**
 * Function is use to Add Country 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 22-June-2017
 */
function addCountry(req, res) {
    console.log("add Country", req.body);
    var country = new Country(req.body);
    country.save(function (err, countryData) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
            console.log(err)
        } else {
            res.json({
                code: 200,
                message: constantsObj.messages.addCountrySucess,
                data: countryData
            });
        }
    });
}

/**
 * Function is use to Add Service Type 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 22-June-2017
 */
function addServiceType(req, res) {
    console.log("add service type", req.body);
    var serviceType = new ServiceType(req.body);
    serviceType.save(function (err, serviceData) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
            console.log(err)
        } else {
            res.json({
                code: 200,
                message: constantsObj.messages.addServiceTypeSucess,
                data: serviceData
            });
        }
    });
}

/**
 * Function is use to Get Country 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 22-June-2017
 */
function getCountry(req, res) {
    Country.find({ is_deleted: false, status: true }).lean().exec(function (err, countryData) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (countryData) {
            res.json({
                code: 200,
                message: constantsObj.messages.getCountrySucess,
                data: countryData
            });
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    });
}

/**
 * Function is use to Get Hospital For Patient Reg
 * @access private
 * @return json
 * Created by Rahul Gupta
 * @smartData Enterprises (I) Ltd
 * Created Date 30-Jan-2018
 */
function getHospitalForReg(req, res) {
    Hospital.find({ is_deleted: false, status: true }).lean().exec(function (err, hospitalData) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (hospitalData) {
            res.json({
                code: 200,
                message: constantsObj.messages.hospitalsGetSuccessfully,
                data: hospitalData
            });
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    });
}


/**
 * Function is use to Get Service Type 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 22-June-2017
 */
function getServiceType(req, res) {
    ServiceType.find({ is_deleted: false, status: true }).lean().exec(function (err, serviceData) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (serviceData) {
            res.json({
                code: 200,
                message: constantsObj.messages.getServiceTypeSucess,
                data: serviceData
            });
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    });
}


/**
 * Function is use to Add Diabetes Status  
 * @access private
 * @return json
 * Created by Akshay
 * @smartData Enterprises (I) Ltd
 * Created Date 15-June-2017
 */
function addDiabetesStatus(req, res) {

    console.log('gagfasg-------', req.user.id);
    co(function* () {

        let userData = yield User.findById(req.user.id);
        console.log('userData---', userData);
        if (userData) {
            console.log('gagfasg----1111---', req.body);
            var diabetes = new DiabetesStatus(req.body)
            diabetes.save(function (err, diabetesdata) {
                if (err) {
                    res.json({ code: 400, message: 'DiabetesStatusNotAdded' });
                } else {
                    res.json({ code: 200, message: 'DiabetesStatusAddedSuccessfully' });
                }
            })

        } else {
            return res.json({ code: 402, message: 'Not valid user 1' });
        }
    }).catch(function (err) {
        console.log(err, 'Error')
        return res.json({ code: 402, message: 'Internal Error' });
    });
}

function getDiabetesStatus(req, res) {
    DiabetesStatus.find({ is_deleted: false }).exec(function (err, data) {
        if (err) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Ethnicity data not found'
            });
        } else {
            res.json({
                'code': config.httpSuccess,
                'data': data
            });
        }
    });
}

function addSmokingStatus(req, res) {

}

function getSmokingStatus(req, res) {
    SmokingStatus.find({ is_deleted: false }).exec(function (err, data) {
        if (err) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Ethnicity data not found'
            });
        } else {
            res.json({
                'code': config.httpSuccess,
                'data': data
            });
        }
    });

}


function updateRules(req, res) {
    console.log(req.body);
    co(function* () {
        let ruleData = yield Rule.findById(req.body._id);
        if (ruleData) {
            ruleData.heart_rate_from = req.body.heart_rate_from;
            ruleData.heart_rate_to = req.body.heart_rate_to;
            ruleData.blood_glucose = req.body.blood_glucose;
            ruleData.blood_pressure = req.body.blood_pressure;
            ruleData.weight = req.body.weight;
            let savedData = yield ruleData.save();
            res.json({
                code: 200,
                message: constantsObj.messages.ruleUpdatedSuccess,
                data: savedData
            });
        } else {
            var rule = new Rule(req.body);
            rule.save(function (err, ruleData) {
                console.log('2', err);
                if (err) {
                    res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
                } else {
                    res.json({
                        code: 200,
                        message: constantsObj.messages.ruleUpdatedSuccess,
                        data: ruleData
                    });
                }

            });
        }
    }).catch(function (err) {
        res.json({
            code: 404,
            message: utility.validationErrorHandler(err)
        });
    });
}


function getRules(req, res) {
    var rulesEngineId = req.swagger.params.id.value;
    console.log("rulesEngineId", rulesEngineId);
    RulesEngine.findOne({ _id: rulesEngineId, status: true, is_deleted: false }).lean().exec(function (err, rulesEngine) {
        if (err) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Rules data not found'
            });
        } else {
            res.json({
                'code': config.httpSuccess,
                'data': rulesEngine
            });
        }
    });
}

function kmeansfactor(req, res) {
    var idarr = req.body.fileid;
    var type = req.body.fileType;
    console.log(type);
    var uniqueTypeArray = type.filter(function (item, pos) {
        return type.indexOf(item) == pos;
    })
    var kfactor = uniqueTypeArray.length;
    console.log('kfactor', kfactor);
    console.log('idarr', idarr);
    Ecgmeasure.find({ ecgfile_id: { $in: idarr } }, { '_id': 0, 'time': 1, 'sign0': 1, 'sign1': 1 }).exec(function (err, data) {
        var datasetArr = []
        if (data.length > 0) {
            data.forEach(function (item, i) {
                if (item.type = 'normal') {
                    var arr = [item.time, item.sign0, item.sign1]
                } else if (item.type = 'superven') {
                    var arr = [item.time, item.sign0, item.sign1]
                } else if (item.type = 'venarh') {
                    var arr = [item.time, item.sign0, item.sign1]
                } else {
                    var arr = [item.time, item.sign0, item.sign1]
                }
                datasetArr.push(arr);
            })
        }

        //  console.log("Data==>",datasetArr);
        var km = new kmeancluster({
            K: kfactor
        });
        if (datasetArr.length > 0) {
            km.cluster(datasetArr);
            while (km.step()) {
                km.findClosestCentroids();
                km.moveCentroids();
                if (km.hasConverged()) break;
            }

            var returnArr = [];
            for (var i = 0; i < km.centroids.length; i++) {
                var obj = {}
                obj.centroid = km.centroids[i];
                obj.count = km.clusters[i].length;
                returnArr.push(obj);
            }

            res.json({
                'code': config.httpSuccess,
                'data': returnArr
            });
        } else {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Input data set should not be empty.'
            });
        }

    });
}

function uploadcsv(req, res) {
    var file = req.swagger.params.file.value;
    var filetype = req.swagger.params.filetype.value;
    var filename = file.originalname;
    Ecgfile.findOne({ filename: filename }).exec(function (err, fileData) {
        if (err) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Something went wrong please try again later.'
            });
        } else if (fileData) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'CSV file with the same name already uploaded.'
            });
        } else {
            var filePath = path.resolve('public/upload/' + filename);
            fs.writeFile(filePath, file.buffer, function (err) {
                if (err) {
                    console.log('errror', err);
                } else {
                    var ecgdata = {};
                    ecgdata.filename = filename;
                    ecgdata.filetype = filetype;
                    ecgdata.filepath = 'public/upload/' + filename;
                    var ecgfile = new Ecgfile(ecgdata);
                    ecgfile.save(function (err, ecgfileData) {
                        if (err) {
                            console.log(err);
                        } else {
                            var masterList = [];
                            var fileId = ecgfileData._id;
                            //console.log(fileId);
                            var stream = fs.createReadStream('public/upload/' + filename);
                            csv.fromStream(stream, { headers: true }).on('data', function (data) {
                                masterList.push(data);
                                addToCollection(data, fileId);
                            }).on('end', function () {
                                //console.log(masterList.toString());
                                //console.log(' i m here');
                                res.json({
                                    'code': config.httpSuccess,
                                    'message': 'File uploaded successfully.'
                                });
                            });
                        }
                    });
                }
            })
        }
    });
}

function addToCollection(data, fileId) {
    //create model and save to database
    data.ecgfile_id = fileId;
    var ecgmeasure = new Ecgmeasure(data);
    ecgmeasure.save(function (err) {
        if (err) // ...
            console.log(err);
    });
}

function getCsvlist(req, res) {
    Ecgfile.find({}).exec(function (err, data) {
        if (err) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Files not found'
            });
        } else {
            res.json({
                'code': config.httpSuccess,
                'data': data
            });
        }
    });
}

function getAdminDetails(req, res) {
    console.log("-------", req.user.id);
    User.findOne({ _id: req.user.id }).lean().exec(function (err, data) {
        if (err) {
            res.json({
                'code': 402,
                'message': 'Admin data not found'
            })
        } else {
            res.json({
                'code': 200,
                'data': data
            })
        }
    })
}

function updateAdminProfile(req, res) {
    var timestamp = Number(new Date()); // current time as number
    console.log(req.body);
    var file = req.swagger.params.file.value;
    var first_name = req.swagger.params.first_name.value;
    var last_name = req.swagger.params.last_name.value;
    console.log("first_name", first_name);
    var user_id = req.user.id;
    if (file) {
        var splitFile = file.originalname.split('.');
        var filename = +timestamp + '_' + common.randomToken(6) + '.' + ((splitFile.length > 0) ? splitFile[splitFile.length - 1] : file.originalname);
        var imagePath = "./public/assets/uploads/profile/" + filename;
    }
    var obj = {};
    obj.first_name = first_name;
    obj.last_name = last_name;
    if (file) {
        obj.file = file;
    }
    // utility.fileUpload(imagePath, file.buffer).then(function() {
    function update() {
        User.findOne({ _id: user_id }).then(function (user) {
            if (filename) {
                user.image = "assets/uploads/profile/" + filename;
            }
            if (user.image) {
                user.image = user.image;
            }
            user.first_name = first_name;
            user.last_name = last_name;

            user.save(function (err, ItemImage) {
                if (err) {
                    res.json({ code: 500, message: constantsObj.validationMessages.internalError });
                } else {
                    res.json({ code: 200, message: 'Profile updated successfully' });
                }
            });

        }).catch(function (err) {
            console.log("err", err);
            res.json({ code: 500, message: constantsObj.validationMessages.internalError, data: err });
        });
    }
    if (file) {
        fs.writeFile(path.resolve(imagePath), file.buffer, function (err) {
            if (err) {
                res.json({ code: 402, 'message': 'Request could not be processed. Please try again.', data: {} });
            } else {
                update();
            }
        });
    } else {
        update();
    }
}


function kmeansData(req, res) {
    var result = {};
    Ecgmeasure.find().distinct('type', function (err, ids) {
        if (err) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Something went wrong, please try again later.'
            });
        } else {
            result.centroids = ids;
            result.centroidsLen = ids.length;
            Ecgmeasure.count({}).exec(function (errs, count) {
                if (errs) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Something went wrong, please try again later.'
                    });
                } else {
                    result.observation = count;
                    res.json({
                        'code': config.httpSuccess,
                        'data': result
                    });
                }
            });
        }
    });
}

/**
 * Function is use to Add Language 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 4-July-2017
 */
function addLanguage(req, res) {
    var language = new Language(req.body);
    language.save(function (err, languageData) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
            console.log(err)
        } else {
            res.json({
                code: 200,
                message: constantsObj.messages.addLanguageSucess,
                data: languageData
            });
        }
    });
}

/**
 * Function is use to Get Language 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 4-July-2017
 */
function getLanguage(req, res) {
    Language.find({ is_deleted: false, status: true }).lean().exec(function (err, languageData) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (languageData) {
            res.json({
                code: 200,
                message: constantsObj.messages.getLanguageSucess,
                data: languageData
            });
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    });
}

/**
 * Function is use to Get Device Type
 * @access private
 * @return json
 * Created by Rahul Gupta
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Jan-2018
 */
function getdeviceType(req, res) {
    DeviceManagement.find({ status: true }).lean().exec(function (err, device) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (device) {
            res.json({
                code: 200,
                message: constantsObj.messages.DeviceGettingSuccess,
                data: device
            });
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    });
}


/**
 * Function is use to Get Device Management  
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Jan-2018
 */
function getDeviceManagementList(req, res) {
    DeviceManagement.find({}).exec(function (err, device) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (device) {
            res.json({
                code: 200,
                message: constantsObj.messages.DeviceGettingSuccess,
                data: device
            })
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

// **
//  * Function is use to Get Device By Id  
//  * @access private
//  * @return json
//  * Created by Rahul Gupta
//  * @smartData Enterprises (I) Ltd
//  * Created Date 11-Jan-2018
//  */
function getDeviceManagementById(req, res) {
    var deviceId = req.swagger.params.id.value;
    DeviceManagement.findOne({ _id: deviceId }).lean().exec(function (err, device) {
        console.log("device----->>>>", device);
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (device) {
            res.json({
                code: 200,
                message: constantsObj.messages.DeviceGettingSuccess,
                data: device
            })
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

// **
//  * Function is use to edit Device  
//  * @access private
//  * @return json
//  * Created by Rahul Gupta
//  * @smartData Enterprises (I) Ltd
//  * Created Date 11-Jan-2018
//  */

function editDeviceManagement(req, res) {
    co(function* () {
        let savedData = yield DeviceManagement.findById(req.body._id);
        if (savedData) {
            savedData.deviceName = req.body.deviceName;
            savedData.deviceUrl = req.body.deviceUrl;
            let savedDataNew = yield savedData.save();
            res.json({
                code: 200,
                message: constantsObj.messages.DeviceUpdatedSuccess,
            });
        } else {
            return res.json(Response(402, constantsObj.validationMessages.patientMedicationAddedFailed, err));
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    });
}


/**
 * Function is use to Enable Disable Device
 * @access private
 * @return json
 * Created by Rahul Gupta
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Jan-2018
 */
function enableDisableDevice(req, res) {
    console.log("req.body", req.body);
    if (!req.body.userId || req.body.status == null) {
        res.json({
            code: 402,
            status: 'failed',
            message: constantsObj.validationMessages.requiredFieldsMissing
        });
    } else {
        DeviceManagement.findById(req.body.userId).exec(function (err, data) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else {
                if (!data) {
                    res.json({ 'code': 402, status: 'failed', message: constantsObj.validationMessages.userNotFound });
                } else if (data) {
                    data.status = req.body.status;
                    data.save(function (err) {
                        if (err) {
                            res.json({
                                code: 404,
                                message: utility.validationErrorHandler(err)
                            });
                        } else {
                            res.json({ 'code': 200, status: 'success', "message": 'Device ' + ((req.body.status == true) ? 'activated' : 'deactivated') + ' successfully' })
                        }
                    })

                } else {
                    res.json({ 'code': 402, status: 'failed', message: constantsObj.validationMessages.userNotFound });
                }
            }
        })
    }
}

/**
 * Function is use to Add Rules Engines
 * @access private
 * @return json
 * Created by Rahul Gupta
 * @smartData Enterprises (I) Ltd
 * Created Date 12-Jan-2018
 */
function addRulesEngines(req, res) {
    co(function* () {
        let ruleEnginesData = yield RulesEngine.findById(req.body._id);
        if (ruleEnginesData) {
            ruleEnginesData.rulesEngine_name = req.body.rulesEngine_name;
            ruleEnginesData.heart_rate_from = req.body.heart_rate_from;
            ruleEnginesData.heart_rate_to = req.body.heart_rate_to;
            ruleEnginesData.blood_glucose = req.body.blood_glucose;
            ruleEnginesData.blood_pressure = req.body.blood_pressure;
            ruleEnginesData.weight = req.body.weight;
            ruleEnginesData.hospitalMsg = req.body.hospitalMsg;
            ruleEnginesData.clinicianMsg = req.body.clinicianMsg;
            ruleEnginesData.ambulenceMsg = req.body.ambulenceMsg;
            ruleEnginesData.towingMsg = req.body.towingMsg;
            ruleEnginesData.careMsg = req.body.careMsg;
            ruleEnginesData.cholesterol = req.body.cholesterol;
            let savedData = yield ruleEnginesData.save();
            res.json({
                code: 200,
                message: constantsObj.messages.ruleUpdatedSuccess,
                data: savedData
            });
        } else {
            var rules = new RulesEngine(req.body);
            rules.save(function (err, ruleEnginesData) {
                if (err) {
                    res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
                } else {
                    res.json({
                        code: 200,
                        message: constantsObj.messages.ruleUpdatedSuccess,
                        data: ruleEnginesData
                    });
                }

            });
        }
    }).catch(function (err) {
        res.json({
            code: 404,
            message: utility.validationErrorHandler(err)
        });
    });
}




/**
 * Function is use to Get Rules Engines By Id
 * @access private
 * @return json
 * Created by Rahul Gupta
 * @smartData Enterprises (I) Ltd
 * Created Date 12-Jan-2018
 */
function getRulesEnginesById(req, res) {
    var rulesEngineId = req.swagger.params.id.value;
    RulesEngine.findOne({ _id: rulesEngineId }).lean().exec(function (err, rulesEngine) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (rulesEngine) {
            res.json({
                code: 200,
                message: constantsObj.messages.RulesEngineGettingSuccess,
                data: rulesEngine
            })
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}


/**
 * Function is use to Get All Rules Engines
 * @access private
 * @return json
 * Created by Rahul Gupta
 * @smartData Enterprises (I) Ltd
 * Created Date 12-Jan-2018
 */

function getAllRulesEngines(req, res) {
    RulesEngine.find({ is_deleted: false }).exec(function (err, rulesEngine) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (rulesEngine) {
            res.json({
                code: 200,
                message: constantsObj.messages.RulesEngineGettingSuccess,
                data: rulesEngine
            })
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

/**
 * Function is use to Get All Rules Engines for Risk management
 * @access private
 * @return json
 * Created by Rahul Gupta
 * @smartData Enterprises (I) Ltd
 * Created Date 22-Jan-2018
 */

function getRulesEnginesforRisk(req, res) {
    RulesEngine.find({ is_deleted: false, status: true }).exec(function (err, rulesEngine) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (rulesEngine) {
            res.json({
                code: 200,
                message: constantsObj.messages.RulesEngineGettingSuccess,
                data: rulesEngine
            })
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}


/**
 * Function is use to delete Rules Engine
 * @access private
 * @return json
 * Created by Rahul Gupta
 * @smartData Enterprises (I) Ltd
 * Created Date 12-Jan-2018
 */

function deleteRulesEngine(req, res) {
    console.log("deleteRulesEngine", req.swagger.params.id.value);
    var ruleId = req.swagger.params.id.value;
    RulesEngine.update({ _id: ruleId }, { $set: { is_deleted: true } }, function (err) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else {
            res.json({
                code: 200,
                message: constantsObj.messages.RuleEngineDeleteSuccess,
            })
        }
    })
}



/**
 * Function is use to Enable Disable Rules
 * @access private
 * @return json
 * Created by Rahul Gupta
 * @smartData Enterprises (I) Ltd
 * Created Date 12-Jan-2018
 */
function enableDisableRules(req, res) {
    console.log("req.body", req.body);
    if (!req.body.userId || req.body.status == null) {
        res.json({
            code: 402,
            status: 'failed',
            message: constantsObj.validationMessages.requiredFieldsMissing
        });
    } else {
        RulesEngine.findById(req.body.userId).exec(function (err, data) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else {
                if (!data) {
                    res.json({ 'code': 402, status: 'failed', message: constantsObj.validationMessages.userNotFound });
                } else if (data) {
                    data.status = req.body.status;
                    data.save(function (err) {
                        if (err) {
                            res.json({
                                code: 404,
                                message: utility.validationErrorHandler(err)
                            });
                        } else {
                            res.json({ 'code': 200, status: 'success', "message": 'Rules Engine ' + ((req.body.status == true) ? 'activated' : 'deactivated') + ' successfully' })
                        }
                    })

                } else {
                    res.json({ 'code': 402, status: 'failed', message: constantsObj.validationMessages.userNotFound });
                }
            }
        })
    }
}


/**
 * Function is use to set Default
 * @access private
 * @return json
 * Created by Rahul Gupta
 * @smartData Enterprises (I) Ltd
 * Created Date 18-Jan-2018
 */
function setDefault(req, res) {
    if (!req.body.userId || req.body.is_default == null) {
        res.json({
            code: 402,
            status: 'failed',
            message: constantsObj.validationMessages.requiredFieldsMissing
        });
    } else {
        RulesEngine.update({ is_default: true }, { $set: { is_default: false } }, function (err) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else {
                RulesEngine.update({ _id: req.body.userId }, { $set: { is_default: true } }, function (err) {
                    if (err) {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        });
                    } else {
                        res.json({
                            code: 200,
                            message: constantsObj.messages.ruleUpdatedSuccess,
                        })
                    }
                })
            }
        })

    }
}


/**
 * Function is use to Get Default Rules Engine
 * @access private
 * @return json
 * Created by Rahul Gupta
 * @smartData Enterprises (I) Ltd
 * Created Date 12-Jan-2018
 */
function getDefaultRulesEngine(req, res) {
    // var rulesEngineId = req.swagger.params.id.value;
    RulesEngine.findOne({ is_default: true }).lean().exec(function (err, rulesEngine) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (rulesEngine) {
            res.json({
                code: 200,
                message: constantsObj.messages.RulesEngineGettingSuccess,
                data: rulesEngine
            })
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}



/**
 * Function is use to Add SMS Template 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 16-Feb-2018
 */
function addSmsTemplateByAdmin(req, res) {
    co(function* () {
        let savedData = yield SmsTemplateAdmin.findById(req.body._id);
        if (savedData) {
            savedData.title = req.body.title;
            savedData.smsMessage = req.body.smsMessage;
            let savedDataNew = yield savedData.save();
            res.json({
                code: 200,
                message: 'Update SMS Template Succesfully',
            });
        } else if (!savedData) {
            var smsObj = req.body;
            console.log("req.body-------->>>>>", smsObj);
            smsObj.status = true;
            var smsData = new SmsTemplateAdmin (smsObj);
            smsData.save(function (err, smsData) {
                if (err) {
                    res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
                } else {
                    res.json({
                        code: 200,
                        message: 'Add SMS Template Succesfully',
                        data: smsData
                    });
                }
            });
        } else {
            return res.json(Response(402, constantsObj.validationMessages.patientMedicationAddedFailed, err));
        }
    }).catch(function (err) {
        console.log("err-------->>", err);
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    });
}

/**
 * Function is use to Get SMS Template 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 16-Feb-2018
 */
function getSmsTemplateListByAdmin(req, res) {
    co(function* () {
        console.log("req.user.id", req.user.id);
        SmsTemplateAdmin.find({ is_deleted:false }).exec(function (err, emailData) {
            console.log('SmsTemplateAdmin',emailData);
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (emailData) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientsGetSuccessfully,
                    data: emailData
                })
            }
            else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}


/**
 * Function is use to Get Email Message
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 16-Feb-2018
 */
function getSmsTemplateByIdAdmin(req, res) {
    var id = req.swagger.params.id.value;
    SmsTemplateAdmin.findOne({ _id: id }).exec(function (err, data) {
        if (err) {
            res.json({
                'code': 402,
                'message': 'No record found'
            });
        } else {
            res.json({
                code: 200,
                data: data
            });
        }
    })
}
/**
 * Function is use to delete Template
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 16-Feb-2018
 */
function deleteSmsTemplateByAdmin(req, res) {
    var smsId = req.swagger.params.id.value;
    SmsTemplateAdmin.update({ _id: smsId }, { $set: { is_deleted: true } }, function (err) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else {
            res.json({
                code: 200,
                message: 'SMS Template Delete Successfully',
            })
        }
    })
}