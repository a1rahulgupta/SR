'use strict';

var mongoose = require('mongoose'),
    co = require('co'),
    constant = require('../lib/constants'),
    utility = require('../lib/utility.js'),
    async = require('async'),
    constantsObj = require('../lib/constants'),
    User = mongoose.model('User'),
    crypto = require('crypto'),
    Clinician = mongoose.model('Clinician'),
    Hospital = mongoose.model('Hospital'),
    CareCoordinator = mongoose.model('CareCoordinator'),
    Ambulance = mongoose.model('Ambulance'),
    Towing = mongoose.model('Towing'),
    Patient = mongoose.model('Patient'),
    Role = mongoose.model('Role'),
    Response = require('../lib/response.js'),
    config = require('../../config/config.js'),
    validator = require('../../config/validator.js'),
    algorithm = constantsObj.config.cryptoAlgorithm,
    password = constantsObj.config.cryptoPassword,
    twilio = require('../lib/twilio'),
    SmsHistory = mongoose.model('SmsHistory'),
    EmailHistory = mongoose.model('EmailsHistory');

module.exports = {
    sendSMS: sendSMS,
    getAllAllignedUsers: getAllAllignedUsers,
    getSmsMsgList: getSmsMsgList,
    getSentSMSList: getSentSMSList,
    deleteEmailByHospital: deleteEmailByHospital,
    deleteSmsByHospital: deleteSmsByHospital,
    markSmsAsRead: markSmsAsRead,
    getUnreadSmsCount: getUnreadSmsCount
}

function decrypt(decText) {
    var decipher = crypto.createDecipher(algorithm, password)
    var decText = decipher.update(decText, 'hex', 'utf8')
    decText += decipher.final('utf8');
    return decText;
}
/**
 * Function is use to Get Disease  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 14-June-2017
 */
function getUserList(req, res) {
    console.log("in getUserList list");
    co(function* () {
        let userList = yield User.find({}).lean().exec();
        for (var i = 0; i < userList.length; i++) {
            console.log("userList[i]-->", userList[i]);
            let userInfo = {};
            let name = '';
            let roleInfo = yield Role.findOne({ _id: userList[i].role_id, is_deleted: false, status: true }).exec();
            console.log("roleInfo-->", roleInfo);
            if (roleInfo.name == 'Patient') {
                userInfo = yield Patient.findOne({ is_deleted: false, user_id: userList[i]._id }, { 'first_name': true, 'last_name': true }).lean();
                console.log(" Patient userInfo-->", userInfo);
                if (userInfo) {
                    userInfo.first_name = decrypt(userInfo.first_name);
                    userInfo.last_name = decrypt(userInfo.last_name);
                    name = userInfo.first_name + "  " + userInfo.last_name;
                }
            }
            else if (roleInfo.name == 'Hospital') {
                userInfo = yield Hospital.findOne({ user_id: userList[i]._id }, { 'hospital_name': true }).lean();
                console.log(" Hospital userInfo-->", userInfo);
                if (userInfo) {
                    name = userInfo.hospital_name;
                }
            }
            else if (roleInfo.name == 'Clinician') {
                userInfo = yield Clinician.findOne({ user_id: userList[i]._id }, { 'last_name': true, 'first_name': true }).lean();
                console.log(" Clinician userInfo-->", userInfo);
                if (userInfo) {
                    name = userInfo.first_name + "  " + userInfo.last_name;
                }
            }
            else if (roleInfo.name == 'CareCoordinator') {
                userInfo = yield CareCoordinator.findOne({ user_id: userList[i]._id }, { 'last_name': true, 'first_name': true }).lean();
                console.log(" CareCoordinator userInfo-->", userInfo);
                if (userInfo) {
                    name = userInfo.first_name + "  " + userInfo.last_name;
                }
            }
            else if (roleInfo.name == 'Ambulance') {
                userInfo = yield Ambulance.findOne({ user_id: userList[i]._id }, { 'company_name': true }).lean();
                console.log(" Ambulance userInfo-->", userInfo);
                if (userInfo) {
                    name = userInfo.company_name;
                }
            }
            else if (roleInfo.name == 'Towing') {
                userInfo = yield Towing.findOne({ user_id: userList[i]._id }, { 'company_name': true }).lean();
                console.log(" Towing userInfo-->", userInfo);
                if (userInfo) {
                    name = userInfo.company_name;
                }
            }
            userList[i].name = name;
            console.log("userList[i]", userList[i]);
        }
        console.log("after userList-->", userList);
        return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": userList });
    }).catch(function (err) {
        console.log("getVisitById Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}

function sendSMS(req, res) {
    console.log("sendSMS--->", req.body);
    co(function* () {
        var recieverList = req.body.sms_to;
        let fromUserInfo = yield User.findById(req.user.id).lean().exec();
        let fromName = '';
        if (!validator.isValid(recieverList) || !validator.isValid(req.body.sms_message)) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Required fields are missing'
            });
        } else {
            let roleInfo = yield Role.findOne({ _id: fromUserInfo.role_id, is_deleted: false, status: true }).exec();
            if (roleInfo.name == 'Patient') {
                fromUserInfo = yield Patient.findOne({ is_deleted: false, user_id: req.user.id }, { 'first_name': true, 'last_name': true }).lean();
                console.log(" Patient fromUserInfo-->", fromUserInfo);
                if (fromUserInfo) {
                    fromUserInfo.first_name = decrypt(fromUserInfo.first_name);
                    fromUserInfo.last_name = decrypt(fromUserInfo.last_name);
                    fromName = fromUserInfo.first_name + "  " + fromUserInfo.last_name;
                }
            }
            else if (roleInfo.name == 'Hospital') {
                fromUserInfo = yield Hospital.findOne({ user_id: req.user.id }, { 'hospital_name': true }).lean();
                console.log(" Hospital fromUserInfo-->", fromUserInfo);
                if (fromUserInfo) {
                    fromName = fromUserInfo.hospital_name;
                }
            }
            else if (roleInfo.name == 'Clinician') {
                fromUserInfo = yield Clinician.findOne({ user_id: req.user.id }, { 'last_name': true, 'first_name': true }).lean();
                console.log(" Clinician fromUserInfo-->", fromUserInfo);
                if (fromUserInfo) {
                    fromName = fromUserInfo.first_name + "  " + fromUserInfo.last_name;
                }
            }
            else if (roleInfo.name == 'CareCoordinator') {
                fromUserInfo = yield CareCoordinator.findOne({ user_id: req.user.id }, { 'last_name': true, 'first_name': true }).lean();
                console.log(" CareCoordinator fromUserInfo-->", fromUserInfo);
                if (fromUserInfo) {
                    fromName = fromUserInfo.first_name + "  " + fromUserInfo.last_name;
                }
            }
            else if (roleInfo.name == 'Ambulance') {
                fromUserInfo = yield Ambulance.findOne({ user_id: req.user.id }, { 'company_name': true }).lean();
                console.log(" Ambulance fromUserInfo-->", fromUserInfo);
                if (fromUserInfo) {
                    fromName = fromUserInfo.company_name;
                }
            }
            else if (roleInfo.name == 'Towing') {
                fromUserInfo = yield Towing.findOne({ user_id: req.user.id }, { 'company_name': true }).lean();
                console.log(" Towing fromUserInfo-->", fromUserInfo);
                if (fromUserInfo) {
                    fromName = fromUserInfo.company_name;
                }
            }
            let from_id = {
                name: fromName,
                id: req.user.id
            }
            console.log("from_id--->", from_id);
            recieverList.forEach(function (reciever) {
                console.log("reciever--->", reciever);
                var data = { to: '+918789858844', message: req.body.sms_message };
                twilio.sendSMS(data, (returnData) => {
                    if (returnData.status == 200) {
                        co(function* () {
                            let smsHistoryData = {
                                from_id: from_id,
                                to: reciever,
                                message: req.body.sms_message,
                            }
                            var smsHistoryRecord = new SmsHistory(smsHistoryData);
                            let data = yield smsHistoryRecord.save();
                        });
                    }
                });
            });
            res.json({ code: 200, message: "SMS sent successfully", data: {} })
        }
    }).catch(function (err) {
        console.log("sendSMS Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}

function getSmsMsgList(req, res) {
    console.log("getSmsMsgList--->", req.body);
    console.log("req.user.id--------------->", req.user.id);
    co(function* () {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
        var condition = { is_deleted: false };
        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (req.body.searchText) {
            condition.$or = [{ 'first_name': new RegExp(searchText, 'gi') }, { 'last_name': new RegExp(searchText, 'gi') }, { 'clinician_npi_no': new RegExp(searchText, 'gi') }, { 'SSN': new RegExp(searchText, 'gi') }, { 'mobile_no': new RegExp(searchText, 'gi') }, { 'hospitalInfo.hospital_name': new RegExp(searchText, 'gi') }];
        }
        let aggregate = [
            { $match: condition },
            { "$unwind": "$to" },
            {
                "$group": {
                    _id: { "_id": "$_id", "message": '$message', "from_id": "$from_id", "is_read": "$is_read", "createdAt": "$createdAt" },
                    // to: { $push: "$to" },
                    mcount: { $sum: { $cond: [{ $eq: [req.user.id, "$to.userid"] }, 1, 0] } }
                }
            },
            { $match: { mcount: { $gt: 0 } } },
        ];
        var aggregateCnt = [].concat(aggregate);
        if (req.body.count && req.body.page) {
            console.log("----------in req.body-------------");
            aggregate.push({ $sort: sorting });
            aggregate.push({ $skip: skip });
            aggregate.push({ $limit: count });
        }
        console.log("aggregate--->", aggregate);
        let smsHistoryData = yield SmsHistory.aggregate(aggregate);
        console.log("smsHistoryData-->", smsHistoryData);
        aggregateCnt.push({ $group: { _id: null, count: { $sum: 1 } } });
        let smsHistoryCount = yield SmsHistory.aggregate(aggregateCnt);
        return res.json({ code: 200, message: 'Data retrieved successfully', data: smsHistoryData, totalCount: ((smsHistoryCount[0]) ? smsHistoryCount[0].count : 0) });

    }).catch(function (err) {
        console.log('Error', err);
        return res.json({ code: 400, message: 'Internal server error', data: {} });
    });
}

function getSentSMSList(req, res) {
    console.log("getSentSMSList--->", req.body);
    co(function* () {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
        var condition = { is_deleted: false, "from_id.id": req.user.id };
        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (req.body.searchText) {
            condition.$or = [{ 'first_name': new RegExp(searchText, 'gi') }, { 'last_name': new RegExp(searchText, 'gi') }, { 'clinician_npi_no': new RegExp(searchText, 'gi') }, { 'SSN': new RegExp(searchText, 'gi') }, { 'mobile_no': new RegExp(searchText, 'gi') }, { 'hospitalInfo.hospital_name': new RegExp(searchText, 'gi') }];
        }
        let aggregate = [
            { $match: condition },
        ];
        var aggregateCnt = [].concat(aggregate);
        if (req.body.count && req.body.page) {
            aggregate.push({ $sort: sorting });
            aggregate.push({ $skip: skip });
            aggregate.push({ $limit: count });
        }
        let smsHistoryData = yield SmsHistory.aggregate(aggregate);
        aggregateCnt.push({ $group: { _id: null, count: { $sum: 1 } } });
        let smsHistoryCount = yield SmsHistory.aggregate(aggregateCnt);
        return res.json({ code: 200, message: 'Data retrieved successfully', data: smsHistoryData, totalCount: ((smsHistoryCount[0]) ? smsHistoryCount[0].count : 0) });

    }).catch(function (err) {
        console.log('Error', err);
        return res.json({ code: 400, message: 'Internal server error', data: {} });
    });
}

function getAllAllignedUsers(req, res) {
    console.log("  getAllAllignedUsers---------req.body.patientId----------->", '5a71b378b55ee2629c6c2082');
    co(function* () {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
        var condition = { patient_id: '5a71b378b55ee2629c6c2082' };
        // {patient_id: req.body.patientId}  is_deleted: false,
        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (req.body.searchText) {
            condition.$or = [{ 'first_name': new RegExp(searchText, 'gi') }, { 'last_name': new RegExp(searchText, 'gi') }, { 'clinician_npi_no': new RegExp(searchText, 'gi') }, { 'SSN': new RegExp(searchText, 'gi') }, { 'mobile_no': new RegExp(searchText, 'gi') }, { 'hospitalInfo.hospital_name': new RegExp(searchText, 'gi') }];
        }
        let aggregate = [{
            $lookup: {
                from: 'roles',
                localField: "role_id",
                foreignField: "_id",
                as: "roleInfo"
            }
        },
        { $unwind: { path: "$roleInfo" } },
        { $match: condition },
        ];

        console.log("aggregate--->", aggregate);
        let assignedUserListData = yield HospitalAssign.aggregate(aggregate);
        console.log("assignedUserListData--->", assignedUserListData);
        // var aggregateCnt = [].concat(aggregate);
        // if (req.body.count && req.body.page) {
        //     console.log("----------in req.bosdy-------------");
        //     aggregate.push({ $sort: sorting });
        //     aggregate.push({ $skip: skip });
        //     aggregate.push({ $limit: count });
        // }
        //  console.log("smsHistoryData-->", smsHistoryData);
        //  aggregateCnt.push({ $group: { _id: null, count: { $sum: 1 } } });
        //  let smsHistoryCount = yield HospitalAssign.aggregate(aggregateCnt);
        //  return res.json({ code: 200, message: 'Data retrieved successfully', data: smsHistoryData, totalCount: ((smsHistoryCount[0]) ? smsHistoryCount[0].count : 0) });
        // return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": assignedUserList });
    }).catch(function (err) {
        console.log("getAllAllignedUsers Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}

/**
 * Function is use to delete Emails By Hospital
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 7-Feb-2017
 */
function deleteEmailByHospital(req, res) {
    co(function* () {
        let emailHistoryList = req.body.mailToBeDeleted;
        console.log("deleteEmailByHospital-------->", emailHistoryList);
        for (var i = 0; i < emailHistoryList.length; i++) {
            var email_id = emailHistoryList[i]._id;
            let is_deletedList = emailHistoryList[i].is_deleted;
            is_deletedList.push(req.user.id);
            console.log("is_deletedList--->", is_deletedList);
            let emailNew = yield EmailHistory.update({ _id: email_id }, { $set: { is_deleted: is_deletedList } }).exec();
        }
        return res.json({ 'code': 200, status: 'success', "message": "Delete Mail Successfully", "data": {} });
    }).catch(function (err) {
        console.log("getSentSMSList Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}

/**
 * Function is use to delete Sms By Hospital
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 8-Feb-2017
 */
function deleteSmsByHospital(req, res) {
    co(function* () {
        let smSHistoryList = req.body.smsListArray;
        for (var i = 0; i < smSHistoryList.length; i++) {
            var sms_id = smSHistoryList[i]._id;
            let SmsUpdate = yield SmsHistory.update({ _id: sms_id }, { $set: { is_deleted: true } }).exec();
        }
        return res.json({ 'code': 200, status: 'success', "message": "Delete SMS Successfully", "data": {} });
    }).catch(function (err) {
        console.log("getSentSMSList Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}
/**
 * Function is use to read Sms 
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 12-Feb-2017
 */

function markSmsAsRead(req, res) {
    co(function* () {
        let read_id = req.swagger.params.id.value;
        let SmsHistoryData = yield SmsHistory.update({ _id: read_id }, { $set: { is_read: true } }).exec();
        return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": {} });
    }).catch(function (err) {
        return res.json({ code: 404, message: "Internal error" });
    })
}


/**
 * Function is use to get Unread Sms Count
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 12-Feb-2017
 */
function getUnreadSmsCount(req, res) {
    co(function* () {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
        var condition = {};
        condition.is_deleted = false;
        condition.is_read = false;
        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (req.body.searchText) {
            condition.$or = [{ 'first_name': new RegExp(searchText, 'gi') }, { 'last_name': new RegExp(searchText, 'gi') }, { 'clinician_npi_no': new RegExp(searchText, 'gi') }, { 'SSN': new RegExp(searchText, 'gi') }, { 'mobile_no': new RegExp(searchText, 'gi') }, { 'hospitalInfo.hospital_name': new RegExp(searchText, 'gi') }];
        }
        let aggregate = [
            { $match: condition },
            { "$unwind": "$to" },
            {
                "$group": {
                    _id: { "_id": "$_id", "message": '$message', "from_id": "$from_id", "is_read": "$is_read", "createdAt": "$createdAt" },
                    // to: { $push: "$to" },
                    mcount: { $sum: { $cond: [{ $eq: [req.user.id, "$to.userid"] }, 1, 0] } }
                }
            },
            { $match: { mcount: { $gt: 0 } } },
        ];
        var aggregateCnt = [].concat(aggregate);
        if (req.body.count && req.body.page) {
            aggregate.push({ $sort: sorting });
            aggregate.push({ $skip: skip });
            aggregate.push({ $limit: count });
        }
        let smsHistoryData = yield SmsHistory.aggregate(aggregate);
        aggregateCnt.push({ $group: { _id: null, mcount: { $sum: 1 } } });
        let smsHistoryCount = yield SmsHistory.aggregate(aggregateCnt);
        return res.json({ code: 200, message: 'Data retrieved successfully', data: ((smsHistoryCount[0]) ? smsHistoryCount[0].mcount : 0) });
    }).catch(function (err) {
        console.log('Error', err);
        return res.json({ code: 400, message: 'Internal server error', data: {} });
    });
}
