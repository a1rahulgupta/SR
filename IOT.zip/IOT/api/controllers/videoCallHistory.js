'use strict';

var mongoose = require('mongoose'),
    Patient = mongoose.model('Patient'),
    Role = mongoose.model('Role'),
    User = mongoose.model('User'),
    VideoHistory = mongoose.model('VideoHistory'),
    HospitalAssign = mongoose.model('HospitalAssign'),
    VideoCallStatus = mongoose.model('VideoCallStatus'),
    co = require('co'),
    moment = require('moment'),
    config = require('../../config/config.js'),
    constantsObj = require('../lib/constants'),
    algorithm = constantsObj.config.cryptoAlgorithm,
    password = constantsObj.config.cryptoPassword,
    validator = require('../../config/validator.js'),
    crypto = require('crypto'),
    utility = require('../lib/utility.js'),
    async = require('async'),
    fs = require('fs'),
    path = require('path'),
    constant = require('../lib/constants'),
    mailer = require('../lib/mailer'),
    common = require('../../config/common.js');


module.exports = {
    acceptCall: acceptCall,
    rejectCall: rejectCall,
    missedCall: missedCall,
    getMissedVideoCount:getMissedVideoCount,
    getMissedVideoCallList:getMissedVideoCallList,
    deleteMissedCall:deleteMissedCall,
    markAsReadMissedCall:markAsReadMissedCall

};

function decrypt(decText) {
    var decipher = crypto.createDecipher(algorithm, password)
    var decText = decipher.update(decText, 'hex', 'utf8')
    decText += decipher.final('utf8');
    return decText;
}




/**
 * Function is use to acceptCall
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 14-March-2018
 */
function acceptCall(req, res) {
    console.log("req-------->>>>", req.body);
    co(function* () {
        var obj = req.body;
        obj.calling_Person = req.user.id;
        var videoData = new VideoHistory(obj);
        videoData.save(function (err, videoData) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
                console.log(err)
            } else {
                res.json({
                    code: 200
                    // message: constantsObj.messages.diseaseAddedSuccess,
                    // data: videoData
                });
            }
        });
    }).catch(function (err) {
        res.json({ code: 402, message: utility.validationErrorHandler(err), err });
    });
}

/**
 * Function is use to rejectCall
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 15-March-2018
 */
function rejectCall(req, res) {
    console.log("req-------->>>>", req.body);
    co(function* () {
        var obj = req.body;
        obj.calling_Person = req.user.id;
        var videoData = new VideoHistory(obj);
        videoData.save(function (err, videoData) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
                console.log(err)
            } else {
                res.json({
                    code: 200
                    // message: constantsObj.messages.diseaseAddedSuccess,
                    // data: videoData
                });
            }
        });
    }).catch(function (err) {
        res.json({ code: 402, message: utility.validationErrorHandler(err), err });
    });
} 

/**
 * Function is use to MissedVideoCall
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 15-March-2018
 */
function missedCall(req, res) {
    console.log("req---body Missed Call----->>>>", req.body);
    console.log("userId",req.user.id);
    co(function* () {
        var obj = req.body;
        obj.name = req.body.data.data.callerName;
        obj.receive_person = req.user.id;
        obj.call_date = moment().format('DD-MM-YYYY hh:mm A');
        var videoData = new VideoCallStatus(obj);
        videoData.save(function (err, videoData) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
                console.log(err)
            } else {
                res.json({
                    code: 200,
                    data: videoData
                });
            }
        });
    }).catch(function (err) {
        res.json({ code: 402, message: utility.validationErrorHandler(err), err });
    });
} 


/**
 * Function is use to Get Missed Video Count
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 15-March-2018
**/


function getMissedVideoCount(req, res) {
    co(function* () {
        let missedVideoCount = yield VideoCallStatus.find({ receive_person: req.user.id, is_view: false, is_deleted:false }).count().exec();
        res.json({
            code: 200,
            data: missedVideoCount
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));

    })
}

/**
 * Function is use to Get Missed Video Count
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 15-March-2018
**/


function getMissedVideoCallList(req, res) {
    co(function* () {
        let missedVideoCallList = yield VideoCallStatus.find({ receive_person: req.user.id,is_deleted:false }).sort([['_id', -1]]).lean().exec();
        res.json({
            code: 200,
            data: missedVideoCallList
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));

    })
}

/**
 * Function is use to delete MissedCall
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 15-March-2018
 */
function deleteMissedCall(req, res) {
    var callId = req.swagger.params.id.value;
    VideoCallStatus.update({ _id: callId }, { $set: { is_deleted: true } }, function (err) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else {
            res.json({
                code: 200,
                message: "Missed Call Deleted successfully"
            })
        }
    })
}

/**
 * Function is use to mark as read on Missed Call
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 15-March-2018
 */
function markAsReadMissedCall(req, res) {
    var callId = req.swagger.params.id.value;
    VideoCallStatus.update({ _id: callId }, { $set: { is_view: true } }, function (err) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else {
            res.json({
                code: 200
            })
        }
    })
}

