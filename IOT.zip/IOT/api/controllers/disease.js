'use strict';

var mongoose = require('mongoose'),
    co = require('co'),
    utility = require('../lib/utility.js'),
    async = require('async'),
    constantsObj = require('../lib/constants'),
    Disease = mongoose.model('Disease');

module.exports = {
    addDisease: addDisease,
    getDiseaseList: getDiseaseList 
}

/**
 * Function is use to Add Disease 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 14-June-2017
 */
function addDisease(req, res) {
    co(function*() {
          var obj = req.body;
                var disease = new Disease(obj);
                disease.save(function (err, diseaseData) {
                if (err) {
                  res.json({
                  code: 404,
                  message: utility.validationErrorHandler(err)
                });
                  console.log(err)
                } else {
                    res.json({
                    code: 200,
                    message: constantsObj.messages.diseaseAddedSuccess,
                    data: diseaseData
                    });
                  }
                });
        }).catch(function(err) {
            res.json({code:402,message:utility.validationErrorHandler(err), err});
        });
} 

/**
 * Function is use to Get Disease  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 14-June-2017
 */
function getDiseaseList(req, res) {
  console.log("in disease list");
  Disease.find({}).lean().exec(function (err, disease) {
    if (err) {
      res.json({
        code: 404,
        message: utility.validationErrorHandler(err)
      });
    } else if (disease) {
          res.json({
                code: 200,
                message: constantsObj.messages.diseaseGettingSuccess,
                data: disease
          })  
      }else {
          res.json({
          code: 404,
          message: constantsObj.messages.noDataFound
          })
      }
  }).catch(function (err) {
      res.json({code:402,message:utility.validationErrorHandler(err),err});
  })
}


