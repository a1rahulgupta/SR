'use strict';

var mongoose = require('mongoose'),
    Patient = mongoose.model('Patient'),
    Role = mongoose.model('Role'),
    User = mongoose.model('User'),
    HospitalAssign = mongoose.model('HospitalAssign'),
    Ambulance = mongoose.model('Ambulance'),
    co = require('co'),
    constantsObj = require('../lib/constants'),
    config = require('../../config/config.js'),
    algorithm = constantsObj.config.cryptoAlgorithm,
    password = constantsObj.config.cryptoPassword,
    validator = require('../../config/validator.js'),
    crypto = require('crypto'),
    utility = require('../lib/utility.js'),
    async = require('async'),
    fs = require('fs'),
    path = require('path'),
    constant = require('../lib/constants'),
    mailer = require('../lib/mailer'),
    common = require('../../config/common.js');

module.exports = {
    getAllAmbulance: getAllAmbulance,
    deleteAmbulanceById: deleteAmbulanceById,
    addAmbulance: addAmbulance,
    getAmbulanceById: getAmbulanceById,
    enableDisableAmbulance: enableDisableAmbulance,
    getAmbulanceDetails: getAmbulanceDetails,
    updateAmbulanceProfile: updateAmbulanceProfile,
    getAssignPatientForAmbulance: getAssignPatientForAmbulance,
    getAllEntitiesLinkedToAmbulance: getAllEntitiesLinkedToAmbulance,
    getAmbulanceCount:getAmbulanceCount
};
function decrypt(decText) {
    var decipher = crypto.createDecipher(algorithm, password)
    var decText = decipher.update(decText, 'hex', 'utf8')
    decText += decipher.final('utf8');
    return decText;
}
/**
 * Function is use to Get Clinician List
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 21-june-2017
 */
function getAllAmbulance(req, res) {
    co(function* () {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
        var condition = { is_deleted: false };
        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (req.body.searchText) {
            condition.$or = [{ 'company_name': new RegExp(searchText, 'gi') }, { 'serviceInfo.serviceType_name': new RegExp(searchText, 'gi') }, { 'address': new RegExp(searchText, 'gi') }, { 'mobile_no': new RegExp(searchText, 'gi') }];
        }
        let aggregate = [{
            $lookup: {
                from: 'servicetypes',
                localField: "service_type",
                foreignField: "_id",
                as: "serviceInfo"
            }
        },
        { $unwind: { path: "$serviceInfo" } },
        { $match: condition },
        { $sort: sorting }
        ];
        // var aggregateCnt = lodash.clone(aggregate, true);
        var aggregateCnt = [].concat(aggregate);
        if (req.body.count && req.body.page) {
            aggregate.push({ $sort: sorting });
            aggregate.push({ $skip: skip });
            aggregate.push({ $limit: count });
        }
        let ambulanceData = yield Ambulance.aggregate(aggregate);
        aggregateCnt.push({ $group: { _id: null, count: { $sum: 1 } } });
        let ambulanceDataCount = yield Ambulance.aggregate(aggregateCnt);
        return res.json({ code: 200, message: 'Data retrieved successfully', data: ambulanceData, totalCount: ((ambulanceDataCount[0]) ? ambulanceDataCount[0].count : 0) });

    }).catch(function (err) {
        console.log('Error', err);
        return res.json({ code: 400, message: 'Internal server error', data: {} });
    });
}

/**
 * Function is use to Delete Ambulance By Id 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 24-June-2017
 */
function deleteAmbulanceById(req, res) {
    console.log("req.swagger.params.id.value", req.swagger.params.id.value);
    var id = req.swagger.params.id.value;
    co(function* () {
        let ambulanceData = yield Ambulance.findById(id);
        if (ambulanceData) {
            var ambulanceInfo = ambulanceData;
            console.log("ambulancedelete");
            ambulanceData.is_deleted = true;
            let ambulanceDelete = yield ambulanceData.save();
            let userData = yield User.findById(ambulanceInfo.user_id);
            if (userData) {
                console.log("userdelete");
                userData.is_deleted = true;
                let userDelete = yield userData.save();
            } else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.userDeletedFailed
                })
            }
            console.log("response delete");
            res.json({
                code: 200,
                message: constantsObj.messages.userDeletedSuccess
            })
        } else {
            return res.json(Response(402, constantsObj.messages.noRecordFound, err));
        }
    }).catch(function (err) {
        return res.json(Response(404, utility.validationErrorHandler(err), err));
    });
}

/**
 * Function is use to add Ambulance 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 24-June-2017
 */
function addAmbulance(req, res) {
    var body = req.body;
    console.log("body", body);
    if (!validator.isValid(body.address) || !validator.isValid(body.city) || !validator.isValid(body.state) || !validator.isValid(body.country) || !validator.isValid(body.zip_code) || !validator.isValid(body.mobile_no) || !validator.isValid(body.company_name) || !validator.isValid(body.email) || !validator.isValid(body.service_type)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else if (req.body.id) {
        Ambulance.findOne({ _id: req.body.id, is_deleted: false }).exec(function (err, group) {
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Something went wrong please try again!'
                });
            } else if (group) {
                User.findOne({ _id: group.user_id }).exec(function (err, exist) {
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Something went wrong please try again!'
                        });
                    } else {
                        if (exist) {
                            exist.email = body.email;
                            exist.save(function (err, userData) {
                                if (err) {
                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Unable to Update Ambulance'
                                    });
                                } else {
                                    group.company_name = body.company_name;
                                    group.service_type = body.service_type;
                                    group.address = body.address;
                                    group.city = body.city;
                                    group.state = body.state;
                                    group.zip_code = body.zip_code;
                                    group.country = body.country;
                                    group.mobile_no = body.mobile_no;
                                    group.save(function (err) {
                                        if (err) {
                                            res.json({
                                                'code': config.httpUnauthorize,
                                                'message': 'Unable to Update Ambulance'
                                            });
                                        } else {
                                            var userMailData = {
                                                company_name: body.company_name,
                                                email: body.email,
                                                // password: body.password
                                            };

                                            mailer.sendMail(body.email, constant.emailKeyword.WelComeEmailTowing, userMailData, function (err, resp) {
                                                if (err) {
                                                    res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                                } else {
                                                    res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                }
                                            });
                                            console.log("in Care Coordinator Update");
                                            res.json({
                                                'code': config.httpSuccess,
                                                'message': 'Ambulance Update successfully'
                                            });
                                        }
                                    })
                                }
                            })
                        }
                    }
                })
            } else {
                res.json({
                    'code': 402,
                    'message': 'No record found'
                });
            };
        })
    } else {
        Role.findOne({ name: 'Ambulance', is_deleted: false, status: true }).exec(function (err, group) {
            console.log("group", group);
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Something went wrong please try again!'
                });
            } else if (group) {
                console.log("group", group);

                User.findOne({ email: body.email }).exec(function (err, exist) {
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Something went wrong please try again!'
                        });
                    } else {
                        if (exist) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Ambulance Name with this email already exist please try another!'
                            });
                        } else {

                            var user = new User();
                            var randompass = common.randomToken(8);
                            user.email = body.email;
                            user.role_id = group._id;
                            user.setPassword(randompass);

                            user.save(function (err, userData) {
                                if (err) {
                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Unable to save ambulance'
                                    });
                                } else {

                                    console.log("in user save");
                                    var ambulance = new Ambulance();
                                    ambulance.company_name = body.company_name;
                                    ambulance.user_id = userData._id;
                                    ambulance.service_type = body.service_type;
                                    ambulance.address = body.address;
                                    ambulance.city = body.city;
                                    ambulance.state = body.state;
                                    ambulance.zip_code = body.zip_code;
                                    ambulance.country = body.country;
                                    ambulance.mobile_no = body.mobile_no;
                                    ambulance.save(function (err) {
                                        if (err) {
                                            res.json({
                                                'code': config.httpUnauthorize,
                                                'message': 'Unable to save ambulance'
                                            });
                                        } else {
                                            var userMailData = {
                                                company_name: body.company_name,
                                                email: body.email,
                                                password: randompass
                                            };

                                            mailer.sendMail(body.email, constant.emailKeyword.WelComeEmailTowing, userMailData, function (err, resp) {
                                                if (err) {
                                                    res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                                } else {
                                                    res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                }
                                            });
                                            console.log("in ambulance save");
                                            res.json({
                                                'code': config.httpSuccess,
                                                'message': 'Ambulance saved successfully'
                                            });
                                        }
                                    })


                                }
                            });
                        }
                    }
                });
            } else {
                res.json({
                    'code': 402,
                    'message': 'No record found'
                });
            };
        })
    }
}

/**
 * Function is use to Get Ambulance By Id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 24-June-2017
 */
function getAmbulanceById(req, res) {
    console.log("in getAmbulanceById");
    co(function* () {
        var id = req.swagger.params.id.value;
        let ambulanceInfo = yield Ambulance.findById(id).populate('user_id').exec();
        res.json({ 'code': 200, status: 'success', "message": constantsObj.messages.dataRetrievedSuccess, "data": ambulanceInfo });
    }).catch(function (err) {
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}

/**
 * Function is use to Enable Disable Ambulance
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-June-2017
 */
function enableDisableAmbulance(req, res) {
    if (!req.body.userId || req.body.status == null) {
        res.json({
            code: 402,
            status: 'failed',
            message: constantsObj.validationMessages.requiredFieldsMissing
        });
    } else {
        Ambulance.findById(req.body.userId).exec(function (err, data) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else {
                if (!data) {
                    res.json({ 'code': 402, status: 'failed', message: constantsObj.validationMessages.userNotFound });
                } else {
                    data.status = req.body.status;
                    data.save(function (err) {
                        if (err) {
                            res.json({
                                code: 404,
                                message: utility.validationErrorHandler(err)
                            });
                        } else {
                            User.findById(data.user_id).exec(function (err, userData) {
                                if (err) {
                                    res.json({
                                        code: 404,
                                        message: utility.validationErrorHandler(err)
                                    });
                                } else if (userData) {
                                    userData.status = req.body.status;
                                    userData.save(function (err) {
                                        if (err) {
                                            res.json({
                                                code: 404,
                                                message: utility.validationErrorHandler(err)
                                            });
                                        } else {
                                            res.json({ 'code': 200, status: 'success', "message": 'Ambulance Company ' + ((req.body.status == true) ? 'activated' : 'deactivated') + ' successfully' })
                                        }
                                    })

                                } else {
                                    res.json({ 'code': 402, status: 'failed', message: constantsObj.validationMessages.userNotFound });
                                }
                            })
                        }
                    })

                }
            }
        })
    }
}

function getAmbulanceDetails(req, res) {
    Ambulance.findOne({ user_id: req.user.id }).populate('user_id').lean().exec(function (err, data) {
        if (err) {
            res.json({
                'code': 402,
                'message': 'Ambulance data not found'
            })
        } else {
            res.json({
                code: 200,
                data: data
            })
        }
    })
}

function updateAmbulanceProfile(req, res) {
    var timestamp = Number(new Date()); // current time as number
    console.log(req.body);
    var file = req.swagger.params.file.value;
    var company_name = req.swagger.params.company_name.value;
    var address = req.swagger.params.address.value;
    var mobile_no = req.swagger.params.mobile_no.value;
    var city = req.swagger.params.city.value;
    var state = req.swagger.params.state.value;
    var zip_code = req.swagger.params.zip_code.value;
    var country = req.swagger.params.country.value;
    var service_type = req.swagger.params.service_type.value;
    //console.log("first_name", first_name);
    var user_id = req.user.id;
    if (file) {
        var splitFile = file.originalname.split('.');
        var filename = +timestamp + '_' + common.randomToken(6) + '.' + ((splitFile.length > 0) ? splitFile[splitFile.length - 1] : file.originalname);
        var imagePath = "./public/assets/uploads/profile/" + filename;
    }
    var obj = {};
    obj.company_name = company_name;
    obj.address = address;
    obj.mobile_no = mobile_no;
    obj.city = city;
    obj.state = state;
    obj.zip_code = zip_code;
    obj.country = country;
    obj.service_type = service_type;
    if (file) {
        obj.file = file;
    }
    // utility.fileUpload(imagePath, file.buffer).then(function() {
    function update() {
        Ambulance.findOne({ user_id: user_id }).then(function (ambulance) {
            if (filename) {
                ambulance.image = "assets/uploads/profile/" + filename;
            }
            ambulance.company_name = company_name;
            ambulance.address = address;
            ambulance.mobile_no = mobile_no;
            ambulance.city = city;
            ambulance.state = state;
            ambulance.zip_code = zip_code;
            ambulance.country = country;
            ambulance.service_type = service_type;
            if (ambulance.image) {
                ambulance.image = ambulance.image;
            }
            ambulance.save(function (err, ItemImage) {
                if (err) {
                    res.json({ code: 500, message: constantsObj.validationMessages.internalError });
                } else {
                    res.json({ code: 200, message: 'Profile updated successfully' });
                }
            });

        }).catch(function (err) {
            console.log("err", err);
            res.json({ code: 500, message: constantsObj.validationMessages.internalError, data: err });
        });
    }
    if (file) {
        fs.writeFile(path.resolve(imagePath), file.buffer, function (err) {
            if (err) {
                res.json({ code: 402, 'message': 'Request could not be processed. Please try again.', data: {} });
            } else {
                update();
            }
        });
    } else {
        update();
    }
}
/**
 * Function is use to Get Assign Patient By Hospital
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 07-Feb-2018
**/

function getAssignPatientForAmbulance(req, res) {
    co(function* () {
        let ambulanceUserId = yield User.find({ _id: req.user.id, is_deleted: false }).exec();
        let ambulanceId = yield Ambulance.find({ user_id: ambulanceUserId, is_deleted: false }).exec();
        let assignUsers = yield HospitalAssign.find({ assign_id: ambulanceId, is_deleted: false }).populate('patient_id').exec();
        for (var i = 0; i < assignUsers.length; i++) {
            assignUsers[i].patient_id.first_name = decrypt(assignUsers[i].patient_id.first_name);
            assignUsers[i].patient_id.last_name = decrypt(assignUsers[i].patient_id.last_name);
            assignUsers[i].patient_id.mobile_no = decrypt(assignUsers[i].patient_id.mobile_no);
        }
        return res.json({ 'code': 200, status: 'success', "data": assignUsers });
    }).catch(function (err) {
        res.json({ 'code': 402, status: 'failed', "message": utility.validationErrorHandler(err), "data": {} });
    });
}

/**
 * Function is use to All entites linked to hospital
 * @access private
 * @return json
 * Created by Swapnali Jare
 * @smartData Enterprises (I) Ltd
 * Created Date 06-Feb-2018
 */
function getAllEntitiesLinkedToAmbulance(req, res) {
    co(function* () {
        let ambulanceInfo = yield Ambulance.findOne({
            user_id: req.user.id,
            is_deleted: false
        }).populate('hospital_id').lean().exec();

        ambulanceInfo = yield Ambulance.populate(ambulanceInfo, {
            path: 'hospital_id.user_id',
            model: 'User'
        });

        console.log("before ambulanceInfo-->", ambulanceInfo);
        let assignedPatientList = yield HospitalAssign.find({
            assign_id: ambulanceInfo._id,
            is_deleted: false
        }).populate('patient_id').populate('role_id').lean().exec();
        assignedPatientList = yield HospitalAssign.populate(assignedPatientList, {
            path: 'patient_id.user_id',
            model: 'User'
        });
        //console.log("before assignedPatientList-->", assignedPatientList);
        for (var i = 0; i < assignedPatientList.length; i++) {
            //  console.log("assignedPatientList[i]-->", i, assignedPatientList[i]);
            assignedPatientList[i].name = decrypt(assignedPatientList[i].patient_id.first_name) + ' ' + decrypt(assignedPatientList[i].patient_id.last_name);
            assignedPatientList[i].mobile_no = decrypt(assignedPatientList[i].patient_id.mobile_no);
            assignedPatientList[i].email = assignedPatientList[i].patient_id.user_id.email;
            assignedPatientList[i].userid = assignedPatientList[i].patient_id.user_id._id;
            assignedPatientList[i].userType = 'Patient';
            //  console.log("assignedPatientList[i]--->", assignedPatientList[i]);
        }
        if (ambulanceInfo) {
            let hosptalInfo = ambulanceInfo.hospital_id;
            console.log("hosptalInfo--->", hosptalInfo);
            hosptalInfo.role = 'Hospital';
            hosptalInfo.name = hosptalInfo.hospital_name;
            hosptalInfo.mobile_no = hosptalInfo.hospital_mobile_no;
            hosptalInfo.email = hosptalInfo.user_id.email;
            hosptalInfo.userid = hosptalInfo.user_id._id;
            assignedPatientList.push(hosptalInfo);
        }
        // console.log("assignedUserList--->", assignedPatientList);
        return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": assignedPatientList });
    }).catch(function (err) {
        console.log("getAllEntitiesLinkedToClinician Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}

/**
 * Function is use to Get Ambulance Count
 * @access private
 * @return json
 * Created by Rahul G
 * @smartData Enterprises (I) Ltd
 * Created Date 12-March-2018
**/


function getAmbulanceCount(req, res) {
    co(function* () {
        let ambulanceCount = yield Ambulance.find({ is_deleted: false }).count().exec();
        res.json({
            code: 200,
            data: ambulanceCount
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));

    })
}