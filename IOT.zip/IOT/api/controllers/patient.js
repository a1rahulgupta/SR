'use strict';

var mongoose = require('mongoose'),
    constantsObj = require('../lib/constants'),
    Patient = mongoose.model('Patient'),
    co = require('co'),
    config = require('../../config/config.js'),
    algorithm = constantsObj.config.cryptoAlgorithm,
    password = constantsObj.config.cryptoPassword,
    validator = require('../../config/validator.js'),
    LabTest = mongoose.model('LabTest'),
    DeviceManagement = mongoose.model('DeviceManagement'),
    Role = mongoose.model('Role'),
    Prescription = mongoose.model('Prescription'),
    Appointment = mongoose.model('Appointment'),
    PatientDemographic = mongoose.model('PatientDemographic'),
    PatientInsurance = mongoose.model('PatientInsurance'),
    PatientVital = mongoose.model('PatientVital'),
    Clinician = mongoose.model('Clinician'),
    RiskAssessments = mongoose.model('RiskAssessments'),
    PatientEncounter = mongoose.model('PatientEncounter'),
    PatientMedication = mongoose.model('PatientMedication'),
    PatientDisease = mongoose.model('PatientDisease'),
    PatientFamilyHistory = mongoose.model('PatientFamilyHistory'),
    PatientActivity = mongoose.model('PatientActivity'),
    PatientAllergicReaction = mongoose.model('PatientAllergicReaction'),
    PatientChronicDisease = mongoose.model('PatientChronicDisease'),
    User = mongoose.model('User'),
    PatientSurgery = mongoose.model('PatientSurgery'),
    Device = mongoose.model('Device'),
    PatientDisease = mongoose.model('PatientDisease'),
    PatientReport = mongoose.model('PatientReport'),
    PatientAssessment = mongoose.model('PatientAssessment'),
    AssesmentQuestion = mongoose.model('AssesmentQuestion'),
    IvrSetting = mongoose.model('IvrSetting'),
    crypto = require('crypto'),
    utility = require('../lib/utility.js'),
    constant = require('../lib/constants'),
    generateToken = require('../lib/generateToken'),
    mailer = require('../lib/mailer'),
    async = require('async'),
    fs = require('fs'),
    path = require('path'),
    emailObj = require('../lib/emails'),
    AssignQuestions = mongoose.model('AssignQuestions'),
    common = require('../../config/common.js'),
    EmailHistory = mongoose.model('EmailsHistory'),
    Hospital = mongoose.model('Hospital'),
    CareCoordinator = mongoose.model('CareCoordinator'),
    Ambulance = mongoose.model('Ambulance'),
    TokenService = require('../lib/tokenService'),
    Towing = mongoose.model('Towing');
var moment = require('moment');

module.exports = {
    addPatient: addPatient,
    updatePatient: updatePatient,
    getAllPatient: getAllPatient,
    getAllPatientName: getAllPatientName,
    getPatientById: getPatientById,
    prescribeMedication: prescribeMedication,
    orderLabTest: orderLabTest,
    addPatientDemographics: addPatientDemographics,
    addPatientInsuranceDetails: addPatientInsuranceDetails,
    addPatientVitals: addPatientVitals,
    addPatientEncounter: addPatientEncounter,
    addPatientMedication: addPatientMedication,
    addPatientDisease: addPatientDisease,
    addPatientDevice: addPatientDevice,
    getPatientDevice: getPatientDevice,
    getPatientActivity: getPatientActivity,
    addPatientFamilyHistory: addPatientFamilyHistory,
    addPatientAllergiesAndReactions: addPatientAllergiesAndReactions,
    addPatientChronicDisease: addPatientChronicDisease,
    addPatientSurgeries: addPatientSurgeries,
    getPatientDetails: getPatientDetails,
    getPatientDeviceDetail: getPatientDeviceDetail,
    deletePatientById: deletePatientById,
    deletePatientDeviceDetail: deletePatientDeviceDetail,
    getPatientDetailById: getPatientDetailById,
    getRiskAssessmentReportByPatient: getRiskAssessmentReportByPatient,
    getPatientVitals: getPatientVitals,
    viewPatientVitalsById: viewPatientVitalsById,
    addPatientByAdmin: addPatientByAdmin,
    updatePatientByAdmin: updatePatientByAdmin,
    getPatientByAdminId: getPatientByAdminId,
    updatePatientProfile: updatePatientProfile,
    enableDisablePatient: enableDisablePatient,
    getPatientAllergiesAndReactions: getPatientAllergiesAndReactions,
    addPatientByClinician: addPatientByClinician,
    getAllPatientByClinicianId: getAllPatientByClinicianId,
    getPatientDisease: getPatientDisease,
    getPatientChronicDisease: getPatientChronicDisease,
    getPatientFamilyHistory: getPatientFamilyHistory,
    getPatientSurgeries: getPatientSurgeries,
    getPatientMedication: getPatientMedication,
    getPatientEncounter: getPatientEncounter,
    getPatientInsuranceDetails: getPatientInsuranceDetails,
    getPatientDemographics: getPatientDemographics,
    addAppointment: addAppointment,
    getAppointmentById: getAppointmentById,
    updateAppointment: updateAppointment,
    uploadPatientReports: uploadPatientReports,
    getUploadReports: getUploadReports,
    viewUploadReport: viewUploadReport,
    deleteReportById: deleteReportById,
    getLastWithingScore: getLastWithingScore,
    getLastRiskAssessmentScore: getLastRiskAssessmentScore,
    getAllAppointmentByPatientId: getAllAppointmentByPatientId,
    viewAppointmentById: viewAppointmentById,
    getAllPatients: getAllPatients,
    getAssignPatient: getAssignPatient,
    submitQuestions: submitQuestions,
    getSubmitQuestions: getSubmitQuestions,
    viewAssignQuestion: viewAssignQuestion,
    composeMail: composeMail,
    getMailList: getMailList,
    getMailById: getMailById,
    getSentMailList: getSentMailList,
    getPatientFitbitActivity: getPatientFitbitActivity,
    getPatientDeviceList: getPatientDeviceList,
    getPatientAllingedUserList: getPatientAllingedUserList,
    markMailAsRead: markMailAsRead,
    getUnreadMailCount: getUnreadMailCount,
    getTollfreeNumber:getTollfreeNumber
};

/**
 * Function is use to Add Patient 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 6-June-2017
 */
function addPatient(req, res) {
    console.log("addPatient", req.body);
    var obj = req.body;
    var patientObj = {};
    var field = ['user_id', 'clinician_id', 'coordinator_id', 'DOB'];
    utility.encryptedRecord(obj, field, function (patientObj) {
        var patient = new Patient(patientObj);
        patient.save(function (err, patientData) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientCreatedSuccess,
                    data: patientData
                });
            }

        });
    })
}


function addPatientByAdmin(req, res) {
    console.log("addPatientByAdmin", req.body);
    var body = req.body;
    if (!validator.isValid(body.first_name) || !validator.isValid(body.last_name) || !validator.isValid(body.mobile_no) || !validator.isValid(body.email)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        Role.findOne({ name: 'Patient', is_deleted: false, status: true }).exec(function (err, group) {
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Something went wrong please try again!'
                });
            } else if (group) {
                User.findOne({ email: body.email, is_deleted: false }).exec(function (err, exist) {
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Something went wrong please try again!'
                        });
                    } else {
                        if (exist) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Patient Name with this email already exist please try another!'
                            });
                        } else {

                            var user = new User();
                            var randompass = common.randomToken(8);
                            user.email = body.email;
                            user.role_id = group._id;
                            user.setPassword(randompass);
                            user.save(function (err, userData) {
                                if (err) {
                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Unable to save user'
                                    });
                                } else {
                                    var patientObj = {};
                                    var field = ['user_id', 'DOB'];
                                    var obj = req.body;
                                    obj.user_id = userData._id;
                                    utility.encryptedRecord(obj, field, function (patientObj) {
                                        var patient = new Patient(patientObj);
                                        patient.save(function (err, patientData) {
                                            if (err) {
                                                res.json({
                                                    code: 404,
                                                    message: utility.validationErrorHandler(err)
                                                });
                                            } else {
                                                var userMailData = {
                                                    first_name: body.first_name,
                                                    last_name: body.last_name,
                                                    password: randompass,
                                                    email: body.email
                                                };

                                                mailer.sendMail(body.email, constant.emailKeyword.WelComeEmail, userMailData, function (err, resp) {
                                                    if (err) {
                                                        res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                                    } else {
                                                        res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                    }
                                                });
                                                res.json({
                                                    code: 200,
                                                    message: constantsObj.messages.patientCreatedSuccess,
                                                    data: patientData
                                                });
                                            }

                                        });
                                    })

                                }
                            });
                        }
                    }
                });
            } else {
                res.json({
                    'code': 402,
                    'message': 'No record found'
                });
            };
        })
    }
}

function addPatientByClinician(req, res) {
    var body = req.body;
    if (!validator.isValid(body.first_name) || !validator.isValid(body.last_name) || !validator.isValid(body.mobile_no) || !validator.isValid(body.email)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        Role.findOne({ name: 'Patient', is_deleted: false, status: true }).exec(function (err, group) {
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Something went wrong please try again!'
                });
            } else if (group) {
                User.findOne({ email: body.email, is_deleted: false }).exec(function (err, exist) {
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Something went wrong please try again!'
                        });
                    } else {
                        if (exist) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Patient Name with this email already exist please try another!'
                            });
                        } else {

                            var user = new User();
                            user.email = body.email;
                            user.role_id = group._id;
                            //user.setPassword(body.password);
                            user.save(function (err, userData) {
                                if (err) {
                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Unable to save user'
                                    });
                                } else {
                                    var patientObj = {};
                                    var field = ['user_id', 'DOB'];
                                    var obj = req.body;
                                    obj.user_id = userData._id;
                                    utility.encryptedRecord(obj, field, function (patientObj) {
                                        var patient = new Patient(patientObj);
                                        patient.clinician_id = req.user.id
                                        patient.save(function (err, patientData) {
                                            if (err) {
                                                res.json({
                                                    code: 404,
                                                    message: utility.validationErrorHandler(err)
                                                });
                                            } else {
                                                res.json({
                                                    code: 200,
                                                    message: constantsObj.messages.patientCreatedSuccess,
                                                    data: patientData
                                                });
                                            }

                                        });
                                    })

                                }
                            });
                        }
                    }
                });
            } else {
                res.json({
                    'code': 402,
                    'message': 'No record found'
                });
            };
        })
    }
}

function updatePatientByAdmin(req, res) {
    var body = req.body;
    if (!validator.isValid(body.first_name) || !validator.isValid(body.last_name) || !validator.isValid(body.mobile_no) || !validator.isValid(body.email)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        Role.findOne({ name: 'Patient', is_deleted: false, status: true }).exec(function (err, group) {
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Something went wrong please try again!'
                });
            } else if (group) {
                User.findOne({ email: body.email, _id: { $ne: body.userId }, is_deleted: false }).exec(function (err, exist) {
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Something went wrong please try again!'
                        });
                    } else {
                        if (exist) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Patient Name with this email already exist please try another!'
                            });
                        } else {
                            User.findOne({ email: body.email, is_deleted: false }).exec(function (err, user) {
                                if (err) {
                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Unable to get user'
                                    });
                                } else {
                                    Patient.findOne({ _id: body._id }).exec(function (err, patient) {
                                        if (err) {

                                        } else {
                                            user.email = body.email;
                                            user.role_id = group._id;
                                            //user.setPassword(body.password);
                                            user.save(function (err, userData) {
                                                if (err) {
                                                    res.json({
                                                        'code': config.httpUnauthorize,
                                                        'message': 'Unable to save user'
                                                    });
                                                } else {
                                                    var patientObj = {};
                                                    var field = ['user_id', 'DOB'];
                                                    var obj = req.body;
                                                    obj.user_id = userData._id;
                                                    utility.encryptedRecord(obj, field, function (patientObj) {
                                                        patient.SSN = patientObj.SSN;
                                                        patient.first_name = patientObj.first_name;
                                                        patient.last_name = patientObj.last_name;
                                                        patient.gender = patientObj.gender;
                                                        patient.DOB = patientObj.DOB;
                                                        patient.age = patientObj.age;
                                                        patient.mobile_no = patientObj.mobile_no;
                                                        patient.diabetes = patientObj.diabetes;
                                                        patient.smoker = patientObj.smoker;
                                                        patient.bp_treatment = patientObj.bp_treatment;
                                                        patient.save(function (err, patientData) {
                                                            if (err) {
                                                                res.json({
                                                                    code: 404,
                                                                    message: utility.validationErrorHandler(err)
                                                                });
                                                            } else {
                                                                res.json({
                                                                    code: 200,
                                                                    message: "Patient Data Updated Successfully",
                                                                    data: patientData
                                                                });
                                                            }

                                                        });
                                                    })

                                                }
                                            });
                                        }
                                    });
                                }
                            });
                        }
                    }
                });
            } else {
                res.json({
                    'code': 402,
                    'message': 'No record found'
                });
            };
        })
    }
}


function encrypt(encText) {
    var cipher = crypto.createCipher(algorithm, password)
    var encText = cipher.update(encText, 'utf8', 'hex')
    encText += cipher.final('hex');
    return encText;
}

/**
 * Function is use to Get Patient List
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 6-june-2017
 */
function getAllPatient(req, res) {
    console.log('getAllPatient');
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
    var condition = {};
    var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");

    console.log("searchText", searchText);
    if (req.body.searchText) {
        var searchText = encrypt(searchText);
        condition.$or = [{ 'SSN': new RegExp(searchText, 'gi') },
        { 'first_name': new RegExp(searchText, 'gi') },
        { 'last_name': new RegExp(searchText, 'gi') },
        { 'mobile_no': new RegExp(searchText, 'gi') },
        ];
    }
    condition.is_deleted = false;
    console.log(condition, "condition");
    Patient.find(condition)
        .sort(sorting)
        .skip(parseInt(skip))
        .limit(parseInt(count))
        .lean().exec(function (err, patient) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (patient) {
                Patient.find(condition)
                    .count()
                    .exec(function (err, totalCount) {
                        if (err) {
                            res.json({
                                code: 404,
                                message: 'TotalCount Not Correct'
                            })
                        } else {
                            var newArr = [];
                            var filed = ['user_id', 'clinician_id', 'coordinator_id', 'DOB', 'image', 'country', 'hospital_id'];
                            utility.decryptedRecord(patient, filed, function (newArr) {
                                console.log("newArr", newArr);
                                res.json({
                                    code: 200,
                                    message: constantsObj.messages.patientsGetSuccessfully,
                                    data: newArr,
                                    totalCount: totalCount
                                })
                            })
                        }
                    });
            } else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        }).catch(function (err) {
            return res.json(Response(402, utility.validationErrorHandler(err), err));
        })
}



function getAllPatientByClinicianId(req, res) {
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
    for (var key in req.body) {
        var reg = new RegExp("sorting", 'gi');
        if (reg.test(key)) {
            var value = req.body[key];
            key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
            var sorting = {};
            if (value == 1 || value == -1) {
                sorting[key] = value;
            } else {
                sorting[key] = (value == 'desc') ? -1 : 1;
            }
        }
    }
    var condition = {};
    var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");

    console.log("searchText", searchText);
    if (req.body.searchText) {
        var searchText = encrypt(searchText);
        condition.$or = [{ 'SSN': new RegExp(searchText, 'gi') },
        { 'first_name': new RegExp(searchText, 'gi') },
        { 'last_name': new RegExp(searchText, 'gi') },
        { 'mobile_no': new RegExp(searchText, 'gi') },
        ];
    }
    condition.is_deleted = false;
    condition.clinician_id = req.user.id;
    console.log(condition, "condition");
    Patient.find(condition)
        .sort(sorting)
        .skip(parseInt(skip))
        .limit(parseInt(count))
        .lean().exec(function (err, patient) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (patient) {
                Patient.find(condition)
                    .count()
                    .exec(function (err, totalCount) {
                        if (err) {
                            res.json({
                                code: 404,
                                message: 'TotalCount Not Correct'
                            })
                        } else {
                            var newArr = [];
                            var filed = ['user_id', 'clinician_id', 'coordinator_id', 'DOB', 'image', 'country', 'hospital_id'];
                            utility.decryptedRecord(patient, filed, function (newArr) {
                                res.json({
                                    code: 200,
                                    message: constantsObj.messages.patientsGetSuccessfully,
                                    data: newArr,
                                    totalCount: totalCount
                                })
                            })
                        }
                    });
            } else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        }).catch(function (err) {
            return res.json(Response(402, utility.validationErrorHandler(err), err));
        })
}

function getAllPatientName(req, res) {
    Patient.find({ is_deleted: false }, { first_name: 1, last_name: 1 }).lean().exec(function (err, patient) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (patient) {
            var newArr = [];
            var filed = ['user_id', 'clinician_id', 'coordinator_id', 'DOB', 'image', 'country', 'hospital_id'];
            utility.decryptedRecord(patient, filed, function (newArr) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientsGetSuccessfully,
                    data: newArr
                })
            })
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

/**
 * Function is use to Prescribe Medication to Patient 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 8-June-2017
 */
function prescribeMedication(req, res) {
    co(function* () {
        let savedData = yield Prescription.findById(req.body._id);
        if (savedData) { } else if (!savedData) {
            var prescriptionObj = {};
            var field = [];
            var obj = req.body;

            utility.encryptedRecord(obj, field, function (prescriptionObj) {
                var patient = new Prescription(prescriptionObj);
                patient.save(function (err, prescription) {
                    if (err) {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        });
                    } else {
                        res.json({
                            code: 200,
                            message: constantsObj.messages.prescribeMedicationSuccess,
                            data: prescription
                        });
                    }

                });
            })
        } else {
            return res.json(Response(402, constantsObj.validationMessages.prescribeMedicationFailed, err));
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    });
}

/**
 * Function is use to Order Lab Test for Patient 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 9-June-2017
 */
function orderLabTest(req, res) {
    co(function* () {
        let savedData = yield LabTest.findById(req.body._id);
        if (savedData) { } else if (!savedData) {
            var labTestObj = {};
            var field = [];
            var obj = req.body;

            utility.encryptedRecord(obj, field, function (labTestObj) {
                var test = new LabTest(labTestObj);
                test.save(function (err, labTest) {
                    if (err) {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        });
                    } else {
                        res.json({
                            code: 200,
                            message: constantsObj.messages.orderLabTestSuccess,
                            data: labTest
                        });
                    }

                });
            })
        } else {
            return res.json(Response(402, constantsObj.validationMessages.orderLabTestFailed, err));
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    });
}


/**
 * Function is use to Add Patient Demographics 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 9-June-2017
 * modified on 4-July-2017
 */
function addPatientDemographics(req, res) {
    co(function* () {
        let patientData = yield Patient.findOne({ user_id: req.user.id, is_deleted: false });
        if (patientData) {
            let demographicData = yield PatientDemographic.findOne({ patient_id: patientData._id, is_deleted: false });
            if (demographicData) {
                res.json({ code: 400, message: 'Information already exist' });
            } else {
                var demographic = req.body;
                demographic.patient_id = patientData._id;
                let savedData = yield new PatientDemographic(demographic).save();
                res.json({ code: 200, message: 'Patient Demographics added successfully' });
            }
        }
    }).catch(function (err) {
        res.json({ code: 402, message: 'Internal error', err });
    });
}

/**
 * Function is use to Add Patient Insurance Details 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 9-June-2017
 */
function addPatientInsuranceDetails(req, res) {
    co(function* () {
        let patientData = yield Patient.findOne({ user_id: req.user.id, is_deleted: false });
        if (patientData) {
            let insuranceData = yield PatientInsurance.findOne({ patient_id: patientData._id, is_deleted: false });
            if (insuranceData) {
                res.json({ code: 400, message: 'Information already exist' });
            } else {
                var insurance = req.body;
                insurance.patient_id = patientData._id;
                let savedData = yield new PatientInsurance(insurance).save();
                res.json({ code: 200, message: 'Patient insurance added successfully' });
            }
        }
    }).catch(function (err) {
        res.json({ code: 402, message: utility.validationErrorHandler(err), data: err });
    });
}

/**
 * Function is use to Add Patient Vitals 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 9-June-2017
 */
function addPatientVitals(req, res) {

    co(function* () {
        let userData = yield User.findById(req.user.id);

        if (userData) {
            var vitalsObj = {};
            var field = [];
            var obj = req.body;
            var body_mass = {
                height: req.body.body_mass.height,
                weight: req.body.body_mass.weight
            };
            var cholesterol = {
                total_cholesterol: req.body.cholesterol.total_cholesterol,
                HDL: req.body.cholesterol.HDL
            };
            var blood_pressure = {
                diastolic: req.body.blood_pressure.diastolic,
                systolic: req.body.blood_pressure.systolic
            };
            var newObj = obj;
            newObj.patient_id = req.user.id;
            newObj.cholesterol = cholesterol;
            newObj.blood_pressure = blood_pressure;
            newObj.body_mass = body_mass;
            var patientVital = new PatientVital(newObj);

            patientVital.save(function (err, vitals) {
                if (err) {
                    res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
                } else {
                    res.json({
                        code: 200,
                        message: constantsObj.messages.patientVitalsAddedSuccess,
                        data: vitals
                    });
                }

            });


        } else {
            return res.json(Response(402, constantsObj.messages.patientVitalsAddedFailed, err));
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    });
}

/**
 * Function is use to Add Patient Encounter 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 9-June-2017
 */
function addPatientEncounter(req, res) {
    co(function* () {
        let patientData = yield Patient.findOne({ user_id: req.user.id, is_deleted: false });
        if (patientData) {
            let encounterData = yield PatientEncounter.findOne({ patient_id: patientData._id, is_deleted: false });
            if (encounterData) {
                res.json({ code: 400, message: 'Information already exist' });
            } else {
                var encounter = req.body;
                encounter.patient_id = patientData._id;
                let savedData = yield new PatientEncounter(encounter).save();
                res.json({ code: 200, message: 'Patient Encounter added successfully' });
            }
        }
    }).catch(function (err) {
        res.json({ code: 402, message: utility.validationErrorHandler(err), data: err });
    });
}

/**
 * Function is use to Add Patient Medication 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 9-June-2017
 */
function addPatientMedication(req, res) {
    co(function* () {
        let patientData = yield Patient.findOne({ user_id: req.user.id, is_deleted: false });
        if (patientData) {
            let medicationData = yield PatientMedication.findOne({ patient_id: patientData._id, is_deleted: false });
            if (medicationData) {
                res.json({ code: 400, message: 'Information already exist' });
            } else {
                var medication = req.body;
                medication.patient_id = patientData._id;
                let savedData = yield new PatientMedication(medication).save();
                res.json({ code: 200, message: 'Patient Medication added successfully' });
            }
        }
    }).catch(function (err) {
        res.json({ code: 402, message: utility.validationErrorHandler(err), data: err });
    });
}

/**
 * Function is use to Add Patient Disease 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 15-June-2017
 * modified on 1-July-2017
 */
function addPatientDisease(req, res) {
    co(function* () {
        let patientData = yield Patient.findOne({ user_id: req.user.id, is_deleted: false });
        if (patientData) {
            let diseaseData = yield PatientDisease.findOne({ patient_id: patientData._id, is_deleted: false });
            if (diseaseData) {
                res.json({ code: 400, message: 'Information already exist' });
            } else {
                let savedData = yield new PatientDisease({
                    "patient_id": patientData._id,
                    "disease_id": req.body.disease_id,
                    "datetime_diagnosed": req.body.datetime_diagnosed,
                    "condition": req.body.condition,
                    "pDflag": req.body.pDflag
                }).save();
                res.json({ code: 200, message: 'Patient disease added successfully' });
            }
        }
    }).catch(function (err) {
        res.json({ code: 402, message: 'Internal error', err });
    });
}
/**
 * Function is use to Update Patient Data
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 6-June-2017
 */
function updatePatient(req, res) {
    co(function* () {
        let patientData = yield Patient.findById(req.body._id);
        if (patientData) {
            let savedData = yield patientData.save();
            return res.json(Response(200, constantsObj.messages.patientUpdatedSuccess, {}));
        } else {
            return res.json(Response(402, constantsObj.validationMessages.patientUpdatedFailed, err));
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    });
}

/**
 * Function is use to Add Patient Device
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 10-June-2017
 */
function addPatientDevice(req, res) {
    co(function* () {
        let savedData = yield Device.findById(req.body._id);
        if (savedData) {
            savedData.deviceName = req.body.deviceName;
            savedData.deviceType = req.body.deviceType;
            savedData.make = req.body.make;
            savedData.model = req.body.model;
            savedData.description = req.body.description;
            savedData.wearable = req.body.wearable;
            let savedDataNew = yield savedData.save();
            res.json({
                code: 200,
                message: constantsObj.messages.patientDeviceUpdatedSuccess,
            });
        } else if (!savedData) {
            var deviceObj = req.body;
            console.log("req.body-------->>>>>",deviceObj);
            deviceObj.status = true;
            Patient.findOne({ user_id: req.user.id }).exec(function (err, patient) {
                if (err) {
                    res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
                } else {
                    deviceObj.patient_id = patient._id;
                    var device = new Device(deviceObj);
                    device.save(function (err, device) {
                        if (err) {
                            res.json({
                                code: 404,
                                message: utility.validationErrorHandler(err)
                            });
                        } else {
                            res.json({
                                code: 200,
                                message: constantsObj.messages.DeviceAddedSuccess,
                                data: device
                            });
                        }

                    });
                }
            });


            //})
        } else {
            return res.json(Response(402, constantsObj.validationMessages.patientMedicationAddedFailed, err));
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    });
}




function getPatientVitals(req, res) {
    PatientVital.find({ patient_id: req.user.id }).lean().exec(function (err, data) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else {
            res.json({
                code: 200,
                data: data
            })
        }
    })
}


function viewPatientVitalsById(req, res) {
    var id = req.swagger.params.id.value;
    PatientVital.findOne({ _id: id }).lean().exec(function (err, data) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else {
            res.json({
                code: 200,
                data: data
            })
        }
    })
}
/**
 * Function is use to Get Patient Device  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 10-June-2017
 */
function getPatientDevice(req, res) {
    // let patientId = req.user.id;
    // console.log("patientId--->", patientId);
    Device.find({ is_deleted: false, status: true }).populate('deviceType').lean().exec(function (err, device) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (device) {
            //var newArr = [];
            //var filed = ['patient_id'];
            //utility.decryptedRecord(device, filed, function(newArr){
            res.json({
                code: 200,
                message: constantsObj.messages.patientDeviceGettingSuccess,
                data: device
            })
            //})   
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}
/**
 * Function is use to Get Patient Device  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 10-June-2017
 */
function deletePatientDeviceDetail(req, res) {
    var deviceId = req.swagger.params.id.value;
    Device.update({ _id: deviceId }, { $set: { is_deleted: true } }, function (err) {
        //Device.findOne({ _id: deviceId }).lean().exec(function(err, device) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else {
            res.json({
                code: 200,
                message: constantsObj.messages.patientDeviceDeleteSuccess,
            })
        }
    })
}
/**
 * Function is use to Get Patient Device  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 10-June-2017
 */
function getPatientDeviceDetail(req, res) {
    console.log("getPatientDeviceDetail");
    var deviceId = req.swagger.params.id.value;
    Device.findOne({ _id: deviceId }).lean().exec(function (err, device) {
        console.log("device----------->>>>", device);
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (device) {
            //var newArr = [];
            //var filed = ['patient_id'];
            //utility.decryptedRecord(device, filed, function(newArr){
            res.json({
                code: 200,
                message: constantsObj.messages.patientDeviceGettingSuccess,
                data: device
            })
            //})   
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

/**
 * Function is use to Get Patient Device  
 * @access private
 * @return json
 * Created by Vinod
 * @smartData Enterprises (I) Ltd
 * Created Date 12-June-2017
 */
function getPatientActivity(req, res) {
    var deviceId = req.swagger.params.id.value;
    var weekStr = req.swagger.params.week.value
    if (weekStr == 'd') {
        var start = moment().startOf('day').toISOString();
        var end = moment().endOf('day').toISOString();
    } else if (weekStr > 0) {
        var start = moment().subtract(weekStr, 'weeks').startOf('week').toISOString();
        var end = moment().subtract(weekStr, 'weeks').endOf('week').toISOString();
    } else {
        var start = moment().startOf('week').toISOString();
        var end = moment().endOf('week').toISOString();
    }
    //var start = moment('2017-05-01').toISOString();
    Patient.findOne({ user_id: req.user.id }).exec(function (err, patient) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else {
            var patient_id = patient._id;
            PatientActivity.aggregate([{
                $project: {
                    patient_id: 1,
                    device_id: 1,
                    grpid: 1,
                    category: 1,
                    measures: 1,
                    measures_date: 1,
                    //yearMonthDay: { $dateToString: { format: "%Y-%m-%d", date: "$measures_date" } }
                    yearMonthDay: { $dateToString: { format: "%Y-%m-%d", date: "$measures_date" } }
                }
            }, {
                $match: {
                    patient_id: mongoose.Types.ObjectId(patient_id),
                    device_id: mongoose.Types.ObjectId(deviceId),
                    measures_date: { '$gte': new Date(moment(start)), '$lt': new Date(moment(end)) }
                }
            }, {
                $group: {
                    _id: '$yearMonthDay',
                    data: {
                        $push: {
                            patient_id: '$patient_id',
                            device_id: '$device_id',
                            grpid: '$grpid',
                            category: '$category',
                            measures: '$measures',
                            measures_date: '$measures_date'
                        }
                    }
                }
            }, {
                $sort: {
                    measures_date: -1
                }
            }])
                .exec(function (err, activity) {
                    if (err) {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        });
                    } else if (activity) {
                        var activityRtn = [];
                        async.each(activity, function (activityData, callback) {
                            var newActivity = {};
                            newActivity._id = activityData._id;
                            var newArr = [];
                            var filed = ['patient_id', 'device_id', 'measures_date'];
                            utility.decryptedRecord(activityData.data, filed, function (newArr) {
                                newActivity.data = newArr;
                            })
                            activityRtn.push(newActivity);
                            callback();
                        }, function (err) {
                            if (err) {
                                res.json({
                                    code: 404,
                                    message: constantsObj.messages.noDataFound
                                })
                            } else {
                                res.json({
                                    code: 200,
                                    message: constantsObj.messages.patientDeviceGettingSuccess,
                                    data: activityRtn,
                                    dates: { startDate: start, endDate: end }
                                })
                            }
                        })

                    } else {
                        res.json({
                            code: 404,
                            message: constantsObj.messages.noDataFound
                        })
                    }
                }).catch(function (err) {
                    return res.json(Response(402, utility.validationErrorHandler(err), err));
                })
            /*PatientActivity.find({patient_id:patient_id,device_id:deviceId}).lean().sort('measures_date').exec(function (err, activity) {
                if (err) {
                  res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                  });
                } else if (activity) {
                  var newArr = [];
                  var filed = ['patient_id','device_id','measures_date'];
                  utility.decryptedRecord(activity, filed, function(newArr){
                      res.json({
                            code: 200,
                            message: constantsObj.messages.patientDeviceGettingSuccess,
                            data: newArr
                      })
                  })   
                  } else {
                      res.json({
                      code: 404,
                      message: constantsObj.messages.noDataFound
                      })
                  }
              }).catch(function (err) {
                 return res.json(Response(402,utility.validationErrorHandler(err), err));
              })*/
        }
    });
}

/**
 * Function is use to Add Patient Family History  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 12-June-2017
 */
function addPatientFamilyHistory(req, res) {
    co(function* () {
        let patientData = yield Patient.findOne({ user_id: req.user.id, is_deleted: false });
        if (patientData) {
            let familyData = yield PatientFamilyHistory.findOne({ patient_id: patientData._id, is_deleted: false });
            if (familyData) {
                res.json({ code: 400, message: 'Information already exist' });
            } else {
                var history = req.body;
                history.patient_id = patientData._id;
                let savedData = yield new PatientFamilyHistory(history).save();
                res.json({ code: 200, message: 'Patient disease added successfully' });
            }
        }
    }).catch(function (err) {
        res.json({ code: 402, message: 'Internal error', err });
    });
}

/**
 * Function is Add Patient Allergies And Reactions
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 12-June-2017
 * modified on 30-June-2017
 */
function addPatientAllergiesAndReactions(req, res) {
    co(function* () {
        let patientData = yield Patient.findOne({ user_id: req.user.id, is_deleted: false });
        if (patientData) {
            let allergiesData = yield PatientAllergicReaction.findOne({ patient_id: patientData._id, is_deleted: false });
            if (allergiesData) {
                res.json({ code: 400, message: 'Information already exist' });
            } else {
                let savedData = yield new PatientAllergicReaction({
                    "patient_id": patientData._id,
                    "allergies": req.body.allergies,
                    "aRflag": req.body.aRflag
                }).save();
                res.json({ code: 200, message: 'Patient allergies and reaction added successfully' });
            }
        }
    }).catch(function (err) {
        res.json({ code: 402, message: utility.validationErrorHandler(err), data: err });
    });
}

/**
 * Function is Add Patient Chronic Disease
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 12-June-2017
 * modified on 3-July-2017
 */
function addPatientChronicDisease(req, res) {
    co(function* () {
        let patientData = yield Patient.findOne({ user_id: req.user.id, is_deleted: false });
        if (patientData) {
            let diseaseData = yield PatientChronicDisease.findOne({ patient_id: patientData._id, is_deleted: false });
            if (diseaseData) {
                res.json({ code: 400, message: 'Information already exist' });
            } else {
                let savedData = yield new PatientChronicDisease({
                    "patient_id": patientData._id,
                    "disease_id": req.body.disease_id,
                    "start_date": req.body.start_date,
                    "condition": req.body.condition,
                    "pCflag": req.body.pCflag
                }).save();
                res.json({ code: 200, message: 'Patient disease added successfully' });
            }
        }
    }).catch(function (err) {
        res.json({ code: 402, message: 'Internal error', err });
    });
}

/**
 * Function is Add Patient Surgeries
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 12-June-2017
 */
function addPatientSurgeries(req, res) {
    co(function* () {
        let patientData = yield Patient.findOne({ user_id: req.user.id, is_deleted: false });
        if (patientData) {
            let surgeriesData = yield PatientSurgery.findOne({ patient_id: patientData._id, is_deleted: false });
            if (surgeriesData) {
                res.json({ code: 400, message: 'Information already exist' });
            } else {
                var surgery = req.body;
                surgery.patient_id = patientData._id
                let savedData = yield new PatientSurgery(surgery).save();
                res.json({ code: 200, message: 'Patient Surgeries added successfully' });
            }
        }
    }).catch(function (err) {
        res.json({ code: 402, message: "Internal error", data: err });
    });
}

/**
 * Function is use to Get Patient Details 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 12-June-2017
 */
function getPatientById(req, res) {
    var id = req.swagger.params.id.value;
    Patient.findOne({ _id: id }).lean().exec(function (err, patient) {
        Patient.findOne({ _id: id }).populate('user_id').lean().exec(function (err, patient) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (patient) {
                //console.log("patienttrtt", patient);
                var newArr = [];
                var filed = ['user_id', 'clinician_id', 'coordinator_id', 'DOB', 'image', 'country', 'hospital_id'];
                utility.decryptedRecord(patient, filed, function (newArr) {
                    res.json({
                        code: 200,
                        message: constantsObj.messages.patientDetailsGettingSuccess,
                        data: newArr
                    })
                })
            } else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}


function getPatientByAdminId(req, res) {
    var id = req.swagger.params.id.value;
    Patient.findOne({ _id: id }).populate('user_id').lean().exec(function (err, patient) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (patient) {
            var patientArr = [];
            var filed = ['user_id', 'clinician_id', 'coordinator_id', 'DOB', 'image', 'country', 'hospital_id'];
            utility.decryptedRecord(patient, filed, function (patientArr) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientDetailsGettingSuccess,
                    data: patientArr
                })
            })


        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

function getPatientDetailById(req, res) {
    console.log("getPatientDetailById",req.swagger.params.id.value);
    var id = req.swagger.params.id.value;
    Patient.findOne({ _id: id }).lean().exec(function (err, patientData) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (patientData) {
            PatientVital.findOne({ patient_id: patientData.user_id }).sort({ "createdAt": -1 }).limit(1).exec(function (vitalErr, vitalData) {
                if (vitalErr) {
                    res.json({
                        code: 404,
                        message: "Patient Vital Data Not Found"
                    })
                } else {

                    var newArr = {};
                    var filed = ['user_id', 'clinician_id', 'coordinator_id', 'hospital_id', 'DOB', 'smoker', 'diabetes', 'bp_treatment', 'reports_documents', 'image'];
                    utility.decryptedRecord(patientData, filed, function (newArr) {
                        var data = {};
                        data.vitalData = vitalData;
                        data.patientData = newArr;
                        res.json({
                            code: 200,
                            message: constantsObj.messages.patientDetailsGettingSuccess,
                            data: data
                        })
                    })
                }
            })
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}


function getRiskAssessmentReportByPatient(req, res) {
    var id = req.swagger.params.id.value;
    RiskAssessments.findOne({ patient_id: id }).sort({ "createdAt": -1 }).limit(1).populate('patient_id').lean().exec(function (err, data) {
        //RiskAssessments.findOne({ patient_id: id }).sort({ "createdAt": -1 }).limit(1).populate('patient_id').exec(function(err, data) {
        if (err) {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        } else {
            var newArr = {};
            var filed = ['patient_id', 'body_mass', 'blood_pressure', 'cholesterol', 'bp_treatment', 'diabetes', 'smoker', 'risk'];
            utility.decryptedRecord(data, filed, function (newArr) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientDetailsGettingSuccess,
                    data: newArr

                })
            })
        }
    })
}


/*function getRiskAssessmentReportByPatient(req, res) {
    var id = req.swagger.params.id.value;
    console.log("id", id);
    Patient.findOne({ _id: id }).lean().exec(function(err, patientData) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (patientData) {
            console.log("patient-------------", patientData);
            RiskAssessments.findOne({ patient_id: patientData._id }).sort({ "createdAt": -1 }).limit(1).exec(function(RiskErr, RiskAssmntData) {
                if (RiskErr) {
                    res.json({
                        code: 404,
                        message: "Patient RiskAssessment Data Not Found"
                    })
                } else {
                    //console.log("vitalData", vitalData);

                    var newArr = {};
                    var RiskArr = {};
                    var filed = ['user_id', 'clinician_id', 'coordinator_id', 'hospital_id', 'DOB', 'age', 'smoker', 'diabetes', 'bp_treatment', 'reports_documents'];
                    var riksFiled = ['patient_id', 'body_mass', 'blood_pressure', 'cholesterol'];
                    utility.decryptedRecord(patientData, filed, function(newArr) {
                        utility.decryptedRecord(RiskAssmntData, riksFiled, function(RiskArr) {
                            // console.log("newArr", newArr);
                            var data = {};
                            data.patientData = newArr;
                            data.RiskAssmntData = RiskArr;
                            res.json({
                                code: 200,
                                message: constantsObj.messages.patientDetailsGettingSuccess,
                                data: data

                            })
                        })
                    })
                }
            })
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    }).catch(function(err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}*/


/**
 * Function is use to Get Patient Details 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 12-June-2017
 */
function getPatientDetails(req, res) {
    Patient.findOne({ user_id: req.user.id, is_deleted: false }).populate('user_id').populate('country').lean().exec(function (err, patient) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (patient) {
            console.log("patient--->", patient);
            var newArr = [];
            var filed = ['user_id', 'DOB', 'image', 'smoker', 'diabetes', 'pflag', 'bp_treatment', 'country', 'hospital_id', 'clinician_id'];
            utility.decryptedRecord(patient, filed, function (newArr) {
                res.json({
                    code: 200,
                    message: constantsObj.messages.patientDetailsGettingSuccess,
                    data: newArr
                })
            })
        } else {
            res.json({
                code: 404,
                message: 'no data found'
            })
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

/**
 * Function is use to Get Patient Disease 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 12-June-2017
 * modified on 1-July-2017
 */
function getPatientDisease(req, res) {
    co(function* () {
        var id = req.user.id;
        let patientData = yield Patient.findOne({ user_id: id, is_deleted: false });
        if (patientData) {
            let patientDisease = yield PatientDisease.findOne({ patient_id: patientData._id, is_deleted: false }).populate('disease_id').lean().exec();
            if (patientDisease) {
                res.json({ code: 200, message: "Patient disease get successfully", data: patientDisease });
            } else {
                res.json({ code: 400, message: "No record found" });
            }
        } else {
            res.json({ code: 400, message: "No record found" });
        }
    }).catch(function (err) {
        res.json({ code: 402, message: 'Internal Error', err });
    });
}
/**
 * Function is use to Get Patient Chronic Disease 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 12-June-2017
 */
function getPatientChronicDisease(req, res) {
    co(function* () {
        var id = req.user.id;
        let patientData = yield Patient.findOne({ user_id: id, is_deleted: false });
        if (patientData) {
            let patientDisease = yield PatientChronicDisease.findOne({ patient_id: patientData._id, is_deleted: false }).populate('disease_id').lean().exec();
            if (patientDisease) {
                res.json({ code: 200, message: "Patient Chronic disease get successfully", data: patientDisease });
            } else {
                res.json({ code: 400, message: "No record found" });
            }
        } else {
            res.json({ code: 400, message: "No record found" });
        }
    }).catch(function (err) {
        res.json({ code: 500, message: 'Internal Error', err });
    });
}

/**
 * Function is use to Get Patient Family History 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 12-June-2017
 */
function getPatientFamilyHistory(req, res) {
    co(function* () {
        var id = req.user.id;
        let patientData = yield Patient.findOne({ user_id: id, is_deleted: false });
        if (patientData) {
            let patientHistory = yield PatientFamilyHistory.findOne({ patient_id: patientData._id, is_deleted: false }).populate('disease_id').lean().exec();
            if (patientHistory) {
                res.json({ code: 200, message: "Patient family history get successfully", data: patientHistory });
            } else {
                res.json({ code: 400, message: "No record found" });
            }
        } else {
            res.json({ code: 400, message: "No record found" });
        }
    }).catch(function (err) {
        res.json({ code: 500, message: 'Internal Error', err });
    });
}

/**
 * Function is use to Get Patient Surgical History 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 12-June-2017
 */
function getPatientSurgeries(req, res) {
    co(function* () {
        var id = req.user.id;
        let patientData = yield Patient.findOne({ user_id: id, is_deleted: false });
        if (patientData) {
            let surgeriesData = yield PatientSurgery.findOne({ patient_id: patientData._id, is_deleted: false }).lean().exec();
            if (surgeriesData) {
                res.json({ code: 200, message: "Patient surgeries get successfully", data: surgeriesData });
            } else {
                res.json({ code: 400, message: "No record found" });
            }
        } else {
            res.json({ code: 400, message: "No record found" });
        }
    }).catch(function (err) {
        res.json({ code: 402, message: utility.validationErrorHandler(err), data: err });
    });
}

/**
 * Function is use to Delete Patient By Id 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 23-June-2017
 */
function deletePatientById(req, res) {
    var id = req.swagger.params.id.value;
    co(function* () {
        let patientData = yield Patient.findById(id);
        if (patientData) {
            let userData = yield User.findById(patientData.user_id);
            if (userData) {
                userData.is_deleted = true;
                let userDelete = yield userData.save();
            } else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.userDeletedFailed
                })
            }
            patientData.is_deleted = true;
            let patientDelete = yield patientData.save();
            res.json({
                code: 200,
                message: constantsObj.messages.userDeletedSuccess
            })
        } else {
            return res.json(Response(402, constantsObj.messages.noRecordFound, err));
        }
    }).catch(function (err) {
        return res.json(Response(404, utility.validationErrorHandler(err), err));
    });
}



function updatePatientProfile(req, res) {
    console.log("updatePatientProfile------------>>>>", req.body);
    var timestamp = Number(new Date()); // current time as number
    var file = req.swagger.params.file.value;
    var first_name = req.swagger.params.first_name.value;
    var last_name = req.swagger.params.last_name.value;
    var SSN = req.swagger.params.SSN.value;
    var age = req.swagger.params.age.value;
    var gender = req.swagger.params.gender.value;
    var mobile_no = req.swagger.params.mobile_no.value;
    var DOB = req.swagger.params.DOB.value;
    var pflag = req.swagger.params.pflag.value;
    var address = req.swagger.params.address.value;
    var city = req.swagger.params.city.value;
    var state = req.swagger.params.state.value;
    var zip_code = req.swagger.params.zip_code.value;
    var country = req.swagger.params.country.value;
    var smoker = req.swagger.params.smoker.value;
    var diabetes = req.swagger.params.diabetes.value;
    var bp_treatment = req.swagger.params.bp_treatment.value;
    var user_id = req.user.id;
    if (file) {
        var splitFile = file.originalname.split('.');
        var filename = +timestamp + '_' + common.randomToken(6) + '.' + ((splitFile.length > 0) ? splitFile[splitFile.length - 1] : file.originalname);
        var imagePath = "./public/assets/uploads/profile/" + filename;
    }
    var obj = {};
    obj.first_name = first_name;
    obj.last_name = last_name;
    obj.SSN = SSN;
    obj.age = age;
    obj.gender = gender;
    obj.mobile_no = mobile_no;
    obj.DOB = DOB;
    obj.pflag = pflag;
    obj.address = address;
    obj.city = city;
    obj.country = country;
    obj.state = state;
    obj.zip_code = zip_code;
    obj.smoker = smoker;
    obj.diabetes = diabetes;
    obj.bp_treatment = bp_treatment;
    if (file) {
        obj.file = file;
    }
    // utility.fileUpload(imagePath, file.buffer).then(function() {
    function update() {
        Patient.findOne({ user_id: user_id }).then(function (patient) {
            if (filename) {
                patient.image = "assets/uploads/profile/" + filename;
            }
            var patientObj = {};
            var field = ['user_id', 'DOB', 'country', 'file', 'pflag', 'smoker', 'diabetes', 'bp_treatment'];
            utility.encryptedRecord(obj, field, function (patientObj) {
                patient.first_name = patientObj.first_name;
                patient.last_name = patientObj.last_name;
                patient.SSN = patientObj.SSN;
                patient.age = patientObj.age;
                patient.gender = patientObj.gender;
                patient.mobile_no = patientObj.mobile_no;
                patient.DOB = patientObj.DOB;
                patient.pflag = patientObj.pflag;
                patient.address = patientObj.address;
                patient.city = patientObj.city;
                patient.state = patientObj.state;
                patient.zip_code = patientObj.zip_code;
                patient.state = patientObj.state;
                patient.country = patientObj.country;
                patient.smoker = patientObj.smoker;
                patient.diabetes = patientObj.diabetes;
                patient.bp_treatment = patientObj.bp_treatment;
                if (patient.image) {
                    patient.image = patient.image;
                }
                patient.save(function (err, ItemImage) {
                    if (err) {
                        res.json({ code: 500, status: "failed", message: constantsObj.validationMessages.internalError });
                    } else {
                        res.json({ code: 200, status: "failed", message: 'Item image added successfully' });
                    }
                });
            });
        }).catch(function (err) {
            res.json({ code: 500, message: constantsObj.validationMessages.internalError, data: err });
        });

    }
    if (file) {
        fs.writeFile(path.resolve(imagePath), file.buffer, function (err) {
            if (err) {
                res.json({ code: 402, 'message': 'Request could not be processed. Please try again.', data: {} });
            } else {
                update();
            }
        });
    } else {
        update();
    }

}

/**
 * Function is use to Enable Disable Patient
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-June-2017
 */
function enableDisablePatient(req, res) {
    if (!req.body.userId || req.body.status == null) {
        res.json({
            code: 402,
            status: 'failed',
            message: constantsObj.validationMessages.requiredFieldsMissing
        });
    } else {
        Patient.findById(req.body.userId).exec(function (err, data) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else {
                if (!data) {
                    res.json({ 'code': 402, status: 'failed', message: constantsObj.validationMessages.userNotFound });
                } else {
                    data.status = req.body.status;
                    data.save(function (err) {
                        if (err) {
                            res.json({
                                code: 404,
                                message: utility.validationErrorHandler(err)
                            });
                        } else {
                            User.findById(data.user_id).exec(function (err, userData) {
                                if (err) {
                                    res.json({
                                        code: 404,
                                        message: utility.validationErrorHandler(err)
                                    });
                                } else if (userData) {
                                    userData.status = req.body.status;
                                    userData.save(function (err) {
                                        if (err) {
                                            res.json({
                                                code: 404,
                                                message: utility.validationErrorHandler(err)
                                            });
                                        } else {
                                            res.json({ 'code': 200, status: 'success', "message": 'Patient ' + ((req.body.status == true) ? 'activated' : 'deactivated') + ' successfully' })
                                        }
                                    })

                                } else {
                                    res.json({ 'code': 402, status: 'failed', message: constantsObj.validationMessages.userNotFound });
                                }
                            })
                        }
                    })

                }
            }
        })
    }
}

/**
 * Function is use to Get Patient Allergies And Reactions
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 1-July-2017
 */
function getPatientAllergiesAndReactions(req, res) {
    co(function* () {
        var id = req.user.id;
        let patientData = yield Patient.findOne({ user_id: id, is_deleted: false });
        if (patientData) {
            let allergiesData = yield PatientAllergicReaction.findOne({ patient_id: patientData._id, is_deleted: false }).lean().exec();
            if (allergiesData) {
                res.json({ code: 200, message: "Patient data get successfully", data: allergiesData });
            } else {
                res.json({ code: 400, message: "No record found" });
            }
        } else {
            res.json({ code: 400, message: "No record found" });
        }
    }).catch(function (err) {
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}



// function addAppointment(req, res) {
//     var body = req.body;
//     console.log("body", body);
//     if (!validator.isValid(body.title) || !validator.isValid(body.description)) {
//         res.json({
//             'code': config.httpUnauthorize,
//             'message': 'Required fields are missing'
//         });
//     } else {

//         Patient.findOne({ user_id: req.user.id }).lean().exec(function(pateintErr, patientData) {
//             if (pateintErr) {
//                 res.json({
//                     'code': 402,
//                     'message': 'Patient data not found'
//                 })
//             } else {
//                 var appointment = new Appointment(body);
//                 if (patientData.clinician_id) {
//                     appointment.clinician_id = patientData.clinician_id;
//                     appointment.patient_id = patientData._id;
//                     appointment.status = true;
//                     appointment.save(function(err) {
//                         if (err) {
//                             res.json({
//                                 'code': config.httpUnauthorize,
//                                 'message': 'Unable to save appointment'
//                             });
//                         } else {
//                             res.json({
//                                 'code': 200,
//                                 'message': 'Appointment added successfully'
//                             });
//                         }
//                     });
//                 } else if (patientData.hospital_id) {
//                     appointment.hospital_id = patientData.hospital_id;
//                     appointment.patient_id = patientData._id;
//                     appointment.status = true;
//                     appointment.save(function(err) {
//                         if (err) {
//                             res.json({
//                                 'code': config.httpUnauthorize,
//                                 'message': 'Unable to save appointment'
//                             });
//                         } else {
//                             res.json({
//                                 'code': 200,
//                                 'message': 'Appointment added successfully'
//                             });
//                         }
//                     });
//                 } else {
//                     res.json({
//                         'code': 402,
//                         'message': 'You are not authorized for appointment'
//                     })
//                 }

//             }
//         });
//     }
// }

function addAppointment(req, res) {
    var body = req.body;
    console.log("body", body);
    if (!validator.isValid(body.title) || !validator.isValid(body.description) || !validator.isValid(body.hospital_id) || !validator.isValid(body.clinician_id)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        Patient.findOne({ user_id: req.user.id }).lean().exec(function (patientErr, patientData) {
            if (patientErr) {
                console.log("patientErr", patientErr);
            } else {
                var newArr = [];
                var filed = ['user_id', 'clinician_id', 'coordinator_id', 'DOB', 'image'];
                utility.decryptedRecord(patientData, filed, function (newArr) {
                    console.log("data", newArr);
                    if (body.is_video_call == '1') {
                        body.is_video_call = true;
                        body.room_id = randomstring(10);
                    } else {
                        body.is_video_call = false;
                    }
                    var appointment = new Appointment(body);
                    appointment.patient_id = patientData._id;
                    appointment.save(function (err) {
                        if (err) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Unable to save appointment'
                            });
                        } else {

                            Clinician.findOne({ _id: body.clinician_id }).populate({ path: 'user_id', select: 'email' }).lean().exec(function (clinicianErr, clinicianData) {
                                if (clinicianErr) {
                                    console.log("clinicianErr", clinicianErr);
                                } else {
                                    console.log("clinicianData", clinicianData);
                                    var userMailData = {
                                        first_name: clinicianData.first_name,
                                        last_name: clinicianData.last_name,
                                        patient_first_name: newArr.first_name,
                                        patient_last_name: newArr.last_name,
                                        appointment_title: body.title,
                                        appointment_description: body.description
                                    };
                                    console.log("email", userMailData);
                                    mailer.sendMail(clinicianData.user_id.email, constant.emailKeyword.SendAppointmnetByPatient, userMailData, function (err, resp) {
                                        if (err) {
                                            res.json({
                                                'code': 402,
                                                'message': 'Something went wrong'
                                            });
                                        } else {
                                            res.json({
                                                'code': 200,
                                                'message': 'Appointment added successfully'
                                            });
                                        }
                                    });
                                }
                            });

                        }
                    })
                })
            }
        })
    }
}

function decrypt(decText) {
    var decipher = crypto.createDecipher(algorithm, password)
    var decText = decipher.update(decText, 'hex', 'utf8')
    decText += decipher.final('utf8');
    return decText;
}

function getAppointmentById(req, res) {
    var id = req.swagger.params.id.value;
    Appointment.findOne({ _id: id }).populate({ path: 'patient_id', select: 'first_name last_name' }).lean().exec(function (err, data) {
        if (err) {
            res.json({
                'code': 402,
                'message': 'Appointment data not found'
            })
        } else {
            data.patient_id.first_name = decrypt(data.patient_id.first_name);
            data.patient_id.last_name = decrypt(data.patient_id.last_name);
            console.log("aaaa", data);
            res.json({
                'code': 200,
                'data': data
            })
            //});
        }
    })
}

function updateAppointment(req, res) {
    var body = req.body;
    if (!validator.isValid(body.response_message)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        Appointment.findOne({ _id: body._id }).exec(function (err, appointment) {
            if (err) {
                res.json({
                    'code': 402,
                    'message': 'Appointment data not found'
                })
            } else {
                var htmlstr = '<b>Hello There</b><br/></p>Someone requested to reset your passwod, Please ingore if you did not.<br/>Or<br/>Please "' + body.response_message + '" to reset your password.</p><p>---<br/>Thanks & Regards,<br>IOTies</p>';
                var data = {
                    from: 'iotied@yopmail.com',
                    to: 'rahul@yopmail.com',
                    subject: 'Appointment Status',
                    message: htmlstr
                }
                appointment.response_message = body.response_message;
                appointment.appointment_status = body.appointment_status;
                appointment.save(function (err, appointmentData) {
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Unable to save user'
                        });
                    } else {
                        Patient.findOne({ _id: appointment.patient_id }).populate({ path: 'user_id', select: 'email' }).lean().exec(function (patientErr, patientData) {
                            if (patientErr) {
                                console.log(patientErr, "patientErr");
                            } else {
                                var newArr = [];
                                var filed = ['user_id', 'clinician_id', 'coordinator_id', 'DOB', 'image'];
                                utility.decryptedRecord(patientData, filed, function (newArr) {
                                    var userMailData = {
                                        first_name: newArr.first_name,
                                        last_name: newArr.last_name,
                                        appointment_response: body.response_message
                                    };
                                    console.log("userMailData", userMailData);
                                    console.log("newArr.user_id.email", newArr.user_id.email);
                                    mailer.sendMail(newArr.user_id.email, constant.emailKeyword.ConfirmAppointmnetByClinician, userMailData, function (err, resp) {
                                        if (err) {
                                            console.log('email failed');
                                        } else {
                                            console.log('email success');
                                        }
                                    });
                                    res.json({
                                        'code': 200,
                                        'message': 'Appointment updated successfully'
                                    });
                                });
                            }
                        });

                    }
                });
            }
        });
    }
}

/**
 * Function is use to Get Patient Medication
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 3-July-2017
 */
function getPatientMedication(req, res) {
    co(function* () {
        var id = req.user.id;
        let patientData = yield Patient.findOne({ user_id: id, is_deleted: false });
        if (patientData) {
            let medicationData = yield PatientMedication.findOne({ patient_id: patientData._id, is_deleted: false }).lean().exec();
            if (medicationData) {
                res.json({ code: 200, message: "Patient medication get successfully", data: medicationData });
            } else {
                res.json({ code: 400, message: "No record found" });
            }
        } else {
            res.json({ code: 400, message: "No record found" });
        }
    }).catch(function (err) {
        res.json({ code: 402, message: utility.validationErrorHandler(err), data: err });
    });
}

/**
 * Function is use to Get Patient Encounter
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 3-July-2017
 */
function getPatientEncounter(req, res) {
    co(function* () {
        var id = req.user.id;
        let patientData = yield Patient.findOne({ user_id: id, is_deleted: false });
        if (patientData) {
            let encounterData = yield PatientEncounter.findOne({ patient_id: patientData._id, is_deleted: false }).populate('country').lean().exec();
            if (encounterData) {
                res.json({ code: 200, message: "Patient encounter get successfully", data: encounterData });
            } else {
                res.json({ code: 400, message: "No record found" });
            }
        } else {
            res.json({ code: 400, message: "No record found" });
        }
    }).catch(function (err) {
        res.json({ code: 402, message: utility.validationErrorHandler(err), data: err });
    });
}

/**
 * Function is use to Get Patient Insurance Details 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 4-July-2017
 */
function getPatientInsuranceDetails(req, res) {
    co(function* () {
        var id = req.user.id;
        let patientData = yield Patient.findOne({ user_id: id, is_deleted: false });
        if (patientData) {
            let patientInsurance = yield PatientInsurance.findOne({ patient_id: patientData._id, is_deleted: false }).populate('disease_id').lean().exec();
            if (patientInsurance) {
                res.json({ code: 200, message: "Patient insurance details get successfully", data: patientInsurance });
            } else {
                res.json({ code: 400, message: "No record found" });
            }
        } else {
            res.json({ code: 400, message: "No record found" });
        }
    }).catch(function (err) {
        res.json({ code: 500, message: 'Internal Error', err });
    });
}

/**
 * Function is use to Get Patient Demographics 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 4-July-2017
 */
function getPatientDemographics(req, res) {
    co(function* () {
        var id = req.user.id;
        let patientData = yield Patient.findOne({ user_id: id, is_deleted: false });
        if (patientData) {
            let patientDemographic = yield PatientDemographic.findOne({ patient_id: patientData._id, is_deleted: false }).populate('language').lean().exec();
            if (patientDemographic) {
                res.json({ code: 200, message: "Patient demographic get successfully", data: patientDemographic });
            } else {
                res.json({ code: 400, message: "No record found" });
            }
        } else {
            res.json({ code: 400, message: "No record found" });
        }
    }).catch(function (err) {
        res.json({ code: 500, message: 'Internal Error' });
    });
}


function uploadPatientReports(req, res) {
    var timestamp = Number(new Date()); // current time as number
    var file = req.swagger.params.file.value;
    var splitFile = file.originalname.split('.');
    var filename = +timestamp + '_' + common.randomToken(6) + '.' + ((splitFile.length > 0) ? splitFile[splitFile.length - 1] : file.originalname);
    var imagePath = "./public/assets/uploads/patientReports/" + filename;
    var obj = {};
    obj.file = file;
    fs.writeFile(path.resolve(imagePath), file.buffer, function (err) {
        if (err) {
            res.json({ code: 402, 'message': 'Request could not be processed. Please try again.', data: {} });
        } else {
            Patient.findOne({ user_id: req.user.id, is_deleted: false }).exec(function (err, patientData) {
                if (err) {
                    res.json({ code: 402, message: 'Error in finding' })
                } else if (patientData) {
                    var patientReport = new PatientReport();
                    patientReport.patient_id = patientData._id;
                    patientReport.upload_report = "assets/uploads/patientReports/" + filename;
                    patientReport.save(function (err, fileData) {
                        if (err) {
                            res.json({ code: 500, message: constantsObj.validationMessages.internalError });
                        } else {
                            res.json({ code: 200, message: "Report uploaded successfully" });
                        }
                    })
                } else {
                    res.json({ code: 400, message: "No record found" });
                }
            })
        }
    });
}

function getUploadReports(req, res) {
    var id = req.user.id;
    Patient.findOne({ user_id: id }).exec(function (err, patientData) {

        PatientReport.find({ patient_id: patientData._id, is_deleted: false, status: true }).lean().exec(function (err, report) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (report) {
                res.json({
                    code: 200,
                    message: 'Uploaded report get successfully',
                    data: report
                })

            } else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }

        })
    }).catch(function (err) {
        res.json({ code: 402, message: utility.validationErrorHandler(err), data: err });
    })
}

function viewUploadReport(req, res) {
    co(function* () {
        var id = req.swagger.params.id.value;
        let uploadReportInfo = yield PatientReport.findById(id).exec();
        res.json({ code: 200, message: constantsObj.messages.dataRetrievedSuccess, data: uploadReportInfo });
    }).catch(function (err) {
        res.json({ code: 402, message: utility.validationErrorHandler(err), });
    });
}

function deleteReportById(req, res) {
    var id = req.swagger.params.id.value;
    PatientReport.findById(id).exec(function (err, data) {
        if (err) {
            return res.json({ code: 500, message: 'internal error' });
        } else {
            if (!data) {
                return res.json({ code: 402, message: 'report not found' });
            } else {
                data.is_deleted = true;
                data.save(function (err, userData) {
                    if (err)
                        return res.json({ code: 500, message: 'internal error' });
                    else {
                        return res.json({ code: 200, message: 'Uploaded report deleted successfully' });
                    }
                });
            }
        }
    })
}


/**
 * Function is use to Get Pateint Last Risk Assessment (data show on dashboard)
 * @access private
 * @return json
 * Created by Akshay
 * @smartData Enterprises (I) Ltd
 * Created Date 6-July-2017
 */
function getLastRiskAssessmentScore(req, res) {
    Patient.findOne({ user_id: req.user.id }, { _id: 1 }).exec(function (err, data) {
        if (err) { } else {
            if (data) {
                RiskAssessments.findOne({ patient_id: data._id }).sort({ "createdAt": -1 }).limit(1).exec(function (err, data) {
                    if (err) {
                        res.json({
                            'code': 402,
                            'message': 'Patient Last Risk RiskAssessment Sore Not Found',
                        })
                    } else {
                        res.json({
                            'code': 200,
                            'data': data
                        })
                    }
                })
            }
        }
    });
}

/**
 * Function is use to Get Pateint Last Activity Score (data show on dashboard)
 * @access private
 * @return json
 * Created by Akshay
 * @smartData Enterprises (I) Ltd
 * Created Date 6-July-2017
 */
function getLastWithingScore(req, res) {
    Patient.findOne({ user_id: req.user.id }, { _id: 1 }).exec(function (err, data) {
        if (err) { } else {
            PatientActivity.findOne({ patient_id: data._id }).sort({ "createdAt": -1 }).limit(1).exec(function (err, withingdata) {
                if (err) {
                    res.json({
                        'code': 402,
                        'message': 'Patient Last Risk RiskAssessment Sore Not Found',
                    })
                } else {
                    var newArr = [];
                    var filed = ['patient_id', 'device_id', 'measures_date'];
                    utility.decryptedRecord(withingdata, filed, function (newArr) {
                        res.json({
                            code: 200,
                            data: newArr,
                        })
                    })
                }
            })
        }
    });
}


/**
 * Function is use to Get Hospital List
 * @access private
 * @return json
 * Created by Akshay M
 * @smartData Enterprises (I) Ltd
 * Created Date 11-july-2017
 */

function getAllAppointmentByPatientId(req, res) {
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };

    for (var key in req.body) {
        var reg = new RegExp("sorting", 'gi');
        if (reg.test(key)) {
            var value = req.body[key];
            key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
            var sorting = {};
            if (value == 1 || value == -1) {
                sorting[key] = value;
            } else {
                sorting[key] = (value == 'desc') ? -1 : 1;
            }
        }
    }

    Patient.findOne({ user_id: req.user.id }).lean().exec(function (patientErr, patientData) {
        if (patientErr) {
            res.json({
                code: 404,
                message: 'Clinician Data Not Found'
            })
        } else {
            var condition = {};
            var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            console.log("searchText", searchText);
            if (req.body.searchText) {
                condition.$or = [{ 'title': new RegExp(searchText, 'gi') },
                { 'clinicianInfo.first_name': new RegExp(searchText, 'gi') },
                { 'clinicianInfo.last_name': new RegExp(searchText, 'gi') },
                { 'hospitalInfo.hospital_name': new RegExp(searchText, 'gi') },
                ];
            }
            condition.is_deleted = false;
            condition.patient_id = patientData._id;
            console.log(condition, "condition");
            var aggregateQuery = [{
                $lookup: {
                    from: 'hospitals',
                    localField: "hospital_id",
                    foreignField: "_id",
                    as: "hospitalInfo"
                }
            },
            { $unwind: { path: "$hospitalInfo", preserveNullAndEmptyArrays: true } }, {
                $lookup: {
                    from: 'clinicians',
                    localField: "clinician_id",
                    foreignField: "_id",
                    as: "clinicianInfo"
                }
            },

            { $unwind: { path: "$clinicianInfo", preserveNullAndEmptyArrays: true } },
            { $match: condition },
            { $sort: sorting }, {
                $project: {
                    title: 1,
                    appointment_status: 1,
                    hospitalInfo: {
                        hospital_name: 1,
                    },
                    clinicianInfo: {
                        first_name: 1,
                        last_name: 1,
                    }
                }
            }
            ];

            var countQuery = [].concat(aggregateQuery);
            aggregateQuery.push({ $sort: sorting });
            aggregateQuery.push({ $skip: parseInt(skip) });
            aggregateQuery.push({ $limit: parseInt(count) });
            Appointment.aggregate(aggregateQuery).then(function (result) {
                countQuery.push({ $group: { _id: null, count: { $sum: 1 } } });
                Appointment.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    res.json({
                        code: 200,
                        data: result,
                        totalCount: cnt
                    })

                });
            }).catch(function (err) {
                console.log("err", err);
                return res.json({
                    code: 404,
                    message: 'internal Error'
                });
            });




        }
    })
}

function viewAppointmentById(req, res) {
    var id = req.swagger.params.id.value;
    Appointment.findOne({ _id: id }).populate({
        path: 'hospital_id',
        select: 'hospital_name'
    }).populate({
        path: 'clinician_id',
        select: 'first_name last_name'
    }).lean().exec(function (err, data) {
        if (err) {
            res.json({
                'code': 402,
                'message': 'Appointment data not found'
            })
        } else {
            res.json({
                'code': 200,
                'data': data
            })
        }
    })
}

/**
 * Function is use to Get Patients For Question Assignment
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 10-july-2017
 */
function getAllPatients(req, res) {
    AssignQuestions.distinct('patient_id', function (err, patientId) {
        Patient.find({ is_deleted: false, status: true, _id: { $nin: patientId } }, { '_id': true, 'first_name': true, 'last_name': true }).lean().exec(function (err, patient) {
            // console.log("response in assign question",patient);      
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (patient) {
                var newArr = [];
                var reqArr = [];
                var filed = ['_id'];
                utility.decryptedRecord(patient, filed, function (newArr) {
                    async.each(newArr, function (patientData, callback) {
                        var newData = {};
                        newData.id = patientData._id;
                        newData.label = patientData.first_name + ' ' + patientData.last_name;
                        reqArr.push(newData);
                        callback();
                    }, function (err) {
                        if (err) {
                            res.json({
                                code: 404,
                                message: constantsObj.messages.noDataFound
                            })
                        } else {
                            res.json({
                                code: 200,
                                message: constantsObj.messages.patientDetailsGettingSuccess,
                                data: reqArr,
                            })
                        }
                    })
                })
            } else {
                res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                })
            }
        }).catch(function (err) {
            return res.json(Response(402, utility.validationErrorHandler(err), err));
        })
    })
}


function randomstring(num) {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < num; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}

/**
 * Function is use to Get Assign Question Patient List
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 13-July-2017
 */
function getAssignPatient(req, res) {
    var count = req.query.count ? req.query.count : 0;
    var skip = req.query.count * (req.query.page - 1);
    var sorting = req.query.sorting ? req.query.sorting : { _id: -1 };
    var condition = { is_deleted: false };
    AssignQuestions.distinct('patient_id', function (err, patientId) {
        Patient.find({ is_deleted: false, _id: { $in: patientId } }, { '_id': true, 'first_name': true, 'last_name': true, 'SSN': true, 'mobile_no': true }, { condition }).limit(parseInt(count))
            .skip(parseInt(skip))
            .sort(sorting).lean().exec(function (err, patient) {
                if (err) {
                    res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
                } else if (patient) {
                    Patient.find({ is_deleted: false, _id: { $in: patientId } }, { '_id': true, 'first_name': true, 'last_name': true, 'SSN': true, 'mobile_no': true }, { condition })
                        .count()
                        .exec(function (err, totalCount) {
                            if (err) {
                                res.json({
                                    code: 404,
                                    message: 'TotalCount Not Correct'
                                })
                            } else {
                                var newArr = [];
                                var reqArr = [];
                                var filed = ['_id'];
                                utility.decryptedRecord(patient, filed, function (newArr) {
                                    async.each(newArr, function (patientData, callback) {
                                        var newData = {};
                                        newData._id = patientData._id;
                                        newData.first_name = patientData.first_name;
                                        newData.last_name = patientData.last_name;
                                        newData.SSN = patientData.SSN;
                                        newData.mobile_no = patientData.mobile_no;
                                        reqArr.push(newData);
                                        callback();
                                    }, function (err) {
                                        if (err) {
                                            res.json({
                                                code: 404,
                                                message: constantsObj.messages.noDataFound
                                            })
                                        } else {
                                            res.json({
                                                code: 200,
                                                message: constantsObj.messages.patientDetailsGettingSuccess,
                                                data: reqArr,
                                                totalCount: totalCount
                                            })
                                        }
                                    })
                                })
                            }
                        });
                } else {
                    res.json({
                        code: 404,
                        message: constantsObj.messages.noDataFound
                    })
                }
            })
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

/**
 * Function is use to Submit Patient Self Assesment Question 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 14-July-2017
 */
function submitQuestions(req, res) {
    Patient.findOne({ user_id: req.user.id }).exec(function (err, patientInfo) {
        PatientAssessment.findOne({ patient_id: patientInfo._id, is_deleted: false, status: true }).exec(function (err, detailsAssessment) {
            if (err) {
                res.json({
                    code: 404,
                    message: utility.validationErrorHandler(err)
                });
            } else if (detailsAssessment) {
                res.json({
                    code: 202,
                    message: 'Information already exist'
                })
            } else {
                var assesmentQuestionData = req.body.assesmentQuestionData;
                async.each(assesmentQuestionData, function (record, callback) {
                    var patientAssessment = new PatientAssessment();
                    patientAssessment.question_id = record._id;
                    patientAssessment.patient_id = patientInfo._id;
                    if (typeof (record.answer) == 'object') {
                        var checkAnswer = '';
                        for (var data in record.answer)
                            if (record.answer[data] != false) {
                                checkAnswer = checkAnswer + record.answer[data] + ',';
                            }
                        checkAnswer = checkAnswer.substring(0, checkAnswer.length - 1);
                        console.log("checkAnswer", checkAnswer);
                        patientAssessment.answer = checkAnswer;
                    } else {
                        patientAssessment.answer = record.answer;
                    }
                    patientAssessment.save(function (err, questionData) {
                        if (err) {
                            res.json({
                                code: 404,
                                message: utility.validationErrorHandler(err)
                            });
                        }
                    })
                    callback();
                }, function (err) {
                    if (err) {
                        res.json({ code: 404, message: "Internal error" });
                    } else {
                        res.json({ code: 200, message: "Self assessment questions submitted successfully" });
                    }
                })
            }
        })

    })
}

/**
 * Function is use to Get Assesment Questions By Id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 14-July-2017
 */
function getSubmitQuestions(req, res) {
    Patient.findOne({ user_id: req.user.id }).exec(function (err, patientInfo) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else if (patientInfo) {
            AssignQuestions.distinct('question_id', { patient_id: patientInfo._id, is_deleted: false, status: true }, function (err, questionIds) {
                AssesmentQuestion.find({ is_deleted: false, status: true, _id: { $in: questionIds } }).sort({ '_id': 1 }).lean().exec(function (err, question) {
                    if (err) {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        });
                    } else if (question) {
                        PatientAssessment.find({ is_deleted: false, status: true, patient_id: patientInfo._id }).sort({ 'question_id': 1 }).exec(function (err, answerData) {
                            //console.log('answerData',answerData);
                            if (err) {
                                res.json({
                                    code: 404,
                                    message: utility.validationErrorHandler(err)
                                });
                            } else if (answerData) {
                                var isEdit = false;
                                if (answerData.length > 0) {
                                    isEdit = true;
                                    for (var i = 0; i < question.length; i++) {
                                        question[i]['answer'] = answerData[i];
                                        if (answerData[i] != undefined) {
                                            if (question[i].question_type == 'checkbox') {
                                                question[i]['answer'] = [];
                                                question[i]['answer'] = answerData[i].answer.split(',');
                                            } else {
                                                question[i]['answer'] = answerData[i].answer;
                                            }
                                        }

                                    }
                                }
                                res.json({
                                    code: 200,
                                    message: constantsObj.messages.AssesmentQuestionGettingSuccess,
                                    data: question,
                                    isEdit: isEdit
                                })

                            } else {
                                res.json({
                                    code: 200,
                                    message: constantsObj.messages.AssesmentQuestionGettingSuccess,
                                    data: question
                                })
                            }
                        })
                    } else {
                        res.json({
                            code: 404,
                            message: constantsObj.messages.noDataFound
                        })
                    }
                })
            })
        } else {
            res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
            })
        }
    }).catch(function (err) {
        return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

/**
 * Function is use to View Assigned Assesment Questions By Patient Id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 15-July-2017
 */
function viewAssignQuestion(req, res) {
    var id = req.swagger.params.id.value;
    co(function* () {
        AssignQuestions.distinct('question_id', { patient_id: id, is_deleted: false, status: true }, function (err, questionIds) {
            if (err) {
                res.json({ code: 402, message: utility.validationErrorHandler(err), });
            } else if (questionIds) {
                AssesmentQuestion.find({ is_deleted: false, status: true, _id: { $in: questionIds } }, { '_id': true, 'question': true }).lean().exec(function (err, question) {
                    if (err) {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        });
                    } else if (question) {
                        res.json({
                            code: 200,
                            message: "Successfully get the assign questions",
                            data: question
                        })
                    } else {
                        res.json({
                            code: 404,
                            message: constantsObj.messages.noDataFound
                        })
                    }
                })
            }
            // res.json({ code: 200, message: constantsObj.messages.dataRetrievedSuccess, data: uploadFileInfo});
        })
    }).catch(function (err) {
        res.json({ code: 402, message: utility.validationErrorHandler(err), });
    });
}

function composeMail(req, res) {
    var body = req.body;
    console.log("composeMail--->", body);
    console.log("user id check--->", req.user.id);
    co(function* () {
        let userInfo = yield User.findById(req.user.id).lean().exec();
        let from_name = '';
        let fromUserInfo = {};
        console.log("fromUserInfo-->", fromUserInfo);
        if (!validator.isValid(body.mail_to) || !validator.isValid(body.mail_subject) || !validator.isValid(body.mail_body)) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Required fields are missing'
            });
        } else {
            let roleInfo = yield Role.findOne({ _id: userInfo.role_id, is_deleted: false, status: true }).exec();
            console.log("roleInfo-->", roleInfo);
            if (roleInfo.name == 'Patient') {
                fromUserInfo = yield Patient.findOne({ is_deleted: false, user_id: req.user.id }, { 'first_name': true, 'last_name': true }).lean();
                console.log(" Patient fromUserInfo-->", fromUserInfo);
                if (fromUserInfo) {
                    fromUserInfo.first_name = decrypt(fromUserInfo.first_name);
                    fromUserInfo.last_name = decrypt(fromUserInfo.last_name);
                    from_name = fromUserInfo.first_name + "  " + fromUserInfo.last_name;
                }
            }
            else if (roleInfo.name == 'Hospital') {
                fromUserInfo = yield Hospital.findOne({ user_id: req.user.id }, { 'hospital_name': true }).lean();
                console.log(" Hospital fromUserInfo-->", fromUserInfo);
                if (fromUserInfo) {
                    from_name = fromUserInfo.hospital_name;
                }
            }
            else if (roleInfo.name == 'Clinician') {
                fromUserInfo = yield Clinician.findOne({ user_id: req.user.id }, { 'last_name': true, 'first_name': true }).lean();
                console.log(" Clinician fromUserInfo-->", fromUserInfo);
                if (fromUserInfo) {
                    from_name = fromUserInfo.first_name + "  " + fromUserInfo.last_name;
                }
            }
            else if (roleInfo.name == 'CareCoordinator') {
                fromUserInfo = yield CareCoordinator.findOne({ user_id: req.user.id }, { 'last_name': true, 'first_name': true }).lean();
                console.log(" CareCoordinator fromUserInfo-->", fromUserInfo);
                if (fromUserInfo) {
                    from_name = fromUserInfo.first_name + "  " + fromUserInfo.last_name;
                }
            }
            else if (roleInfo.name == 'Ambulance') {
                fromUserInfo = yield Ambulance.findOne({ user_id: req.user.id }, { 'company_name': true }).lean();
                console.log(" Ambulance fromUserInfo-->", fromUserInfo);
                if (fromUserInfo) {
                    from_name = fromUserInfo.company_name;
                }
            }
            else if (roleInfo.name == 'Towing') {
                fromUserInfo = yield Towing.findOne({ user_id: req.user.id }, { 'company_name': true }).lean();
                console.log(" Towing fromUserInfo-->", fromUserInfo);
                if (fromUserInfo) {
                    from_name = fromUserInfo.company_name;
                }
            }
            // only for test
            var userMailData = {
                mail_to: body.mail_to,
                mail_cc: body.mail_cc,
                mail_bcc: body.mail_bcc,
                subject: body.mail_subject,
                mail_body: body.mail_body,
                from_id: req.user.id,
                from_name: from_name,
                from_email: userInfo.email
            };

            mailer.sendMailToMultiple(constant.emailKeyword.GeneralEmail, userMailData, function (err, resp) {
                if (err) {
                    res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                } else {
                    res.json({
                        code: 200,
                        message: "Mail sent successfully",
                        data: {}
                    })
                }
            });
        }
    }).catch(function (err) {
        console.log("getVisitById Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}


function getMailList(req, res) {
    console.log("getMailList--->", req.body);
    console.log("req.user.id--------------->", req.user.id);
    co(function* () {
        let userInfo = yield User.findById(req.user.id).lean().exec();
        let userMail = userInfo.email;
         console.log("userMail--------------->", req.user.id);
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
        var condition =  { "$or": [{ "to": userMail }, { "cc": userMail }, { "bcc": userMail }] } ;
        condition.is_deleted = { $nin: [req.user.id]  };
        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (req.body.searchText) {
            condition.$or = [{ 'first_name': new RegExp(searchText, 'gi') }, { 'last_name': new RegExp(searchText, 'gi') }, { 'clinician_npi_no': new RegExp(searchText, 'gi') }, { 'SSN': new RegExp(searchText, 'gi') }, { 'mobile_no': new RegExp(searchText, 'gi') }, { 'hospitalInfo.hospital_name': new RegExp(searchText, 'gi') }];
        }
        let aggregate = [
            { $match: condition },
        ];
        var aggregateCnt = [].concat(aggregate);
        if (req.body.count && req.body.page) {
            console.log("----------in req.bosdy-------------");
            aggregate.push({ $sort: sorting });
            aggregate.push({ $skip: skip });
            aggregate.push({ $limit: count });
        }
        console.log("aggregate--->", aggregate);
        let emailHistoryData = yield EmailHistory.aggregate(aggregate);
        console.log("smsHistoryData-->", emailHistoryData);
        aggregateCnt.push({ $group: { _id: null, count: { $sum: 1 } } });
        let emailHistoryCount = yield EmailHistory.aggregate(aggregateCnt);
        return res.json({ code: 200, message: 'Data retrieved successfully', data: emailHistoryData, totalCount: ((emailHistoryCount[0]) ? emailHistoryCount[0].count : 0) });

    }).catch(function (err) {
        console.log('Error', err);
        return res.json({ code: 400, message: 'Internal server error', data: {} });
    });
}

function getSentMailList(req, res) {
    console.log("getSentMailList--->", req.body);
    console.log("req.user.id--------------->", req.user.id);
    co(function* () {
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
        var condition = { from_id: mongoose.Types.ObjectId(req.user.id) };

        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (req.body.searchText) {
            condition.$or = [{ 'first_name': new RegExp(searchText, 'gi') }, { 'last_name': new RegExp(searchText, 'gi') }, { 'clinician_npi_no': new RegExp(searchText, 'gi') }, { 'SSN': new RegExp(searchText, 'gi') }, { 'mobile_no': new RegExp(searchText, 'gi') }, { 'hospitalInfo.hospital_name': new RegExp(searchText, 'gi') }];
        }
        let aggregate = [
            { $match: condition },
        ];
        var aggregateCnt = [].concat(aggregate);
        if (req.body.count && req.body.page) {
            console.log("----------in req.bosdy-------------", req.body.count);
            aggregate.push({ $sort: sorting });
            aggregate.push({ $skip: skip });
            aggregate.push({ $limit: count });
        }
        console.log("aggregate--->", aggregate);
        let emailHistoryData = yield EmailHistory.aggregate(aggregate);
        console.log("smsHistoryData-->", emailHistoryData);
        aggregateCnt.push({ $group: { _id: null, count: { $sum: 1 } } });
        let emailHistoryCount = yield EmailHistory.aggregate(aggregateCnt);
        return res.json({ code: 200, message: 'Data retrieved successfully', data: emailHistoryData, totalCount: ((emailHistoryCount[0]) ? emailHistoryCount[0].count : 0) });

    }).catch(function (err) {
        console.log('Error', err);
        return res.json({ code: 400, message: 'Internal server error', data: {} });
    });
}

/**
 * Function is use to get mail by ID
 * @access private
 * @return json
 * Created by Swapnali
 * @smartData Enterprises (I) Ltd
 * Created Date 18-Jan-2018
 */
function getMailById(req, res) {
    co(function* () {
        var id = req.swagger.params.id.value;
        let mailInfo = yield EmailHistory.findById(id).lean().exec();
        let fromInfo = yield User.findById(mailInfo.from_id).lean().exec();
        let roleInfo = yield Role.findOne({ _id: fromInfo.role_id, is_deleted: false, status: true }).exec();
        let fromUserInfo = {};
        switch (roleInfo.name) {
            case 'Patient':
                fromUserInfo = yield Patient.findOne({ is_deleted: false, user_id: mailInfo.from_id }, { 'first_name': true, 'last_name': true }).lean();
                if (fromUserInfo) {
                    fromUserInfo.first_name = decrypt(fromUserInfo.first_name);
                    fromUserInfo.last_name = decrypt(fromUserInfo.last_name);
                    mailInfo.from_name = fromUserInfo.first_name + "  " + fromUserInfo.last_name;
                }
                break;
            case 'Hospital':
                fromUserInfo = yield Hospital.findOne({ user_id: mailInfo.from_id }, { 'hospital_name': true }).lean();
                if (fromUserInfo) {
                    mailInfo.from_name = fromUserInfo.hospital_name;
                }
                break;
            case 'Clinician':
                fromUserInfo = yield Clinician.findOne({ user_id: mailInfo.from_id }, { 'last_name': true, 'first_name': true }).lean();
                if (fromUserInfo) {
                    mailInfo.from_name = fromUserInfo.first_name + "  " + fromUserInfo.last_name;
                }
                break;
            case 'CareCoordinator':
                fromUserInfo = yield CareCoordinator.findOne({ user_id: mailInfo.from_id }, { 'last_name': true, 'first_name': true }).lean();
                if (fromUserInfo) {
                    mailInfo.from_name = fromUserInfo.first_name + "  " + fromUserInfo.last_name;
                }
                break;
            case 'Ambulance':
                fromUserInfo = yield Ambulance.findOne({ user_id: mailInfo.from_id }, { 'company_name': true }).lean();
                if (fromUserInfo) {
                    mailInfo.from_name = fromUserInfo.company_name;
                }
                break;
            case 'Towing':
                fromUserInfo = yield Towing.findOne({ user_id: mailInfo.from_id }, { 'company_name': true }).lean();
                if (fromUserInfo) {
                    mailInfo.from_name = fromUserInfo.company_name;
                }
                break;
        }
        return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": mailInfo });
    }).catch(function (err) {
        console.log("getVisitById Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}

function getPatientDeviceList(req, res) {
    var patientId = req.user.id;
    co(function* () {
        let patientInfo = yield Patient.findOne({ is_deleted: false, user_id: patientId }).lean();
        console.log("getPatientDeviceList-->", patientInfo._id);
        let deviceList = [];
        if (patientInfo && patientInfo._id) {
            let deviceList = yield Device.find({ patient_id: patientInfo._id, is_deleted: false, status: true }).populate('deviceType').lean().exec();
            return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": deviceList });
        }
        else {
            return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": [] });
        }
    }).catch(function (err) {
        console.log("getVisitById Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}

function getPatientFitbitActivity(req, res) {
    var deviceId = req.swagger.params.id.value;
    var weekStr = req.swagger.params.week.value
    if (weekStr == 'd') {
        var start = moment().startOf('day').toISOString();
        var end = moment().endOf('day').toISOString();
    } else if (weekStr > 0) {
        var start = moment().subtract(weekStr, 'weeks').startOf('week').toISOString();
        var end = moment().subtract(weekStr, 'weeks').endOf('week').toISOString();
    } else {
        var start = moment().startOf('week').toISOString();
        var end = moment().endOf('week').toISOString();
    }
    //var start = moment('2017-05-01').toISOString();
    Patient.findOne({ user_id: req.user.id }).exec(function (err, patient) {
        if (err) {
            res.json({
                code: 404,
                message: utility.validationErrorHandler(err)
            });
        } else {
            var patient_id = patient._id;
            PatientActivity.aggregate([{
                $project: {
                    patient_id: 1,
                    device_id: 1,
                    measures: 1,
                    createdAt: 1,
                    //yearMonthDay: { $dateToString: { format: "%Y-%m-%d", date: "$measures_date" } }
                    yearMonthDay: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }
                }
            }, {
                $match: {
                    patient_id: mongoose.Types.ObjectId(patient_id),
                    device_id: mongoose.Types.ObjectId(deviceId),
                    createdAt: { '$gte': new Date(moment(start)), '$lt': new Date(moment(end)) }
                }
            }, {
                $group: {
                    _id: '$yearMonthDay',
                    data: {
                        $push: {
                            patient_id: '$patient_id',
                            device_id: '$device_id',
                            // grpid: '$grpid',
                            // category: '$category',
                            measures: '$measures',
                            createdAt: '$createdAt'
                        }
                    }
                }
            }, {
                $sort: {
                    createdAt: -1
                }
            }])
                .exec(function (err, activity) {
                    if (err) {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        });
                    } else if (activity) {
                        var activityRtn = [];
                        async.each(activity, function (activityData, callback) {
                            console.log("activity----------->", activity);
                            for (var i = 0; i < activityData.data.length; i++) {
                                console.log("activityData.data----------->", i, activityData.data[i]);
                                if (activityData.data[i] && activityData.data[i].measures) {
                                    console.log("aactivityData.data[i]----------->", i, activityData.data[i]);

                                    //    if (activityData.data[i].measures && activityData.data[i].measures.length > 0) {
                                    let fetchedMeasures = activityData.data[i].measures;

                                    let measures = [];
                                    if (fetchedMeasures.weight) {
                                        //  console.log("fetchedMeasures.weight----------->", fetchedMeasures.weight);
                                        var weightValue = [];
                                        var bmiValue = [];
                                        var fatValue = [];
                                        for (let j = 0; j < fetchedMeasures.weight.length; j++) {
                                            // let weightObj = {}
                                            console.log("fetchedMeasures.weight[i]", j, fetchedMeasures.weight[i]);
                                            // weightValue.push({ time: fetchedMeasures.weight[j].time, value: fetchedMeasures.weight[j].weight });
                                            weightValue.push(fetchedMeasures.weight[j].weight + ' kg');
                                            bmiValue.push(fetchedMeasures.weight[j].bmi);
                                            if (fetchedMeasures.weight[j].fat) {
                                                fatValue.push(fetchedMeasures.weight[j].fat);
                                            }
                                        }
                                        measures.push({ type: "Weight", value: weightValue });
                                        measures.push({ type: "Body Mass Index", value: bmiValue });
                                        measures.push({ type: "Fat Percentage", value: fatValue });
                                        // if (fetchedMeasures.weight[0].weight) {
                                        //     measures.push({ type: "Weight", value: fetchedMeasures.weight[0].weight });
                                        // }
                                        // if (fetchedMeasures.weight[0].bmi) {
                                        //     measures.push({ type: "Body Mass Index", value: fetchedMeasures.weight[0].bmi });
                                        // }
                                        // if (fetchedMeasures.weight[0].fat) {
                                        //     measures.push({ type: "Fat Percentage", value: fetchedMeasures.weight[0].fat });
                                        // }
                                    }
                                    if (fetchedMeasures.user) {
                                        if (fetchedMeasures.user.height) {
                                            measures.push({ type: "Height", value: [fetchedMeasures.user.height + ' cm'] });
                                        }
                                    }
                                    if (fetchedMeasures.foodLogs) {
                                        console.log("fetchedMeasures.foodLogs.summary", fetchedMeasures.foodLogs.foods);
                                        if (fetchedMeasures.foodLogs.summary && fetchedMeasures.foodLogs.summary.water) {
                                            measures.push({ type: "Water Intake", value: [fetchedMeasures.foodLogs.summary.water + ' ml'] });
                                        }
                                        if (fetchedMeasures.foodLogs.summary && fetchedMeasures.foodLogs.summary.calories) {
                                            measures.push({ type: "Calories In", value: [fetchedMeasures.foodLogs.summary.calories] });
                                        }

                                        var food = {}
                                        var foodValue = [];
                                        if (fetchedMeasures.foodLogs.foods) {
                                            for (let j = 0; j < (fetchedMeasures.foodLogs.foods).length; j++) {
                                                let foodLog = fetchedMeasures.foodLogs.foods[j];
                                                foodValue.push({ mealType: foodLog.mealType, name: foodLog.name, amount: foodLog.amount, unitName: foodLog.unitName, calories: foodLog.calories + '  cals' });
                                            }
                                            food.foodValue = foodValue;
                                            food.summary = fetchedMeasures.foodLogs.summary;
                                            measures.push({ type: "Food", value: food });
                                        }
                                    }
                                    if (fetchedMeasures.activity) {
                                        //console.log("activities--->", fetchedMeasures.activity.activities);

                                        var activityValue = [];
                                        if (fetchedMeasures.activity.activities) {
                                            for (let j = 0; j < (fetchedMeasures.activity.activities).length; j++) {
                                                // let weightObj = {}
                                                //  console.log("fetchedMeasures.activities[i]", j, fetchedMeasures.activity.activities[j]);
                                                let activity = fetchedMeasures.activity.activities[j];
                                                activityValue.push({ time: activity.startTime, activityName: activity.activityName, steps: activity.steps, distance: activity.distance + '   ' + activity.distanceUnit, calories: activity.calories + '  cals' });
                                            }
                                            measures.push({ type: "Activity", value: activityValue });
                                        }

                                        if (fetchedMeasures.activity.summary && fetchedMeasures.activity.summary.steps) {
                                            measures.push({ type: "Steps", value: [fetchedMeasures.activity.summary.steps] });
                                        }
                                        if (fetchedMeasures.activity.summary && fetchedMeasures.activity.summary.distance) {
                                            measures.push({ type: "Distance", value: [fetchedMeasures.activity.summary.distance + ' km'] });
                                        }
                                    }
                                    // console.log("activityData.data--->", activityData.data);
                                    // console.log("----------------------i------------->", i);
                                    //  console.log("----------------------activityData.data[i]------------->", activityData.data[i]);
                                    activityData.data[i].measures = measures;
                                    //   }
                                    // console.log("fetchedMeasures----------->", fetchedMeasures);
                                }
                            }
                            activityRtn.push(activityData);
                            callback();
                        }, function (err) {
                            if (err) {
                                res.json({
                                    code: 404,
                                    message: constantsObj.messages.noDataFound
                                })
                            } else {
                                res.json({
                                    code: 200,
                                    message: constantsObj.messages.patientDeviceGettingSuccess,
                                    data: activityRtn,
                                    dates: { startDate: start, endDate: end }
                                })
                            }
                        })

                    } else {
                        res.json({
                            code: 404,
                            message: constantsObj.messages.noDataFound
                        })
                    }
                }).catch(function (err) {
                    return res.json(Response(402, utility.validationErrorHandler(err), err));
                })
        }
    });
}

function getPatientAllingedUserList(req, res) {
    console.log("------------getPatientAllingedUserList------------------");
    co(function* () {
        var userId = req.user.id;
        var userList = [];
        let patientInfo = yield Patient.findOne({ is_deleted: false, user_id: userId }).lean();
        console.log("------------patientInfo------------------", patientInfo);
        let allingedHospitalInfo = yield Hospital.findOne({ _id: patientInfo.hospital_id }).populate('user_id').lean();
        console.log("------------allingedHospitalInfo------------------", allingedHospitalInfo);
        if (allingedHospitalInfo) {
            userList.push(allingedHospitalInfo);
        }
        return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": userList });
    }).catch(function (err) {
        console.log("getPatientAllingedUserList Err---->", err);
        return res.json({ code: 404, message: "Internal error" });
    });
}


function markMailAsRead(req, res) {
    co(function* () {
        console.log("markMailAsRead--->", req.body);
        let emailHistoryData = yield EmailHistory.findOne({ _id: req.body.id }).exec();
        if ( (emailHistoryData.is_read).indexOf(req.user.id)  > -1 ){
            console.log("Already mark as read");
          //  return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": {} });
        }
        else{
           (emailHistoryData.is_read).push( req.user.id );
           let emailHistory = yield EmailHistory.update({ _id: req.body.id }, { $set: { is_read: emailHistoryData.is_read } }).exec();
           return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": {} });
        }
    }).catch(function (err) {
        console.log("markMailAsRead Err---->", err);
        return res.json({ code: 404, message: "Internal error" });
    })
}


function deleteEmailByHospital(req, res) {
    co(function* () {
        let emailHistoryList = req.body.mailToBeDeleted;
        console.log("deleteEmailByHospital-------->", emailHistoryList);
        for (var i = 0; i < emailHistoryList.length; i++) {
            var email_id = emailHistoryList[i]._id;
            let is_deletedList = emailHistoryList[i].is_deleted;
            is_deletedList.push(req.user.id);
            console.log("is_deletedList--->", is_deletedList);
            let emailNew = yield EmailHistory.update({ _id: email_id }, { $set: { is_deleted: is_deletedList } }).exec();
        }
        return res.json({ 'code': 200, status: 'success', "message": "delete Success", "data": {} });
    }).catch(function (err) {
        console.log("getSentSMSList Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}

function getUnreadMailCount(req, res) {
    console.log("getUnreadMailCount--->", req.body);
    console.log("req.user.id--------------->", req.user.id);
    co(function* () {
        let userInfo = yield User.findById(req.user.id).lean().exec();
        let userMail = userInfo.email;
        console.log("userMail--------------->", req.user.id);
        var count = parseInt(req.body.count ? req.body.count : 0);
        var skip = parseInt(req.body.count * (req.body.page - 1));
        var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
        var condition =  { "$or": [{ "to": userMail }, { "cc": userMail }, { "bcc": userMail }] } ;
        condition.is_deleted = { $nin: [req.user.id]  };
        condition.is_read = { $nin: [req.user.id]  };
        for (var key in req.body) {
            var reg = new RegExp("sorting", 'gi');
            if (reg.test(key)) {
                var value = req.body[key];
                key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
                var sorting = {};
                if (value == 1 || value == -1) {
                    sorting[key] = value;
                } else {
                    sorting[key] = (value == 'desc') ? -1 : 1;
                }
            }
        }
        var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
        if (req.body.searchText) {
            condition.$or = [{ 'first_name': new RegExp(searchText, 'gi') }, { 'last_name': new RegExp(searchText, 'gi') }, { 'clinician_npi_no': new RegExp(searchText, 'gi') }, { 'SSN': new RegExp(searchText, 'gi') }, { 'mobile_no': new RegExp(searchText, 'gi') }, { 'hospitalInfo.hospital_name': new RegExp(searchText, 'gi') }];
        }
        let aggregate = [
            { $match: condition },
        ];
        var aggregateCnt = [].concat(aggregate);
        if (req.body.count && req.body.page) {
            aggregate.push({ $sort: sorting });
            aggregate.push({ $skip: skip });
            aggregate.push({ $limit: count });
        }
        let emailHistoryData = yield EmailHistory.aggregate(aggregate);
        aggregateCnt.push({ $group: { _id: null, count: { $sum: 1 } } });
        let emailHistoryCount = yield EmailHistory.aggregate(aggregateCnt);
        return res.json({ code: 200, message: 'Data retrieved successfully', data: ((emailHistoryCount[0]) ? emailHistoryCount[0].count : 0) });
    }).catch(function (err) {
        console.log('Error', err);
        return res.json({ code: 400, message: 'Internal server error', data: {} });
    });
}


function getTollfreeNumber(req, res) {
    co(function* () {
        var userId = req.user.id;
        var tollfreeNo  ;
        let patientInfo = yield Patient.findOne({ is_deleted: false, user_id: userId }).lean();
        let hospitalInfo = yield Hospital.findOne({ _id: patientInfo.hospital_id }).populate('user_id').lean();
        let ivrInfo = yield IvrSetting.findOne({user_id:hospitalInfo.user_id._id})
        if(ivrInfo){
         tollfreeNo = ivrInfo.toll_free_number;
        }
        return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data":tollfreeNo });
    }).catch(function (err) {
        console.log("getPatientAllingedUserList Err---->", err);
        return res.json({ code: 404, message: "Internal error" });
    });
}
