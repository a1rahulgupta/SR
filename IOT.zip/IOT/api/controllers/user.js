'use strict';

var mongoose = require('mongoose'),
    co = require('co'),
    constant = require('../lib/constants'),
    utility = require('../lib/utility.js'),
    async = require('async'),
    constantsObj = require('../lib/constants'),
    User = mongoose.model('User'),
    crypto = require('crypto'),
    Clinician = mongoose.model('Clinician'),
    Hospital = mongoose.model('Hospital'),
    CareCoordinator = mongoose.model('CareCoordinator'),
    Ambulance = mongoose.model('Ambulance'),
    Towing = mongoose.model('Towing'),
    Patient = mongoose.model('Patient'),
    Role = mongoose.model('Role'),
    Response = require('../lib/response.js'),
    config = require('../../config/config.js'),
    algorithm = constantsObj.config.cryptoAlgorithm,
    HospitalAssign = mongoose.model('HospitalAssign'),
    password = constantsObj.config.cryptoPassword;
module.exports = {
    getUserList: getUserList,
    getAllAllignedUsers: getAllAllignedUsers
}

function decrypt(decText) {
    var decipher = crypto.createDecipher(algorithm, password)
    var decText = decipher.update(decText, 'hex', 'utf8')
    decText += decipher.final('utf8');
    return decText;
}
/**
 * Function is use to Get Disease  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 14-June-2017
 */
function getUserList(req, res) {
    console.log("in getUserList list");
    co(function* () {
        let userList = yield User.find({}).lean().exec();
        for (var i = 0; i < userList.length; i++) {
            console.log("userList[i]-->", userList[i]);
            let userInfo = {};
            let name = '';
            let roleInfo = yield Role.findOne({ _id: userList[i].role_id, is_deleted: false, status: true }).exec();
            console.log("roleInfo-->", roleInfo);
            if (roleInfo.name == 'Patient') {
                userInfo = yield Patient.findOne({ is_deleted: false, user_id: userList[i]._id }, { 'first_name': true, 'last_name': true }).lean();
                console.log(" Patient userInfo-->", userInfo);
                if (userInfo) {
                    userInfo.first_name = decrypt(userInfo.first_name);
                    userInfo.last_name = decrypt(userInfo.last_name);
                    name = userInfo.first_name + "  " + userInfo.last_name;
                }
            }
            else if (roleInfo.name == 'Hospital') {
                userInfo = yield Hospital.findOne({ user_id: userList[i]._id }, { 'hospital_name': true }).lean();
                console.log(" Hospital userInfo-->", userInfo);
                if (userInfo) {
                    name = userInfo.hospital_name;
                }
            }
            else if (roleInfo.name == 'Clinician') {
                userInfo = yield Clinician.findOne({ user_id: userList[i]._id }, { 'last_name': true, 'first_name': true }).lean();
                console.log(" Clinician userInfo-->", userInfo);
                if (userInfo) {
                    name = userInfo.first_name + "  " + userInfo.last_name;
                }
            }
            else if (roleInfo.name == 'CareCoordinator') {
                userInfo = yield CareCoordinator.findOne({ user_id: userList[i]._id }, { 'last_name': true, 'first_name': true }).lean();
                console.log(" CareCoordinator userInfo-->", userInfo);
                if (userInfo) {
                    name = userInfo.first_name + "  " + userInfo.last_name;
                }
            }
            else if (roleInfo.name == 'Ambulance') {
                userInfo = yield Ambulance.findOne({ user_id: userList[i]._id }, { 'company_name': true }).lean();
                console.log(" Ambulance userInfo-->", userInfo);
                if (userInfo) {
                    name = userInfo.company_name;
                }
            }
            else if (roleInfo.name == 'Towing') {
                userInfo = yield Towing.findOne({ user_id: userList[i]._id }, { 'company_name': true }).lean();
                console.log(" Towing userInfo-->", userInfo);
                if (userInfo) {
                    name = userInfo.company_name;
                }
            }
            userList[i].name = name;
            console.log("userList[i]", userList[i]);
        }
        console.log("after userList-->", userList);
        return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": userList });
    }).catch(function (err) {
        console.log("getVisitById Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}

function getAllAllignedUsers(req, res) {
    console.log("in getAllAllignedUsers list");
    co(function* () {
        let userList = yield User.find({}).lean().exec();
        for (var i = 0; i < userList.length; i++) {
            console.log("userList[i]-->", userList[i]);
            let userInfo = {};
            let name = '';
            let mobileNo = '';
            let roleInfo = yield Role.findOne({ _id: userList[i].role_id, is_deleted: false, status: true }).exec();
            console.log("roleInfo-->", roleInfo);
            if (roleInfo.name == 'Patient') {
                userInfo = yield Patient.findOne({ is_deleted: false, user_id: userList[i]._id }, { 'first_name': true, 'last_name': true, 'mobile_no': true }).lean();
                console.log(" Patient userInfo-->", userInfo);
                if (userInfo) {
                    userInfo.first_name = decrypt(userInfo.first_name);
                    userInfo.last_name = decrypt(userInfo.last_name);
                    mobileNo = decrypt(userInfo.mobile_no);
                    name = userInfo.first_name + "  " + userInfo.last_name;
                }
            }
            else if (roleInfo.name == 'Hospital') {
                userInfo = yield Hospital.findOne({ user_id: userList[i]._id }, { 'hospital_name': true, 'hospital_mobile_no': true }).lean();
                console.log(" Hospital userInfo-->", userInfo);
                if (userInfo) {
                    name = userInfo.hospital_name;
                    mobileNo = userInfo.hospital_mobile_no;
                }
            }
            else if (roleInfo.name == 'Clinician') {
                userInfo = yield Clinician.findOne({ user_id: userList[i]._id }, { 'last_name': true, 'first_name': true, 'mobile_no': true }).lean();
                console.log(" Clinician userInfo-->", userInfo);
                if (userInfo) {
                    name = userInfo.first_name + "  " + userInfo.last_name;
                    mobileNo = userInfo.mobile_no;
                }
            }
            else if (roleInfo.name == 'CareCoordinator') {
                userInfo = yield CareCoordinator.findOne({ user_id: userList[i]._id }, { 'last_name': true, 'first_name': true, 'mobile_no': true }).lean();
                console.log(" CareCoordinator userInfo-->", userInfo);
                if (userInfo) {
                    name = userInfo.first_name + "  " + userInfo.last_name;
                    mobileNo = userInfo.mobile_no;
                }
            }
            else if (roleInfo.name == 'Ambulance') {
                userInfo = yield Ambulance.findOne({ user_id: userList[i]._id }, { 'company_name': true, 'mobile_no': true }).lean();
                console.log(" Ambulance userInfo-->", userInfo);
                if (userInfo) {
                    name = userInfo.company_name;
                    mobileNo = userInfo.mobile_no;
                }
            }
            else if (roleInfo.name == 'Towing') {
                userInfo = yield Towing.findOne({ user_id: userList[i]._id }, { 'company_name': true, 'mobile_no': true }).lean();
                console.log(" Towing userInfo-->", userInfo);
                if (userInfo) {
                    name = userInfo.company_name;
                    mobileNo = userInfo.mobile_no;
                }
            }
            userList[i].name = name;
            userList[i].mobileNo = mobileNo;
            console.log("userList[i]", userList[i]);
        }
        console.log("after userList-->", userList);
        return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": userList });
    }).catch(function (err) {
        console.log("getAllAllignedUsers Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}

// function getAllAllignedUsers(req, res) {
//     console.log("  getAllAllignedUsers---------req.body.patientId----------->", '5a71b378b55ee2629c6c2082');
//     co(function* () {
//         var count = parseInt(req.body.count ? req.body.count : 0);
//         var skip = parseInt(req.body.count * (req.body.page - 1));
//         var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
//         var condition = { patient_id: '5a71b378b55ee2629c6c2082' };
//         // {patient_id: req.body.patientId}  is_deleted: false,
//         for (var key in req.body) {
//             var reg = new RegExp("sorting", 'gi');
//             if (reg.test(key)) {
//                 var value = req.body[key];
//                 key = key.replace(/sorting/g, '').replace(/\[/g, '').replace(/\]/g, '');
//                 var sorting = {};
//                 if (value == 1 || value == -1) {
//                     sorting[key] = value;
//                 } else {
//                     sorting[key] = (value == 'desc') ? -1 : 1;
//                 }
//             }
//         }
//         var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
//         if (req.body.searchText) {
//             condition.$or = [{ 'first_name': new RegExp(searchText, 'gi') }, { 'last_name': new RegExp(searchText, 'gi') }, { 'clinician_npi_no': new RegExp(searchText, 'gi') }, { 'SSN': new RegExp(searchText, 'gi') }, { 'mobile_no': new RegExp(searchText, 'gi') }, { 'hospitalInfo.hospital_name': new RegExp(searchText, 'gi') }];
//         }
//         let aggregate = [{
//                 $lookup: {
//                     from: 'roles',
//                     localField: "role_id",
//                     foreignField: "_id",
//                     as: "roleInfo"
//                 }
//             },
//             { $unwind: { path: "$roleInfo" } },
//             {
//                 $lookup: {
//                     from: 'clinicians',
//                     localField: "assign_id",
//                     foreignField: "_id",
//                     as: "clinicianInfo"
//                 }
//             },
//             { $unwind: { path: "$userInfo" } },
//             {
//                 $lookup: {
//                     from: 'carecoordinators',
//                     localField: "assign_id",
//                     foreignField: "_id",
//                     as: "carecoordinatorsInfo"
//                 }
//             },
//             { $unwind: { path: "$carecoordinatorsInfo" } },


//         ];
//          // { $match: condition },

//         console.log("aggregate--->", aggregate);
//         let assignedUserListData = yield HospitalAssign.aggregate(aggregate);
//         console.log("assignedUserListData--->", assignedUserListData);
//         // var aggregateCnt = [].concat(aggregate);
//         // if (req.body.count && req.body.page) {
//         //     console.log("----------in req.bosdy-------------");
//         //     aggregate.push({ $sort: sorting });
//         //     aggregate.push({ $skip: skip });
//         //     aggregate.push({ $limit: count });
//         // }
//       //  console.log("smsHistoryData-->", smsHistoryData);
//       //  aggregateCnt.push({ $group: { _id: null, count: { $sum: 1 } } });
//       //  let smsHistoryCount = yield HospitalAssign.aggregate(aggregateCnt);
//       //  return res.json({ code: 200, message: 'Data retrieved successfully', data: smsHistoryData, totalCount: ((smsHistoryCount[0]) ? smsHistoryCount[0].count : 0) });
//        // return res.json({ 'code': 200, status: 'success', "message": constant.messages.dataRetrievedSuccess, "data": assignedUserList });
//     }).catch(function (err) {
//         console.log("getAllAllignedUsers Err---->", err);
//         return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
//     });
// }