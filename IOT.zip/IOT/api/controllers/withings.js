'use strict';

//var Withings = require('withings-lib'),
var Withings = require('../lib/withings.js'),
    config = require('../../config/config.js'),
    mongoose = require('mongoose'),
    Roles = mongoose.model('Role'),
    User = mongoose.model('User'),
    Rule = mongoose.model('Rule'),
    Patient = mongoose.model('Patient'),
    PatientActivity = mongoose.model('PatientActivity'),
    co = require('co'),
    utility = require('../lib/utility.js'),
    async = require('async'),
    constantsObj = require('../lib/constants'),
    PatientDeviceConfig = mongoose.model('PatientDeviceConfig');
var moment = require('moment');

module.exports = {
    authRequest: authRequest,
    oauth_callback: oauth_callback,
    activity_steps: activity_steps,
    DailySteps: DailySteps,
    createNotify: createNotify,
    notifyScaleActivity: notifyScaleActivity,
    notifyBpActivity: notifyBpActivity,
    notifyBodyActivity: notifyBodyActivity,
    notifySleepActivity: notifySleepActivity,
    getNotificationlist: getNotificationlist,
    /*SleepSummary:SleepSummary,
    PulseMeasures:PulseMeasures,
    WeightMeasures:WeightMeasures,
    DailyCalories:DailyCalories,
    Steps:Steps,
    Calories:Calories,*/
};

/**
 * [createfcst - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function createNotify(req, res) {
    var baseUrl = req.protocol + '://' + req.get('host');
    console.log(req.user.id);
    Patient.findOne({ user_id: req.user.id }).exec(function(err, patient) {
        if (err) {
            res.json({
                code: config.httpUnauthorize,
                message: err
            });
        } else {
            var patientId = patient._id;
            PatientDeviceConfig.findOne({ device_id: req.query.deviceId, patient_id: patientId }).exec(function(err, patientDevConf) {
                if (err) {
                    res.json({
                        code: config.httpUnauthorize,
                        message: err
                    });
                } else if (patientDevConf) {
                    var options = {
                        consumerKey: config.CONSUMER_KEY,
                        consumerSecret: config.CONSUMER_SECRET,
                        accessToken: patientDevConf.accessToken,
                        accessTokenSecret: patientDevConf.accessTokenSecret,
                        userID: patientDevConf.withing_user_id
                    };
                    /***create notification***/
                    var callbackNotify = encodeURIComponent(baseUrl + '/notifyScaleActivity');
                    var comment = 'Notify when new Body Scale records change';
                    var client = new Withings(options);
                    client.createNotification(callbackNotify, comment, 1, function(err, data) {});
                    /******/
                }
            })

        }
    });
}

/**
 * [getNotificationlist - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function getNotificationlist(req, res) {
    var baseUrl = req.protocol + '://' + req.get('host');
    Patient.findOne({ user_id: req.user.id }).exec(function(err, patient) {
        if (err) {
            res.json({
                code: config.httpUnauthorize,
                message: err
            });
        } else {
            var patientId = patient._id;
            // PatientDeviceConfig.findOne({ device_id: '5a092a7b92d7ce2a9e1606a1', patient_id: patientId }).exec(function(err, patientDevConf) {
            PatientDeviceConfig.findOne({ device_id: req.query.deviceId, patient_id: patientId }).exec(function(err, patientDevConf) {
                if (err) {
                    res.json({
                        code: config.httpUnauthorize,
                        message: err
                    });
                } else if (patientDevConf) {
                    var options = {
                        consumerKey: config.CONSUMER_KEY,
                        consumerSecret: config.CONSUMER_SECRET,
                        accessToken: patientDevConf.accessToken,
                        accessTokenSecret: patientDevConf.accessTokenSecret,
                        userID: patientDevConf.withing_user_id
                    };
                    /***create notification***/

                    var client = new Withings(options);
                    client.listNotifications(1, function(err, data) {
                        console.log('1', data);
                    });
                    client.listNotifications(4, function(err, data) {
                        console.log('4', data);
                    });
                    client.listNotifications(16, function(err, data) {
                        console.log('16', data);
                    });
                    client.listNotifications(44, function(err, data) {
                        console.log('44', data);
                    });
                    /******/
                }
            })

        }
    });
}

function syncRealData(req, res, options, option2) {
    var startDate = option2.startdate;
    var endDate = option2.enddate;
    var patient_id = option2.patient_id;
    var device_id = option2.device_id;
    var client = new Withings(options);
    client.ActivityMeasures(startDate, endDate, function(err, data) {
        if (err) {
            res.send(err);
        }

        async.each(data, function(activity, callback) {
            var d = new Date(0);
            var postData = {
                    'patient_id': patient_id,
                    'device_id': device_id,
                    'grpid': activity.grpid,
                    'attrib': activity.attrib,
                    'category': activity.category,
                    'measures_date': d.setUTCSeconds(activity.date),
                    'measures': activity.measures
                }
                //save data
            var patientObj = {};
            var field = ['patient_id', 'device_id', 'measures_date'];
            utility.encryptedRecord(postData, field, function(activityObj) {
                var patientActivity = new PatientActivity(activityObj);
                patientActivity.save(function(err, activity) {
                    if (err) {
                        console.log(err)
                    } else {
                        console.log('realtime success')
                    }
                });
            })
            callback();
        }, function(err) {
            if (err) {
                console.log('async error in realtime');
            } else {
                console.log('async success in realtime');
            }
        });
        //res.json(data);
    });
}
/**
 * [notifyScaleActivity - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function notifyScaleActivity(req, res) {
    if (req.body) {
        var withUserId = req.body.userid;
        var startdate = req.body.startdate;
        var enddate = req.body.enddate;
        PatientDeviceConfig.findOne({ withing_user_id: withUserId }).exec(function(err, patientDevConf) {
            if (err) {
                res.json({
                    code: config.httpUnauthorize,
                    message: err
                });
            } else if (patientDevConf) {
                var options = {
                    consumerKey: config.CONSUMER_KEY,
                    consumerSecret: config.CONSUMER_SECRET,
                    accessToken: patientDevConf.accessToken,
                    accessTokenSecret: patientDevConf.accessTokenSecret,
                    userID: patientDevConf.withing_user_id
                };
                //code will be here
                var option2 = {
                    startdate: startdate,
                    enddate: enddate,
                    patient_id: patientDevConf.patient_id,
                    device_id: patientDevConf.device_id
                }
                syncRealData(req, res, options, option2);
            }
        })
    }
    ///********/
    console.log('This is about ScaleActivity notification');
    console.log('req.query', req.query);
    console.log('req.body', req.body);
    res.json({
        code: 200,
        message: 'This is about ScaleActivity notification',
    });
    /**********/
}

/**
 * [notifyBpActivity - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function notifyBpActivity(req, res) {
    if (req.body) {
        var withUserId = req.body.userid;
        var startdate = req.body.startdate;
        var enddate = req.body.enddate;
        PatientDeviceConfig.findOne({ withing_user_id: withUserId }).exec(function(err, patientDevConf) {
            if (err) {
                res.json({
                    code: config.httpUnauthorize,
                    message: err
                });
            } else if (patientDevConf) {
                var options = {
                    consumerKey: config.CONSUMER_KEY,
                    consumerSecret: config.CONSUMER_SECRET,
                    accessToken: patientDevConf.accessToken,
                    accessTokenSecret: patientDevConf.accessTokenSecret,
                    userID: patientDevConf.withing_user_id
                };
                //code will be here
                var option2 = {
                    startdate: startdate,
                    enddate: enddate,
                    patient_id: patientDevConf.patient_id,
                    device_id: patientDevConf.device_id
                }
                syncRealData(req, res, options, option2);
            }
        })
    }
    console.log('This is about blood pressure Activity notification');
    console.log('req.query', req.query);
    console.log('req.query', req.body);
    res.json({
        code: 200,
        message: 'This is about blood pressure Activity notification',
    });
}

/**
 * [notifyBodyActivity - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function notifyBodyActivity(req, res) {
    if (req.body) {
        var withUserId = req.body.userid;
        var startdate = req.body.startdate;
        var enddate = req.body.enddate;
        PatientDeviceConfig.findOne({ withing_user_id: withUserId }).exec(function(err, patientDevConf) {
            if (err) {
                res.json({
                    code: config.httpUnauthorize,
                    message: err
                });
            } else if (patientDevConf) {
                var options = {
                    consumerKey: config.CONSUMER_KEY,
                    consumerSecret: config.CONSUMER_SECRET,
                    accessToken: patientDevConf.accessToken,
                    accessTokenSecret: patientDevConf.accessTokenSecret,
                    userID: patientDevConf.withing_user_id
                };
                //code will be here
                var option2 = {
                    startdate: startdate,
                    enddate: enddate,
                    patient_id: patientDevConf.patient_id,
                    device_id: patientDevConf.device_id
                }
                syncRealData(req, res, options, option2);
            }
        })
    }
    console.log('This is about activity measures notification');
    console.log('req.query', req.query);
    console.log('req.query', req.body);
    res.json({
        code: 200,
        message: 'This is about activity measures notification',
    });
}

/**
 * [notifyBodyActivity - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function notifySleepActivity(req, res) {
    if (req.body) {
        var withUserId = req.body.userid;
        var startdate = req.body.startdate;
        var enddate = req.body.enddate;
        PatientDeviceConfig.findOne({ withing_user_id: withUserId }).exec(function(err, patientDevConf) {
            if (err) {
                res.json({
                    code: config.httpUnauthorize,
                    message: err
                });
            } else if (patientDevConf) {
                var options = {
                    consumerKey: config.CONSUMER_KEY,
                    consumerSecret: config.CONSUMER_SECRET,
                    accessToken: patientDevConf.accessToken,
                    accessTokenSecret: patientDevConf.accessTokenSecret,
                    userID: patientDevConf.withing_user_id
                };
                //code will be here
                var option2 = {
                    startdate: startdate,
                    enddate: enddate,
                    patient_id: patientDevConf.patient_id,
                    device_id: patientDevConf.device_id
                }
                syncRealData(req, res, options, option2);
            }
        })
    }
    console.log('This is about sleep activity measures notification');
    console.log('req.query', req.query);
    console.log('req.query', req.body);
    res.json({
        code: 200,
        message: 'This is about sleep activity measures notification',
    });
}
/**
 * [createfcst - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function authRequest(req, res) {
    console.log('req.query',req.query.deviceId);
    console.log(req.user.id);
    var baseUrl = req.protocol + '://' + req.get('host');
    var callbackUrl = baseUrl + config.CALLBACK_URL;
    console.log('baseUrl', baseUrl);
    console.log("callbackUrl",callbackUrl);
    if (req.query.deviceId && req.user.id) {
        Patient.findOne({ user_id: req.user.id }).exec(function(err, patient) {
            if (err) {
                res.json({
                    code: config.httpUnauthorize,
                    message: err
                });
            } else {
                var patientId = patient._id;
                req.session.oauth = {
                    'patientId': patientId,
                    'deviceId': req.query.deviceId
                };
                PatientDeviceConfig.findOne({ device_id: req.query.deviceId, patient_id: patientId }).exec(function(err, patientDevConf) {
                    console.log("patientDevConf",err,patientDevConf);
                    if (err) {
                        res.json({
                            code: config.httpUnauthorize,
                            message: err
                        });
                    } else if (patientDevConf) {
                        console.log("patientDevConf44",err,patientDevConf);
                        var options = {
                            consumerKey: config.CONSUMER_KEY,
                            consumerSecret: config.CONSUMER_SECRET,
                            accessToken: patientDevConf.accessToken,
                            accessTokenSecret: patientDevConf.accessTokenSecret,
                            userID: patientDevConf.withing_user_id
                        };
                        var redirect = false;
                        syncwithing(req, res, options, redirect, patientDevConf._id);

                    } else {
                        var options = {
                            consumerKey: config.CONSUMER_KEY,
                            consumerSecret: config.CONSUMER_SECRET,
                            callbackUrl: callbackUrl
                        };
                        var client = new Withings(options);
                        console.log("options 11",options);
                        client.getRequestToken(function(err, token, tokenSecret) {
                            console.log("getRequestToken------------withing--33------->>>>",err,token,tokenSecret);

                            if (err) {
                                // Throw error
                                return;
                            }
                            req.session.oauth = {
                                'requestToken': token,
                                'requestTokenSecret': tokenSecret,
                                'patientId': patientId,
                                'deviceId': req.query.deviceId
                            };
                             console.log("req.session 11",req.session);
                            res.json({
                                code: config.httpSuccess,
                                url: client.authorizeUrl(token, tokenSecret),
                            });

                            //res.redirect(client.authorizeUrl(token, tokenSecret));
                        });
                    }
                });
            }
        })
    } else {
        res.json({
            code: config.httpUnauthorize,
            message: 'Invalid request, Please try again later.',
        });
    }
}

/**
 * [createfcst - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function oauth_callback(req, res) {
    console.log('req.query', req.query);
    var baseUrl = req.protocol + '://' + req.get('host');
    var callbackUrl = baseUrl + config.CALLBACK_URL;
    var verifier = req.query.oauth_verifier
    var oauthSettings = req.session.oauth
    var options = {
        consumerKey: config.CONSUMER_KEY,
        consumerSecret: config.CONSUMER_SECRET,
        callbackUrl: callbackUrl,
        userID: req.query.userid
    };
    var client = new Withings(options);
    // Request an access token
    client.getAccessToken(oauthSettings.requestToken, oauthSettings.requestTokenSecret, verifier,
        function(err, token, secret) {
            console.log("xxxxxxxxxxxxxxxxxxxxxx",token,secret);
            if (err) {
                //error
                /*res.json({
                    code: config.httpUnauthorize,
                    message: err,
                });*/
                res.redirect('/#!/deviceList');
            }
            var postData = {
                'accessToken': token,
                'accessTokenSecret': secret,
                'withing_user_id': req.query.userid,
                'patient_id': oauthSettings.patientId,
                'device_id': oauthSettings.deviceId
            }
            PatientDeviceConfig.findOneAndUpdate({ patient_id: oauthSettings.patientId, device_id: oauthSettings.deviceId }, {
                $set: postData
            }, { upsert: true, new: true }, function(err, data) {
                if (err) {
                    res.redirect('/#!/deviceList');
                } else {
                    console.log(err, data);
                    var options = {
                        consumerKey: config.CONSUMER_KEY,
                        consumerSecret: config.CONSUMER_SECRET,
                        accessToken: token,
                        accessTokenSecret: secret,
                        userID: req.query.userid
                    };
                    //***Create notification****//
                    var client = new Withings(options);
                    /////Body Scale
                    //var callbackNotify = encodeURI(baseUrl + '/api/v1/notifyScaleActivity');
                    var callbackNotify = baseUrl + '/notifyScaleActivity';
                    console.log('callbackNotify url', callbackNotify);
                    var comment = 'Notify when body scale records change';
                    client.createNotification(callbackNotify, comment, 1, function(err, data) {
                        console.log('notifyScaleActivity', data, err);
                    });
                    /////BP monitor
                    //var callbackNotify = encodeURI(baseUrl + '/notifyBpActivity');
                    var callbackNotify = baseUrl + '/notifyBpActivity';
                    var comment = 'Notify when blood pressure records change';
                    client.createNotification(callbackNotify, comment, 4, function(err, data) {
                        console.log('notifyBpActivity', data, err);
                    });
                    /////Activity Measure
                    //var callbackNotify = encodeURIComponent(baseUrl + '/notifyBodyActivity');
                    var callbackNotify = baseUrl + '/notifyBodyActivity';
                    var comment = 'Notify when body activity records change';
                    client.createNotification(callbackNotify, comment, 16, function(err, data) {
                        console.log('notifyBodyActivity', data, err);
                    });
                    /////Sleep monitor
                    //var callbackNotify = encodeURIComponent(baseUrl + '/api/v1/notifySleepActivity');
                    var callbackNotify = baseUrl + '/notifySleepActivity';
                    var comment = 'Notify sleep records change';
                    client.createNotification(callbackNotify, comment, 44, function(err, data) {
                        console.log('notifySleepActivity', data, err);
                    });
                    //***End create notification***//
                    var redirect = true;
                    syncwithing(req, res, options, redirect, data._id);
                }
            })
        }
    );
}

/**
 * [syncwithing - create syncwithing]
 * Created By Rahul
 * Created Date 28-Nov-2017
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function syncwithing(req, res, options, redirect, devId) {
    console.log("req, res, options, redirect, devId------>>>", req, res, options, redirect, devId);
    var oauthSettings = req.session.oauth
    var client = new Withings(options);
    PatientDeviceConfig.findOne({ _id: devId }).exec(function(err, patientDevConf) {
        if (err) {
            res.json({
                code: config.httpUnauthorize,
                message: err
            });
        } else {
            if (patientDevConf.last_sync) {
                console.log("patientDevConf.last_sync------------------>>>>>>",patientDevConf.last_sync);
                var today = moment().format('YYYY-MM-DD');
                if (patientDevConf.last_sync == today) {
                    res.json({
                        code: config.httpSuccess,
                        message: 'Records already synctronised.'
                    });
                    return false;
                } else {
                    var startDate = moment(patientDevConf.last_sync).add(1, 'day').format('YYYY-MM-DD');
                }
            } else {
                var startDate = '0';
            }
            var endDate = moment().format('YYYY-MM-DD');
            /*client.ActivityMeasures('2017-01-01','2017-06-11', function(err, data) {*/

            client.ActivityMeasures(startDate, endDate, function(err, data) {
                if (err) {
                    res.send(err);
                }
                async.each(data, function(activity, callback) {
                    var d = new Date(0);
                    var postData = {
                        'patient_id': oauthSettings.patientId,
                        'device_id': oauthSettings.deviceId,
                        'grpid': activity.grpid,
                        'attrib': activity.attrib,
                        'category': activity.category,
                        'measures_date': d.setUTCSeconds(activity.date),
                        'measures': activity.measures
                    }

                    // Rule.findOne({ is_deleted: false }).lean().exec(function(ruleErr, ruleData) {
                    //     if (ruleErr) {
                    //         res.json({
                    //             code: 402,
                    //             message: 'Data not found'
                    //         });
                    //     } else {
                    //         console.log("ruleData", ruleData);
                    //         res.json({
                    //             code: 200,
                    //             data: ruleData
                    //         });
                    //     }
                    // });

                    //save data
                    var patientObj = {};
                    var field = ['patient_id', 'device_id', 'measures_date'];
                    utility.encryptedRecord(postData, field, function(activityObj) {
                        var patientActivity = new PatientActivity(activityObj);
                        patientActivity.save(function(err, activity) {

                            if (err) {
                                console.log(err)
                            } else {
                                console.log('success')
                            }
                        });
                    })
                    callback();
                }, function(err) {
                    if (err) {
                        if (redirect) {
                            res.redirect('/#!/deviceList');
                        } else {
                            res.json({
                                code: config.httpUnauthorize,
                                message: 'Something went wrong, please try again later..'
                            });
                        }
                    } else {
                        PatientDeviceConfig.findOneAndUpdate({ _id: devId }, {
                            $set: { last_sync: endDate }
                        }, { new: true }, function(err, data) {
                            if (err) {
                                res.json({
                                    code: config.httpUnauthorize,
                                    message: 'Something went wrong, please try again later..'
                                });
                            } else {
                                if (redirect) {
                                    res.redirect('/#!/deviceList');
                                } else {
                                    res.json({
                                        code: config.httpSuccess,
                                        message: 'Withings records synctronised successfully.'
                                    });
                                }
                            }
                        })
                    }
                });
                //res.json(data);
            });
        }
    });
}
/**
 * [createfcst - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function DailySteps(req, res) {
    //console.log('req.query',req.query.deviceId);
    //console.log(req.user.id);
    if (req.query.deviceId && req.user.id) {
        Patient.findOne({ user_id: req.user.id }).exec(function(err, patient) {
            if (err) {
                res.json({
                    code: config.httpUnauthorize,
                    message: err
                });
            } else {
                var patientId = patient._id;
                req.session.oauth = {
                    'patientId': patientId,
                    'deviceId': req.query.deviceId
                };
                PatientDeviceConfig.findOne({ device_id: req.query.deviceId, patient_id: patientId }).exec(function(err, patientDevConf) {
                    if (patientDevConf) {
                        var options = {
                            consumerKey: config.CONSUMER_KEY,
                            consumerSecret: config.CONSUMER_SECRET,
                            accessToken: patientDevConf.accessToken,
                            accessTokenSecret: patientDevConf.accessTokenSecret,
                            userID: patientDevConf.withing_user_id
                        };
                        var client = new Withings(options);
                        //var today = moment('2017-06-13').format('YYYY-MM-DD');
                        var today = moment().format('YYYY-MM-DD');
                        client.getDailySteps(today, function(err, data) { //working
                            console.log('cntrl', data);
                            if (err) {
                                res.send(err);
                            }
                            res.json({
                                code: config.httpSuccess,
                                data: data
                            });
                        });
                    }
                });
            }
        })
    } else {
        res.json({
            code: config.httpUnauthorize,
            message: 'Something went wrong, please try again later.'
        });
    }
    /*var options = {
        consumerKey: config.CONSUMER_KEY,
        consumerSecret: config.CONSUMER_SECRET,
        accessToken: req.session.oauth.accessToken,
        accessTokenSecret: req.session.oauth.accessTokenSecret,
        //userID: req.query.userid
        userID: req.session.oauth.userid
    };
    console.log('options',options);
    var client = new Withings(options);
    client.getDailySteps('2017-06-02', function(err, data) { //working
        console.log('cntrl',data);
        if (err) {
            res.send(err);    
        }
        res.json(data);
    });*/
}
/**
 * [createfcst - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function Steps(req, res) {
    var options = {
        consumerKey: config.CONSUMER_KEY,
        consumerSecret: config.CONSUMER_SECRET,
        accessToken: req.session.oauth.accessToken,
        accessTokenSecret: req.session.oauth.accessTokenSecret,
        //userID: req.query.userid
        userID: req.session.oauth.userid
    };
    //console.log('options',options);
    var client = new Withings(options);
    client.getSteps('2017-05-29', '2017-06-01', function(err, data) { //working
        console.log('cntrl', data);
        if (err) {
            res.send(err);
        }
        res.json(data);
    });
}
/**
 * [createfcst - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function DailyCalories(req, res) {
    var options = {
        consumerKey: config.CONSUMER_KEY,
        consumerSecret: config.CONSUMER_SECRET,
        accessToken: req.session.oauth.accessToken,
        accessTokenSecret: req.session.oauth.accessTokenSecret,
        //userID: req.query.userid
        userID: req.session.oauth.userid
    };
    console.log('options', options);
    var client = new Withings(options);
    client.getDailyCalories('2017-06-01', function(err, data) { //working
        if (err) {
            res.send(err);
        }
        res.json(data);
    });
}
/**
 * [createfcst - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function Calories(req, res) {
    var options = {
        consumerKey: config.CONSUMER_KEY,
        consumerSecret: config.CONSUMER_SECRET,
        accessToken: req.session.oauth.accessToken,
        accessTokenSecret: req.session.oauth.accessTokenSecret,
        //userID: req.query.userid
        userID: req.session.oauth.userid
    };
    //console.log('options',options);
    var client = new Withings(options);
    client.getCalories('2017-05-29', '2017-06-01', function(err, data) { //working
        if (err) {
            res.send(err);
        }
        res.json(data);
    });
}
/**
 * [createfcst - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function activity_steps(req, res) {
    var options = {
        consumerKey: config.CONSUMER_KEY,
        consumerSecret: config.CONSUMER_SECRET,
        accessToken: req.session.oauth.accessToken,
        accessTokenSecret: req.session.oauth.accessTokenSecret,
        //userID: req.query.userid
        userID: req.session.oauth.userid
    };
    //console.log('options',options);
    var client = new Withings(options);
    client.getSleepSummary('2017-01-01', '2017-06-02', function(err, data) { //working
        //client.getPulseMeasures('2017-01-01','2017-06-02', function(err, data) { //working
        //client.getWeightMeasures('2017-01-01','2017-06-02', function(err, data) { // working
        if (err) {
            res.send(err);
        }
        res.json(data);
    });
}

/**
 * [createfcst - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function SleepSummary(req, res) {
    var options = {
        consumerKey: config.CONSUMER_KEY,
        consumerSecret: config.CONSUMER_SECRET,
        accessToken: req.session.oauth.accessToken,
        accessTokenSecret: req.session.oauth.accessTokenSecret,
        //userID: req.query.userid
        userID: req.session.oauth.userid
    };
    //console.log('options',options);
    var client = new Withings(options);
    client.getSleepSummary('2017-01-01', '2017-06-02', function(err, data) { //working
        if (err) {
            res.send(err);
        }
        res.json(data);
    });
}
/**
 * [createfcst - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function PulseMeasures(req, res) {
    var options = {
        consumerKey: config.CONSUMER_KEY,
        consumerSecret: config.CONSUMER_SECRET,
        accessToken: req.session.oauth.accessToken,
        accessTokenSecret: req.session.oauth.accessTokenSecret,
        //userID: req.query.userid
        userID: req.session.oauth.userid
    };
    //console.log('options',options);
    var client = new Withings(options);
    //client.getSleepSummary('2017-01-01','2017-06-02', function(err, data) { //working
    client.getPulseMeasures('2017-01-01', '2017-06-02', function(err, data) { //working
        if (err) {
            res.send(err);
        }
        res.json(data);
    });
}
/**
 * [createfcst - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function WeightMeasures(req, res) {
    var options = {
        consumerKey: config.CONSUMER_KEY,
        consumerSecret: config.CONSUMER_SECRET,
        accessToken: req.session.oauth.accessToken,
        accessTokenSecret: req.session.oauth.accessTokenSecret,
        //userID: req.query.userid
        userID: req.session.oauth.userid
    };
    //console.log('options',options);
    var client = new Withings(options);
    client.getWeightMeasures('2017-01-01', '2017-06-02', function(err, data) { // working
        if (err) {
            res.send(err);
        }
        res.json(data);
    });
}
