'use strict';

var mongoose = require('mongoose'),
    co = require('co'),
    utility = require('../lib/utility.js'),
    async = require('async'),
    constantsObj = require('../lib/constants'),
    User = mongoose.model('User'),
    async = require('async'),
    common = require('../../config/common.js'),
    path = require('path'),
    fs = require('fs'),
    AssesmentQuestion = mongoose.model('AssesmentQuestion'),
    Patient = mongoose.model('Patient'),
    AssesQuestionFile = mongoose.model('AssesQuestionFile'),
    AssignQuestions = mongoose.model('AssignQuestions'),
    PatientAssessment = mongoose.model('PatientAssessment'),
    AssesmentQuestionOption = mongoose.model('AssesmentQuestionOption');
    
module.exports = {
    addAssesmentQuestion: addAssesmentQuestion,
    getAssesmentQuestions: getAssesmentQuestions,
    addAssesmentQuestionOptions:addAssesmentQuestionOptions,
    getAssesmentQuestionsOptions:getAssesmentQuestionsOptions,
    addSelfAssessmentQuestion:addSelfAssessmentQuestion,
    questionFileUpload:questionFileUpload,
    deleteQuestionById:deleteQuestionById,
    getAssesQuestionFile:getAssesQuestionFile,
    viewFileById:viewFileById,
    deleteFileById:deleteFileById,
    getQuestionsForAssign:getQuestionsForAssign,
    assignQuestions:assignQuestions,
    getAssesmentQuestionsById:getAssesmentQuestionsById,
    getQuestionsForAssignOnEdit:getQuestionsForAssignOnEdit,
    checkQuestionsEditable:checkQuestionsEditable
}

/**
 * Function is use to Add Assesment Question 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 16-June-2017
 */ 
function addAssesmentQuestion(req, res) {
    co(function* () {
        let userData = yield User.findById(req.user.id);
        if (userData) {
            let assesmentQuestionData = yield AssesmentQuestion.findById(req.body._id);
            if (assesmentQuestionData) {
                assesmentQuestionData.question = req.body.question;
                assesmentQuestionData.question_type = req.body.question_type;
                let savedAssesmentData = yield assesmentQuestionData.save();
                res.json({code:200,message:constantsObj.messages.AssesmentQuestionUpdatedSuccess,data:savedAssesmentData});
            }
            else {
                let savedAssesmentData = yield new AssesmentQuestion(req.body).save();
                res.json({code:200,message:constantsObj.messages.AssesmentQuestionAddedSuccess,data:savedAssesmentData});
            }
            
        } else {
            return res.json(Response(402, "failed", constantsObj.messages.UserNotFound, err));
        }
    }).catch(function (err) {
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), err));
    });
}
/**
 * Function is use to Get Assesment Questions  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 16-June-2017
 */
function getAssesmentQuestions(req, res) {
  AssesmentQuestion.find({is_deleted:false}).lean().exec(function (err, question) {
    if (err) {
      res.json({
        code: 404,
        message: utility.validationErrorHandler(err)
      });
    } else if (question) {
          res.json({
                code: 200,
                message: constantsObj.messages.AssesmentQuestionGettingSuccess,
                data: question
          })
         
      }else {
          res.json({
          code: 404,
          message: constantsObj.messages.noDataFound
          })
      }

  }).catch(function (err) {
     return res.json(Response(402,utility.validationErrorHandler(err), err));
  })
}

/**
 * Function is use to Add Assesment Question Options
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 17-June-2017
 */
function addAssesmentQuestionOptions(req, res) {
    co(function*() {
                var assesmentQuestionOption = new AssesmentQuestionOption(req.body);
                assesmentQuestionOption.save(function (err, questionOption) {
                if (err) {
                  res.json({
                  code: 404,
                  message: utility.validationErrorHandler(err)
                });
                } else {
                    AssesmentQuestion.findById(questionOption.question_id).lean().exec(function(err,questionData){
                      if(err){
                         res.json({
                          code: 404,
                          message: utility.validationErrorHandler(err)
                        });
                      }
                      else if(questionData){
                        AssesmentQuestion.update({_id:questionOption.question_id},{$push:{options_id:questionOption._id}},function(err,details){
                            if(err){
                              res.json({
                              code: 404,
                              message: utility.validationErrorHandler(err)
                              });
                            }else{
                              res.json({
                              code: 200,
                              message: constantsObj.messages.QuestionOptionsAddedSuccess,
                              data: questionOption
                              });
                            }
                        })
                       }
                    });
                  }
                });
        }).catch(function(err) {
        return res.json(Response(402,utility.validationErrorHandler(err), err));
        });
}

/**
 * Function is use to Get Assesment Questions Options 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 16-June-2017
 */
function getAssesmentQuestionsOptions(req, res) {
  AssesmentQuestionOption.find({}).populate('question_id').lean().exec(function (err, questionOption) {
    if (err) {
      res.json({
        code: 404,
        message: utility.validationErrorHandler(err)
      });
    } else if (questionOption) {
          res.json({
                code: 200,
                message: constantsObj.messages.AssesmentQuestionOptionsGettingSuccess,
                data: questionOption
          })
      }else {
          res.json({
          code: 404,
          message: constantsObj.messages.noDataFound
          })
      }

  }).catch(function (err) {
     return res.json(Response(402,utility.validationErrorHandler(err), err));
  })
}

function questionFileUpload(req, res) {
    var timestamp = Number(new Date()); // current time as number
    var file = req.swagger.params.file.value;
    // var fileType = req.swagger.params.fileType.value;
    // console.log("in question file upload1",fileType);
    var splitFile = file.originalname.split('.');
    var filename = +timestamp + '_' + common.randomToken(6) + '.' + ((splitFile.length > 0) ? splitFile[splitFile.length - 1] : file.originalname);
    var imagePath = "./public/assets/uploads/file/" + filename;
    var obj = {};
    obj.file = file;
    
    fs.writeFile(path.resolve(imagePath), file.buffer, function(err) {
        if (err) {
            res.json({ code: 402, 'message': 'Request could not be processed. Please try again.', data: {} });
        } else {
                var assesQuestionFile = new AssesQuestionFile();
                assesQuestionFile.file_upload = "assets/uploads/file/" + filename;
                assesQuestionFile.question_type = "fileType";
                assesQuestionFile.save(function(err,fileData){
                  if(err){
                    res.json({ code: 500, message: constantsObj.validationMessages.internalError });
                  }else{
                      res.json({code:200,message:"Questions file uploaded successfully"});    
                  }
                })
        }
    });
}
/**
 * Function is use to Add Self Assesment Question 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 27-June-2017
 */ 
function addSelfAssessmentQuestion(req, res) {
        var questions = req.body.questions;
        async.each(questions,function(record,callback){
          var assessmentQuestion = new AssesmentQuestion();
          assessmentQuestion.question = record.question;
          assessmentQuestion.question_type = record.question_type;
          if(record.question_type != 'text'){
           assessmentQuestion.options = record.options;
          }
          assessmentQuestion.save(function(err,questionData){
          })
          callback();
        },function(err){
          if(err){
            res.json({code:404,message:"Internal error"});
          }else{
            res.json({code:200,message:"Question and options saved successfully"});
          }
        })
}


function deleteQuestionById(req, res) {
    var id = req.swagger.params.id.value;
    AssesmentQuestion.findById(id).exec(function(err, data) {
        if (err) {
            return res.json({code:500,message:'internal error'});
        } else {
            if (!data) {
                return res.json({code:402,message:'Question not found'});
            } else {
                data.is_deleted = true;
                data.save(function(err, userData) {
                    if (err)
                        return res.json({code:500,message:'internal error'});
                    else {
                        return res.json({code:200,message:'Question deleted successfully'});
                    }
                });
            }
        }
    })
}

function getAssesQuestionFile(req, res) {
  AssesQuestionFile.find({is_deleted:false}).lean().exec(function (err, question) {
    if (err) {
      res.json({
        code: 404,
        message: utility.validationErrorHandler(err)
      });
    } else if (question) {
          res.json({
                code: 200,
                message: constantsObj.messages.AssesmentQuestionFileGettingSuccess,
                data: question
          })
         
      }else {
          res.json({
          code: 404,
          message: constantsObj.messages.noDataFound
          })
      }

  }).catch(function (err) {
     return res.json(Response(402,utility.validationErrorHandler(err), err));
  })
}

function viewFileById(req, res) {
    co(function*() {
        var id = req.swagger.params.id.value;
        let uploadFileInfo = yield AssesQuestionFile.findById(id).exec();
        res.json({ code: 200, message: constantsObj.messages.dataRetrievedSuccess, data: uploadFileInfo});
    }).catch(function(err) {
       res.json({code:402, message: utility.validationErrorHandler(err), });
    });
}


function deleteFileById(req, res) {
    var id = req.swagger.params.id.value;
    AssesQuestionFile.findById(id).exec(function(err, data) {
        if (err) {
            return res.json({code:500,message:'internal error'});
        } else {
            if (!data) {
                return res.json({code:402,message:'file not found'});
            } else {
                data.is_deleted = true;
                data.save(function(err, userData) {
                    if (err)
                        return res.json({code:500,message:'internal error'});
                    else {
                        return res.json({code:200,message:'Question file deleted successfully'});
                    }
                });
            }
        }
    })
}

/**
 * Function is use to Get Assesment Questions  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 10-July-2017
 */
function getQuestionsForAssign(req, res) {
  AssesmentQuestion.find({is_deleted:false,status:true},{'_id':true,'question':true}).lean().exec(function (err, question) {
    if (err) {
      res.json({
        code: 404,
        message: utility.validationErrorHandler(err)
      });
    } else if (question) {
          var reqArr = [];
              async.each(question, function(questionData, callback) {
              var newData = {};
              newData.id = questionData._id;
              newData.label = questionData.question;
              reqArr.push(newData);
              callback();
              }, function(err) {
                  if (err) {
                      res.json({
                          code: 404,
                          message: constantsObj.messages.noDataFound
                      })
                  } else {
                      res.json({
                          code: 200,
                          message: constantsObj.messages.AssesmentQuestionGettingSuccess,
                          data: reqArr
                      })
                  }
              })         
      }else {
          res.json({
          code: 404,
          message: constantsObj.messages.noDataFound
          })
      }
  }).catch(function (err) {
          res.json({
                code:402,
                message:utility.validationErrorHandler(err),
                data:err
          });
  })
}

/**
 * Function is use to Assign Assesment Questions To Patients 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 10-July-2017
 */ 
function assignQuestions(req, res) {
  var patientsId =  [];
  var questionsId =  [];
  var questionFile = [];
  patientsId =  req.body.patients;
  questionsId =  req.body.questions;
  if(req.body.assesQuestionFile && req.body.assesQuestionFile[0] != null){
  questionFile = req.body.assesQuestionFile;
  }  
    co(function* () {
        let userData = yield User.findById(req.user.id);
        if (userData) {
            async.each(patientsId, function(patientId, callback) {
              if(patientId){
                async.each(questionsId, function(questionId, callback) {
                var assignQuestions = new AssignQuestions();
                assignQuestions.patient_id = patientId;
                assignQuestions.question_id = questionId;
                assignQuestions.save(function(err){
                  if(err){
                    res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
                  } 
                })
                callback();
                }, function(err) {
                    if (err) {
                        res.json({
                            code: 404,
                            message: utility.validationErrorHandler(err)
                        })
                    }else if(questionFile){
                      async.each(questionFile,function(ques,callback){
                        var assignQuestions = new AssignQuestions();
                        assignQuestions.patient_id = patientId;
                        assignQuestions.question_id = ques._id;
                        assignQuestions.save(function(err){
                          if(err){
                            res.json({
                                code: 404,
                                message: utility.validationErrorHandler(err)
                            });
                          } 
                        })
                        callback();  
                      },function(err){
                          if (err) {
                              res.json({
                                  code: 404,
                                  message: utility.validationErrorHandler(err)
                              })
                          }
                      })
                    }
                }) 
              }else{
                 res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
              }
           })
                 res.json({
                            code: 200,
                            message:  constantsObj.messages.AssignQuestionsSuccessfully,
                 })   
        } else {
             res.json({code:402, message:constantsObj.messages.UserNotFound, data:err});
        }
    }).catch(function (err) {
         res.json({code:402, message:utility.validationErrorHandler(err), data:err});
    });
}


/**
 * Function is use to Get Assesment Questions By Id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 13-July-2017
 */
function getAssesmentQuestionsById(req, res) {
          Patient.findOne({user_id:req.user.id}).exec(function(err,patientInfo){
            if(err){
               res.json({
                  code: 404,
                  message: utility.validationErrorHandler(err)
                });
             }else if(patientInfo){
              AssignQuestions.distinct('question_id',{patient_id:patientInfo._id,is_deleted:false,status:true},function(err,questionIds){
              AssesmentQuestion.find({is_deleted:false,status:true,_id:{$in:questionIds}}).lean().exec(function (err, question) {
              if (err) {
                res.json({
                  code: 404,
                  message: utility.validationErrorHandler(err)
                });
              } else if (question) {
                    res.json({
                          code: 200,
                          message: constantsObj.messages.AssesmentQuestionGettingSuccess,
                          data: question
                    })
                }else {
                    res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
                    })
                }
            })
           })   
          }else{
            res.json({
                    code: 404,
                    message: constantsObj.messages.noDataFound
            })
          }
          }).catch(function (err) {
     return res.json(Response(402,utility.validationErrorHandler(err), err));
  })
}

/**
 * Function is use to Get Not Assigned Question By Id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 17-July-2017
 */
function getQuestionsForAssignOnEdit(req, res) {
    var id = req.swagger.params.id.value;
    AssignQuestions.distinct('question_id',{patient_id:id,is_deleted:false,status:true}, function(err, questionIds) {
        AssesmentQuestion.find({is_deleted:false,status:true,_id:{$nin:questionIds}},{'_id':true,'question':true}).lean().exec(function (err, question) {
          if (err) {
            res.json({
              code: 404,
              message: utility.validationErrorHandler(err)
            });
          } else if (question) {
                var reqArr = [];
                    async.each(question, function(questionData, callback) {
                    var newData = {};
                    newData.id = questionData._id;
                    newData.label = questionData.question;
                    reqArr.push(newData);
                    callback();
                    }, function(err) {
                        if (err) {
                            res.json({
                                code: 404,
                                message: constantsObj.messages.noDataFound
                            })
                        } else {
                            res.json({
                                code: 200,
                                message: constantsObj.messages.AssesmentQuestionGettingSuccess,
                                data: reqArr
                            })
                        }
                    })         
            }else {
                res.json({
                code: 404,
                message: constantsObj.messages.noDataFound
                })
            }
        })
    }).catch(function(err) {
            return res.json(Response(402, utility.validationErrorHandler(err), err));
    })
}

/**
 * Function is use to Check Assigned Question Editable Or Not 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 17-July-2017
 */ 
function checkQuestionsEditable(req, res) {
  console.log("i check questions editable?");
    co(function* () {
        var id = req.swagger.params.id.value;
        let patientAssessment = yield PatientAssessment.findOne({patient_id:id,is_deleted:false,status:true}).lean();
        if (patientAssessment) {
                console.log("in find",patientAssessment);

                res.json({code:200,message:'Not editable.Assigned questions answered by patient'});
        }else {
                res.json({code:402,message:'Assigned questions is editable'});
        }
    }).catch(function (err) {
           res.json({code:402, message:utility.validationErrorHandler(err)});
    });
}