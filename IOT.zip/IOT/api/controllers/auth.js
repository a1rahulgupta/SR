'use strict';

var duo = require('duo_web'),
    mongoose = require('mongoose'),
    co = require('co'),
    async = require('async'),
    config = require('../../config/config.js'),
    validator = require('../../config/validator.js'),
    jwt = require('jsonwebtoken'),
    User = mongoose.model('User'),
    Role = mongoose.model('Role'),
    Hospital = mongoose.model('Hospital'),
    Patient = mongoose.model('Patient'),
    CareCoordinator = mongoose.model('CareCoordinator'),
    Clinician = mongoose.model('Clinician'),
    Ambulance = mongoose.model('Ambulance'),
    Towing = mongoose.model('Towing'),
   HospitalAssign = mongoose.model('HospitalAssign'),
    utility = require('../lib/utility.js'),
    constantsObj = require('../lib/constants'),
    constant = require('../lib/constants'),
    mailer = require('../lib/mailer'),
    moment = require('moment'),
    twilio = require('../lib/twilio'),
    emailObj = require('../lib/emails'),
    Response = require('../lib/response.js');

// console.log(constant.emailKeyword.WelComeEmail, 'constant.emailKeyword.WelComeEmail')
module.exports = {
    login: login,
    loginCheck: loginCheck,
    logOut: logOut,
    hospitalSignUp: hospitalSignUp,
    patientSignUp: patientSignUp,
    careCoordinatorSignUp: careCoordinatorSignUp,
    clinicianSignUp: clinicianSignUp,
    ambulanceSignUp: ambulanceSignUp,
    towingSignUp: towingSignUp,
    forgotpass: forgotpass,
    checkresettoken: checkresettoken,
    resetpassword: resetpassword
};

/**
 * [login Check credentials and login user ]
 * @param  {object} req
 * @param  {object} res
 * @return {json}
 */
function login(req, res) {
    var body = req.body;
    var email = body.email;

    var password = body.password;
    var jwtToken = null;
    var role = body.role;
    console.log("role", role);
    console.log("role-----------------------------------", role);
    User.findOne({
        email: email
    })
        .exec(function (err, user) {
            if (err || !user) {
                console.log("err", err);
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Invalid email or password'
                });
            } else if (!user.validPassword(password)) {
                console.log("err----", user);
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Invalid email or password'
                });
                /*} else if (user.group_id.name !== 'admin') {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Unauthorized access'
                    });*/
            } else {

                console.log("user", user.role_id);
                Role.findOne({ _id: user.role_id, name: role }, { name: 1 }).exec(function (rolerr, roldata) {
                    if (err) {
                        console.log("rolerr", rolerr)
                        res.json({
                            'code': config.httpBadRequest,
                            'message': 'Something went wrong with user role'
                        });
                    } else {
                        if (!roldata) {
                            res.json({
                                'code': config.httpBadRequest,
                                'message': 'Invalid Username & password'
                            });
                        } else {
                            //user is valid
                            var expirationDuration = 60 * 60 * 24 * 1; // expiration duration 1 day.
                            var params = {
                                id: user._id,
                                type: role
                            }
                            jwtToken = jwt.sign(params, config.SECRET, {
                                expiresIn: expirationDuration
                            });
                            if (validator.isValid(jwtToken)) {
                                user.duoToken = jwtToken;
                                user.duoVerified = true;

                                user.save(function (err, result) {
                                    if (err) {
                                        res.json({
                                            'code': config.httpBadRequest,
                                            'message': 'Something went wrong please try again!'
                                        });
                                    } else {
                                        var data = {
                                            token: 'Bearer ' + jwtToken,
                                            role: roldata.name,
                                            user_id:user._id
                                        };
                                        /*var data = {to : '+919665368708',message : 'This is test message from iotied.'}
                                        twilio.sendSMS(data,function(returnData){
                                            console.log('twilio', returnData);
                                        });*/
                                        res.json({
                                            'code': config.httpSuccess,
                                            'data': data,
                                            'message': 'login successfully'
                                        });
                                    }
                                });
                            } else {
                                res.json({
                                    'code': config.httpUnauthorize,
                                    'message': 'Something went wrong please try again!'
                                });
                            }

                        }



                    }
                });
            }
        });
}
/**
 * [forgotpass To request reset password token]
 * @param  {object} req
 * @param  {object} res
 * @return {json}
 */
function forgotpass(req, res) {
    var body = req.body;
    var email = body.email;
    var module = req.headers.entity;
    console.log(req.body);
    Role.findOne({ name: module }).exec(function (err, roldata) {
        if (err) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Required fields are missing'
            });
        } else if (roldata) {
            User.findOne({ email: email, role_id: roldata._id }).exec(function (err, user) {
                if (err) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Required fields are missing'
                    });
                } else if (!user) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'The email address that you have entered does not match any account'
                    });
                } else if (user) {
                    var userId = user._id;
                    var randstr = randomstring(15);
                    console.log("________________", module);
                    if (module == 'CareCoordinator') {
                        module = 'careCoordinator';
                    } else {
                        module = module.toLowerCase();
                    }
                    module = (module == 'patient') ? ('') : (module);
                    var baseUrl = req.protocol + '://' + req.get('host');
                    var reseturl = baseUrl + '/' + module + '/#!/resetPassword/' + randstr;
                    var htmlstr = '<b>Hello There</b><br/></p>Someone requested to reset your passwod, Please ingore if you did not.<br/>Or<br/>Please <a target="_blank" href="' + reseturl + '">click here</a> to reset your password.</p><p>---<br/>Thanks & Regards,<br>IOTies</p>';
                    var data = {
                        from: 'iotied@yopmail.com',
                        to: user.email,
                        subject: 'Forgot Password',
                        message: htmlstr
                    }
                    emailObj.sendEmail(data, function (returnData) {
                        console.log('returnObj', returnData);
                        if (returnData && returnData.code == 200) {
                            var updateData = {
                                forgot_request: new Date(),
                                forgot_token: randstr
                            }
                            User.findOneAndUpdate({
                                _id: userId,
                            }, {
                                    $set: updateData
                                }, function (err, data) {
                                    if (err) {
                                        res.json({
                                            'code': config.httpUnauthorize,
                                            'message': 'Something went wrong please try again!'
                                        });
                                    } else {
                                        res.json({
                                            'code': config.httpSuccess,
                                            'message': 'Please check email in your inbox to reset your password.',
                                        });
                                    }
                                });
                        }
                    });
                }
            });
        } else {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Something went wrong, please try again later.'
            });
        }

    });
}
/**
 * [checkresettoken To verify reset password tocken ]
 * @param  {object} req
 * @param  {object} res
 * @return {json}
 */
function checkresettoken(req, res) {
    var token = req.query.token;
    User.findOne({ forgot_token: token }).exec(function (err, user) {
        if (err) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Required fields are missing'
            });
        } else {
            if (user) {
                var minutes = moment().diff(moment(user.forgot_request), 'minutes');
                console.log('minutes', minutes);
                if (minutes > 120) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Token has been expired.'
                    });
                } else {
                    res.json({
                        'code': config.httpSuccess,
                        'message': 'This is a valid token.'
                    });
                }
            } else {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Token has been expired.'
                });
            }
        }
    });
}

/**
 * [resetpassword To reset password, with encrypt password ]
 * @param  {object} req
 * @param  {object} res
 * @return {json}
 */
function resetpassword(req, res) {
    console.log(req.body);
    var password = req.body.password
    var conf_password = req.body.conf_password
    var token = req.body.token
    if (password == conf_password) {
        User.findOne({ forgot_token: token }).exec(function (err, user) {
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Required fields are missing'
                });
            } else {
                if (user) {
                    var userId = user._id;
                    var minutes = moment().diff(moment(user.forgot_request), 'minutes');
                    console.log('minutes', minutes);
                    if (minutes > 120) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Token has been expired, please try again.'
                        });
                    } else {
                        var user = new User();
                        var obj = user.createPassword(password);
                        User.findOneAndUpdate({
                            _id: userId,
                        }, {
                                $set: obj
                            }, function (err, data) {
                                if (err) {
                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Something went wrong please try again!'
                                    });
                                } else {
                                    res.json({
                                        'code': config.httpSuccess,
                                        'message': 'Password reset successfully.',
                                    });
                                }
                            });
                    }
                }
            }
        });
    }
}
/**
 * [register To register user, with encrypt password ]
 * @param  {object} req
 * @param  {object} res
 * @return {json}
 */
function register(req, res) {
    var body = req.body;
    if (!validator.isValid(body.username) || !validator.isValid(body.password) || !validator.isValid(body.name) || !validator.isValid(body.email)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        User.existCheck(body.username, body.email, '', function (err, exist) {
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Something went wrong please try again!'
                });
            } else {
                if (exist) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Username or email already exist please try another!'
                    });
                } else {
                    Group.findOne({ name: 'admin', deleted: false, status: true }, function (err, group) {
                        var user = new User();
                        user.username = body.username;
                        user.name = body.name;
                        user.email = body.email;
                        user.group_id = group._id;
                        user.phone = body.phone;
                        user.setPassword(body.password);

                        user.save(function (err) {
                            if (err) {
                                res.json({
                                    'code': config.httpUnauthorize,
                                    'message': 'Unable to save user'
                                });
                            } else {
                                res.json({
                                    'code': config.httpSuccess,
                                    'message': 'User saved successfully'
                                });
                            }
                        });
                    })
                }
            }
        });
    }
}



/**
 * To check logged in user
 * @param  {object} req
 * @param  {Object} res
 * @return {config.httpSuccess or config.httpUnauthorize}
 */
function loginCheck(req, res) {
    if (validator.isValid(req.headers) && (validator.isValid(req.headers.authorization || validator.isValid(req.query.api_key)))) {
        var bearer = req.headers.authorization !== undefined ? req.headers.authorization.split(' ') : req.query.api_key.split(' ');
        var bearerToken = bearer[1];
        jwt.verify(bearerToken, config.SECRET, function (err, decoded) {
            req.user = decoded;
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Your Session Expired, Please login Again.'
                });
            } else {
                if (bearer.length == 2) {
                    User.findOne({
                        duoToken: bearer[1]
                    }).populate({
                        path: 'role_id',
                        select: 'name'
                    })
                        .exec(function (err, user) {
                            if (err || !user) {
                                res.json({
                                    'code': config.httpUnauthorize,
                                    'message': 'Authentication failed',
                                    'data': user
                                });
                            } else {
                                res.json({
                                    'code': config.httpSuccess,
                                    'message': 'Authenticated',
                                    'data': user
                                });
                            }
                        });
                } else {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Authentication failed'
                    });
                }

            }
        });
    } else {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Authentication failed'
        });
    }
};

/**
 * To logout
 * @param  {object} req
 * @param  {Object} res
 * @return {config.httpSuccess or config.httpUnauthorize}
 */
function logOut(req, res) {
    if (validator.isValid(req.headers) && (validator.isValid(req.headers.authorization || validator.isValid(req.query.api_key)))) {
        var parts = req.headers.authorization !== undefined ? req.headers.authorization.split(' ') : req.query.api_key.split(' ');
        if (parts.length == 2) {
            console.log(parts[1]);
            User.findOne({
                duoToken: parts[1],
                duoVerified: true
            }, function (err, user) {
                if (err) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Authentication failed'
                    });
                } else if (user) {
                    user.duoToken = '';
                    user.duoVerified = false;
                    user.save(function (err, data) {
                        if (err) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Authentication failed'
                            });
                        } else {
                            res.json({
                                'code': config.httpSuccess,
                                'message': 'Logout successfully'
                            });
                        }
                    });
                } else {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Authentication failed'
                    });
                }
            });
        } else {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Authentication failed'
            });
        }
    } else {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Authentication failed1'
        });
    }
};

/**
 * [register To register Hospital, with encrypt password] 
 * @param  {object} req
 * @param  {object} res
 * @return {json}
 */
function hospitalSignUp(req, res) {
    var body = req.body;
    console.log("body", body);
    if (!validator.isValid(body.hospital_name) || !validator.isValid(body.hospital_address) || !validator.isValid(body.hospital_city) || !validator.isValid(body.hospital_state) || !validator.isValid(body.hospital_zip_code) || !validator.isValid(body.hospital_mobile_no) || !validator.isValid(body.email) || !validator.isValid(body.password)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        Role.findOne({ name: 'Hospital', is_deleted: false, status: true }).exec(function (err, group) {
            console.log("group", group);
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Something went wrong please try again!'
                });
            } else if (group) {
                console.log("group", group);

                User.findOne({ email: body.email }).exec(function (err, exist) {
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Something went wrong please try again!'
                        });
                    } else {
                        if (exist) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Hospital Name with this email already exist please try another!'
                            });
                        } else {

                            var user = new User();
                            user.email = body.email;
                            user.role_id = group._id;
                            user.setPassword(body.password);

                            user.save(function (err, userData) {
                                if (err) {
                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Unable to save user'
                                    });
                                } else {

                                    console.log("in user save");
                                    var hospital = new Hospital();
                                    hospital.hospital_npi_no = body.hospital_npi_no;
                                    hospital.user_id = userData._id;
                                    hospital.hospital_name = body.hospital_name;
                                    hospital.hospital_address = body.hospital_address;
                                    hospital.hospital_city = body.hospital_city;
                                    hospital.hospital_state = body.hospital_state;
                                    hospital.hospital_zip_code = body.hospital_zip_code;
                                    hospital.hospital_country = body.hospital_country;
                                    hospital.hospital_mobile_no = body.hospital_mobile_no;
                                    hospital.save(function (err) {
                                        if (err) {
                                            res.json({
                                                'code': config.httpUnauthorize,
                                                'message': 'Unable to save user'
                                            });
                                        } else {
                                            var userMailData = {
                                                hospital_name: body.hospital_name,
                                                email: body.email,
                                                password: body.password
                                            };

                                            mailer.sendMail(body.email, constant.emailKeyword.WelComeEmailHospital, userMailData, function (err, resp) {
                                                if (err) {

                                                    res.json(Response(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                                } else {
                                                    res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                }
                                            });
                                            res.json({
                                                'code': config.httpSuccess,
                                                'message': 'Hospital Registered successfully'
                                            });
                                        }
                                    })


                                }
                            });
                        }
                    }
                });
            } else {
                res.json({
                    'code': 402,
                    'message': 'No record found'
                });
            };
        })
    }
}

/**
 * [register To register user, with encrypt password]
 * @param  {object} req
 * @param  {object} res
 * @return {json}
 */
function patientSignUp(req, res) {
    co(function* () {
        var body = req.body;
        if (!validator.isValid(body.first_name) || !validator.isValid(body.last_name) || !validator.isValid(body.mobile_no) || !validator.isValid(body.email) || !validator.isValid(body.password)) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'Required fields are missing'
            });
        } else {
            Role.findOne({ name: 'Patient', is_deleted: false, status: true }).exec(function (err, group) {
                if (err) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'Something went wrong please try again!'
                    });
                } else if (group) {
                    console.log("User", body.email);
                    User.findOne({ email: body.email }).exec(function (err, exist) {
                        if (err) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Something went wrong please try again!'
                            });
                        } else {
                            if (exist) {

                                res.json({
                                    'code': config.httpUnauthorize,
                                    'message': 'Patient Name with this email already exist please try another!'
                                });
                            } else {
                                var user = new User();
                                user.email = body.email;
                                user.role_id = group._id;
                                user.setPassword(body.password);
                                user.save(function (err, userData) {
                                    if (err) {
                                        res.json({
                                            'code': config.httpUnauthorize,
                                            'message': 'Unable to save user'
                                        });
                                    } else {
                                        var patientObj = {};
                                        var field = ['user_id', 'hospital_id'];
                                        var obj = req.body;
                                        obj.user_id = userData._id;
                                        utility.encryptedRecord(obj, field, function (patientObj) {
                                            var patient = new Patient(patientObj);
                                            patient.save(function (err, patientData) {
                                                console.log("patientData--------->>>>", patientData)
                                                if (err) {
                                                    res.json({
                                                        code: 404,
                                                        message: utility.validationErrorHandler(err)
                                                    });
                                                    console.log(err)
                                                } else {
                                                    var userMailData = {
                                                        first_name: body.first_name,
                                                        last_name: body.last_name,
                                                        password: body.password,
                                                        email: body.email
                                                    };
                                                    co(function* () {
                                                        let roleInfo = yield Role.findOne({ "name": "Hospital", is_deleted: false, status: true }).exec();
                                                        if (roleInfo) {
                                                            var assignHospitalData = {
                                                                "role_id": roleInfo._id,
                                                                "assign_id": req.body.hospital_id,
                                                                "patient_id": patientData._id,
                                                            }
                                                            console.log("assignHospitalData--->", assignHospitalData);
                                                            var assign = new HospitalAssign(assignHospitalData);
                                                            assign.save(function (err, data) {
                                                                if (err) {

                                                                } else {

                                                                }
                                                            });
                                                        }
                                                    });

                                                    mailer.sendMail(body.email, constant.emailKeyword.WelComeEmail, userMailData, function (err, resp) {
                                                            console.log("err@", err);
                                                            if (err) {

                                                                res.json(Response(constant.statusCode.error, constant.messages.requestNotProcessed, {}, err));
                                                            } else {
                                                                res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                            }
                                                        });
                                                    res.json({
                                                        code: 200,
                                                        message: 'Patient Registered successfully',
                                                        data: patientData
                                                    });
                                                }

                                            });
                                        })

                                    }
                                });
                            }
                        }
                    });
                } else {
                    res.json({
                        'code': 402,
                        'message': 'No record found'
                    });
                };
            })
        }
    }).catch(function (err) {
        console.log("patientSignUp Err---->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), {}));
    });
}




/**
 * [register To register Care Coordinator , with encrypt password] 
 * @param  {object} req
 * @param  {object} res
 * @return {json}
 */
function careCoordinatorSignUp(req, res) {
    var body = req.body;
    console.log("body", body);
    if (!validator.isValid(body.first_name) || !validator.isValid(body.last_name) || !validator.isValid(body.address) || !validator.isValid(body.city) || !validator.isValid(body.state) || !validator.isValid(body.country) || !validator.isValid(body.zip_code) || !validator.isValid(body.mobile_no) || !validator.isValid(body.SSN) || !validator.isValid(body.email) || !validator.isValid(body.careCoordinator_npi_no) || !validator.isValid(body.password)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        Role.findOne({ name: 'CareCoordinator', is_deleted: false, status: true }).exec(function (err, group) {
            console.log("group", group);
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Something went wrong please try again!'
                });
            } else if (group) {
                console.log("group", group);

                User.findOne({ email: body.email }).exec(function (err, exist) {
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Something went wrong please try again!'
                        });
                    } else {
                        if (exist) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Care Coordinator Name with this email already exist please try another!'
                            });
                        } else {

                            var user = new User();
                            user.email = body.email;
                            user.role_id = group._id;
                            user.setPassword(body.password);

                            user.save(function (err, userData) {
                                if (err) {
                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Unable to save user'
                                    });
                                } else {

                                    console.log("in user save");
                                    var careCoordinator = new CareCoordinator();
                                    careCoordinator.careCoordinator_npi_no = body.careCoordinator_npi_no;
                                    careCoordinator.user_id = userData._id;
                                    careCoordinator.first_name = body.first_name;
                                    careCoordinator.last_name = body.last_name;
                                    careCoordinator.SSN = body.SSN;
                                    careCoordinator.address = body.address;
                                    careCoordinator.city = body.city;
                                    careCoordinator.state = body.state;
                                    careCoordinator.zip_code = body.zip_code;
                                    careCoordinator.country = body.country;
                                    careCoordinator.mobile_no = body.mobile_no;
                                    careCoordinator.hospital_id = body.hospital_id;
                                    careCoordinator.save(function (err) {
                                        if (err) {
                                            res.json({
                                                'code': config.httpUnauthorize,
                                                'message': 'Unable to save user'
                                            });
                                        } else {
                                            var userMailData = {
                                                first_name: body.first_name,
                                                last_name: body.last_name,
                                                password: body.password,
                                                email: body.email
                                            };

                                            mailer.sendMail(body.email, constant.emailKeyword.WelComeEmail, userMailData, function (err, resp) {
                                                if (err) {
                                                    res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                                } else {
                                                    res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                }
                                            });
                                            console.log("in CareCoordinator save");
                                            res.json({
                                                'code': config.httpSuccess,
                                                'message': 'Care Coordinator Registered successfully'
                                            });
                                        }
                                    })


                                }
                            });
                        }
                    }
                });
            } else {
                res.json({
                    'code': 402,
                    'message': 'No record found'
                });
            };
        })
    }
}

/**
 * [register To register Clinician , with encrypt password] 
 * @param  {object} req
 * @param  {object} res
 * @return {json}
 */
function clinicianSignUp(req, res) {
    var body = req.body;
    console.log("body", body);
    if (!validator.isValid(body.first_name) || !validator.isValid(body.last_name) || !validator.isValid(body.address) || !validator.isValid(body.city) || !validator.isValid(body.state) || !validator.isValid(body.country) || !validator.isValid(body.zip_code) || !validator.isValid(body.mobile_no) || !validator.isValid(body.SSN) || !validator.isValid(body.email) || !validator.isValid(body.clinician_npi_no) || !validator.isValid(body.password)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        Role.findOne({ name: 'Clinician', is_deleted: false, status: true }).exec(function (err, group) {
            console.log("group", group);
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Something went wrong please try again!'
                });
            } else if (group) {
                console.log("group", group);

                User.findOne({ email: body.email }).exec(function (err, exist) {
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Something went wrong please try again!'
                        });
                    } else {
                        if (exist) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Clinician Name with this email already exist please try another!'
                            });
                        } else {

                            var user = new User();
                            user.email = body.email;
                            user.role_id = group._id;
                            user.setPassword(body.password);

                            user.save(function (err, userData) {
                                if (err) {
                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Unable to save clinician'
                                    });
                                } else {

                                    console.log("in user save");
                                    var clinician = new Clinician();
                                    clinician.clinician_npi_no = body.clinician_npi_no;
                                    clinician.user_id = userData._id;
                                    clinician.first_name = body.first_name;
                                    clinician.last_name = body.last_name;
                                    clinician.SSN = body.SSN;
                                    clinician.address = body.address;
                                    clinician.city = body.city;
                                    clinician.state = body.state;
                                    clinician.zip_code = body.zip_code;
                                    clinician.country = body.country;
                                    clinician.mobile_no = body.mobile_no;
                                    clinician.hospital_id = body.hospital_id;
                                    clinician.save(function (err) {
                                        if (err) {
                                            res.json({
                                                'code': config.httpUnauthorize,
                                                'message': 'Unable to save clinician'
                                            });
                                        } else {
                                            var userMailData = {
                                                first_name: body.first_name,
                                                last_name: body.last_name,
                                                password: body.password,
                                                email: body.email
                                            };

                                            mailer.sendMail(body.email, constant.emailKeyword.WelComeEmail, userMailData, function (err, resp) {
                                                if (err) {
                                                    res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                                } else {
                                                    res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                }
                                            });
                                            console.log("in Clinician save");
                                            res.json({
                                                'code': config.httpSuccess,
                                                'message': 'Clinician Registered successfully'
                                            });
                                        }
                                    })


                                }
                            });
                        }
                    }
                });
            } else {
                res.json({
                    'code': 402,
                    'message': 'No record found'
                });
            };
        })
    }
}

/**
 * [register To register Ambulance , with encrypt password] 
 * @param  {object} req
 * @param  {object} res
 * @return {json}
 */
function ambulanceSignUp(req, res) {
    var body = req.body;
    console.log("body", body);
    if (!validator.isValid(body.address) || !validator.isValid(body.city) || !validator.isValid(body.state) || !validator.isValid(body.country) || !validator.isValid(body.zip_code) || !validator.isValid(body.mobile_no) || !validator.isValid(body.company_name) || !validator.isValid(body.email) || !validator.isValid(body.service_type) || !validator.isValid(body.password)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        Role.findOne({ name: 'Ambulance', is_deleted: false, status: true }).exec(function (err, group) {
            console.log("group", group);
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Something went wrong please try again!'
                });
            } else if (group) {
                console.log("group", group);

                User.findOne({ email: body.email }).exec(function (err, exist) {
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Something went wrong please try again!'
                        });
                    } else {
                        if (exist) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Ambulance Name with this email already exist please try another!'
                            });
                        } else {

                            var user = new User();
                            user.email = body.email;
                            user.role_id = group._id;
                            user.setPassword(body.password);

                            user.save(function (err, userData) {
                                if (err) {
                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Unable to save ambulance'
                                    });
                                } else {

                                    console.log("in user save");
                                    var ambulance = new Ambulance();
                                    ambulance.company_name = body.company_name;
                                    ambulance.user_id = userData._id;
                                    ambulance.service_type = body.service_type;
                                    ambulance.address = body.address;
                                    ambulance.city = body.city;
                                    ambulance.state = body.state;
                                    ambulance.zip_code = body.zip_code;
                                    ambulance.country = body.country;
                                    ambulance.mobile_no = body.mobile_no;
                                    ambulance.hospital_id = body.hospital_id;
                                    ambulance.save(function (err) {
                                        if (err) {
                                            res.json({
                                                'code': config.httpUnauthorize,
                                                'message': 'Unable to save ambulance'
                                            });
                                        } else {
                                            var userMailData = {
                                                company_name: body.company_name,
                                                email: body.email,
                                                password: body.password
                                            };

                                            mailer.sendMail(body.email, constant.emailKeyword.WelComeEmailTowing, userMailData, function (err, resp) {
                                                if (err) {
                                                    res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                                } else {
                                                    res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                }
                                            });
                                            console.log("in ambulance save");
                                            res.json({
                                                'code': config.httpSuccess,
                                                'message': 'Ambulance Registered successfully'
                                            });
                                        }
                                    })


                                }
                            });
                        }
                    }
                });
            } else {
                res.json({
                    'code': 402,
                    'message': 'No record found'
                });
            };
        })
    }
}

/**
 * [register To register Towing , with encrypt password] 
 * @param  {object} req
 * @param  {object} res
 * @return {json}
 */
function towingSignUp(req, res) {
    var body = req.body;
    console.log("body", body);
    if (!validator.isValid(body.address) || !validator.isValid(body.city) || !validator.isValid(body.state) || !validator.isValid(body.country) || !validator.isValid(body.zip_code) || !validator.isValid(body.mobile_no) || !validator.isValid(body.company_name) || !validator.isValid(body.email) || !validator.isValid(body.service_type) || !validator.isValid(body.password)) {
        res.json({
            'code': config.httpUnauthorize,
            'message': 'Required fields are missing'
        });
    } else {
        Role.findOne({ name: 'Towing', is_deleted: false, status: true }).exec(function (err, group) {
            console.log("group", group);
            if (err) {
                res.json({
                    'code': config.httpUnauthorize,
                    'message': 'Something went wrong please try again!'
                });
            } else if (group) {
                console.log("group", group);

                User.findOne({ email: body.email }).exec(function (err, exist) {
                    if (err) {
                        res.json({
                            'code': config.httpUnauthorize,
                            'message': 'Something went wrong please try again!'
                        });
                    } else {
                        if (exist) {
                            res.json({
                                'code': config.httpUnauthorize,
                                'message': 'Towing Company Name with this email already exist please try another!'
                            });
                        } else {

                            var user = new User();
                            user.email = body.email;
                            user.role_id = group._id;
                            user.setPassword(body.password);

                            user.save(function (err, userData) {
                                if (err) {
                                    res.json({
                                        'code': config.httpUnauthorize,
                                        'message': 'Unable to save towing'
                                    });
                                } else {

                                    console.log("in user save");
                                    var towing = new Towing();
                                    towing.company_name = body.company_name;
                                    towing.user_id = userData._id;
                                    towing.service_type = body.service_type;
                                    towing.address = body.address;
                                    towing.city = body.city;
                                    towing.state = body.state;
                                    towing.zip_code = body.zip_code;
                                    towing.country = body.country;
                                    towing.mobile_no = body.mobile_no;
                                    towing.hospital_id = body.hospital_id;
                                    towing.save(function (err) {
                                        if (err) {
                                            res.json({
                                                'code': config.httpUnauthorize,
                                                'message': 'Unable to save towing'
                                            });
                                        } else {
                                            var userMailData = {
                                                company_name: body.company_name,
                                                email: body.email,
                                                password: body.password
                                            };

                                            mailer.sendMail(body.email, constant.emailKeyword.WelComeEmailTowing, userMailData, function (err, resp) {
                                                if (err) {
                                                    res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                                } else {
                                                    res.json(Response(constant.statusCode.ok, constant.messages.passwordSentSuccess, {}, null));
                                                }
                                            });
                                            console.log("in towing save");
                                            res.json({
                                                'code': config.httpSuccess,
                                                'message': 'Towing Registered successfully'
                                            });
                                        }
                                    })


                                }
                            });
                        }
                    }
                });
            } else {
                res.json({
                    'code': 402,
                    'message': 'No record found'
                });
            };
        })
    }
}


function randomstring(num) {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < num; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}
