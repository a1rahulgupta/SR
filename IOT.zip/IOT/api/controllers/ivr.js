'use strict';

var mongoose = require('mongoose'),
    config = require('../../config/config.js'),
    Patient = mongoose.model('Patient'),
    constantsObj = require('../lib/constants'),
    algorithm = constantsObj.config.cryptoAlgorithm,
    password = constantsObj.config.cryptoPassword,
    utility = require('../lib/utility.js'),
    Role = mongoose.model('Role'),
    HospitalAssign = mongoose.model('HospitalAssign'),
    co = require('co'),
    IvrSetting = mongoose.model('IvrSetting'),
    Ambulance = mongoose.model('Ambulance'),
    Clinician = mongoose.model('Clinician'),
    Towing = mongoose.model('Towing'),
    CareCoordinator = mongoose.model('CareCoordinator'),
    Hospital = mongoose.model('Hospital'),
    Appointment = mongoose.model('Appointment'),
    generateToken = require('../lib/generateToken'),
    async = require('async'),
    twilio = require('twilio');

var accountSid = config.TWILIO_ACCOUNT_SID;
var authToken = config.TWILIO_AUTH_TOKEN;

var client = require('twilio')(accountSid, authToken);
var VoiceResponse = require('twilio').twiml.VoiceResponse;

module.exports = {
    welcome: welcome,
    menu: menu,
    recordSystemId: recordSystemId,
    dial: dial,
    checkedSSN: checkedSSN,
    record: record,
    update: update,
    getIvrData: getIvrData,
    getivrnumbers: getivrnumbers,
    getVideoCallReqs: getVideoCallReqs
};

var entity_mobileNo;

function decrypt(decText) {
    var decipher = crypto.createDecipher(algorithm, password)
    var decText = decipher.update(decText, 'hex', 'utf8')
    decText += decipher.final('utf8');
    return decText;
}
function update(req, res) {
    var userId = req.user.id;
    console.log('userdata:', req.user.type);
    req.body.user_id = userId;
    req.body.user_type = req.user.type;
    //console.log(req.body,req.body);
    co(function* () {
        let ivrData = yield IvrSetting.findById(req.body._id);
        if (ivrData) {
            //console.log('ivrData',ivrData);
            ivrData.ivr_label = req.body.ivr_label;
            ivrData.language = req.body.language;
            ivrData.welcome_message = req.body.welcome_message;
            ivrData.verification_message = req.body.verification_message;
            ivrData.thankyou_message = req.body.thankyou_message;
            ivrData.toll_free_number = req.body.toll_free_number;
            ivrData.ccoo_thankyou_message = req.body.ccoo_thankyou_message;
            if (req.body.toll_free_no_gps) {
                ivrData.toll_free_no_gps = req.body.toll_free_no_gps;
            }
            let savedData = yield ivrData.save();
            res.json({
                code: 200,
                message: constantsObj.messages.ivrUpdatedSuccess,
                data: savedData
            });
        } else {
            var ivrSetting = new IvrSetting(req.body);
            ivrSetting.save(function (err, ivrSettingData) {
                if (err) {
                    res.json({
                        code: 404,
                        message: utility.validationErrorHandler(err)
                    });
                } else {
                    res.json({
                        code: 200,
                        message: constantsObj.messages.ivrUpdatedSuccess,
                        data: ivrSettingData
                    });
                }
            });
        }
    }).catch(function (err) {
        res.json({
            code: 404,
            message: utility.validationErrorHandler(err)
        });
    });
}

function getIvrData(req, res) {
    var userId = req.user.id;
    IvrSetting.findOne({ user_id: userId }).exec(function (err, data) {
        if (err) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'IVR data not found'
            });
        } else {
            res.json({
                'code': config.httpSuccess,
                'data': data
            });
        }
    });
}

function welcome(req, res) {
    console.log('req.body welcome function', req.body);
    getIvrSetting(req, function (ivr) {
        var voiceResponse = new VoiceResponse();
        voiceResponse.say({ voice: 'alice', language: ivr.language }, ivr.welcome_message);
        var gather = voiceResponse.gather({
            action: '/ivr/menu',
            numDigits: '1',
            method: 'POST',
        });
        gather.say({ voice: 'alice', language: ivr.language }, ivr.verification_message);
        res.send(voiceResponse.toString());
    });
}

function menu(req, res) {
    console.log('in "menu" function');
    getIvrSetting(req, function (ivr) {
        var selectedOption = req.body.Digits;
        var voiceResponse = new VoiceResponse();
        if (selectedOption == 1) { // Clock In
            var gather = voiceResponse.gather({
                action: '/ivr/record-system-id?t=1',
                numDigits: '1',
                method: 'POST',
            });
            gather.say({ voice: 'alice', language: ivr.language }, 'Welcome to the clinician service, we Discover High Risk Patient Population, Manage them by taking pro active action automatically. Press 1 to provide your demographics.');
            res.send(voiceResponse.toString());
        } else if (selectedOption == 2) {
            var gather = voiceResponse.gather({
                action: '/ivr/record-system-id?t=2',
                numDigits: '1',
                method: 'POST',
            });
            gather.say({ voice: 'alice', language: ivr.language }, 'Welcome to towing service, we Discover High Risk Patient Population, Manage them by taking pro active action automatically , Press 1 to  provide towing emergency service.');
            res.send(voiceResponse.toString());
        } else if (selectedOption == 3) {
            var gather = voiceResponse.gather({
                action: '/ivr/record-system-id?t=3',
                numDigits: '1',
                method: 'POST',
            });
            gather.say({ voice: 'alice', language: ivr.language }, 'Welcome to Ambulance service, we Discover High Risk Patient Population, Manage them by taking pro active action automatically , Press 1 to  provide Ambulance emergency service.');
            res.send(voiceResponse.toString());
        } else if (selectedOption == 4) {
            var gather = voiceResponse.gather({
                action: '/ivr/record-system-id?t=4',
                numDigits: '1',
                method: 'POST',
            });
            gather.say({ voice: 'alice', language: ivr.language }, ivr.ccoo_thankyou_message);
            res.send(voiceResponse.toString());
        } else if (selectedOption == 5) {
            voiceResponse.say({ voice: 'alice', language: ivr.language }, ivr.thankyou_message);
            res.send(voiceResponse.toString());
        } else {
            voiceResponse.say({ voice: 'alice', language: ivr.language }, 'You entered invalid option, Please try again later, Thank you.');
            res.send(voiceResponse.toString());
        }
    });
}

function recordSystemId(req, res) {
    console.log('in "recordSystemId" function');
    getIvrSetting(req, function (ivr) {
        var t = req.query.t;
         console.log("recordSystemId------t--->>",t);
        // var selected = req.body.Digits;
        //
        var voiceResponse = new VoiceResponse();
        if (t == 1) {
            var gather = voiceResponse.gather({
                action: '/ivr/checkedSSN?t=Clinician',
                numDigits: '9',
                method: 'POST',
            });
            gather.say({ voice: 'alice', language: ivr.language }, 'This is clinician service. Press Enter Your SSN Number to Verify.');
            res.send(voiceResponse.toString());
        } else if (t == 2) {
            var gather = voiceResponse.gather({
                action: '/ivr/checkedSSN?t=Towing',
                numDigits: '9',
                method: 'POST',
            });
            gather.say({ voice: 'alice', language: ivr.language }, 'This is Towing service . Press Enter Your SSN Number to Verify. ');
            res.send(voiceResponse.toString());
        } else if (t == 3) {
            var gather = voiceResponse.gather({
                action: '/ivr/checkedSSN?t=Ambulance',
                numDigits: '9',
                method: 'POST',
            });
            gather.say({ voice: 'alice', language: ivr.language }, 'This is Ambulance service. Press Enter Your SSN Number to Verify. ');
            res.send(voiceResponse.toString());
        }else if (t==4) {
             var gather = voiceResponse.gather({
                action: '/ivr/checkedSSN?t=Care_Co',
                numDigits: '9',
                method: 'POST',
            });
            gather.say({ voice: 'alice', language: ivr.language }, 'This is Care Coordinator service. Press Enter Your SSN Number to Verify. ');
            res.send(voiceResponse.toString());

        }
    });
}
function checkedSSN(req, res) {
    console.log('in "checkedSSN" function');
    getIvrSetting(req, function (ivr) {
        var t = req.query.t;
         console.log('------------t----checkedSSN-----',t);
        co(function* () {
            console.log("ivr------------------------------>>>>>>>", ivr);
            let hospitalInfo = yield Hospital.findOne({ user_id: ivr.user_id }).lean();
            console.log("-----hospitalInfo----", hospitalInfo);
            var condition = {};
            condition.is_deleted = false;
            if (hospitalInfo) {
                condition.hospital_id = hospitalInfo._id;
            }
            console.log("condition", condition);
            // let patientInfo = yield Patient.find(condition).lean();
            Patient.find(condition).lean().exec(function (err, patientInfo) {
                console.log("patientInfo", patientInfo);
                if (patientInfo) {
                    var find_Flag=false;
                    var newArr = [];
                    var filed = ['user_id', 'clinician_id', 'coordinator_id', 'DOB', 'image', 'country', 'hospital_id'];
                    utility.decryptedRecord(patientInfo, filed, function (newArr) {
                        console.log("newArr-------------->>>>>>>>>", newArr);
                        var voiceResponse = new VoiceResponse();
                        newArr.forEach(function (data) {
                            var SSN = parseInt(data.SSN);
                            var selectedSSN = req.body.Digits;
                            console.log("selectedSSN", selectedSSN);
                            console.log("SSN", SSN);
                            if (selectedSSN == SSN) {
                                find_Flag=true;
                                console.log("data", data);
                                console.log("data._id", data._id);
                                let userInfo = {};
                                HospitalAssign.find({ patient_id: data._id, is_deleted: false }).lean().populate('role_id').exec(function (err, assignInfo) {
                                    console.log("patientInfo 1111", assignInfo);
                                    console.log("before assignedUserList-->", assignInfo);
                                    for (var i = 0; i < assignInfo.length; i++) {
                                        console.log("assignInfo[i]-->", assignInfo[i]);
                                        if (assignInfo[i].role_id && assignInfo[i].role_id.name) {
                                            console.log("--------111111-------");
                                            let roleType = assignInfo[i].role_id.name;
                                            let assign_id = assignInfo[i].assign_id;
                                            let userInfo = {};
                                            if (t == 'Clinician') {
                                                console.log("--------222-Clinician------");
                                                Clinician.findOne({ _id: assign_id, is_deleted: false }).lean().exec(function (err, userInfo) {
                                                    if (userInfo) {
                                                        console.log("--------222333-------", userInfo);
                                                        userInfo = userInfo;
                                                        entity_mobileNo = userInfo.mobile_no

                                                    }
                                                })
                                            }
                                            if (t == 'Towing') {
                                                console.log("--------222TOWING-------");
                                                Towing.findOne({ _id: assign_id, is_deleted: false }).lean().exec(function (err, userInfo) {
                                                    if (userInfo) {
                                                        console.log("--------222333-------", userInfo);
                                                        userInfo = userInfo;
                                                        entity_mobileNo = userInfo.mobile_no

                                                    }
                                                })
                                            }
                                            if(t=='Care_Co'){
                                                 console.log("--------222Care_Co-------");
                                                CareCoordinator.findOne({ _id: assign_id, is_deleted: false }).lean().exec(function (err, userInfo) {
                                                    if (userInfo) {
                                                        console.log("--------222333-------", userInfo);
                                                        userInfo = userInfo;
                                                        entity_mobileNo = userInfo.mobile_no

                                                    }
                                                })

                                            }
                                            if(t=='Ambulance'){
                                                 console.log("--------222Ambulance-------");
                                                 Ambulance.findOne({ _id: assign_id, is_deleted: false }).lean().exec(function (err, userInfo) {
                                                    if (userInfo) {
                                                        console.log("--------222333-------", userInfo);
                                                        userInfo = userInfo;
                                                        entity_mobileNo = userInfo.mobile_no

                                                    }
                                                })
                                            }

                                        }

                                    }

                                })
                            }
                        
                        })
                        if(find_Flag){
                        var gather = voiceResponse.gather({
                                    action: '/ivr/dial',
                                    numDigits: '1',
                                    method: 'POST',
                                });
                                gather.say({ voice: 'alice', language: ivr.language }, 'Thank You, You Are Verified. Press 1 for Calling.');
                        res.send(voiceResponse.toString());
                        }
                        else{
                           voiceResponse.say({ voice: 'alice', language: ivr.language }, 'Your SSN Number is Invalid. Thank you for calling into Iotied Support System');
                            res.send(voiceResponse.toString());
                        }
                    })
                }
            })
        }).catch(function (err) {
            console.log("err", err);
        });
    })
}


function dial(req, res) {
    console.log('in "dial" function---------->>>>>>>>>', req);
    getIvrSetting(req, function (ivr) {
        var response = new VoiceResponse();
        var dial = response.dial({
            record: 'record-from-ringing-dual',
            recordingStatusCallback: '/ivr/record'
        });
        dial.number(entity_mobileNo);
        console.log("entity_mobileNo",entity_mobileNo);
        console.log(response.toString());
        res.send(response.toString());
    });
}

function record(req, res) {
    console.log('in "record" function');
    console.log(req.body);
}

function getIvrSetting(request, callback) {
    var toll_free_number = request.body.To;
    //toll_free_number = toll_free_number.substr(toll_free_number.length - 10);
    IvrSetting.findOne({ toll_free_number: toll_free_number }).exec(function (err, ivrConfig) {
        if (err) {
            console.log("No IVR configured for the company");
            callback();
        } else if (!ivrConfig) {
            console.log("No IVR configured for the company");
            callback()
        } else {
            callback(ivrConfig);
        }
    });
};

function getivrnumbers(req, res) {
    IvrSetting.find().exec(function (err, ivrConfig) {
        if (err) {
            res.json({
                'code': config.httpUnauthorize,
                'message': 'IVR data not found'
            });
        } else {
            var returnArr = []
            async.each(ivrConfig, function (ivrData, callback) {
                var obj = {};
                obj.type = ivrData.user_type;
                obj.number = ivrData.toll_free_number;
                Hospital.findOne({ user_id: ivrData.user_id }).exec(function (err, hospitalData) {
                    console.log(obj, hospitalData.hospital_name);
                    obj.name = hospitalData.hospital_name;
                });
                setTimeout(function () {
                    console.log(obj);
                    returnArr.push(obj);
                    callback();
                }, 1000);
            }, function (err) {
                if (err) {
                    res.json({
                        'code': config.httpUnauthorize,
                        'message': 'IVR data not found'
                    });
                } else {
                    console.log('returnArr----', returnArr);
                    res.json({
                        'code': config.httpSuccess,
                        'data': returnArr
                    });
                }
            });
        }
    });
}


function getVideoCallReqs(req, res) {
    var returnData = generateToken.generateToken('a92ed33a0bc44fbab3bd2753a3a8e86a', '09d35c.vidyo.io', 'Vinodt', 10000);
    console.log(returnData);

    Clinician.findOne({ user_id: req.user.id }).lean().exec(function (err, data) {
        if (err) {
            res.json({
                'code': 402,
                'message': 'Clinician data not found'
            })
        } else {
            var clinicianId = data._id
            console.log("clinicianId------->>>", clinicianId);
            Appointment.find({ clinician_id: clinicianId, is_deleted: false, is_video_call: true }).populate('patient_id', { first_name: true, last_name: true }).lean().exec(function (err, data) {
                if (err) {
                    console.log("errr", err);
                    res.json({
                        'code': 402,
                        'message': 'Clinician data not found'
                    })
                } else {
                    console.log("data------->>>", data);
                    var resultArr = []
                    for (var i = 0; i < data.length; i++) {
                        var filed = [];
                        utility.decryptedRecord(data[i].patient_id, filed, function (newArr) {
                            data[i].patient_id = newArr
                        });
                        resultArr.push(data);
                    }
                    res.json({
                        'code': 200,
                        'data': data
                    })
                }
            });
        }
    });
}

