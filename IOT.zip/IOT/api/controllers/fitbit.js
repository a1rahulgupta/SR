var fitbitClient = require('../lib/fitbitClient.js');
config = require('../../config/config.js'),
    mongoose = require('mongoose'),
    Roles = mongoose.model('Role'),
    User = mongoose.model('User'),
    Rule = mongoose.model('Rule'),
    Patient = mongoose.model('Patient'),
    PatientActivity = mongoose.model('PatientActivity'),
    co = require('co'),
    utility = require('../lib/utility.js'),
    async = require('async'),
    constantsObj = require('../lib/constants'),
    PatientDeviceConfig = mongoose.model('PatientDeviceConfig');
Response = require('../lib/response.js');
var moment = require('moment');

module.exports = {
    authRequestfitbit: authRequestfitbit,
    oauth_fitbit_callback: oauth_fitbit_callback,
    verifyCode: verifyCode
};

function authRequestfitbit(req, res) {
    console.log('req.query', req.query.deviceId);
    console.log(req.user.id);
    var baseUrl = req.protocol + '://' + req.get('host');
    var callbackUrl = baseUrl + config.CALLBACK_URL_FITBIT;
    console.log('baseUrl', baseUrl);
    console.log("callbackUrl", callbackUrl);
    if (req.query.deviceId && req.user.id) {
        Patient.findOne({
            user_id: req.user.id
        }).exec(function (err, patient) {
            if (err) {
                res.json({
                    code: config.httpUnauthorize,
                    message: err
                });
            } else {
                var patientId = patient._id;
                req.session.oauth = {
                    'patientId': patientId,
                    'deviceId': req.query.deviceId
                };
                PatientDeviceConfig.findOne({
                    device_id: req.query.deviceId,
                    patient_id: patientId
                }).exec(function (err, patientDevConf) {
                    console.log("patientDevConf", err, patientDevConf);
                    if (err) {
                        res.json({
                            code: config.httpUnauthorize,
                            message: err
                        });
                    }
                    else if (patientDevConf) {
                        console.log("-------------patientDevConf present-----------------------", err, patientDevConf);
                        var options = {
                            consumerKey: config.CONSUMER_KEY_FITBIT,
                            consumerSecret: config.CONSUMER_SECRET_FITBIT,
                            accessToken: patientDevConf.fitbit_access_token,
                            refreshToken: patientDevConf.fitbit_refesh_token,
                            userID: patientDevConf.fitbit_user_id
                        };
                        var redirect = false;
                        syncFitbit(req, res, options, redirect, patientDevConf._id, {
                            'patientId': patientId,
                            'deviceId': req.query.deviceId
                        });

                        //  syncFitbit(req, res, options, redirect, data._id, oauthSettings);
                    }
                    else {
                        var options = {
                            consumerKey: config.CONSUMER_KEY_FITBIT,
                            consumerSecret: config.CONSUMER_SECRET_FITBIT,
                            callbackUrl: callbackUrl
                        };
                        var client = new fitbitClient(options);
                        //  console.log("options 11", options);
                        req.session.oauth = {
                            'patientId': patientId,
                            'deviceId': req.query.deviceId,
                        };
                        // console.log("req.session.oauth--------->", req.session.oauth);
                        res.json({
                            code: config.httpSuccess,
                            url: client.getAuthorizeUrl('activity profile heartrate location nutrition settings sleep social weight', callbackUrl)
                        });
                    }
                });
            }
        })
    } else {
        res.json({
            code: config.httpUnauthorize,
            message: 'Invalid request, Please try again later.',
        });
    }
}

/**
 * [createfcst - create fcstrcos]
 * @param  {json body} req
 * @param  {object} res
 * @return {json}
 */
function oauth_fitbit_callback(req, res) {
    console.log('req.query oauth_fitbit_callback----------------->', req.sessionStore.sessions);
    var oauthSettings = {};
    Object.keys(req.sessionStore.sessions).forEach((item) => {
        console.log("item--->", item);
        let value = JSON.parse(req.sessionStore.sessions[item]);
        console.log("value--->", value);
        if (value && value.hasOwnProperty("oauth")) {
            oauthSettings = JSON.parse(req.sessionStore.sessions[item])['oauth'];
        }
    });
    console.log("oauthSettings--->", oauthSettings);
    var baseUrl = req.protocol + '://' + req.get('host');
    var callbackUrl = baseUrl + config.CALLBACK_URL_FITBIT;
    var verifier = req.query.code;
    //var oauthSettings = req.session.oauth;
    var options = {
        consumerKey: config.CONSUMER_KEY_FITBIT,
        consumerSecret: config.CONSUMER_SECRET_FITBIT,
        callbackUrl: callbackUrl
    };
    var client = new fitbitClient(options);
    console.log("client in oauth_fitbit_callback---->", client);
    client.getAccessToken(verifier, callbackUrl).then(result => {
        console.log("getAccessToken result--->", result);
        var postData = {
            'fitbit_access_token': result.access_token,
            'fitbit_refesh_token': result.refresh_token,
            'fitbit_user_id': result.user_id,
            'patient_id': oauthSettings.patientId,
            'device_id': oauthSettings.deviceId,
        }
        console.log("postData---->", postData);
        console.log("oauthSettings---->", oauthSettings);
        PatientDeviceConfig.findOneAndUpdate({
            patient_id: oauthSettings.patientId,
            device_id: oauthSettings.deviceId
        }, {
                $set: postData
            }, {
                upsert: true,
                new: true
            }, function (err, data) {
                console.log("findOneAndUpdate---->", err);
                console.log("findOneAndUpdate---->", data);
                if (err) {
                    res.redirect('/#!/deviceList');
                } else {
                    var options = {
                        consumerKey: config.CONSUMER_KEY_FITBIT,
                        consumerSecret: config.CONSUMER_SECRET_FITBIT,
                        accessToken: result.access_token,
                        userID: result.user_id
                    };
                    var redirect = true;
                    syncFitbit(req, res, options, redirect, data._id, oauthSettings);
                }
            })
    });
}

function syncFitbit(req, res, options, redirect, devId, oauthSettings) {
    console.log("req, res, options, redirect, devId------>>>", options, redirect, devId);
    console.log("before options---------->", options);

    co(function* () {
        var client = new fitbitClient(options);
        let patientDevConf = yield PatientDeviceConfig.findOne({ _id: devId }).lean().exec();
        console.log("patientDevConf--->", patientDevConf);
        if (patientDevConf) {
            let isTokenExpired = yield client.getTokenState(options.accessToken).then(results => {
                console.log("results----if---->>",results);
                if (results[0].errors && results[0].errors.length > 0) {
                    if (results[0].errors[0].errorType == 'expired_token') {
                        return true;
                    }
                }
            });
            if (isTokenExpired) {
                let response = yield client.getRefreshToken(options).then(results => {
                    console.log("results----else---->>",results);
                    if (results[0]) {
                        let postData = {
                            'fitbit_access_token': results[0].access_token,
                            'fitbit_refesh_token': results[0].refresh_token,
                            'fitbit_user_id': results[0].user_id
                        }
                        options.accessToken = results[0].access_token;
                        options.refreshToken = results[0].refresh_token;
                        co(function* () {
                            let patientDevConfig = yield PatientDeviceConfig.findOneAndUpdate({ _id: devId }, {
                                $set: postData
                            }).exec();
                        });
                    }
                });
            }

            console.log("after options---------->", options);
            var endDate = moment().format('YYYY-MM-DD');
            var fitbitData = yield {
                activity:
                co(function* () {
                    var activityUrl = constantsObj.fitbitApiBaseUrl.activity + endDate + '.json';
                    let activityData = yield client.get(activityUrl, options.accessToken, options.userID).then(results => {
                        //   console.log("activityUrl results[0]------------------>", results);
                        if (results[0].errors && (results[0].errors.length > 0)) {
                            return {};
                        }
                        else {
                            return (results[0]);
                        }
                    });
                    return activityData;
                }),
                fat:
                co(function* () {
                    var fatUrl = constantsObj.fitbitApiBaseUrl.fat + endDate + '.json';
                    let fatData = yield client.get(fatUrl, options.accessToken, options.userID).then(results => {
                         console.log("fatUrl results[0]------------------>", results[0]);
                        if (results[0] && results[0].fat)
                            return (results[0].fat);
                        else
                            return {};
                    });
                    return fatData;
                }),
                weight:
                co(function* () {
                    var weightUrl = constantsObj.fitbitApiBaseUrl.weight + endDate + '.json';
                    let weightData = yield client.get(weightUrl, options.accessToken, options.userID).then(results => {
                        console.log("fatUrl results[0]------------------>", results[0]);
                        if (results[0] && results[0].weight)
                            return (results[0].weight);
                        else
                            return {};
                    });
                    return weightData;
                }),
                // heartRate:
                // co(function* () {
                //     var weightUrl = constantsObj.fitbitApiBaseUrl.heartRate;
                //     let weightData = yield client.get(weightUrl, options.accessToken, options.userID).then(results => {
                //         // console.log("heartRate results[0]------------------>", results[0]);
                //         if (results[0].errors && (results[0].errors.length > 0)) {
                //             return {};
                //         }
                //         else {
                //             return results[0];
                //         }
                //     });
                //     return weightData;
                // }),
                // sleep:
                // co(function* () {
                //     var weightUrl = constantsObj.fitbitApiBaseUrl.sleep + endDate + '.json';
                //     let weightData = yield client.get(weightUrl, options.accessToken, options.userID).then(results => {
                //         // console.log("sleep results[0]------------------>", results[0]);
                //         if (results[0].errors && (results[0].errors.length > 0)) {
                //             return {};
                //         }
                //         else {
                //             return results[0];
                //         }
                //     });
                //     return weightData;
                // }),
                user:
                co(function* () {
                    var weightUrl = constantsObj.fitbitApiBaseUrl.user;
                    let weightData = yield client.get(weightUrl, options.accessToken, options.userID).then(results => {
                         console.log("user results[0]------------------>", results[0]);
                        if (results[0] && results[0].user)
                            return (results[0].user);
                        else
                            return {};
                    });
                    return weightData;
                }),
                foodLogs:
                co(function* () {
                    var weightUrl = constantsObj.fitbitApiBaseUrl.food + endDate + '.json';
                    let weightData = yield client.get(weightUrl, options.accessToken, options.userID).then(results => {
                        console.log("user results[0] ------------------>", results[0]);
                       // console.log("results[0].foods------------------>", results[0].foods);
                        let obj = {};
                        if (results[0].summary) {
                            obj.summary = results[0].summary;
                        }
                        if (results[0].foods) {
                            obj.foods = [];
                            (results[0].foods).forEach((item) => {
                           //     console.log("element--->", item);
                                obj.foods.push(item.loggedFood);
                            });
                        }
                        return (obj);
                    });
                    return weightData;
                }),
            };


            // console.log("----------fitbitData----------");
            console.log(fitbitData);
            let postData = {
                'patient_id': oauthSettings.patientId,
                'device_id': oauthSettings.deviceId,
                'measures': fitbitData,
                'fitbit_measures_date': endDate,
            }
            if (patientDevConf.last_sync) {
                console.log("patientDevConf.last_sync------------------>>>>>>", patientDevConf.last_sync);
                var today = moment().format('YYYY-MM-DD');
                if (patientDevConf.last_sync == today) {
                    let postData = { 'measures': fitbitData, 'fitbit_measures_date': endDate }
                    console.log("endDate-->", endDate);
                    let data = yield PatientActivity.findOneAndUpdate({
                        patient_id: oauthSettings.patientId,
                        device_id: oauthSettings.deviceId,
                        fitbit_measures_date: endDate
                    }, {
                            $set: postData
                        }).exec();
                    console.log("data in update of patient activiy--------->", data);
                } else {
                    var patientActivity = new PatientActivity(postData);
                    let data = yield patientActivity.save();
                    console.log("data in save of patient activiy--------->", data);
                }
            }
            else {
                let postData = {
                    'patient_id': oauthSettings.patientId,
                    'device_id': oauthSettings.deviceId,
                    'measures': fitbitData,
                    'fitbit_measures_date': endDate,
                }
                var patientActivity = new PatientActivity(postData);
                let data = yield patientActivity.save();
                console.log("data in save of patient activiy--------->", data);
            }
            let patientDevConfig = yield PatientDeviceConfig.findOneAndUpdate({ _id: devId }, {
                $set: { last_sync: endDate }
            }).exec();
            //  return res.json({ 'code': 200, status: 'success', "message": '', "data": fitbitData });
            if (redirect) {
                res.redirect('/#!/deviceList');
            } else {
                res.json({
                    code: config.httpSuccess,
                    message: 'Fitbit records synctronised successfully.'
                });
            }
        }
    }).catch(function (err) {
        console.log("syncFitbit err-->", err);
        return res.json(Response(402, "failed", utility.validationErrorHandler(err), err));
    });
}

function verifyCode(req, res) {
    console.log('req.query verifyCode--->', req.query.verify);
    var verficationcode = "5350b3c98b5a7c4f3436df8403254fd0a62346d961b9d4da315e4a2b77b91fb2";
    if(req.query.verify == verficationcode){
           console.log("-------------verification successfull--------------");
           return res.status(204).end();
    }
    else{
        console.log("-------------verification un----successfull--------------");
        return res.status(404).end();
    }
}
// PatientDeviceConfig.findOne({ _id: devId }).exec(function (err, patientDevConf) {
//     if (err) {
//         res.json({
//             code: config.httpUnauthorize,
//             message: err
//         });
//     } else {
//         if (patientDevConf.last_sync) {
//             console.log("patientDevConf.last_sync------------------>>>>>>", patientDevConf.last_sync);
//             var today = moment().format('YYYY-MM-DD');
//             if (patientDevConf.last_sync == today) {
//                 res.json({
//                     code: config.httpSuccess,
//                     message: 'Records already synctronised.'
//                 });
//                 return false;
//             } else {
//                 var startDate = moment(patientDevConf.last_sync).add(1, 'day').format('YYYY-MM-DD');
//             }
//         } else {
//             var startDate = '0';
//         }
//         var endDate = moment().format('YYYY-MM-DD');
//         var activityUrl = "/activities/date/" + endDate + '.json';
//         console.log("url--->", activityUrl);
//         var fitbitData = yield {
//             avgStartToTriageDone:
//             co(function* () {
//             }
//                 };
//         client.get(activityUrl, options.accessToken, options.userID).then(results => {
//             console.log("activityUrl results------------------>", results);
//             console.log("activityUrl results[0]------------------>", results[0]);

//             // res.send(results[0]);
//         });

//     }
// });


// function getPatientDashboardCount(req, res) {
//     co(function* () {
//         //   console.log("req.body.timeRangeType:--->", req.body.timeRangeType);

//         var counts = yield {
//             enteredEmc: Visit.find({ "updatedAt": { "$gte": lowerTimeLimit, "$lte": upperTimeLimit }, visitIsClosed: 0, currentStatus: constantsObj.statusId.WAITING_FOR_NURSE }).count(),
//             triageDone: Visit.find({ "updatedAt": { "$gte": lowerTimeLimit, "$lte": upperTimeLimit }, visitIsClosed: 0, currentStatus: { $in: [constantsObj.statusId.AT_NURSE, constantsObj.statusId.WAITING_FOR_DOCTOR] } }).count(),
//             drSaw: Visit.find({ "updatedAt": { "$gte": lowerTimeLimit, "$lte": upperTimeLimit }, visitIsClosed: 0, currentStatus: { $in: [constantsObj.statusId.AT_DOCTOR, constantsObj.statusId.WAITING_FOR_CLOSURE, constantsObj.statusId.IN_TREATEMENT] } }).count(),
//             treatmentDone: Visit.find({ "updatedAt": { "$gte": lowerTimeLimit, "$lte": upperTimeLimit }, $or: [{ visitIsClosed: 1 }, { currentStatus: { $in: [constantsObj.statusId.COMPLETED, constantsObj.statusId.COMPLETED_UNPAID] } }] }).count(),
//             avgStartToTriageDone:
//             co(function* () {

//                 return Math.round(avg);
//             }),
//             avgNurseExamDoneToDrSaw:
//             co(function* () {
//                 let visitList = yield Visit.find({ "updatedAt": { "$gte": lowerTimeLimit, "$lte": upperTimeLimit }, visitIsClosed: 0 }).exec();
//                 console.log("visitList --->", visitList);
//                 var diffTimeTriageDoneToDrSaw = [];
//                 for (var i = 0; i < visitList.length; i++) {
//                     console.log(" Visit list value for:  " + i + "------------>" + visitList[i]);
//                     let stageData = yield VisitStage.findOne({ visitId: visitList[i]._id });
//                     console.log("stageData for--->" + i + "----->" + stageData);
//                     var mainstageData = stageData.mainStage;
//                     var WaitingForDoctorTime = '';
//                     var AtDoctor = '';
//                     for (var j = 0; j < mainstageData.length; j++) {
//                         //WAITING_FOR_DOCTOR    
//                         if (mainstageData[j].name == constantsObj.statusId.WAITING_FOR_DOCTOR) {
//                             if (mainstageData[j].createdAt) {
//                                 WaitingForDoctorTime = mainstageData[j].createdAt;
//                             }
//                         }
//                         //AT_DOCTOR  AT_DOCTOR
//                         else if (mainstageData[j].name == constantsObj.statusId.AT_DOCTOR) {
//                             if (mainstageData[j].createdAt) {
//                                 AtDoctor = mainstageData[j].createdAt;
//                             }
//                         }
//                     }
//                     if (WaitingForDoctorTime != '' && AtDoctor != '') {
//                         console.log("WaitingForDoctorTime:--->", WaitingForDoctorTime);
//                         console.log("AtDoctor:--->", AtDoctor);
//                         var minuteDiff = moment(AtDoctor).diff(WaitingForDoctorTime, 'minutes');
//                         console.log("Diff:--->", minuteDiff);
//                         diffTimeTriageDoneToDrSaw.push(minuteDiff);
//                     }
//                 }

//                 var total = 0;
//                 for (var i = 0; i < diffTimeTriageDoneToDrSaw.length; i++) {
//                     total += diffTimeTriageDoneToDrSaw[i];
//                 }
//                 var avg = 0;
//                 if (total > 0) {
//                     avg = total / diffTimeTriageDoneToDrSaw.length;
//                 }
//                 return Math.round(avg);
//             }),
//             avgTimeVisitStartToEnd:
//             co(function* () {
//                 // let visitList = yield Visit.find({ "updatedAt": { "$gte": lowerTimeLimit, "$lte": upperTimeLimit }, visitIsClosed: 1 }).exec();
//                 let visitList = yield Visit.find({ "updatedAt": { "$gte": lowerTimeLimit, "$lte": upperTimeLimit }, "visitEnd": { "$lte": upperTimeLimit }, visitIsClosed: 1 }).exec();
//                 console.log("visitList --->", visitList);
//                 var diffVisitStartToEnd = [];
//                 for (var i = 0; i < visitList.length; i++) {
//                     console.log(" Visit list value for:  " + i + "------------>" + visitList[i]);
//                     var minuteDiff = moment(visitList[i].visitEnd).diff(moment(visitList[i].visitStart), 'minutes');
//                     diffVisitStartToEnd.push(minuteDiff);
//                 }
//                 var total = 0;
//                 console.log("diffVisitStartToEnd --->", diffVisitStartToEnd);
//                 for (var i = 0; i < diffVisitStartToEnd.length; i++) {
//                     total += diffVisitStartToEnd[i];
//                 }
//                 console.log("total --->", total);
//                 var avg = 0;
//                 if (total > 0) {
//                     avg = total / diffVisitStartToEnd.length;
//                 }
//                 console.log("avg --->", avg);
//                 return Math.round(avg);
//             })
//         };
//         console.log(counts);
//         return res.json({ 'code': 200, status: 'success', "message": constantsObj.messages.dataRetrievedSuccess, "data": counts });
//     }).catch(function (err) {
//         console.log("getPatientDashboardCount err-->", err);
//         return res.json(Response(402, "failed", utility.validationErrorHandler(err), err));
//     });
// }

























// var sess = {
//     secret: 'keyboard cat',
//     cookie: {}
// },
//     userId;

// app.use(bodyParser.json());
// app.use(session(sess));
// app.use(cookieParser());

// app.set('port', (process.env.PORT || 5000));
// app.use(express.static(__dirname + '/public'));

// // Fitbit initialization
// fitbitClient.init(
//     process.env.FITBIT_CONSUMER_KEY,
//     process.env.FITBIT_CONSUMER_SECRET,
//     process.env.FITBIT_CALLBACK_URL);

// // Routes
// app.get('/', function (request, response) {
//     fitbitClient.getRequestToken(function (error, oauth_token, oauth_token_secret, results) {
//         if (error) {
//             console.log('error' + error);
//         } else {
//             request.session.oauth_token = oauth_token;
//             request.session.oauth_token_secret = oauth_token_secret;
//             response.redirect(fitbitClient.getAuthorizeURL(oauth_token));
//         }
//     });
// });


// app.get('/authorizationcompleted', function (request, response) {
//     fitbitClient.getAccessToken(request.session.oauth_token, request.session.oauth_token_secret, request.param('oauth_verifier'),
//         function (error, oauth_access_token, oauth_access_token_secret, results) {
//             if (error) {
//                 console.log('error ' + error);
//             } else {
//                 request.session.oauth_access_token = oauth_access_token;
//                 request.session.oauth_access_token_secret = oauth_access_token_secret;

//                 fitbitClient.setToken(oauth_access_token);
//                 fitbitClient.setTokenSecret(oauth_access_token_secret);

//                 userId = results.encoded_user_id;

//                 fitbitClient.requestResource('/profile.json', 'GET', oauth_access_token, oauth_access_token_secret, results.encoded_user_id,
//                     function (error, data, result) {
//                         var feed = JSON.parse(data);
//                         response.send(feed);
//                     }
//                 );
//             }
//         }
//     );
// });


// app.get('/getWeight', function (request, response) {
//     fitbitClient.requestResource(
//         '/body/log/weight/date/2015-03-01/30d.json',
//         'GET',
//         fitbitClient.getToken(),
//         fitbitClient.getTokenSecret(),
//         userId,
//         function (error, data, result) {
//             var feed = JSON.parse(data);
//             response.send(feed);
//         }
//     );
// });

// app.listen(app.get('port'), function () {
//     console.log("Node app is running at localhost:" + app.get('port'));
// });

























// 'use strict';

// var config = require('../../config/config.js'),
//     mongoose = require('mongoose'),
//     Roles = mongoose.model('Role'),
//     User = mongoose.model('User'),
//     Rule = mongoose.model('Rule'),
//     Patient = mongoose.model('Patient'),
//     PatientActivity = mongoose.model('PatientActivity'),
//     co = require('co'),
//     utility = require('../lib/utility.js'),
//     async = require('async'),
//     constantsObj = require('../lib/constants'),
//     PatientDeviceConfig = mongoose.model('PatientDeviceConfig');
// var moment = require('moment');
// // var client = new Fitbit(config.CONSUMER_KEY_FITBIT, config.CONSUMER_SECRET_FITBIT);
// const FitbitApiClient = require("fitbit-node");


// const client = new FitbitApiClient({
// 	clientId: "22CPZR",
// 	clientSecret: "64bb2deb347996423e4e78aaa4f48933",
// 	apiVersion: '1.2' // 1.2 is the default
// });

// module.exports = {
//     authRequestfitbit: authRequestfitbit,
//   //  oauth_fitbit_callback: oauth_fitbit_callback,
// };




// /**
//  * [createfcst - create fcstrcos]
//  * @param  {json body} req
//  * @param  {object} res
//  * @return {json}
//  */
// function authRequestfitbit(req, res) {
//     console.log('req.query', req.query.deviceId);
//     console.log(req.user.id);
//     var baseUrl = req.protocol + '://' + req.get('host');
//     var callbackUrl = baseUrl + config.CALLBACK_URL;
//     console.log('baseUrl', baseUrl);
//     console.log("callbackUrl", callbackUrl);
//     if (req.query.deviceId && req.user.id) {
//         Patient.findOne({ user_id: req.user.id }).exec(function (err, patient) {
//             if (err) {
//                 res.json({
//                     code: config.httpUnauthorize,
//                     message: err
//                 });
//             } else {
//                 var patientId = patient._id;
//                 req.session.oauth = {
//                     'patientId': patientId,
//                     'deviceId': req.query.deviceId
//                 };
//                 PatientDeviceConfig.findOne({ device_id: req.query.deviceId, patient_id: patientId }).exec(function (err, patientDevConf) {
//                     console.log("patientDevConf", err, patientDevConf);
//                     if (err) {
//                         res.json({
//                             code: config.httpUnauthorize,
//                             message: err
//                         });
//                     } else if (patientDevConf) {
//                         console.log("patientDevConf44", err, patientDevConf);
//                         var options = {
//                             consumerKey: config.CONSUMER_KEY,
//                             consumerSecret: config.CONSUMER_SECRET,
//                             accessToken: patientDevConf.accessToken,
//                             accessTokenSecret: patientDevConf.accessTokenSecret,
//                             userID: patientDevConf.withing_user_id
//                         };
//                         var redirect = false;
//                         syncwithing(req, res, options, redirect, patientDevConf._id);

//                     } else {
//                         var options = {
//                             consumerKey: '',
//                             consumerSecret: config.CONSUMER_SECRET,
//                             callbackUrl: callbackUrl
//                         };
//                         //var client = new FitbitApiClient();
//                         console.log("options 11", client);


//                         client.getAccessToken(function (err, token, tokenSecret) {
//                             console.log("getRequestToken------------withing--33------->>>>", err, token, tokenSecret);

//                             if (err) {
//                                 // Throw error
//                                 return;
//                             }
//                             req.session.oauth = {
//                                 'requestToken': token,
//                                 'requestTokenSecret': tokenSecret,
//                                 'patientId': patientId,
//                                 'deviceId': req.query.deviceId
//                             };
//                             res.json({
//                                 code: config.httpSuccess,
//                                 url: client.getAuthorizeUrl('activity heartrate location nutrition profile settings sleep social weight', callbackUrl),
//                             });

//                             //res.redirect(client.authorizeUrl(token, tokenSecret));
//                         });
//                     }
//                 });
//             }
//         })
//     } else {
//         res.json({
//             code: config.httpUnauthorize,
//             message: 'Invalid request, Please try again later.',
//         });
//     }
// }

// /**
//  * [createfcst - create fcstrcos]
//  * @param  {json body} req
//  * @param  {object} res
//  * @return {json}
//  */
// function oauth_callback(req, res) {
//     console.log('req.query', req.query);
//     var baseUrl = req.protocol + '://' + req.get('host');
//     var callbackUrl = baseUrl + config.CALLBACK_URL;
//     var verifier = req.query.oauth_verifier
//     var oauthSettings = req.session.oauth
//     var options = {
//         consumerKey: config.CONSUMER_KEY,
//         consumerSecret: config.CONSUMER_SECRET,
//         callbackUrl: callbackUrl,
//         userID: req.query.userid
//     };
//     var client = new Withings(options);
//     // Request an access token
//     client.getAccessToken(oauthSettings.requestToken, oauthSettings.requestTokenSecret, verifier,
//         function (err, token, secret) {
//             console.log("xxxxxxxxxxxxxxxxxxxxxx", token, secret);
//             if (err) {
//                 //error
//                 /*res.json({
//                     code: config.httpUnauthorize,
//                     message: err,
//                 });*/
//                 res.redirect('/#!/deviceList');
//             }
//             var postData = {
//                 'accessToken': token,
//                 'accessTokenSecret': secret,
//                 'withing_user_id': req.query.userid,
//                 'patient_id': oauthSettings.patientId,
//                 'device_id': oauthSettings.deviceId
//             }
//             PatientDeviceConfig.findOneAndUpdate({ patient_id: oauthSettings.patientId, device_id: oauthSettings.deviceId }, {
//                 $set: postData
//             }, { upsert: true, new: true }, function (err, data) {
//                 if (err) {
//                     res.redirect('/#!/deviceList');
//                 } else {
//                     console.log(err, data);
//                     var options = {
//                         consumerKey: config.CONSUMER_KEY,
//                         consumerSecret: config.CONSUMER_SECRET,
//                         accessToken: token,
//                         accessTokenSecret: secret,
//                         userID: req.query.userid
//                     };
//                     //***Create notification****//
//                     var client = new Withings(options);
//                     /////Body Scale
//                     //var callbackNotify = encodeURI(baseUrl + '/api/v1/notifyScaleActivity');
//                     var callbackNotify = baseUrl + '/notifyScaleActivity';
//                     console.log('callbackNotify url', callbackNotify);
//                     var comment = 'Notify when body scale records change';
//                     client.createNotification(callbackNotify, comment, 1, function (err, data) {
//                         console.log('notifyScaleActivity', data, err);
//                     });
//                     /////BP monitor
//                     //var callbackNotify = encodeURI(baseUrl + '/notifyBpActivity');
//                     var callbackNotify = baseUrl + '/notifyBpActivity';
//                     var comment = 'Notify when blood pressure records change';
//                     client.createNotification(callbackNotify, comment, 4, function (err, data) {
//                         console.log('notifyBpActivity', data, err);
//                     });
//                     /////Activity Measure
//                     //var callbackNotify = encodeURIComponent(baseUrl + '/notifyBodyActivity');
//                     var callbackNotify = baseUrl + '/notifyBodyActivity';
//                     var comment = 'Notify when body activity records change';
//                     client.createNotification(callbackNotify, comment, 16, function (err, data) {
//                         console.log('notifyBodyActivity', data, err);
//                     });
//                     /////Sleep monitor
//                     //var callbackNotify = encodeURIComponent(baseUrl + '/api/v1/notifySleepActivity');
//                     var callbackNotify = baseUrl + '/notifySleepActivity';
//                     var comment = 'Notify sleep records change';
//                     client.createNotification(callbackNotify, comment, 44, function (err, data) {
//                         console.log('notifySleepActivity', data, err);
//                     });
//                     //***End create notification***//
//                     var redirect = true;
//                     syncwithing(req, res, options, redirect, data._id);
//                 }
//             })
//         }
//     );
// }

// // function authRequestfitbit(req, res) {
// //     console.log('req.query', req.query.deviceId);
// //     console.log(req.user.id);
// //     var baseUrl = req.protocol + '://' + req.get('host');
// //     var callbackUrl = baseUrl + config.CALLBACK_URL_FITBIT;
// //     console.log('baseUrl', baseUrl);
// //     console.log("callbackUrl", callbackUrl);
// //     if (req.query.deviceId && req.user.id) {
// //         Patient.findOne({ user_id: req.user.id }).exec(function (err, patient) {
// //             console.log("patient", patient);
// //             if (err) {
// //                 res.json({
// //                     code: config.httpUnauthorize,
// //                     message: err
// //                 });
// //             } else {
// //                 var patientId = patient._id;
// //                 req.session.oauth = {
// //                     'patientId': patientId,
// //                     'deviceId': req.query.deviceId
// //                 };
// //                 PatientDeviceConfig.findOne({ device_id: req.query.deviceId, patient_id: patientId }).exec(function (err, patientDevConf) {
// //                     console.log("patientDevConf----------1", err, patientDevConf);
// //                     if (err) {
// //                         console.log("patientDevConf----------2", err);
// //                         res.json({
// //                             code: config.httpUnauthorize,
// //                             message: err
// //                         });
// //                     } else if (patientDevConf) {
// //                         console.log("patientDevConf----------3", patientDevConf);
// //                         var options = {
// //                             consumerKey: config.CONSUMER_KEY_FITBIT,
// //                             consumerSecret: config.CONSUMER_SECRET_FITBIT,
// //                             accessToken: patientDevConf.accessToken,
// //                             accessTokenSecret: patientDevConf.accessTokenSecret,
// //                             userID: patientDevConf.withing_user_id
// //                         };
// //                         var redirect = false;
// //                         syncwithing(req, res, options, redirect, patientDevConf._id);

// //                     } else {
// //                         var options = {
// //                             consumerKey: config.CONSUMER_KEY_FITBIT,
// //                             consumerSecret: config.CONSUMER_SECRET_FITBIT,
// //                             callbackUrl: callbackUrl
// //                         };
// //                         var client = new Fitbit(options);
// //                         console.log("options 11", options);
// //                         client.getRequestToken(function (err, token, tokenSecret) {
// //                             console.log("getRequestToken----------fitbit--------33--->>>>", err, token, tokenSecret)
// //                             if (err) {
// //                                 // Throw error
// //                                 return;
// //                             }
// //                             req.session.oauth = {
// //                                 'requestToken': token,
// //                                 'requestTokenSecret': tokenSecret,
// //                                 'patientId': patientId,
// //                                 'deviceId': req.query.deviceId
// //                             };
// //                             res.json({
// //                                 code: config.httpSuccess,
// //                                 url: client.authorizeUrl(token, tokenSecret),
// //                             });

// //                             //res.redirect(client.authorizeUrl(token, tokenSecret));
// //                         });
// //                     }
// //                 });
// //             }
// //         })
// //     } else {
// //         res.json({
// //             code: config.httpUnauthorize,
// //             message: 'Invalid request, Please try again later.',
// //         });
// //     }
// // }


// // FitbitApiClient {
// //   apiVersion: '1.2',
// //   oauth2: 
// //    { authorizationCode: 
// //       { authorizeURL: [Function: authorizeURL],
// //         getToken: [Function: getToken] },
// //      ownerPassword: { getToken: [Function: getToken] },
// //      clientCredentials: { getToken: [Function: getToken] },
// //      accessToken: { create: [Function: createAccessToken] } } }
