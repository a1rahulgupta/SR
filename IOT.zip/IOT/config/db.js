'use strict';

/* DB */
var mongoose = require('mongoose');
require('../api/models/Roles');
require('../api/models/Rules');
require('../api/models/Users');
require('../api/models/Ambulance');
require('../api/models/AmbulatoryActions');
require('../api/models/AmbulatoryMessages');
require('../api/models/AssesmentQuestionOptions');
require('../api/models/AssesmentQuestions');
require('../api/models/CareCoordinators');
require('../api/models/Clinicians');
require('../api/models/Conversations');
require('../api/models/Devices');
require('../api/models/Diseases');
require('../api/models/Emails');
require('../api/models/Hospitals');
require('../api/models/HospitalsAmbulances');
require('../api/models/IvrSettings');
require('../api/models/LabTests');
require('../api/models/Messages');
require('../api/models/PatientActivities');
require('../api/models/PatientAllergicReactions');
require('../api/models/PatientAssessments');
require('../api/models/PatientChronicDiseases');
require('../api/models/PatientDemographics');
require('../api/models/PatientDiseases');
require('../api/models/PatientDeviceConfigs');
require('../api/models/PatientEncounter');
require('../api/models/PatientFamilyHistories');
require('../api/models/PatientInsurances');
require('../api/models/PatientMedications');
require('../api/models/PatientSurgeries');
require('../api/models/PatientVitals');
require('../api/models/Populations');
require('../api/models/Prescriptions');
require('../api/models/TowingMessages');
require('../api/models/Towings');
require('../api/models/VideoCallRequests');
require('../api/models/Patients');
require('../api/models/TowingReqActions');
require('../api/models/RiskAssessments');
require('../api/models/Ethnicities');
require('../api/models/DiabetesStatus');
require('../api/models/SmokingStatus');
require('../api/models/Country');
require('../api/models/ServiceType');
require('../api/models/Ecgmeasures');
require('../api/models/Ecgfiles');
require('../api/models/OrderTests');
require('../api/models/CarePlans');
require('../api/models/AssesQuestionFile');
require('../api/models/Language');
require('../api/models/Appointment');
require('../api/models/EmailTemplates');
require('../api/models/PatientReports');
require('../api/models/AssignQuestions');
require('../api/models/DeviceManagement');
require('../api/models/RulesEngines');
require('../api/models/EmailsHistory');
require('../api/models/HospitalAssign');
require('../api/models/SMSHistory');
require('../api/models/EmailMessage');
require('../api/models/SmsTemplate');
require('../api/models/SmsTemplateAdmin');
require('../api/models/VideoHistory');
require('../api/models/VideoCallStatus');

var uri = (process.env.NODE_ENV == 'production') ? 'mongodb://52.34.207.5:27017/iotied' : 'mongodb://52.34.207.5:27017/iotied';
var options = (process.env.NODE_ENV == 'production') ? {
    user: 'iotied',
    pass: 'iotied87656!!',
    promiseLibrary: require('bluebird')
} : {
    user: 'iotied',
    pass: 'iotied87656!!',
    promiseLibrary: require('bluebird')
};


//server connection
mongoose.connect(uri, options);
mongoose.Promise = global.Promise;
var db = mongoose.connection;
// mongoose.set('debug', true);
db.on('error', console.error.bind(console, 'database connection error:'));
db.once('open', function (callback) {
    console.log('Database connection successful!');
});
/* end DB */
