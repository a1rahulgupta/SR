"use strict";
angular.module("Login", []);
angular.module("Dashboard", []);
angular.module("Hospital", []);
angular.module("Appointment", []);
angular.module("SelfAssesmentQuestions", []);
angular.module("Chat", []);
angular.module("videoChat", []);

var iotiedApp = angular.module('iotiedApp', ['ui.router', 'ui.bootstrap', 'oc.lazyLoad', 'ui.tinymce', 'toastr', 'ngRoute', 'ngStorage', 'ngTable', 'ngResource', 'ngTagsInput', 'ngIntlTelInput', 'ngSanitize', 'Login', 'Dashboard', 'Hospital', 'SelfAssesmentQuestions', 'Appointment', 'Chat', 'videoChat', 'angularMoment'])
    .config(['$routeProvider', '$httpProvider', '$locationProvider', '$stateProvider', '$urlRouterProvider', '$qProvider', function (
        $routeProvider, $httpProvider, $locationProvider, $stateProvider, $urlRouterProvider, $qProvider) {

        $qProvider.errorOnUnhandledRejections(false);

        $httpProvider.interceptors.push(function ($q, $location, $window) {
            return {
                request: function (config) {
                    config.headers = config.headers || {};
                    if ($window.localStorage && $window.localStorage.token) {
                        config.headers.Authorization = $window.localStorage.token;
                    }
                    //console.log($location.path());
                    if ($location.path() == '/forgot_password') {
                        config.headers.entity = 'Patient';
                    }
                    return config;
                },
                response: function (response) {
                    if (response.status !== 200) {
                        // handle the case where the user is not authenticated
                        //$location.path('/');
                    }
                    return response || $q.when(response);
                }
            };
        });
        //$urlRouterProvider.otherwise('/dashboard');
        $urlRouterProvider.otherwise('/');
        $stateProvider
            .state('login', {
                url: '/',
                views: {
                    'header': {
                        //templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/login/views/login.html',
                        controller: "loginController"
                    },
                    'footer': {
                        //templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                title: 'Login',
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/login/controller/loginController.js',
                            '/modules/login/services/loginService.js'
                        ]);

                    }
                },
                data: {
                    isAuthenticate: false
                }
            })
            .state('forgot', {
                url: '/forgot_password',
                views: {
                    'header': {
                        //templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/login/views/forgot_password.html',
                        controller: "loginController"
                    },
                    'footer': {
                        //templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                title: 'Forgot Password',
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/login/controller/loginController.js',
                            '/modules/login/services/loginService.js'
                        ]);

                    }
                },
                data: {
                    isAuthenticate: false
                }
            })
            .state('reset', {
                url: '/resetPassword/:token',
                views: {
                    'header': {
                        //templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/login/views/reset_password.html',
                        controller: "loginController"
                    },
                    'footer': {
                        //templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/login/controller/loginController.js',
                            '/modules/login/services/loginService.js'
                        ]);

                    }
                },
                data: {
                    isAuthenticate: false
                }
            })
            .state('dashboard', {
                url: '/dashboard',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/dashboard.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('appointmentList', {
                url: '/appointmentList',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/appointment/views/appointmentList.html',
                        controller: "appointmentController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/appointment/controller/appointmentController.js',
                            '/modules/appointment/services/appointmentService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('viewAppointment', {
                url: '/viewAppointment/:id',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/appointment/views/viewAppointment.html',
                        controller: "appointmentController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/appointment/controller/appointmentController.js',
                            '/modules/appointment/services/appointmentService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('bookAppointment', {
                url: '/bookAppointment',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/appointment/views/bookAppointment.html',
                        controller: "appointmentController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/appointment/controller/appointmentController.js',
                            '/modules/appointment/services/appointmentService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('deviceList', {
                url: '/deviceList',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/devicelist.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('addDevice', {
                url: '/addDevice',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/addDevice.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('updateProfile', {
                url: '/updateProfile',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/updateProfile.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('editDevice', {
                url: '/editDevice/:id',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/editDevice.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('activityData', {
                url: '/activities/:id',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/activity.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('activityFitbitData', {
                url: '/fitbitActivities/:id',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/fitbitActivity.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('videochat', {
                url: '/videochat',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/communication/views/videoChat.html',
                        controller: "videoController",
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },

                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/communication/controller/videoController.js',
                            '/modules/communication/services/videoService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('videochatIncoming', {
                url: '/videochatIncoming',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/communication/views/videoChatIncoming.html',
                        controller: "videoController",
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },

                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/communication/controller/videoController.js',
                            '/modules/communication/services/videoService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })


            .state('mail', {
                url: '/mail',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/mail/inbox.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },

                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('composemail', {
                url: '/composeMail',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/mail/compose.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('singleMail', {
                url: '/singleMail/:id',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/mail/single.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('sendMail', {
                url: '/sendMail',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/mail/sentBox.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('singleSentMail', {
                url: '/singleSentMail/:id',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/mail/singleSentMail.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            // ********************by sunny on 13-June-2017************************//
            .state('addPatientDemographics', {
                url: '/addPatientDemographics',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/addPatientDemographics.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('addInsuranceDetails', {
                url: '/addInsuranceDetails',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/addInsuranceDetails.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('patientVitals', {
                url: '/patientVitals',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/patientVitals.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('addPatientVitals', {
                url: '/addPatientVitals',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/addPatientVitals.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('addPatientEncounter', {
                url: '/addPatientEncounter',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/addPatientEncounter.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('addPatientAllergiesAndReactions', {
                url: '/addPatientAllergiesAndReactions',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/addPatientAllergiesAndReactions.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('addPatientMedication', {
                url: '/addPatientMedication',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/addPatientMedication.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('addPatientFamilyHistory', {
                url: '/addPatientFamilyHistory',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/addPatientFamilyHistory.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('addPatientSurgeries', {
                url: '/addPatientSurgeries',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/addPatientSurgeries.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })


            //**************************by sunny on 14-June-2017*****************//
            .state('addPatientChronicDisease', {
                url: '/addPatientChronicDisease',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/addPatientChronicDisease.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })


            //**************************by sunny on 15-June-2017*****************//
            .state('addPatientDisease', {
                url: '/addPatientDisease',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/addPatientDisease.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('hospitallogin', {
                url: '/hospital/login',
                views: {
                    'header': {
                        //templateUrl: '/modules/hospital/views/element/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/hospital/views/login.html',
                        controller: "loginController"
                    },
                    'footer': {
                        //templateUrl: '/modules/hospital/views/element/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/hospital/controller/loginController.js',
                            '/modules/hospital/services/loginService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: false
                }
            })

            .state('selfAssesmentQuestions', {
                url: '/selfAssesmentQuestions',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/selfAssesmentQuestion/views/selfAssesmentQuestions.html',
                        controller: "selfAssesmentController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/selfAssesmentQuestion/controller/selfAssesmentController.js',
                            '/modules/selfAssesmentQuestion/services/selfAssesmentService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            //***************************By sunny on 20-June-2017*****************************//
            .state('patient_register', {
                url: '/patient_register',
                views: {
                    'header': {
                        //templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/login/views/patient_register.html',
                        controller: "loginController"
                    },
                    'footer': {
                        //templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                title: 'Login',
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/login/controller/loginController.js',
                            '/modules/login/services/loginService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: false
                }
            })

            .state('uploadPatientReports', {
                url: '/uploadPatientReports',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/uploadReports.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('ivr', {
                url: '/ivr',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/ivrconf.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('chat', {
                url: '/chat',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/communication/views/chat.html',
                        controller: "chatController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/communication/controller/chatController.js',
                            '/modules/communication/services/chatService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('sms', {
                url: '/sms',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/sms/inbox.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('composeSms', {
                url: '/composeSms',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/sms/compose.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },

                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('sendSMSList', {
                url: '/sendSMSList',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/sms/sentBox.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('videoCall', {
                url: '/videoCall',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/videoCallUserList.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })


        //to remove the # from the URL
        //$locationProvider.html5Mode({enabled : true, requireBase : false});
    }])
    .run(['$rootScope', '$state', '$http', '$location', '$timeout', 'toastr', '$window',
        function ($rootScope, $state, $http, $location, $timeout, toastr, $window) {
            $rootScope.$on('$stateChangeStart', function (event, toState) {
                console.log($location.path(), toState.name);
                $rootScope.CurrPath = toState.name;
                //console.log(toState.name, toState.data.isAuthenticate);
                //if (toState.data.isAuthenticate == true) {
                if (!$window.localStorage.token && toState.data.isAuthenticate) {
                    event.preventDefault();
                    $state.go('login');
                }

                $http.get('/api/v1/auth/login_check')
                    .then(function (data) {
                        if (data.data.code == 200) {
                            var pathName = $window.location.pathname.toLowerCase();
                            var entity = data.data.data.role_id.name.toLowerCase();
                            entity = (entity == 'patient') ? ('/') : (entity);
                            if (pathName.indexOf(entity) === -1) {
                                event.preventDefault();
                                if (entity == 'patient') {
                                    var pathurl = '/';
                                } else {
                                    var pathurl = '/' + entity + '/';
                                }
                                window.location = '//' + $window.location.host + pathurl + '#!/dashboard';
                            }
                            $rootScope.User = data;
                            if (!toState.data.isAuthenticate) {
                                event.preventDefault();
                                $state.go('dashboard');
                            }
                            $rootScope.userLoggedin = true;
                            $rootScope.bodyclass = "skin-blue layout-top-nav fixed ng-scope";
                        } else {
                            $rootScope.bodyclass = "hold-transition login-page patientLoginBg";
                            $rootScope.userLoggedin = false;
                            delete $window.localStorage.token;
                            delete $window.localStorage.userLoggedin;
                            event.preventDefault();
                            if (toState.data.isAuthenticate) {
                                if ($location.path() != '/') {
                                    toastr.success('', 'Unfortunately you are logged out, please login again.');
                                }
                                $state.go('login');
                            } else {
                                // $state.go(toState.name);
                            }
                        }
                    });
                //}
            });
        }
    ])
    // Header controller
    .controller('headerCtrl', ['$scope', '$http', '$location', '$rootScope', '$window', 'toastr', '$state', 'socket',
        function ($scope, $http, $location, $rootScope, $window, toastr, $state, socket) {

            var join_name = {};
            join_name.name = "Patient - " + $window.localStorage.patientName;
            join_name.joinId = $window.localStorage.patientId;
            console.log("join_name",join_name);

            socket.on('testAlert', function (data) {
                console.log("response missed call----------->>>>>>>>>",data);
                console.log("$window.localStorage.patientId",$window.localStorage.patientId);

                if (data.id == $window.localStorage.patientId) {
                    var r = bootbox.confirm("Are you sure, you want to Join video call to " + " " + "<b>" + data.callerName + "</b>" + " ", function (r) {
                        if (r == true) {
                            socket.emit('accept_call', join_name);
                            $state.go('videochatIncoming');
                        } else {
                            socket.emit('reject_call', join_name);
                            $http.post('/api/v1/missedCall', { data:{'data':data}, headers: {  'Authorization': $window.localStorage.token } })
                                .then(function (response) {
                                    console.log("response missed call",response);
                                })
                        }
                    })
                }

            });



            $rootScope.menuprofile = ['addPatientDemographics', 'addInsuranceDetails', 'addPatientVitals', 'patientVitals'];
            $rootScope.menumedical = ['addPatientEncounter', 'addPatientAllergiesAndReactions', 'addPatientMedication', 'addPatientDisease', 'addPatientChronicDisease', 'addPatientFamilyHistory', 'addPatientSurgeries', 'uploadPatientReports'];
            $rootScope.menuwrdevice = ['deviceList', 'addDevice', 'activityData', 'editDevice'];
            $rootScope.menudashboard = ['updateProfile', 'dashboard'];
            $rootScope.menuappoint = ['bookAppointment', 'appointmentList', 'viewAppointment'];
            $rootScope.menumail = ['mail', 'sendMail'];
            $rootScope.menucommuniction = [];
            $rootScope.flag = false;

            // Get profile information
            $rootScope.getUserInfo = function () {
                $http.get('/api/v1/getPatientDetails', {
                    headers: {
                        'Authorization': $window.localStorage.token
                    }
                })
                    .then(function (response) {
                        if (response.data.code == 200) {
                            if (response.data.data.pflag == true) {
                                var user = {};
                                $rootScope.flag = true;

                                user.SSN = response.data.data.SSN;
                                user.first_name = response.data.data.first_name;
                                user.last_name = response.data.data.last_name;
                                user.age = response.data.data.age;
                                user.DOB = response.data.data.DOB;
                                user.gender = response.data.data.gender;
                                user.address = response.data.data.address;
                                user.city = response.data.data.city;
                                user.state = response.data.data.state;
                                user.zip_code = response.data.data.zip_code;
                                user.countryName = response.data.data.country.country_name;
                                user.mobile_no = response.data.data.mobile_no;
                                user.hospital_id = response.data.data.hospital_id;
                                user.smoker = response.data.data.smoker;
                                user.diabetes = response.data.data.diabetes;
                                user.bp_treatment = response.data.data.bp_treatment;
                                user.image = response.data.data.image;
                                if (response.data.data.smoker == true) {
                                    user.smoker = 'Yes';
                                } else {
                                    user.smoker = 'No';
                                }
                                if (response.data.data.diabetes == true) {
                                    user.diabetes = 'Yes';
                                } else {
                                    user.diabetes = 'No';
                                }
                                if (response.data.data.bp_treatment == true) {
                                    user.bp_treatment = 'Yes';
                                } else {
                                    user.bp_treatment = 'No';
                                }
                                user.image = response.data.data.image;
                                console.log("user", user);
                                $rootScope.userInfo = response.data.data;
                                $rootScope.user = user;
                            } else {
                                $rootScope.flag = false;
                                $rootScope.userInfo = response.data.data;
                                console.log("$rootScope.userInfo", $rootScope.userInfo);
                                var userData = {};
                                userData.first_name = response.data.data.first_name;
                                userData.last_name = response.data.data.last_name;
                                userData.mobile_no = response.data.data.mobile_no;
                                userData.image = response.data.data.image;
                                userData.gender = 'Male';
                                userData.smoker = 'No';
                                userData.diabetes = 'No';
                                userData.bp_treatment = 'No';
                                console.log("userData in app.js", userData);
                                $rootScope.userData = userData;
                            }
                        } else {
                            toastr.error('Something went wrong please try again !!!', 'Error');
                        }
                    });
            };

            $rootScope.getUnreadMailCount = function () {
                $http.get('/api/v1/getUnreadMailCount', {
                    headers: {
                        'Authorization': $window.localStorage.token
                    }
                })
                    .then(function (response) {
                        if (response.data.code == 200) {
                            $rootScope.unreadMailCount = response.data.data;
                        } else {
                            $rootScope.unreadMailCount = 0
                            //toastr.error('Something went wrong please try again !!!', 'Error');
                        }
                    });
            };
            $rootScope.getUnreadSmsCount = function () {
                $http.get('/api/v1/getUnreadSmsCount', {
                    headers: {
                        'Authorization': $window.localStorage.token
                    }
                })
                    .then(function (response) {
                        if (response.data.code == 200) {
                            $rootScope.unreadSmsCount = response.data.data;
                        } else {
                            $rootScope.unreadSmsCount = 0
                            //toastr.error('Something went wrong please try again !!!', 'Error');
                        }
                    });
            };
            $rootScope.getMissedVideoCount = function () {
                console.log("getMissedVideoCount");
                $http.get('/api/v1/getMissedVideoCount', {
                    headers: {
                        'Authorization': $window.localStorage.token
                    }
                })
                    .then(function (response) {
                        console.log("response---getMissedVideoCount----",response);
                        if (response.data.code == 200) {
                            $rootScope.missedVideoCall = response.data.data;
                        } else {
                            $rootScope.missedVideoCall = 0
                            //toastr.error('Something went wrong please try again !!!', 'Error');
                        }
                    });
            };


            $rootScope.getTollfreeNumber = function () {
                console.log("getTollfreeNumber");
                $http.get('/api/v1/getTollfreeNumber', {
                    headers: {
                        'Authorization': $window.localStorage.token
                    }

                }).then(function (response) {
                    if (response.data.code == 200) {
                        console.log("getTollfreeNumber", response);
                        $rootScope.tollfreeNo = response.data.data;
                    } else {
                        $rootScope.tollfreeNo = "-----";
                    }
                })
            }

            // if ($window.localStorage.token && $rootScope.userLoggedin) {
            //     $scope.getUserInfo();
            // }

            if ($window.localStorage.token) {
                $scope.getUserInfo();
            }

            if ($window.localStorage.userLoggedin) {
                $rootScope.userLoggedinnext = true;
                $rootScope.bodyclass = "skin-blue layout-top-nav fixed ng-scope";
            } else {
                $rootScope.bodyclass = "hold-transition login-page patientLoginBg";
            }
            // SignOut function
            $rootScope.logOut = function () {
                if ($window.localStorage.token) {
                    $http.get('/api/v1/auth/logout').then(function (data) {
                        if (data.data.code == 200) {
                             localStorage.clear();
                            // Erase the token if the user fails to log in
                            // delete $window.localStorage.token;
                            // delete $window.localStorage.patientId;
                            // delete $window.localStorage.userLoggedin;
                            $rootScope.userLoggedin = false;
                            //$location.path('/');
                            window.location = "/";
                            $rootScope.bodyclass = "hold-transition login-page patientLoginBg";
                            toastr.success('Logout', 'Logout successfully');
                        } else {
                            delete $window.localStorage.token;
                            delete $window.localStorage.patientId;
                            delete $window.localStorage.userLoggedin;
                            $scope.userLoggedin = false;
                            window.location = "/";
                            toastr.success('Logout', 'Logout successfully');
                            //toastr.error('Something went wrong please try again.!', 'Error');
                        }
                    });
                }
            };

            $rootScope.showww = function () {
                var dropd = document.getElementById("image-dropdown");
                dropd.style.height = "auto";
                dropd.style.overflow = "y-scroll";
            };

            $rootScope.hideee = function () {
                var dropd = document.getElementById("image-dropdown");
                dropd.style.height = "20px";
                dropd.style.overflow = "hidden";
            };

            $rootScope.myfuunc = function (imgParent) {
                $rootScope.hideee();
                var mainDIVV = document.getElementById("image-dropdown");
                imgParent.parentNode.removeChild(imgParent);
                mainDIVV.insertBefore(imgParent, mainDIVV.childNodes[0]);
            };

        }
    ])
    .filter('measureTypeWithings', function ($filter) {
        var types = [];
        types['1'] = 'Weight (kg)';
        types['4'] = 'Height (meter)';
        types['5'] = 'Fat Free Mass (kg)';
        types['6'] = 'Fat Ratio (%)';
        types['8'] = 'Fat Mass Weight (kg)';
        types['9'] = 'Diastolic Blood Pressure (mmHg)';
        types['10'] = 'Systolic Blood Pressure (mmHg)';
        types['11'] = 'Heart Pulse (bpm)';
        types['12'] = 'Temperature';
        types['54'] = 'SP02(%)';
        types['71'] = 'Body Temperature';
        types['73'] = 'Skin Temperature';
        types['76'] = 'Muscle Mass';
        types['77'] = 'Hydration';
        types['88'] = 'Bone Mass';
        types['91'] = 'Pulse Wave Velocity';

        return function (input) {
            //console.log(input);
            var string = '';
            for (var i = 0; i < input.length; i++) {
                var key = input[i].type;
                string += types[key] + ' : ' + input[i].value;
            }
            return string;
        };
    })
    .filter('displaymeasures', function ($filter) {
        return function (input, index) {
            //console.log(input,index);
            if (input.length > 0) {
                var string = '';
                for (var i = 0; i < input.length; i++) {
                    var obj = input[i];
                    if (obj.hasOwnProperty('dt' + index)) {
                        string += obj['dt' + index] + ', ';
                    }
                }
                if (string.length > 0) {
                    return string.slice(0, -2);
                } else {
                    return string;
                }

            } else {
                var string = '-';
                return string;
            }

        };
    })

    .filter('displayFitbitmeasures', function ($filter) {
        return function (input, index) {
            // console.log(input,index);
            if (input.length > 0) {
                var string = {};
                for (var i = 0; i < input.length; i++) {
                    var obj = input[i];
                    if (obj.hasOwnProperty('dt' + index)) {
                        console.log("displayFitbitmeasures obj----->", obj);
                        string = obj['dt' + index];
                        console.log("displayFitbitmeasures obj string ----->", string);
                        return string;
                        // string += obj['dt' + index] + ', ';
                    }
                }
                // if (string.length > 0) {
                //     return string.slice(0, -2);
                // } else {
                //     return string;    
                // }

            } else {
                var string = [];
                return string;
            }

        };
    })
    // Directive to calculate Age by sunny on 16-June-2017
    .directive('calculateAge', function () {
        return {
            restrict: 'E',

            link: function (scope, element, attrs) {
                var dob = attrs.dob.split('T');
                dob = dob[0].split('-');
                var birthDay = dob[2];
                var birthMonth = dob[1];
                var birthYear = dob[0];
                var todayDate = new Date();
                var todayYear = todayDate.getFullYear();
                var todayMonth = todayDate.getMonth();
                var todayDay = todayDate.getDate();
                var age = todayYear - birthYear;

                if (todayMonth < birthMonth - 1) {
                    age--;
                }

                if (birthMonth - 1 == todayMonth && todayDay < birthDay) {
                    age--;
                }
                scope.age = age;
            }
        }
    })
    .directive('compareTo', function () {
        return {
            require: "ngModel",
            scope: {
                otherModelValue: "=compareTo"
            },
            link: function (scope, element, attributes, ngModel) {

                ngModel.$validators.compareTo = function (modelValue) {
                    return modelValue == scope.otherModelValue;
                };
                scope.$watch("otherModelValue", function () {
                    ngModel.$validate();
                });
            }
        }
    })
    .factory('socket', function ($rootScope, $window) {
        var socket = io.connect($window.location.origin);
        socket.on('connect', function () {
            var id = socket.io.engine.id;
            console.log("$window.sessionStorage.userId------>", $window.localStorage.userLoggedin);
            console.log("$window.localStorage.patientId", $window.localStorage.patientId);
            if ($window.localStorage.userLoggedin == true) {
                socket.emit('join', $window.localStorage.patientId);
            }
        });

        return {
            on: function (eventName, callback) {
                socket.on(eventName, function () {
                    var args = arguments;
                    $rootScope.$apply(function () {
                        callback.apply(socket, args);
                    });
                });
            },
            emit: function (eventName, data, callback) {
                socket.emit(eventName, data, function () {
                    var args = arguments;
                    $rootScope.$apply(function () {
                        if (callback) {
                            callback.apply(socket, args);
                        }
                    });
                });
            }
        };
    })  