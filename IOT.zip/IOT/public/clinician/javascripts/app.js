"use strict";
angular.module("Login", []);
angular.module("Dashboard", []);
angular.module("Appointment", []);
angular.module("Ivr", []);
angular.module("Chat", []);
angular.module("videoChat", []);

var iotiedApp = angular.module('iotiedApp', ['ui.router', 'ui.bootstrap', 'ui.calendar', 'oc.lazyLoad', 'toastr', 'ngRoute', 'ngStorage', 'ngTable', 'ngResource', 'ui.tinymce', 'ngTagsInput', 'ngIntlTelInput', 'ngSanitize', 'Login', 'Dashboard', 'Appointment', 'Ivr', 'Chat', 'videoChat', 'angularMoment'])
    .config(['$routeProvider', '$httpProvider', '$locationProvider', '$stateProvider', '$urlRouterProvider', '$qProvider', function (
        $routeProvider, $httpProvider, $locationProvider, $stateProvider, $urlRouterProvider, $qProvider) {

        $qProvider.errorOnUnhandledRejections(false);

        $httpProvider.interceptors.push(function ($q, $location, $window) {
            return {
                request: function (config) {
                    config.headers = config.headers || {};
                    if ($window.localStorage && $window.localStorage.token) {
                        config.headers.Authorization = $window.localStorage.token;
                    }
                    if ($location.path() == '/forgot_password') {
                        config.headers.entity = 'Clinician';
                    }
                    return config;
                },
                response: function (response) {
                    if (response.status !== 200) {
                        // handle the case where the user is not authenticated
                        //$location.path('/');
                    }
                    return response || $q.when(response);
                }
            };
        });
        //$urlRouterProvider.otherwise('/dashboard');
        $urlRouterProvider.otherwise('/');
        $stateProvider
            .state('login', {
                url: '/',
                views: {
                    'header': {
                        //templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/login/views/login.html',
                        controller: "loginController"
                    },
                    'footer': {
                        //templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                title: 'Login',
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/login/controller/loginController.js',
                            '/clinician/modules/login/services/loginService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: false
                }
            })
            .state('forgot', {
                url: '/forgot_password',
                views: {
                    'header': {
                        //templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/login/views/forgot_password.html',
                        controller: "loginController"
                    },
                    'footer': {
                        //templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                title: 'Forgot Password',
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/login/controller/loginController.js',
                            '/clinician/modules/login/services/loginService.js'
                        ]);

                    }
                },
                data: {
                    isAuthenticate: false
                }
            })
            .state('reset', {
                url: '/resetPassword/:token',
                views: {
                    'header': {
                        //templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/login/views/reset_password.html',
                        controller: "loginController"
                    },
                    'footer': {
                        //templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/login/controller/loginController.js',
                            '/clinician/modules/login/services/loginService.js'
                        ]);

                    }
                },
                data: {
                    isAuthenticate: false
                }
            })
            .state('dashboard', {
                url: '/dashboard',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/dashboard.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('assignPatientList', {
                url: '/assignPatientList',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/assignPatientList.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('patientList', {
                url: '/patientList',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/patientList.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('addPatient', {
                url: '/addPatient',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/addPatient.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('editPatient', {
                url: '/editPatient/:id',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/addPatient.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('updateProfile', {
                url: '/updateProfile',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/updateProfile.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('orderTestList', {
                url: '/orderTestList/:id',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/orderTestList.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('carePlanList', {
                url: '/carePlanList/:id',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/carePlanList.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('appointmentList', {
                url: '/appointmentList',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/appointment/views/appointmentList.html',
                        controller: "appointmentController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/appointment/controller/appointmentController.js',
                            '/clinician/modules/appointment/services/appointmentService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('confirmAppointment', {
                url: '/confirmAppointment/:id',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/appointment/views/confirmAppointment.html',
                        controller: "appointmentController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/appointment/controller/appointmentController.js',
                            '/clinician/modules/appointment/services/appointmentService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('selfAssesmentQuestions', {
                url: '/selfAssesmentQuestions',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/selfAssesmentQuestion/views/selfAssesmentQuestions.html',
                        controller: "selfAssesmentController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/selfAssesmentQuestion/controller/selfAssesmentController.js',
                            '/modules/selfAssesmentQuestion/services/selfAssesmentService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            //***************************By sunny on 20-June-2017*****************************//
            .state('clinician_register', {
                url: '/clinician_register',
                views: {
                    'header': {
                        //templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/login/views/clinician_register.html',
                        controller: "loginController"
                    },
                    'footer': {
                        //templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                title: 'Login',
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/login/controller/loginController.js',
                            '/clinician/modules/login/services/loginService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: false
                }
            })
            .state('ivr', {
                url: '/ivr',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/ivr/views/setting.html',
                        controller: "ivrController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/ivr/controller/ivrController.js',
                            '/clinician/modules/ivr/services/ivrService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('videocallrequest', {
                url: '/video-call-request',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/ivr/views/videocallrequest.html',
                        controller: "ivrController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/ivr/controller/ivrController.js',
                            '/clinician/modules/ivr/services/ivrService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('vidyo', {
                url: '/vidyo',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/ivr/views/videochat.html',
                        controller: "ivrController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/ivr/controller/ivrController.js',
                            '/clinician/modules/ivr/services/ivrService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('videochat', {
                url: '/videochat',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/communication/views/videoChat.html',
                        controller: "videoController",
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },

                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/communication/controller/videoController.js',
                            '/clinician/modules/communication/services/videoService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('videochatIncoming', {
                url: '/videochatIncoming',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/communication/views/videoChatIncoming.html',
                        controller: "videoController",
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },

                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/communication/controller/videoController.js',
                            '/clinician/modules/communication/services/videoService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('chat', {
                url: '/chat',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/communication/views/chat.html',
                        controller: "chatController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/communication/controller/chatController.js',
                            '/clinician/modules/communication/services/chatService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            //mail section
            .state('mail', {
                url: '/mail',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/mail/inbox.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('composemail', {
                url: '/composeMail',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/mail/compose.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('singleMail', {
                url: '/singleMail/:id',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/mail/single.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('sendMail', {
                url: '/sendMail',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/mail/sentBox.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('singleSentMail', {
                url: '/singleSentMail/:id',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/mail/singleSentMail.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('sms', {
                url: '/sms',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/sms/inbox.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('composeSms', {
                url: '/composeSms',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/sms/compose.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('sendSMSList', {
                url: '/sendSMSList',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/sms/sentBox.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('call', {
                url: '/call',
                views: {
                    'header': {
                        templateUrl: '/clinician/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/clinician/modules/dashboard/views/videoCallUserList.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/clinician/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/clinician/modules/dashboard/controller/dashboardController.js',
                            '/clinician/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
        //sms section
        //to remove the # from the URL
        //$locationProvider.html5Mode({enabled : true, requireBase : false});
    }])
    .run(['$rootScope', '$state', '$http', '$location', '$timeout', 'toastr', '$window',
        function ($rootScope, $state, $http, $location, $timeout, toastr, $window) {
            $rootScope.$on('$stateChangeStart', function (event, toState) {
                // $rootScope.PUBLICURL = $PUBLICURL;   
                //if(toState.data.isAuthenticate==true){
                $rootScope.CurrPath = toState.name;
                if (!$window.localStorage.token && toState.data.isAuthenticate) {
                    event.preventDefault();
                    $state.go('login');
                }
                $http.get('/api/v1/auth/login_check')
                    .then(function (data) {
                        if (data.data.code == 200) {
                            var pathName = $window.location.pathname.toLowerCase();
                            var entity = data.data.data.role_id.name.toLowerCase();
                            if (pathName.indexOf(entity) === -1) {
                                event.preventDefault();
                                if (entity == 'patient') {
                                    var pathurl = '/';
                                } else {
                                    var pathurl = '/' + entity + '/';
                                }
                                window.location = '//' + $window.location.host + pathurl + '#!/dashboard';
                            }
                            $rootScope.User = data;
                            if (!toState.data.isAuthenticate) {
                                event.preventDefault();
                                $state.go('dashboard');
                            }
                            $rootScope.userLoggedin = true;
                            $rootScope.bodyclass = "skin-blue layout-top-nav fixed ng-scope";
                        } else {
                            $rootScope.bodyclass = "hold-transition login-page hospitalLoginBg";
                            $rootScope.userLoggedin = false;
                            delete $window.localStorage.clinicianId;
                            delete $window.localStorage.token;
                            delete $window.localStorage.userLoggedin;
                            event.preventDefault();
                            if (toState.data.isAuthenticate) {
                                if ($location.path() != '/') {
                                    toastr.success('', 'Unfortunately you are logged out, please login again.');
                                }
                                $state.go('login');
                            } else {
                                $state.go(toState.name);
                            }
                        }
                    });
                /*}
                else{

                }*/
            });
        }
    ])
    // Header controller
    .controller('headerCtrl', ['$scope', '$http', '$location', '$rootScope', '$window', 'toastr', '$state', 'socket',
        function ($scope, $http, $location, $rootScope, $window, toastr, $state, socket) {


            var join_name = {};
            join_name.name = "Clinician - " + $window.localStorage.clinicianName;
            join_name.joinId = $window.localStorage.clinicianId;
            console.log("join_name", join_name);

            socket.on('testAlert', function (data) {
                if (data.id == $window.localStorage.clinicianId) {
                    var r = bootbox.confirm("Are you sure, you want to Join video call to " + " " + "<b>" + data.callerName + "</b>" + " ", function (r) {
                        if (r == true) {
                            socket.emit('accept_call', join_name);
                            $state.go('videochatIncoming');
                        } else {
                            socket.emit('reject_call', join_name);
                            $http.post('/api/v1/missedCall', { data:{'data':data}, headers: {  'Authorization': $window.localStorage.token } })
                                .then(function (response) {
                                    console.log("response missed call",response);
                                })
                        }
                    })

                }
            });

            // if ($window.localStorage.token && $rootScope.userLoggedin) {
            //     $scope.getUserInfo();
            // }
            // Get profile information
            $rootScope.menuappointment = ['confirmAppointment', 'appointmentList'];
            $rootScope.menudashboard = ['orderTestList', 'carePlanList', 'dashboard', 'updateProfile'];
            $rootScope.menupatpopmng = ['patientList', 'editPatient'];
            $rootScope.menupatRelmng = ['ivr', 'videochat', 'videocallrequest'];
            $rootScope.menumail = ['mail', 'sendMail'];

            $scope.getUserInfo = function () {
                $http.get('/api/v1/getClinicianDetails', { headers: { 'Authorization': $window.localStorage.token } })
                    .then(function (response) {
                        if (response.data.code == 200) {
                            $rootScope.userInfo = response.data.data;
                            var userData = {};
                            userData.first_name = response.data.data.first_name;
                            userData.last_name = response.data.data.last_name;
                            userData.SSN = response.data.data.SSN;
                            userData.address = response.data.data.address;
                            userData.mobile_no = response.data.data.mobile_no;
                            userData.city = response.data.data.city;
                            userData.state = response.data.data.state;
                            userData.zip_code = response.data.data.zip_code;
                            userData.country = response.data.data.country;
                            userData.hospital_id = response.data.data.hospital_id;
                            userData.clinician_npi_no = response.data.data.clinician_npi_no;
                            userData.image = response.data.data.image;
                            $rootScope.userInfo = response.data.data;
                            $rootScope.userData = userData;
                            //console.log("$rootScope.userInfo", $rootScope.userInfo)

                        } else {
                            console.log('Something went wrong please try ==========again!!!', 'Error');
                        }
                    });
            };

            // if ($window.localStorage.token && $rootScope.userLoggedin) {
            //     $scope.getUserInfo();
            // }

            if ($window.localStorage.token) {
                $scope.getUserInfo();
            }


            if ($window.localStorage.userLoggedin) {
                $rootScope.userLoggedinnext = true;
                $rootScope.bodyclass = "skin-blue layout-top-nav fixed ng-scope";
            } else {
                $rootScope.bodyclass = "hold-transition login-page hospitalLoginBg";
            }
            // SignOut function
            $rootScope.logOut = function () {
                if ($window.localStorage.token) {
                    $http.get('/api/v1/auth/logout').then(function (data) {
                        if (data.data.code == 200) {
                            localStorage.clear();
                            // Erase the token if the user fails to log in
                            // delete $window.localStorage.token;
                            // delete $window.localStorage.clinicianId;
                            // delete $window.localStorage.userLoggedin;
                            $rootScope.userLoggedin = false;
                            //$location.path('/');
                            window.location = "/clinician/#!";
                            $window.location.reload();
                            $rootScope.bodyclass = "hold-transition login-page hospitalLoginBg";
                            toastr.success('Logout', 'Logout successfully');
                        } else {
                            delete $window.localStorage.token;
                            delete $window.localStorage.clinicianId;
                            delete $window.localStorage.userLoggedin;
                            $scope.userLoggedin = false;
                            window.location = "/";
                            toastr.success('Logout', 'Logout successfully');
                            //toastr.error('Something went wrong please try again.!', 'Error');
                        }
                    });
                }
            };

            $rootScope.showww = function () {
                var dropd = document.getElementById("image-dropdown");
                dropd.style.height = "auto";
                dropd.style.overflow = "y-scroll";
            };

            $rootScope.hideee = function () {
                var dropd = document.getElementById("image-dropdown");
                dropd.style.height = "20px";
                dropd.style.overflow = "hidden";
            };

            $rootScope.myfuunc = function (imgParent) {
                $rootScope.hideee();
                var mainDIVV = document.getElementById("image-dropdown");
                imgParent.parentNode.removeChild(imgParent);
                mainDIVV.insertBefore(imgParent, mainDIVV.childNodes[0]);
            };


            $rootScope.getUnreadMailCount = function () {
                $http.get('/api/v1/getUnreadMailCount', {
                    headers: {
                        'Authorization': $window.localStorage.token
                    }
                })
                    .then(function (response) {
                        if (response.data.code == 200) {
                            $rootScope.unreadMailCount = response.data.data;
                        } else {
                            $rootScope.unreadMailCount = 0
                            //toastr.error('Something went wrong please try again !!!', 'Error');
                        }
                    });
            };
            $rootScope.getUnreadSmsCount = function () {
                $http.get('/api/v1/getUnreadSmsCount', {
                    headers: {
                        'Authorization': $window.localStorage.token
                    }
                })
                    .then(function (response) {
                        if (response.data.code == 200) {
                            console.log("response", response);
                            $rootScope.unreadSmsCount = response.data.data;
                        } else {
                            $rootScope.unreadSmsCount = 0
                            //toastr.error('Something went wrong please try again !!!', 'Error');
                        }
                    });
            };
            $rootScope.getMissedVideoCount = function () {
                console.log("getMissedVideoCount");
                $http.get('/api/v1/getMissedVideoCount', {
                    headers: {
                        'Authorization': $window.localStorage.token
                    }
                })
                    .then(function (response) {
                        console.log("response---getMissedVideoCount----",response);
                        if (response.data.code == 200) {
                            $rootScope.missedVideoCall = response.data.data;
                        } else {
                            $rootScope.missedVideoCall = 0
                            //toastr.error('Something went wrong please try again !!!', 'Error');
                        }
                    });
            };

        }
    ])
    .filter('measureTypeWithings', function ($filter) {
        var types = [];
        types['1'] = 'Weight (kg)';
        types['4'] = 'Height (meter)';
        types['5'] = 'Fat Free Mass (kg)';
        types['6'] = 'Fat Ratio (%)';
        types['8'] = 'Fat Mass Weight (kg)';
        types['9'] = 'Diastolic Blood Pressure (mmHg)';
        types['10'] = 'Systolic Blood Pressure (mmHg)';
        types['11'] = 'Heart Pulse (bpm)';
        types['12'] = 'Temperature';
        types['54'] = 'SP02(%)';
        types['71'] = 'Body Temperature';
        types['73'] = 'Skin Temperature';
        types['76'] = 'Muscle Mass';
        types['77'] = 'Hydration';
        types['88'] = 'Bone Mass';
        types['91'] = 'Pulse Wave Velocity';

        return function (input) {
            //console.log(input);
            var string = '';
            for (var i = 0; i < input.length; i++) {
                var key = input[i].type;
                string += types[key] + ' : ' + input[i].value;
            }
            return string;
        };
    })
    .filter('displaymeasures', function ($filter) {
        return function (input, index) {
            //console.log(input,index);
            if (input.length > 0) {
                var string = '';
                for (var i = 0; i < input.length; i++) {
                    var obj = input[i];
                    if (obj.hasOwnProperty('dt' + index)) {
                        string += obj['dt' + index] + ', ';
                    }
                }
                if (string.length > 0) {
                    return string.slice(0, -2);
                } else {
                    return string;
                }

            } else {
                var string = '-';
                return string;
            }

        };
    })
    // Directive to calculate Age by sunny on 16-June-2017
    .directive('calculateAge', function () {
        return {
            restrict: 'E',
            link: function (scope, element, attrs) {
                var dob = attrs.dob.split('T');
                dob = dob[0].split('-');
                var birthDay = dob[2];
                var birthMonth = dob[1];
                var birthYear = dob[0];

                var todayDate = new Date();
                var todayYear = todayDate.getFullYear();
                var todayMonth = todayDate.getMonth();
                var todayDay = todayDate.getDate();
                var age = todayYear - birthYear;

                if (todayMonth < birthMonth - 1) {
                    age--;
                }

                if (birthMonth - 1 == todayMonth && todayDay < birthDay) {
                    age--;
                }
                scope.age = age;
            }
        }
    })

    .factory('socket', function ($rootScope, $window) {
        var socket = io.connect($window.location.origin);
        socket.on('connect', function () {
            var id = socket.io.engine.id;
            console.log("$window.sessionStorage.userId------>", $window.localStorage.userLoggedin);
            console.log("$window.localStorage.clinicianId", $window.localStorage.clinicianId);
            if ($window.localStorage.userLoggedin == true) {
                socket.emit('join', $window.localStorage.clinicianId);
            }
        });

        return {
            on: function (eventName, callback) {
                socket.on(eventName, function () {
                    var args = arguments;
                    $rootScope.$apply(function () {
                        callback.apply(socket, args);
                    });
                });
            },
            emit: function (eventName, data, callback) {
                socket.emit(eventName, data, function () {
                    var args = arguments;
                    $rootScope.$apply(function () {
                        if (callback) {
                            callback.apply(socket, args);
                        }
                    });
                });
            }
        };
    })  