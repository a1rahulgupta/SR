"use strict"

angular.module("Appointment")

.factory('AppointmentService', ['$http', '$resource', function($http, $resource) {

    var getAppointmentById = function() {
        return $resource('/api/v1/getAppointmentById/:id', null, {
            get: {
                method: 'GET'
            }
        });
    }
    var updateAppointment = function() {
        return $resource('/api/v1/updateAppointment', null, {
            save: {
                method: 'POST',
            }
        });
    }
    var getAllAppointmentByClinicianId = function(id) {
        return $resource('/api/v1/getAllAppointmentByClinicianId/', null, {
            save: {
                method: 'POST'
            }
        });
    }

    return {
        getAppointmentById: getAppointmentById,
        updateAppointment: updateAppointment,
        getAllAppointmentByClinicianId: getAllAppointmentByClinicianId
    }

}]);
