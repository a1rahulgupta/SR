"use strict";

angular.module('Appointment')
    .controller("appointmentController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', 'AppointmentService', 'toastr', '$uibModal', 'ngTableParams', 'ngTableParamsService',
        function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, AppointmentService, toastr, $uibModal, ngTableParams, ngTableParamsService) {

            $scope.getAppointmentById = function(id) {
                if (!id) {
                    id = $stateParams.id
                }
                AppointmentService.getAppointmentById().get({ id: id }, function(response) {
                    console.log("response.data", response.data);
                    if (response.code == 200) {
                        $scope.appointmentData = response.data;
                        $scope.appointmentData.appointment_status = '2';
                    } else {
                        toastr.error(response.message, 'Error');
                    }
                });
            }

            $scope.disableSubmitBtn = false;
            $scope.loader = false;
            $scope.updateAppointment = function() {
                if ($scope.form.$valid) {
                    $scope.disableSubmitBtn = true;
                    AppointmentService.updateAppointment().save($scope.appointmentData, function(response) {
                        console.log("response.data", response.data);
                        $scope.disableSubmitBtn = false;
                        if (response.code == 200) {
                            toastr.success(response.message);
                            $location.path('/appointmentList');
                        } else {
                            toastr.error(response.message, 'Error');
                        }
                    });
                }
            };

            $scope.getAllAppointmentByClinicianId = function() {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.appointmentList = [];
                        AppointmentService.getAllAppointmentByClinicianId().save($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.appointmentList = response.data;
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.getAllAppointmentByClinicianIdSearching = function() {
                ngTableParamsService.set('', '', $scope.searchTextField, '');
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.appointmentList = [];
                        AppointmentService.getAllAppointmentByClinicianId().save($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.appointmentList = response.data;
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }


        }
    ]);
