"use strict"

angular.module("Dashboard")

    .factory('dashboardService', ['$http', '$resource', function ($http, $resource) {

        var connectWithing = function () {
            return $resource('/api/v1/withings/connect', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var getDeviceList = function () {
            return $resource('/api/v1/getPatientDevice', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var activityList = function (deviceId, week) {
            return $resource('/api/v1/getPatientActivity/' + deviceId + '/' + week, null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var deletePatient = function (id) {
            return $resource('/api/v1/deletePatientById/' + id, null, {
                delete: {
                    method: 'DELETE',
                    id: '@id'
                }
            });
        }
        var addPatient = function () {
            return $resource('/api/v1/addPatientByClinician', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var addOrderTest = function () {
            return $resource('/api/v1/addOrderTest', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var getPatientById = function () {
            return $resource('/api/v1/getPatientByAdminId/:id', null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            });
        }

        var getAllOrderTestByPatientId = function () {
            return $resource('/api/v1/getAllOrderTestByPatientId/:id', null, {
                save: {
                    method: 'POST',
                    id: '@id'
                }
            });
        }

        var viewTestOrderById = function () {
            return $resource('/api/v1/viewTestOrderById/:id', null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            });
        }

        var getAllCarePlanByPatientId = function () {
            return $resource('/api/v1/getAllCarePlanByPatientId/:id', null, {
                save: {
                    method: 'POST',
                    id: '@id'
                }
            });
        }

        var viewCarePlanById = function () {
            return $resource('/api/v1/viewCarePlanById/:id', null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            });
        }

        var addCarePlan = function () {
            return $resource('/api/v1/addCarePlan', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var getAllPatient = function () {
            return $resource('/api/v1/getAllPatient', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var getAllPatientByClinicianId = function () {
            return $resource('/api/v1/getAllPatientByClinicianId', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var addDevice = function () {
            return $resource('/api/v1/addPatientDevice', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var editDevice = function (id) {
            return $resource('/api/v1/addPatientDevice', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientDemographics = function () {
            return $resource('/api/v1/addPatientDemographics', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var updateClinicianProfile = function () {
            return $resource('/api/v1/updateClinicianProfile', null, {
                save: {
                    method: 'POST',
                    headers: { 'Content-Type': undefined }
                }
            });
        }
        var addPatientInsuranceDetails = function () {
            return $resource('/api/v1/addPatientInsuranceDetails', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientVitals = function () {
            return $resource('/api/v1/addPatientVitals', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientEncounter = function () {
            return $resource('/api/v1/addPatientEncounter', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientAllergiesAndReactions = function () {
            return $resource('/api/v1/addPatientAllergiesAndReactions', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientMedication = function () {
            return $resource('/api/v1/addPatientMedication', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientFamilyHistory = function () {
            return $resource('/api/v1/addPatientFamilyHistory', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientSurgeries = function () {
            return $resource('/api/v1/addPatientSurgeries', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getDiseaseList = function () {
            return $resource('/api/v1/getDiseaseList', null, {
                get: {
                    method: 'GET'
                }
            });
        }

        var addPatientDisease = function () {
            return $resource('/api/v1/addPatientDisease', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientChronicDisease = function () {
            return $resource('/api/v1/addPatientChronicDisease', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getDeviceDetail = function (id) {
            return $resource('/api/v1/getPatientDevice/' + id, null, {
                save: {
                    method: 'GET'
                }
            });
        }
        var deleteDevice = function (id) {
            return $resource('/api/v1/deletePatientDevice/' + id, null, {
                save: {
                    method: 'GET'
                }
            });
        }
        var dailyActivity = function () {
            return $resource('/api/v1/withings/DailySteps', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var getCountry = function (deviceId) {
            return $resource('/api/v1/auth/getCountry', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var createNotify = function () {
            return $resource('/api/v1/getNotificationlist', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var updatePatient = function () {
            return $resource('/api/v1/updatePatientByAdmin', null, {
                save: {
                    method: 'POST',
                }
            });
        }
        var enableDisablePatient = function () {
            return $resource('/api/v1/enableDisablePatient', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getHospital = function () {
            return $resource('/api/v1/getHospital', null, {
                save: {
                    method: 'GET'
                }
            });
        }
        var getAssignPatientForClinician = function () {
            return $resource('/api/v1/getAssignPatientForClinician', null, {
                save: {
                    method: 'GET'
                }
            });
        }

        //-----------------------communication module-----------------------------

        var composeMail = function () {
            return $resource('/api/v1/composeMail', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getMailList = function () {
            return $resource('/api/v1/getMailList', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getMailById = function (id) {
            return $resource('/api/v1/getMailById/' + id, null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            });
        }

        var getSentMailList = function () {
            return $resource('/api/v1/getSentMailList', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getAllignedUsersList = function () {
            return $resource('/api/v1/getAllAllignedUsers', null, {
                get: {
                    method: 'GET'
                }
            });
        }

        var sendSMS = function () {
            return $resource('/api/v1/sendSMS', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getSmsMsgList = function () {
            return $resource('/api/v1/getSmsMsgList', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getSentSMSList = function () {
            return $resource('/api/v1/getSentSMSList', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getAssignUsersByHospital = function (id) {
            return $resource('/api/v1/getAssignUsersByHospital/' + id, null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            });
        }

        var getUsersList = function () {
            return $resource('/api/v1/getUserList', null, {
                get: {
                    method: 'GET'
                }
            });
        }

        var getAllEntitiesLinkedToClinician = function () {
            return $resource('/api/v1/getAllEntitiesLinkedToClinician', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var markMailAsRead = function () {
            return $resource('/api/v1/markMailAsRead', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var deleteEmail = function () {
            return $resource('/api/v1/deleteEmailByHospital', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var deleteSms = function () {
            return $resource('/api/v1/deleteSmsByHospital', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var markSmsAsRead = function (id) {
            console.log("markSmsAsRead", id);
            return $resource('/api/v1/markSmsAsRead/' + id, null, {
                save: {
                    method: 'GET'

                }
            });
        }
        var markAsReadMissedCall = function (id) {
            return $resource('/api/v1/markAsReadMissedCall/' + id, null, {
                save: {
                    method: 'GET'

                }
            });
        }
        var getEmailMesssageListforClinician = function () {
            return $resource('/api/v1/getEmailMesssageListforClinician', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var getEmailMesssageById = function (id) {
            return $resource('/api/v1/getEmailMesssageById/' + id, null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            });
        }
        var getSmsTemplateById = function (id) {
            return $resource('/api/v1/getSmsTemplateById/' + id, null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            });
        }
        var getSmsTemplateListforClinician = function () {
            return $resource('/api/v1/getSmsTemplateListforClinician', null, {
                get: {
                    method: 'GET'
                }
            });
        }

        var getMissedVideoCallList = function () {
            return $resource('/api/v1/getMissedVideoCallList', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var deleteMissedCall = function (id) {
            return $resource('/api/v1/deleteMissedCall/' + id, null, {
                save: {
                    method: 'GET'
                }
            });
        }

        return {
            connectWithing: connectWithing,
            addDevice: addDevice,
            updatePatient: updatePatient,
            getDeviceList: getDeviceList,
            activityList: activityList,
            addPatient: addPatient,
            deletePatient: deletePatient,
            addPatientDemographics: addPatientDemographics,
            addPatientInsuranceDetails: addPatientInsuranceDetails,
            addPatientVitals: addPatientVitals,
            addPatientEncounter: addPatientEncounter,
            addPatientAllergiesAndReactions: addPatientAllergiesAndReactions,
            addPatientMedication: addPatientMedication,
            addPatientFamilyHistory: addPatientFamilyHistory,
            addPatientSurgeries: addPatientSurgeries,
            getDiseaseList: getDiseaseList,
            addPatientDisease: addPatientDisease,
            addPatientChronicDisease: addPatientChronicDisease,
            getDeviceDetail: getDeviceDetail,
            editDevice: editDevice,
            dailyActivity: dailyActivity,
            createNotify: createNotify,
            deleteDevice: deleteDevice,
            getAllPatient: getAllPatient,
            getCountry: getCountry,
            updateClinicianProfile: updateClinicianProfile,
            addOrderTest: addOrderTest,
            addCarePlan: addCarePlan,
            getPatientById: getPatientById,
            getAllPatientByClinicianId: getAllPatientByClinicianId,
            enableDisablePatient: enableDisablePatient,
            getHospital: getHospital,
            getAllOrderTestByPatientId: getAllOrderTestByPatientId,
            getAllCarePlanByPatientId: getAllCarePlanByPatientId,
            viewTestOrderById: viewTestOrderById,
            viewCarePlanById: viewCarePlanById,
            getAssignPatientForClinician: getAssignPatientForClinician,
            //communication module-------------
            composeMail: composeMail,
            getMailList: getMailList,
            getMailById: getMailById,
            getSentMailList: getSentMailList,
            getAllignedUsersList: getAllignedUsersList,
            sendSMS: sendSMS,
            getSmsMsgList: getSmsMsgList,
            getSentSMSList: getSentSMSList,
            getAssignUsersByHospital: getAssignUsersByHospital,
            getUsersList: getUsersList,
            getAllEntitiesLinkedToClinician: getAllEntitiesLinkedToClinician,
            markMailAsRead: markMailAsRead,
            deleteSms: deleteSms,
            deleteEmail: deleteEmail,
            markSmsAsRead: markSmsAsRead,
            getEmailMesssageListforClinician: getEmailMesssageListforClinician,
            getEmailMesssageById: getEmailMesssageById,
            getSmsTemplateById: getSmsTemplateById,
            getSmsTemplateListforClinician: getSmsTemplateListforClinician,
            getMissedVideoCallList: getMissedVideoCallList,
            deleteMissedCall: deleteMissedCall,
            markAsReadMissedCall: markAsReadMissedCall

            //communication module end-----------------------------------

        }

    }]);
