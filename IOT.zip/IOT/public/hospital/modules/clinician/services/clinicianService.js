"use strict"

angular.module("Clinician")

.factory('clinicianService', ['$http', '$resource', function($http, $resource) {

    var addClinicianByHospital = function() {
        return $resource('/api/v1/addClinicianByHospital', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllClinicianByHospital = function() {
        return $resource('/api/v1/getAllClinicianByHospital', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getClinicianById = function(id) {
        console.log('getClinicianById', id);
        return $resource('/api/v1/getClinicianById/' + id, null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var enableDisableClinician = function() {
        return $resource('/api/v1/enableDisableClinician', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteClinician = function(id) {
        return $resource('/api/v1/deleteClinicianById/' + id, null, {
            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var getCountry = function(deviceId) {
        return $resource('/api/v1/auth/getCountry', null, {
            get: {
                method: 'GET'
            }
        });
    }

    return {
        addClinicianByHospital: addClinicianByHospital,
        getClinicianById: getClinicianById,
        getAllClinicianByHospital: getAllClinicianByHospital,
        enableDisableClinician: enableDisableClinician,
        deleteClinician: deleteClinician,
        getCountry: getCountry
    }

}]);
