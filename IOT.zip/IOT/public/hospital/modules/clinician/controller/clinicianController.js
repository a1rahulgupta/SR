"use strict";

angular.module('Clinician')
    .controller("clinicianController", ['$scope', '$rootScope', '$localStorage', '$routeParams',
        '$route', '$location', '$state', '$stateParams', '$http', 'toastr', 'clinicianService', 'ngTableParams', 'ngTableParamsService',
        function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state,
            $stateParams, $http, toastr, clinicianService, ngTableParams, ngTableParamsService) {

            $scope.disableSubmitBtn = false;
            $scope.loader = false;
            $scope.patientForm = {};
            $scope.dateModel = {};

            $scope.getCountry = function() {
                console.log("here");
                clinicianService.getCountry().get({}, function(response, err) {
                    // console.log('response',response);
                    if (response.code == 200) {
                        $scope.country = response.data;
                    } else {
                        $scope.country = {};
                    }
                });
            }

            $scope.addClinicianByHospital = function() {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                console.log("addClinicianByHospital", $scope.clinicianForm);
                // var password = $scope.clinicianForm.password;
                // var confirm_password = $scope.confirm_password;
                var clinicianForm = $scope.clinicianForm;
                // if(password == confirm_password){
                if ($state.params.id) {
                    clinicianForm.id = $state.params.id;
                }
                console.log("$scope.clinicianForm", clinicianForm);
                clinicianService.addClinicianByHospital().save(clinicianForm, function(response) {
                    //console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        $location.path('/clinicianList');
                        $scope.patientFlag = false;
                        $scope.clinicianFlag = true;
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
                // }else if(password != confirm_password){    
                //    toastr.info("Password and confirm password not matched");
                // }else{
                //     console.log("error");
                // }
            };

            $scope.getClinicianById = function() {
                var id = $state.params.id;
                console.log(id);
                clinicianService.getClinicianById(id).get(function(response, err) {
                    if (response.code == 200) {
                        console.log("response", response.data);
                        var clinicianData = response.data;
                        clinicianData.email = response.data.user_id.email;
                        $scope.clinicianForm = clinicianData;
                    } else {
                        $scope.clinicianForm = {};
                    }
                });
            };

            $scope.getAllClinicianByHospital = function() {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.clinicianList = [];
                        clinicianService.getAllClinicianByHospital().save($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.clinicianList = response.data;
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.getAllClinicianByHospitalSearch = function(searchTextField) {
                ngTableParamsService.set('', '', searchTextField, '');
                console.log("searchtextfield", searchTextField);
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.clinicianList = [];
                        clinicianService.getAllClinicianByHospital().save($scope.paramUrl, function(response) {
                            $scope.tableLoader = false;
                            $scope.clinicianList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.totalCount;
                            params.total(response.totalCount);
                            $defer.resolve(data);
                        });
                    }
                });
            };

            $scope.enableDisableClinician = function(id, condition) {
                var status;
                if (condition == 'Active') {
                    status = true;
                } else {
                    status = false;
                }
                clinicianService.enableDisableClinician().save({ userId: id, status: status }, function(response) {
                    if (response.code == 200) {
                        $scope.getAllClinicianByHospital();
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                })
            };

            $scope.deleteClinician = function(id) {
                console.log("deleteClinician", id);
                bootbox.confirm('Are you sure you want to delete', function(r) {
                    if (r) {
                        clinicianService.deleteClinician(id).delete(function(response) {
                            if (response.code == 200) {
                                $scope.getAllClinicianByHospital();
                                toastr.success(response.message);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                })
            }


        }
    ]);
