"use strict"

angular.module("Dashboard")

    .factory('dashboardService', ['$http', '$resource', function ($http, $resource) {

        var connectWithing = function () {
            return $resource('/api/v1/withings/connect', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var getDeviceList = function () {
            return $resource('/api/v1/getPatientDevice', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var activityList = function (deviceId) {
            return $resource('/api/v1/getPatientActivity/' + deviceId, null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var getCountry = function (deviceId) {
            return $resource('/api/v1/auth/getCountry', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var addPatientDeviceByHospital = function () {
            return $resource('/api/v1/addPatientDeviceByHospital', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var updateHospitalProfile = function () {
            return $resource('/api/v1/updateHospitalProfile', null, {
                save: {
                    method: 'POST',
                    headers: { 'Content-Type': undefined }
                }
            });
        }
        var addPatientDemographics = function () {
            return $resource('/api/v1/addPatientDemographics', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientInsuranceDetails = function () {
            return $resource('/api/v1/addPatientInsuranceDetails', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientVitals = function () {
            return $resource('/api/v1/addPatientVitals', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientEncounter = function () {
            return $resource('/api/v1/addPatientEncounter', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientAllergiesAndReactions = function () {
            return $resource('/api/v1/addPatientAllergiesAndReactions', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientMedication = function () {
            return $resource('/api/v1/addPatientMedication', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientFamilyHistory = function () {
            return $resource('/api/v1/addPatientFamilyHistory', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientSurgeries = function () {
            return $resource('/api/v1/addPatientSurgeries', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getDiseaseList = function () {
            return $resource('/api/v1/getDiseaseList', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var dailyActivity = function () {
            return $resource('/api/v1/withings/DailySteps', null, {
                get: {
                    method: 'GET'
                }
            });
        }

        //-----------------------communication module-----------------------------

        var composeMail = function () {
            return $resource('/api/v1/composeMail', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getMailList = function () {
            return $resource('/api/v1/getMailList', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getMailById = function (id) {
            return $resource('/api/v1/getMailById/' + id, null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            });
        }

        var getSentMailList = function () {
            return $resource('/api/v1/getSentMailList', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getAllignedUsersList = function () {
            return $resource('/api/v1/getAllAllignedUsers', null, {
                get: {
                    method: 'GET'
                }
            });
        }

        var sendSMS = function () {
            return $resource('/api/v1/sendSMS', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getSmsMsgList = function () {
            return $resource('/api/v1/getSmsMsgList', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getSentSMSList = function () {
            return $resource('/api/v1/getSentSMSList', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getAssignUsersByHospital = function (id) {
            return $resource('/api/v1/getAssignUsersByHospital/' + id, null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            });
        }

        var getUsersList = function () {
            return $resource('/api/v1/getUserList', null, {
                get: {
                    method: 'GET'
                }
            });
        }

        var getAllEntitiesLinkedToHospital = function () {
            return $resource('/api/v1/getAllEntitiesLinkedToHospital', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var deleteEmail = function () {
            return $resource('/api/v1/deleteEmailByHospital', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var deleteSmsByHospital = function () {
            return $resource('/api/v1/deleteSmsByHospital', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getdeviceType = function () {
            return $resource('/api/v1/getdeviceType', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var getPatientListForDevice = function () {
            return $resource('/api/v1/getPatientListForDevice', null, {
                save: {
                    method: 'GET'
                }
            });
        }
        var getDeviceListForHospital = function () {
            return $resource('/api/v1/getDeviceListForHospital', null, {
                save: {
                    method: 'GET'
                }
            });
        }

        var getDeviceById = function (id) {
            return $resource('/api/v1/getPatientDevice/' + id, null, {
                save: {
                    method: 'GET'
                }
            });
        }
        var deleteDevice = function (id) {
            return $resource('/api/v1/deletePatientDevice/' + id, null, {
                save: {
                    method: 'GET'
                }
            });
        }
        var viewDeviceListForPatient = function () {
            return $resource('/api/v1/viewDeviceListForPatient/:id', null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            })
        }
        var markMailAsRead = function () {
            return $resource('/api/v1/markMailAsRead', null, {
                save: {
                    method: 'POST'

                }
            });
        }

        var markSmsAsRead = function (id) {
            console.log("markSmsAsRead", id);
            return $resource('/api/v1/markSmsAsRead/' + id, null, {
                save: {
                    method: 'GET'

                }
            });
        }
        var getEmailMesssageList = function () {
            return $resource('/api/v1/getEmailMesssageList', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var addEmailMessage = function () {
            return $resource('/api/v1/addEmailMessage', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var getEmailMesssageById = function (id) {
            console.log("getEmailMesssageById", id);
            return $resource('/api/v1/getEmailMesssageById/' + id, null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            });
        }
        var deleteEmailMessage = function (id) {
            return $resource('/api/v1/deleteEmailMessage/' + id, null, {
                save: {
                    method: 'GET'
                }
            });
        }

        var getSmsTemplateList = function () {
            return $resource('/api/v1/getSmsTemplateList', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var addSmsTemplate = function () {
            return $resource('/api/v1/addSmsTemplate', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var getSmsTemplateById = function (id) {
            return $resource('/api/v1/getSmsTemplateById/' + id, null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            });
        }
        var deleteSmsTemplate = function (id) {
            return $resource('/api/v1/deleteSmsTemplate/' + id, null, {
                save: {
                    method: 'GET'
                }
            });
        }
        var getMissedVideoCallList = function () {
            return $resource('/api/v1/getMissedVideoCallList', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var deleteMissedCall = function (id) {
            return $resource('/api/v1/deleteMissedCall/' + id, null, {
                save: {
                    method: 'GET'
                }
            });
        }
        var markAsReadMissedCall = function (id) {
            return $resource('/api/v1/markAsReadMissedCall/' + id, null, {
                save: {
                    method: 'GET'

                }
            });
        }

        return {
            connectWithing: connectWithing,
            addPatientDeviceByHospital: addPatientDeviceByHospital,
            getDeviceList: getDeviceList,
            activityList: activityList,
            addPatientDemographics: addPatientDemographics,
            addPatientInsuranceDetails: addPatientInsuranceDetails,
            addPatientVitals: addPatientVitals,
            addPatientEncounter: addPatientEncounter,
            addPatientAllergiesAndReactions: addPatientAllergiesAndReactions,
            addPatientMedication: addPatientMedication,
            addPatientFamilyHistory: addPatientFamilyHistory,
            addPatientSurgeries: addPatientSurgeries,
            getDiseaseList: getDiseaseList,
            dailyActivity: dailyActivity,
            updateHospitalProfile: updateHospitalProfile,
            getCountry: getCountry,
            composeMail: composeMail,
            getMailList: getMailList,
            getMailById: getMailById,
            getSentMailList: getSentMailList,
            getAllignedUsersList: getAllignedUsersList,
            sendSMS: sendSMS,
            getSmsMsgList: getSmsMsgList,
            getSentSMSList: getSentSMSList,
            getAssignUsersByHospital: getAssignUsersByHospital,
            getUsersList: getUsersList,
            getAllEntitiesLinkedToHospital: getAllEntitiesLinkedToHospital,
            deleteSmsByHospital: deleteSmsByHospital,
            getdeviceType: getdeviceType,
            getPatientListForDevice: getPatientListForDevice,
            getDeviceListForHospital: getDeviceListForHospital,
            viewDeviceListForPatient: viewDeviceListForPatient,
            getDeviceById: getDeviceById,
            deleteDevice: deleteDevice,
            deleteEmail: deleteEmail,
            markMailAsRead: markMailAsRead,
            markSmsAsRead: markSmsAsRead,
            addEmailMessage: addEmailMessage,
            getEmailMesssageList: getEmailMesssageList,
            getEmailMesssageById: getEmailMesssageById,
            deleteEmailMessage: deleteEmailMessage,
            addSmsTemplate: addSmsTemplate,
            getSmsTemplateList: getSmsTemplateList,
            getSmsTemplateById: getSmsTemplateById,
            deleteSmsTemplate: deleteSmsTemplate,
            getMissedVideoCallList: getMissedVideoCallList,
            deleteMissedCall: deleteMissedCall,
            markAsReadMissedCall: markAsReadMissedCall


        }

    }]);
