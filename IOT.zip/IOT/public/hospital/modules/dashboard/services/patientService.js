"use strict"

angular.module("Patient")

.factory('patientService', ['$http', '$resource', function($http, $resource) {

    var getSmokingStatus = function() {
        return $resource('/api/v1/getSmokingStatus', null, {
            get: {
                method: 'GET'
            }
        });
    }

    var getAllPatient = function() {
        return $resource('/api/v1/getAllPatient', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllClinicianName = function() {
        return $resource('/api/v1/getAllClinicianName', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var addPatient = function() {
        return $resource('/api/v1/addPatient', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var updatePatient = function() {
        return $resource('/api/v1/updatePatient', null, {
            save: {
                method: 'POST',
            }
        });
    }

    var getPatientById = function(id) {
        console.log("id----", id);
        return $resource('/api/v1/getPatientById/' + id, null, {
            delete: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var deletePatient = function(id) {
        return $resource('/api/v1/deletePatientById/' + id, null, {
            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    return {
        getAllPatient: getAllPatient,
        deletePatient: deletePatient,
        addPatient: addPatient,
        updatePatient: updatePatient,
        getPatientById: getPatientById,
        getAllClinicianName: getAllClinicianName
    }

}]);
