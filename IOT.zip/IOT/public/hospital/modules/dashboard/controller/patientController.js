"use strict";

angular.module('Patient')
    .controller("patientController", ['$scope', '$rootScope', '$localStorage', '$routeParams',
        '$route', '$location', '$state', '$stateParams', '$http', 'toastr', 'patientService', 'ngTableParams', 'ngTableParamsService',
        function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state,
            $stateParams, $http, toastr, patientService, ngTableParams, ngTableParamsService) {
            $scope.service = { 'vinod': 'telang' };

            $scope.disableSubmitBtn = false;
            $scope.loader = false;
            $scope.patientForm = {};
            $scope.getAllPatient = function() {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.patientList = [];
                        console.log(0);
                        patientService.getAllPatient().get($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.patientList = response.data;
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.getPatientById = function(id) {
                console.log("getPatientById", $stateParams.id);
                patientService.getPatientById($stateParams.id).get(function(response) {
                    if (response.code == 200) {
                        $scope.imageBase64 = true
                        $scope.add = true
                        $scope.patient = response.data;
                    }
                });
            }


            $scope.getAllClinicianName = function() {
                $scope.getClinicianData = patientService.getAllClinicianName().get({}, function(response, err) {
                    if (response.code == 200) {
                        $scope.getClinicianData = response.data;
                    } else {
                        $scope.getClinicianData = {};
                    }
                });
            }

            $scope.calculateAge = function(DOB) {
                var birthDay = DOB.getDate();
                var birthMonth = DOB.getMonth();
                var birthYear = DOB.getFullYear();
                var todayDate = new Date();
                var todayYear = todayDate.getFullYear();
                var todayMonth = todayDate.getMonth();
                var todayDay = todayDate.getDate();
                var age = todayYear - birthYear;

                if (todayMonth < birthMonth - 1) {
                    age--;
                }

                if (birthMonth - 1 == todayMonth && todayDay < birthDay) {
                    age--;
                }
                $scope.userData.age = age;
                console.log("age", $scope.userData.age);
            }

            $scope.addPatient = function() {
                console.log("$scope.patientForm", $scope.patientForm);
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                patientService.addPatient().save($scope.patientForm, function(response) {

                    console.log("response------------>>>>",response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        $location.path('/patient');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }

            $scope.addUpdateServiceData = function(form) {
                if (form.$valid) {
                    $scope.err = '';
                    $scope.disableSubmitBtn = true;
                    $scope.loader = true;
                    if (!$scope.patient._id) {
                        patientService.addPatient().save($scope.patientForm, function(response) {
                            console.log(response);
                            $scope.disableSubmitBtn = false;
                            $scope.loader = false;
                            if (response.code == 200) {
                                //$window.location.href = '/#!/deviceList'
                                toastr.success(response.message);
                                $location.path('/patient');
                            } else {
                                toastr.error(response.message, 'Error');
                                $scope.disableSubmitBtn = false;
                                $scope.loader = false;
                            }
                        });
                    } else {
                        patientService.updatePatient().save($scope.patientForm, function(response) {
                            $scope.disableSubmitBtn = false;
                            $scope.loader = false;
                            if (response.code == 200) {
                                //$window.location.href = '/#!/deviceList'
                                toastr.success(response.message);
                                $location.path('/patient');
                            } else {
                                toastr.error(response.message, 'Error');
                                $scope.disableSubmitBtn = false;
                                $scope.loader = false;
                            }
                        });
                    }
                }
            }



            $scope.deletePatient = function(id) {
                console.log("abc      deletePatient", id);
                bootbox.confirm('Are you sure you want to delete this image', function(r) {
                    if (r) {
                        patientService.deletePatient(id).delete(function(response) {
                            console.log("Resta");
                            if (response.code == 200) {
                                $scope.getAllPatient();
                                logger.logSuccess(response.message);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });


            }
        }
    ]);
