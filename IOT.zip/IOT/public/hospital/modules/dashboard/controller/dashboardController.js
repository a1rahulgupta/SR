"use strict";

var iotiedApp = angular.module('dashboard.controller', []);
iotiedApp.controller("dashboardController", ['$scope', '$rootScope', '$templateCache', '$localStorage', 'dashboardService', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', 'toastr', '$uibModal', 'ngTableParams', 'ngTableParamsService',
    function ($scope, $rootScope, $localStorage, $templateCache, dashboardService, $routeParams, $route, $location, $state, $stateParams, $http, toastr, $uibModal, ngTableParams, ngTableParamsService) {
        $scope.mailData = {}
        $scope.mailData.title = '';
        $scope.smsData = {}
        $scope.smsData.title = '';

        $scope.tinymceOptions = {
            // plugins: 'link image code',
            menubar: false,
            toolbar: 'fontselect fontsizeselect | formatselect | undo redo | bold italic | alignleft aligncenter alignright | code | removeformat'
        };


        $scope.measureTypes = [{ 'type': '1', 'name': 'Weight (kg)', 'measures': [] },
        { 'type': '4', 'name': 'Height (meter)', 'measures': [] },
        { 'type': '5', 'name': 'Fat Free Mass (kg)', 'measures': [] },
        { 'type': '6', 'name': 'Fat Ratio (%)', 'measures': [] },
        { 'type': '8', 'name': 'Fat Mass Weight (kg)', 'measures': [] },
        { 'type': '9', 'name': 'Diastolic BP (mmHg)', 'measures': [] },
        { 'type': '10', 'name': 'Systolic BP (mmHg)', 'measures': [] },
        { 'type': '11', 'name': 'Heart Pulse (bpm)', 'measures': [] },
        { 'type': '12', 'name': 'Temperature', 'measures': [] },
        { 'type': '54', 'name': 'SP02(%)', 'measures': [] },
        { 'type': '71', 'name': 'Body Temperature', 'measures': [] },
        { 'type': '73', 'name': 'Skin Temperature', 'measures': [] },
        { 'type': '76', 'name': 'Muscle Mass', 'measures': [] },
        { 'type': '77', 'name': 'Hydration', 'measures': [] },
        { 'type': '88', 'name': 'Bone Mass', 'measures': [] },
        { 'type': '91', 'name': 'Pulse Wave Velocity', 'measures': [] },
        ];
        var formDataFileUpload = '';
        $scope.imageBase64 = '';

        $scope.dateModel = {};
        $scope.today = function () {
            $scope.dt = new Date();
        };
        $scope.dateformat = "dd/MM/yyyy";
        $scope.today();
        $scope.showcalendar = function ($event) {
            $scope.dateModel.showdp = true;
        };
        $scope.showcalendar1 = function ($event) {
            $scope.dateModel.showdp1 = true;
        };
        $scope.showcalendar2 = function ($event) {
            $scope.dateModel.showdp2 = true;
        };
        $scope.dateModel.showdp = false;
        $scope.dateModel.showdp1 = false;
        $scope.dateModel.showdp2 = false;
        $scope.dtmax = new Date();

        if ($rootScope.userInfo) {
            if ($rootScope.userInfo.user_id._id) {
                $scope.userid = $rootScope.userInfo.user_id._id;
            }
        }
        $scope.connectToWithings = function (devId) {
            $scope.connectData = dashboardService.connectWithing().get({ 'deviceId': devId }, function (response, err) {
                //console.log('response',response);
                if (response.code == 200) {
                    //window.location.href = response.url;
                    if (response.url) {
                        var win = window.open(response.url, '_blank');
                        win.focus();
                    } else {
                        toastr.success(response.message);
                    }
                } else {
                    $scope.connectData = {};
                }
            });
        };

        $scope.deviceForm = {};
        $scope.disableSubmitBtn = false;
        $scope.loader = false;

        $scope.addDevice = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                $scope.deviceForm.wearable = "wearable";
                dashboardService.addPatientDeviceByHospital().save($scope.deviceForm, function (response) {
                    //console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };


        $scope.imageBrowse = function () {
            document.getElementById('filePicker').addEventListener('change', function (evt) {
                var files = evt.target.files;
                var file = files[0];
                if (files && file) {
                    var splitFileName = file.name.split('.');
                    var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                    if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {
                        if (file.size > 6291456) {
                            logger.log('File size cannot exceed limit of 6 mb');
                            document.getElementById("filePicker").value = "";
                        } else {
                            formDataFileUpload = file;
                            // formDataFileUpload.append('file', file);
                            var reader = new FileReader();
                            reader.onload = function (readerEvt) {
                                $scope.imageBase64 = btoa(readerEvt.target.result);
                                $scope.$apply();
                                document.getElementById('imgTag').src = 'data:image/' + ext + ';base64,' + $scope.imageBase64;
                            };
                            reader.readAsBinaryString(file);
                        }
                    } else {
                        document.getElementById("filePicker").value = "";
                        bootbox.alert('Invalid image format');
                    }
                }
            });
        }

        $scope.updateHospitalProfile = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;

                var formData = new FormData();
                formData.append('hospital_npi_no', $scope.userData.hospital_npi_no);
                formData.append('hospital_name', $scope.userData.hospital_name);
                formData.append('hospital_address', $scope.userData.hospital_address);
                formData.append('hospital_city', $scope.userData.hospital_city);
                formData.append('hospital_state', $scope.userData.hospital_state);
                formData.append('hospital_zip_code', $scope.userData.hospital_zip_code);
                formData.append('hospital_country', $scope.userData.hospital_country);
                formData.append('hospital_mobile_no', $scope.userData.hospital_mobile_no);
                if (formDataFileUpload) {
                    formData.append('file', formDataFileUpload);
                }
                dashboardService.updateHospitalProfile().save(formData, function (response) {
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        toastr.success(response.message);
                        $location.path('/dashboard');
                        $rootScope.getUserInfo();
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }

                });

            }
        }

        $scope.getCountry = function () {
            console.log("here");
            dashboardService.getCountry().get({}, function (response, err) {
                // console.log('response',response);
                if (response.code == 200) {
                    //console.log("getCountry", response.data);
                    $scope.country = response.data;
                } else {
                    $scope.country = {};
                }
            });
        }
        $scope.getDeviceListForHospital = function () {
            $scope.deviceData = dashboardService.getDeviceListForHospital().get({}, function (response, err) {
                console.log('response--->>>', response);
                if (response.code == 200) {
                    $scope.deviceData = response.data;
                } else {
                    $scope.deviceData = {};
                }
            });
        }




        $scope.getdeviceType = function () {
            dashboardService.getdeviceType().get({}, function (response, err) {
                if (response.code == 200) {
                    console.log("getdeviceType------>>>>", response.data);
                    $scope.deviceType = response.data;
                } else {
                    $scope.deviceType = {};
                }
            });
        }
        $scope.getPatientListForDevice = function () {
            console.log("getPatientListForDevice");
            dashboardService.getPatientListForDevice().get({}, function (response, err) {
                if (response.code == 200) {
                    $scope.getPatientData = response.data;
                    console.log("getPatientData", response.data);
                } else {
                    $scope.getPatientData = {};
                }
            });
        }


        $scope.activityList = function (deviceId) {
            console.log('here888');
            $scope.activityData = dashboardService.activityList(deviceId).get({}, function (response, err) {
                if (response.code == 200) {
                    $scope.activityData = response.data;
                    var dates = []
                    for (var i = 0; i < response.data.length; i++) {
                        var obj = response.data[i].data;
                        for (var j = 0; j < obj.length; j++) {
                            syncMeasures(i, response.data.length, obj[j].measures);
                        }
                    }

                } else {
                    $scope.activityData = {};
                }
            });
            console.log('here');
            $scope.dailyActivityData = dashboardService.dailyActivity().get({ 'deviceId': deviceId }, function (response, err) {
                if (response.code == 200) {

                } else {
                    $scope.dailyActivityData = {};
                }
            });
            console.log('here123');
        }



        function syncMeasures(dt, count, arr) {
            var key = 'dt' + dt
            //var key = dt
            for (var i = 0; i < arr.length; i++) {
                for (var j = 0; j < $scope.measureTypes.length; j++) {
                    if (arr[i].type == $scope.measureTypes[j].type) {
                        var obj = {}
                        obj[key] = arr[i].value;
                        $scope.measureTypes[j].measures.push(obj);
                    }
                }
            }
        }
        /**
         * Function is use to add Patient Demographics  
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */

        $scope.addPatientDemographics = function () {

            console.log("addPatientDemographics", $scope.demographicForm)
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                dashboardService.addPatientDemographics().save($scope.demographicForm, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };


        /**
         * Function is use to add Patient Insurance Details 
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */
        $scope.addPatientInsuranceDetails = function () {

            console.log("addPatientInsuranceDetails", $scope.insuranceForm)
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                dashboardService.addPatientInsuranceDetails().save($scope.insuranceForm, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };
        /**
         * Function is use to add Patient Vitals 
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */
        $scope.addPatientVitals = function () {

            console.log("addPatientVitals", $scope.vitalsForm)
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                var blood_pressure = [{
                    minValue: $scope.bloodPresure.minValue,
                    maxValue: $scope.bloodPresure.maxValue
                }]
                var vitalsForm = $scope.vitalsForm;
                vitalsForm.blood_pressure = blood_pressure;
                console.log("vitals", vitalsForm);
                dashboardService.addPatientVitals().save(vitalsForm, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };
        /**
         * Function is use to add Patient Encounter  
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */
        $scope.addPatientEncounter = function () {

            console.log("addPatientEncounter", $scope.encounterForm)
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                var diagnosis = [{
                    diagnosis1: $scope.diagnosis.diagnosis1,
                    diagnosis2: $scope.diagnosis.diagnosis2,
                    diagnosis3: $scope.diagnosis.diagnosis3
                }]
                var encounterForm = $scope.encounterForm;
                encounterForm.diagnosis = diagnosis;
                console.log("encounterForm", encounterForm);
                dashboardService.addPatientEncounter().save(encounterForm, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        /**
         * Function is use to add Patient Allergies And Reactions 
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */
        $scope.addPatientAllergiesAndReactions = function () {

            console.log("addPatientAllergiesAndReactions", $scope.allergiesForm)
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                var allergy = {};
                var allergies = [{
                    substance: $scope.allergiesForm.substance,
                    reaction: $scope.allergiesForm.reaction,
                    severity: $scope.allergiesForm.severity,
                    status: $scope.allergiesForm.status
                }]
                allergy.allergies = allergies;
                console.log("allergy", allergy);
                dashboardService.addPatientAllergiesAndReactions().save(allergy, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        /**
         * Function is use to add Patient Medication 
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */
        $scope.addPatientMedication = function () {

            console.log("addPatientMedication", $scope.medicationForm)
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                var medication = [{
                    diagnosis1: $scope.medicationForm.medication1,
                    diagnosis2: $scope.medicationForm.medication2,
                    diagnosis3: $scope.medicationForm.medication3
                }]
                var medicationForm = $scope.medicationForm;
                medicationForm.medication = medication;
                console.log("medication", medication);
                dashboardService.addPatientAllergiesAndReactions().save(medicationForm, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        /**
         * Function is use to add Patient Family History  
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */
        $scope.addPatientFamilyHistory = function () {

            console.log("addPatientFamilyHistory", $scope.familyForm)
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                dashboardService.addPatientFamilyHistory().save($scope.familyForm, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        /**
         * Function is use to add Patient Surgeries  
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */
        $scope.addPatientSurgeries = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                var surgeryData = {};
                var surgeries = [{
                    surgery: $scope.surgeryForm.surgery,
                    surgery_date: $scope.surgeryForm.surgery_date,
                    physician: $scope.surgeryForm.physician,
                    status: $scope.surgeryForm.status
                }]
                surgeryData.surgeries = surgeries;
                console.log("surgeryData", surgeryData);
                dashboardService.addPatientSurgeries().save(surgeryData, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        /**
         * Function is use to Get Disease    
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 14-June-2017
         */
        $scope.getDiseaseList = function () {
            $scope.deviceData = dashboardService.getDiseaseList().get({}, function (response, err) {
                // console.log('response',response);
                if (response.code == 200) {
                    $scope.diseaseData = response.data[0];
                    console.log("diseasedata", response.data[0]);
                } else {
                    $scope.diseaseData = {};
                }
            });
        }

        //--------------Mail Section------------------------------------------

        $scope.getAllUsers = function () {
            // $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            $scope.tableLoader = true;
            $scope.usersList = [];
            dashboardService.getUsersList().get({}, function (response) {
                $scope.usersList = response.data;
            });
        };


        $scope.loadEmails = function ($query) {
            return ($scope.entitiesList).filter(function (user) {
                return ((user.name).toLowerCase().indexOf($query.toLowerCase()) != -1);
            });
        };

        $scope.mailForm = {};
        $scope.disableSubmitBtn = false;
        $scope.loader = false;
        //Swapnali
        $scope.sendMail = function (mailData) {
            if ($scope.mailForm.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                if (mailData.mail_to) {
                    mailData.mail_to = (mailData.mail_to).map(function (tag) {
                        return tag.email;
                    }).join(",");
                }
                if (mailData.mail_cc) {
                    mailData.mail_cc = (mailData.mail_cc).map(function (tag) {
                        return tag.email;
                    }).join(",");
                }
                if (mailData.mail_bcc) {
                    mailData.mail_bcc = (mailData.mail_bcc).map(function (tag) {
                        return tag.email;
                    }).join(",");
                }
                dashboardService.composeMail().save(mailData, function (response) {
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        toastr.success(response.message);
                        $location.path('/mail');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        $scope.showMail = function (id) {
            dashboardService.markMailAsRead().save({ id: id }, function (response) {
                if (response.code == 200) {
                }
            });
            $state.go('singleMail', {
                id: id
            });
        };

        $scope.showSentMail = function (id) {
            $state.go('singleSentMail', {
                id: id
            });
        };

        $scope.getMailById = function () {
            $scope.mailInfo = {};
            dashboardService.getMailById($stateParams.id).get({}, function (response) {
                if (response.code == 200) {
                    $scope.mailInfo = response.data;
                }
            });
        };

        $scope.setReplyInfo = function () {
            $scope.mailData = {};
            var mailTo = ($scope.mailInfo.from_email).split(',');
            (mailTo).map(function (email) { return { email: email } })
            $scope.mailData.mail_to = mailTo;
            $scope.mailData.mail_subject = 'Re:' + $scope.mailInfo.subject;
        }

        $scope.replyMailForm = {};
        $scope.sendReplyMail = function (mailData) {
            if (mailData.mail_to) {
                mailData.mail_to = (mailData.mail_to).map(function (tag) {
                    return tag.email;
                }).join(",");
            }
            dashboardService.composeMail().save(mailData, function (response) {
                $scope.disableSubmitBtn = false;
                if (response.code == 200) {
                    toastr.success(response.message);
                    $location.path('/mail');
                } else {
                    toastr.error(response.message, 'Error');
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                }
            });

        };

        $scope.getMails = function () {
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.mailList = [];
                    dashboardService.getMailList().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        $scope.mailList = response.data;
                        var data = response.data;
                        console.log("data", data);
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }

        var getData = ngTableParamsService.get();
        $scope.searchTextField = getData.searchText;
        $scope.searching = function () {
            ngTableParamsService.set('', '', $scope.searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.mailList = [];
                    dashboardService.getMailList().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        // $scope.paramUrlActive = paramUrl;
                        $scope.mailList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }

        $scope.getSentMailList = function () {
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.mailList = [];
                    dashboardService.getSentMailList().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        $scope.mailList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }

        var getData = ngTableParamsService.get();
        $scope.searchTextField = getData.searchText;
        $scope.searching = function () {
            ngTableParamsService.set('', '', $scope.searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.mailList = [];
                    dashboardService.getSentMailList().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        // $scope.paramUrlActive = paramUrl;
                        $scope.mailList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }

        $scope.redirectToInbox = function () {
            $location.path('/mail');
        };


        $scope.removeEmail = function () {
            var newMail = [];
            $scope.selectedAll = false;
            angular.forEach($scope.mailList, function (selected) {
                if (selected.selected) {
                    console.log(!selected.selected);
                    newMail.push(selected);
                    $scope.List = newMail;
                }
            });
            $scope.deleteEmail($scope.List);
        };

        $scope.checkEmail = function ($event, id) {
            $event.stopPropagation();
        };


        $scope.deleteEmail = function (newMail) {
            var obj = {};
            obj.mailToBeDeleted = newMail;
            if (obj.mailToBeDeleted && obj.mailToBeDeleted.length > 0) {
                bootbox.confirm('Are you sure, you want to delete this Mail', function (r) {
                    if (r) {
                        dashboardService.deleteEmail().save(obj, function (response, err) {
                            if (response.code == 200) {
                                toastr.success(response.message);
                                $scope.getMails();
                            } else {
                                toastr.error('Something went wrong, please try again later.');
                            }
                        });
                    }
                })
            }
            else {
                bootbox.alert('Please select mail to delete.');
            }
        }
        $scope.toggleMailCheckbox = function () {
            if ($scope.selectedAll) {
                $scope.selectedAll = true;
            } else {
                $scope.selectedAll = false;
            }
            angular.forEach($scope.mailList, function (item) {
                item.selected = $scope.selectedAll;
            });
        };

        //--------------------------------------------------------------------
        //-------------------------------SMS SECTION-------------------------------------
        //Swapnali
        $scope.smsForm = {};
        $scope.sendSMS = function (smsData) {
            console.log(" sendSms----->>>", $scope.smsForm);
            if ($scope.smsForm.$valid) {
                let sms_to = [];
                console.log(" smsData.sms_to----->>>", smsData.sms_to);
                if (smsData.sms_to) {
                    (smsData.sms_to).forEach(function (user) {
                        sms_to.push({ userid: user.userInfo._id, name: user.name, mobileNo: user.mobile_no });
                    });
                }
                smsData.sms_to = sms_to;
                console.log(" $scope.sms_to----->>>", smsData);
                dashboardService.sendSMS().save(smsData, function (response) {
                    console.log("sendSMS response---->", response)
                    if (response.code == 200) {
                        toastr.success(response.message);
                        $location.path('/sms');
                    } else {
                        toastr.error(response.message, 'Error');
                    }
                });
            }
        };

        $scope.getAllAllignedUsers = function () {
            $scope.allignedUsersList = [];
            dashboardService.getAllignedUsersList().get({}, function (response) {
                $scope.allignedUsersList = response.data;
            });
        };

        $scope.loadPhoneNumbers = function ($query) {
            return ($scope.entitiesList).filter(function (user) {
                return (user.name).toLowerCase().indexOf($query.toLowerCase()) != -1;
            });
        };

        $scope.getSmsMsgList = function () {
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.usersList = [];
                    dashboardService.getSmsMsgList().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        $scope.smsList = response.data;
                        console.log("$scope.smsList---->", $scope.smsList);
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }

        var getData = ngTableParamsService.get();
        $scope.searchTextField = getData.searchText;
        $scope.searching = function () {
            ngTableParamsService.set('', '', $scope.searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.smsList = [];
                    dashboardService.getSmsMsgList().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        // $scope.paramUrlActive = paramUrl;
                        $scope.smsList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }
        //---------------------------------------------
        $scope.getSentSmsList = function () {
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.usersList = [];
                    dashboardService.getSentSMSList().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        $scope.sentSmsList = response.data;
                        console.log("$scope.getSentSMSList---->", $scope.sentSmsList);
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }

        var getData = ngTableParamsService.get();
        $scope.searchTextField = getData.searchText;
        $scope.searching = function () {
            ngTableParamsService.set('', '', $scope.searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.sentSmsList = [];
                    dashboardService.getSentSMSList().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        // $scope.paramUrlActive = paramUrl;
                        $scope.sentSmsList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }

        // ---------------Email Template Section-----------------start-

        $scope.addEmailMessage = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                dashboardService.addEmailMessage().save($scope.MsgForm, function (response) {
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        toastr.success(response.message);
                        $location.path('/emailMessageList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        $scope.getEmailMesssageList = function () {
            $scope.emailMessageData = dashboardService.getEmailMesssageList().get({}, function (response, err) {
                if (response.code == 200) {
                    $scope.emailMessageData = response.data;
                } else {
                    $scope.emailMessageData = {};
                }
            });
        }

        $scope.getEmailMesssageById = function (id) {
            if (id) {
                $scope.email_id = id;
            } else {
                $scope.email_id = $stateParams.id;
            }
            dashboardService.getEmailMesssageById($scope.email_id).get({}, function (response) {
                $scope.MsgForm = response.data;
                $scope.mailData.mail_subject = '';
                $scope.mailData.mail_body = '';
                if (response.code == 200) {
                    $scope.MsgForm = response.data;
                    $scope.mailData.mail_subject = response.data.subject;
                    $scope.mailData.mail_body = response.data.emailMsg;

                }
            });
        };

        $scope.deleteEmailMessage = function (Id) {
            bootbox.confirm('Are you sure, you want to delete this template?', function (r) {
                if (r) {
                    $scope.emailData = dashboardService.deleteEmailMessage(Id).get({}, function (response, err) {
                        if (response.code == 200) {
                            toastr.success(response.message);
                            $scope.getEmailMesssageList();
                        } else {
                            toastr.error('Something went wrong, please try again later.');
                        }
                    });
                }
            })

        }
        // ---------------Email Template Section------------------end---

        // ---------------SMS Template Section------------------Start---

        $scope.addSmsTemplate = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                dashboardService.addSmsTemplate().save($scope.SmsFrm, function (response) {
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        toastr.success(response.message);
                        $location.path('/smsTemplateList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        $scope.getSmsTemplateList = function () {
            $scope.smsTemplateData = dashboardService.getSmsTemplateList().get({}, function (response, err) {
                if (response.code == 200) {
                    $scope.smsTemplateData = response.data;
                } else {
                    $scope.smsTemplateData = {};
                }
            });
        }

        $scope.getSmsTemplateById = function (id) {
            if (id) {
                $scope.sms_id = id;
            } else {
                $scope.sms_id = $stateParams.id;
            }
            dashboardService.getSmsTemplateById($scope.sms_id).get({}, function (response) {
                $scope.SmsFrm = response.data;
                $scope.smsData.sms_message = '';
                if (response.code == 200) {
                    $scope.SmsFrm = response.data;
                    $scope.smsData.sms_message = response.data.smsMessage;

                }
            });
        };

        $scope.deleteSmsTemplate = function (Id) {
            bootbox.confirm('Are you sure, you want to delete this template?', function (r) {
                if (r) {
                    $scope.smsData = dashboardService.deleteSmsTemplate(Id).get({}, function (response, err) {
                        if (response.code == 200) {
                            toastr.success(response.message);
                            $scope.getSmsTemplateList();
                        } else {
                            toastr.error('Something went wrong, please try again later.');
                        }
                    });
                }
            })

        }

           $scope.viewMissedCall = function () {
            $uibModal.open({
                templateUrl: '/hospital/modules/dashboard/views/viewVideoCall.html',
                size: "lg",
                controller: function ($scope, $uibModalInstance) {
                    $scope.getMissedVideoCallList = function () {
                        dashboardService.getMissedVideoCallList().get({}, function (response, err) {
                            if (response.code == 200) {
                                console.log("response---------viewMissedCall--", response.data);
                                $scope.callList = response.data;

                            } else {
                                $scope.callList = {};
                            }
                        });
                        $scope.cancel = function () {
                            $uibModalInstance.dismiss('cancel');
                        };
                    }
                    $scope.deleteMissedCall = function (Id) {
                        bootbox.confirm('Are you sure, you want to delete this missed call', function (r) {
                            if (r) {
                                dashboardService.deleteMissedCall(Id).get({}, function (response, err) {
                                    if (response.code == 200) {
                                        toastr.success(response.message);
                                        $scope.getMissedVideoCallList();
                                    } else {
                                        toastr.error('Something went wrong, please try again later.');
                                    }
                                });
                            }
                        })

                    }
                    $scope.markAsReadMissedCall = function (id) {
                        dashboardService.markAsReadMissedCall(id).get({}, function (response) {
                            if (response.code == 200) {
                                $scope.getMissedVideoCallList();
                            }
                        });
                    }
                }
            });
        };

        // $scope.getSentSmsList = function () {
        //     $scope.tableLoader = true;
        //     $scope.sentSmsList = [];
        //     dashboardService.getSentSMSList().get({}, function (response) {
        //         if (response.code == 200) {
        //             $scope.tableLoader = false;
        //             $scope.sentSmsList = response.data;
        //         }
        //     });
        // };

        // -----------------Videcall section -------------------

        // $scope.getAssignUsersList = function () {
        //     $scope.tableLoader = true;
        //     $scope.assignedUserList = [];
        //     console.log("$rootScope--->", $rootScope);
        //     if ($rootScope.userInfo._id) {
        //         dashboardService.getAssignUsersByHospital($rootScope.userInfo._id).get({}, function (response) {
        //             if (response.code == 200) {
        //                 $scope.tableLoader = false;
        //                 $scope.assignedUserList = response.data;
        //             }
        //         });
        //     }
        // };

        $scope.getAllUsersLinkedToHospital = function () {
            $scope.entitiesList = [];
            dashboardService.getAllEntitiesLinkedToHospital().save({}, function (response) {
                if (response.code == 200) {
                    $scope.entitiesList = response.data;
                    console.log("$scope.getAllEntitiesLinkedToHospital---->", $scope.entitiesList);
                }
            });
        };

        $scope.getAllEntitiesLinkedToHospital = function () {
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.entitiesList = [];
                    dashboardService.getAllEntitiesLinkedToHospital().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        $scope.entitiesList = response.data;
                        console.log("$scope.getAllEntitiesLinkedToHospital---->", $scope.entitiesList);
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }

        var getData = ngTableParamsService.get();
        $scope.searchTextField = getData.searchText;
        $scope.searching = function () {
            ngTableParamsService.set('', '', $scope.searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.entitiesList = [];
                    dashboardService.getAllEntitiesLinkedToHospital().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        // $scope.paramUrlActive = paramUrl;
                        $scope.entitiesList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }

        $scope.removeSms = function () {
            var smsListArray = [];
            $scope.selectedAll = false;
            angular.forEach($scope.smsList, function (selected) {
                if (selected.selected) {
                    console.log(!selected.selected);
                    smsListArray.push(selected);
                    $scope.List = smsListArray;
                }
            });
            $scope.deleteSmsByHospital($scope.List);
        };
        $scope.checkAllSms = function () {
            if (!$scope.selectedAll) {
                $scope.selectedAll = true;
            } else {
                $scope.selectedAll = false;
            }
            angular.forEach($scope.smsList, function (sms) {
                sms.selected = $scope.selectedAll;
            });
        };

        $scope.checkSms = function ($event, id) {
            $event.stopPropagation();
        };
        $scope.deleteSmsByHospital = function (smsListArray) {
            var obj = {};
            obj.smsListArray = smsListArray;
            if (obj.smsListArray && obj.smsListArray.length > 0) {
                bootbox.confirm('Are you sure, you want to delete this SMS', function (r) {
                    if (r) {
                        dashboardService.deleteSmsByHospital().save(obj, function (response, err) {
                            if (response.code == 200) {
                                toastr.success(response.message);
                                $scope.getSmsMsgList();
                            } else {
                                toastr.error('Something went wrong, please try again later.');
                            }
                        });
                    }
                })
            } else {
                bootbox.alert('Please select SMS to delete.');
            }

        }
        $scope.getDeviceById = function () {
            $scope.deviceData = dashboardService.getDeviceById($stateParams.id).get({}, function (response, err) {
                if (response.code == 200) {
                    console.log('here');
                    $scope.deviceForm = response.data;
                } else {
                    $scope.deviceForm = {};
                }
            });
        }
        $scope.viewDeviceList = function (id) {
            $rootScope.patientId = id;
            $uibModal.open({
                templateUrl: 'modules/dashboard/views/viewDeviceDetails.html',
                size: "lg",
                controller: "ModalCtrl",
                resolve: {
                    items: function () {
                        return {
                            id: id
                        }
                    }
                }
            })
        }
        $scope.viewSms = function (item, read_id) {
            dashboardService.markSmsAsRead(read_id._id).get({}, function (response) {
                if (response.code == 200) {
                    $scope.getSmsMsgList();
                }
            });
            $uibModal.open({
                templateUrl: '/modules/dashboard/views/sms/viewSms.html',
                size: "lg",
                controller: function ($scope, $uibModalInstance) {
                    $scope.smsDetails = item;
                    $scope.cancel = function () {
                        $uibModalInstance.dismiss('cancel');
                    };

                }
            });
        }
    }
])

iotiedApp.controller('ModalCtrl', ['$scope', '$uibModal', '$state', '$stateParams', 'dashboardService', '$uibModalInstance', 'items', 'ngTableParams', 'ngTableParamsService',
    function ($scope, $uibModal, $state, $stateParams, dashboardService, $uibModalInstance, items, ngTableParams, ngTableParamsService) {
        $scope.role_id = '';
        $scope.viewDeviceListForPatient = function () {
            $scope.viewdeviceData = dashboardService.viewDeviceListForPatient().get({ id: $scope.patientId }, function (response, err) {
                if (response.code == 200) {
                    $scope.viewdeviceData = response.data;
                } else {
                    $scope.viewdeviceData = {};
                }
            });
        }
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
        $(document).ready(function () {
            $(".fancybox").fancybox();
        });

        $scope.deleteDevice = function (devId) {
            bootbox.confirm('Are you sure, you want to delete this device detail?', function (r) {
                if (r) {
                    $scope.deviceData = dashboardService.deleteDevice(devId).get({}, function (response, err) {
                        if (response.code == 200) {
                            toastr.success(response.message);
                            $scope.viewDeviceListForPatient();
                        } else {
                            toastr.error('Something went wrong, please try again later.');
                        }
                    });
                }
            })

        }
    }]);

