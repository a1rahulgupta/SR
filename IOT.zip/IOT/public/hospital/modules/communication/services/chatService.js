"use strict"

angular.module("Chat")

.factory('ChatService', ['$http', '$resource', function($http, $resource) {

        var getPatientAllingedUserList = function () {
            return $resource('/api/v1/getPatientAllingedUserList', null, {
                get: {
                    method: 'GET'
                }
            });
        }

          var getAllEntitiesLinkedToHospital = function () {
            return $resource('/api/v1/getAllEntitiesLinkedToHospital', null, {
                save: {
                    method: 'POST'
                }
            });
        }


    return {
        getPatientAllingedUserList: getPatientAllingedUserList,
        getAllEntitiesLinkedToHospital: getAllEntitiesLinkedToHospital
    }

}]);
