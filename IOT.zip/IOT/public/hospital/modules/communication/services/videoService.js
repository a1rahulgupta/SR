"use strict"

angular.module("videoChat")

    .factory('videoService', ['$http', '$resource', function ($http, $resource) {

        var getAllEntitiesLinkedToClinician = function () {
            return $resource('/api/v1/getAllEntitiesLinkedToClinician', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getAllEntitiesLinkedToHospital = function () {
            return $resource('/api/v1/getAllEntitiesLinkedToHospital', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var acceptCall = function () {
            return $resource('/api/v1/acceptCall', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var rejectCall = function () {
            return $resource('/api/v1/rejectCall', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        return {
            getAllEntitiesLinkedToClinician: getAllEntitiesLinkedToClinician,
            getAllEntitiesLinkedToHospital: getAllEntitiesLinkedToHospital,
            acceptCall:acceptCall,
            rejectCall:rejectCall

        }


    }]);