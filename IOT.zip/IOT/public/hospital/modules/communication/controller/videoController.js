var appchat = angular.module('videoChat')
appchat.controller("videoController", ['$scope', '$state', '$http', '$rootScope', '$window', 'videoService', 'socket', 'toastr', '$timeout',
    function ($scope, $state, $http, $rootScope, $window, videoService, socket, toastr, $timeout) {
        var callerId;

        if ($window.localStorage.hospitalId) {
            $rootScope.hospital = $window.localStorage.hospitalId;
            console.log("$scope.hospital", $rootScope.hospital);
        }

        $scope.open = function () {
            $timeout(function () {
                document.getElementById("button-join").click();
            }, 100);
        }
 

        $scope.connect = function (id) {
            callerId = id;
            var data = {};
             data.id = id;
             data.callerName = "Hospital - " + $window.localStorage.hospitalName; 
            socket.emit('roomName', data);
        }

        socket.on('acceptAlert', function (acceptData) {
            if (acceptData.joinId == callerId) {
                toastr.info(acceptData.name + " " + "Accept Your Call");
                acceptData.status = '2';
                videoService.acceptCall().save(acceptData, function(response){
                console.log("acceptCall---->", response);
                })
            }
        })

        socket.on('rejectAlert', function (rejectData) {
            if (rejectData.joinId == callerId) {
                toastr.error(rejectData.name + " " + "Decline Your Call");
                rejectData.status = '1';
                videoService.rejectCall().save(rejectData, function(response){
                console.log("acceptCall---->", response);
                })
            }
        })

        $scope.getAllEntitiesLinkedToHospital = function () {
            $scope.entitiesList = [];
            videoService.getAllEntitiesLinkedToHospital().save({}, function (response) {
                if (response.code == 200) {
                    $scope.entitiesList = response.data;
                    console.log("$scope.getAllEntitiesLinkedToHospital---->", $scope.entitiesList);
                }
            });
        };
        $scope.$on('$viewContentLoaded', function () {
            document.getElementById("button-join").style.display = "none";
        });
        $scope.$watch("hospital_id", function (newValue, oldValue) {
            if ($scope.hospital_id) {
                document.getElementById("button-join").style.display = "block";
                document.getElementById("button-join").style.marginLeft = "48%";
            }
        });

    }]);