"use strict"

angular.module("Towing")

.factory('towingService', ['$http', '$resource', function($http, $resource) {

    var addTowingByHospital = function() {
        return $resource('/api/v1/addTowingByHospital', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllTowingByHospital = function() {
        return $resource('/api/v1/getAllTowingByHospital', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getTowingById = function(id) {
        console.log('getTowingById', id);
        return $resource('/api/v1/getTowingById/' + id, null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var enableDisableTowing = function() {
        return $resource('/api/v1/enableDisableTowing', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteTowing = function(id) {
        return $resource('/api/v1/deleteTowingById/' + id, null, {
            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var getCountry = function() {
        return $resource('/api/v1/auth/getCountry', null, {
            get: {
                method: 'GET'
            }
        });
    }
     var getServiceType = function() {
        return $resource('/api/v1/auth/getServiceType', null, {
            get: {
                method: 'GET'
            }
        });
    }

    return {
        addTowingByHospital: addTowingByHospital,
        getTowingById: getTowingById,
        getAllTowingByHospital: getAllTowingByHospital,
        enableDisableTowing: enableDisableTowing,
        deleteTowing: deleteTowing,
        getCountry: getCountry,
        getServiceType:getServiceType
    }

}]);
