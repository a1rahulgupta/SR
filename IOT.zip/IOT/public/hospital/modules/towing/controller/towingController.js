"use strict";

angular.module('Towing')
    .controller("towingController", ['$scope', '$rootScope', '$localStorage', '$routeParams',
        '$route', '$location', '$state', '$stateParams', '$http', 'toastr', 'towingService', 'ngTableParams', 'ngTableParamsService',
        function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state,
            $stateParams, $http, toastr, towingService, ngTableParams, ngTableParamsService) {

            $scope.disableSubmitBtn = false;
            $scope.loader = false;
            $scope.patientForm = {};
            $scope.dateModel = {};

            $scope.getCountry = function() {
                console.log("here");
                towingService.getCountry().get({}, function(response, err) {
                    if (response.code == 200) {
                        $scope.country = response.data;
                    } else {
                        $scope.country = {};
                    }
                });
            }

            $scope.addTowingByHospital = function() {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                console.log("addTowingByHospital", $scope.towingForm);
                var towingForm = $scope.towingForm;
                if ($state.params.id) {
                    towingForm.id = $state.params.id;
                }
                console.log("$scope.towingForm", towingForm);
                towingService.addTowingByHospital().save(towingForm, function(response) {
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        toastr.success(response.message);
                        $location.path('/towingList');
                        $scope.patientFlag = false;
                        $scope.towingFlag = true;
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            };

            $scope.getTowingById = function() {
                var id = $state.params.id;
                console.log(id);
                towingService.getTowingById(id).get(function(response, err) {
                    if (response.code == 200) {
                        console.log("response", response.data);
                        var towingData = response.data;
                        towingData.email = response.data.user_id.email;
                        $scope.towingForm = towingData;
                    } else {
                        $scope.towingForm = {};
                    }
                });
            };

            $scope.getAllTowingByHospital = function() {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.towingList = [];
                        towingService.getAllTowingByHospital().save($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.towingList = response.data;
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.getAllTowingByHospitalSearch = function(searchTextField) {
                ngTableParamsService.set('', '', searchTextField, '');
                console.log("searchtextfield", searchTextField);
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.towingList = [];
                        towingService.getAllTowingByHospital().save($scope.paramUrl, function(response) {
                            $scope.tableLoader = false;
                            $scope.towingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.totalCount;
                            params.total(response.totalCount);
                            $defer.resolve(data);
                        });
                    }
                });
            };

            $scope.enableDisableTowing = function(id, condition) {
                var status;
                if (condition == 'Active') {
                    status = true;
                } else {
                    status = false;
                }
                towingService.enableDisableTowing().save({ userId: id, status: status }, function(response) {
                    if (response.code == 200) {
                        $scope.getAllTowingByHospital();
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                })
            };

            $scope.deleteTowing = function(id) {
                console.log("deleteTowing", id);
                bootbox.confirm('Are you sure you want to delete', function(r) {
                    if (r) {
                        towingService.deleteTowing(id).delete(function(response) {
                            if (response.code == 200) {
                                $scope.getAllTowingByHospital();
                                toastr.success(response.message);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                })
            }
             $scope.getServiceType = function() {
                towingService.getServiceType().get({}, function(response, err) {
                    if (response.code == 200) {
                        $scope.service = response.data;
                    } else {
                        $scope.country = {};
                    }
                });
            }



        }
    ]);
