"use strict"

angular.module("CareCoordinator")

.factory('careCoordinatorService', ['$http', '$resource', function($http, $resource) {

    var addCareCoordinatorByHospital = function() {
        return $resource('/api/v1/addCareCoordinatorByHospital', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllCareCoordinatorByHospital = function() {
        return $resource('/api/v1/getAllCareCoordinatorByHospital', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getCareCoordinatorById = function(id) {
        return $resource('/api/v1/getCareCoordinatorById/' + id, null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var enableDisableCoordinator = function() {
        return $resource('/api/v1/enableDisableCoordinator', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteCareCoordinator = function(id) {
        return $resource('/api/v1/deleteCareCoordinatorById/' + id, null, {
            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var getCountry = function(deviceId) {
        return $resource('/api/v1/auth/getCountry', null, {
            get: {
                method: 'GET'
            }
        });
    }

    return {
        addCareCoordinatorByHospital: addCareCoordinatorByHospital,
        getCareCoordinatorById: getCareCoordinatorById,
        getAllCareCoordinatorByHospital: getAllCareCoordinatorByHospital,
        enableDisableCoordinator: enableDisableCoordinator,
        deleteCareCoordinator: deleteCareCoordinator,
        getCountry: getCountry
    }

}]);
