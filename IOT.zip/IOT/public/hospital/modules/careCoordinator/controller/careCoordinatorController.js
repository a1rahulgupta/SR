"use strict";

angular.module('CareCoordinator')
    .controller("careCoordinatorController", ['$scope', '$rootScope', '$localStorage', '$routeParams',
        '$route', '$location', '$state', '$stateParams', '$http', 'toastr', 'careCoordinatorService', 'ngTableParams', 'ngTableParamsService',
        function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state,
            $stateParams, $http, toastr, careCoordinatorService, ngTableParams, ngTableParamsService) {

            $scope.disableSubmitBtn = false;
            $scope.loader = false;
            $scope.patientForm = {};
            $scope.dateModel = {};

            $scope.getCountry = function() {
                careCoordinatorService.getCountry().get({}, function(response, err) {
                    // console.log('response',response);
                    if (response.code == 200) {
                        $scope.country = response.data;
                    } else {
                        $scope.country = {};
                    }
                });
            }

            $scope.addCareCoordinatorByHospital = function() {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                var careCoordinatorForm = $scope.coordinatorForm;
                if ($state.params.id) {
                    careCoordinatorForm.id = $state.params.id;
                }
                careCoordinatorService.addCareCoordinatorByHospital().save(careCoordinatorForm, function(response) {
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        toastr.success(response.message);
                        $location.path('/careCoordinatorList');
                        $scope.patientFlag = false;
                        $scope.coordinatorFlag = true;
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            };

            $scope.getCareCoordinatorById = function() {
                var id = $state.params.id;
                careCoordinatorService.getCareCoordinatorById(id).get(function(response, err) {
                    if (response.code == 200) {
                        var coordinatorData = response.data;
                        coordinatorData.email = response.data.user_id.email;
                        $scope.coordinatorForm = coordinatorData;
                    } else {
                        $scope.coordinatorForm = {};
                    }
                });
            };

            $scope.getAllCareCoordinatorByHospital = function() {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.careCoordinatorList = [];
                        careCoordinatorService.getAllCareCoordinatorByHospital().save($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.careCoordinatorList = response.data;
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.Searching = function(searchTextField) {
                ngTableParamsService.set('', '', searchTextField, '');
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.careCoordinatorList = [];
                        careCoordinatorService.getAllCareCoordinatorByHospital().save($scope.paramUrl, function(response) {
                            $scope.tableLoader = false;
                            $scope.careCoordinatorList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.totalCount;
                            params.total(response.totalCount);
                            $defer.resolve(data);
                        });
                    }
                });
            };

            $scope.enableDisableCoordinator = function(id, condition) {
                var status;
                if (condition == 'Active') {
                    status = true;
                } else {
                    status = false;
                }
                careCoordinatorService.enableDisableCoordinator().save({ userId: id, status: status }, function(response) {
                    if (response.code == 200) {
                        $scope.getAllCareCoordinatorByHospital();
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                })
            };

            $scope.deleteCareCoordinator = function(id) {
                bootbox.confirm('Are you sure you want to delete', function(r) {
                    if (r) {
                        careCoordinatorService.deleteCareCoordinator(id).delete(function(response) {
                            if (response.code == 200) {
                                $scope.getAllCareCoordinatorByHospital();
                                toastr.success(response.message);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                })
            }


        }
    ]);
