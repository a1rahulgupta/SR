"use strict"

angular.module("videoChat")

    .factory('videoService', ['$http', '$resource', function ($http, $resource) {
  
            var getAllEntitiesLinkedToCareCoordinator = function () {
            return $resource('/api/v1/getAllEntitiesLinkedToCareCoordinator', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var acceptCall = function () {
            return $resource('/api/v1/acceptCall', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var rejectCall = function () {
            return $resource('/api/v1/rejectCall', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        return {
            getAllEntitiesLinkedToCareCoordinator: getAllEntitiesLinkedToCareCoordinator,
            acceptCall:acceptCall,
            rejectCall:rejectCall

        }


    }]);