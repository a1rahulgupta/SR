"use strict";

//angular.module("Login", ['ngCookies'])
var iotiedApp = angular.module('login.controller', ['ngCookies']);
iotiedApp.controller('loginController', ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', 'toastr', '$window', '$cookies', 'loginService',
    function ($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, toastr, $window, $cookies, loginService) {

        $rootScope.title = 'Login';
        $scope.loginForm = {};
        $scope.loginForm.email = '';
        $scope.loginForm.password = '';
        $scope.disableLoginSbmtBtn = false;
        $scope.loader = false;
        $scope.loginForm.email = $cookies.get('iotied.email');
        $scope.loginForm.password = $cookies.get('iotied.password');
        $scope.loginForm.remember = $cookies.get('iotied.remember');
        //$scope.loginForm.email = $cookies.get('iotied.email');
        //$scope.loginForm.password = $cookies.get('iotied.password');

        $scope.loginCareCoordinator = function () {
            console.log("login care Coordinator");
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableLoginSbmtBtn = true;
                $scope.loader = true;
                $scope.loginForm.role = 'CareCoordinator';
                loginService.login().save($scope.loginForm, function (response) {
                    $scope.disableLoginSbmtBtn = false;
                    $scope.loader = false;
                    if ($scope.loginForm.remember) {
                        $cookies.put('iotied.email', $scope.loginForm.email);
                        $cookies.put('iotied.password', $scope.loginForm.password);
                        $cookies.put('iotied.remember',$scope.loginForm.remember);
                        
                    } else {
                        $cookies.remove("iotied.email");
                        $cookies.remove("iotied.password");
                        $cookies.remove("iotied.remember");
                    }

                    /*if($scope.selectedUsers){
                      $cookies.put('iotied.email',$scope.loginForm.email);
                      $cookies.put('iotied.password',$scope.loginForm.password);
                    }else{
                      $cookies.remove("iotied.email");
                      $cookies.remove("iotied.password");
                    } */

                    if (response.code === 200) {
                        $window.localStorage.token = response.data.token;
                        $window.localStorage.userLoggedin = true;
                        //$rootScope.userLoggedin = true;
                        //window.location.href = 'http://'+$window.location.host+$window.location.pathname+'#!/dashboard';

                        $http.get('/api/v1/getcareCoordinatorDetails', { headers: { 'Authorization': $window.localStorage.token } })
                            .then(function (response) {
                                if (response.data.code == 200) {
                                    $rootScope.userInfo = response.data.data;
                                    $window.localStorage.careCoordinatorId = response.data.data._id;
                                    $window.localStorage.careCoordinatorName = response.data.data.first_name + " " + response.data.data.last_name;
                                    console.log("$window.localStorage.careCoordinatorId----------------->>>>>>>>>", $window.localStorage.careCoordinatorId);
                                    var userData = {};
                                    userData.first_name = response.data.data.first_name;
                                    userData.last_name = response.data.data.last_name;
                                    userData.SSN = response.data.data.SSN;
                                    userData.address = response.data.data.address;
                                    userData.mobile_no = response.data.data.mobile_no;
                                    userData.city = response.data.data.city;
                                    userData.state = response.data.data.state;
                                    userData.zip_code = response.data.data.zip_code;
                                    userData.country = response.data.data.country;
                                    userData.careCoordinator_npi_no = response.data.data.careCoordinator_npi_no;
                                    userData.image = response.data.data.image;
                                    $rootScope.userInfo = response.data.data;
                                    $rootScope.userData = userData;
                                } else {
                                    console.log('Something went wrong please try again!!!', 'Error');
                                }
                            });

                        window.location = '//' + $window.location.host + $window.location.pathname + '#!/dashboard';

                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableLoginSbmtBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };


        $scope.careCoordinatorSignUp = function () {
            $scope.err = '';
            $scope.disableSubmitBtn = true;
            $scope.loader = true;
            console.log("careCoordinatorSignUp", $scope.signUpForm);
            var password = $scope.signUpForm.password;
            var confirm_password = $scope.confirm_password;
            if (password == confirm_password) {
                loginService.careCoordinatorSignUp().save($scope.signUpForm, function (response) {
                    //console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        $location.path('/login');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            } else if (password != confirm_password) {
                toastr.info("Password and confirm password not matched");
            } else {
                console.log("error");
            }
        };

        $scope.getCountry = function () {
            console.log("here");
            loginService.getCountry().get({}, function (response, err) {
                // console.log('response',response);
                if (response.code == 200) {
                    console.log("getCountry", response.data);
                    $scope.country = response.data;
                } else {
                    $scope.country = {};
                }
            });
        }
        $scope.forgotForm = {}
        $scope.forgotRequest = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableLoginSbmtBtn = true;
                $scope.loader = true;
                // $scope.forgotForm.role = 'Patient';
                loginService.forgotpass().save($scope.forgotForm, function (response) {
                    $scope.disableLoginSbmtBtn = false;
                    $scope.loader = false;
                    if (response.code === 200) {
                        delete $scope.forgotForm;
                        $scope.successMsg = true;
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableLoginSbmtBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        }
        $scope.chkResetToken = function () {

            var token = $stateParams.token;
            console.log('token', token);
            $scope.tokenData = loginService.chkResetToken().get({ 'token': token }, function (response, err) {
                console.log(response.code);
                if (response.code == 200) {
                    //valid token
                } else {
                    toastr.error(response.message, 'Error');
                    $state.go('login');
                }
            });
        }
        $scope.resetForm = {}
        $scope.resetpassword = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableLoginSbmtBtn = true;
                $scope.loader = true;
                var token = $stateParams.token;
                if ($scope.resetForm && $scope.resetForm.password == $scope.resetForm.conf_password) {
                    $scope.resetForm.token = token;
                    loginService.resetPassword().save($scope.resetForm, function (response) {
                        console.log(response.code);
                        if (response.code == 200) {
                            toastr.success(response.message);
                            $scope.disableLoginSbmtBtn = false;
                            $state.go('login');
                        } else {
                            toastr.error(response.message, 'Error');
                            $scope.disableLoginSbmtBtn = false;
                        }
                    });
                } else {
                    toastr.error('Confirm password does not match with password.', 'Error');
                }
            }
        }

        $scope.getHospitalForReg = function () {
            loginService.getHospitalForReg().get({}, function (response, err) {
                console.log('response', response);
                if (response.code == 200) {
                    console.log("getHospitalForReg", response.data);
                    $scope.hospitalList = response.data;
                } else {
                    $scope.hospitalList = {};
                }
            });
        }
    }


]);
