"use strict";

//angular.module("Login", ['ngCookies'])
var iotiedApp = angular.module('login.controller', ['ngCookies']);
iotiedApp.controller('loginController', ['$scope', 'loginService', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', 'toastr', '$window', '$cookies',
    function ($scope, loginService, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, toastr, $window, $cookies) {
        $rootScope.title = 'Login';
        $scope.loginForm = {};
        $scope.loginForm.email = '';
        $scope.loginForm.password = '';
        $scope.disableLoginSbmtBtn = false;
        $scope.loader = false;
        $scope.userData = {};
        $scope.userData.gender = false;
        $scope.loginForm.email = $cookies.get('iotied.email');
        $scope.loginForm.password = $cookies.get('iotied.password');
        $scope.loginForm.remember = $cookies.get('iotied.remember');

        $scope.loginUser = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableLoginSbmtBtn = true;
                $scope.loader = true;
                $scope.loginForm.role = 'Admin';
                console.log("--------", $scope.loginForm);
                loginService.login().save($scope.loginForm, function (response) {
                    $scope.disableLoginSbmtBtn = false;
                    $scope.loader = false;
                       if ($scope.loginForm.remember) {
                        $cookies.put('iotied.email', $scope.loginForm.email);
                        $cookies.put('iotied.password', $scope.loginForm.password);
                        $cookies.put('iotied.remember',$scope.loginForm.remember);
                        
                    } else {
                        $cookies.remove("iotied.email");
                        $cookies.remove("iotied.password");
                        $cookies.remove("iotied.remember");
                    }
                    /*if($scope.selectedUsers){
                      $cookies.put('iotied.email',$scope.loginForm.email);
                      $cookies.put('iotied.password',$scope.loginForm.password);
                    }else{
                      $cookies.remove("iotied.email");
                      $cookies.remove("iotied.password");
                    } */


                    if (response.code === 200) {
                        $window.localStorage.token = response.data.token;
                        $window.localStorage.userLoggedin = true;
                        console.log("role---------------------", response.data.role);
                        //$rootScope.userLoggedin = true;
                        //window.location.href = 'http://'+$window.location.host+$window.location.pathname+'#!/dashboard';
                        $http.get('/api/v1/getAdminDetails', { headers: { 'Authorization': $window.localStorage.token } })
                            .then(function (response) {
                                console.log("response in login", response);
                                if (response.data.code == 200) {
                                    var userData = {};
                                    userData.first_name = response.data.data.first_name;
                                    userData.last_name = response.data.data.last_name;
                                    $rootScope.userInfo = response.data.data;
                                    $rootScope.userData = userData;
                                } else {
                                    console.log('Something went wrong please try again!!!', 'Error');
                                }
                            });



                        window.location = '//' + $window.location.host + $window.location.pathname + '#!/dashboard';

                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableLoginSbmtBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };
        $scope.forgotForm = {}
        $scope.forgotRequest = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableLoginSbmtBtn = true;
                $scope.loader = true;
                // $scope.forgotForm.role = 'Patient';
                loginService.forgotpass().save($scope.forgotForm, function (response) {
                    $scope.disableLoginSbmtBtn = false;
                    $scope.loader = false;
                    if (response.code === 200) {
                        delete $scope.forgotForm;
                        $scope.successMsg = true;
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableLoginSbmtBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        }
        $scope.chkResetToken = function () {

            var token = $stateParams.token;
            console.log('token', token);
            $scope.tokenData = loginService.chkResetToken().get({ 'token': token }, function (response, err) {
                console.log(response.code);
                if (response.code == 200) {
                    //valid token
                } else {
                    toastr.error(response.message, 'Error');
                    $state.go('login');
                }
            });
        }
        $scope.resetForm = {}
        $scope.resetpassword = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableLoginSbmtBtn = true;
                $scope.loader = true;
                var token = $stateParams.token;
                if ($scope.resetForm && $scope.resetForm.password == $scope.resetForm.conf_password) {
                    $scope.resetForm.token = token;
                    loginService.resetPassword().save($scope.resetForm, function (response) {
                        console.log(response.code);
                        if (response.code == 200) {
                            toastr.success(response.message);
                            $scope.disableLoginSbmtBtn = false;
                            $state.go('login');
                        } else {
                            toastr.error(response.message, 'Error');
                            $scope.disableLoginSbmtBtn = false;
                        }
                    });
                } else {
                    toastr.error('Confirm password does not match with password.', 'Error');
                }
            }
        }
    }

]);
