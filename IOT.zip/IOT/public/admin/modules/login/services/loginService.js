"use strict"

angular.module("Login")

.factory('loginService', ['$http', '$resource', function($http, $resource) {

    var login = function() {
        return $resource('/api/v1/auth/login', null, {
            'save': { method: 'POST' }
        });
    }
    var forgotpass = function(){
        return $resource('/api/v1/auth/forgotpass', null, {
            'save': { method: 'POST' }
        });   
    }
    var chkResetToken = function(){
        return $resource('/api/v1/auth/checkResetToken', null, {
            get: { 
                method: 'GET'
            }
        });
    }
    var resetPassword = function(){
        return $resource('/api/v1/auth/resetPassword', null, {
            'save': { method: 'POST' }
        });      
    }
    return {
        login: login,
        forgotpass:forgotpass,
        chkResetToken:chkResetToken,
        resetPassword:resetPassword
    }

}]);
