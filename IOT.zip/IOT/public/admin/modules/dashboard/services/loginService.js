"use strict"

angular.module("Login").factory('dashboardService', ['$http', '$resource', function($http, $resource) {

    var getDashboardList = function() {
        return $resource('/api/getDashboardList', null, {
            get: {
                method: 'GET'
            }
        });
    }
    var getDashboardItem = function() {
        return $resource('/api/getDashboardItem', null, {
            save: {
                method: 'POST'
            }
        });
    }
    var forgotpass = function(){
        return $resource('/api/v1/auth/forgotpass', null, {
            'save': { method: 'POST' }
        });   
    }
    var chkResetToken = function(){
        return $resource('/api/v1/auth/checkResetToken', null, {
            get: { 
                method: 'GET'
            }
        });
    }
    var resetPassword = function(){
        return $resource('/api/v1/auth/resetPassword', null, {
            'save': { method: 'POST' }
        });      
    }
    
    return {
        getDashboardList: getDashboardList,
        getDashboardItem: getDashboardItem,
        forgotpass:forgotpass,
        chkResetToken:chkResetToken,
        resetPassword:resetPassword
    }

}]);

