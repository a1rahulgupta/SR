"use strict"

angular.module("Dashboard")

    .factory('dashboardService', ['$http', '$resource', function ($http, $resource) {


        var connectWithing = function () {
            return $resource('/api/v1/withings/connect', null, {
                get: {
                    method: 'GET'
                }
            });
        }

        var devicemanagementList = function () {
            return $resource('/api/v1/getDeviceManagementList', null, {
                get: {
                    method: 'GET'
                }
            })
        }


        var getDeviceManagementById = function (id) {
            return $resource('/api/v1/getDeviceManagementById/' + id, null, {
                save: {
                    method: 'GET'
                }
            });
        }

        var editDeviceManagement = function (id) {
            return $resource('/api/v1/editDeviceManagement', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var enableDisableDevice = function () {
            return $resource('/api/v1/enableDisableDevice', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getDeviceList = function () {
            return $resource('/api/v1/api/getPatientDevice', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var activityList = function () {
            return $resource('/api/v1/getPatientActivity', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var updateAdminProfile = function () {
            return $resource('/api/v1/updateAdminProfile', null, {
                save: {
                    method: 'POST',
                    headers: { 'Content-Type': undefined }
                }
            });
        }
        var addDevice = function () {
            return $resource('/api/v1/api/addPatientDevice', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var saveRules = function () {
            return $resource('/api/v1/saveRulesEngine', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var getRules = function () {
            return $resource('/api/v1/getRules', null, {
                save: {
                    method: 'GET'
                }
            });
        }
        var kmeans = function () {
            return $resource('/api/v1/kmeans', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var uploadcsv = function () {
            console.log('hsdfhsd');
            return $resource('/api/v1/uploadcsv', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var getcsvList = function () {
            return $resource('/api/v1/getCsvfiles', null, {
                save: {
                    method: 'GET'
                }
            });
        }
        var kmeansnew = function () {
            return $resource('/api/v1/kmeans', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var getDataForKmean = function () {
            return $resource('/api/v1/kmeansData', null, {
                save: {
                    method: 'GET'
                }
            });
        }

        var addRulesEngines = function () {
            return $resource('/api/v1/addRulesEngines', null, {
                save: {
                    method: 'POST'
                }
            });
        }



        var getAllRulesEngines = function () {
            return $resource('/api/v1/getAllRulesEngines', null, {
                get: {
                    method: 'GET'
                }
            })
        }

        var getDefaultRulesEngine = function () {
            return $resource('/api/v1/getDefaultRulesEngine', null, {
                get: {
                    method: 'GET'
                }
            })
        }


        var getRulesEnginesById = function (id) {
            return $resource('/api/v1/getRulesEnginesById/' + id, null, {
                save: {
                    method: 'GET'
                }
            });
        }

        var deleteRulesEngine = function (id) {
            return $resource('/api/v1/deleteRulesEngine/' + id, null, {
                save: {
                    method: 'GET'
                }
            });
        }

        var enableDisableRules = function () {
            return $resource('/api/v1/enableDisableRules', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var setDefault = function () {
            console.log("")
            return $resource('/api/v1/setDefault', null, {
                save: {
                    method: 'POST'
                }
            })
        }

        var getSmsTemplateList = function () {
            return $resource('/api/v1/getSmsTemplateListByAdmin', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var addSmsTemplate = function () {
            return $resource('/api/v1/addSmsTemplateByAdmin', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var getSmsTemplateById = function (id) {
            return $resource('/api/v1/getSmsTemplateByIdAdmin/' + id, null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            });
        }
        var deleteSmsTemplate = function (id) {
            return $resource('/api/v1/deleteSmsTemplateByAdmin/' + id, null, {
                save: {
                    method: 'GET'
                }
            });
        }





        return {
            connectWithing: connectWithing,
            addDevice: addDevice,
            getDeviceList: getDeviceList,
            activityList: activityList,
            saveRules: saveRules,
            getRules: getRules,
            kmeans: kmeans,
            uploadcsv: uploadcsv,
            getcsvList: getcsvList,
            kmeansnew: kmeansnew,
            updateAdminProfile: updateAdminProfile,
            getDataForKmean: getDataForKmean,
            devicemanagementList: devicemanagementList,
            getDeviceManagementById: getDeviceManagementById,
            editDeviceManagement: editDeviceManagement,
            enableDisableDevice: enableDisableDevice,
            addRulesEngines: addRulesEngines,
            getAllRulesEngines: getAllRulesEngines,
            getRulesEnginesById: getRulesEnginesById,
            deleteRulesEngine: deleteRulesEngine,
            enableDisableRules: enableDisableRules,
            setDefault: setDefault,
            getDefaultRulesEngine: getDefaultRulesEngine,
            addSmsTemplate: addSmsTemplate,
            getSmsTemplateList: getSmsTemplateList,
            getSmsTemplateById: getSmsTemplateById,
            deleteSmsTemplate: deleteSmsTemplate



        }

    }]);
