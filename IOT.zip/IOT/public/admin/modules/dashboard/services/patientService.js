"use strict"

angular.module("Patient")

.factory('patientService', ['$http', '$resource', function($http, $resource) {

    var getSmokingStatus = function() {
        return $resource('/api/v1/getSmokingStatus', null, {
            get: {
                method: 'GET'
            }
        });
    }

    var getAllPatient = function() {
        return $resource('/api/v1/getAllPatient', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deletePatient = function(id) {
        return $resource('/api/v1/deletePatientById/' + id, null, {
            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var getAllHospital = function() {
        return $resource('/api/v1/getAllHospital', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllClinician = function() {
        return $resource('/api/v1/getAllClinician', null, {
            save: {
                method: 'POST'
            }
        });
    }
    var getAllAmbulance = function() {
        return $resource('/api/v1/getAllAmbulance', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllTowing = function() {
        return $resource('/api/v1/getAllTowing', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getPatientVitals = function() {
        return $resource('/api/v1/getPatientVitals', null, {
            get: {
                method: 'GET'
            }
        });
    }

    var getAllCareCoordinator = function() {
        return $resource('/api/v1/getAllCareCoordinator', null, {
            get: {
                method: 'GET'
            }
        });
    }

    var deleteHospital = function(id) {
        return $resource('/api/v1/deleteHospitalById/' + id, null, {
            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    return {
        getAllPatient: getAllPatient,
        getAllHospital:getAllHospital,
        getAllClinician:getAllClinician,
        getAllAmbulance:getAllAmbulance,
        getPatientVitals: getPatientVitals,
        getAllTowing:getAllTowing,
        getAllCareCoordinator:getAllCareCoordinator,
        deletePatient: deletePatient,
        deleteHospital:deleteHospital
    }

}]);
