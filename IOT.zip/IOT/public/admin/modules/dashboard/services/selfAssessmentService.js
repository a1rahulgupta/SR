"use strict"

angular.module("SelfAssessment")

.factory('SelfAssessmentService', ['$http', '$resource', function($http, $resource) {

    var getEthinicity = function() {
        return $resource('/api/v1/getEthinicity', null, {
            get: {
                method: 'GET'
            }
        });
    }
    var getDiabetesStatus = function() {
        return $resource('/api/v1/getDiabetesStatus', null, {
            get: {
                method: 'GET'
            }
        });
    }
    var getSmokingStatus = function() {
        return $resource('/api/v1/getSmokingStatus', null, {
            get: {
                method: 'GET'
            }
        });
    }

    var addRiskAssessment = function() {
        return $resource('/api/v1/addRiskAssessment', null, {
            save: {
                method: 'POST'
            }
        });
    }

    return {
        addRiskAssessment: addRiskAssessment,
        getEthinicity: getEthinicity,
        getDiabetesStatus: getDiabetesStatus,
        getSmokingStatus: getSmokingStatus
    }

}]);
