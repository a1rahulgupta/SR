"use strict"

angular.module("RiskAssessment")

.factory('riskAssessmentService', ['$http', '$resource', function($http, $resource) {

    var getEthinicity = function() {
        return $resource('/api/v1/getEthinicity', null, {
            get: {
                method: 'GET'
            }
        });
    }
    var getDiabetesStatus = function() {
        return $resource('/api/v1/getDiabetesStatus', null, {
            get: {
                method: 'GET'
            }
        });
    }
    var getAllPatientName = function() {
        return $resource('/api/v1/getAllPatientName', null, {
            save: {
                method: 'GET'
            }
        });
    }
    var getSmokingStatus = function() {
        return $resource('/api/v1/getSmokingStatus', null, {
            get: {
                method: 'GET'
            }
        });
    }


    var getRules = function(id) {
        return $resource('/api/v1/getRules/' + id, null, {
            save: {
                method: 'GET'
            }
        });
    }


    var addRiskAssessment = function() {
        return $resource('/api/v1/addRiskAssessment', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getPatientDetailById = function() {
        return $resource('/api/v1/getPatientDetailById/:id', null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getRiskAssessmentReportByPatient = function() {
        return $resource('/api/v1/getRiskAssessmentReportByPatient/:id', null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }
     var getRulesEnginesforRisk = function(){
        return $resource('/api/v1/getRulesEnginesforRisk', null,{
            get: {
                method: 'GET'
            }
        })
    }


    return {
        addRiskAssessment: addRiskAssessment,
        getEthinicity: getEthinicity,
        getDiabetesStatus: getDiabetesStatus,
        getSmokingStatus: getSmokingStatus,
        getAllPatientName: getAllPatientName,
        getPatientDetailById: getPatientDetailById,
        getRiskAssessmentReportByPatient: getRiskAssessmentReportByPatient,
        getRules: getRules,
        getRulesEnginesforRisk:getRulesEnginesforRisk
    }

}]);
