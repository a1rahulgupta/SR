"use strict"

angular.module("EmailTemplate")

.factory('emailTemplateService', ['$http', '$resource', function($http, $resource) {

    var getAllEmailTemplates = function() {
        return $resource('/api/v1/getAllEmailTemplates', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var updateEmailTemplate = function() {
        return $resource('/api/v1/updateEmailTemplate', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getEmailTemplateById = function() {
        return $resource('/api/v1/getEmailTemplateById/:id', null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    return {
        getAllEmailTemplates: getAllEmailTemplates,
        getEmailTemplateById: getEmailTemplateById,
        updateEmailTemplate: updateEmailTemplate
    }

}]);
