"use strict";

angular.module('RiskAssessment')
    .controller("riskAssessmentController", ['$scope', '$rootScope', '$localStorage', 'ngTableParams', 'riskAssessmentService', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', 'toastr', '$uibModal',
        function ($scope, $rootScope, $localStorage, $ngTableParamsService, riskAssessmentService, $routeParams, $route, $location, $state, $stateParams, $http, toastr, $uibModal) {
            $scope.service = { 'vinod': 'telang' };

            $scope.riskAssessmentForm = {};
            $scope.disableSubmitBtn = false;
            $scope.loader = false;
            $scope.cholesterol = {};
            $scope.blood_pressure = {};
            $scope.body_mass = {};
            //$scope.riskAssessmentForm = { user_limit: "1", gender: "Male", age_limit: "1", diabetes: "No", smoker: "No", bp_treatment: "No" };


            $scope.addRiskAssessment = function () {
                if ($scope.form.$valid) {
                    $scope.err = '';
                    $scope.disableSubmitBtn = true;
                    $scope.loader = true;

                    var cholesterol = {
                        total_cholesterol: $scope.cholesterol.total_cholesterol,
                        HDL: $scope.cholesterol.HDL
                    };
                    var blood_pressure = {
                        diastolic: $scope.blood_pressure.diastolic,
                        systolic: $scope.blood_pressure.systolic
                    };
                    // var body_mass = {
                    //     height: $scope.body_mass.height,
                    //     weight: $scope.body_mass.weight
                    // };

                    var riskAssessment = {};

                    riskAssessment.patient_id = $scope.riskAssessmentForm.patient_id;
                    riskAssessment.age = $scope.riskAssessmentForm.age;
                    riskAssessment.gender = $scope.riskAssessmentForm.gender;
                    riskAssessment.mobile_no = $scope.riskAssessmentForm.mobile_no;

                    riskAssessment.smoker = ($scope.riskAssessmentForm.smoker);
                    riskAssessment.diabetes = ($scope.riskAssessmentForm.diabetes);
                    riskAssessment.bp_treatment = ($scope.riskAssessmentForm.bp_treatment);

                    riskAssessment.cholesterol = cholesterol;
                    riskAssessment.blood_pressure = blood_pressure;
                    var getRules_id = $scope.riskAssessmentForm.rulesEngine_id;
                    //riskAssessment.body_mass = body_mass;

                    console.log("riskAssessment----------------", $scope.riskAssessmentForm.rulesEngine_id);
                    //console.log("riskAssessment----------------", cholesterol.total_cholesterol);
                    /// total_cholesterol cholesterol range 130-320
                    riskAssessmentService.getRules(getRules_id).get(function (response) {
                        if (response.code != 200) {
                            toastr.error(response.message, 'Error');
                        } else {
                            $scope.getRuleData = response.data;
                            // console.log("$scope.getRuleData", $scope.getRuleData);
                            var total_cholesterol_LR = $scope.getRuleData.cholesterol.total_cholesterol_lr;
                            var total_cholesterol_HR = $scope.getRuleData.cholesterol.total_cholesterol_hr;
                            var HDL_LR = $scope.getRuleData.cholesterol.HDL_lr;
                            var HDL_HR = $scope.getRuleData.cholesterol.HDL_hr;
                            var systolic_BP_LR = $scope.getRuleData.blood_pressure.systolic.low;
                            var systolic_BP_HR = $scope.getRuleData.blood_pressure.systolic.high;
                            var diastolic_BP_LR = $scope.getRuleData.blood_pressure.diastolic.low;
                            var diastolic_BP_HR = $scope.getRuleData.blood_pressure.diastolic.high;


                            console.log("total_cholesterol_LR", total_cholesterol_LR);
                            console.log("total_cholesterol_HR", total_cholesterol_HR);
                            console.log("HDL_LR", HDL_LR);
                            console.log("HDL_HR", HDL_HR);
                            console.log("systolic_BP_LR", systolic_BP_LR);
                            console.log("systolic_BP_HR", systolic_BP_HR);
                            console.log("diastolic_BP_LR", diastolic_BP_LR);
                            console.log("diastolic_BP_HR", diastolic_BP_HR);

                            //return;
                            if ((total_cholesterol_LR => cholesterol.total_cholesterol) && (cholesterol.total_cholesterol <= total_cholesterol_HR)) {
                                cholesterol.total_cholesterol
                            } else if ((HDL_LR => cholesterol.HDL) && (cholesterol.HDL <= HDL_HR)) {
                                cholesterol.HDL
                            } else if ((systolic_BP_LR => blood_pressure.systolic) && (blood_pressure.systolic <= systolic_BP_HR)) {
                                blood_pressure.systolic
                            } else if ((diastolic_BP_LR => blood_pressure.diastolic) && (blood_pressure.diastolic <= diastolic_BP_HR)) {
                                blood_pressure.diastolic
                            }

                            console.log("riskAssessment------------111----", riskAssessment.cholesterol);

                            riskAssessmentService.addRiskAssessment().save(riskAssessment, function (response) {
                                console.log("----------------###########---------------------", response);
                                $scope.disableSubmitBtn = false;
                                $scope.loader = false;
                                if (response.code == 200) {
                                    //$window.location.href = '/#!/deviceList'
                                    toastr.success(response.message);
                                    $location.path('/riskAssessment');
                                } else {
                                    toastr.error(response.message, 'Error');
                                    $scope.disableSubmitBtn = false;
                                    $scope.loader = false;
                                }
                            });

                        }
                    });
                }
            };


            $scope.viewRiskAssessmentReport = function (id) {
                console.log("id", id);
                $uibModal.open({
                    templateUrl: '/modules/dashboard/views/riskassessmentReport.html',
                    size: "lg",
                    controller: function ($scope, $uibModalInstance) {
                        riskAssessmentService.getRiskAssessmentReportByPatient().get({ id: id }, function (response, err) {
                            if (response.code == 200) {
                                $scope.getRAreport = response.data;
                                var riskColor = $scope.getRAreport.risk
                                if (riskColor < 10) {
                                    riskColor = 'alert-low';
                                } else { riskColor = 'alert-high'; }
                                $scope.getRAreport.riskColor = riskColor;
                            } else {
                                $scope.getRAreport = {};
                            }
                        });
                        $scope.cancel = function () {
                            $uibModalInstance.dismiss('cancel');
                        };

                    }
                });
            };

            $(".selectpicker").selectpicker();
            $scope.getPatientDetailById = function (id) {
                //console.log("id", id);
                $scope.riskAssessmentForm = {};
                $scope.cholesterol = {};
                $scope.blood_pressure = {};
                $scope.body_mass = {};
                riskAssessmentService.getPatientDetailById().get({ id: id }, function (response, err) {

                    if (response.code == 200) {
                         console.log("response--------------->>>>>>>>", response.data.patientData);
                        $scope.riskAssessmentForm = response.data.patientData;
                        $scope.riskAssessmentForm.patient_id = response.data.patientData._id;
                        $scope.riskAssessmentForm.mobile_no = response.data.patientData.mobile_no;
                        $scope.riskAssessmentForm.diabetes = response.data.patientData.diabetes;
                        $scope.riskAssessmentForm.smoker = response.data.patientData.smoker;
                        $scope.riskAssessmentForm.bp_treatment = response.data.patientData.bp_treatment
                        $scope.riskAssessmentForm.age = parseInt(response.data.patientData.age);
                        $scope.cholesterol = response.data.vitalData.cholesterol;
                        $scope.blood_pressure = response.data.vitalData.blood_pressure;
                        $scope.body_mass = response.data.vitalData.body_mass;
                        setTimeout(function () {
                            $('.selectpicker').selectpicker('refresh');
                        }, 1000);
                        $scope.getRulesEnginesforRisk();
                    } else {
                        $scope.getPatientDetailData = {};
                    }
                });
            }




            $scope.getEthinicity = function () {
                riskAssessmentService.getEthinicity().get({}, function (response, err) {
                    if (response.code == 200) {
                        $scope.getEthinicityData = response.data;
                    } else {
                        $scope.getEthinicityData = {};
                    }
                });
            }

            $scope.getAllPatientName = function () {
                riskAssessmentService.getAllPatientName().get({}, function (response, err) {
                    if (response.code == 200) {
                        $scope.getPatientData = response.data;
                    } else {
                        $scope.getPatientData = {};
                    }
                });
            }


            $scope.getAllEthinicity = function () {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function ($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.ethinicityList = [];
                        riskAssessmentService.getEthinicity().get($scope.paramUrl, function (response, err) {

                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.ethinicityList = response.data.data;
                                var data = response.data.data;
                                $scope.totalCount = response.data.totalCount;
                                params.total(response.data.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }


            $scope.getDiabetesStatus = function () {
                riskAssessmentService.getDiabetesStatus().get({}, function (response, err) {
                    if (response.code == 200) {
                        $scope.getDiabetesStatusData = response.data;
                    } else {
                        $scope.getDiabetesStatusData = {};
                    }
                });
            }

            $scope.getSmokingStatus = function () {
                riskAssessmentService.getSmokingStatus().get({}, function (response, err) {
                    if (response.code == 200) {
                        $scope.getSmokingStatusData = response.data;
                    } else {
                        $scope.getSmokingStatusData = {};
                    }
                });
            }
            $scope.getRulesEnginesforRisk = function () {
                $scope.rulesEngine = riskAssessmentService.getRulesEnginesforRisk().get({}, function (response, err) {
                    if (response.code == 200) {
                      $scope.rulesEngine = response.data;
                      var riskAssessmentForm = {};
                      for(var i=0;i< $scope.rulesEngine.length;i++){
                          if($scope.rulesEngine[i].is_default==true){
                            $scope.riskAssessmentForm.rulesEngine_id = $scope.rulesEngine[i]._id; 
                          }
                      }

                    } else {
                        $scope.rulesEngine = {};
                    }
                });
            }

        }
    ]);
