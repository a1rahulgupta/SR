"use strict";

angular.module('Patient')
    .controller("patientController", ['$scope', '$rootScope', '$localStorage', 'patientService', '$routeParams',
        '$route', '$location', '$state', '$stateParams', '$http', 'toastr', 'ngTableParams', 'ngTableParamsService',
        function($scope, $rootScope, $localStorage, patientService, $routeParams, $route, $location, $state,
            $stateParams, $http, toastr, ngTableParams, ngTableParamsService) {
            $scope.service = { 'vinod': 'telang' };

            $scope.disableSubmitBtn = false;
            $scope.loader = false;

            $scope.getAllPatient = function() {
                console.log("in patient");
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.patientList = [];
                        console.log(0);
                        patientService.getAllPatient().get($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.patientList = response.data;
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.getRecord = function() {
                if ($scope.user.selectUser == 'Patient') {
                    $scope.patientFlag = true;
                    $scope.hospitalFlag = false;
                    $scope.clinicianFlag = false;
                    $scope.coordinatorFlag = false;
                    $scope.ambulanceFlag = false;
                    $scope.towingFlag = false;
                } else if ($scope.user.selectUser == 'Hospital') {
                    $scope.patientFlag = false;
                    $scope.hospitalFlag = true;
                    $scope.clinicianFlag = false;
                    $scope.coordinatorFlag = false;
                    $scope.ambulanceFlag = false;
                    $scope.towingFlag = false;
                } else if ($scope.user.selectUser == 'Clinician') {
                    $scope.patientFlag = false;
                    $scope.hospitalFlag = false;
                    $scope.clinicianFlag = true;
                    $scope.coordinatorFlag = false;
                    $scope.ambulanceFlag = false;
                    $scope.towingFlag = false;
                } else if ($scope.user.selectUser == 'CareCoordinator') {
                    $scope.patientFlag = false;
                    $scope.hospitalFlag = false;
                    $scope.clinicianFlag = false;
                    $scope.coordinatorFlag = true;
                    $scope.ambulanceFlag = false;
                    $scope.towingFlag = false;
                } else if ($scope.user.selectUser == 'Ambulance') {
                    $scope.patientFlag = false;
                    $scope.hospitalFlag = false;
                    $scope.clinicianFlag = false;
                    $scope.coordinatorFlag = false;
                    $scope.ambulanceFlag = true;
                    $scope.towingFlag = false;
                } else if ($scope.user.selectUser == 'Towing') {
                    $scope.patientFlag = false;
                    $scope.hospitalFlag = false;
                    $scope.clinicianFlag = false;
                    $scope.coordinatorFlag = false;
                    $scope.ambulanceFlag = false;
                    $scope.towingFlag = true;
                }

            }

            $scope.getAllHospital = function() {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.hospitalList = [];
                        console.log(0);
                        patientService.getAllHospital().get($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.hospitalList = response.data;
                                console.log("response data", response.data);
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.getAllClinician = function() {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.clinicianList = [];
                        console.log(0);
                        patientService.getAllClinician().get($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.clinicianList = response.data;
                                console.log("response data", response.data);
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.getAllAmbulance = function() {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.ambulanceList = [];
                        console.log(0);
                        patientService.getAllAmbulance().get($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.ambulanceList = response.data;
                                console.log("response data", response.data);
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.getAllTowing = function() {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.towingList = [];
                        console.log(0);
                        patientService.getAllTowing().get($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.towingList = response.data;
                                console.log("response data", response.data);
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.getAllCareCoordinator = function() {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.careCoordinatorList = [];
                        console.log(0);
                        patientService.getAllCareCoordinator().get($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.careCoordinatorList = response.data;
                                console.log("response data", response.data);
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.deletePatient = function(id) {

                console.log("deletePatient", id);
                patientService.deletePatient(id).delete(function(response) {
                    if (response.code == 200) {
                        $scope.getAllPatient();
                        toastr.success(response.message);
                    } else {
                        logger.logError(response.message);
                    }
                });
            }

            $scope.deleteHospital = function(id) {

                console.log("deleteHospital", id);
                patientService.deleteHospital(id).delete(function(response) {
                    if (response.code == 200) {
                        $scope.getAllHospital();
                        toastr.success(response.message);
                    } else {
                        logger.logError(response.message);
                    }
                });
            }

        }
    ]);
