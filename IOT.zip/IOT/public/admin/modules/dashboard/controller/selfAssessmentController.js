"use strict";

angular.module('SelfAssessment')
    .controller("selfAssessmentController", ['$scope', '$rootScope', '$localStorage', 'ngTableParams', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', 'SelfAssessmentService', 'toastr',
        function($scope, $rootScope, $localStorage, $ngTableParamsService, $routeParams, $route, $location, $state, $stateParams, $http, SelfAssessmentService, toastr) {
            
            $scope.options = [{ "Option": ""}];

            $scope.removeOptionRow = function (index) {
                $scope.options.splice(index, 1);
              };  
            //add a row in the array
            $scope.addOption = function () {
                // create a blank array
                console.log("here");
                var newrow = [];
                newrow = { "Option": ""};
                // add the new row at the end of the array
                $scope.options.push(newrow);
            };
            
            $scope.addSelfAssessmentQuestion = function() {

                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                console.log("$scope.data", $scope.selfAssessment);
                console.log("$scope.options", $scope.options);
                return;
                var riskAssessment = $scope.riskAssessmentForm;
                riskAssessment.cholesterol = cholesterol;
                riskAssessment.blood_pressure = blood_pressure;
                riskAssessment.body_mass = body_mass;

                // console.log("riskAssessment", riskAssessment);
                riskAssessmentService.addSelfAssessmentQuestion().save(riskAssessment, function(response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        $location.path('/riskAssessment');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });

            };


            // $scope.getEthinicity = function() {
            //     $scope.getEthinicityData = riskAssessmentService.getEthinicity().get({}, function(response, err) {
            //         if (response.code == 200) {
            //             $scope.getEthinicityData = response.data;
            //         } else {
            //             $scope.getEthinicityData = {};
            //         }
            //     });
            // }


        }
    ]);
