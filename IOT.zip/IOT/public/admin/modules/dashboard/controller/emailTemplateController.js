"use strict";

angular.module('EmailTemplate')
    .controller("emailTemplateController", ['$scope', '$rootScope', '$localStorage', 'ngTableParams', 'emailTemplateService', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', 'toastr', '$uibModal', 'ngTableParams', 'ngTableParamsService',
        function($scope, $rootScope, $localStorage, $ngTableParamsService, emailTemplateService, $routeParams, $route, $location, $state, $stateParams, $http, toastr, $uibModal, ngTableParams, ngTableParamsService) {
            $scope.tinymceOptions = {
                plugins: 'link image code',
                toolbar: 'undo redo | bold italic | alignleft aligncenter alignright | code'
            };

            $scope.getAllEmailTemplates = function() {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.emailTemplateList = [];
                        emailTemplateService.getAllEmailTemplates().save($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.emailTemplateList = response.data;
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.getAllEmailTemplateSearching = function(searchTextField) {
                ngTableParamsService.set('', '', searchTextField, '');
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.emailTemplateList = [];
                        emailTemplateService.getAllEmailTemplates().save($scope.paramUrl, function(response) {
                            $scope.tableLoader = false;
                            $scope.emailTemplateList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.totalCount;
                            params.total(response.totalCount);
                            $defer.resolve(data);
                        });
                    }
                });
            };


            $scope.getEmailTemplateById = function(id) {
                if (!id) {
                    id = $stateParams.id
                }
                emailTemplateService.getEmailTemplateById().get({ id: id }, function(response) {
                    if (response.code == 200) {
                        $scope.emailTemplateForm = response.data;
                    } else {
                        $scope.getPatientDetailData = {};
                    }
                });
            }

            $scope.updateEmailTemplate = function() {
                console.log("emailTemplateForm", $scope.emailTemplateForm);
                emailTemplateService.updateEmailTemplate().save($scope.emailTemplateForm, function(response) {
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        $location.path('/emailTemplateList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        }
    ]);
