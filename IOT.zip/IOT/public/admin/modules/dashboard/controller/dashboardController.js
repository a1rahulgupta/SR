"use strict";

var iotiedApp = angular.module('dashboard.controller', []);
iotiedApp.controller("dashboardController", ['$scope', '$rootScope', '$localStorage', 'dashboardService', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', 'toastr',
    function ($scope, $rootScope, $localStorage, dashboardService, $routeParams, $route, $location, $state, $stateParams, $http, toastr) {

        $scope.service = { 'vinod': 'telang' };
        var formDataFileUpload = '';
        $scope.imageBase64 = '';
        $scope.colors = ["red", "green", "blue", "yellow", "orange", "grey"];
        $scope.connectToWithings = function (devId) {
            $scope.connectData = dashboardService.connectWithing().get({ 'deviceId': devId }, function (response, err) {
                console.log('response', response);
                if (response.code == 200) {
                    //window.location.href = response.url;
                    var win = window.open(response.url, '_blank');
                    win.focus();
                    $scope.connectData = response.data;
                    //console.log('serviceList:- ',$scope.serviceList);
                } else {
                    $scope.connectData = {};
                }
            });
        };
        //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
        //console.log($state.params, '-------');
        //console.log($routeParams,'=====');
        //console.log($state.params)

        $scope.deviceForm = {};
        //$scope.disableSubmitBtn = false;
        $scope.loader = false;

        $scope.addDevice = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                dashboardService.addDevice().save($scope.deviceForm, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        $scope.imageBrowse = function () {
            document.getElementById('filePicker').addEventListener('change', function (evt) {
                var files = evt.target.files;
                var file = files[0];
                if (files && file) {
                    var splitFileName = file.name.split('.');
                    var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                    if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {
                        if (file.size > 6291456) {
                            logger.log('File size cannot exceed limit of 6 mb');
                            document.getElementById("filePicker").value = "";
                        } else {
                            formDataFileUpload = file;
                            // formDataFileUpload.append('file', file);
                            var reader = new FileReader();
                            reader.onload = function (readerEvt) {
                                $scope.imageBase64 = btoa(readerEvt.target.result);
                                $scope.$apply();
                                document.getElementById('imgTag').src = 'data:image/' + ext + ';base64,' + $scope.imageBase64;
                            };
                            reader.readAsBinaryString(file);
                        }
                    } else {
                        document.getElementById("filePicker").value = "";
                        bootbox.alert('Invalid image format');
                    }
                }
            });
        }

        $scope.updateAdminProfile = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;

                var formData = new FormData();
                formData.append('first_name', $scope.userData.first_name);
                formData.append('last_name', $scope.userData.last_name);
                if (formDataFileUpload) {
                    formData.append('file', formDataFileUpload);
                }
                dashboardService.updateAdminProfile().save(formData, function (response) {
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        toastr.success(response.message);
                        $location.path('/updateProfile');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }

                });

            }
        }

        $scope.addRiskAssessment = function () {
            console.log("here i m");
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                riskAssessmentService.addRiskAssessment().save($scope.riskAssessmentForm, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };
        $scope.rulesForm = {};
        $scope.addRulesEngines = function () {
            if ($scope.rulesForm) {
                $scope.rulesForm.heart_rate_from = Number($scope.rulesForm.heart_rate_from);
                $scope.rulesForm.heart_rate_to = Number($scope.rulesForm.heart_rate_to);
            }
            console.log($scope.rulesForm);
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                console.log("$scope.rulesForm", $scope.rulesForm);
                dashboardService.addRulesEngines().save($scope.rulesForm, function (response) {
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        toastr.success(response.message);
                        $location.path('/rulesEngineList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        $scope.deleteRulesEngine = function (id) {
            bootbox.confirm('Are you sure you want to delete this Rule Engine', function (r) {
                if (r) {
                    $scope.deviceData = dashboardService.deleteRulesEngine(id).get({}, function (response, err) {
                        if (response.code == statusCode.ok) {
                            $scope.getAllRulesEngines();
                            toastr.success(response.message);
                        } else {
                            toastr.error('Something went wrong, please try again later.');
                        }
                    });
                }
            })
        }

        $scope.getAllRulesEngines = function () {
            console.log("getAllRulesEngines");
            $scope.rulesEngine = dashboardService.getAllRulesEngines().get({}, function (response, err) {
                if (response.code == 200) {
                    console.log("response.data", response.data);
                    $scope.rulesEngine = response.data;
                } else {
                    $scope.rulesEngine = {};
                }
            });
        }

        $scope.getRulesEnginesById = function () {
            $scope.ruleData = dashboardService.getRulesEnginesById($stateParams.id).get({}, function (response, err) {
                if (response.code == 200) {
                    if (!response.data.weight) {
                        var obj = {}
                        obj.bmi = { 'underweight': '', 'normal': '', 'overweight': '', 'obesity': '' }
                        response.data.weight = obj;
                    }
                    if (!response.data.blood_pressure) {
                        var obj = {}
                        obj.diastolic = { 'low': '', 'high': '' }
                        obj.systolic = { 'low': '', 'high': '' }
                        response.data.blood_pressure = obj;
                    }
                    if (!response.data.cholesterol) {
                        var obj = {}
                        obj.total_cholesterol_lr = '';
                        obj.total_cholesterol_hr = '';
                        obj.HDL_lr = '';
                        obj.HDL_hr = '';
                        response.data.cholesterol = obj;
                    }
                    $scope.rulesForm = response.data;
                } else {
                    $scope.rulesForm = {};
                }
            });
        }
        $scope.getDefaultRulesEngine = function () {
            $scope.ruleData = dashboardService.getDefaultRulesEngine().get({}, function (response, err) {
                if (response.code == 200) {
                    if (!response.data.weight) {
                        var obj = {}
                        obj.bmi = { 'underweight': '', 'normal': '', 'overweight': '', 'obesity': '' }
                        response.data.weight = obj;
                    }
                    if (!response.data.blood_pressure) {
                        var obj = {}
                        obj.diastolic = { 'low': '', 'high': '' }
                        obj.systolic = { 'low': '', 'high': '' }
                        response.data.blood_pressure = obj;
                    }
                    if (!response.data.cholesterol) {
                        var obj = {}
                        obj.total_cholesterol_lr = '';
                        obj.total_cholesterol_hr = '';
                        obj.HDL_lr = '';
                        obj.HDL_hr = '';
                        response.data.cholesterol = obj;
                    }
                    $scope.rulesForm = response.data;
                } else {
                    $scope.rulesForm = {};
                }
            });
        }
        $scope.kmeansForm = { 'cluster': '3' };
        $scope.kmeans = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                dashboardService.kmeans().save($scope.kmeansForm, function (response) {
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        var clusterArr = ['Malignant ventricular', 'Normal', 'Supraventricular']
                        var clusterResultArr = [];
                        for (var i = 0; i < response.data.length; i++) {
                            var obj = {}
                            obj.name = (clusterArr[i]) ? (clusterArr[i]) : ('Unknown');
                            obj.count = response.data[i].points.length;
                            obj.points = response.data[i].points;
                            clusterResultArr.push(obj);
                        }
                        $scope.clustersData = clusterResultArr;
                        $scope.displaychart();
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        }
        $scope.selection = [];
        $scope.selectionType = [];
        $scope.kmeans2 = function () {
            $scope.kmeansFormNew = {}
            $scope.kmeansFormNew.fileid = [];
            $scope.kmeansFormNew.fileType = [];
            $scope.kmeansFormNew.fileid = $scope.selection;
            $scope.kmeansFormNew.fileType = $scope.selectionType;
            var type = $scope.selectionType;
            var clusterArr = type.filter(function (item, pos) {
                return type.indexOf(item) == pos;
            });
            //console.log('$scope.selectionType',$scope.selectionType);
            //console.log('selection',$scope.selection);
            //console.log('clusterArr',clusterArr);
            $scope.errorMesg = "";
            if (clusterArr.length < 3) {
                $scope.errorMesg = "Please select at least 3 different kind of csv files.";
            } else {
                $scope.errorMesg = "";
                dashboardService.kmeansnew().save($scope.kmeansFormNew, function (response) {

                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //var clusterArr = ['Malignant ventricular','Normal','Supraventricular']
                        var clusterResultArr = [];
                        for (var i = 0; i < response.data.length; i++) {
                            var obj = {}
                            obj.name = (clusterArr[i]) ? (clusterArr[i]) : ('Unknown');
                            obj.count = response.data[i].count;
                            //obj.points = response.data[i].centroid;
                            var pt = []
                            var ptopt = ['Time', 'Sign0', 'Sign1']
                            for (var j = 0; j < response.data[i].centroid.length; j++) {
                                var str = ptopt[j] + ':' + response.data[i].centroid[j];
                                pt.push(str)
                            }
                            obj.points = pt;
                            clusterResultArr.push(obj);
                        }
                        $scope.clustersData = clusterResultArr;
                        $scope.displaychart();
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        }
        // Toggle selection for a given fruit by name
        $scope.toggleSelection = function toggleSelection(id, type) {
            //console.log('after click 12', id, type);
            var idx = $scope.selection.indexOf(id);
            var idt = $scope.selectionType.indexOf(type);
            // Is currently selected
            if (idx > -1) {
                $scope.selection.splice(idx, 1);
                $scope.selectionType.splice(idt, 1);
            }
            // Is newly selected
            else {
                $scope.selection.push(id);
                $scope.selectionType.push(type);
            }
            // console.log('after click', $scope.selection, $scope.selectionType);
        };

        $scope.displaychart = function () {
            console.log('i m here');
            google.charts.load('current', { 'packages': ['corechart'] });
            google.charts.setOnLoadCallback(drawChart);
        }

        $scope.devicemanagementList = function () {
            console.log("devicemanagementList");
            $scope.deviceData = dashboardService.devicemanagementList().get({}, function (response, err) {
                console.log('response', response);
                if (response.code == 200) {
                    $scope.deviceData = response.data;
                } else {
                    $scope.deviceData = {};
                }
            });
        }

        $scope.getDeviceManagementById = function () {
            $scope.deviceData = dashboardService.getDeviceManagementById($stateParams.id).get({}, function (response, err) {
                console.log('response----->>>', response);
                if (response.code == 200) {
                    console.log('here');
                    $scope.deviceForm = response.data;
                } else {
                    $scope.deviceForm = {};
                }
            });
        }

        $scope.editDeviceManagement = function () {
            console.log('parama---->>', $stateParams.id);
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                $scope.deviceData = dashboardService.editDeviceManagement($stateParams.id).save($scope.deviceForm, function (response) {
                    console.log("response", response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };


        $scope.enableDisableDevice = function (id, condition) {
            var status;
            if (condition == 'Active') {
                status = true;
            } else {
                status = false;
            }
            dashboardService.enableDisableDevice().save({ userId: id, status: status }, function (response) {
                if (response.code == 200) {
                    $scope.devicemanagementList();
                    toastr.success(response.message);
                } else {
                    toastr.error(response.message);
                }
            })
        };
        $scope.enableDisableRules = function (id, condition) {
            var status;
            if (condition == 'Active') {
                status = true;
            } else {
                status = false;
            }
            dashboardService.enableDisableRules().save({ userId: id, status: status }, function (response) {
                if (response.code == 200) {
                    $scope.getAllRulesEngines();
                    toastr.success(response.message);
                } else {
                    toastr.error(response.message);
                }
            })
        };

        $scope.setDefault = function (id, defaultValue) {
            console.log("setDefault--------->>>", id, defaultValue);
            var is_default;
            if (defaultValue == 'Active') {
                is_default = true;
            } else {
                is_default = false;
            }
            dashboardService.setDefault().save({ userId: id, is_default: is_default }, function (response) {
                if (response.code == 200) {
                    $scope.getAllRulesEngines();
                    toastr.success(response.message);
                } else {
                    toastr.error(response.message);
                }
            })
        };

        $scope.activityList = function () {
            $scope.activityData = dashboardService.activityList().get({}, function (response, err) {
                if (response.code == 200) {
                    $scope.activityData = response.data;
                } else {
                    $scope.activityData = {};
                }
            });
        }

        $scope.getEthinicity = function () {
            $scope.getEthinicityData = riskAssessmentService.getEthinicity().get({}, function (response, err) {
                if (response.code == 200) {
                    $scope.getEthinicityData = response.data;
                } else {
                    $scope.getEthinicityData = {};
                }
            });
        }

        function drawChart() {
            var data = $scope.clustersData;
            var responseData = [
                ['Cluster', 'Value']
            ]
            if (data.length > 0) {
                for (var i = 0; i < data.length; i++) {
                    var arr = [data[i].name, Number(data[i].count)]
                    responseData.push(arr);
                }
                console.log(responseData);
            }
            var data = google.visualization.arrayToDataTable(responseData);
            var options = {
                title: 'Clustering',
            };

            var chart = new google.visualization.PieChart(document.getElementById('piechart'));
            //var chart = new google.visualization.ScatterChart(document.getElementById('chart_div'));

            chart.draw(data, options);
        }


        $scope.fileErr = 0;
        $scope.csvfiletype = 'normal';
        $scope.uploadcsv = function () {
            if ($scope.form.$valid && $scope.myFile) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                var file = $scope.myFile;
                var fileType = file.type;
                var fileName = fileType.split('/').reverse()[0];
                var file_ext = fileName.split('.').reverse()[0];
                var file_ext = file_ext.toLowerCase();
                if (file_ext == 'csv' || file_ext == 'ms-excel') {
                    $scope.fileErr = 0;
                    var uploadUrl = "/api/v1/uploadcsv";
                    var fd = new FormData();
                    fd.append('file', file);
                    fd.append('filetype', $scope.csvfiletype);
                    //fd.filetype = $scope.csvfiletype;
                    $http.post(uploadUrl, fd, {
                        transformRequest: angular.identity,
                        headers: { 'Content-Type': undefined }
                    }).then(function (response) {
                        $scope.disableSubmitBtn = false;
                        if (response.data.code == 200) {
                            toastr.success(response.data.message);
                            $scope.getcsvList();
                            $scope.getDataForKmean();
                        } else {
                            toastr.error(response.data.message, 'Error');
                        }
                    });

                } else {
                    $scope.fileErr = 1;
                    $scope.disableSubmitBtn = false;
                }
            } else {
                $scope.fileErr = 1;
                $scope.disableSubmitBtn = false;
            }
        };

        $scope.checkCsv = function () {
            var file = $scope.myFile;
            var fileType = file.type;
            var fileName = fileType.split('/').reverse()[0];
            var file_ext = fileName.split('.').reverse()[0];
            var file_ext = file_ext.toLowerCase();
            if (file_ext == 'csv') {
                $scope.fileErr = 0;
            } else {
                $scope.fileErr = 1;
            }
        }

        $scope.getcsvList = function () {
            $scope.csvfileData = dashboardService.getcsvList().get({}, function (response, err) {
                if (response.code == 200) {
                    $scope.csvfileData = response.data;
                    $scope.recordsFound = response.data.length
                } else {
                    $scope.csvfileData = {};
                }
            });
        }

        $scope.getDataForKmean = function () {
            $scope.kmeanData = dashboardService.getDataForKmean().get({}, function (response, err) {
                if (response.code == 200) {
                    $scope.kmeanData = response.data;
                    if (response.data.centroids && response.data.centroids.length > 0) {
                        var cluster = [];
                        for (var i = 0; i < response.data.centroids.length; i++) {
                            var obj = {}
                            obj.name = response.data.centroids[i];
                            obj.color = ($scope.colors[i]) ? ($scope.colors[i]) : ('');
                            cluster.push(obj);
                        }
                        $scope.kmeanData.cluster = cluster;
                        if ($scope.kmeanData.observation > 0 && $scope.kmeanData.centroidsLen > 0) {
                            setTimeout(function () {
                                angular.element('#buttonGenerate').triggerHandler('click');
                                angular.element('#buttonCluster').triggerHandler('click');
                            }, 1000);
                        }
                    }
                } else {
                    $scope.kmeanData = {};
                }
            });
        }
        $scope.refreshcluster = function () {
            console.log($scope.kmeanData.observation);
            console.log($scope.kmeanData.cluster.length);
            console.log($scope.kmeanData.centroidsLen);
            //$scope.kmeanData.centroidsLen = angular.element('#inputNumCentroids').val();
            var num = angular.element('#inputNumCentroids').val();
            if ($scope.kmeanData.cluster.length < num) {
                console.log($scope.kmeanData.cluster.length);
                console.log(num);

                for (var i = $scope.kmeanData.cluster.length; i < num; i++) {
                    var obj = {}
                    obj.name = 'Unknown';
                    obj.color = ($scope.colors[i]) ? ($scope.colors[i]) : ('');
                    $scope.kmeanData.cluster.push(obj);
                }
            } else if ($scope.kmeanData.cluster.length > num) {
                var diff = num - $scope.kmeanData.cluster.length;
                $scope.kmeanData.cluster = $scope.kmeanData.cluster.slice(0, diff);
            }
        }


        $scope.addSmsTemplate = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                dashboardService.addSmsTemplate().save($scope.SmsFrm, function (response) {
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        toastr.success(response.message);
                        $location.path('/smsTemplateList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };
        $scope.rulesForm = {}
        $scope.rulesForm.title = '';

        $scope.getSmsTemplateList = function () {
            console.log("getSmsTemplateList");
            $scope.smsTemplateData = dashboardService.getSmsTemplateList().get({}, function (response, err) {
                if (response.code == 200) {
                    $scope.smsTemplateData = response.data;
                } else {
                    $scope.smsTemplateData = {};
                }
            });
        }

        $scope.getSmsTemplateById = function () {
            $scope.smsId = $stateParams.id;
            dashboardService.getSmsTemplateById($scope.smsId).get({}, function (response) {
                $scope.SmsFrm = response.data;
                if (response.code == 200) {
                    $scope.SmsFrm = response.data;
                }
            });
        };

        $scope.deleteSmsTemplate = function (Id) {
            bootbox.confirm('Are you sure, you want to delete this template?', function (r) {
                if (r) {
                    $scope.smsData = dashboardService.deleteSmsTemplate(Id).get({}, function (response, err) {
                        if (response.code == 200) {
                            toastr.success(response.message);
                            $scope.getSmsTemplateList();
                        } else {
                            toastr.error('Something went wrong, please try again later.');
                        }
                    });
                }
            })

        }
        $scope.getSmsTemplateforHospital = function (id) {
            if (id) {
                $scope.sms_id = id;
            }
            dashboardService.getSmsTemplateById($scope.sms_id).get({}, function (response) {
                $scope.rulesForm.hospitalMsg = '';
                if (response.code == 200) {
                    $scope.rulesForm.hospitalMsg = response.data.smsMessage;

                }
            });
        };
        $scope.getSmsTemplateforCareCoordinator = function (id) {
            if (id) {
                $scope.sms_id = id;
            } 
            dashboardService.getSmsTemplateById($scope.sms_id).get({}, function (response) {
                $scope.rulesForm.careMsg = '';
                if (response.code == 200) {
                    $scope.rulesForm.careMsg = response.data.smsMessage;

                }
            });
        };
        $scope.getSmsTemplateforAmbulance = function (id) {
            if (id) {
                $scope.sms_id = id;
            } 
            dashboardService.getSmsTemplateById($scope.sms_id).get({}, function (response) {
                $scope.rulesForm.ambulenceMsg = '';
                if (response.code == 200) {
                    $scope.rulesForm.ambulenceMsg = response.data.smsMessage;

                }
            });
        };
        $scope.getSmsTemplateforTowing = function (id) {
            if (id) {
                $scope.sms_id = id;
            }
            dashboardService.getSmsTemplateById($scope.sms_id).get({}, function (response) {
                $scope.rulesForm.towingMsg = '';
                if (response.code == 200) {
                    $scope.rulesForm.towingMsg = response.data.smsMessage;

                }
            });
        };
        $scope.getSmsTemplateforClinician = function (id) {
            if (id) {
                $scope.sms_id = id;
            } 
            dashboardService.getSmsTemplateById($scope.sms_id).get({}, function (response) {
                $scope.rulesForm.clinicianMsg = '';
                if (response.code == 200) {
                    $scope.rulesForm.clinicianMsg = response.data.smsMessage;

                }
            });
        };


    }
]);
