"use strict";

angular.module('UserManagement')
    .controller("userMangController", ['$scope', '$rootScope', '$localStorage', '$routeParams',
        '$route', '$location', '$state', '$stateParams', '$http', 'toastr', 'userMangService', 'ngTableParams', 'ngTableParamsService',
        function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state,
            $stateParams, $http, toastr, userMangService, ngTableParams, ngTableParamsService) {
            $scope.searchTextField = '';
            if ($state.params.id) {
                $scope.isUpdate = true;
            } else {
                $scope.isUpdate = false;
            }
            $scope.disableSubmitBtn = false;
            $scope.loader = false;
            $scope.patientForm = {};
            $scope.patientForm.gender = 'Male';
            $scope.patientForm.diabetes = 'No';
            $scope.patientForm.smoker = 'No';
            $scope.patientForm.bp_treatment = 'No';
            $scope.user = {}
            $scope.user.selectUser = 'Patient';
            $scope.patient = {};
            $scope.patientFlag = true;
            $scope.getRecord = function() {
                if ($scope.user.selectUser == 'Patient') {
                    $scope.patientFlag = true;
                    $scope.hospitalFlag = false;
                    $scope.clinicianFlag = false;
                    $scope.coordinatorFlag = false;
                    $scope.ambulanceFlag = false;
                    $scope.towingFlag = false;
                } else if ($scope.user.selectUser == 'Hospital') {
                    $scope.patientFlag = false;
                    $scope.hospitalFlag = true;
                    $scope.clinicianFlag = false;
                    $scope.coordinatorFlag = false;
                    $scope.ambulanceFlag = false;
                    $scope.towingFlag = false;
                } else if ($scope.user.selectUser == 'Clinician') {
                    $scope.patientFlag = false;
                    $scope.hospitalFlag = false;
                    $scope.clinicianFlag = true;
                    $scope.coordinatorFlag = false;
                    $scope.ambulanceFlag = false;
                    $scope.towingFlag = false;
                } else if ($scope.user.selectUser == 'CareCoordinator') {
                    $scope.patientFlag = false;
                    $scope.hospitalFlag = false;
                    $scope.clinicianFlag = false;
                    $scope.coordinatorFlag = true;
                    $scope.ambulanceFlag = false;
                    $scope.towingFlag = false;
                } else if ($scope.user.selectUser == 'Ambulance') {
                    $scope.patientFlag = false;
                    $scope.hospitalFlag = false;
                    $scope.clinicianFlag = false;
                    $scope.coordinatorFlag = false;
                    $scope.ambulanceFlag = true;
                    $scope.towingFlag = false;
                } else if ($scope.user.selectUser == 'Towing') {
                    $scope.patientFlag = false;
                    $scope.hospitalFlag = false;
                    $scope.clinicianFlag = false;
                    $scope.coordinatorFlag = false;
                    $scope.ambulanceFlag = false;
                    $scope.towingFlag = true;
                }

            }
            $scope.today = function() {
                $scope.dt = new Date();
            };
            $scope.dateformat = "MM/dd/yyyy";
            $scope.today();
            $scope.showcalendar = function($event) {
                $scope.showdp = true;
            };
            $scope.showdp = false;
            $scope.dtmax = new Date();

            $scope.getPatientById = function(id) {
                console.log("getPatientById");
                if (!id) {
                    id = $stateParams.id
                }
                userMangService.getPatientById().get({ id: id }, function(response) {
                    console.log("response.data", response.data);
                    if (response.code == 200) {
                        $scope.add = true
                        $scope.patientForm = response.data;
                        console.log("$scope.patientForm",$scope.patientForm);
                        $scope.patientForm.DOB = new Date(response.data.DOB);
                        $scope.patientForm.email = response.data.user_id.email;
                        $scope.patientForm.userId = response.data.user_id._id;
                        $scope.patientForm.diabetes = response.data.diabetes ? 'Yes' : 'No';
                        $scope.patientForm.smoker = response.data.smoker ? 'Yes' : 'No';
                        $scope.patientForm.bp_treatment = response.data.bp_treatment ? 'Yes' : 'No';

                    }
                });
            }

            $scope.getHospitalById = function(id) {
                console.log("abcc", id);
                if (!id) {
                    id = $stateParams.id
                }
                userMangService.getHospitalById().get({ id: id }, function(response) {
                    console.log("response.data", response.data);
                    if (response.code == 200) {
                        $scope.add = true
                        $scope.hospitalForm = response.data;
                        $scope.hospitalForm.email = response.data.user_id.email;
                        $scope.hospitalForm.userId = response.data.user_id._id;

                    }
                });
            }

        //  $scope.dateModel = {};
            


        //      $scope.today = function() {
        //     $scope.dt = new Date();
        // };
        // $scope.dateformat = "MM/dd/yyyy";
        // $scope.today();

        // $scope.showcalendar = function($event) {
        //     $scope.showdp = true;
        // };

        // $scope.showdp = false;
        // $scope.dtmax = new Date();
        // $scope.patientForm = { DOB: '' };

            $scope.addUpdatePatient = function() {
                console.log("addUpdatePatient");
                if ($scope.form.$valid) {
                    $scope.err = '';
                    $scope.disableSubmitBtn = true;
                    $scope.loader = true;
                    $scope.patientForm.role = 'Patient';
                    console.log("$scope.patientForm.DOB",$scope.patientForm.DOB)
                    if (!$scope.patientForm._id) {
                        console.log("form", $scope.patientForm);
                        //return;
                        userMangService.addPatient().save($scope.patientForm, function(response) {
                            console.log(response);
                            $scope.disableSubmitBtn = false;
                            $scope.loader = false;
                            if (response.code == 200) {
                                //$window.location.href = '/#!/deviceList'
                                toastr.success(response.message);
                                $location.path('/patientList');
                            } else {
                                toastr.error(response.message, 'Error');
                                $scope.disableSubmitBtn = false;
                                $scope.loader = false;
                            }
                        });
                    } else {
                        console.log("Hello");
                        if ($scope.patientForm.diabetes == 'Yes') {
                            $scope.patientForm.diabetes = true
                        } else {
                            $scope.patientForm.diabetes = false;
                        }
                        if ($scope.patientForm.smoker == 'Yes') {
                            $scope.patientForm.smoker = true
                        } else {
                            $scope.patientForm.smoker = false;
                        }
                        if ($scope.patientForm.bp_treatment == 'Yes') {
                            $scope.patientForm.bp_treatment = true
                        } else {
                            $scope.patientForm.bp_treatment = false;
                        }
                        console.log("Hello", $scope.patientForm);
                        userMangService.updatePatient().save($scope.patientForm, function(response) {
                            console.log(response);
                            $scope.disableSubmitBtn = false;
                            $scope.loader = false;
                            if (response.code == 200) {
                                //$window.location.href = '/#!/deviceList'
                                toastr.success(response.message);
                                $location.path('/patientList');
                            } else {
                                toastr.error(response.message, 'Error');
                                $scope.disableSubmitBtn = false;
                                $scope.loader = false;
                            }
                        });
                    }
                }
            }


            $scope.addUpdateHospital = function() {
                if ($scope.form.$valid) {
                    $scope.err = '';
                    $scope.disableSubmitBtn = true;
                    $scope.loader = true;
                    $scope.hospitalForm.role = 'Patient';
                    if (!$scope.hospitalForm._id) {
                        console.log("form", $scope.hospitalForm);
                        //return;
                        userMangService.addHospital().save($scope.hospitalForm, function(response) {
                            console.log(response);
                            $scope.disableSubmitBtn = false;
                            $scope.loader = false;
                            if (response.code == 200) {
                                //$window.location.href = '/#!/deviceList'
                                toastr.success(response.message);
                                $location.path('/hospitalList');
                            } else {
                                toastr.error(response.message, 'Error');
                                $scope.disableSubmitBtn = false;
                                $scope.loader = false;
                            }
                        });
                    } else {
                        console.log("$scope.hospitalForm", $scope.hospitalForm);
                        userMangService.updateHospital().save($scope.hospitalForm, function(response) {
                            console.log(response);
                            $scope.disableSubmitBtn = false;
                            $scope.loader = false;
                            if (response.code == 200) {
                                //$window.location.href = '/#!/deviceList'
                                toastr.success(response.message);
                                $location.path('/hospitalList');
                            } else {
                                toastr.error(response.message, 'Error');
                                $scope.disableSubmitBtn = false;
                                $scope.loader = false;
                            }
                        });
                    }
                }
            }





            $scope.getAllPatient = function() {
                console.log("in patient controller");
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.patientList = [];
                        userMangService.getAllPatient().save($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.patientList = response.data;
                                console.log("response.data-------->>>",response.data);
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }


            $scope.getAllPatientSearching = function(searchTextField) {
                ngTableParamsService.set('', '', searchTextField, '');
                console.log("searchtextfield", searchTextField);
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.patientList = [];
                        userMangService.getAllPatient().save($scope.paramUrl, function(response) {
                            $scope.tableLoader = false;
                            $scope.patientList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.totalCount;
                            params.total(response.totalCount);
                            $defer.resolve(data);
                        });
                    }
                });
            };

            $scope.getAllHospital = function() {
                console.log("getAllHospital");
                    $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                        counts: [],
                        getData: function($defer, params) {
                            // send an ajax request to your server. in my case MyResource is a $resource.
                            ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                            $scope.paramUrl = params.url();
                            $scope.tableLoader = true;
                            $scope.hospitalList = [];
                            userMangService.getAllHospital().save($scope.paramUrl, function(response, err) {
                                if (response.code == 200) {
                                    $scope.tableLoader = false;
                                    $scope.hospitalList = response.data;
                                    //console.log("response data", response.data);
                                    var data = response.data;
                                    $scope.totalCount = response.totalCount;
                                    params.total(response.totalCount);
                                    $defer.resolve(data);
                                } else {
                                    logger.logError(response.message);
                                }
                            });
                        }
                    });
                }
                // $scope.abc = function() {
                //     console.log("+++++++", $scope.searchTextField);
                // }
                // $scope.getAllHospitalSearching = function() {
                //     ngTableParamsService.set('', '', $scope.searchTextField, '');

            //     console.log("------------", ngTableParamsService.get());
            //     $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            //         counts: [],
            //         getData: function($defer, params) {
            //             // send an ajax request to your server. in my case MyResource is a $resource.
            //             ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
            //             $scope.paramUrl = params.url();
            //             $scope.tableLoader = true;
            //             $scope.hospitalList = [];
            //             userMangService.getAllHospital().save($scope.paramUrl, function(response, err) {
            //                 if (response.code == 200) {
            //                     $scope.tableLoader = false;
            //                     $scope.hospitalList = response.data;
            //                     //console.log("response data", response.data);
            //                     var data = response.data;
            //                     $scope.totalCount = response.totalCount;
            //                     params.total(response.totalCount);
            //                     $defer.resolve(data);
            //                 } else {
            //                     logger.logError(response.message);
            //                 }
            //             });
            //         }
            //     });
            // }


            $scope.getAllHospitalSearching = function(searchTextField) {
                ngTableParamsService.set('', '', searchTextField, '');
                console.log("searchtextfield", searchTextField);
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.hospitalList = [];
                        userMangService.getAllHospital().save($scope.paramUrl, function(response) {
                            $scope.tableLoader = false;
                            $scope.hospitalList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.totalCount;
                            params.total(response.totalCount);
                            $defer.resolve(data);
                        });
                    }
                });
            };

            $scope.searchable = function(searchTextField) {
                ngTableParamsService.set('', '', searchTextField, '');
                console.log("searchtextfield", searchTextField);
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.clinicianList = [];
                        userMangService.getAllClinician().save($scope.paramUrl, function(response) {
                            $scope.tableLoader = false;
                            $scope.clinicianList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.totalCount;
                            params.total(response.totalCount);
                            $defer.resolve(data);
                        });
                    }
                });
            };

            $scope.getAllClinician = function() {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.clinicianList = [];
                        userMangService.getAllClinician().save($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.clinicianList = response.data;
                                console.log("response data", response.data);
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.getAllAmbulance = function() {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.ambulanceList = [];
                        userMangService.getAllAmbulance().save($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.ambulanceList = response.data;
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.getAllAmbulanceSearching = function(searchTextField) {
                ngTableParamsService.set('', '', searchTextField, '');
                console.log("searchtextfield", searchTextField);
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.ambulanceList = [];
                        userMangService.getAllAmbulance().save($scope.paramUrl, function(response) {
                            $scope.tableLoader = false;
                            $scope.ambulanceList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.totalCount;
                            params.total(response.totalCount);
                            $defer.resolve(data);
                        });
                    }
                });
            };

            $scope.getAllTowing = function() {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.towingList = [];
                        userMangService.getAllTowing().save($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.towingList = response.data;
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.getAllTowingSearching = function(searchTextField) {
                ngTableParamsService.set('', '', searchTextField, '');
                console.log("searchtextfield", searchTextField);
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.towingList = [];
                        userMangService.getAllTowing().save($scope.paramUrl, function(response) {
                            $scope.tableLoader = false;
                            $scope.towingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.totalCount;
                            params.total(response.totalCount);
                            $defer.resolve(data);
                        });
                    }
                });
            };

            $scope.getAllCareCoordinator = function() {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.careCoordinatorList = [];
                        console.log(0);
                        userMangService.getAllCareCoordinator().save($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.careCoordinatorList = response.data;
                                //console.log("response data", response.data);
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.getAllCareCoordinatorSearching = function(searchTextField) {
                ngTableParamsService.set('', '', searchTextField, '');
                console.log("searchtextfield", searchTextField);
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.careCoordinatorList = [];
                        userMangService.getAllCareCoordinator().save($scope.paramUrl, function(response) {
                            $scope.tableLoader = false;
                            $scope.careCoordinatorList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.totalCount;
                            params.total(response.totalCount);
                            $defer.resolve(data);
                        });
                    }
                });
            };

            $scope.deletePatient = function(id) {
                console.log("deletePatient", id);
                bootbox.confirm('Are you sure you want to delete', function(r) {
                    if (r) {
                        userMangService.deletePatient(id).delete(function(response) {
                            if (response.code == 200) {
                                $scope.getAllPatient();
                                toastr.success(response.message);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                })
            }

            $scope.deleteHospital = function(id) {
                console.log("deleteHospital", id);
                bootbox.confirm('Are you sure you want to delete', function(r) {
                    if (r) {
                        userMangService.deleteHospital(id).delete(function(response) {
                            if (response.code == 200) {
                                $scope.getAllHospital();
                                toastr.success(response.message);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                })
            }

            $scope.deleteClinician = function(id) {
                console.log("deleteClinician", id);
                bootbox.confirm('Are you sure you want to delete', function(r) {
                    if (r) {
                        userMangService.deleteClinician(id).delete(function(response) {
                            if (response.code == 200) {
                                $scope.getAllClinician();
                                toastr.success(response.message);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                })
            }

            $scope.deleteAmbulance = function(id) {
                console.log("deleteAmbulance", id);
                bootbox.confirm('Are you sure you want to delete', function(r) {
                    if (r) {
                        userMangService.deleteAmbulance(id).delete(function(response) {
                            if (response.code == 200) {
                                $scope.getAllAmbulance();
                                toastr.success(response.message);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                })
            }

            $scope.deleteTowing = function(id) {
                console.log("deleteTowing", id);
                bootbox.confirm('Are you sure you want to delete', function(r) {
                    if (r) {
                        userMangService.deleteTowing(id).delete(function(response) {
                            if (response.code == 200) {
                                $scope.getAllTowing();
                                toastr.success(response.message);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                })
            }

            $scope.deleteCareCoordinator = function(id) {
                console.log("deleteCareCoordiantor", id);
                bootbox.confirm('Are you sure you want to delete', function(r) {
                    if (r) {
                        userMangService.deleteCareCoordinator(id).delete(function(response) {
                            if (response.code == 200) {
                                $scope.getAllCareCoordinator();
                                toastr.success(response.message);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                })
            }

            $scope.getAllClinicianName = function() {
                $scope.getClinicianData = userMangService.getAllClinicianName().get({}, function(response, err) {
                    if (response.code == 200) {
                        $scope.getClinicianData = response.data;
                    } else {
                        $scope.getClinicianData = {};
                    }
                });
            }

            $scope.addUpdateServiceData = function(form) {
                if (form.$valid) {
                    $scope.err = '';
                    $scope.disableSubmitBtn = true;
                    $scope.loader = true;
                    if (!$scope.patient._id) {
                        userMangService.addPatient().save($scope.patientForm, function(response) {
                            console.log(response);
                            $scope.disableSubmitBtn = false;
                            $scope.loader = false;
                            if (response.code == 200) {
                                //$window.location.href = '/#!/deviceList'
                                toastr.success(response.message);
                                $location.path('/patient');
                            } else {
                                toastr.error(response.message, 'Error');
                                $scope.disableSubmitBtn = false;
                                $scope.loader = false;
                            }
                        });
                    } else {
                        userMangService.updatePatient().save($scope.patientForm, function(response) {
                            $scope.disableSubmitBtn = false;
                            $scope.loader = false;
                            if (response.code == 200) {
                                //$window.location.href = '/#!/deviceList'
                                toastr.success(response.message);
                                $location.path('/patient');
                            } else {
                                toastr.error(response.message, 'Error');
                                $scope.disableSubmitBtn = false;
                                $scope.loader = false;
                            }
                        });
                    }
                }
            }

            $scope.getCountry = function() {
                console.log("here");
                userMangService.getCountry().get({}, function(response, err) {
                    // console.log('response',response);
                    if (response.code == 200) {
                        console.log("getCountry", response.data);
                        $scope.country = response.data;
                    } else {
                        $scope.country = {};
                    }
                });
            }

            $scope.getServiceType = function() {
                console.log("here");
                userMangService.getServiceType().get({}, function(response, err) {
                    // console.log('response',response);
                    if (response.code == 200) {
                        console.log("getServiceType", response.data);
                        $scope.service = response.data;
                    } else {
                        $scope.country = {};
                    }
                });
            }

            $scope.addClinician = function() {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                console.log("addClinician", $scope.clinicianForm);
                // var password = $scope.clinicianForm.password;
                // var confirm_password = $scope.confirm_password;
                var clinicianForm = $scope.clinicianForm;
                // if(password == confirm_password){
                if ($state.params.id) {
                    clinicianForm.id = $state.params.id;
                }
                console.log("$scope.clinicianForm", clinicianForm);
                userMangService.addClinician().save(clinicianForm, function(response) {
                    //console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        $location.path('/clinicianList');
                        $scope.patientFlag = false;
                        $scope.clinicianFlag = true;
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
                // }else if(password != confirm_password){    
                //    toastr.info("Password and confirm password not matched");
                // }else{
                //     console.log("error");
                // }
            };

            $scope.addCareCoordinator = function() {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                console.log("addCareCoordinator", $scope.coordinatorForm);
                // var password = $scope.coordinatorForm.password;
                // var confirm_password = $scope.confirm_password;
                // if(password == confirm_password){
                var careCoordinatorForm = $scope.coordinatorForm;
                if ($state.params.id) {
                    careCoordinatorForm.id = $state.params.id;
                }
                console.log("$scope.careCoordinatorForm", careCoordinatorForm);
                userMangService.addCareCoordinator().save(careCoordinatorForm, function(response) {
                    //console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        $location.path('/careCoordinatorList');
                        $scope.patientFlag = false;
                        $scope.coordinatorFlag = true;
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
                // }else if(password != confirm_password){    
                //    toastr.info("Password and confirm password not matched");
                // }else{
                //     console.log("error");
                // }
            };

            $scope.addAmbulance = function() {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                console.log("addAmbulance", $scope.ambulanceForm);
                // var password = $scope.ambulanceForm.password;
                // var confirm_password = $scope.confirm_password;
                // if(password == confirm_password){
                // console.log("$scope.ambulanceForm",$scope.ambulanceForm); 
                var ambulanceForm = $scope.ambulanceForm;
                if ($state.params.id) {
                    ambulanceForm.id = $state.params.id;
                }
                console.log("$scope.ambulanceForm", ambulanceForm);
                userMangService.addAmbulance().save(ambulanceForm, function(response) {
                    //console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        $location.path('/ambulenceList');
                        $scope.patientFlag = false;
                        $scope.ambulanceFlag = true;
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
                // }else if(password != confirm_password){    
                //    toastr.info("Password and confirm password not matched");
                // }else{
                //     console.log("error");
                // }
            };

            $scope.addTowing = function() {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                console.log("addTowing", $scope.towingForm);
                // var password = $scope.towingForm.password;
                // var confirm_password = $scope.confirm_password;
                // if(password == confirm_password){
                // console.log("$scope.towingForm",$scope.towingForm); 
                var towingForm = $scope.towingForm;
                if ($state.params.id) {
                    towingForm.id = $state.params.id;
                }
                console.log("$scope.towingForm", towingForm);
                userMangService.addTowing().save(towingForm, function(response) {
                    //console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        $location.path('/towingList');
                        $scope.patientFlag = false;
                        $scope.towingFlag = true;
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
                // }else if(password != confirm_password){    
                //    toastr.info("Password and confirm password not matched");
                // }else{
                //     console.log("error");
                // }
            };

            $scope.getClinicianById = function() {
                var id = $state.params.id;
                console.log(id);
                userMangService.getClinicianById(id).get(function(response, err) {
                    if (response.code == 200) {
                        console.log("response", response.data);
                        var clinicianData = response.data;
                        clinicianData.email = response.data.user_id.email;
                        $scope.clinicianForm = clinicianData;
                    } else {
                        $scope.clinicianForm = {};
                    }
                });
            };

            $scope.getCareCoordinatorById = function() {
                var id = $state.params.id;
                console.log(id);
                userMangService.getCareCoordinatorById(id).get(function(response, err) {
                    if (response.code == 200) {
                        console.log("response", response.data);
                        var coordinatorData = response.data;
                        coordinatorData.email = response.data.user_id.email;
                        $scope.coordinatorForm = coordinatorData;
                    } else {
                        $scope.coordinatorForm = {};
                    }
                });
            };

            $scope.getAmbulanceById = function() {
                var id = $state.params.id;
                console.log(id);
                userMangService.getAmbulanceById(id).get(function(response, err) {
                    if (response.code == 200) {
                        console.log("response", response.data);
                        var ambulanceData = response.data;
                        ambulanceData.email = response.data.user_id.email;
                        $scope.ambulanceForm = ambulanceData;
                    } else {
                        $scope.coordinatorForm = {};
                    }
                });
            };

            $scope.getTowingById = function() {
                var id = $state.params.id;
                console.log(id);
                userMangService.getTowingById(id).get(function(response, err) {
                    if (response.code == 200) {
                        console.log("response", response.data);
                        var towingData = response.data;
                        towingData.email = response.data.user_id.email;
                        $scope.towingForm = towingData;
                    } else {
                        $scope.coordinatorForm = {};
                    }
                });
            }

            $scope.enableDisableClinician = function(id, condition) {
                var status;
                if (condition == 'Active') {
                    status = true;
                } else {
                    status = false;
                }
                userMangService.enableDisableClinician().save({ userId: id, status: status }, function(response) {
                    if (response.code == 200) {
                        $scope.getAllClinician();
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                })
            };

            $scope.enableDisableAmbulance = function(id, condition) {
                var status;
                if (condition == 'Active') {
                    status = true;
                } else {
                    status = false;
                }
                userMangService.enableDisableAmbulance().save({ userId: id, status: status }, function(response) {
                    if (response.code == 200) {
                        $scope.getAllAmbulance();
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                })
            };

            $scope.enableDisableTowing = function(id, condition) {
                var status;
                if (condition == 'Active') {
                    status = true;
                } else {
                    status = false;
                }
                userMangService.enableDisableTowing().save({ userId: id, status: status }, function(response) {
                    if (response.code == 200) {
                        $scope.getAllTowing();
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                })
            };

            $scope.enableDisableCoordinator = function(id, condition) {
                var status;
                if (condition == 'Active') {
                    status = true;
                } else {
                    status = false;
                }
                userMangService.enableDisableCoordinator().save({ userId: id, status: status }, function(response) {
                    if (response.code == 200) {
                        $scope.getAllCareCoordinator();
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                })
            };

            $scope.enableDisablePatient = function(id, condition) {
                var status;
                if (condition == 'Active') {
                    status = true;
                } else {
                    status = false;
                }
                userMangService.enableDisablePatient().save({ userId: id, status: status }, function(response) {
                    if (response.code == 200) {
                        $scope.getAllPatient();
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                })
            };

            $scope.enableDisableHospital = function(id, condition) {
                var status;
                if (condition == 'Active') {
                    status = true;
                } else {
                    status = false;
                }
                userMangService.enableDisableHospital().save({ userId: id, status: status }, function(response) {
                    if (response.code == 200) {
                        $scope.getAllHospital();
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                })
            };

          


            $scope.getHospital = function() {
                console.log("getHospital");
                userMangService.getHospital().get(function(response, err) {
                    if (response.code == 200) {
                        $scope.hospitals = response.data;
                        console.log("hospitals------>>>", response.data);
                    } else {
                        $scope.hospitals = {};
                    }
                });
            };

            $scope.cancelHospital = function() {
                alert('in cancel hospital');
                $scope.hospitalFlag = true;
                $scope.clinicianFlag = false;
                $scope.patientFlag = false;
                $scope.coordinatorFlag = false;
                $scope.ambulanceFlag = false;
                $scope.towingFlag = false;
                $scope.user.selectUser = 'Hospital';
                $state.go('userListing');
            }

        }
    ]);
