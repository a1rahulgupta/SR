"use strict"

angular.module("UserManagement")

.factory('userMangService', ['$http', '$resource', function($http, $resource) {

    var getSmokingStatus = function() {
        return $resource('/api/v1/getSmokingStatus', null, {
            get: {
                method: 'GET'
            }
        });
    }

    var getAllPatient = function() {
        return $resource('/api/v1/getAllPatient', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllHospital = function() {
        return $resource('/api/v1/getAllHospital', null, {
        save: {
                method: 'POST'
            }
        });
    }

    var getAllClinician = function() {
        return $resource('/api/v1/getAllClinician', null, {
            save: {
                method: 'POST'
            }
        });
    }
    var getAllAmbulance = function() {
        return $resource('/api/v1/getAllAmbulance', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllTowing = function() {
        return $resource('/api/v1/getAllTowing', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllCareCoordinator = function() {
        return $resource('/api/v1/getAllCareCoordinator', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllClinicianName = function() {
        return $resource('/api/v1/getAllClinicianName', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var addPatient = function() {
        return $resource('/api/v1/addPatientByAdmin', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var addHospital = function() {
        return $resource('/api/v1/addHospitalByAdmin', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var updateHospital = function() {
        return $resource('/api/v1/updateHospitalByAdmin', null, {
            save: {
                method: 'POST',
            }
        });
    }
    var updatePatient = function() {
        return $resource('/api/v1/updatePatientByAdmin', null, {
            save: {
                method: 'POST',
            }
        });
    }

    var deletePatient = function(id) {
        return $resource('/api/v1/deletePatientById/' + id, null, {
            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var deleteHospital = function(id) {
        return $resource('/api/v1/deleteHospitalById/' + id, null, {
            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var deleteClinician = function(id) {
        return $resource('/api/v1/deleteClinicianById/' + id, null, {
            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var deleteAmbulance = function(id) {
        return $resource('/api/v1/deleteAmbulanceById/' + id, null, {
            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var deleteTowing = function(id) {
        return $resource('/api/v1/deleteTowingById/' + id, null, {
            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var deleteCareCoordinator = function(id) {
        return $resource('/api/v1/deleteCareCoordinatorById/' + id, null, {
            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }
    var getPatientById = function() {
        return $resource('/api/v1/getPatientByAdminId/:id', null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getHospitalById = function() {
        return $resource('/api/v1/getHospitalByAdminId/:id', null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }


    var getServiceType = function(deviceId) {
        return $resource('/api/v1/auth/getServiceType', null, {
            get: {
                method: 'GET'
            }
        });
    }

    var getCountry = function(deviceId) {
        return $resource('/api/v1/auth/getCountry', null, {
            get: {
                method: 'GET'
            }
        });
    }

    var addClinician = function() {
        return $resource('/api/v1/addClinician', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var addCareCoordinator = function() {
        return $resource('/api/v1/addCareCoordinator', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var addAmbulance = function() {
        return $resource('/api/v1/addAmbulance', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var addTowing = function() {
        return $resource('/api/v1/addTowing', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getClinicianById = function(id) {
        console.log('getClinicianById', id);
        return $resource('/api/v1/getClinicianById/' + id, null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getCareCoordinatorById = function(id) {
        console.log('getCareCoordinatorById', id);
        return $resource('/api/v1/getCareCoordinatorById/' + id, null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getAmbulanceById = function(id) {
        console.log('getAmbulanceById', id);
        return $resource('/api/v1/getAmbulanceById/' + id, null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getTowingById = function(id) {
        console.log('getTowingById', id);
        return $resource('/api/v1/getTowingById/' + id, null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var enableDisableClinician = function() {
        return $resource('/api/v1/enableDisableClinician', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var enableDisableAmbulance = function() {
        return $resource('/api/v1/enableDisableAmbulance', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var enableDisableTowing = function() {
        return $resource('/api/v1/enableDisableTowing', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var enableDisableCoordinator = function() {
        return $resource('/api/v1/enableDisableCoordinator', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var enableDisablePatient = function() {
        return $resource('/api/v1/enableDisablePatient', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var enableDisableHospital = function() {
        return $resource('/api/v1/enableDisableHospital', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getHospital = function() {
        return $resource('/api/v1/getHospital', null, {
            save: {
                method: 'POST'
            }
        });
    }

    return {
        addPatient: addPatient,
        updatePatient: updatePatient,
        getPatientById: getPatientById,
        getAllClinicianName: getAllClinicianName,
        getAllPatient: getAllPatient,
        getAllHospital: getAllHospital,
        getAllClinician: getAllClinician,
        getAllAmbulance: getAllAmbulance,
        getAllTowing: getAllTowing,
        getAllCareCoordinator: getAllCareCoordinator,
        deletePatient: deletePatient,
        deleteHospital: deleteHospital,
        deleteClinician: deleteClinician,
        deleteAmbulance: deleteAmbulance,
        deleteTowing: deleteTowing,
        deleteCareCoordinator: deleteCareCoordinator,
        getCountry: getCountry,
        addHospital: addHospital,
        updateHospital: updateHospital,
        getHospitalById: getHospitalById,
        addClinician: addClinician,
        addCareCoordinator: addCareCoordinator,
        addAmbulance: addAmbulance,
        getServiceType: getServiceType,
        addTowing: addTowing,
        getClinicianById: getClinicianById,
        getCareCoordinatorById: getCareCoordinatorById,
        getAmbulanceById: getAmbulanceById,
        getTowingById: getTowingById,
        enableDisableClinician: enableDisableClinician,
        enableDisableAmbulance: enableDisableAmbulance,
        enableDisableTowing: enableDisableTowing,
        enableDisableCoordinator: enableDisableCoordinator,
        enableDisablePatient: enableDisablePatient,
        enableDisableHospital: enableDisableHospital,
        getHospital: getHospital
    }

}]);
