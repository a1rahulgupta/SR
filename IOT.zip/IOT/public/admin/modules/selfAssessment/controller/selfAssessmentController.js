"use strict";

angular.module('SelfAssessment')
    .controller("selfAssessmentController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', 'SelfAssessmentService', 'toastr','$uibModal', 'ngTableParams', 'ngTableParamsService',
        function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, SelfAssessmentService, toastr,$uibModal, ngTableParams, ngTableParamsService) {
            
    
            var formDataFileUpload = '';
            $scope.imageBase64 = '';
            $scope.questionLength = 0;
            $scope.assignment = [];
            $scope.questions = [{ 'Question': '','options':[{ 'options': ''}],'question_type':'text'}];
            // $scope.questions.question_type = 'text'; 
            // $scope.patientForm.gender = 'Male';
            //add a row in the array
            $scope.addQuestion = function () {
                // create a blank array
                console.log("here1");
                var newrow = { 'Question': '','options':[{ 'options': ''}],'question_type':'text'};
                // add the new row at the end of the array
                $scope.questions.push(newrow);
            };
            $scope.addOption = function (indexV) {
                console.log('indexV',indexV);
                // create a blank array
               
               var newrow = { 'options': ''}
                // add the new row at the end of the array
                console.log($scope.questions,'444');
                $scope.questions[indexV].options.push(newrow);
            };

            $scope.removeOptionRow = function (key1,key) {
                // console.log('indexV',indexV);
                console.log('key',key);
                $scope.questions[key1].options.splice(key, 1);
            };

            $scope.removeQuestionRow = function (index) {
                // console.log('indexV',indexV);
                // console.log('key',key);
                $scope.questions.splice(index, 1);
            };   


            $scope.imageBrowse = function() {
            document.getElementById('filePicker').addEventListener('change', function(evt) {
                var files = evt.target.files;
                var file = files[0];
                if (files && file) {
                    var splitFileName = file.name.split('.');
                    var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                    if (ext == 'jpg' || ext == 'jpeg' || ext == 'png' || ext == 'txt' || ext == 'pdf' || ext == 'doc') {
                        if (file.size > 6291456) {
                            logger.log('File size cannot exceed limit of 6 mb');
                            document.getElementById("filePicker").value = "";
                        } else {
                            formDataFileUpload = file;
                            // formDataFileUpload.append('file', file);
                            var reader = new FileReader();
                            reader.onload = function(readerEvt) {
                                $scope.imageBase64 = btoa(readerEvt.target.result);
                                $scope.$apply();
                                document.getElementById('imgTag').src = 'data:image/' + ext + ';base64,' + $scope.imageBase64;
                            };
                            reader.readAsBinaryString(file);
                        }
                    } else {
                        document.getElementById("filePicker").value = "";
                        bootbox.alert('Invalid image format.It accept only jpg, jpeg, png, txt, pdf, doc');
                    }
                }
            });
        }

        $scope.questionFileUpload = function(questions) {
            
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;

                if (formDataFileUpload) {
                    console.log("in controller file upload");
                    var formData = new FormData();
                    formData.append('file', formDataFileUpload);
                    formData.append('question_type', "fileType");
                    SelfAssessmentService.questionFileUpload().save(formData, function(response) {
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                        if (response.code == 200) {
                            toastr.success(response.message);
                        } else {
                            toastr.error(response.message, 'Error');
                            $scope.disableSubmitBtn = false;
                            $scope.loader = false;
                        }

                    });
                }
            
        }

        $scope.getAssesmentQuestions = function() {
            SelfAssessmentService.getAssesmentQuestions().get(function(response, err) {
                if (response.code == 200) {
                    $scope.assesmentQuestionData = response.data;
                    $scope.view = true;
                    $scope.viewQuestions = response.data;
                    $scope.questionLength = response.data.length;
                    console.log("questions111",response.data);
                } else {
                    $scope.assesmentQuestionData = {};
                }
            });
        }  

        $scope.addSelfAssessmentQuestion = function(questions) {
                console.log("questions check",questions);
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                console.log(questions);
                var selfAssessment = {};
                selfAssessment.questions = questions;
                $scope.questionFileUpload();
                if(questions[0].question!=undefined && questions[0].question!=''){
                    SelfAssessmentService.addSelfAssessmentQuestion().save(selfAssessment, function(response) {
                            if (response.code == 200) {
                                toastr.success(response.message);
                                $location.path('/viewSelfAssessmentQuestion')                            
                            } else {
                                alert('no record');
                            }
                        }, function(response) {
                            toastr.error(response.message);
                    })
                }else{
                    $location.path('/viewSelfAssessmentQuestion')
                }
        }; 

        $scope.deleteQuestion = function (id) {
        bootbox.confirm('Are you sure you want to delete this question', function (r) {
        if (r) {
            console.log('deleteQuestion',id);
            SelfAssessmentService.deleteQuestion(id).delete(function (response) {
                if (response.code == 200) {
                    toastr.success(response.message);
                    $scope.getAssesmentQuestions();

                } else {
                    toastr.error(response.message);
                    console.log(response);
                }
            })
        }
        })
        }

        $scope.ckhExtension = function(filePath){
            var fileType = filePath;
            var fileName = fileType.split('/').reverse()[0];
            var file_ext = fileName.split('.').reverse()[0];
            var file_ext = file_ext.toLowerCase();
            return file_ext;
        }

        $scope.viewFileById = function(id) {
                SelfAssessmentService.viewFileById().get({ id: id }, function(response, err) {
                            if (response.code == 200) {
                                var fileType = response.data.file_upload;
                                var fileName = fileType.split('/').reverse()[0];
                                var file_ext = fileName.split('.').reverse()[0];
                                var file_ext = file_ext.toLowerCase();
                                $rootScope.questionFile = response.data;
                                if(file_ext == 'txt' || file_ext =='pdf'){
                                    setTimeout(function(){
                                        window.open(location.protocol + "//" + location.hostname + 
                                         (location.port && ":" + location.port) + "/"+fileType,'_blank',"width=500,height=500,menubar=0,location=0,toolbar=0");
                                    },300);
                                }else{
                                  $uibModal.open({
                                        templateUrl: 'modules/selfAssessment/views/viewUploadFile.html',
                                        size: "lg",
                                        controller: function($scope, $uibModalInstance) {
                                            $scope.questionFile = $rootScope.questionFile;
                                            $scope.cancel = function() {
                                                $uibModalInstance.dismiss('cancel');
                                            };

                                        }
                                    });
                                }
                            } else {
                                $scope.questionFile = {};
                            }
                });

        };

        $scope.getAssesQuestionFile = function() {
            SelfAssessmentService.getAssesQuestionFile().get(function(response, err) {
                if (response.code == 200) {
                    $scope.assesQuestionFile = response.data;
                } else {
                    $scope.assesQuestionFile = {};
                }
            });
        }

        $scope.deleteFileById = function (id) {
        bootbox.confirm('Are you sure you want to delete this file', function (r) {
        if (r) {
            SelfAssessmentService.deleteFileById(id).delete(function (response) {
                if (response.code == 200) {
                    toastr.success(response.message);
                    $scope.getAssesQuestionFile();

                } else {
                    toastr.error(response.message);
                    console.log(response);
                }
            })
        }
        })
        }

        $scope.assignPatient = {};

        $scope.getAllPatient = function() {
            SelfAssessmentService.getAllPatient().get(function(response, err) {
                if (response.code == 200) {
                    $scope.patients = response.data;
                } else {
                    $scope.patients = {};
                }
            });
        }
        $scope.checkAll = function() {
            $scope.assignPatient.patients = $scope.patients.map(function(item) { return item.id; });
        };
          
        $scope.uncheckAll = function() {
            $scope.assignPatient.patients = [];
        };

        $scope.getQuestionsForAssign = function() {
            SelfAssessmentService.getQuestionsForAssign().get(function(response, err) {
                if (response.code == 200) {
                    $scope.questions = response.data;
                } else {
                    $scope.questions = {};
                }
            });
        } 

        $scope.checkAllQuestion = function() {
            $scope.assignPatient.questions = $scope.questions.map(function(item) { return item.id; });
             $scope.assignPatient.assesQuestionFile = angular.copy($scope.assesQuestionFile);
        };
          
        $scope.uncheckAllQuestion = function() {
            $scope.assignPatient.questions = [];
            $scope.assignPatient.assesQuestionFile = [];
        }; 

        $scope.assignQuestions = function(assignPatient) {
                SelfAssessmentService.assignQuestions().save(assignPatient, function(response) {
                        if (response.code == 200) {
                            toastr.success(response.message);
                            $scope.getAllPatient();
                            $scope.assignPatient = {};
                            $scope.getAssignPatient();                            
                        } else {
                            // alert('no record');
                        }
                    }, function(response) {
                        toastr.error(response.message);
                });
        }; 

        $scope.getAssignPatient = function() {
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    counts: [],
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.tableLoader = true;
                        $scope.patientRecord = [];
                        console.log(0);
                        SelfAssessmentService.getAssignPatient().get($scope.paramUrl, function(response, err) {
                            if (response.code == 200) {
                                $scope.tableLoader = false;
                                $scope.patientRecord = response.data;
                                var data = response.data;
                                $scope.totalCount = response.totalCount;
                                params.total(response.totalCount);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }

            $scope.viewAssignQuestion = function(id) {
                SelfAssessmentService.viewAssignQuestion().get({ id: id }, function(response, err) {
                            if (response.code == 200) {
                                $rootScope.questions = response.data;
                            }else{
                                $rootScope.questions = {};
                            }
                        })
                $uibModal.open({
                    templateUrl: 'modules/selfAssessment/views/viewAssignQuestions.html',
                    size: "lg",
                    controller: function($scope, $uibModalInstance) {
                         $scope.questions = $rootScope.questions;
                        $scope.cancel = function() {
                            $uibModalInstance.dismiss('cancel');
                        }
                    }
                })
            };

            $scope.getQuestionsForAssignOnEdit = function() {
                var id = $state.params.id;
                SelfAssessmentService.getQuestionsForAssignOnEdit().get({ id: id },function(response, err) {
                    if (response.code == 200) {
                        $scope.questions = response.data;
                    } else {
                        $scope.questions = {};
                    }
                });
            } 

            $scope.viewAssignQuestionsOnEdit = function(){
                var id = $state.params.id;
                SelfAssessmentService.viewAssignQuestion().get({ id: id }, function(response, err) {
                            if (response.code == 200) {
                                $scope.assignedQuestions = response.data;
                            }else{
                                $scope.questions = {};
                            }
                })

            }

            $scope.assignQuestionsOnEdit = function(assignPatient) {
                console.log(assignPatient);
                assignPatient.patients = [];
                assignPatient.patients.push($state.params.id);
;                SelfAssessmentService.assignQuestions().save(assignPatient, function(response) {
                        if (response.code == 200) {
                            toastr.success(response.message);
                            $scope.assignPatient = {};
                            $state.go("assignSelfAssessmentQuestion");
                            // $scope.viewAssignQuestionsOnEdit(); 
                            // $scope.getQuestionsForAssignOnEdit();                           
                        } else {
                            toastr.error(response.message);
                        }
                    }, function(response) {
                        toastr.error(response.message);
                })
            };

            $scope.checkQuestionsEditable = function(id){
                SelfAssessmentService.checkQuestionsEditable().get({ id: id }, function(response, err) {
                            if (response.code == 200) {
                                toastr.info(response.message);
                            }else{
                                $location.path("/editAssignedQuestionsById/"+id);
                            }
                })

            }

        }
    ]);
