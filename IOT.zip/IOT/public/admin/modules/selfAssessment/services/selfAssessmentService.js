"use strict"

angular.module("SelfAssessment")

.factory('SelfAssessmentService', ['$http', '$resource', function($http, $resource) {

    var getEthinicity = function() {
        return $resource('/api/v1/getEthinicity', null, {
            get: {
                method: 'GET'
            }
        });
    }
    var getDiabetesStatus = function() {
        return $resource('/api/v1/getDiabetesStatus', null, {
            get: {
                method: 'GET'
            }
        });
    }
    var getSmokingStatus = function() {
        return $resource('/api/v1/getSmokingStatus', null, {
            get: {
                method: 'GET'
            }
        });
    }

    var addRiskAssessment = function() {
        return $resource('/api/v1/addRiskAssessment', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var addSelfAssessmentQuestion = function() {
        return $resource('/api/v1/addSelfAssessmentQuestion', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var questionFileUpload = function() {
        return $resource('/api/v1/questionFileUpload', null, {
            save: {
                method: 'POST',
                headers: { 'Content-Type': undefined }
            }
        });
    }

    var getAssesmentQuestions = function(){
        return $resource('/api/v1/getAssesmentQuestions',null, {
            save: {
                method: 'GET'
            }
        });   
    }

    var deleteQuestion = function(id) {
       
        return $resource('/api/v1/deleteQuestionById/'+ id, null, {

            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var getAssesQuestionFile = function(){
        return $resource('/api/v1/getAssesQuestionFile',null, {
            save: {
                method: 'GET'
            }
        });   
    }

    var viewFileById = function() {
        return $resource('/api/v1/viewFileById/:id', null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var deleteFileById = function(id) {
       
        return $resource('/api/v1/deleteFileById/'+ id, null, {

            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var getAllPatient = function(){
        return $resource('/api/v1/getAllPatients',null, {
            save: {
                method: 'GET'
            }
        });   
    }

    var getQuestionsForAssign = function(){
        return $resource('/api/v1/getQuestionsForAssign',null, {
            save: {
                method: 'GET'
            }
        });   
    }

    var assignQuestions = function() {
        return $resource('/api/v1/assignQuestions', null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAssignPatient = function() {
        return $resource('/api/v1/getAssignPatient', null, {
            get: {
                method: 'GET'
            }
        });
    }

    var viewAssignQuestion = function() {
        return $resource('/api/v1/viewAssignQuestion/:id', null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getQuestionsForAssignOnEdit = function() {
        return $resource('/api/v1/getQuestionsForAssignOnEdit/:id', null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var checkQuestionsEditable = function() {
        return $resource('/api/v1/checkQuestionsEditable/:id', null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    return {
        addRiskAssessment: addRiskAssessment,
        getEthinicity: getEthinicity,
        getDiabetesStatus: getDiabetesStatus,
        getSmokingStatus: getSmokingStatus,
        addSelfAssessmentQuestion:addSelfAssessmentQuestion,
        questionFileUpload:questionFileUpload,
        getAssesmentQuestions:getAssesmentQuestions,
        deleteQuestion:deleteQuestion,
        getAssesQuestionFile:getAssesQuestionFile,
        viewFileById:viewFileById,
        deleteFileById:deleteFileById,
        getAllPatient:getAllPatient,
        getQuestionsForAssign:getQuestionsForAssign,
        assignQuestions:assignQuestions,
        getAssignPatient:getAssignPatient,
        viewAssignQuestion:viewAssignQuestion,
        getQuestionsForAssignOnEdit:getQuestionsForAssignOnEdit,
        checkQuestionsEditable:checkQuestionsEditable
    }

}]);
