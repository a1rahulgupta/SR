"use strict";
angular.module("Login", []);
angular.module("Dashboard", []);
angular.module("RiskAssessment", []);
angular.module("UserManagement", []);
angular.module("Patient", []);
angular.module("SelfAssessment", []);
angular.module("EmailTemplate", []);
var iotiedApp = angular.module('iotiedApp', ['ui.router', 'ui.bootstrap', 'ui.tinymce', 'oc.lazyLoad', 'toastr', 'ngRoute', 'ngStorage', 'ngTable', 'ngIntlTelInput', 'ngResource', 'ngSanitize', 'ui.select', 'Login', 'Dashboard', 'RiskAssessment', 'UserManagement', 'SelfAssessment', 'EmailTemplate', 'ui.multiselect', 'angularjs-dropdown-multiselect', 'checklist-model'])
    .config(['$routeProvider', '$httpProvider', '$locationProvider', '$stateProvider', '$urlRouterProvider', '$qProvider', function (
        $routeProvider, $httpProvider, $locationProvider, $stateProvider, $urlRouterProvider, $qProvider) {

        $qProvider.errorOnUnhandledRejections(false);

        $httpProvider.interceptors.push(function ($q, $location, $window) {
            return {
                request: function (config) {
                    config.headers = config.headers || {};
                    if ($window.localStorage && $window.localStorage.token) {
                        config.headers.Authorization = $window.localStorage.token;
                    }
                    if ($location.path() == '/forgot_password') {
                        config.headers.entity = 'Admin';
                    }
                    return config;
                },
                response: function (response) {
                    if (response.status !== 200) {
                        // handle the case where the user is not authenticated
                        //$location.path('/');
                    }
                    return response || $q.when(response);
                }
            };
        });
        //$urlRouterProvider.otherwise('/dashboard');
        $urlRouterProvider.otherwise('/');
        $stateProvider
            .state('login', {
                url: '/',
                views: {
                    'header': {
                        //templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/login/views/login.html',
                        controller: "loginController"
                    },
                    'footer': {
                        //templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                title: 'Login',
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/login/controller/loginController.js',
                            '/admin/modules/login/services/loginService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: false
                }
            })
            .state('forgot', {
                url: '/forgot_password',
                views: {
                    'header': {
                        //templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/login/views/forgot_password.html',
                        controller: "loginController"
                    },
                    'footer': {
                        //templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                title: 'Forgot Password',
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/login/controller/loginController.js',
                            '/admin/modules/login/services/loginService.js'
                        ]);

                    }
                },
                data: {
                    isAuthenticate: false
                }
            })
            .state('reset', {
                url: '/resetPassword/:token',
                views: {
                    'header': {
                        //templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/login/views/reset_password.html',
                        controller: "loginController"
                    },
                    'footer': {
                        //templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/login/controller/loginController.js',
                            '/admin/modules/login/services/loginService.js'
                        ]);

                    }
                },
                data: {
                    isAuthenticate: false
                }
            })
            .state('dashboard', {
                url: '/dashboard',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/dashboard.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/dashboardController.js',
                            '/admin/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('updateProfile', {
                url: '/updateProfile',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/updateProfile.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/dashboardController.js',
                            '/admin/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('riskAssessment', {
                url: '/riskAssessment',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/riskAssessment.html',
                        controller: "riskAssessmentController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/riskAssessmentController.js',
                            '/admin/modules/dashboard/services/riskAssessmentService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('emailTemplateList', {
                url: '/emailTemplateList',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/emailTemplateList.html',
                        controller: "emailTemplateController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/emailTemplateController.js',
                            '/admin/modules/dashboard/services/emailTemplateService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('editEmailTemplate', {
                url: '/editEmailTemplate/:id',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/editEmailTemplate.html',
                        controller: "emailTemplateController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/emailTemplateController.js',
                            '/admin/modules/dashboard/services/emailTemplateService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('ethnicity', {
                url: '/ethnicity',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/ethnicity.html',
                        controller: "riskAssessmentController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/riskAssessmentController.js',
                            '/admin/modules/dashboard/services/riskAssessmentService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('smokingStatus', {
                url: '/smokingStatus',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/smokingStatus.html',
                        controller: "riskAssessmentController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/riskAssessmentController.js',
                            '/admin/modules/dashboard/services/riskAssessmentService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('diabetesStatus', {
                url: '/diabetesStatus',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/diabetesStatus.html',
                        controller: "riskAssessmentController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/riskAssessmentController.js',
                            '/admin/modules/dashboard/services/riskAssessmentService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('userListing', {
                url: '/userListing',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/userListing.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                },
                params: { selectedOption: null }
            })

            .state('addClinician', {
                url: '/addClinician',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/addClinician.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('editClinician', {
                url: '/editClinician/:id',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/addClinician.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })



            .state('addCareCoordinator', {
                url: '/addCareCoordinator',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/addCareCoordinator.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('editCareCoordinator', {
                url: '/editCareCoordinator/:id',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/addCareCoordinator.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('addAmbulance', {
                url: '/addAmbulance',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/addAmbulance.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('editAmbulance', {
                url: '/editAmbulance/:id',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/addAmbulance.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('addTowing', {
                url: '/addTowing',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/addTowing.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('editTowing', {
                url: '/editTowing/:id',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/addTowing.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('addPatient', {
                url: '/addPatient',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/addPatient.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('editPatient', {
                url: '/editPatient/:id',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/addPatient.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('addHospital', {
                url: '/addHospital',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/addHospital.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('editHospital', {
                url: '/editHospital/:id',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/addHospital.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('rulesengine', {
                url: '/rules-engine',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/rules.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/dashboardController.js',
                            '/admin/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('defaultRulesEngine', {
                url: '/defaultRulesEngine',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/defaultRuleEngine.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/dashboardController.js',
                            '/admin/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('editRuleEngine', {
                url: '/editRuleEngine/:id',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/rules.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/dashboardController.js',
                            '/admin/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('deviceList', {
                url: '/deviceList',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/devicelist.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/dashboardController.js',
                            '/admin/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('editdevice', {
                url: '/editdevice/:id',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/editDevice.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/dashboardController.js',
                            '/admin/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })


            .state('addDevice', {
                url: '/addDevice',
                views: {
                    'header': {
                        templateUrl: '/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/addDevice.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/modules/dashboard/controller/dashboardController.js',
                            '/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            //******************************by  Sunny on 17-June-2017************************//
            .state('addSelfAssessmentQuestion', {
                url: '/addSelfAssessmentQuestion',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/selfAssessment/views/addQuestion.html',
                        controller: "selfAssessmentController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/selfAssessment/controller/selfAssessmentController.js',
                            '/admin/modules/selfAssessment/services/selfAssessmentService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })


            .state('viewSelfAssessmentQuestion', {
                url: '/viewSelfAssessmentQuestion',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/selfAssessment/views/viewQuestion.html',
                        controller: "selfAssessmentController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/selfAssessment/controller/selfAssessmentController.js',
                            '/admin/modules/selfAssessment/services/selfAssessmentService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('assignSelfAssessmentQuestion', {
                url: '/assignSelfAssessmentQuestion',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/selfAssessment/views/assignSelfAssessmentQuestion.html',
                        controller: "selfAssessmentController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/selfAssessment/controller/selfAssessmentController.js',
                            '/admin/modules/selfAssessment/services/selfAssessmentService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('editAssignedQuestionsById', {
                url: '/editAssignedQuestionsById/:id',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/selfAssessment/views/editAssignedQuestions.html',
                        controller: "selfAssessmentController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/selfAssessment/controller/selfAssessmentController.js',
                            '/admin/modules/selfAssessment/services/selfAssessmentService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('kmeans', {
                url: '/kmeans',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/kmeans.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: 'modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/dashboardController.js',
                            '/admin/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('kmeansjs', {
                url: '/kmeans-plotting',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/modules/dashboard/views/csvupload.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: 'modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/dashboardController.js',
                            '/admin/modules/dashboard/services/dashboardService.js',
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('rulesEngineList', {
                url: '/rulesEngineList',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/rulesEngineList.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/dashboardController.js',
                            '/admin/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('smsTemplateList', {
                url: '/smsTemplateList',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/smsTemplateList.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },

                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/dashboardController.js',
                            '/admin/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('addSmsTemplate', {
                url: '/addSmsTemplate',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/addSmsTemplate.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/dashboardController.js',
                            '/admin/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })

            .state('editSmsTemplate', {
                url: '/editSmsTemplate/:id',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/dashboard/views/addSmsTemplate.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                //params: {'userid': null,'oauth_token': null,'oauth_verifier': null}, 
                //params: {}
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/dashboard/controller/dashboardController.js',
                            '/admin/modules/dashboard/services/dashboardService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('ambulenceList', {
                url: '/ambulenceList',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/ambulenceList.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('towingList', {
                url: '/towingList',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/towingList.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('careCoordinatorList', {
                url: '/careCoordinatorList',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/careCoordinatorList.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('patientList', {
                url: '/patientList',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/patientList.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('hospitalList', {
                url: '/hospitalList',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/hospitalList.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
            .state('clinicianList', {
                url: '/clinicianList',
                views: {
                    'header': {
                        templateUrl: '/admin/modules/dashboard/views/header.html'
                    },
                    'content': {
                        templateUrl: '/admin/modules/userManagement/views/clinicianList.html',
                        controller: "userMangController"
                    },
                    'footer': {
                        templateUrl: '/admin/modules/dashboard/views/footer.html'
                    }
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            '/admin/modules/userManagement/controller/userMangController.js',
                            '/admin/modules/userManagement/services/userMangService.js'
                        ]);
                    }
                },
                data: {
                    isAuthenticate: true
                }
            })
        //to remove the # from the URL
        //$locationProvider.html5Mode({enabled : true, requireBase : false});
    }])
    .run(['$rootScope', '$state', '$http', '$location', '$timeout', 'toastr', '$window',
        function ($rootScope, $state, $http, $location, $timeout, toastr, $window) {
            $rootScope.$on('$stateChangeStart', function (event, toState) {
                // $rootScope.PUBLICURL = $PUBLICURL; 
                $rootScope.CurrPath = toState.name;
                //if (toState.data.isAuthenticate == true) {
                if (!$window.localStorage.token && toState.data.isAuthenticate) {
                    event.preventDefault();
                    $state.go('login');
                    //window.location="/";
                }
                /*TO authenticate states on state change*/
                $http.get('/api/v1/auth/login_check')
                    .then(function (data) {
                        if (data.data.code == 200) {
                            var pathName = $window.location.pathname.toLowerCase();
                            var entity = data.data.data.role_id.name.toLowerCase();
                            if (pathName.indexOf(entity) === -1) {
                                event.preventDefault();
                                if (entity == 'patient') {
                                    var pathurl = '/';
                                } else {
                                    var pathurl = '/' + entity + '/';
                                }
                                window.location = '//' + $window.location.host + pathurl + '#!/dashboard';
                            }
                            $rootScope.User = data;
                            if (!toState.data.isAuthenticate) {
                                event.preventDefault();
                                $state.go('dashboard');
                            }
                            $rootScope.userLoggedin = true;
                            $rootScope.bodyclass = "skin-blue layout-top-nav fixed ng-scope";
                        } else {
                            $rootScope.bodyclass = "hold-transition login-page patientLoginBg";
                            $rootScope.userLoggedin = false;
                            delete $window.localStorage.token;
                            delete $window.localStorage.userLoggedin;
                            event.preventDefault();
                            if (toState.data.isAuthenticate) {
                                if ($location.path() != '/') {
                                    toastr.success('', 'Unfortunately you are logged out, please login again.');
                                }
                                $state.go('login');
                            } else {
                                // $state.go(toState.name);
                            }

                        }
                    });

                //}
            });
        }
    ])
    // Header controller
    .controller('headerCtrl', ['$scope', '$http', '$location', '$rootScope', '$window', 'toastr', '$state', '$uibModal',
        function ($scope, $http, $location, $rootScope, $window, toastr, $state, $uibModal) {

            $rootScope.menuassessment = ['addSelfAssessmentQuestion', 'viewSelfAssessmentQuestion', 'assignSelfAssessmentQuestion'];
            $rootScope.menupopurisk = ['kmeans', 'kmeansjs'];
            $rootScope.menuusermang = ['userListing', 'addPatient', 'editPatient', 'addClinician', 'editClinician', 'addHospital', 'editHospital', 'addCareCoordinator', 'editCareCoordinator', 'addAmbulance', 'editAmbulance', 'addTowing', 'editTowing'];
            // Get profile information
            $scope.getUserInfo = function () {
                $http.get('/api/v1/getAdminDetails', { headers: { 'Authorization': $window.localStorage.token } })
                    .then(function (response) {
                        if (response.data.code == 200) {
                            var userData = {};
                            userData.first_name = response.data.data.first_name;
                            userData.last_name = response.data.data.last_name;
                            $rootScope.userInfo = response.data.data;
                            $rootScope.userData = userData;
                        } else {
                            console.log("Something went wrong please try again.!'");
                        }
                    });
            };

            if ($window.localStorage.token) {
                $scope.getUserInfo();
            }

            

            $rootScope.getHospitalCount = function () {
                $http.get('/api/v1/getHospitalCount', {
                    headers: {
                        'Authorization': $window.localStorage.token
                    }

                })
                    .then(function (response) {
                        if (response.data.code == 200) {
                           
                            $rootScope.hospitalCount = response.data.data;
                        } else {
                             $rootScope.hospitalCount = 0;
                        }

                    })
            }
            $rootScope.getCareCount = function () {
                $http.get('/api/v1/getCareCount', {
                    headers: {
                        'Authorization': $window.localStorage.token
                    }

                })
                    .then(function (response) {
                        if (response.data.code == 200) {
                           
                            $rootScope.careCount = response.data.data;
                        } else {
                             $rootScope.careCount = 0;
                        }

                    })
            }
            $rootScope.getAmbulanceCount = function () {
                $http.get('/api/v1/getAmbulanceCount', {
                    headers: {
                        'Authorization': $window.localStorage.token
                    }

                })
                    .then(function (response) {
                        if (response.data.code == 200) {
                           
                            $rootScope.ambulanceCount = response.data.data;
                        } else {
                             $rootScope.ambulanceCount = 0;
                        }

                    })
            }
            $rootScope.getTowingCount = function () {
                $http.get('/api/v1/getTowingCount', {
                    headers: {
                        'Authorization': $window.localStorage.token
                    }

                })
                    .then(function (response) {
                        if (response.data.code == 200) {
                           
                            $rootScope.towingCount = response.data.data;
                        } else {
                             $rootScope.towingCount = 0;
                        }

                    })
            }

            if ($window.localStorage.userLoggedin) {
                $rootScope.userLoggedinnext = true;
                $rootScope.bodyclass = "skin-blue layout-top-nav fixed ng-scope";
            } else {
                $rootScope.bodyclass = "hold-transition login-page patientLoginBg";
            }
            // SignOut function
            $rootScope.logOut = function () {
                if ($window.localStorage.token) {
                    $http.get('/api/v1/auth/logout').then(function (data) {
                        if (data.data.code == 200) {
                            // Erase the token if the user fails to log in
                            delete $window.localStorage.token;
                            delete $window.localStorage.userLoggedin;
                            $rootScope.userLoggedin = false;
                            //$location.path('/');
                            window.location = "/admin";
                            $rootScope.bodyclass = "hold-transition login-page hospitalLoginBg";
                            toastr.success('Logout', 'Logout successfully');
                        } else {
                            toastr.error('Something went wrong please try again.!', 'Error');
                        }
                    });
                }
            };

            $rootScope.showww = function () {
                var dropd = document.getElementById("image-dropdown");
                dropd.style.height = "auto";
                dropd.style.overflow = "y-scroll";
            };

            $rootScope.hideee = function () {
                var dropd = document.getElementById("image-dropdown");
                dropd.style.height = "20px";
                dropd.style.overflow = "hidden";
            };

            $rootScope.myfuunc = function (imgParent) {
                $rootScope.hideee();
                var mainDIVV = document.getElementById("image-dropdown");
                imgParent.parentNode.removeChild(imgParent);
                mainDIVV.insertBefore(imgParent, mainDIVV.childNodes[0]);
            };
            $rootScope.appLauncher = function () {
                $uibModal.open({
                    templateUrl: 'modules/dashboard/views/appLauncher.html',
                    size: "lg",
                    controller: function ($scope, $uibModalInstance) {
                        $scope.cancel = function () {
                            $uibModalInstance.dismiss('cancel');
                        };
                    }
                });
            };

            /*$rootScope.appLauncher = function() {
                console.log(ModalService);
                ModalService.showModal({
                    templateUrl: 'myModalContent1.html',
                }).then(function(modal) {
                    modal.element.modal();
                    modal.close.then(function(result) {
                        $scope.message = "You said " + result;
                    });
                });
            };*/

        }
    ])

    .filter('propsFilter', function () {
        return function (items, props) {
            var out = [];

            if (angular.isArray(items)) {
                var keys = Object.keys(props);

                items.forEach(function (item) {
                    var itemMatches = false;

                    for (var i = 0; i < keys.length; i++) {
                        var prop = keys[i];
                        var text = props[prop].toLowerCase();
                        if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {
                            itemMatches = true;
                            break;
                        }
                    }

                    if (itemMatches) {
                        out.push(item);
                    }
                });
            } else {
                // Let the output be the input untouched
                out = items;
            }

            return out;
        };
    })


    .filter('measureTypeWithings', function ($filter) {
        var types = [];
        types['1'] = 'Weight (kg)';
        types['4'] = 'Height (meter)';
        types['5'] = 'Fat Free Mass (kg)';
        types['6'] = 'Fat Ratio (%)';
        types['8'] = 'Fat Mass Weight (kg)';
        types['9'] = 'Diastolic Blood Pressure (mmHg)';
        types['10'] = 'Systolic Blood Pressure (mmHg)';
        types['11'] = 'Heart Pulse (bpm)';
        types['12'] = 'Temperature';
        types['54'] = 'SP02(%)';
        types['71'] = 'Body Temperature';
        types['73'] = 'Skin Temperature';
        types['76'] = 'Muscle Mass';
        types['77'] = 'Hydration';
        types['88'] = 'Bone Mass';
        types['91'] = 'Pulse Wave Velocity';

        return function (input) {
            //console.log(input);
            var string = '';
            for (var i = 0; i < input.length; i++) {
                var key = input[i].type;
                string += types[key] + ' : ' + input[i].value;
            }
            return string;
        };
    })
    .directive('fileModel', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var model = $parse(attrs.fileModel);
                var modelSetter = model.assign;

                element.bind('change', function () {
                    scope.$apply(function () {
                        modelSetter(scope, element[0].files[0]);
                    });
                });
            }
        };
    }])
    .directive('selectPicker', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            require: '?ngModel',
            priority: 10,
            compile: function (tElement, tAttrs, transclude) {
                tElement.selectpicker($parse(tAttrs.selectpicker)());
                tElement.selectpicker('refresh');
                return function (scope, element, attrs, ngModel) {
                    if (!ngModel) return;

                    scope.$watch(attrs.ngModel, function (newVal, oldVal) {
                        scope.$evalAsync(function () {
                            if (!attrs.ngOptions || /track by/.test(attrs.ngOptions)) element.val(newVal);
                            element.selectpicker('refresh');
                        });
                    });

                    ngModel.$render = function () {
                        scope.$evalAsync(function () {
                            element.selectpicker('refresh');
                        });
                    }
                };
            }

        };
    }]);
