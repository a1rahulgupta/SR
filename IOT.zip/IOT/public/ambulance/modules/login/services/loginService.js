"use strict"

angular.module("Login")

.factory('loginService', ['$http', '$resource', function($http, $resource) {

    var login = function() {
        return $resource('/api/v1/auth/login', null, {
          'save': {method: 'POST'}
        });
    }
    var ambulanceSignUp = function() {
        console.log("in service");
        return $resource('/api/v1/auth/ambulanceSignUp', null, {
          'save': {method: 'POST'}
        });
    }

    var getCountry = function(deviceId){
        return $resource('/api/v1/auth/getCountry', null, {
            get: {
                method: 'GET'
            }
        });   
    }

    var getServiceType = function(deviceId){
        return $resource('/api/v1/auth/getServiceType', null, {
            get: {
                method: 'GET'
            }
        });   
    }
    var forgotpass = function(){
        return $resource('/api/v1/auth/forgotpass', null, {
            'save': { method: 'POST' }
        });   
    }
    var chkResetToken = function(){
        return $resource('/api/v1/auth/checkResetToken', null, {
            get: { 
                method: 'GET'
            }
        });
    }
    var resetPassword = function(){
        return $resource('/api/v1/auth/resetPassword', null, {
            'save': { method: 'POST' }
        });      
    }

    var getHospitalForReg = function(){
        return $resource('/api/v1/auth/getHospitalForReg', null, {
            get: {
                method: 'GET'
            }
        });   
    }
    return {
        login: login,
        ambulanceSignUp:ambulanceSignUp,
        getCountry:getCountry,
        getServiceType:getServiceType,
        forgotpass:forgotpass,
        chkResetToken:chkResetToken,
        resetPassword:resetPassword,
        getHospitalForReg:getHospitalForReg
    }

}]);

