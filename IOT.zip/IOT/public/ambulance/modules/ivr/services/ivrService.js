"use strict"

angular.module("Ivr").factory('ivrService', ['$http', '$resource', function($http, $resource) {

    var update = function() {
        return $resource('/api/v1/updateIvr', null, {
            get: {
                method: 'POST'
            }
        });
    }
    var getIvrData = function() {
        return $resource('/api/v1/getIvrData', null, {
            get: {
                method: 'GET'
            }
        });
    }
    return {
        update: update,
        getIvrData:getIvrData
    }

}]);

