"use strict";

var iotiedApp = angular.module('ivr.controller', []);
iotiedApp.controller("ivrController", ['$scope', '$rootScope', '$localStorage', 'ivrService', '$routeParams', '$route', '$location', '$state', '$stateParams', 'toastr', '$http',
    function($scope, $rootScope, $localStorage, ivrService, $routeParams, $route, $location, $state, $stateParams, toastr, $http) {
        $scope.ivrFrm = {}
        $scope.ivrNoGpsArr = {};
        $scope.disableSbmtBtn = false;
        $scope.loader = false;
        $scope.saveIvr = function() {
            if ($scope.form.$valid) {
                if($scope.ivrNoGpsArr){
                    $scope.ivrFrm.toll_free_no_gps = [];
                    $scope.ivrFrm.toll_free_no_gps.push($scope.ivrNoGpsArr);
                }
                $scope.err = '';
                $scope.disableLoginSbmtBtn = true;
                $scope.loader = true;
                ivrService.update().save($scope.ivrFrm, function(response) {
                    if(response.code == 200){
                        toastr.success(response.message);
                        $scope.ivrFrm = response.data;
                        if(response.data.toll_free_no_gps){
                            $scope.ivrNoGpsArr = response.data.toll_free_no_gps[0];
                        }
                    }else{
                        toastr.error(response.message);
                    }
                });
            }
        }

        $scope.getIvrData = function(){
            ivrService.getIvrData().get(function(response) {
                if(response.code == 200){
                    if(response.data){
                        $scope.ivrFrm = response.data;    
                        if(response.data.toll_free_no_gps){
                            $scope.ivrNoGpsArr = response.data.toll_free_no_gps[0];
                        }
                    }else{
                        $scope.ivrFrm = {}
                        $scope.ivrFrm.toll_free_no_gps = []
                    }
                }else{
                    $scope.ivrFrm = {}
                    $scope.ivrFrm.toll_free_no_gps = []
                }
            });
        }
    }
]);