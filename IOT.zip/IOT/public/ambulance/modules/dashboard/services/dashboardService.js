"use strict"

angular.module("Dashboard")

    .factory('dashboardService', ['$http', '$resource', function ($http, $resource) {

        var connectWithing = function () {
            return $resource('/api/v1/withings/connect', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var getDeviceList = function () {
            return $resource('/api/v1/getPatientDevice', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var activityList = function (deviceId, week) {
            return $resource('/api/v1/getPatientActivity/' + deviceId + '/' + week, null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var updateAmbulanceProfile = function () {
            return $resource('/api/v1/updateAmbulanceProfile', null, {
                save: {
                    method: 'POST',
                    headers: { 'Content-Type': undefined }
                }
            });
        }
        var addDevice = function () {
            return $resource('/api/v1/addPatientDevice', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var editDevice = function (id) {
            return $resource('/api/v1/addPatientDevice', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientDemographics = function () {
            return $resource('/api/v1/addPatientDemographics', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientInsuranceDetails = function () {
            return $resource('/api/v1/addPatientInsuranceDetails', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientVitals = function () {
            return $resource('/api/v1/addPatientVitals', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientEncounter = function () {
            return $resource('/api/v1/addPatientEncounter', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientAllergiesAndReactions = function () {
            return $resource('/api/v1/addPatientAllergiesAndReactions', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientMedication = function () {
            return $resource('/api/v1/addPatientMedication', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientFamilyHistory = function () {
            return $resource('/api/v1/addPatientFamilyHistory', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientSurgeries = function () {
            return $resource('/api/v1/addPatientSurgeries', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getDiseaseList = function () {
            return $resource('/api/v1/getDiseaseList', null, {
                get: {
                    method: 'GET'
                }
            });
        }

        var addPatientDisease = function () {
            return $resource('/api/v1/addPatientDisease', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var addPatientChronicDisease = function () {
            return $resource('/api/v1/addPatientChronicDisease', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getDeviceDetail = function (id) {
            return $resource('/api/v1/getPatientDevice/' + id, null, {
                save: {
                    method: 'GET'
                }
            });
        }
        var deleteDevice = function (id) {
            return $resource('/api/v1/deletePatientDevice/' + id, null, {
                save: {
                    method: 'GET'
                }
            });
        }
        var dailyActivity = function () {
            return $resource('/api/v1/withings/DailySteps', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var getServiceType = function (deviceId) {
            return $resource('/api/v1/auth/getServiceType', null, {
                get: {
                    method: 'GET'
                }
            });
        }

        var getCountry = function (deviceId) {
            return $resource('/api/v1/auth/getCountry', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var createNotify = function () {
            return $resource('/api/v1/getNotificationlist', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var getAssignPatientForAmbulance = function () {
            return $resource('/api/v1/getAssignPatientForAmbulance', null, {
                save: {
                    method: 'GET'
                }
            });
        }

        //-----------------------communication module-----------------------------

        var composeMail = function () {
            return $resource('/api/v1/composeMail', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getMailList = function () {
            return $resource('/api/v1/getMailList', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getMailById = function (id) {
            return $resource('/api/v1/getMailById/' + id, null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            });
        }

        var getSentMailList = function () {
            return $resource('/api/v1/getSentMailList', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getAllignedUsersList = function () {
            return $resource('/api/v1/getAllAllignedUsers', null, {
                get: {
                    method: 'GET'
                }
            });
        }

        var sendSMS = function () {
            return $resource('/api/v1/sendSMS', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getSmsMsgList = function () {
            return $resource('/api/v1/getSmsMsgList', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getSentSMSList = function () {
            return $resource('/api/v1/getSentSMSList', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var getAssignUsersByHospital = function (id) {
            return $resource('/api/v1/getAssignUsersByHospital/' + id, null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            });
        }

        var getUsersList = function () {
            return $resource('/api/v1/getUserList', null, {
                get: {
                    method: 'GET'
                }
            });
        }

        var getAllEntitiesLinkedToAmbulance = function () {
            return $resource('/api/v1/getAllEntitiesLinkedToAmbulance', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var markMailAsRead = function () {
            return $resource('/api/v1/markMailAsRead', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var deleteEmail = function () {
            return $resource('/api/v1/deleteEmailByHospital', null, {
                save: {
                    method: 'POST'
                }
            });
        }

        var deleteSms = function () {
            return $resource('/api/v1/deleteSmsByHospital', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var markSmsAsRead = function (id) {
            console.log("markSmsAsRead", id);
            return $resource('/api/v1/markSmsAsRead/' + id, null, {
                save: {
                    method: 'GET'

                }
            });
        }
        var getEmailMesssageListforAmbulance = function () {
            return $resource('/api/v1/getEmailMesssageListforAmbulance', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var getEmailMesssageById = function (id) {
            return $resource('/api/v1/getEmailMesssageById/' + id, null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            });
        }
        var getSmsTemplateById = function (id) {
            return $resource('/api/v1/getSmsTemplateById/' + id, null, {
                get: {
                    method: 'GET',
                    id: '@id'
                }
            });
        }
        var getSmsTemplateListforAmbulance = function () {
            return $resource('/api/v1/getSmsTemplateListforAmbulance', null, {
                get: {
                    method: 'GET'
                }
            });
        }

        var getMissedVideoCallList = function () {
            return $resource('/api/v1/getMissedVideoCallList', null, {
                get: {
                    method: 'GET'
                }
            });
        }
        var deleteMissedCall = function (id) {
            return $resource('/api/v1/deleteMissedCall/' + id, null, {
                save: {
                    method: 'GET'
                }
            });
        }
        var markAsReadMissedCall = function (id) {
            return $resource('/api/v1/markAsReadMissedCall/' + id, null, {
                save: {
                    method: 'GET'

                }
            });
        }
        return {
            connectWithing: connectWithing,
            addDevice: addDevice,
            getDeviceList: getDeviceList,
            activityList: activityList,
            addPatientDemographics: addPatientDemographics,
            addPatientInsuranceDetails: addPatientInsuranceDetails,
            addPatientVitals: addPatientVitals,
            addPatientEncounter: addPatientEncounter,
            addPatientAllergiesAndReactions: addPatientAllergiesAndReactions,
            addPatientMedication: addPatientMedication,
            addPatientFamilyHistory: addPatientFamilyHistory,
            addPatientSurgeries: addPatientSurgeries,
            getDiseaseList: getDiseaseList,
            addPatientDisease: addPatientDisease,
            addPatientChronicDisease: addPatientChronicDisease,
            getDeviceDetail: getDeviceDetail,
            editDevice: editDevice,
            dailyActivity: dailyActivity,
            createNotify: createNotify,
            deleteDevice: deleteDevice,
            updateAmbulanceProfile: updateAmbulanceProfile,
            getServiceType: getServiceType,
            getCountry: getCountry,
            getAssignPatientForAmbulance: getAssignPatientForAmbulance,
            //communication module-------------
            composeMail: composeMail,
            getMailList: getMailList,
            getMailById: getMailById,
            getSentMailList: getSentMailList,
            getAllignedUsersList: getAllignedUsersList,
            sendSMS: sendSMS,
            getSmsMsgList: getSmsMsgList,
            getSentSMSList: getSentSMSList,
            getAssignUsersByHospital: getAssignUsersByHospital,
            getUsersList: getUsersList,
            getAllEntitiesLinkedToAmbulance: getAllEntitiesLinkedToAmbulance,
            markMailAsRead: markMailAsRead,
            deleteSms: deleteSms,
            deleteEmail: deleteEmail,
            markSmsAsRead: markSmsAsRead,
            getEmailMesssageListforAmbulance: getEmailMesssageListforAmbulance,
            getEmailMesssageById: getEmailMesssageById,
            getSmsTemplateById: getSmsTemplateById,
            getSmsTemplateListforAmbulance: getSmsTemplateListforAmbulance,
            getMissedVideoCallList: getMissedVideoCallList,
            deleteMissedCall: deleteMissedCall,
            markAsReadMissedCall: markAsReadMissedCall

            //communication module end-----------------------------------
        }

    }]);
