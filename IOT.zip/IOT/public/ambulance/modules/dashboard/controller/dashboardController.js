"use strict";

var iotiedApp = angular.module('dashboard.controller', []);
iotiedApp.controller("dashboardController", ['$scope', '$rootScope', '$localStorage', 'dashboardService', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', 'toastr', 'ngTableParams', 'ngTableParamsService', '$uibModal',
    function ($scope, $rootScope, $localStorage, dashboardService, $routeParams, $route, $location, $state, $stateParams, $http, toastr, ngTableParams, ngTableParamsService, $uibModal) {
        $scope.mailData = {}
        $scope.mailData.title = '';
        $scope.smsData = {}
        $scope.smsData.title = '';

        $scope.tinymceOptions = {
            menubar: false,
            toolbar: 'fontselect fontsizeselect | formatselect | undo redo | bold italic | alignleft aligncenter alignright | code | removeformat'
        };

        $scope.measureTypes = [{ 'type': '1', 'name': 'Weight (kg)', 'measures': [] },
        { 'type': '4', 'name': 'Height (meter)', 'measures': [] },
        { 'type': '5', 'name': 'Fat Free Mass (kg)', 'measures': [] },
        { 'type': '6', 'name': 'Fat Ratio (%)', 'measures': [] },
        { 'type': '8', 'name': 'Fat Mass Weight (kg)', 'measures': [] },
        { 'type': '9', 'name': 'Diastolic BP (mmHg)', 'measures': [] },
        { 'type': '10', 'name': 'Systolic BP (mmHg)', 'measures': [] },
        { 'type': '11', 'name': 'Heart Pulse (bpm)', 'measures': [] },
        { 'type': '12', 'name': 'Temperature', 'measures': [] },
        { 'type': '54', 'name': 'SP02(%)', 'measures': [] },
        { 'type': '71', 'name': 'Body Temperature', 'measures': [] },
        { 'type': '73', 'name': 'Skin Temperature', 'measures': [] },
        { 'type': '76', 'name': 'Muscle Mass', 'measures': [] },
        { 'type': '77', 'name': 'Hydration', 'measures': [] },
        { 'type': '88', 'name': 'Bone Mass', 'measures': [] },
        { 'type': '91', 'name': 'Pulse Wave Velocity', 'measures': [] },
        ];
        var formDataFileUpload = '';
        $scope.imageBase64 = '';

        $scope.connectToWithings = function (devId) {
            $scope.connectData = dashboardService.connectWithing().get({ 'deviceId': devId }, function (response, err) {
                //console.log('response',response);
                if (response.code == 200) {
                    //window.location.href = response.url;
                    if (response.url) {
                        var win = window.open(response.url, '_blank');
                        win.focus();
                    } else {
                        toastr.success(response.message);
                    }
                } else {
                    $scope.connectData = {};
                }
            });
        };

        $scope.createNotify = function (devId) {
            $scope.connectData = dashboardService.createNotify().get({ 'deviceId': devId }, function (response, err) {
                console.log('response', response);
            });
        }

        $scope.deviceForm = {};
        $scope.disableSubmitBtn = false;
        $scope.loader = false;

        $scope.addDevice = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                dashboardService.addDevice().save($scope.deviceForm, function (response) {
                    //console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        $scope.editDevice = function () {
            console.log('parama', $stateParams.id);
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                dashboardService.editDevice($stateParams.id).save($scope.deviceForm, function (response) {
                    //console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        //$location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        $scope.deviceList = function () {
            $scope.deviceData = dashboardService.getDeviceList().get({}, function (response, err) {
                // console.log('response',response);
                if (response.code == 200) {
                    $scope.deviceData = response.data;
                } else {
                    $scope.deviceData = {};
                }
            });
        }
        $scope.imageBrowse = function () {
            document.getElementById('filePicker').addEventListener('change', function (evt) {
                var files = evt.target.files;
                var file = files[0];
                if (files && file) {
                    var splitFileName = file.name.split('.');
                    var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                    if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {
                        if (file.size > 6291456) {
                            logger.log('File size cannot exceed limit of 6 mb');
                            document.getElementById("filePicker").value = "";
                        } else {
                            formDataFileUpload = file;
                            // formDataFileUpload.append('file', file);
                            var reader = new FileReader();
                            reader.onload = function (readerEvt) {
                                $scope.imageBase64 = btoa(readerEvt.target.result);
                                $scope.$apply();
                                document.getElementById('imgTag').src = 'data:image/' + ext + ';base64,' + $scope.imageBase64;
                            };
                            reader.readAsBinaryString(file);
                        }
                    } else {
                        document.getElementById("filePicker").value = "";
                        bootbox.alert('Invalid image format');
                    }
                }
            });
        }

        $scope.updateAmbulanceProfile = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;

                var formData = new FormData();
                formData.append('company_name', $scope.userData.company_name);
                formData.append('address', $scope.userData.address);
                formData.append('mobile_no', $scope.userData.mobile_no);
                formData.append('city', $scope.userData.city);
                formData.append('state', $scope.userData.state);
                formData.append('zip_code', $scope.userData.zip_code);
                formData.append('country', $scope.userData.country);
                formData.append('service_type', $scope.userData.service_type);
                if (formDataFileUpload) {
                    formData.append('file', formDataFileUpload);
                }
                dashboardService.updateAmbulanceProfile().save(formData, function (response) {
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        toastr.success(response.message);
                        $location.path('/updateProfile');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }

                });
            }
        }

        $scope.getCountry = function () {
            console.log("here");
            dashboardService.getCountry().get({}, function (response, err) {
                // console.log('response',response);
                if (response.code == 200) {
                    $scope.country = response.data;
                } else {
                    $scope.country = {};
                }
            });
        }

        $scope.getServiceType = function () {
            dashboardService.getServiceType().get({}, function (response, err) {
                // console.log('response',response);
                if (response.code == 200) {
                    $scope.service = response.data;
                } else {
                    $scope.country = {};
                }
            });
        }

        $scope.getDeviceDetail = function () {
            console.log('parama', $stateParams.id);
            $scope.deviceData = dashboardService.getDeviceDetail($stateParams.id).get({}, function (response, err) {
                if (response.code == 200) {
                    console.log('here');
                    $scope.deviceForm = response.data;
                } else {
                    $scope.deviceForm = {};
                }
            });
        }
        $scope.deleteDevice = function (devId) {
            $scope.deviceData = dashboardService.deleteDevice(devId).get({}, function (response, err) {
                if (response.code == 200) {
                    toastr.success(response.message);
                    $scope.deviceList();
                } else {
                    toastr.error('Something went wrong, please try again later.');
                }
            });
        }
        $scope.CurrntWeek = 0;
        $scope.changeWeek = function (num) {
            if (num == 0) {
                $scope.CurrntWeek = 0;
            } else if (num == 'd') {
                $scope.CurrntWeek = 'd';
            } else {
                if ($scope.CurrntWeek == 'd') {
                    $scope.CurrntWeek = 0;
                    $scope.CurrntWeek = $scope.CurrntWeek + num;
                } else {
                    $scope.CurrntWeek = $scope.CurrntWeek + num;
                }
            }
            $scope.activityList($scope.CurrntWeek);
        }
        $scope.activityList = function (week) {
            if (!week) {
                var week = 0;
            }
            if (week == 'd') {
                var loopval = 1;
            } else {
                var loopval = 7;
            }
            console.log('parama', $stateParams.id);
            var deviceId = $stateParams.id;
            $scope.activityData = dashboardService.activityList(deviceId, week).get({}, function (response, err) {
                if (response.code == 200) {
                    console.log('quesry response', response.data);
                    //$scope.activityData = response.data;
                    $scope.weekDays = response.dates;
                    console.log(response.dates);
                    console.log(response.data.length);
                    var dates = []
                    var newArr = []
                    var incr = 0;
                    for (var i = 0; i < loopval; i++) {
                        var b = moment(response.dates.startDate).add(i, 'day');
                        //console.log(b);
                        if (response.data.length > 0) {
                            var compDate = response.data[incr]._id;
                            var t = moment(b).twix(compDate);
                            console.log('compir', t.isSame("day"));
                            if (t.isSame("day")) {
                                var obj = {}
                                obj['_id'] = moment(compDate).format('YYYY-MM-DD');
                                obj['data'] = response.data[incr].data;
                                newArr.push(obj);
                                incr++;
                            } else {
                                var obj = {}
                                obj['_id'] = moment(b).format('YYYY-MM-DD');
                                obj['data'] = [];
                                newArr.push(obj);
                            }
                        } else {
                            var obj = {}
                            obj['_id'] = moment(b).format('YYYY-MM-DD');
                            obj['data'] = [];
                            newArr.push(obj);
                        }
                        //console.log('in',newArr);
                        //var obj = response.data[i].data;
                        $scope.activityData = newArr;
                        var obj = newArr[i].data;
                        for (var j = 0; j < obj.length; j++) {
                            syncMeasures(i, response.data.length, obj[j].measures);
                        }
                    }
                    console.log('sdsds', newArr);
                    /*for (var i = 0; i < response.data.length; i++){
                        var obj = response.data[i].data;
                        for(var j = 0; j<obj.length;j++){
                            syncMeasures(i,response.data.length,obj[j].measures);
                        }
                    }*/
                } else {
                    $scope.activityData = {};
                }
            });

            $scope.dailyActivityData = dashboardService.dailyActivity().get({ 'deviceId': deviceId }, function (response, err) {
                if (response.code == 200) {
                    $scope.dailyActivityData = response.data;
                } else {
                    $scope.dailyActivityData = {};
                }
            });
        }

        /**
         * Function is use to add Patient Demographics  
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */
        function syncMeasures(dt, count, arr) {
            var key = 'dt' + dt
            //var key = dt
            for (var k = 0; k < arr.length; k++) {
                for (var l = 0; l < $scope.measureTypes.length; l++) {
                    if (arr[k].type == $scope.measureTypes[l].type) {
                        var obj = {}
                        obj[key] = arr[k].value;
                        $scope.measureTypes[l].measures.push(obj);
                    }
                }
            }
        }
        /**
         * Function is use to add Patient Demographics  
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */

        $scope.addPatientDemographics = function () {

            console.log("addPatientDemographics", $scope.demographicForm)
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                dashboardService.addPatientDemographics().save($scope.demographicForm, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };


        /**
         * Function is use to add Patient Insurance Details 
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */
        $scope.addPatientInsuranceDetails = function () {

            console.log("addPatientInsuranceDetails", $scope.insuranceForm)
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                dashboardService.addPatientInsuranceDetails().save($scope.insuranceForm, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };
        /**
         * Function is use to add Patient Vitals 
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */
        $scope.addPatientVitals = function () {

            console.log("addPatientVitals", $scope.vitalsForm)
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                var blood_pressure = [{
                    minValue: $scope.bloodPresure.minValue,
                    maxValue: $scope.bloodPresure.maxValue
                }]
                var vitalsForm = $scope.vitalsForm;
                vitalsForm.blood_pressure = blood_pressure;
                console.log("vitals", vitalsForm);
                dashboardService.addPatientVitals().save(vitalsForm, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };
        /**
         * Function is use to add Patient Encounter  
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */
        $scope.addPatientEncounter = function () {

            console.log("addPatientEncounter", $scope.encounterForm)
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                var diagnosis = [{
                    diagnosis1: $scope.diagnosis.diagnosis1,
                    diagnosis2: $scope.diagnosis.diagnosis2,
                    diagnosis3: $scope.diagnosis.diagnosis3
                }]
                var encounterForm = $scope.encounterForm;
                encounterForm.diagnosis = diagnosis;
                console.log("encounterForm", encounterForm);
                dashboardService.addPatientEncounter().save(encounterForm, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        /**
         * Function is use to add Patient Allergies And Reactions 
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */
        $scope.addPatientAllergiesAndReactions = function () {

            console.log("addPatientAllergiesAndReactions", $scope.allergiesForm)
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                var allergy = {};
                var allergies = [{
                    substance: $scope.allergiesForm.substance,
                    reaction: $scope.allergiesForm.reaction,
                    severity: $scope.allergiesForm.severity,
                    status: $scope.allergiesForm.status
                }]
                allergy.allergies = allergies;
                console.log("allergy", allergy);
                dashboardService.addPatientAllergiesAndReactions().save(allergy, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        /**
         * Function is use to add Patient Medication 
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */
        $scope.addPatientMedication = function () {

            console.log("addPatientMedication", $scope.medicationForm)
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                var medication = [{
                    diagnosis1: $scope.medicationForm.medication1,
                    diagnosis2: $scope.medicationForm.medication2,
                    diagnosis3: $scope.medicationForm.medication3
                }]
                var medicationForm = $scope.medicationForm;
                medicationForm.medication = medication;
                console.log("medication", medication);
                dashboardService.addPatientMedication().save(medicationForm, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        /**
         * Function is use to add Patient Family History  
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */
        $scope.addPatientFamilyHistory = function () {

            console.log("addPatientFamilyHistory", $scope.familyForm)
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                dashboardService.addPatientFamilyHistory().save($scope.familyForm, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        /**
         * Function is use to add Patient Surgeries  
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 13-June-2017
         */
        $scope.addPatientSurgeries = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                var surgeryData = {};
                var surgeries = [{
                    surgery: $scope.surgeryForm.surgery,
                    surgery_date: $scope.surgeryForm.surgery_date,
                    physician: $scope.surgeryForm.physician,
                    status: $scope.surgeryForm.status
                }]
                surgeryData.surgeries = surgeries;
                console.log("surgeryData", surgeryData);
                dashboardService.addPatientSurgeries().save(surgeryData, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        /**
         * Function is use to Get Disease    
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 14-June-2017
         */
        $scope.getDiseaseList = function () {
            dashboardService.getDiseaseList().get({}, function (response, err) {
                // console.log('response',response);
                if (response.code == 200) {
                    $scope.diseaseData = response.data;
                    console.log("diseasedata", response.data);
                } else {
                    $scope.diseaseData = {};
                }
            });
        }

        /**
         * Function is use to add Patient Disease  
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 15-June-2017
         */
        $scope.addPatientDisease = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                dashboardService.addPatientDisease().save($scope.diseaseForm, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        /**
         * Function is use to add Patient Chronic Disease  
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 15-June-2017
         */
        $scope.addPatientChronicDisease = function () {
            if ($scope.form.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                dashboardService.addPatientChronicDisease().save($scope.chronicDiseaseForm, function (response) {
                    console.log(response);
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        //$window.location.href = '/#!/deviceList'
                        toastr.success(response.message);
                        // $location.path('/deviceList');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        $scope.getAssignPatientForAmbulance = function () {
            console.log("getAssignPatientForAmbulance");
            dashboardService.getAssignPatientForAmbulance().get({}, function (response, err) {
                console.log("getAssignPatientForAmbulance------------>>>>>>", response);
                if (response.code == 200) {
                    $scope.assignPatientList = response.data;
                }
            });
        }

        $scope.getAllEntitiesLinkedToAmbulance = function () {
            $scope.entitiesList = [];
            dashboardService.getAllEntitiesLinkedToAmbulance().save({}, function (response) {
                if (response.code == 200) {
                    $scope.entitiesList = response.data;
                    console.log("$scope.getAllEntitiesLinkedToHospital---->", $scope.entitiesList);
                }
            });
        };


        //--------------Mail Section------------------------------------------

        $scope.getAllUsers = function () {
            // $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            $scope.tableLoader = true;
            $scope.usersList = [];
            dashboardService.getUsersList().get({}, function (response) {
                $scope.usersList = response.data;
            });
        };


        $scope.loadEmails = function ($query) {
            return ($scope.entitiesList).filter(function (user) {
                return ((user.name).toLowerCase().indexOf($query.toLowerCase()) != -1);
            });
        };

        $scope.mailForm = {};
        $scope.disableSubmitBtn = false;
        $scope.loader = false;
        //Swapnali
        $scope.sendMail = function (mailData) {
            if ($scope.mailForm.$valid) {
                $scope.err = '';
                $scope.disableSubmitBtn = true;
                $scope.loader = true;
                if (mailData.mail_to) {
                    mailData.mail_to = (mailData.mail_to).map(function (tag) {
                        return tag.email;
                    }).join(",");
                }
                if (mailData.mail_cc) {
                    mailData.mail_cc = (mailData.mail_cc).map(function (tag) {
                        return tag.email;
                    }).join(",");
                }
                if (mailData.mail_bcc) {
                    mailData.mail_bcc = (mailData.mail_bcc).map(function (tag) {
                        return tag.email;
                    }).join(",");
                }
                dashboardService.composeMail().save(mailData, function (response) {
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                    if (response.code == 200) {
                        toastr.success(response.message);
                        $location.path('/mail');
                    } else {
                        toastr.error(response.message, 'Error');
                        $scope.disableSubmitBtn = false;
                        $scope.loader = false;
                    }
                });
            }
        };

        $scope.showMail = function (id) {
            dashboardService.markMailAsRead().save({ id: id }, function (response) {
                if (response.code == 200) {
                }
            });
            $state.go('singleMail', {
                id: id
            });
        };

        $scope.showSentMail = function (id) {
            $state.go('singleSentMail', {
                id: id
            });
        };

        $scope.getMailById = function () {
            $scope.mailInfo = {};
            dashboardService.getMailById($stateParams.id).get({}, function (response) {
                if (response.code == 200) {
                    $scope.mailInfo = response.data;
                }
            });
        };

        $scope.setReplyInfo = function () {
            $scope.mailData = {};
            var mailTo = ($scope.mailInfo.from_email).split(',');
            (mailTo).map(function (email) { return { email: email } })
            $scope.mailData.mail_to = mailTo;
            $scope.mailData.mail_subject = 'Re:' + $scope.mailInfo.subject;
        }

        $scope.replyMailForm = {};
        $scope.sendReplyMail = function (mailData) {
            if (mailData.mail_to) {
                mailData.mail_to = (mailData.mail_to).map(function (tag) {
                    return tag.email;
                }).join(",");
            }
            dashboardService.composeMail().save(mailData, function (response) {
                $scope.disableSubmitBtn = false;
                if (response.code == 200) {
                    toastr.success(response.message);
                    $location.path('/mail');
                } else {
                    toastr.error(response.message, 'Error');
                    $scope.disableSubmitBtn = false;
                    $scope.loader = false;
                }
            });

        };

        $scope.getMails = function () {
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.mailList = [];
                    dashboardService.getMailList().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        $scope.mailList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }

        var getData = ngTableParamsService.get();
        $scope.searchTextField = getData.searchText;
        $scope.searching = function () {
            ngTableParamsService.set('', '', $scope.searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.mailList = [];
                    dashboardService.getMailList().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        // $scope.paramUrlActive = paramUrl;
                        $scope.mailList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }

        $scope.getSentMailList = function () {
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.mailList = [];
                    dashboardService.getSentMailList().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        $scope.mailList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }

        var getData = ngTableParamsService.get();
        $scope.searchTextField = getData.searchText;
        $scope.searching = function () {
            ngTableParamsService.set('', '', $scope.searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.mailList = [];
                    dashboardService.getSentMailList().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        // $scope.paramUrlActive = paramUrl;
                        $scope.mailList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }

        $scope.redirectToInbox = function () {
            $location.path('/mail');
        };

        //-------------------------------SMS SECTION-------------------------------------
        //Swapnali
        $scope.smsForm = {};
        $scope.sendSMS = function (smsData) {
            console.log(" sendSms----->>>", $scope.smsForm);
            if ($scope.smsForm.$valid) {
                let sms_to = [];
                console.log(" smsData.sms_to----->>>", smsData.sms_to);
                if (smsData.sms_to) {
                    (smsData.sms_to).forEach(function (user) {
                        sms_to.push({ userid: user.userid, name: user.name, mobileNo: user.mobile_no });
                    });
                }
                smsData.sms_to = sms_to;
                console.log(" $scope.sms_to----->>>", smsData);
                dashboardService.sendSMS().save(smsData, function (response) {
                    console.log("sendSMS response---->", response)
                    if (response.code == 200) {
                        toastr.success(response.message);
                        $location.path('/sms');
                    } else {
                        toastr.error(response.message, 'Error');
                    }
                });
            }
        };

        $scope.getAllAllignedUsers = function () {
            $scope.allignedUsersList = [];
            dashboardService.getAllignedUsersList().get({}, function (response) {
                $scope.allignedUsersList = response.data;
            });
        };

        $scope.loadPhoneNumbers = function ($query) {
            return ($scope.entitiesList).filter(function (user) {
                return (user.name).toLowerCase().indexOf($query.toLowerCase()) != -1;
            });
        };

        $scope.getSmsMsgList = function () {
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.usersList = [];
                    dashboardService.getSmsMsgList().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        $scope.smsList = response.data;
                        console.log("$scope.smsList---->", $scope.smsList);
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }

        var getData = ngTableParamsService.get();
        $scope.searchTextField = getData.searchText;
        $scope.searching = function () {
            ngTableParamsService.set('', '', $scope.searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.smsList = [];
                    dashboardService.getSmsMsgList().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        // $scope.paramUrlActive = paramUrl;
                        $scope.smsList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }
        //---------------------------------------------
        $scope.getSentSmsList = function () {
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.usersList = [];
                    dashboardService.getSentSMSList().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        $scope.sentSmsList = response.data;
                        console.log("$scope.getSentSMSList---->", $scope.sentSmsList);
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }

        var getData = ngTableParamsService.get();
        $scope.searchTextField = getData.searchText;
        $scope.searching = function () {
            ngTableParamsService.set('', '', $scope.searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function ($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.sentSmsList = [];
                    dashboardService.getSentSMSList().save($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        // $scope.paramUrlActive = paramUrl;
                        $scope.sentSmsList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.totalCount;
                        params.total(response.totalCount);
                        $defer.resolve(data);
                    });
                }
            });
        }

        // $scope.getSentSmsList = function () {
        //     $scope.tableLoader = true;
        //     $scope.sentSmsList = [];
        //     dashboardService.getSentSMSList().get({}, function (response) {
        //         if (response.code == 200) {
        //             $scope.tableLoader = false;
        //             $scope.sentSmsList = response.data;
        //         }
        //     });
        // };

        // -----------------Videcall section -------------------

        // $scope.getAssignUsersList = function () {
        //     $scope.tableLoader = true;
        //     $scope.assignedUserList = [];
        //     console.log("$rootScope--->", $rootScope);
        //     if ($rootScope.userInfo._id) {
        //         dashboardService.getAssignUsersByHospital($rootScope.userInfo._id).get({}, function (response) {
        //             if (response.code == 200) {
        //                 $scope.tableLoader = false;
        //                 $scope.assignedUserList = response.data;
        //             }
        //         });
        //     }
        // };

        // $scope.getAllEntitiesLinkedToHospital = function () {
        //     $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
        //         counts: [],
        //         getData: function ($defer, params) {
        //             // send an ajax request to your server. in my case MyResource is a $resource.
        //             ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
        //             $scope.paramUrl = params.url();
        //             $scope.tableLoader = true;
        //             $scope.entitiesList = [];
        //             dashboardService.getAllEntitiesLinkedToHospital().save($scope.paramUrl, function (response) {
        //                 $scope.tableLoader = false;
        //                 $scope.entitiesList = response.data;
        //                 console.log("$scope.getAllEntitiesLinkedToHospital---->", $scope.entitiesList);
        //                 var data = response.data;
        //                 $scope.totalCount = response.totalCount;
        //                 params.total(response.totalCount);
        //                 $defer.resolve(data);
        //             });
        //         }
        //     });
        // }

        // var getData = ngTableParamsService.get();
        // $scope.searchTextField = getData.searchText;
        // $scope.searching = function () {
        //     ngTableParamsService.set('', '', $scope.searchTextField, '');
        //     $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
        //         counts: [],
        //         getData: function ($defer, params) {
        //             // send an ajax request to your server. in my case MyResource is a $resource.
        //             ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
        //             $scope.paramUrl = params.url();
        //             $scope.tableLoader = true;
        //             $scope.entitiesList = [];
        //             dashboardService.getAllEntitiesLinkedToHospital().save($scope.paramUrl, function (response) {
        //                 $scope.tableLoader = false;
        //                 // $scope.paramUrlActive = paramUrl;
        //                 $scope.entitiesList = response.data;
        //                 var data = response.data;
        //                 $scope.totalCount = response.totalCount;
        //                 params.total(response.totalCount);
        //                 $defer.resolve(data);
        //             });
        //         }
        //     });
        // }

        $scope.viewSms = function (item, read_id) {
            dashboardService.markSmsAsRead(read_id._id).get({}, function (response) {
                if (response.code == 200) {
                    $scope.getSmsMsgList();
                }
            });
            $uibModal.open({
                templateUrl: '/ambulance/modules/dashboard/views/sms/viewSms.html',
                size: "lg",
                controller: function ($scope, $uibModalInstance) {
                    $scope.smsDetails = item;
                    $scope.cancel = function () {
                        $uibModalInstance.dismiss('cancel');
                    };

                }
            });
        }

        $scope.removeSms = function () {
            var smsListArray = [];
            $scope.selectedAll = false;
            angular.forEach($scope.smsList, function (selected) {
                if (selected.selected) {
                    console.log(!selected.selected);
                    smsListArray.push(selected);
                    $scope.List = smsListArray;
                }
            });
            $scope.deleteSms($scope.List);
        };
        $scope.checkAllSms = function () {
            if (!$scope.selectedAll) {
                $scope.selectedAll = true;
            } else {
                $scope.selectedAll = false;
            }
            angular.forEach($scope.smsList, function (sms) {
                sms.selected = $scope.selectedAll;
            });
        };

        $scope.checkSms = function ($event, id) {
            $event.stopPropagation();
        };
        $scope.deleteSms = function (smsListArray) {
            var obj = {};
            obj.smsListArray = smsListArray;
            if (obj.smsListArray && obj.smsListArray.length > 0) {
                bootbox.confirm('Are you sure, you want to delete this SMS', function (r) {
                    if (r) {
                        dashboardService.deleteSms().save(obj, function (response, err) {
                            if (response.code == 200) {
                                toastr.success(response.message);
                                $scope.getSmsMsgList();
                            } else {
                                toastr.error('Something went wrong, please try again later.');
                            }
                        });
                    }
                })
            } else {
                bootbox.alert('Please select SMS to delete.');
            }

        }
        $scope.removeEmail = function () {
            var newMail = [];
            $scope.selectedAll = false;
            angular.forEach($scope.mailList, function (selected) {
                if (selected.selected) {
                    console.log(!selected.selected);
                    newMail.push(selected);
                    $scope.List = newMail;
                }
            });
            $scope.deleteEmail($scope.List);
        };

        $scope.checkEmail = function ($event, id) {
            $event.stopPropagation();
        };


        $scope.deleteEmail = function (newMail) {
            var obj = {};
            obj.mailToBeDeleted = newMail;
            if (obj.mailToBeDeleted && obj.mailToBeDeleted.length > 0) {
                bootbox.confirm('Are you sure, you want to delete this Mail', function (r) {
                    if (r) {
                        dashboardService.deleteEmail().save(obj, function (response, err) {
                            if (response.code == 200) {
                                toastr.success(response.message);
                                $scope.getMails();
                            } else {
                                toastr.error('Something went wrong, please try again later.');
                            }
                        });
                    }
                })
            }
            else {
                bootbox.alert('Please select mail to delete.');
            }
        }
        $scope.toggleMailCheckbox = function () {
            if ($scope.selectedAll) {
                $scope.selectedAll = true;
            } else {
                $scope.selectedAll = false;
            }
            angular.forEach($scope.mailList, function (item) {
                item.selected = $scope.selectedAll;
            });
        };

        $scope.getEmailMesssageListforAmbulance = function () {
            console.log("getEmailMesssageList");
            $scope.emailMessageData = dashboardService.getEmailMesssageListforAmbulance().get({}, function (response, err) {
                if (response.code == 200) {
                    console.log("res", response);

                    $scope.emailMessageData = response.data;
                } else {
                    $scope.emailMessageData = {};
                }
            });
        }
        $scope.getEmailMesssageById = function (id) {
            dashboardService.getEmailMesssageById(id).get({}, function (response) {
                $scope.mailData.mail_subject = '';
                $scope.mailData.mail_body = '';
                if (response.code == 200) {
                    $scope.mailData.mail_subject = response.data.subject;
                    $scope.mailData.mail_body = response.data.emailMsg;

                }
            });
        };
        $scope.getSmsTemplateById = function (id) {
            dashboardService.getSmsTemplateById(id).get({}, function (response) {
                $scope.SmsFrm = response.data;
                $scope.smsData.sms_message = '';
                if (response.code == 200) {
                    $scope.SmsFrm = response.data;
                    $scope.smsData.sms_message = response.data.smsMessage;

                }
            });
        };
        $scope.getSmsTemplateListforAmbulance = function () {
            console.log("getEmailMesssageList");
            $scope.smsTemplateData = dashboardService.getSmsTemplateListforAmbulance().get({}, function (response, err) {
                if (response.code == 200) {
                    console.log("res", response);

                    $scope.smsTemplateData = response.data;
                } else {
                    $scope.smsTemplateData = {};
                }
            });
        }
        $scope.viewMissedCall = function () {
            $uibModal.open({
                templateUrl: '/ambulance/modules/dashboard/views/viewVideoCall.html',
                size: "lg",
                controller: function ($scope, $uibModalInstance) {
                    $scope.getMissedVideoCallList = function () {
                        dashboardService.getMissedVideoCallList().get({}, function (response, err) {
                            if (response.code == 200) {
                                console.log("response---------viewMissedCall--", response.data);
                                $scope.callList = response.data;

                            } else {
                                $scope.callList = {};
                            }
                        });
                        $scope.cancel = function () {
                            $uibModalInstance.dismiss('cancel');
                        };
                    }
                    $scope.deleteMissedCall = function (Id) {
                        bootbox.confirm('Are you sure, you want to delete this missed call', function (r) {
                            if (r) {
                                dashboardService.deleteMissedCall(Id).get({}, function (response, err) {
                                    if (response.code == 200) {
                                        toastr.success(response.message);
                                        $scope.getMissedVideoCallList();
                                    } else {
                                        toastr.error('Something went wrong, please try again later.');
                                    }
                                });
                            }
                        })

                    }
                    $scope.markAsReadMissedCall = function (id) {
                        dashboardService.markAsReadMissedCall(id).get({}, function (response) {
                            if (response.code == 200) {
                                $scope.getMissedVideoCallList();
                            }
                        });
                    }
                }
            });
        };

    }
]);
