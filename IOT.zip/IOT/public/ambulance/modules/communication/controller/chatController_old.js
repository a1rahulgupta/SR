"use strict";

angular.module('Chat')
    .controller("chatController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', 'ChatService', 'toastr', '$uibModal', 'ngTableParams', 'ngTableParamsService',
        function ($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, ChatService, toastr, $uibModal, ngTableParams, ngTableParamsService) {
            $scope.chatForm = {};
            var tc = {};
            var $statusRow;
            var $channelList;
            var $inputText;
            var $usernameInput;
            var $statusRow;
            var $connectPanel;
            var $newChannelInputRow;
            var $newChannelInput;
            var $typingRow;
            var $typingPlaceholder;
            var GENERAL_CHANNEL_UNIQUE_NAME = 'general';
            var GENERAL_CHANNEL_NAME = 'General Channel';
            var MESSAGES_HISTORY_LIMIT = 50;
            $(document).ready(function () {
                tc.$messageList = $('#message-list');
                $channelList = $('#channel-list');
                $inputText = $('#input-text');
                $usernameInput = $('#username-input');
                $statusRow = $('#status-row');
                $connectPanel = $('#connect-panel');
                $newChannelInputRow = $('#new-channel-input-row');
                $newChannelInput = $('#new-channel-input');
                $typingRow = $('#typing-row');
                $typingPlaceholder = $('#typing-placeholder');
                $usernameInput.focus();
                // $usernameInput.on('keypress', handleUsernameInputKeypress);
                // $inputText.on('keypress', handleInputTextKeypress);
                // $newChannelInput.on('keypress', tc.handleNewChannelInputKeypress);
                $('#connect-image').on('click', connectClientWithUsername);
                // $('#add-channel-image').on('click', showAddChannelInput);
                // $('#leave-span').on('click', disconnectClient);
                // $('#delete-channel-span').on('click', deleteCurrentChannel);
            });


            function connectClientWithUsername() {
                var usernameText = $usernameInput.val();
                $usernameInput.val('');
                if (usernameText == '') {
                    alert('Username cannot be empty');
                    return;
                }
                tc.username = usernameText;
                fetchAccessToken(tc.username, connectMessagingClient);
            }
            function connectMessagingClient(token) {
                // Initialize the IP messaging client
                tc.messagingClient = new Twilio.Chat.Client(token);
                tc.messagingClient.initialize()
                    .then(function () {
                        updateConnectedUI();
                        tc.loadChannelList(tc.joinGeneralChannel);
                        // tc.messagingClient.on('channelAdded', $.throttle(tc.loadChannelList));
                        // tc.messagingClient.on('channelRemoved', $.throttle(tc.loadChannelList));
                        tc.messagingClient.on('tokenExpired', refreshToken);
                    });
            }

            function fetchAccessToken(username, handler) {
                console.log("fetchAccessToken------->>>", username);
                ChatService.sendMessage().save({ identity: username, device: 'browser' }, function (response) {
                    console.log("response", response);
                    handler(response.token);
                })
            }
            function refreshToken() {
                fetch(tc.username, setNewToken);
            }

            function updateConnectedUI() {
                $('#username-span').text(tc.username);
                $statusRow.addClass('connected').removeClass('disconnected');
                tc.$messageList.addClass('connected').removeClass('disconnected');
                $connectPanel.addClass('connected').removeClass('disconnected');
                $inputText.addClass('with-shadow');
                $typingRow.addClass('connected').removeClass('disconnected');
            }

            tc.loadChannelList = function (handler) {
                if (tc.messagingClient === undefined) {
                    console.log('Client is not initialized');
                    return;
                }

                tc.messagingClient.getPublicChannels().then(function (channels) {
                    tc.channelArray = tc.sortChannelsByName(channels.items);
                    $channelList.text('');
                    tc.channelArray.forEach(addChannel);
                    if (typeof handler === 'function') {
                        handler();
                    }
                });
            };


            tc.joinGeneralChannel = function () {
                console.log('Attempting to join "general" chat channel...');
                if (!tc.generalChannel) {
                    // If it doesn't exist, let's create it
                    tc.messagingClient.createChannel({
                        uniqueName: GENERAL_CHANNEL_UNIQUE_NAME,
                        friendlyName: GENERAL_CHANNEL_NAME
                    }).then(function (channel) {
                        console.log('Created general channel');
                        tc.generalChannel = channel;
                        tc.loadChannelList(tc.joinGeneralChannel);
                    });
                }
                else {
                    console.log('Found general channel:');
                    setupChannel(tc.generalChannel);
                }
            };


            // $scope.sendMessage = function () {
            //     console.log("sendMessage", $scope.chatForm.message);
            //     var message = $scope.chatForm.message;
            //     tc.username = message;
            //     console.log("response---->>>>", tc.username);
            //     ChatService.sendMessage().save({ identity: message, device: 'browser' }, function (response) {
            //         console.log("response", response);
            //         if (response.code == 200) {
            //             // $scope.chat = response.data;
            //             console.log("response", response);
            //             $scope.connectMessagingClient(response.token);

            //         } else {
            //             $scope.chatForm = {};
            //         }
            //     });
            // };

            // $scope.connectMessagingClient = function (token) {
            //     console.log("token---111--25-->>>", token);
            //     tc.messagingClient = new Twilio.Chat.Client(token);
            //     console.log("token----564-222-->>>", tc.messagingClient);
            //     tc.messagingClient.initialize().then(function () {
            //         console.log("token-----333-->>>");
            //         $scope.updateConnectedUI();
            //         tc.loadChannelList(tc.joinGeneralChannel);
            //         // tc.messagingClient.on('channelAdded', $.throttle(tc.loadChannelList));
            //         // tc.messagingClient.on('channelRemoved', $.throttle(tc.loadChannelList));
            //         // tc.messagingClient.on('tokenExpired', refreshToken);
            //     });
            // }

            tc.sortChannelsByName = function (channels) {
                return channels.sort(function (a, b) {
                    if (a.friendlyName === GENERAL_CHANNEL_NAME) {
                        return -1;
                    }
                    if (b.friendlyName === GENERAL_CHANNEL_NAME) {
                        return 1;
                    }
                    return a.friendlyName.localeCompare(b.friendlyName);
                });
            };

            function addChannel(channel) {
                if (channel.uniqueName === GENERAL_CHANNEL_UNIQUE_NAME) {
                    tc.generalChannel = channel;
                }
                // var rowDiv = $('<div>').addClass('row channel-row');
                // rowDiv.loadTemplate('#channel-template', {
                //     channelName: channel.friendlyName
                // });

                var channelP = rowDiv.children().children().first();

                rowDiv.on('click', selectChannel);
                channelP.data('sid', channel.sid);
                if (tc.currentChannel && channel.sid === tc.currentChannel.sid) {
                    tc.currentChannelContainer = channelP;
                    channelP.addClass('selected-channel');
                }
                else {
                    channelP.addClass('unselected-channel')
                }

                $channelList.append(rowDiv);
            }

            function deleteCurrentChannel() {
                if (!tc.currentChannel) {
                    return;
                }

                if (tc.currentChannel.sid === tc.generalChannel.sid) {
                    alert('You cannot delete the general channel');
                    return;
                }

                tc.currentChannel
                    .delete()
                    .then(function (channel) {
                        console.log('channel: ' + channel.friendlyName + ' deleted');
                        setupChannel(tc.generalChannel);
                    });
            }

            function selectChannel(event) {
                var target = $(event.target);
                var channelSid = target.data().sid;
                var selectedChannel = tc.channelArray.filter(function (channel) {
                    return channel.sid === channelSid;
                })[0];
                if (selectedChannel === tc.currentChannel) {
                    return;
                }
                setupChannel(selectedChannel);
            };

            function disconnectClient() {
                leaveCurrentChannel();
                $channelList.text('');
                tc.$messageList.text('');
                channels = undefined;
                $statusRow.addClass('disconnected').removeClass('connected');
                tc.$messageList.addClass('disconnected').removeClass('connected');
                $connectPanel.addClass('disconnected').removeClass('connected');
                $inputText.removeClass('with-shadow');
                $typingRow.addClass('disconnected').removeClass('connected');
            }

            tc.sortChannelsByName = function (channels) {
                return channels.sort(function (a, b) {
                    if (a.friendlyName === GENERAL_CHANNEL_NAME) {
                        return -1;
                    }
                    if (b.friendlyName === GENERAL_CHANNEL_NAME) {
                        return 1;
                    }
                    return a.friendlyName.localeCompare(b.friendlyName);
                });
            };

            tc.addMessageToList = function (message) {
                var rowDiv = $('<div>').addClass('row no-margin');
                rowDiv.loadTemplate($('#message-template'), {
                    username: message.author,
                    date: dateFormatter.getTodayDate(message.timestamp),
                    body: message.body
                });
                if (message.author === tc.username) {
                    rowDiv.addClass('own-message');
                }

                tc.$messageList.append(rowDiv);
                scrollToMessageListBottom();
            };

            function notifyMemberJoined(member) {
                notify(member.identity + ' joined the channel')
            }

            function notifyMemberLeft(member) {
                notify(member.identity + ' left the channel');
            }

            function notify(message) {
                var row = $('<div>').addClass('col-md-12');
                row.loadTemplate('#member-notification-template', {
                    status: message
                });
                tc.$messageList.append(row);
                scrollToMessageListBottom();
            }


            tc.joinGeneralChannel = function () {
                console.log('Attempting to join "general" chat channel...');
                if (!tc.generalChannel) {
                    // If it doesn't exist, let's create it
                    tc.messagingClient.createChannel({
                        uniqueName: GENERAL_CHANNEL_UNIQUE_NAME,
                        friendlyName: GENERAL_CHANNEL_NAME
                    }).then(function (channel) {
                        console.log('Created general channel');
                        tc.generalChannel = channel;
                        tc.loadChannelList(tc.joinGeneralChannel);
                    });
                }
                else {
                    console.log('Found general channel:');
                    setupChannel(tc.generalChannel);
                }
            };



            // $scope.updateConnectedUI = function () {
            //     $scope.username = tc.username;
            //     console.log("token-----333//////////////-->>>", $scope.username);
            //     console.log("token-----333//////////////-->>>", $statusRow);

            //     $statusRow.addClass('connected').removeClass('disconnected');
            //     tc.$messageList.addClass('connected').removeClass('disconnected');
            //     $connectPanel.addClass('connected').removeClass('disconnected');
            //     $inputText.addClass('with-shadow');
            //     $typingRow.addClass('connected').removeClass('disconnected');
            // }



        }
    ]);
