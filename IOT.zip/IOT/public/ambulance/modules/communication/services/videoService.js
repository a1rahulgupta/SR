"use strict"

angular.module("videoChat")

    .factory('videoService', ['$http', '$resource', function ($http, $resource) {
  
            var getAllEntitiesLinkedToAmbulance = function () {
            return $resource('/api/v1/getAllEntitiesLinkedToAmbulance', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var acceptCall = function () {
            return $resource('/api/v1/acceptCall', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        var rejectCall = function () {
            return $resource('/api/v1/rejectCall', null, {
                save: {
                    method: 'POST'
                }
            });
        }
        return {
            getAllEntitiesLinkedToAmbulance: getAllEntitiesLinkedToAmbulance,
            acceptCall:acceptCall,
            rejectCall:rejectCall
        }


    }]);