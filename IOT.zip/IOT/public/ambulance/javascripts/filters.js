'use strict';
/* 
 * @purpose  : filter to provide date in "11:25 am December 22nd" format
 */
iotiedApp.filter('measureTypeWithings', function($filter) {
    /*var suffixes = ["th", "st", "nd", "rd"];
    return function(input) {
        if (input !== undefined) {
            var dtfilter = $filter('date')(input, 'MMMM d');
            var timfilter = $filter('date')(input, 'h:mm a');
            var day = parseInt(dtfilter.slice(-2));
            var relevantDigits = (day < 30) ? day % 20 : day % 30;
            var suffix = (relevantDigits <= 3) ? suffixes[relevantDigits] : suffixes[0];
            return timfilter +', '+ dtfilter + suffix;
        } else {
            return '';
        }
    };*/
    var types = [
        '1':'Weight (kg)',
        '4':'Height (meter)',
        '5':'Fat Free Mass (kg)',
        '6':'Fat Ratio (%)',
        '8':'Fat Mass Weight (kg)',
        '9':'Diastolic Blood Pressure (mmHg)',
        '10':'Systolic Blood Pressure (mmHg)'
        '11':'Heart Pulse (bpm)',
        '12':'Temperature',
        '54':'SP02(%)',
        '71':'Body Temperature',
        '73':'Skin Temperature',
        '76':'Muscle Mass',
        '77':'Hydration',
        '88':'Bone Mass',
        '91': 'Pulse Wave Velocity'
    ];
    return function(input) {
        console.log(input);
        /*if (input !== undefined) {
            var dtfilter = $filter('date')(input, 'MMMM d');
            var timfilter = $filter('date')(input, 'h:mm a');
            var day = parseInt(dtfilter.slice(-2));
            var relevantDigits = (day < 30) ? day % 20 : day % 30;
            var suffix = (relevantDigits <= 3) ? suffixes[relevantDigits] : suffixes[0];
            return timfilter +', '+ dtfilter + suffix;
        } else {
            return '';
        }*/
    };
});