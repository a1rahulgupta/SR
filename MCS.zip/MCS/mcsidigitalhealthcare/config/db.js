'use strict';

var mongoose = require('mongoose');

/* DB */
require('../api/models/users');
require('../api/models/status');
require('../api/models/disease');
require('../api/models/roles');
require('../api/models/auditLog');
require('../api/models/permissions');
require('../api/models/patient');
require('../api/models/survey');
require('../api/models/visitsurvey');
require('../api/models/visitInfo');
require('../api/models/triage');
require('../api/models/patientTest');
require('../api/models/orders');
require('../api/models/inventory');
require('../api/models/triagePatientTest');
require('../api/models/kupatCholim');
require('../api/models/visitStage');
require('../api/models/reportHistory');
require('../api/models/alert');
require('../api/models/visitPayment');
require('../api/models/setting');
require('../api/models/allergy');
require('../api/models/citi');
require('../api/models/externalOrder');


// staging database if upload stagging

// var uri = 'mongodb://localhost/mcsidigitalhealhc';
// var options = {
// 	user: 'mcsidigitalhealhc',
// 	pass: 'mcsidigitalhealhc@!!2'
// }

// staging database
// var uri = 'mongodb://52.34.207.5/mcsidigitalhealhc';
// var options = {
// 	user: 'mcsidigitalhealhc',
// 	pass: 'mcsidigitalhealhc@!!2'
// }

// local database

// var uri = 'mongodb://172.10.1.7:27017/rahulgupta';
// var options = {
// 	user: 'rahulgupta',
// 	pass: 'rahulgupta2017'
// }

// Harshul's local database

// var uri = 'mongodb://localhost:27017/health_db';
// var options = {
// 	user: 'harshulyadav',
// 	pass: 'harshulyadav@123'

// staging database if upload stagging

// var uri = 'mongodb://localhost/mcsidigitalhealhc';
// var options = {
// 	user: 'mcsidigitalhealhc',
// 	pass: 'mcsidigitalhealhc@!!2'
// }

// staging database for local

// var uri = 'mongodb://52.34.207.5:27017/mcsidigitalhealhc';
// var options = {
// 	user: 'mcsidigitalhealhc',
//   	pass: 'mcsidigitalhealhc@!!2'
// }

// lacal database

var uri = 'mongodb://172.10.1.7:27017/rahulgupta';
var options = {
	user: 'rahulgupta',
	pass: 'rahulgupta2017'

}


mongoose.connect(uri, options);
mongoose.Promise = global.Promise;
var db = mongoose.connection;
//mongoose.set('debug', true);
db.on('error', console.error.bind(console, 'database connection error:'));
db.once('open', function (callback) {
	console.log('Database connection successful!');
});





//var uri = 'ds159998.mlab.com:59998';
//mongoose.connect("mongodb://localhost:27017/MCSI_Healthcare");
// mongoose.connect("mongodb://rahulgupta:rahulgupta2017@172.10.1.7:27017/rahulgupta");
// // mongoose.connect('mongodb://mcsidigital:mgh%232ew90@localhost:52189/mcsidigital');
// mongoose.Promise = global.Promise;
// var db = mongoose.connection;
// db.on('error', console.error.bind(console, "connection failed"));
// db.once('open', function() {
//     console.log("Database conencted successfully!");
// });
// mongoose.set('debug', true);

/* end DB */

// U/P :  mcsidigital/D@Fde@3e3

// DB : mcsidigital

// Mongo port : 57170