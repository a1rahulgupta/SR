'use strict';
module.exports = {
    SECRET: 'crm@$12&*01',
    SALTKEY: '$2a$10$8NNrP7ODP9DGWtcW37DSWO',
    // webUrl: 'https://localhost:5055',
    webUrl: 'http://172.10.220.65:5040',
    // webUrl: 'http://52.34.207.5:5054',
    //DIR_NAME: '/app',
    SMTP: {
        service: 'gmail',
        host: 'smtp.gmail.com',
        secure: true,
        port: 465,
        auth: {
            user: 'techteamsdn@gmail.com',
            pass: 'tech@sdn'
        }
    },
    EMAIL_FROM: '"Tech Group" <techteamsdn@gmail.com>',
    EMAIL_BCC: '"LexHelper" <techteamsdn@gmail.com>',
    //EMAIL_TEMP : 'stephanie.daniels@lexhelper.com, support2@lexhelper.com',
    EMAIL_TEMP: 'techteamsdn@gmail.com'


};