'use strict';

var mongoose = require('mongoose'),
constantsObj = require('./../../constants');
var Schema = mongoose.Schema;

var ExternalOrderSchema = new mongoose.Schema({
	drugName: { type: String},
}, {
    timestamps: true
});

var ExternalOrder = mongoose.model('ExternalOrder', ExternalOrderSchema);
module.exports = ExternalOrder;
    
