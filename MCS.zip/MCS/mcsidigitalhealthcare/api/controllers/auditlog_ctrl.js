'use strict';

var mongoose = require('mongoose'),
    AuditLog = mongoose.model('AuditLog');

module.exports = {
    addAuditLog: addAuditLog
};

/**
 * Function is use to Patient 
 * @access private
 * @return json
 * Created by Swapnali
 * @smartData Enterprises (I) Ltd
 * Created Date 20-April-2017
 */
function addAuditLog(entityname, actionBy, actionName, actionSubName, modifiedDetails) {
    return new Promise(function (resolve, reject) {
        new AuditLog({
            entityname: entityname,
            actionBy: actionBy,
            actionName: actionName,
            actionSubName: actionSubName,
            modifiedDetails: modifiedDetails,
        }).save(function (err, auditLog) {
            if (err) {
                reject(err);
            }
            else {
                resolve(auditLog);
            }
        });
    });
}