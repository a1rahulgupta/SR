

module.exports = function(grunt) {

 var projectjsfile = [
    'public/javascripts/app.js',
    'public/javascripts/communication.js',
    'public/javascripts/directives/directives.js',
    'public/javascripts/constants.js',
    'public/modules/authentication/controller.js',
    'public/modules/authentication/service.js',
    'public/javascripts/ngTableParamsService.js',
    'public/javascripts/loggerServices.js',
    'public/modules/home/controller.js',
    'public/modules/home/homeService.js',
    'public/modules/users/controller.js',
    'public/modules/users/service.js',
    'public/modules/roles/service.js',
    'public/modules/roles/controller.js',
    'public/modules/disease/controller.js',
    'public/modules/disease/service.js',
    'public/modules/survey/controller.js',
    'public/modules/survey/service.js',
    'public/modules/patient/controller.js',
    'public/modules/patient/service.js',
    'public/modules/inventory/controller.js',
    'public/modules/inventory/service.js',
    'public/modules/kupatCholim/controller.js',
    'public/modules/kupatCholim/service.js',
    'public/modules/reports/controller.js',
    'public/modules/reports/service.js'
 ];    

    // Project configuration.
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        jshint: {
            all: ['app.js', 'server/**/*.js']
        },
        watch: {
            scripts: {
                files: projectjsfile,
                tasks: ['concat','uglify'],
                options: {
                    livereload: true,
                    spawn: false,
                },
            }
        },
        nodemon: {
            dev: {
                script: './bin/www',
                tasks: ['watch']
            }
        },
        concat: {
            options: {
                separator: '\n;\n\n'
            },
           dist: {
               src: [
                     "public/assets/js/socket.io.js",
                    "public/assets/js/ng-tags-input.min.js",
                    "public/assets/js/angular-strap.js",
                    "public/assets/js/angular-strap.tpl.js",
                    "public/assets/js/bootstrap.min.js",
                    "public/assets/js/web-notification.js",
                    "public/assets/js/angular-web-notification.js",
                    "public/assets/js/ui-bootstrap-tpls.js",
                    "public/bower_components/angular-ui-router/release/angular-ui-router.min.js",
                    "public/assets/js/angular-route.min.js",
                    "public/assets/js/logger.min.js",
                    "public/assets/js/bootbox.min.js",
                    "public/assets/js/ngStorage.min.js",
                    "public/assets/js/ng-table.min.js",
                    "public/bower_components/angular-resource/angular-resource.min.js",
                    "public/bower_components/angularUtils-pagination/dirPagination.js",
                    "public/assets/fancybook/jquery.fancybox.pack.js?v=2.1.6",
                    "public/assets/js/jquery.raty.js",
                    "public/assets/js/angucomplete-alt.min.js",
                    "public/assets/js/isteven-multi-select.min.js",
                    "public/assets/js/ng-img-crop.js",
                    "public/assets/js/ng-file-upload.min.js",
                    "public/assets/js/moment.min.js",
                    "public/assets/js/daterangepicker.min.js",
                    "public/assets/js/ui-grid-unstable.js",
                    "public/assets/js/angular-translate.min.js",
                    "public/assets/js/PascalPrecht_angular-translate.min.js",
                    "public/assets/js/angular-translate-loader-static-files.min.js",
                    "public/assets/js/ocLazyLoad.require.min.js",
                    "public/assets/js/ocLazyLoad.min.js",
                    "public/assets/js/bootstrap-colorpicker-module.min.js",
                    "public/assets/js/hotkeys.js"
               ],
               dest: 'public/gruntFile/user/distLib.js',
           }
        },
        uglify: {
            options: {
                mangle: false
            },
            build: {
                files: {
                    'public/gruntFile/user/built.js': projectjsfile
                }
            }
        },
    });
    // loading tasks modules
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-contrib-jshint');
    grunt.loadNpmTasks('grunt-nodemon');
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-minified');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-concat-css');
    grunt.loadNpmTasks('grunt-stripcomments');
    //grunt.loadNpmTasks('grunt-clean');
    // registerTask
    grunt.registerTask("default", ["nodemon:dev"]);
    grunt.registerTask("con", ["concat", "uglify"]);
   // grunt.registerTask("ugly", ["uglify"]);
};
