"use strict";
angular.module("Authentication", []), angular.module("Users", []), angular.module("Home", []), angular.module("communicationModule", []), angular.module("Roles", []), angular.module("Disease", []), angular.module("Survey", []), angular.module("Patients", []), angular.module("Inventory", []), angular.module("Kupat", []), angular.module("Reports", []);
var MCSIApp = angular.module("MCSIApp", ["ui.router", "ui.bootstrap", "oc.lazyLoad", "ngRoute", "ngStorage", "ngTable", "ngResource", "Authentication", "communicationModule", "Users", "Home", "Disease", "Survey", "Kupat", "Patients", "Inventory", "Roles", "Reports", "ui.bootstrap", "ui.tinymce", "angularUtils.directives.dirPagination", "isteven-multi-select", "ngTagsInput", "angucomplete-alt", "pascalprecht.translate", "ngFileUpload", "ngImgCrop", "ui.grid", "ui.grid.selection", "ui.grid.exporter", "ui.grid.moveColumns", "ui.grid.pagination", "colorpicker.module", "cfp.hotkeys", "angular-web-notification"]).factory("CommonService", ["$http", "$resource", "$rootScope", function ($http, $resource, $rootScope) {
    var user = {},
        getUser = function () {
            return user
        },
        setUser = function (userData) {
            user = "", user = userData
        };
    return {
        getUser: getUser,
        setUser: setUser
    }
}]).factory("socket", function ($rootScope, $window) {
    var socket = io.connect("http://localhost:5040");
    return socket.on("connect", function () {
        socket.io.engine.id;
        void 0 !== $window.sessionStorage.userId && socket.emit("join", $window.sessionStorage.userId)
    }), {
        on: function (eventName, callback) {
            socket.on(eventName, function () {
                var args = arguments;
                $rootScope.$apply(function () {
                    callback.apply(socket, args)
                })
            })
        },
        emit: function (eventName, data, callback) {
            socket.emit(eventName, data, function () {
                var args = arguments;
                $rootScope.$apply(function () {
                    callback && callback.apply(socket, args)
                })
            })
        }
    }
}).config(["$routeProvider", "$httpProvider", "$locationProvider", "$stateProvider", "$urlRouterProvider", "$translateProvider", "$windowProvider", function ($routeProvider, $httpProvider, $locationProvider, $stateProvider, $urlRouterProvider, $translateProvider, $windowProvider) {
    $windowProvider.$get();
    $httpProvider.interceptors.push(function ($q, $location, $localStorage, $window) {
        return {
            request: function (config) {
                config.headers = config.headers || {};
                var token = $window.sessionStorage.getItem("token");
                return config.headers.authorization = "bearer " + token, config.headers["client-type"] = "browser", config
            },
            response: function (response) {
                return 401 == response.data.code && ($window.sessionStorage.setItem("token", ""), $location.path().indexOf("/showSurvey") < 0 && "/changePassword" != $location.path() && $location.path("/signIn")), response || $q.when(response)
            }
        }
    });
    var checkLoggedin = function ($q, $timeout, $http, $location, $rootScope, $state, CommonService) {
            var deferred = $q.defer();
            return $http.get("/api/loggedin").success(function (response) {
                var user = response.user;
                "OK" == response.status ? (CommonService.setUser(user), $state.go("dashboard")) : $timeout(function () {
                    deferred.resolve()
                }, 0)
            }).error(function (error) {
                $timeout(function () {
                    deferred.resolve()
                }, 0)
            }), deferred.promise
        },
        checkLoggedout = function () {
            return ["$q", "$timeout", "$http", "$location", "$rootScope", "$state", "CommonService", function ($q, $timeout, $http, $location, $rootScope, $state, CommonService) {
                var deferred = $q.defer();
                return $http.get("/api/loggedin").success(function (response) {
                    if ("OK" == response.status) {
                        var user = response.user;
                        CommonService.setUser(user), $timeout(deferred.resolve, 0)
                    } else $timeout(function () {
                        deferred.resolve()
                    }, 0), $rootScope.isSpecificPage = !0, $state.go("signIn")
                }).error(function (error) {
                    $timeout(function () {
                        deferred.resolve()
                    }, 0), $rootScope.isSpecificPage = !0, $state.go("signIn")
                }), deferred.promise
            }]
        };
    $translateProvider.preferredLanguage("en"), $translateProvider.fallbackLanguage("hw"), $translateProvider.useStaticFilesLoader({
        prefix: "lang_",
        suffix: ".json"
    }), $urlRouterProvider.otherwise("/dashboard"), $stateProvider.state("signIn", {
        url: "/signIn",
        views: {
            content: {
                templateUrl: "/modules/authentication/views/signin.html",
                controller: "loginController"
            }
        },
        data: {
            isAuthenticate: !1
        },
        resolve: {
            loggedin: checkLoggedin,
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/authentication/controller.js", "/modules/authentication/service.js"])
            }
        }
    }).state("verifying_link", {
        url: "/verifying-link",
        views: {
            content: {
                templateUrl: "/modules/home/views/verifying_link.html",
                controller: "homeController"
            }
        },
        data: {},
        resolve: {
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/home/controller.js", "/modules/home/homeService.js"])
            }
        }
    }).state("forgot_password", {
        url: "/forgot-password",
        views: {
            content: {
                templateUrl: "/modules/authentication/views/forgot-password.html",
                controller: "loginController"
            }
        },
        data: {},
        resolve: {
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/authentication/controller.js", "/modules/authentication/service.js"])
            }
        }
    }).state("terms&condition", {
        url: "/terms-and-condition",
        views: {
            content: {
                templateUrl: "/modules/home/views/terms-and-condition.html",
                controller: "homeController"
            }
        },
        data: {},
        resolve: {
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/home/controller.js", "/modules/home/homeService.js"])
            }
        }
    }).state("privacy", {
        url: "/privacy",
        views: {
            content: {
                templateUrl: "/modules/home/views/privacy.html",
                controller: "homeController"
            }
        },
        data: {},
        resolve: {
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/home/controller.js", "/modules/home/homeService.js"])
            }
        }
    }).state("dashboard", {
        url: "/dashboard",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/home/views/dashboard.html",
                controller: "homeController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/home/controller.js", "/modules/home/homeService.js"])
            }
        }
    }).state("familyDoctors", {
        url: "/dashboard/familyDoctors",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/users/views/FamilyDoc_list.html",
                controller: "userController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/users/controller.js", "/modules/users/service.js"])
            }
        }
    }).state("add_family_Doctors", {
        url: "/dashboard/add_family_Doctors/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/users/views/add_family_doctors.html",
                controller: "userController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/users/controller.js", "/modules/users/service.js"])
            }
        }
    }).state("users", {
        url: "/dashboard/userlist",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/users/views/add_user_list.html",
                controller: "userController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/users/controller.js", "/modules/users/service.js"])
            }
        }
    }).state("addUser", {
        url: "/dashboard/userlist/adduser/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/users/views/add_user.html",
                controller: "userController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/users/controller.js", "/modules/users/service.js"])
            }
        }
    }).state("users_edit", {
        url: "/user-edit/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/users/views/add_user.html",
                controller: "userController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/users/controller.js", "/modules/users/service.js"])
            }
        }
    }).state("myprofile", {
        url: "/myprofile",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/users/views/profileD.html",
                controller: "userController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/users/controller.js", "/modules/users/service.js"])
            }
        }
    }).state("index_add", {
        url: "/dashboard/addIndex",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/disease/views/addIndex.html",
                controller: "diseaseController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/disease/controller.js", "/modules/disease/service.js"])
            }
        }
    }).state("index", {
        url: "/dashboard/indexList",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/disease/views/indexlist.html",
                controller: "diseaseController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/disease/controller.js", "/modules/disease/service.js"])
            }
        }
    }).state("add_disease", {
        url: "/dashboard/add_disease",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/disease/views/add_disease.html",
                controller: "diseaseController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/disease/controller.js", "/modules/disease/service.js"])
            }
        }
    }).state("Diseases", {
        url: "/dashboard/Currentdisease",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/disease/views/disease_list.html",
                controller: "diseaseController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/disease/controller.js", "/modules/disease/service.js"])
            }
        }
    }).state("Test", {
        url: "/dashboard/test/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            footer: {},
            content: {
                templateUrl: "/modules/disease/views/test.html",
                controller: "diseaseController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/disease/controller.js", "/modules/disease/service.js"])
            }
        }
    }).state("survey", {
        url: "/dashboard/survey",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/survey/views/addSurvey.html",
                controller: "surveyController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/survey/controller.js", "/modules/survey/service.js"])
            }
        }
    }).state("patientdashboard", {
        url: "/patientdashboard",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/patientDashboard.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("activePatient", {
        url: "/activePatient",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/activePatientList.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("patientList", {
        url: "/patientList",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/patientList.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("addPatient", {
        url: "/addPatient/:id/:showTopNav",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/addPatient.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("addIndexTriage", {
        url: "/dashboard/indexList/addIndexTriage",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/disease/views/add_index_triage.html",
                controller: "diseaseController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/disease/controller.js", "/modules/disease/service.js"])
            }
        }
    }).state("addIndexDisease", {
        url: "/dashboard/indexList/addIndexDisease",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/disease/views/add_index_disease.html",
                controller: "diseaseController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/disease/controller.js", "/modules/disease/service.js"])
            }
        }
    }).state("edit_disease", {
        url: "/indexList/editdisease/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/disease/views/edit_disease.html",
                controller: "diseaseController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/disease/controller.js", "/modules/disease/service.js"])
            }
        }
    }).state("edit_triage", {
        url: "/indexList/edittriage/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/disease/views/edit_triage.html",
                controller: "diseaseController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/disease/controller.js", "/modules/disease/service.js"])
            }
        }
    }).state("updatetest", {
        url: "/dashboard/updatetest/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/disease/views/updatetest.html",
                controller: "diseaseController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/disease/controller.js", "/modules/disease/service.js"])
            }
        }
    }).state("roles", {
        url: "/roles",
        title: "Role Listing",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/roles/views/index.html",
                controller: "roleController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/roles/controller.js", "/modules/roles/service.js"])
            }
        }
    }).state("addRole", {
        url: "/role/add",
        title: "Add Roles",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/roles/views/create.html",
                controller: "roleController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/roles/controller.js", "/modules/roles/service.js"])
            }
        }
    }).state("editRoles", {
        url: "/roles/edit/:id",
        title: "Edit Role",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/roles/views/edit.html",
                controller: "roleController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/roles/controller.js", "/modules/roles/service.js"])
            }
        }
    }).state("rolePermissions", {
        url: "/roles/permissions/:id",
        title: "Add Role",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/roles/views/permissions.html",
                controller: "roleController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/roles/controller.js", "/modules/roles/service.js"])
            }
        }
    }).state("addVisitReason", {
        url: "/visitReason/add",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/addVisitReason.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("addNewVisitReason", {
        url: "/addNewVisitReason/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/addNewVisitReason.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("editVisitReason", {
        url: "/visitReason-edit/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/addVisitReason.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("editPatientIdentification", {
        url: "/patientIdentification-edit/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/editPatient.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("editPayment", {
        url: "/payment-edit/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/payment.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("editNurseExam", {
        url: "/nurseExam-edit/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/nurseExam.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("visitDetails", {
        url: "/visitDetails-edit/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/visit_details.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("editDoctorExam", {
        url: "/doctorExam-edit/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/doctorExam.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("doctorSummary", {
        url: "/doctorSummary/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/doctorSummary.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("doctorResult", {
        url: "/doctorResult-edit/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/doctorResult.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("doctorPrescription", {
        url: "/prescription-edit/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/doctorPrescription.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("visitCard", {
        url: "/visitCard/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/visitCard.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("prescription", {
        url: "/prescription",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/prescription.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("inventoryList", {
        url: "/inventoryList",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/inventory/views/inventory_list.html",
                controller: "inventoryController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/inventory/controller.js", "/modules/inventory/service.js"])
            }
        }
    }).state("addDrug", {
        url: "/addDrug",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/inventory/views/addDrug.html",
                controller: "inventoryController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/inventory/controller.js", "/modules/inventory/service.js"])
            }
        }
    }).state("summary", {
        url: "/summary-edit/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/summary.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("visitDocument", {
        url: "/visitDocument/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/visitDocument.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("addkupatCholim", {
        url: "/dashboard/kupatCholim_list/addkupatCholim",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/kupatCholim/views/addkupatCholim.html",
                controller: "kupatCholimController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/kupatCholim/controller.js", "/modules/kupatCholim/service.js"])
            }
        }
    }).state("editKupatCholim", {
        url: "/dashboard/kupatCholim_list/editKupatCholim/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/kupatCholim/views/editkupatCholim.html",
                controller: "kupatCholimController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/kupatCholim/controller.js", "/modules/kupatCholim/service.js"])
            }
        }
    }).state("kupatCholim_list", {
        url: "/dashboard/kupatCholim_list",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/kupatCholim/views/kupatCholim_list.html",
                controller: "kupatCholimController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/kupatCholim/controller.js", "/modules/kupatCholim/service.js"])
            }
        }
    }).state("patientVisitHistory", {
        url: "/patientVisitHistory/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/patientVisitHistoryList.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("visitHistory", {
        url: "/visitHistory",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/visitHistoryList.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("patientDrugListing", {
        url: "/patientDrugListing/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/patientDrugListing.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("visitcomment", {
        url: "/visitcomment/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/comment.html",
                controller: "patientController"
            }
        }
    }).state("reportDashboard", {
        url: "/reportDashboard",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/reports/views/reportDashboard.html",
                controller: "reportController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/reports/controller.js", "/modules/reports/service.js"])
            }
        }
    }).state("visitorsResultReport", {
        url: "/visitResultReport",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/reports/views/visitResult_report.html",
                controller: "reportController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/reports/controller.js", "/modules/reports/service.js"])
            }
        }
    }).state("visitResultHistoryReport", {
        url: "/visitResultHistoryReport",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/reports/views/visitResult_history.html",
                controller: "reportController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/reports/controller.js", "/modules/reports/service.js"])
            }
        }
    }).state("currentDiseaseReport", {
        url: "/currentDiseaseReport",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/reports/views/currentDisease_report.html",
                controller: "reportController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/reports/controller.js", "/modules/reports/service.js"])
            }
        }
    }).state("currentDiseaseHistoryReport", {
        url: "/currentDiseaseHistoryReport",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/reports/views/currentDisease_history.html",
                controller: "reportController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/reports/controller.js", "/modules/reports/service.js"])
            }
        }
    }).state("invChangeReport", {
        url: "/invChangeReport",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/reports/views/invChange_report.html",
                controller: "reportController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/reports/controller.js", "/modules/reports/service.js"])
            }
        }
    }).state("invChangeHistoryReport", {
        url: "/invChangeHistoryReport",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/reports/views/invChange_history.html",
                controller: "reportController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/reports/controller.js", "/modules/reports/service.js"])
            }
        }
    }).state("drugsGiveAwayReport", {
        url: "/drugsGiveAwayReport",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/reports/views/drugsGiveAway_report.html",
                controller: "reportController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/reports/controller.js", "/modules/reports/service.js"])
            }
        }
    }).state("drugsGiveAwayHistoryReport", {
        url: "/drugsGiveAwayHistoryReport",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/reports/views/drugsGiveAway_history.html",
                controller: "reportController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/reports/controller.js", "/modules/reports/service.js"])
            }
        }
    }).state("kupatCholimReport", {
        url: "/kupatCholimReport",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/reports/views/kupatCholim_report.html",
                controller: "reportController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/reports/controller.js", "/modules/reports/service.js"])
            }
        }
    }).state("kupatCholimHistoryReport", {
        url: "/kupatCholimHistoryReport",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/reports/views/kupatCholim_history.html",
                controller: "reportController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/reports/controller.js", "/modules/reports/service.js"])
            }
        }
    }).state("status_edit", {
        url: "/status_edit/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/users/views/status_edit.html",
                controller: "userController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/users/controller.js", "/modules/users/service.js"])
            }
        }
    }).state("statuses", {
        url: "/dashboard/statuses",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/users/views/status-list.html",
                controller: "userController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/users/controller.js", "/modules/users/service.js"])
            }
        }
    }).state("patientDebt", {
        url: "/patientDebt",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/patientDebtList.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("showSurvey", {
        url: "/showSurvey/:id",
        views: {
            content: {
                templateUrl: "/modules/survey/views/emc_questionaire.html",
                controller: "surveyController"
            }
        }
    }).state("ipSettings", {
        url: "/dashboard/ipSettings",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/users/views/ipSettings.html",
                controller: "userController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/users/controller.js", "/modules/users/service.js"])
            }
        }
    }).state("doctorOrder", {
        url: "/doctorOrder/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/doctorOrder.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("doctorTreatment", {
        url: "/doctorTreatment-edit/:id",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/doctorTreatment.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout(),
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/patient/controller.js", "/modules/patient/service.js"])
            }
        }
    }).state("changePassword", {
        url: "/changePassword",
        views: {
            content: {
                templateUrl: "/modules/users/views/changepassword.html",
                controller: "userController"
            }
        },
        data: {},
        resolve: {
            loadPlugin: function ($ocLazyLoad) {
                return $ocLazyLoad.load(["/modules/users/controller.js", "/modules/users/service.js"])
            }
        }
    }).state("activePatientByDr", {
        url: "/activePatientByDr",
        views: {
            header: {
                templateUrl: "/modules/home/views/header.html"
            },
            leftBar: {
                templateUrl: "/modules/home/views/leftBar.html"
            },
            content: {
                templateUrl: "/modules/patient/views/activePatientListByDr.html",
                controller: "patientController"
            }
        },
        data: {
            isAuthenticate: !0
        },
        resolve: {
            loggedin: checkLoggedout()
        }
    })
}]).run(["$rootScope", "$location", "$http", "$localStorage", "$state", "$translate", "ngTableParamsService", "$window", function ($rootScope, $location, $http, $localStorage, $state, $translate, ngTableParamsService, $window) {
    $localStorage.lang && "hw" == $localStorage.lang ? $rootScope.toastBase = "toast-top-left" : $rootScope.toastBase = "toast-top-right", $rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState) {
        $rootScope.currentState = toState.name, $rootScope.$emit("start", !0);
        var isCssUnDefined = angular.isUndefined($localStorage.css);
        1 == isCssUnDefined ? ($rootScope.css = "main", $translate.use("en")) : $rootScope.css = $localStorage.css, $translate.use($localStorage.lang);
        var pages = ["/signIn", "/forgot-password", "/changePassword"];
        $rootScope.isSpecificPage = pages.indexOf(toState.url) > -1, $location.path().match("/showSurvey") && ($rootScope.isSpecificPage = !0), $rootScope.loggedInUser = $localStorage.loggedInUser, $rootScope.profileName = $localStorage.profileName, "worker" != fromState.name && ngTableParamsService.set("", "", "", "", "");
        var pagesNotNeedAuthentication = ["/showSurvey", "/changePassword", "/forgot-password"];
        pagesNotNeedAuthentication.indexOf(toState.url) < 0 && toState.data && (!$window.sessionStorage.token && toState.data.isAuthenticate ? $location.path("/signIn") : (toState.resolve || (toState.resolve = {}), toState.resolve.pauseStateChange = ["$q", function ($q) {
            var defer = $q.defer();
            return $http.get("/api/getUsersPermission").then(function (response) {
                response.data.data && 200 === response.data.code ? ($rootScope.permissionsArray = response.data.data.permissions, response.data.data.permissions && response.data.data.permissions.indexOf(toState.name) == -1 && "" != toState.name && ("patientdashboard" == toState.name ? "nurse" == $window.sessionStorage.role ? "activePatient" !== fromState.name ? $state.go("activePatient") : defer.reject() : "doctor" == $window.sessionStorage.role ? "activePatientByDr" !== fromState.name ? $state.go("activePatientByDr") : defer.reject() : "admin" !== $window.sessionStorage.role || "superAdmin" !== $window.sessionStorage.role ? "activePatient" !== fromState.name ? $state.go("activePatient") : defer.reject() : event.preventDefault() : event.preventDefault()), defer.resolve()) : (event.preventDefault(), defer.resolve())
            }), defer.promise
        }]))
    }), $rootScope.$on("$stateChangeSuccess", function (event, toState, toParams, fromState, fromParams) {
        $rootScope.$emit("stop", !0)
    }), $rootScope.$on("$stateChangeError", function (event, toState, toParams, fromState, fromParams, error) {
        $rootScope.$emit("stop", !0)
    })
}]).filter("capitalize", function () {
    return function (input) {
        return input ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : ""
    }
});
angular.module("communicationModule").factory("communicationService", ["$http", function ($http) {
    var service = {};
    return service.resultViaGet = function (serviceUrl, authenticationKey, headerString, callback) {
        void 0 != authenticationKey && ($http.defaults.headers.common.Authorization = "Basic " + authenticationKey), void 0 != headerString && (headerString = '{"ContentType":' + headerString + '"}'), $http.get(serviceUrl, headerString).then(function (response) {
            callback(response)
        }, function (response) {
            callback(response)
        })
    }, service.resultViaPost = function (serviceUrl, authenticationKey, headerString, postData, callback) {
        void 0 != headerString && (headerString = '{"ContentType":' + headerString + '"}'), $http.post(serviceUrl, postData).then(function (response) {
            callback(response)
        }, function (response) {
            callback(response)
        })
    }, service
}]), MCSIApp.directive("validPasswordC", function () {
    return {
        require: "ngModel",
        scope: {
            reference: "=validPasswordC"
        },
        link: function (scope, elm, attrs, ctrl) {
            ctrl.$parsers.unshift(function (viewValue, $scope) {
                var noMatch = viewValue != scope.reference;
                return ctrl.$setValidity("noMatch", !noMatch), noMatch ? noMatch : !noMatch
            }), scope.$watch("reference", function (value) {
                ctrl.$setValidity("noMatch", value === ctrl.$viewValue)
            })
        }
    }
}), MCSIApp.directive("raty", function () {
    return {
        restrict: "AE",
        link: function (scope, elem, attrs) {
            $(elem).raty({
                score: attrs.score,
                number: attrs.number,
                readOnly: attrs.readonly
            })
        }
    }
}), MCSIApp.filter("trust", ["$sce", function ($sce) {
    return function (htmlCode) {
        return $sce.trustAsHtml(htmlCode)
    }
}]), MCSIApp.directive("preloader", function () {
    return {
        restrict: "A",
        template: "",
        link: function (scope, elm, attrs) {
            $(elm).hide(), scope.$on("start", function () {
                elm.addClass("loading-spiner-holder"), $(elm).show()
            }), scope.$on("stop", function () {
                $(elm).hide()
            })
        }
    }
}), MCSIApp.directive("daterangepicker", function () {
    function link(scope, element, attrs) {
        element.daterangepicker({
            timePicker: !0,
            autoApply: !0,
            minDate: new Date,
            opens: "center",
            locale: {
                format: "DD/MM/YYYY hh:mm A"
            }
        })
    }
    return {
        require: "ngModel",
        link: link
    }
}), MCSIApp.directive("weekdaysrangepicker", function () {
    function link(scope, element, attrs) {
        element.daterangepicker({
            timePicker: !0,
            autoApply: !0,
            opens: "center",
            startDate: "Friday: 07:00 AM",
            endDate: "Sunday: 06:59 AM",
            locale: {
                format: "dddd: hh:mm A"
            }
        })
    }
    return {
        require: "ngModel",
        link: link
    }
}), MCSIApp.directive("toggleOffCanvas", [function () {
    return {
        restrict: "A",
        link: function (scope, ele) {
            return ele.on("click", function () {
                return $("#app").toggleClass("on-canvas")
            })
        }
    }
}]);
var baseUrl = location.protocol + "//" + location.hostname + (location.port ? ":" + location.port : "");
console.log("baseUrl:", baseUrl);
var webservices = {
        authenticate: baseUrl + "/api/userLogin",
        forgot_password: baseUrl + "/api/forgotPassword",
        logout: baseUrl + "/api/userLogOut",
        addDisease: baseUrl + "/disease/add",
        addUser: baseUrl + "/users/add",
        userList: baseUrl + "/users/list"
    },
    appConstants = {
        authorizationKey: "dGF4aTphcHBsaWNhdGlvbg=="
    },
    headerConstants = {
        json: "application/json"
    },
    pagingConstants = {
        defaultPageSize: 10,
        defaultPageNumber: 1
    },
    messagesConstants = {};
angular.module("Authentication"), MCSIApp.controller("loginController", ["$scope", "$rootScope", "$location", "$ocLazyLoad", "AuthenticationService", "$localStorage", "logger", "CommonService", "socket", "$window", function ($scope, $rootScope, $location, $ocLazyLoad, AuthenticationService, $localStorage, logger, CommonService, socket, $window) {
    $scope.user = {}, $scope.forgotPass = {}, $scope.isPasswordSent = !1, $scope.disabled = !1, $scope.loader = !1, $scope.login = function (form) {
        form.$valid && ($scope.disabled = !0, $scope.loader = !0, AuthenticationService.Login($scope.user, function (response) {
            $scope.disabled = !1, $scope.loader = !1, 200 == response.code ? (socket.emit("join"), $localStorage.userLoggedIn = !0, response.data && ($window.sessionStorage.setItem("token", response.data.token), $window.sessionStorage.setItem("userId", response.data._id), $localStorage.loggedInUser = response.data.full, $localStorage.profileName = response.data.profileName), socket.emit("join", $window.sessionStorage.userId), CommonService.setUser(response.data), response.data.role_id && response.data.role_id.name ? "nurse" == response.data.role_id.name ? ($location.path("/activePatient"), $window.sessionStorage.setItem("role", response.data.role_id.name)) : "doctor" == response.data.role_id.name ? ($location.path("/activePatientByDr"), $window.sessionStorage.setItem("role", response.data.role_id.name)) : $location.path("/dashboard") : $location.path("/dashboard")) : logger.logError(response.message)
        }))
    }, $scope.logout = function () {
        AuthenticationService.logout($scope.user, function (response) {
            200 == response.code ? (socket.emit("leave"), $window.sessionStorage.setItem("token", ""), $window.sessionStorage.setItem("userId", ""), delete $localStorage.loggedInUser, delete $localStorage.profileName, delete $localStorage.lang, delete $localStorage.css, $rootScope.userLoggedIn = !1, logger.logSuccess(response.message), $location.path("/signIn")) : logger.logError(response.message)
        })
    }, $scope.resendPassword = function (form) {
        form.$valid && ($scope.disabled = !0, $scope.loader = !0, AuthenticationService.resendPassword($scope.forgotPass, function (response) {
            $scope.disabled = !1, $scope.loader = !1, 200 == response.code ? ($scope.isPasswordSent = !0, logger.logSuccess(response.message)) : logger.logError(response.message)
        }))
    }
}]), angular.module("Authentication").factory("AuthenticationService", ["communicationService", "$rootScope", function (communicationService, $rootScope) {
    var service = {};
    return service.Login = function (inputJsonString, callback) {
        communicationService.resultViaPost(webservices.authenticate, appConstants.authorizationKey, headerConstants.json, inputJsonString, function (response) {
            callback(response.data)
        })
    }, service.resendPassword = function (inputJsonString, callback) {
        communicationService.resultViaPost(webservices.forgot_password, appConstants.authorizationKey, headerConstants.json, inputJsonString, function (response) {
            callback(response.data)
        })
    }, service.logout = function (inputJsonString, callback) {
        communicationService.resultViaPost(webservices.logout, appConstants.authorizationKey, headerConstants.json, inputJsonString, function (response) {
            callback(response.data)
        })
    }, service
}]), MCSIApp.service("ngTableParamsService", function () {
    var params = {
            page: 1,
            count: 10,
            searchText: void 0,
            sorting: {
                _id: -1
            }
        },
        setParams = function (Npage, Ncount, Nfilter, Nsorting, Type) {
            if (void 0 === Nfilter) var filter = "";
            else var filter = Nfilter;
            params.page = Npage ? Npage : 1, params.count = Ncount ? Ncount : 10, params.searchText = filter, params.sorting = Nsorting ? Nsorting : {
                _id: -1
            }
        },
        getParams = function () {
            return params
        };
    return {
        set: setParams,
        get: getParams
    }
}), MCSIApp.factory("logger", ["$rootScope", function ($rootScope) {
    var logIt, clear;
    return toastr.options = {
        closeButton: !0,
        preventDuplicates: !0,
        positionClass: $rootScope.toastBase,
        onclick: null,
        timeOut: "3000",
        showMethod: "fadeIn",
        hideMethod: "fadeOut"
    }, logIt = function (message, type, timeOut) {
        return timeOut ? (toastr.options.timeOut = timeOut, toastr.options.extendedTimeOut = timeOut, toastr.options.tapToDismiss = !1) : toastr.options.tapToDismiss = !0, toastr[type](message)
    }, clear = function () {
        toastr.clear()
    }, {
        log: function (message) {
            toastr.options.positionClass = $rootScope.toastBase, logIt(message, "info")
        },
        logWarning: function (message) {
            toastr.options.positionClass = $rootScope.toastBase, logIt(message, "warning")
        },
        logSuccess: function (message) {
            toastr.options.positionClass = $rootScope.toastBase, logIt(message, "success")
        },
        logError: function (message, timeOut) {
            toastr.options.positionClass = $rootScope.toastBase, logIt(message, "error", timeOut)
        },
        clear: function () {
            clear()
        }
    }
}]), angular.module("Home"), MCSIApp.controller("homeController", ["$scope", "$rootScope", "$localStorage", "$location", "$ocLazyLoad", "$translate", "$modal", "$sce", "HomeService", "hotkeys", "socket", "webNotification", function ($scope, $rootScope, $localStorage, $location, $ocLazyLoad, $translate, $modal, $sce, HomeService, hotkeys, socket, webNotification) {
    $scope.counts = {}, $rootScope.modalItems = [], $rootScope.menuHome = ["familyDoctors", "add_family_Doctors", "statuses", "dashboard", "status_edit", "index", "edit_disease", "index_add", "Diseases", "updatetest", "add_disease", "users", "addUser", "users_edit", "roles", "editRoles", "kupatCholim_list", "addkupatCholim", "editKupatCholim", "Test", "survey", "addIndexTriage", "addIndexDisease", "edit_triage", "addRole", "rolePermissions", "ipSettings"], $rootScope.menuPatient = ["activePatient", "patientList", "addPatient", "patientdashboard", "addVisitReason", "addNewVisitReason", "editVisitReason", "editPatientIdentification", "editPayment", "editTriage", "editNurseExam", "visitDetails", "editDoctorExam", "doctorSummary", "doctorResult", "doctorResultFollowUp", "doctorPrescription", "visitCard", "newVisitCard", "prescription", "result", "summary", "visitDocument", "patientVisitHistory", "visitHistory", "patientDrugListing", "patientSummary", "visitcomment", "patientDebt", "doctorOrder", "doctorTreatment", "activePatientByDr"], $rootScope.menuInventory = ["inventoryList", "addDrug"], $rootScope.menuReport = ["reportDashboard", "visitorsResultReport", "visitResultHistoryReport", "currentDiseaseReport", "currentDiseaseHistoryReport", "invChangeReport", "invChangeHistoryReport", "drugsGiveAwayReport", "drugsGiveAwayHistoryReport", "kupatCholimReport", "kupatCholimHistoryReport"], $scope.activationMessage = function () {
        $scope.parmas = $location.search(), $scope.success = $scope.parmas.success
    }, $scope.selectedLanguage = $translate.use(), $scope.changeLanguage = function () {
        $localStorage.lang = $scope.selectedLanguage, "hw" == $scope.selectedLanguage ? ($localStorage.css = "main_a", $rootScope.css = "main_a", $rootScope.toastBase = "toast-top-left") : ($localStorage.css = "main", $rootScope.css = "main", $rootScope.toastBase = "toast-top-right"), $translate.use($scope.selectedLanguage);
        var selectedLanguage = {
            selectedLanguage: $scope.selectedLanguage
        };
        HomeService.updateLanguage().save(selectedLanguage, function (response) {
            200 == response.code
        })
    }, $scope.getCounts = function () {
        HomeService.getCounts().get(function (response) {
            200 == response.code && ($scope.counts = response.data)
        })
    }, socket.on("showDiseaseAlert", function (data) {
        var popupopen = $rootScope.modalItems.indexOf(data.data.alertId) > -1;
        popupopen === !1 && ($rootScope.modalItems.push(data.data.alertId), $scope.viewAlert("diseaseAlert", data))
    }), socket.on("showTriageAlert", function (data) {
        var popupopen = $rootScope.modalItems.indexOf(data.data.alertId) > -1;
        popupopen === !1 && ($rootScope.modalItems.push(data.data.alertId), $scope.viewAlert("triageAlert", data))
    }), $scope.viewAlert = function (type, data) {
        var AlertBody = "",
            title = "";
        if ("triageAlert" == type) {
            title = "Triage Alert Notification", AlertBody = "Patient Name: " + data.data.patientInfo.name + "\r Alert Reason: ";
            var triageTakenTime = "";
            if (data.data.triages) {
                var triagesList = data.data.triages;
                triagesList.forEach(function (item) {
                    AlertBody += item.name + ": " + item.value + ", ", triageTakenTime = item.time
                })
            }
            AlertBody += "\r On test done at:  " + triageTakenTime
        } else if ("diseaseAlert" == type && (title = "Disease Alert Notification", AlertBody = "Patient Name: " + data.data.patientInfo.name + "\r Alert Reason: \r", data.data.diseases)) {
            var diseaseList = data.data.diseases;
            diseaseList.forEach(function (item) {
                AlertBody += "- " + item.name + "\r"
            })
        }
        var modalInstance;
        modalInstance = $modal.open({
            templateUrl: "/modules/patient/views/" + type + ".html",
            controller: "homeViewController",
            resolve: {
                data: function () {
                    return {
                        data: data
                    }
                }
            }
        }), webNotification.showNotification(title, {
            body: $sce.trustAsHtml(AlertBody),
            icon: baseUrl + "/assets/images/favicon.ico",
            onClick: function () {
                var triageURL = baseUrl + "/#/visitDetails-edit/" + data.data.visitId;
                window.open(triageURL)
            }
        }, function (error, hide) {
            "Notification" in window && ("granted" === Notification.permission || "denied" === Notification.permission && "default" !== Notification.permission || Notification.requestPermission(function (permission) {})), error ? window.alert("Unable to show notification: " + error.message) : setTimeout(function () {
                hide()
            }, 5e4)
        })
    }
}]), MCSIApp.controller("homeViewController", ["$scope", "$rootScope", "$localStorage", "$location", "$translate", "HomeService", "socket", "$modal", "$modalInstance", "PatientService", "data", function ($scope, $rootScope, $localStorage, $location, $translate, HomeService, socket, $modal, $modalInstance, PatientService, data) {
    if ($scope.currentDate = new Date, $scope.data = data.data.data, $scope.data && $scope.data.triages)
        for (var traigeList = $scope.data.triages, i = 0; i < traigeList.length; i++) {
            $scope.triageTakenTime = traigeList[i].time;
            break
        }
    $scope.cancel = function () {
        $modalInstance.dismiss("cancel");
        for (var i = 0; i < $rootScope.modalItems.length; i++) $rootScope.modalItems[i] === $scope.data.alertId && $rootScope.modalItems.splice(i, 1)
    }, $scope.goToTriage = function () {
        $modalInstance.dismiss("cancel"), $location.path("/visitDetails-edit/" + $scope.data.visitId)
    }
}]), angular.module("Home").factory("HomeService", ["$http", "communicationService", "$resource", function ($http, communicationService, $resource) {
    var getCounts = function () {
            return $resource("/api/dashboardCount", null, {
                get: {
                    method: "GET"
                }
            })
        },
        updateLanguage = function () {
            return $resource("/api/updateLanguage", null, {
                save: {
                    method: "POST"
                }
            })
        };
    return {
        getCounts: getCounts,
        updateLanguage: updateLanguage
    }
}]), angular.module("Users"), MCSIApp.controller("userController", ["$scope", "$rootScope", "$location", "$ocLazyLoad", "$localStorage", "$modal", "$timeout", "$state", "ngTableParams", "ngTableParamsService", "logger", "UserService", "Upload", "CommonService", function ($scope, $rootScope, $location, $ocLazyLoad, $localStorage, $modal, $timeout, $state, ngTableParams, ngTableParamsService, logger, UserService, Upload, CommonService) {
    $scope.addUser = function (user) {
        UserService.addUser().save(user, function (response) {
            200 == response.code ? (logger.logSuccess(response.message), $state.go("users")) : logger.logError(response.message)
        })
    };
    var getData = ngTableParamsService.get();
    $scope.searchTextField = getData.searchText, $scope.searching = function () {
        ngTableParamsService.set("", "", $scope.searchTextField, ""), $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.usersList = [], UserService.getUsersList().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.usersList = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.getUsersList = function () {
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.usersList = [], UserService.getUsersList().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.usersList = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.getRolesList = function () {
        UserService.getRolesList().get(function (response) {
            200 == response.code ? $scope.rolesList = response.data : logger.logError(response.message)
        })
    }, $scope.getuserbyId = function (id) {
        UserService.getuserbyId($state.params.id).get(function (response) {
                200 == response.code && ($scope.userid = response.data)
            }),
            function (response) {
                logger.logError(response.message)
            }
    }, $scope.searching1 = function () {
        ngTableParamsService.set("", "", $scope.searchTextField, ""), $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.familyDoctors = [], UserService.getFamilyDoctors().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.familyDoctors = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.getFamilyDoctors = function () {
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.familyDoctors = [], UserService.getFamilyDoctors().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.familyDoctors = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.addFamilyDoctor = function (form) {
        UserService.addFamilyDoctor().save(form, function (response) {
                200 == response.code && (logger.logSuccess(response.message), $state.go("familyDoctors"))
            }),
            function (response) {
                logger.logError(response.message)
            }
    }, $scope.addDoctor = function (form) {
        UserService.addDoctor().save(form, function (response) {
                200 == response.code && (logger.logSuccess(response.message), $scope.getDoctors())
            }),
            function (response) {
                logger.logError(response.message)
            }
    }, $scope.getDoctors = function () {
        UserService.getDoctors().get(function (response) {
                200 == response.code && ($scope.getDoctors = response.data)
            }),
            function (respone) {
                logger.logError(response.message)
            }
    }, $scope.addStatus = function (status) {
        UserService.addStatus().save(status, function (response) {
                200 == response.code && (logger.logSuccess(response.message), $scope.getStatus())
            }),
            function (response) {
                logger.logError(response.message)
            }
    }, $scope.getStatus = function () {
        UserService.getStatus().get(function (response) {
                200 == response.code && ($scope.statuslist = response.data)
            }),
            function (response) {
                logger.logError(response.message)
            }
    }, $scope.getDoctorbyId = function (id) {
        UserService.getDoctorbyId($stateParams.id).get(function (response) {
                200 == response.code && ($scope.doctorid = response.data)
            }),
            function (response) {
                logger.logError(response.message)
            }
    }, $scope.deleteUser = function (id) {
        bootbox.confirm("Are you sure you want to delete this user", function (r) {
            r && UserService.deleteUser()["delete"]({
                id: id
            }, function (response) {
                200 == response.code ? ($scope.getUsersList(), logger.logSuccess(response.message)) : logger.logError(response.message)
            })
        })
    }, $scope.deleteFamilyDoctor = function (id) {
        bootbox.confirm("Are you sure you want to delete this family doctor", function (r) {
            r && UserService.deleteUser()["delete"]({
                id: id
            }, function (response) {
                200 == response.code ? ($scope.getFamilyDoctors(), response.message = "Family Doctor deleted successfully", logger.logSuccess(response.message)) : logger.logError(response.message)
            })
        })
    }, $scope.enableDisableUser = function (id, status) {
        UserService.enableDisableUser().save({
            userId: id,
            status: status
        }, function (response) {
            200 == response.code ? ($scope.getUsersList(), logger.logSuccess(response.message)) : logger.logError(response.message)
        })
    }, $scope.getUserByToken = function () {
        UserService.getUserByToken().get(function (response) {
            200 == response.code ? ($scope.UserProfile = response.data, logger.logSuccess(response.message)) : logger.logError(response.message)
        })
    }, $scope.uploadImage = function (dataUrl, name) {
        Upload.upload({
            url: baseUrl + "/api/uploadImage",
            data: {
                file: Upload.dataUrltoBlob(dataUrl, name)
            }
        }).then(function (resp) {
            $timeout(function () {
                $scope.result = resp.data
            }), $scope.getUserByToken(), resp.data && resp.data.data && ($localStorage.profileName = resp.data.data, $rootScope.profileName = resp.data.data), logger.logSuccess(resp.data.message)
        }, function (resp) {
            logger.logError(resp.data.message)
        }, function (evt) {
            $scope.progress = parseInt(100 * evt.loaded / evt.total)
        })
    }, $scope.colorStatusbyId = function (id) {
        UserService.colorStatusbyId($state.params.id).get(function (response) {
                200 == response.code ? $scope.status = response.data : logger.logError(response.message)
            }),
            function (response) {
                logger.logError(response.message)
            }
    }, $scope.updateColorStatus = function (status, id) {
        UserService.updateColorStatus().save(status, function (response) {
            200 == response.code ? (logger.logSuccess(response.message), $state.go("statuses")) : logger.logError(response.message)
        })
    }, $scope.getkupatCholim = function () {
        UserService.getkupatCholim().get(function (response) {
            200 == response.code ? $scope.kupatCholimlist = response.data : logger.logError(response.message)
        })
    }, $scope.items = ["item1", "item"], $scope.openDilogue = function (a, id) {
        var modalInstance;
        modalInstance = $modal.open({
            templateUrl: "/modules/users/views/" + a + ".html",
            controller: "ModalCtrl",
            resolve: {
                items: function () {
                    return {
                        id: id
                    }
                }
            }
        })
    }, $scope.addOrUpdateIp = function () {
        $scope.form.$valid && UserService.addOrUpdateIp().save($scope.settings, function (response) {
            200 === response.code ? logger.logSuccess(response.message) : logger.logError(response.message)
        })
    }, $scope.getSettingsData = function () {
        $scope.settings = {}, UserService.getSettingsData().get(function (response) {
            200 == response.code ? $scope.settings = response.data.data : logger.logError(response.message)
        })
    }, $scope.changePasswordFirstLogin = function (newPassword, confirmPassword) {
        if (newPassword == confirmPassword) {
            var data = {
                id: $location.search().i,
                password: newPassword
            };
            UserService.resetPassword().save(data, function (response) {
                200 == response.code ? (logger.logSuccess(response.message), $state.go("dashboard")) : logger.logError(response.message)
            })
        } else logger.logError("Confirm Password Incorrect")
    }, $scope.updateProfile = function (UserProfile) {
        UserService.updateProfile().save(UserProfile, function (response) {
            200 == response.code ? (logger.logSuccess(response.message), response.data && response.data.full && response.data.full !== $localStorage.loggedInUser && ($localStorage.loggedInUser = response.data.full), $state.go("myprofile")) : logger.logError(response.message)
        })
    }
}]), MCSIApp.controller("ModalCtrl", ["$scope", "$rootScope", "$location", "$modalInstance", "$localStorage", "$modal", "ngTableParams", "ngTableParamsService", "$state", "logger", "UserService", "Upload", "CommonService", function ($scope, $rootScope, $location, $modalInstance, $localStorage, $modal, ngTableParams, ngTableParamsService, $state, logger, UserService, Upload, CommonService) {
    $scope.hide = !0, $scope.getUserByToken = function () {
        UserService.getUserByToken().get(function (response) {
            200 == response.code ? $scope.UserProfile = response.data : logger.logError(response.message)
        })
    }, $scope.cancel = function () {
        $modalInstance.dismiss("cancel")
    }, $(document).ready(function () {
        $(".fancybox").fancybox()
    }), $scope.resetPassword = function (UserProfile, newPassword, confirmPassword, oldPassword, password) {
        oldPassword == password ? newPassword == confirmPassword ? (UserProfile.password = newPassword, UserService.resetPassword().save(UserProfile, function (response) {
            200 == response.code ? (logger.logSuccess(response.message), $scope.cancel()) : logger.logError(response.message)
        })) : logger.logError("Confirm Password Incorrect") : logger.logError("Old Password Incorrect")
    }
}]), angular.module("Users").factory("UserService", ["$http", "communicationService", "$resource", function ($http, communicationService, $resource) {
    var getUsersList = function () {
            return $resource("/api/getUserList", null, {
                get: {
                    method: "GET"
                }
            })
        },
        getRolesList = function () {
            return $resource("/api/getRoles", null, {
                get: {
                    method: "GET"
                }
            })
        },
        getuserbyId = function (id) {
            return $resource("/api/getuserbyId/" + id, null, {
                get: {
                    method: "GET",
                    id: "@id"
                }
            })
        },
        addUser = function () {
            return $resource("/api/addUser", null, {
                save: {
                    method: "POST"
                }
            })
        },
        addFamilyDoctor = function () {
            return $resource("/api/addFamilyDoctor", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getFamilyDoctors = function () {
            return $resource("/api/getFamilyDoctors", null, {
                get: {
                    method: "GET"
                }
            })
        },
        enableDisableUser = function () {
            return $resource("/api/enableDisableUser", null, {
                save: {
                    method: "POST"
                }
            })
        },
        deleteUser = function () {
            return $resource("/api/deleteUserById/:id", null, {
                "delete": {
                    method: "DELETE",
                    id: "@id"
                }
            })
        },
        getkupatCholim = function () {
            return $resource("/api/getkupatCholim", null, {
                get: {
                    method: "GET"
                }
            })
        },
        getUserByToken = function (id) {
            return $resource("/api/getUserByToken", null, {
                get: {
                    method: "GET"
                }
            })
        },
        updateColorStatus = function () {
            return $resource("/api/updateColorStatus", null, {
                save: {
                    method: "POST"
                }
            })
        },
        colorStatusbyId = function (id) {
            return $resource("/api/colorStatusbyId/" + id, null, {
                get: {
                    method: "GET",
                    id: "@id"
                }
            })
        },
        getStatus = function () {
            return $resource("/api/getStatus", null, {
                get: {
                    method: "GET"
                }
            })
        },
        resetPassword = function () {
            return $resource("/api/resetPassword", null, {
                get: {
                    method: "POST"
                }
            })
        },
        addOrUpdateIp = function () {
            return $resource("/api/addOrUpdateIp", null, {
                save: {
                    method: "POST"
                }
            })
        },
        updateProfile = function () {
            return $resource("/api/updateProfile", null, {
                get: {
                    method: "POST"
                }
            })
        },
        getSettingsData = function () {
            return $resource("/api/getSettingsData", null, {
                get: {
                    method: "GET"
                }
            })
        };
    return {
        addUser: addUser,
        getUsersList: getUsersList,
        getFamilyDoctors: getFamilyDoctors,
        addFamilyDoctor: addFamilyDoctor,
        getRolesList: getRolesList,
        enableDisableUser: enableDisableUser,
        deleteUser: deleteUser,
        getuserbyId: getuserbyId,
        getkupatCholim: getkupatCholim,
        getUserByToken: getUserByToken,
        colorStatusbyId: colorStatusbyId,
        updateColorStatus: updateColorStatus,
        getStatus: getStatus,
        resetPassword: resetPassword,
        addOrUpdateIp: addOrUpdateIp,
        updateProfile: updateProfile,
        getSettingsData: getSettingsData
    }
}]), angular.module("Roles").factory("RolesServ", ["$resource", function ($resource) {
    return {
        roles: function () {
            return $resource("/api/roles/:id", null, {
                update: {
                    method: "PUT"
                },
                get: {
                    method: "GET",
                    id: "@id"
                },
                "delete": {
                    method: "DELETE",
                    id: "@id"
                },
                save: {
                    method: "POST"
                }
            })
        },
        rolePermissions: function () {
            return $resource("/api/roles/update_permission/:id", null, {
                update: {
                    method: "PUT"
                }
            })
        },
        permissions: function () {
            return $resource("/api/permissions")
        }
    }
}]), angular.module("Roles"), MCSIApp.controller("roleController", ["$scope", "RolesServ", "$location", "$ocLazyLoad", "$stateParams", "$state", "logger", "ngTableParams", function ($scope, RolesServ, $location, $ocLazyLoad, $stateParams, $state, logger, ngTableParams) {
    $scope.permission = "home", $scope.role = function (val) {
        $scope.permission = val
    }, $scope.roleList = "", $scope.roleForm = {}, $scope.rolePermissionForm = {}, $scope.rolePermissionForm.permission_id = [], $scope.getRolesList = function () {
        RolesServ.roles().get(function (response) {
            $scope.roleList = response.data ? response.data : [], $scope.tableParams = new ngTableParams({
                page: 1,
                count: 10
            }, {
                total: $scope.roleList.length,
                data: $scope.roleList
            })
        })
    }, $scope.getRoleByid = function (type) {
        $stateParams.id && ($scope.rolePermissionForm = {}, $scope.rolePermissionForm.permission_id = [], RolesServ.roles().get({
            id: $stateParams.id
        }, function (response) {
            200 === response.code ? ($scope.roleForm.title = response.data.title, "permission" === type ? $scope.rolePermissionForm.permission_id = response.data.permission_id : $scope.roleForm.description = response.data.description, logger.logSuccess(response.message)) : (logger.logError(response.message), $location.path("roles"))
        }))
    }, $scope.update = function () {
        $scope.form.$valid && ($scope.disableUpdateSbmtBtn = !0, RolesServ.roles().update({
            id: $stateParams.id
        }, $scope.roleForm, function (response) {
            $scope.disableUpdateSbmtBtn = !1, 200 === response.code ? ($location.path("roles"), logger.logSuccess(response.message)) : logger.logError(response.message)
        }))
    }, $scope.updatePermission = function () {
        if ($scope.form.$valid) {
            var params = {};
            params.permission_id = [], angular.forEach($scope.rolePermissionForm.permission_id, function (value, key) {
                null != value && void 0 != value && "" != value && params.permission_id.push(value)
            }), params.permission_id.length > 0 && ($scope.disableUpdateSbmtBtn = !0, RolesServ.rolePermissions().update({
                id: $stateParams.id
            }, params, function (response) {
                $scope.disableUpdateSbmtBtn = !1, 200 === response.code && ($location.path("roles"), logger.logSuccess(response.message))
            }))
        }
    }, $scope.toggle = function (item, list) {
        var idx = list.indexOf(item);
        idx > -1 ? list.splice(idx, 1) : list.push(item)
    }, $scope.exists = function (item, list) {
        return list.indexOf(item) > -1
    }, $scope.add = function () {
        $scope.form.$valid && ($scope.disableAddSbmtBtn = !0, RolesServ.roles().save($scope.roleForm, function (response) {
            $scope.disableAddSbmtBtn = !1, 200 === response.code ? ($location.path("roles"), logger.logSuccess(response.message)) : logger.logError(response.message)
        }))
    }, $scope.getPermissions = function () {
        RolesServ.permissions().get(function (response) {
            200 === response.code && ($scope.permissionList = response.data)
        })
    }, $scope.checkAll = function () {
        angular.forEach($scope.permissionList, function (user) {
            user.select = $scope.selectedAll
        })
    }
}]), angular.module("Disease"), MCSIApp.controller("diseaseController", ["$scope", "$state", "$rootScope", "$location", "$ocLazyLoad", "$localStorage", "ngTableParams", "ngTableParamsService", "logger", "DiseaseService", "CommonService", function ($scope, $state, $rootScope, $location, $ocLazyLoad, $localStorage, ngTableParams, ngTableParamsService, logger, DiseaseService, CommonService) {
    $scope.nurse = [{
        nurseTest: ""
    }], $scope.addnurseTest = function ($event) {
        var nurseTest = {
            nurseTest: ""
        };
        $scope.nurse.push(nurseTest), $event.preventDefault()
    }, $scope.removeNurseTest = function () {
        var lastItem = $scope.nurse.length - 1;
        $scope.nurse.splice(lastItem)
    }, $scope.doctor = [{
        doctorTest: ""
    }], $scope.addDoctorTest = function () {
        var doctorTest = {
            doctorTest: ""
        };
        $scope.doctor.push(doctorTest)
    }, $scope.removeDoctorTest = function () {
        var lastItem = $scope.doctor.length - 1;
        $scope.doctor.splice(lastItem)
    }, $scope.addnewdisease = function (disease) {
        disease.nurseTest = [], disease.doctorTest = [], disease.nurseTest = $scope.nurse, disease.doctorTest = $scope.doctor, DiseaseService.addnewdisease().save(disease, function (response) {
            200 == response.code ? (logger.logSuccess(response.message), $state.go("Diseases")) : logger.logError(response.message)
        }, function (response) {})
    };
    var getData = ngTableParamsService.get();
    $scope.searchTextField = getData.searchText, $scope.searchingdisease = function () {
        ngTableParamsService.set("", "", $scope.searchTextField, ""), $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.diseaseList = [], DiseaseService.getalldisease().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.diseaseList = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.getalldisease = function () {
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.diseaseList = [], DiseaseService.getalldisease().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.diseaseList = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.getAllDisease = function () {
        DiseaseService.getalldisease().get(function (response) {
            200 == response.code ? ($rootScope.diseaselist = response.data, logger.logSuccess(response.message)) : logger.logError(response.message)
        })
    }, $scope.getdiseasebyId = function (id) {
        DiseaseService.getdiseasebyId($state.params.id).get(function (response) {
            if (200 == response.code) {
                $scope.diseaseName = response.data.name, $rootScope.diseaseid = response.data, $scope.allTestList = [], $scope.doctor = response.data.doctorTest, $scope.nurse = response.data.nurseTest;
                for (var i = 0, len = Math.max(response.data.nurseTest.length, response.data.doctorTest.length); i < len;) $scope.allTestList.push({
                    nurseTest: response.data.nurseTest[i] || null,
                    doctorTest: response.data.doctorTest[i] || null
                }), i++
            } else logger.logError(response.message)
        })
    }, $scope.deletedisease = function (id) {
        bootbox.confirm("Are you sure you want to delete this disease", function (r) {
            r && DiseaseService.deletedisease(id)["delete"](function (response) {
                200 == response.code ? logger.logSuccess(response.message) : logger.logError(response.message), $scope.getalldisease()
            })
        })
    }, $scope.updateindex = function (index) {
        DiseaseService.updateindex().save($scope.diseaseid, function (response) {
            200 == response.code ? logger.logSuccess(response.message) : logger.logError(response.message)
        })
    }, $scope.getallIndex = function () {
        DiseaseService.getallIndex().get(function (response) {
            200 == response.code ? $scope.indexList = response.data : logger.logError(response.message)
        })
    }, $scope.getIndexTitleList = function (index) {
        "Disease" == index && ($scope.index2 = void 0), "Triage" == index && ($scope.index1 = void 0);
        var params = {
            indexType: index
        };
        DiseaseService.getIndexTitleList().get(params, function (response) {
            200 == response.code ? $scope.indexList = response.data : logger.logError(response.message)
        })
    }, $scope.addIndex = function (index, indexType) {
        if ("Disease" == indexType) var index3 = {
            _id: index._id,
            alertFreqency: index.alertFreqency,
            indexType: indexType.indexType
        };
        else var index3 = {
            _id: index._id,
            minRange: index.minRange,
            maxRange: index.maxRange,
            alertFreqency: index.alertFreqency,
            indexType: indexType.indexType
        };
        DiseaseService.addIndex().save(index3, function (response) {
            200 == response.code ? (logger.logSuccess(response.message), $state.go("index")) : logger.logError(response.message)
        }, function (response) {})
    }, $scope.editIndex = function (index) {
        DiseaseService.addIndex().save(index, function (response) {
            200 == response.code ? (logger.logSuccess(response.message), $state.go("index")) : logger.logError(response.message)
        }, function (response) {})
    }, $scope.editIndexList = function (id, indexType) {
        "Triage" == indexType ? $location.path("/indexList/edittriage/" + id) : $location.path("/indexList/editdisease/" + id)
    }, $scope.getTriagebyId = function () {
        DiseaseService.getTriagebyId($state.params.id).get(function (response) {
            200 == response.code ? $rootScope.triageId = response.data : logger.logError(response.message)
        })
    }, $scope.updateTest = function (allTestList) {
        var disease = {};
        disease.test = allTestList, disease.id = $state.params.id, disease.nurseTest = $scope.nurse, disease.doctorTest = $scope.doctor, DiseaseService.updatetest().save(disease, function (response) {
            200 == response.code ? (logger.logSuccess(response.message), $state.go("Diseases")) : logger.logError(response.message)
        })
    }
}]), angular.module("Disease").factory("DiseaseService", ["$http", "communicationService", "$resource", function ($http, communicationService, $resource) {
    var getalldisease = function () {
            return $resource("/api/getalldisease", null, {
                get: {
                    method: "GET"
                }
            })
        },
        addnewdisease = function () {
            return $resource("/api/addnewdisease", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getdiseasebyId = function (id) {
            return $resource("/api/getdiseasebyId/" + id, null, {
                get: {
                    method: "GET",
                    id: "@id"
                }
            })
        },
        deletedisease = function (id) {
            return $resource("/api/deletediseasebyId/" + id, null, {
                "delete": {
                    method: "DELETE",
                    id: "@id"
                }
            })
        },
        updateindex = function () {
            return $resource("/api/updateindex", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getallIndex = function () {
            return $resource("/api/getAllIndex", null, {
                get: {
                    method: "GET"
                }
            })
        },
        getIndexTitleList = function () {
            return $resource("/api/getIndexTitleList/:indexType", null, {
                get: {
                    method: "GET"
                }
            })
        },
        addIndex = function () {
            return $resource("/api/addIndex", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getTriagebyId = function (id) {
            return $resource("/api/getTriagebyId/" + id, null, {
                get: {
                    method: "GET",
                    id: "@id"
                }
            })
        },
        updatetest = function () {
            return $resource("/api/updatetest/", null, {
                save: {
                    method: "POST"
                }
            })
        };
    return {
        getalldisease: getalldisease,
        addnewdisease: addnewdisease,
        getdiseasebyId: getdiseasebyId,
        updateindex: updateindex,
        getallIndex: getallIndex,
        getIndexTitleList: getIndexTitleList,
        addIndex: addIndex,
        getTriagebyId: getTriagebyId,
        deletedisease: deletedisease,
        updatetest: updatetest
    }
}]), angular.module("Survey"), MCSIApp.controller("surveyController", ["$scope", "$rootScope", "$location", "$ocLazyLoad", "$localStorage", "$state", "logger", "CommonService", "SurveyService", function ($scope, $rootScope, $location, $ocLazyLoad, $localStorage, $state, logger, CommonService, SurveyService) {
    $scope.questionelemnt = [{
        question: ""
    }], $scope.newItem = function ($event) {
        $scope.questionelemnt.push({
            question: "",
            type: ""
        }), $event.preventDefault()
    }, $scope.addSurvey = function (survey) {
        var id, surveyData = {};
        $scope.survey && $scope.survey.id && (id = $scope.survey.id, surveyData.id = id);
        var level = [],
            question = [];
        Array.prototype.push.apply(level, [survey.level1, survey.level2, survey.level3, survey.level4, survey.level5, survey.level6]), angular.forEach($scope.questionelemnt, function (value, key) {
            "" !== value.question && question.push({
                description: value.question,
                type: value.questionType
            })
        }), surveyData.level = level, surveyData.question = question, surveyData.name = "Survey", SurveyService.addSurvey().save(surveyData, function (response) {
            200 == response.code ? logger.logSuccess(response.message) : logger.logError(response.message)
        })
    }, $scope.getSurveyDetails = function () {
        $scope.$emit("start", !0), SurveyService.getSurveyDetails().get(function (response) {
            if (200 == response.code && response.data[0]) {
                var surveydetails = response.data[0].question;
                angular.forEach(surveydetails, function (value, key) {
                    $scope.questionelemnt.unshift({
                        id: key,
                        question: value.description,
                        questionType: value.type
                    })
                }), $scope.survey = {}, $scope.survey.id = response.data[0]._id, $scope.survey.level1 = response.data[0].level[0], $scope.survey.level2 = response.data[0].level[1], $scope.survey.level3 = response.data[0].level[2], $scope.survey.level4 = response.data[0].level[3], $scope.survey.level5 = response.data[0].level[4], $scope.survey.level6 = response.data[0].level[5]
            } else logger.logError(response.message);
            $scope.$emit("stop", !0)
        })
    }, $scope.getSurveyById = function () {
        var visitDetails = {
            id: $state.params.id
        };
        SurveyService.getSurveyById().save(visitDetails, function (response) {
            200 == response.code ? response.data && ($scope.surveyData = response.data) : logger.logError(response.message)
        })
    }, $scope.submitSurvey = function () {
        SurveyService.submitSurvey().save($scope.surveyData, function (response) {
            200 == response.code ? logger.logSuccess(response.message) : logger.logError(response.message)
        })
    }
}]), angular.module("Survey").factory("SurveyService", ["$http", "communicationService", "$resource", function ($http, communicationService, $resource) {
    var addSurvey = function () {
            return $resource("/api/addSurvey", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getSurveyDetails = function () {
            return $resource("/api/getSurveySetByAdmin", null, {
                get: {
                    method: "GET"
                }
            })
        },
        getSurveyById = function () {
            return $resource("/api/getSurveyById/", null, {
                save: {
                    method: "POST"
                }
            })
        },
        submitSurvey = function () {
            return $resource("/api/submitSurvey", null, {
                save: {
                    method: "POST"
                }
            })
        };
    return {
        addSurvey: addSurvey,
        getSurveyDetails: getSurveyDetails,
        getSurveyById: getSurveyById,
        submitSurvey: submitSurvey
    }
}]), angular.module("Patients"), MCSIApp.controller("patientController", ["$scope", "$rootScope", "$location", "$ocLazyLoad", "$localStorage", "$filter", "$modal", "$http", "$window", "ngTableParams", "ngTableParamsService", "$state", "$sce", "logger", "CommonService", "PatientService", "Upload", "DiseaseService", "socket", "InventoryService", "hotkeys", "datepickerPopupConfig", function ($scope, $rootScope, $location, $ocLazyLoad, $localStorage, $filter, $modal, $http, $window, ngTableParams, ngTableParamsService, $state, $sce, logger, CommonService, PatientService, Upload, DiseaseService, socket, InventoryService, hotkeys, datepickerPopupConfig) {
    $scope.currentDate = new Date, $scope.visitReason = {}, $scope.newvisitReason = {}, $scope.visitReason.isUrgent = 0, $scope.newvisitReason.isUrgent = 0, $scope.visitCommentList = [];
    var getData = ngTableParamsService.get();
    $scope.searchTextField = getData.searchText, datepickerPopupConfig.showButtonBar = !1, $scope.currentPage = "", hotkeys.bindTo($scope).add({
        combo: ["shift+alt"],
        callback: function (event, hotkey) {
            $state.go("activePatient")
        }
    }), hotkeys.bindTo($scope).add({
        combo: ["ctrl"],
        callback: function (event, hotkey) {
            "visitDetails-edit" == $scope.currentPage ? $scope.addVisitDetails($scope.visitData, !1) : "nurseExam-edit" == $scope.currentPage ? $scope.addNurseExamination(!0) : "patientIdentification-edit" == $scope.currentPage ? $scope.editPatient($scope.patient, !1) : "visitReason-edit" == $scope.currentPage ? $scope.addVisitReason($scope.visitData, !1) : "payment-edit" == $scope.currentPage ? $scope.visitData && $scope.visitData._id && $location.path("/visitCard/" + $scope.visitData._id) : "addPatient" == $scope.currentPage ? $scope.addPatient($scope.patientData, !0) : "newVisitReason" == $scope.currentPage ? $scope.addnewVisitReason($scope.patientData) : "doctorSummary" == $scope.currentPage ? $location.path("/doctorExam-edit/" + $scope.visitData._id) : "editDoctorExam" == $scope.currentPage ? $scope.addDoctorExamDetails(!1) : "doctorOrder" == $scope.currentPage ? $scope.addDoctorOrder(!1) : "doctorTreatment" == $scope.currentPage ? $scope.addDoctorTreatment(!1) : "doctorPrescription" == $scope.currentPage ? $scope.addPrescription(!1) : "doctorResult" == $scope.currentPage ? $scope.addTreatmentResultDetails($scope.visitData, !1) : "addPatientDrugs" == $scope.currentPage && $scope.addPatientDrugs(!1)
        }
    }), hotkeys.bindTo($scope).add({
        combo: ["esc"],
        callback: function (event, hotkey) {
            "visitDetails-edit" == $scope.currentPage ? $scope.addVisitDetails($scope.visitData, !0) : "nurseExam-edit" == $scope.currentPage ? $scope.addNurseExamination(!0) : "visitReason-edit" == $scope.currentPage ? $scope.addVisitReason($scope.visitData, !0) : "payment-edit" == $scope.currentPage ? $scope.visitData && $location.path("/visitCard/" + $scope.visitData._id) : "addPatientDrugs" == $scope.currentPage ? $scope.addPatientDrugs(!0) : "doctorSummary" == $scope.currentPage ? $location.path("/visitCard/" + $scope.visitData._id) : "editDoctorExam" == $scope.currentPage ? $scope.addDoctorExamDetails(!0) : "doctorOrder" == $scope.currentPage ? $scope.addDoctorOrder(!0) : "doctorTreatment" == $scope.currentPage ? $scope.addDoctorTreatment(!0) : "doctorPrescription" == $scope.currentPage ? $scope.addPrescription(!0) : "doctorResult" == $scope.currentPage ? $scope.addTreatmentResultDetails($scope.visitData, !0) : "patientIdentification-edit" == $scope.currentPage ? $scope.editPatient($scope.patient, !0) : $scope.visitData && $location.path("/visitCard/" + $scope.visitData._id)
        }
    }), $scope.searchActivePatientTextField = "", $scope.showActiveSearchStatus = "NO", $scope.checkActiveSearchStatus = function (filter) {
        $scope.showActiveSearchStatus = filter, "NO" == filter && ($scope.searchActivePatientTextField = "", $scope.searchActivePatient()), "YES" == filter && $scope.searchActivePatient()
    }, $scope.searchActivePatient = function () {
        ("YES" === $scope.showActiveSearchStatus || "NO" === $scope.showActiveSearchStatus && "" == $scope.searchActivePatientTextField) && (ngTableParamsService.set("", "", $scope.searchActivePatientTextField, ""), $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchActivePatientTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.activeVisitList = [], PatientService.getActivePatientList().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.activeVisitList = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        }))
    }, $scope.getActivePatientList = function () {
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchActivePatientTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.activeVisitList = [], PatientService.getActivePatientList().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.activeVisitList = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.searchActivePatientByDrTextField = "", $scope.showActivePatientSearchStatus = "NO", $scope.checkListSearchStatus = function (filter) {
        $scope.showActivePatientSearchStatus = filter, "NO" == filter && ($scope.searchActivePatientByDrTextField = "", $scope.searchActivePatient()), "YES" == filter && $scope.searchActivePatient()
    }, $scope.searchActivePatientByDr = function () {
        ("YES" === $scope.showActivePatientSearchStatus || "NO" === $scope.showActivePatientSearchStatus && "" == $scope.searchActivePatientByDrTextField) && (ngTableParamsService.set("", "", $scope.searchActivePatientByDrTextField, ""), $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchActivePatientByDrTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.activeVisitListByDr = [], PatientService.getActivePatientListByDr().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.activeVisitListByDr = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        }))
    }, $scope.getActivePatientListByDr = function () {
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchActivePatientByDrTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.activeVisitListByDr = [], PatientService.getActivePatientListByDr().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.activeVisitListByDr = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.isSearchEnable = !1, $scope.searchable = function () {
        $scope.isSearchEnable = !0, ngTableParamsService.set("", "", $scope.searchTextField, ""), $scope.patientList = [], $scope.searchTextField && " " != $scope.searchTextField && ($scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, PatientService.getPatientList().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.patientList = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        }))
    }, $scope.getPatientList = function () {
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.patientList = [], PatientService.getPatientList().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1;
                    var filteredData = params.filter() ? $filter("filter")(response.data, params.filter()) : response.data,
                        orderedData = params.sorting() ? $filter("orderBy")(filteredData, params.orderBy()) : filteredData;
                    params.total(response.totalLength), $defer.resolve(orderedData)
                })
            }
        })
    }, $scope.Sprefix = "", $scope.Ssuffix = "", $scope.Mprefix = "", $scope.Msuffix = "", $scope.getPatientById = function (id) {
        $scope.showTopNav = $state.params.showTopNav, 1 == $scope.showTopNav && ($scope.currentPage = "addPatient"), PatientService.getPatientById($state.params.id).get(function (response) {
            if (200 == response.code) {
                $scope.patientData = response.data, console.log("patient:=====>", $scope.patientData);
                var arr2 = $scope.patientData.secondaryNo.split("-");
                2 == arr2.length ? ($scope.Sprefix = arr2[0], $scope.Ssuffix = arr2[1]) : 1 == arr2.length && ($scope.Ssuffix = arr2[0], $scope.Sprefix = "");
                var arr = $scope.patientData.mobileNo.split("-");
                2 == arr.length ? ($scope.Mprefix = arr[0], $scope.Msuffix = arr[1]) : 1 == arr.length && ($scope.Msuffix = arr[0], $scope.Mprefix = ""), response.data && response.data.allergies && ($scope.allergies = response.data.allergies.join(" , "))
            } else $scope.patientData = {}, $scope.patientData.city = [], logger.logError(response.message)
        })
    }, $scope.addVisitReason = function (visitReason, isExitDashboard, stateToGo) {
        $scope.visitReasonForm.$dirty ? (visitReason.patientId = $scope.visitData.patientId._id, visitReason.visitId = $scope.visitData._id, PatientService.addVisitReason().save(visitReason, function (response) {
            200 == response.code ? (logger.logSuccess(response.message), isExitDashboard ? $state.go("visitCard", {
                id: $scope.visitData._id
            }) : stateToGo ? $state.go(stateToGo, {
                id: $scope.visitData._id
            }) : $state.go("editPayment", {
                id: $scope.visitData._id
            })) : logger.logError(response.message)
        })) : isExitDashboard ? $state.go("visitCard", {
            id: $scope.visitData._id
        }) : stateToGo ? $state.go(stateToGo, {
            id: $scope.visitData._id
        }) : $state.go("editPayment", {
            id: $scope.visitData._id
        })
    }, $scope.addnewVisitReason = function (newvisitReason) {
        newvisitReason.patientId = $scope.patientData._id, PatientService.addNewVisitReason().save(newvisitReason, function (response) {
            200 == response.code ? ($scope.visitData = response.data, $state.go("editPayment", {
                id: $scope.visitData._id
            }), logger.logSuccess(response.message)) : logger.logError(response.message)
        })
    }, $scope.showVisitCard = function (id) {
        $rootScope.permissionsArray.indexOf("visitCard") != -1 && $state.go("visitCard", {
            id: id
        })
    }, $scope.showFreshVisitCard = function (patient) {
        1 == patient.status ? logger.log("Previous Visit not finished yet") : $state.go("addPatient", {
            id: patient._id,
            showTopNav: 1
        })
    }, $scope.triageTestList = [], $scope.newTriageTestList = [], $scope.addtriagetest = function ($event) {
        var test = {
            pulse: 0,
            saturation: 0,
            weight: 0,
            bloodPressure: {
                minValue: 0,
                maxValue: 0
            },
            temperature: 0,
            breadthPerMinute: 0,
            open: !0
        };
        $scope.triageTestList.push(test), $scope.newTriageTestList.push(test), $event.preventDefault()
    }, $scope.addTriageTestform = function () {
        var triageDetails = {};
        triageDetails.triageTest = [], triageDetails.triageTest = $scope.newTriageTestList, triageDetails.visitId = $scope.visitData._id, $scope.tagsString = $scope.visitData.patientId.allergies.map(function (tag) {
            return tag.text
        }), triageDetails.allergies = $scope.tagsString, PatientService.addTriageDetails().save(triageDetails, function (response) {
            200 == response.code ? ($scope.getVisitById(), response.data && response.data.alertInfo && response.data.alertInfo.triages && response.data.alertInfo.triages.length > 0 && socket.emit("triageAlert", response.data.alertInfo), $scope.getTriageTestByVisitId($scope.visitData._id), logger.logSuccess(response.message)) : logger.logError(response.message)
        })
    }, $scope.getTriageTestByVisitId = function (id) {
        PatientService.getTriageTestByVisitId($state.params.id).get(function (response) {
            200 == response.code ? response.data && response.data.triageTest && ($scope.triageData = response.data, $scope.triageTestList = response.data.triageTest) : logger.logError(response.message)
        })
    }, $scope.allergiesInfo = [], $scope.getAllergies = function () {
        PatientService.getAllergies().get(function (response) {
            200 == response.code && ($scope.allergiesInfo = response.data, $scope.allergiesInfo.forEach(function (e) {
                e.text = e.name
            }))
        })
    }, $scope.loadAllergies = function () {
        return $scope.allergiesInfo
    }, $scope.cities = [], $scope.loadCities = function () {
        return $scope.cities
    }, $scope.getCities = function () {
        PatientService.getCities().get(function (response) {
            200 == response.code && ($scope.cities = response.data)
        })
    }, $scope.changeCity = function (city) {
        $scope.patientData && ($scope.patientData.city = city), $scope.patient && ($scope.patient.city = city)
    }, $scope.forceOneTag = function (tags) {
        return 0 === tags.length
    }, $scope.savedExtRef = !1, $scope.getVisitById = function (id) {
        var diseaseName = [];
        $scope.$emit("start", !0), PatientService.getVisitById($state.params.id).get(function (response) {
                if (200 == response.code) {
                    $scope.patientData = response.patientData, $scope.visitData = response.data, response.data.patientId && ($scope.allergies = response.data.patientId.allergies.join(" , "));
                    for (var i = 0; i < response.data.currentDisease.length; i++) diseaseName.push(response.data.currentDisease[i].name);
                    $scope.diseaseName = diseaseName.join(), $scope.patient = $scope.visitData.patientId;
                    var extreferral = $scope.visitData.treatmentResultType;
                    "External Referral" == extreferral && ($scope.extreferral = !0, $scope.savedExtRef = !0, $scope.RefferedTo = "ER"), 1 == response.data.isUrgent ? $scope.isUrgent = !0 : $scope.isUrgent = !1, $scope.visitCommentList = $scope.visitData.visitComment
                } else logger.logError(response.message);
                $scope.$emit("stop", !0)
            }),
            function (response) {}
    }, $scope.toggle = function (data) {
        $scope.isUrgent = !!data
    }, $scope.check = function (data) {
        $scope.isChecked = !!data
    }, $scope.addVisitDetails = function (visitDetails, isExitDashboard) {
        if (visitDetails.currentDisease = [], visitDetails.modifiedCurrentDisease)
            for (var i = 0; i < visitDetails.modifiedCurrentDisease.length; i++) visitDetails.currentDisease.push(visitDetails.modifiedCurrentDisease[i]._id);
        var triageDetails = {};
        triageDetails.triageTest = [], triageDetails.triageTest = $scope.newTriageTestList, triageDetails.visitId = $scope.visitData._id, $scope.tagsString = $scope.visitData.patientId.allergies.map(function (tag) {
            return tag.text
        }), triageDetails.allergies = $scope.tagsString, PatientService.addVisitDetails().save(visitDetails, function (response) {
            200 == response.code ? (response.data && response.data.diseases && response.data.diseases.length > 0 && socket.emit("diseaseAlert", response.data), PatientService.addTriageDetails().save(triageDetails, function (response) {
                200 == response.code ? (response.data && response.data.alertInfo && response.data.alertInfo.triages && response.data.alertInfo.triages.length > 0 && socket.emit("triageAlert", response.data.alertInfo), $scope.getVisitById(), $scope.getTriageTestByVisitId($scope.visitData._id), isExitDashboard ? $state.go("visitCard", {
                    id: $scope.visitData._id
                }) : $state.go("editNurseExam", {
                    id: $scope.visitData._id
                }), logger.logSuccess(response.message)) : logger.logError(response.message)
            })) : logger.logError(response.message)
        })
    }, $scope.getVisitDetailsById = function (id) {
        DiseaseService.getalldisease().get(function (response) {
            if (200 == response.code) {
                $scope.diseaselist = response.data, $scope.modifiedList = [];
                for (var i = 0; i < $scope.diseaselist.length; i++) {
                    var obj = {
                        _id: $scope.diseaselist[i]._id,
                        name: $scope.diseaselist[i].name,
                        ticked: !1
                    };
                    $scope.modifiedList.push(obj)
                }
                PatientService.getVisitById($state.params.id).get(function (response) {
                    if (200 == response.code && response.data.currentDisease) {
                        for (var i = 0; i < response.data.currentDisease.length; i++)
                            for (var j = 0; j < $scope.modifiedList.length; j++)
                                if (response.data.currentDisease[i]._id == $scope.modifiedList[j]._id) {
                                    $scope.modifiedList[j].ticked = !0;
                                    break
                                }
                        $scope.visitData.modifiedCurrentDisease = [], $scope.visitData = response.data, $scope.allergies = response.data.allergies.join(" , "), 1 == response.data.isUrgent ? $scope.isUrgent = !0 : $scope.isUrgent = !1
                    } else logger.logError(response.message)
                })
            } else logger.logError(response.message)
        })
    }, $scope.getFamilyDoctor = function () {
        PatientService.getFamilyDoctor().get(function (response) {
            200 == response.code ? $scope.familydoctor = response.data : logger.logError(response.message)
        })
    }, $scope.addPatient = function (patient, isNextStage) {
        $scope.form.$dirty ? (patient.mobileNo = $scope.Mprefix + "-" + $scope.Msuffix, patient.secondaryNo = $scope.Sprefix + "-" + $scope.Ssuffix, patient.patientId && "" != patient.patientId ? PatientService.addPatient().save(patient, function (response) {
            200 == response.code ? (logger.logSuccess(response.message), isNextStage ? $state.go("addNewVisitReason", {
                id: $scope.patientData._id
            }) : $scope.patientData && $scope.patientData._id ? $state.go("addNewVisitReason", {
                id: $scope.patientData._id
            }) : response.data && response.data._id && ($scope.patientData = response.data, $state.go("addNewVisitReason", {
                id: $scope.patientData._id
            }))) : logger.logError(response.message)
        }) : bootbox.confirm("PatientId is not filled. Do you want to autogenerate?", function (result) {
            result && PatientService.addPatient().save(patient, function (response) {
                200 == response.code ? (logger.logSuccess(response.message), isNextStage ? $state.go("addNewVisitReason", {
                    id: $scope.patientData._id
                }) : $scope.patientData && $scope.patientData._id ? $state.go("addNewVisitReason", {
                    id: $scope.patientData._id
                }) : response.data && response.data._id && ($scope.patientData = response.data, $state.go("addNewVisitReason", {
                    id: $scope.patientData._id
                }))) : logger.logError(response.message)
            })
        })) : isNextStage && $state.go("addNewVisitReason", {
            id: $scope.patientData._id
        })
    }, $scope.getKCforpatientId = function () {
        PatientService.getKCforpatientId().get(function (response) {
            200 == response.code ? $scope.kupatCholimlist = response.data : logger.logError(response.message)
        })
    }, $scope.nurseTest = [], $scope.doctorTest = [], $scope.getNurseTestByCurrentDisease = function (id) {
        PatientService.getPatientVisitTest($state.params.id).get(function (response) {
            if (200 == response.code) {
                if ($scope.nurseTest = [], $scope.doctorTest = [], response.data) {
                    if (response.data.nurseTest) {
                        $scope.nurseTest = response.data.nurseTest;
                        for (var i = 0; i < $scope.nurseTest.length; i++) "" == $scope.nurseTest[i].comment ? $scope.nurseTest[i].isChecked = !1 : $scope.nurseTest[i].isChecked = !0
                    }
                    if (response.data.doctorTest) {
                        $scope.doctorTest = response.data.doctorTest;
                        for (var i = 0; i < $scope.doctorTest.length; i++) "" == $scope.doctorTest[i].comment ? $scope.doctorTest[i].isChecked = !1 : $scope.doctorTest[i].isChecked = !0
                    }
                }
            } else logger.logError(response.message)
        })
    }, $scope.addNurseExamination = function (isExitToDashboard, stateToGo) {
        for (var isAlltestperformed = !0, i = 0; i < $scope.nurseTest.length; i++) {
            if (!$scope.nurseTest[i].hasOwnProperty("isChecked")) {
                isAlltestperformed = !1;
                break
            }
            if ($scope.nurseTest[i].isChecked !== !0 || void 0 == $scope.nurseTest[i].comment || "" == $scope.nurseTest[i].comment) {
                isAlltestperformed = !1;
                break
            }
        }
        if (isAlltestperformed) {
            var nurseTestDetails = {};
            nurseTestDetails.visitId = $scope.visitData._id, nurseTestDetails.nurseTest = $scope.nurseTest, nurseTestDetails.refferedTo = $scope.visitData.refferedTo, PatientService.addNurseExamination().save(nurseTestDetails, function (response) {
                200 == response.code ? (logger.logSuccess(response.message), stateToGo ? $state.go(stateToGo, {
                    id: $scope.visitData._id
                }) : $state.go("visitCard", {
                    id: $scope.visitData._id
                })) : logger.logError(response.message)
            })
        } else logger.logWarning("Can not continue unless all tests are confirmed!"), stateToGo ? $state.go(stateToGo, {
            id: $scope.visitData._id
        }) : isExitToDashboard && $state.go("visitCard", {
            id: $scope.visitData._id
        })
    }, $scope.getDoctorList = function () {
        PatientService.getDoctorList().get(function (response) {
            200 == response.code ? $scope.drlist = response.data : logger.logError(response.message)
        })
    }, $scope.tabs = [{
        slug: "basic",
        name: "Basic",
        checked: 3,
        finding: ""
    }, {
        slug: "head",
        name: "Head",
        checked: 3,
        finding: ""
    }, {
        slug: "eent",
        name: "EENT",
        checked: 3,
        finding: ""
    }, {
        slug: "heart",
        name: "Heart",
        checked: 3,
        finding: ""
    }, {
        slug: "lungs",
        name: "Lungs",
        checked: 3,
        finding: ""
    }, {
        slug: "skin",
        name: "Skin",
        checked: 3,
        finding: ""
    }, {
        slug: "abdominal",
        name: "Abdominal",
        checked: 3,
        finding: ""
    }, {
        slug: "neurological",
        name: "Neurological",
        checked: 3,
        finding: ""
    }], $scope.getVisitDoctorExamById = function (id) {
        PatientService.getVisitById($state.params.id).get(function (response) {
            if (response.data.patientId && ($scope.allergies = response.data.patientId.allergies.join(" , ")), 200 == response.code) {
                for (var i = 0; i < response.data.phyExam.length; i++)
                    for (var j = 0; j < $scope.tabs.length; j++) $scope.tabs[j].name == response.data.phyExam[i].name && ($scope.tabs[j].checked = response.data.phyExam[i].value,
                        $scope.tabs[j].finding = response.data.phyExam[i].finding);
                $scope.visitData = response.data
            } else logger.logError(response.message)
        })
    }, $scope.addDoctorExamDetails = function (isExitDashboard, stateToGo) {
        for (var isAlltestperformed = !0, i = 0; i < $scope.doctorTest.length; i++)
            if ($scope.doctorTest[i].isChecked !== !0 || void 0 == $scope.doctorTest[i].comment || "" == $scope.doctorTest[i].comment) {
                isAlltestperformed = !1;
                break
            }
        if (isAlltestperformed) {
            var doctorExamDetails = {};
            doctorExamDetails.visitId = $scope.visitData._id, doctorExamDetails.currentdisease = $scope.visitData.currentdisease, doctorExamDetails.doctorTest = $scope.doctorTest, doctorExamDetails.phyExam = [];
            for (var i = 0; i < $scope.tabs.length; i++) 2 === $scope.tabs[i].checked ? doctorExamDetails.phyExam.push({
                name: $scope.tabs[i].name,
                finding: $scope.tabs[i].finding,
                value: 2
            }) : doctorExamDetails.phyExam.push({
                name: $scope.tabs[i].name,
                finding: "",
                value: $scope.tabs[i].checked
            });
            PatientService.addDoctorExamination().save(doctorExamDetails, function (response) {
                200 == response.code ? (logger.logSuccess(response.message), isExitDashboard ? $state.go("visitCard", {
                    id: $scope.visitData._id
                }) : stateToGo ? $state.go(stateToGo, {
                    id: $scope.visitData._id
                }) : $state.go("doctorOrder", {
                    id: $scope.visitData._id
                })) : logger.logError(response.message)
            })
        } else logger.logWarning("Can not continue unless all tests are confirmed!"), isExitDashboard && $state.go("visitCard", {
            id: $scope.visitData._id
        })
    }, $scope.emcOrders = [], $scope.extOrders = [], $scope.drOrders = [], $scope.getPrescriptionById = function (id) {
        $scope.isExtOrderSaved = !1, PatientService.getPrescriptions($state.params.id).get(function (response) {
            200 == response.code ? response.data && (response.data.emcOrder && ($scope.emcOrders = response.data.emcOrder), response.data.extOrder && ($scope.extOrders = response.data.extOrder, response.data.extOrder.length > 1 && ($scope.isExtOrderSaved = !0))) : logger.logError(response.message)
        })
    }, $scope.duplicatedData = [], $scope.addNewEmcOrders = function () {
        $scope.emcOrders.push({
            dosage: "",
            drugName: "",
            description: "",
            prescriptionAmount: 0,
            props: []
        }), $scope.duplicatedData[$scope.emcOrders.length - 1] = angular.copy($scope.inventoryList)
    }, $scope.removeEmcOrders = function () {
        var newDataList = [];
        $scope.selectedAll = !1, angular.forEach($scope.emcOrders, function (selected) {
            selected.selected || newDataList.push(selected)
        }), $scope.emcOrders = newDataList
    }, $scope.checkAllEmcOrders = function () {
        $scope.selectedAll ? $scope.selectedAll = !1 : $scope.selectedAll = !0, angular.forEach($scope.emcOrders, function (emcOrder) {
            emcOrder.selected = $scope.selectedAll
        })
    }, $scope.addNewExtOrders = function () {
        $scope.extOrders.push({
            dosage: "",
            drugName: "",
            description: "",
            prescriptionAmount: 0
        })
    }, $scope.removeExtOrders = function () {
        var newDataList = [];
        $scope.selectedAll = !1, angular.forEach($scope.extOrders, function (selected) {
            selected.selected || newDataList.push(selected)
        }), $scope.extOrders = newDataList
    }, $scope.checkAllExtOrders = function () {
        $scope.selectedAll ? $scope.selectedAll = !1 : $scope.selectedAll = !0, angular.forEach($scope.extOrders, function (extOrder) {
            extOrder.selected = $scope.selectedAll
        })
    }, $scope.addPrescription = function (isExitDashboard, stateToGo) {
        if ($scope.form.$dirty) {
            var prescriptionDetails = {};
            prescriptionDetails.visitId = $scope.visitData._id, angular.forEach($scope.emcOrders, function (emcOrder, index) {
                "" === emcOrder.drugName && $scope.emcOrders.splice(index, 1)
            }), prescriptionDetails.emcOrder = $scope.emcOrders, prescriptionDetails.extOrder = $scope.extOrders, PatientService.addDoctorPrescription().save(prescriptionDetails, function (response) {
                200 == response.code ? ($scope.extOrders && $scope.extOrders.length > 0 ? $scope.isExtOrderSaved = !0 : $scope.isExtOrderSaved = !1, $scope.getPrescriptionById(), logger.logSuccess(response.message), isExitDashboard ? $state.go("visitCard", {
                    id: $scope.visitData._id
                }) : stateToGo ? $state.go(stateToGo, {
                    id: $scope.visitData._id
                }) : $state.go("doctorResult", {
                    id: $scope.visitData._id
                })) : logger.logError(response.message)
            })
        } else isExitDashboard ? $state.go("visitCard", {
            id: $scope.visitData._id
        }) : stateToGo ? $state.go(stateToGo, {
            id: $scope.visitData._id
        }) : $state.go("doctorResult", {
            id: $scope.visitData._id
        })
    }, $scope.saveDrPresAndIssuePres = function () {
        if ($scope.form.$dirty) {
            var prescriptionDetails = {};
            angular.forEach($scope.emcOrders, function (emcOrder, index) {
                "" === emcOrder.drugName && $scope.emcOrders.splice(index, 1)
            }), prescriptionDetails.visitId = $scope.visitData._id, prescriptionDetails.emcOrder = $scope.emcOrders, prescriptionDetails.extOrder = $scope.extOrders, PatientService.addDoctorPrescription().save(prescriptionDetails, function (response) {
                200 == response.code ? ($scope.getPrescriptionById(), logger.logSuccess(response.message), $scope.issueDocument("Prescription")) : logger.logError(response.message)
            })
        } else $scope.extOrders && $scope.extOrders.length > 0 && $scope.issueDocument("Prescription")
    }, $scope.addDrugNameToEmcOrderItem = function (selectedDrug, OrderIndex) {
        selectedDrug && selectedDrug[0] && ($scope.emcOrders[OrderIndex].drugName = selectedDrug[0].drugName)
    }, $scope.addDosageToEmcOrderItem = function (selectedDosage, OrderIndex) {
        selectedDosage && ($scope.emcOrders[OrderIndex].dosage = selectedDosage)
    }, $scope.getDrugs = function () {
        InventoryService.getDrugs().get(function (response) {
            200 == response.code && ($scope.inventoryList = response.data, $scope.inventoryList.forEach(function (e) {
                e.name = e.drugName, e.ticked = !1
            }))
        })
    }, $scope.paymentItemList = [{
        name: "",
        price: ""
    }], $scope.newPaymentItem = function ($event) {
        $scope.paymentItemList.push({
            name: "",
            price: ""
        }), $event.preventDefault()
    }, $scope.issueInvLoader = !1, $scope.emailInvLoader = !1, $scope.issueInvoice = function (paymentDetails) {
        $scope.issueInvLoader = !0, paymentDetails.visitId = $scope.visitData._id, paymentDetails.itemList = $scope.paymentItemList, PatientService.issueInvoice().save(paymentDetails, function (response) {
            $scope.issueInvLoader = !1, 200 == response.code ? (logger.logSuccess(response.message), $scope.invoiceIssuedData = response.data) : logger.logError(response.message)
        })
    }, $scope.emailInvoice = function () {
        $scope.emailInvLoader = !0;
        var invoiceDetails = {};
        invoiceDetails.visitId = $scope.visitData._id, invoiceDetails.invoiceIssuedData = $scope.invoiceIssuedData, PatientService.emailInvoice().save(invoiceDetails, function (response) {
            $scope.issueInvLoader = !1, 200 == response.code ? logger.logSuccess(response.message) : logger.logError(response.message)
        })
    }, $scope.showVisitPayment = function (id) {
        $state.go("editPayment", {
            id: id
        })
    }, $scope.internalRefferalXray = {}, $scope.internalRefferalBTest = {}, $scope.internalRefUrineTest = {}, $scope.getTreatmentDetails = function () {
        PatientService.getVisitById($state.params.id).get(function (response) {
            if (200 == response.code) {
                for (var i = 0; i < response.data.internalRefferal.length; i++) "XRAY" == response.data.internalRefferal[i].type ? ($scope.internalRefferalXray.typeXray = "XRAY", $scope.xrayComment = !0, $scope.internalRefferalXray.comments = response.data.internalRefferal[i].comment) : "BLOODTEST" == response.data.internalRefferal[i].type ? ($scope.internalRefferalBTest.typeBT = "BLOODTEST", $scope.bTComment = !0, $scope.internalRefferalBTest.comments = response.data.internalRefferal[i].comment) : "URINETEST" == response.data.internalRefferal[i].type && ($scope.internalRefUrineTest.typeUr = "URINETEST", $scope.UrComment = !0, $scope.internalRefUrineTest.comments = response.data.internalRefferal[i].comment);
                $scope.visitData = response.data
            } else logger.logError(response.message)
        })
    }, $scope.saveDrOrderAndIssueInternalRef = function () {
        if ($scope.doctorTreatmentForm.$dirty) {
            var treatmentData = {},
                internalReferalArray = [];
            "XRAY" == $scope.internalRefferalXray.typeXray && (internalReferalArray.push({
                type: $scope.internalRefferalXray.typeXray,
                comment: $scope.internalRefferalXray.comments
            }), treatmentData.internalRefferal = internalReferalArray), "BLOODTEST" == $scope.internalRefferalBTest.typeBT && (internalReferalArray.push({
                type: $scope.internalRefferalBTest.typeBT,
                comment: $scope.internalRefferalBTest.comments
            }), treatmentData.internalRefferal = internalReferalArray), "URINETEST" == $scope.internalRefUrineTest.typeUr && (internalReferalArray.push({
                type: $scope.internalRefUrineTest.typeUr,
                comment: $scope.internalRefUrineTest.comments
            }), treatmentData.internalRefferal = internalReferalArray), treatmentData.visitId = $state.params.id, PatientService.addDoctorOrder().save(treatmentData, function (response) {
                200 == response.code ? ($scope.getVisitById(), logger.logSuccess(response.message), $scope.issueDocument("Internal Referral")) : logger.logError(response.message)
            })
        } else $scope.visitData.internalRefferal && $scope.visitData.internalRefferal.length > 0 && $scope.issueDocument("Internal Referral")
    }, $scope.addDoctorOrder = function (isExitDashboard, stateToGo) {
        if ($scope.doctorTreatmentForm.$dirty) {
            var treatmentData = {},
                internalReferalArray = [];
            "XRAY" == $scope.internalRefferalXray.typeXray && (internalReferalArray.push({
                type: $scope.internalRefferalXray.typeXray,
                comment: $scope.internalRefferalXray.comments
            }), treatmentData.internalRefferal = internalReferalArray), "BLOODTEST" == $scope.internalRefferalBTest.typeBT && (internalReferalArray.push({
                type: $scope.internalRefferalBTest.typeBT,
                comment: $scope.internalRefferalBTest.comments
            }), treatmentData.internalRefferal = internalReferalArray), "URINETEST" == $scope.internalRefUrineTest.typeUr && (internalReferalArray.push({
                type: $scope.internalRefUrineTest.typeUr,
                comment: $scope.internalRefUrineTest.comments
            }), treatmentData.internalRefferal = internalReferalArray), treatmentData.course = $scope.visitData.course, treatmentData.diagonosis = $scope.visitData.diagonosis, treatmentData.internalReferralComments = $scope.visitData.internalReferralComments, treatmentData.visitId = $state.params.id, PatientService.addDoctorOrder().save(treatmentData, function (response) {
                200 == response.code ? ($scope.getVisitById(), logger.logSuccess(response.message), internalReferalArray.length > 0 ? bootbox.confirm({
                    title: "",
                    message: "Do you want to issue internal referral?",
                    buttons: {
                        cancel: {
                            label: '<i class="fa fa-times"></i> No'
                        },
                        confirm: {
                            label: '<i class="fa fa-check"></i>Yes'
                        }
                    },
                    callback: function (result) {
                        result ? ($scope.issueDocument("Internal Referral"), isExitDashboard ? $state.go("visitCard", {
                            id: $scope.visitData._id
                        }) : stateToGo ? $state.go(stateToGo, {
                            id: $scope.visitData._id
                        }) : $state.go("doctorTreatment", {
                            id: $scope.visitData._id
                        })) : isExitDashboard ? $state.go("visitCard", {
                            id: $scope.visitData._id
                        }) : stateToGo ? $state.go(stateToGo, {
                            id: $scope.visitData._id
                        }) : $state.go("doctorTreatment", {
                            id: $scope.visitData._id
                        })
                    }
                }) : isExitDashboard ? $state.go("visitCard", {
                    id: $scope.visitData._id
                }) : stateToGo ? $state.go(stateToGo, {
                    id: $scope.visitData._id
                }) : $state.go("doctorTreatment", {
                    id: $scope.visitData._id
                })) : logger.logError(response.message)
            })
        } else isExitDashboard ? $state.go("visitCard", {
            id: $scope.visitData._id
        }) : stateToGo ? $state.go(stateToGo, {
            id: $scope.visitData._id
        }) : $state.go("doctorTreatment", {
            id: $scope.visitData._id
        })
    }, $scope.visitData = {
        externalRefferedTo: null
    }, $scope.saveTreatmentResultAndIssueInternalRef = function (docResult) {
        docResult.visitId = $state.params.id, $scope.savedExtRef = !1, $scope.form.$dirty && PatientService.addTreatmentResultDetails().save(docResult, function (response) {
            200 == response.code && ($scope.getVisitById(), logger.logSuccess(response.message), $scope.issueDocument("External Referral")), logger.logError(response.message)
        })
    }, $scope.addTreatmentResultDetails = function (docResult, isExitDashboard, stateToGo) {
        docResult.visitId = $state.params.id, $scope.savedExtRef = !1, $scope.form.$dirty ? PatientService.addTreatmentResultDetails().save(docResult, function (response) {
            200 == response.code ? ("External Referral" == docResult.treatmentResultType && ($scope.savedExtRef = !0), logger.logSuccess(response.message), isExitDashboard ? $state.go("visitCard", {
                id: $scope.visitData._id
            }) : stateToGo ? $state.go(stateToGo, {
                id: $scope.visitData._id
            }) : $state.go("visitCard", {
                id: $scope.visitData._id
            })) : logger.logError(response.message)
        }) : isExitDashboard ? $state.go("visitCard", {
            id: $scope.visitData._id
        }) : stateToGo ? $state.go(stateToGo, {
            id: $scope.visitData._id
        }) : $state.go("visitCard", {
            id: $scope.visitData._id
        })
    }, $scope.issueInternalReferral = function () {
        var treatmentData = {};
        treatmentData.visitId = $state.params.id, PatientService.issueInternalReferral().save(treatmentData, function (response) {
            200 == response.code ? logger.logSuccess(response.message) : logger.logError(response.message)
        })
    }, $scope.editPatient = function (patient, isExitDashboard, stateToGo) {
        $scope.form.$dirty ? (patient.mobileNo = $scope.Mprefix + "-" + $scope.Msuffix, patient.secondaryNo = $scope.Sprefix + "-" + $scope.Ssuffix, PatientService.addPatient().save(patient, function (response) {
            200 == response.code ? (logger.logSuccess(response.message), isExitDashboard ? $state.go("visitCard", {
                id: $scope.patient.visitId
            }) : stateToGo ? $state.go(stateToGo, {
                id: $scope.patient.visitId
            }) : $state.go("editVisitReason", {
                id: $scope.patient.visitId
            })) : logger.logError(response.message)
        })) : isExitDashboard ? $state.go("visitCard", {
            id: $scope.patient.visitId
        }) : stateToGo ? $state.go(stateToGo, {
            id: $scope.patient.visitId
        }) : $state.go("editVisitReason", {
            id: $scope.patient.visitId
        })
    }, $scope.issueDocument = function (docType, action) {
        if ("Prescription" == docType && $scope.extOrders && 0 == $scope.extOrders.length) logger.logWarning("No External prescription to issue!");
        else {
            var docData = {};
            docData.visitId = $state.params.id, docData.docType = docType, action && 1 != $scope.issuedocChecked || ($scope.loader = !0), PatientService.issueDocument().save(docData, function (response) {
                if ($scope.loader = !1, 200 == response.code) {
                    if (!action || 1 == $scope.issuedocChecked)
                        for (var i = 0; i < response.data.length; i++) $http.get(baseUrl + "/getdoc/" + response.data[i]).success(function (data) {
                            if ("" == data || void 0 == data) logger.logError("Falied to open PDF.");
                            else if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                                for (var byteCharacters = atob(data), byteNumbers = new Array(byteCharacters.length), i = 0; i < byteCharacters.length; i++) byteNumbers[i] = byteCharacters.charCodeAt(i);
                                var byteArray = new Uint8Array(byteNumbers),
                                    blob = new Blob([byteArray], {
                                        type: "application/pdf"
                                    });
                                window.navigator.msSaveOrOpenBlob(blob, fileName)
                            } else {
                                for (var base64EncodedPDF = data, BASE64_MARKER = ";base64,", dataURI = "data:application/pdf;base64," + base64EncodedPDF, base64Index = dataURI.indexOf(BASE64_MARKER) + BASE64_MARKER.length, base64 = dataURI.substring(base64Index), raw = window.atob(base64), rawLength = raw.length, array = new Uint8Array(new ArrayBuffer(rawLength)), i = 0; i < rawLength; i++) array[i] = raw.charCodeAt(i);
                                var blob = new Blob([array], {
                                        type: "application/pdf"
                                    }),
                                    fileurl = window.URL.createObjectURL(blob);
                                window.open(fileurl, "_blank"), window.close(fileurl)
                            }
                        });
                    1 == action ? $scope.sendSummaryToFamilyDoctor() : 2 == action ? $scope.closeVisitAndSendSurvey() : 3 == action ? ($scope.sendSummaryToFamilyDoctor(), $scope.closeVisitAndSendSurvey()) : logger.logSuccess(response.message)
                } else logger.logError(response.message)
            })
        }
    }, $scope.getVisitDocumentInfoById = function () {
        PatientService.getVisitDocumentInfoById($state.params.id).get(function (response) {
            200 == response.code ? $scope.visitDocumentData = response.data : logger.logError(response.message)
        })
    }, $scope.uploadFile = function (file) {
        var visitId = $scope.visitData._id;
        $scope.loader = !0, Upload.upload({
            url: baseUrl + "/api/uploadFile",
            data: {
                file: file,
                visitId: visitId
            }
        }).then(function (resp) {
            $scope.loader = !1, resp.data && 200 == resp.data.code ? (logger.logSuccess(resp.data.message), $scope.getVisitDocumentInfoById()) : logger.logError(resp.data.message)
        })
    }, $scope.download = function (document_id) {
        var id = document_id + "_" + $scope.visitData._id;
        $window.open(baseUrl + "/download-file/" + id, "_blank")
    }, $scope.viewVisitDocument = function (document_id) {
        var id = document_id + "_" + $scope.visitData._id;
        $http.get(baseUrl + "/viewVisitDocument/" + id).success(function (data) {
            if ("" == data || void 0 == data) logger.logError("Falied to open PDF.");
            else if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                for (var byteCharacters = atob(data), byteNumbers = new Array(byteCharacters.length), i = 0; i < byteCharacters.length; i++) byteNumbers[i] = byteCharacters.charCodeAt(i);
                var byteArray = new Uint8Array(byteNumbers),
                    blob = new Blob([byteArray], {
                        type: "application/pdf"
                    });
                window.navigator.msSaveOrOpenBlob(blob, fileName)
            } else {
                for (var base64EncodedPDF = data, BASE64_MARKER = ";base64,", dataURI = "data:application/pdf;base64," + base64EncodedPDF, base64Index = dataURI.indexOf(BASE64_MARKER) + BASE64_MARKER.length, base64 = dataURI.substring(base64Index), raw = window.atob(base64), rawLength = raw.length, array = new Uint8Array(new ArrayBuffer(rawLength)), i = 0; i < rawLength; i++) array[i] = raw.charCodeAt(i);
                var blob = new Blob([array], {
                        type: "application/pdf"
                    }),
                    fileurl = window.URL.createObjectURL(blob);
                window.open(fileurl, "_blank", ""), window.close(fileurl)
            }
        })
    }, $scope.closeVisitAndSendSurvey = function (action) {
        var details = {
            visitId: $state.params.id
        };
        $scope.visitData && PatientService.checkVisitPaymentDone().save(details, function (response) {
            1 == response.data ? ($scope.issueDocument("Treatment Summary", action), PatientService.closeVisitAndSendSurvey().save(details, function (response) {
                200 == response.code ? (logger.logSuccess(response.message), $state.go("visitCard", {
                    id: $state.params.id
                })) : logger.logError(response.message)
            })) : bootbox.confirm("Are you sure you want to close visit? Patient did not pay yet.", function (result) {
                result ? ($scope.issueDocument("Treatment Summary", action), PatientService.closeVisitAndSendSurvey().save(details, function (response) {
                    200 == response.code ? (logger.logSuccess(response.message), $state.go("visitCard", {
                        id: $state.params.id
                    })) : logger.logError(response.message)
                })) : $state.go("visitCard", {
                    id: $state.params.id
                })
            })
        })
    }, $scope.issuedocChecked = !0, $scope.sendMailToFamilyDrChecked = !0, $scope.closeVistChecked = !0, $scope.submitSummary = function (visitCard, isExitToDashboard) {
        var action = 0;
        1 == $scope.issuedocChecked && 0 == $scope.sendMailToFamilyDrChecked && 0 == $scope.closeVistChecked ? ($scope.issueDocument("Treatment Summary"), $location.path("/visitCard/" + visitCard)) : 1 == $scope.issuedocChecked && 1 == $scope.sendMailToFamilyDrChecked && 0 == $scope.closeVistChecked ? (action = 1, $scope.issueDocument("Treatment Summary", action), $location.path("/visitCard/" + visitCard)) : 0 == $scope.sendMailToFamilyDrChecked && 1 == $scope.closeVistChecked ? $scope.closeVisitAndSendSurvey() : 0 == $scope.issuedocChecked && 1 == $scope.sendMailToFamilyDrChecked && 0 == $scope.closeVistChecked ? (action = 1, $scope.issueDocument("Treatment Summary", action), $location.path("/visitCard/" + visitCard)) : 1 == $scope.sendMailToFamilyDrChecked && 1 == $scope.closeVistChecked ? (action = 1, $scope.closeVisitAndSendSurvey(1)) : 0 == $scope.issuedocChecked && 0 == $scope.sendMailToFamilyDrChecked && 0 == $scope.closeVistChecked ? ($scope.issueDocument("Treatment Summary"), $location.path("/visitCard/" + visitCard)) : $location.path("/visitCard/" + visitCard)
    }, $scope.searchPatientVisitTextField = "", $scope.searchPatientVisits = function () {
        ("YES" === $scope.showFilteredStatus || "NO" === $scope.showFilteredStatus && "" == $scope.searchPatientVisitTextField) && (ngTableParamsService.set("", "", $scope.searchPatientVisitTextField, ""), $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchPatientVisitTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.completedVisitList = [], $scope.paramUrl.visitId = $state.params.id, PatientService.getPatientVisitHistory().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.completedVisitList = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        }))
    }, $scope.getPatientVisitHistory = function () {
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchPatientVisitTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.completedVisitList = [], $scope.paramUrl.visitId = $state.params.id, PatientService.getPatientVisitHistory().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.completedVisitList = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.showFilteredStatus = "NO", $scope.checkFilteredStatus = function (filter) {
        $scope.showFilteredStatus = filter, "NO" == filter && ($scope.searchPatientVisitTextField = "", $scope.searchPatientVisits()), "YES" == filter && $scope.searchPatientVisits()
    }, $scope.searchVisitHistoryTextField = "", $scope.showHistoryStatus = "NO", $scope.checkHistoryStatus = function (filter) {
        $scope.showHistoryStatus = filter, "NO" == filter && ($scope.searchVisitHistoryTextField = "", $scope.searchVisitHistory()), "YES" == filter && $scope.searchVisitHistory()
    }, $scope.searchVisitHistory = function () {
        ("YES" === $scope.showHistoryStatus || "NO" === $scope.showHistoryStatus && "" == $scope.searchVisitHistoryTextField) && (ngTableParamsService.set("", "", $scope.searchVisitHistoryTextField, ""), $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchVisitHistoryTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.closedVisitList = [], PatientService.getVisitHistory().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.closedVisitList = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        }))
    }, $scope.getVisitHistory = function () {
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchVisitHistoryTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.closedVisitList = [], PatientService.getVisitHistory().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.closedVisitList = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.updateStatus = function (visitId, status, page) {
        var visitDetails = {
            visitId: visitId,
            status: status
        };
        PatientService.updateStatus().save(visitDetails, function (response) {
            200 == response.code ? $location.path("/" + page + "/" + $scope.visitData._id) : logger.logError(response.message)
        })
    }, $scope.decrementPatientWaitCount = function (visitId) {
        var visitDetails = {
            visitId: visitId
        };
        PatientService.decrementPatientWaitCount().save(visitDetails, function (response) {
            200 == response.code
        })
    }, $scope.getStageInfoById = function () {
        $scope.$emit("start", !0), PatientService.getStageInfoById($state.params.id).get(function (response) {
            200 == response.code ? response.data && response.data.stages && response.data.mainStage && ($scope.stageData = response.data.stages, $scope.mainStages = response.data.mainStage) : logger.logError(response.message), $scope.$emit("stop", !0)
        })
    }, $scope.isStageCompleted = function (stageName) {
        var found = !1;
        if ($scope.stageData) {
            for (var stageList = $scope.stageData, i = 0; i < stageList.length; i++)
                if (stageList[i].name == stageName && 1 == stageList[i].isCompleted) {
                    found = !0;
                    break
                }
            return found
        }
    }, $scope.getStageDateTime = function (stageName) {
        var found = 0,
            returnTime = "";
        if ($scope.stageData)
            for (var stageList = $scope.stageData, i = 0; i < stageList.length; i++) stageList[i].name == stageName && (found = 1, returnTime = stageList[i].updatedAt);
        return returnTime
    }, $scope.getMainStageDateTime = function (stageName) {
        if ($scope.stageData)
            for (var stageList = $scope.mainStages, i = 0; i < stageList.length; i++)
                if (stageList[i].name == stageName) return stageList[i].updatedAt
    }, $scope.getPatientEmcPrescription = function () {
        PatientService.getPrescriptions($state.params.id).get(function (response) {
            200 == response.code ? response.data && response.data.emcOrder && ($scope.emcOrders = response.data.emcOrder) : logger.logError(response.message)
        })
    }, $scope.givePrescriptionOnSomeClick = function ($index) {
        $scope.emcOrders[$index].isSomeClick = !0
    }, $scope.addPatientDrugs = function (isExitDashboard) {
        var prescriptionDetails = {};
        prescriptionDetails.visitId = $scope.visitData._id, prescriptionDetails.emcOrder = $scope.emcOrders, PatientService.addPatientDrugs().save(prescriptionDetails, function (response) {
            200 == response.code ? (logger.logSuccess(response.message), isExitDashboard ? $state.go("visitCard", {
                id: $scope.visitData._id
            }) : $state.go("summary", {
                id: $scope.visitData._id
            })) : logger.logError(response.message)
        })
    }, $scope.Yes = "", $scope.Yes = function (index) {
        $scope.emcOrders[index].Yes = "yes", $scope.emcOrders[index].Some = "", $scope.emcOrders[index].No = ""
    }, $scope.Some = "", $scope.Some = function (index) {
        $scope.emcOrders[index].Yes = "", $scope.emcOrders[index].Some = "some", $scope.emcOrders[index].No = ""
    }, $scope.No = "", $scope.No = function (index) {
        $scope.emcOrders[index].Yes = "", $scope.emcOrders[index].Some = "", $scope.emcOrders[index].No = "No"
    }, $scope.sendSummaryToFamilyDoctor = function () {
        $scope.sendSummaryLoader = !0;
        var details = {
            visitId: $state.params.id
        };
        PatientService.sendSummaryToFamilyDoctor().save(details, function (response) {
            $scope.sendSummaryLoader = !1, 200 == response.code ? logger.logSuccess(response.message) : 402 == response.code && logger.log(response.message)
        })
    }, $scope.disableAlert = function () {
        var details = {
            visitId: $state.params.id
        };
        PatientService.disableAlert().save(details, function (response) {
            200 == response.code
        })
    }, $scope.newVisitCommentList = [], $scope.addBlankVisitComment = function ($event) {
        var comment = {
            comment: "",
            open: !0
        };
        $scope.visitCommentList.push(comment), $scope.newVisitCommentList.push(comment), $event.preventDefault()
    }, $scope.addVisitComment = function (isExitDashboard) {
        if ($scope.form.$dirty) {
            var visitDetails = {};
            visitDetails.visitComment = [], visitDetails.visitComment = $scope.newVisitCommentList, visitDetails.visitId = $scope.visitData._id, PatientService.addVisitComment().save(visitDetails, function (response) {
                200 == response.code ? (logger.logSuccess(response.message), $scope.newVisitCommentList = [], $scope.getVisitById(), isExitDashboard && $state.go("visitCard", {
                    id: $scope.visitData._id
                })) : logger.logError(response.message)
            })
        } else isExitDashboard && $state.go("visitCard", {
            id: $scope.visitData._id
        })
    }, $scope.billList = [], $scope.newBillList = [], $scope.disabled = !0, $scope.disabled_printInv = !0, $scope.newPaymentItem = function (index) {
        $scope.billList[index].billableItems.push({
            name: "",
            price: 0
        }), $scope.newBillList = $scope.billList
    }, $scope.removeBillableItem = function (parentIndex, index) {
        $scope.billList[parentIndex].billableItems.splice(index, 1)
    }, $scope.addNewPaymentGroup = function ($event) {
        var paymentItem = {
            visitPayment: $scope.visitPrice,
            billableItems: [],
            isBillPayed: !1,
            previousDebt: $scope.visitData.patientId.previousDebt,
            open: !0
        };
        $scope.billList.push(paymentItem), $event.preventDefault()
    }, $scope.savePaymentDetails = function () {
        var paymentDetails = {};
        paymentDetails.billList = [];
        for (var i = 0; i < $scope.billList.length; i++) "none" !== $scope.billList[i].paymentType && ($scope.billList[i].isBillPayed = !0);
        paymentDetails.billList = $scope.billList, paymentDetails.visitId = $scope.visitData._id, PatientService.savePaymentDetails().save(paymentDetails, function (response) {
            200 == response.code ? (response.data && ($scope.billList = response.data.billList), logger.logSuccess(response.message)) : logger.logError(response.message)
        })
    }, $scope.getPaymentDetailsByVisitId = function () {
        PatientService.getPaymentDetailsByVisitId($state.params.id).get(function (response) {
            200 == response.code ? (response.data && response.data.paymentInfo && response.data.paymentInfo.billList && ($scope.billList = response.data.paymentInfo.billList), $scope.visitPrice = response.data.visitPrice) : logger.logError(response.message)
        })
    }, $scope.sum = function (list, kupatPrice, previousDebt) {
        "undefined" != typeof kupatPrice && kupatPrice || (kupatPrice = 0), "undefined" != typeof previousDebt && previousDebt || (previousDebt = 0);
        var total = kupatPrice + previousDebt;
        return angular.forEach(list, function (item) {
            total += parseInt(item.price)
        }), total
    }, $scope.issueInvLoader = !1, $scope.emailInvLoader = !1, $scope.issueInvoice = function (billData) {
        var paymentDetails = {};
        $scope.paymentData || "cash" == billData.paymentType ? ("cash" == billData.paymentType && ($scope.paymentData = {}), paymentDetails.visitId = $scope.visitData._id, $scope.paymentData.billData = billData, paymentDetails.paymentData = $scope.paymentData, $scope.issueInvLoader = !0, PatientService.issueInvoice().save(paymentDetails, function (response) {
            $scope.issueInvLoader = !1, 200 == response.code ? ($scope.getPaymentDetailsByVisitId(), logger.logSuccess(response.message), $scope.invoiceIssuedData = response.data, $scope.invoiceIssuedData && $scope.invoiceIssuedData.doc_url && ($scope.disabled_printInv = !1)) : logger.logError(response.message)
        })) : bootbox.confirm("Please Select payment mode  and fill details of payment to issue invoice.", function (result) {})
    }, $scope.emailInvoice = function (billData) {
        $scope.emailInvLoader = !0;
        var invoiceDetails = {};
        invoiceDetails.visitId = $scope.visitData._id, 1 == billData.isDocIssued ? invoiceDetails.invoiceIssuedData = billData.invoiceIssuedData : invoiceDetails.invoiceIssuedData = $scope.invoiceIssuedData, PatientService.emailInvoice().save(invoiceDetails, function (response) {
            $scope.emailInvLoader = !1, 200 == response.code ? logger.logSuccess(response.message) : logger.logError(response.message)
        })
    }, $scope.printInvoice = function (billData) {
        1 == billData.isDocIssued ? window.open(billData.invoiceIssuedData.doc_url, "_blank") : window.open($scope.invoiceIssuedData.doc_url, "_blank")
    }, $scope.enableInvoiceButton = function (paymentType, billData) {
        "cash" == paymentType && ($scope.disabled = !1, $scope.paymentData = {
            billData: billData,
            paidWithInfo: {}
        })
    }, $scope.searchDebtTextField = "", $scope.showDebtStatus = "NO", $scope.checkDebtStatus = function (filter) {
        $scope.showDebtStatus = filter, "NO" == filter && ($scope.searchDebtTextField = "", $scope.searchPatientDebt()), "YES" == filter && $scope.searchPatientDebt()
    }, $scope.searchPatientDebt = function () {
        ("YES" === $scope.showDebtStatus || "NO" === $scope.showDebtStatus && "" == $scope.searchDebtTextField) && (ngTableParamsService.set("", "", $scope.searchDebtTextField, ""), $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchDebtTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.debtList = [], PatientService.getPatientDebt().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.debtList = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        }))
    }, $scope.getViewVisitDetailsById = function (id) {
        PatientService.getVisitById($state.params.id).get(function (response) {
            if ($scope.selectedDiseaseList = [], 200 == response.code) {
                if (response.data.currentDisease)
                    for (var i = 0; i < response.data.currentDisease.length; i++) $scope.selectedDiseaseList.push(response.data.currentDisease[i].name);
                $scope.visitData = response.data, $scope.visitData && ($scope.allergies = response.data.allergies.join(" , ")), 1 == response.data.isUrgent ? $scope.isUrgent = !0 : $scope.isUrgent = !1
            }
        })
    }, $scope.getPatientDebt = function () {
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchDebtTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.debtList = [], PatientService.getPatientDebt().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.debtList = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.initializeDatepicker = function () {
        $("#dateRange").daterangepicker({
            autoApply: !0
        })
    }, $scope.timeRange = "2", $scope.getPatientDashboardCount = function () {
        var dateRange = angular.element($("#dateRange")).val(),
            details = {
                timeRangeType: $scope.timeRange,
                dateRange: dateRange
            };
        PatientService.getdashboardCount().get(details, function (response) {
            200 == response.code && ($scope.counts = response.data)
        })
    }, $scope.items = ["item1", "item"], $scope.openDilogue = function (a, id) {
        var modalInstance;
        modalInstance = $modal.open({
            templateUrl: "/modules/patient/Modals/" + a + "Modal.html",
            controller: "ModalInstanceCtrl",
            resolve: {
                items: function () {
                    return {
                        id: id
                    }
                }
            }
        })
    }, $scope.visitbyId = function () {
        PatientService.visitbyId($state.params.id).get(function (response) {
                if (200 == response.code) {
                    $scope.patient = response.data;
                    var arr2 = $scope.patient.secondaryNo.split("-"),
                        Sprefix = "",
                        Ssuffix = "";
                    2 == arr2.length ? (Sprefix = arr2[0], Ssuffix = arr2[1]) : 1 == arr2.length && (Ssuffix = arr2[0], Sprefix = ""), $scope.Sprefix = Sprefix, $scope.Ssuffix = Ssuffix;
                    var arr = $scope.patient.mobileNo.split("-"),
                        Mprefix = "",
                        Msuffix = "";
                    2 == arr.length ? (Mprefix = arr[0], Msuffix = arr[1]) : 1 == arr.length && (Msuffix = arr[0], Mprefix = ""),
                        $scope.Mprefix = Mprefix, $scope.Msuffix = Msuffix, $scope.patient.kupatCholim = $scope.patient.kupatCholim._id, $scope.patient.familyDoctorId && ($scope.patient.familyDoctorId = $scope.patient.familyDoctorId._id)
                } else logger.logError(response.message)
            }),
            function (response) {
                logger.logError(response.message)
            }
    }, $scope.addDoctorTreatment = function (isExitDashboard, stateToGo) {
        if ($scope.doctorTreatmentForm.$dirty) {
            var treatmentData = {};
            treatmentData.course = $scope.visitData.course, treatmentData.diagonosis = $scope.visitData.diagonosis, treatmentData.internalReferralComments = $scope.visitData.internalReferralComments, treatmentData.visitId = $state.params.id, PatientService.addDoctorTreatment().save(treatmentData, function (response) {
                200 == response.code ? ($scope.getVisitById(), logger.logSuccess(response.message), isExitDashboard ? $state.go("visitCard", {
                    id: $scope.visitData._id
                }) : stateToGo ? $state.go(stateToGo, {
                    id: $scope.visitData._id
                }) : $state.go("doctorPrescription", {
                    id: $scope.visitData._id
                })) : logger.logError(response.message)
            })
        } else isExitDashboard ? $state.go("visitCard", {
            id: $scope.visitData._id
        }) : stateToGo ? $state.go(stateToGo, {
            id: $scope.visitData._id
        }) : $state.go("doctorPrescription", {
            id: $scope.visitData._id
        })
    }, $scope.openPaymentModal = function (paymentType, billData) {
        var modalInstance;
        "cash" == paymentType && ($scope.disabled = !1), $scope.paymentData = {
            paidWithInfo: {}
        }, modalInstance = $modal.open({
            templateUrl: "/modules/patient/Modals/" + paymentType + "Modal.html",
            controller: "PaymentModalInstanceCtrl",
            resolve: {
                paymentData: function () {
                    return $scope.paymentData
                }
            }
        }), modalInstance.result.then(function (paymentData) {
            $scope.disabled = !Object.keys($scope.paymentData.paidWithInfo).length
        }, function () {})
    }, $scope.patient = {}, $scope.patientData = {}, $scope.ageCalculate = function (dob) {
        var age = {},
            today = new Date,
            birthDate = new Date(dob),
            year = today.getFullYear() - birthDate.getFullYear(),
            month = today.getMonth() - birthDate.getMonth(),
            day = today.getDate() - birthDate.getDate();
        month < 0 && (year--, month = 12 + month), today.getDate() < birthDate.getDate() && (month--, day = 30 + day), age.month = month >= 0 ? month : 0, age.day = day >= 0 ? day : 0, age.year = year >= 0 ? year : 0, $scope.patientData.age = age, $scope.patient.age = age
    }
}]), MCSIApp.controller("PaymentModalInstanceCtrl", ["$scope", "$rootScope", "$localStorage", "$location", "$translate", "HomeService", "$modal", "$modalInstance", "PatientService", "paymentData", function ($scope, $rootScope, $localStorage, $location, $translate, HomeService, $modal, $modalInstance, PatientService, paymentData) {
    $scope.currentDate = new Date, $scope.paymentData = paymentData, $scope.cancel = function () {
        $modalInstance.dismiss("cancel")
    }, $scope.ok = function () {
        $modalInstance.close($scope.paymentData)
    }
}]), MCSIApp.controller("ModalInstanceCtrl", ["$scope", "$rootScope", "$location", "$modalInstance", "$localStorage", "$filter", "$modal", "$http", "$window", "ngTableParams", "ngTableParamsService", "$state", "logger", "CommonService", "PatientService", "Upload", "DiseaseService", "items", function ($scope, $rootScope, $location, $modalInstance, $localStorage, $filter, $modal, $http, $window, ngTableParams, ngTableParamsService, $state, logger, CommonService, PatientService, Upload, DiseaseService, items) {
    $scope.visitReason = {}, $scope.newvisitReason = {}, $scope.visitReason.isUrgent = 0, $scope.newvisitReason.isUrgent = 0, $scope.tabs = [{
        slug: "basic",
        name: "Basic",
        checked: 3,
        finding: ""
    }, {
        slug: "head",
        name: "Head",
        checked: 3,
        finding: ""
    }, {
        slug: "eent",
        name: "EENT",
        checked: 3,
        finding: ""
    }, {
        slug: "heart",
        name: "Heart",
        checked: 3,
        finding: ""
    }, {
        slug: "lungs",
        name: "Lungs",
        checked: 3,
        finding: ""
    }, {
        slug: "skin",
        name: "Skin",
        checked: 3,
        finding: ""
    }, {
        slug: "abdominal",
        name: "Abdominal",
        checked: 3,
        finding: ""
    }, {
        slug: "neurological",
        name: "Neurological",
        checked: 3,
        finding: ""
    }], $scope.getVisitById = function () {
        var diseaseName = [];
        PatientService.getVisitById($state.params.id).get(function (response) {
            if (200 == response.code) {
                $scope.visitData = response.data, $scope.patientData = response.patientData, response.data.patientId && ($scope.allergies = response.data.patientId.allergies.join(" , "));
                for (var i = 0; i < response.data.currentDisease.length; i++) diseaseName.push(response.data.currentDisease[i].name);
                $scope.diseaseName = diseaseName.join(" , "), $scope.patient = $scope.visitData.patientId;
                var extreferral = $scope.visitData.treatmentResultType;
                "External Referral" == extreferral && ($scope.extreferral = !0), 1 == response.data.isUrgent ? $scope.isUrgent = !0 : $scope.isUrgent = !1, $scope.visitCommentList = $scope.visitData.visitComment, $scope.visitData.refferedTo && PatientService.getDoctorList().get(function (response) {
                    if (200 == response.code) {
                        $scope.drlist = response.data;
                        for (var i = 0; i < $scope.drlist.length; i++) $scope.drlist[i].id._id == $scope.visitData.refferedTo && ($scope.doctorName = $scope.drlist[i].id.firstname + "   " + $scope.drlist[i].id.lastname)
                    } else logger.logError(response.message)
                })
            } else logger.logError(response.message)
        })
    }, $scope.getVisitDetailsById = function (id) {
        DiseaseService.getalldisease().get(function (response) {
            if (200 == response.code) {
                $scope.diseaselist = response.data, $scope.modifiedList = [];
                for (var i = 0; i < $scope.diseaselist.length; i++) {
                    var obj = {
                        _id: $scope.diseaselist[i]._id,
                        name: $scope.diseaselist[i].name,
                        ticked: !1
                    };
                    $scope.modifiedList.push(obj)
                }
                PatientService.getVisitById($state.params.id).get(function (response) {
                    if (200 == response.code && response.data.currentDisease) {
                        for (var i = 0; i < response.data.currentDisease.length; i++)
                            for (var j = 0; j < $scope.modifiedList.length; j++)
                                if (response.data.currentDisease[i]._id == $scope.modifiedList[j]._id) {
                                    $scope.modifiedList[j].ticked = !0;
                                    break
                                }
                        $scope.visitData = response.data, $scope.visitData && ($scope.visitData.modifiedCurrentDisease = [], $scope.allergies = response.data.allergies.join(" , ")), 1 == response.data.isUrgent ? $scope.isUrgent = !0 : $scope.isUrgent = !1
                    } else logger.logError(response.message)
                })
            } else logger.logError(response.message)
        })
    }, $scope.getViewVisitDetailsById = function (id) {
        PatientService.getVisitById($state.params.id).get(function (response) {
            if ($scope.selectedDiseaseList = [], 200 == response.code) {
                if (response.data.currentDisease)
                    for (var i = 0; i < response.data.currentDisease.length; i++) $scope.selectedDiseaseList.push(response.data.currentDisease[i].name);
                $scope.visitData = response.data, $scope.visitData && ($scope.allergies = response.data.allergies.join(" , ")), 1 == response.data.isUrgent ? $scope.isUrgent = !0 : $scope.isUrgent = !1
            }
        })
    }, $scope.cancel = function () {
        $modalInstance.dismiss("cancel")
    }, $scope.getFamilyDoctor = function () {
        PatientService.getFamilyDoctor().get(function (response) {
            200 == response.code ? $scope.familydoctor = response.data : logger.logError(response.message)
        })
    }, $scope.getStageInfoById = function () {
        $scope.$emit("start", !0), PatientService.getStageInfoById($state.params.id).get(function (response) {
            200 == response.code ? response.data && response.data.stages && response.data.mainStage && ($scope.stageData = response.data.stages, $scope.mainStages = response.data.mainStage) : logger.logError(response.message), $scope.$emit("stop", !0)
        })
    }, $scope.nurseTest = [], $scope.doctorTest = [], $scope.getNurseTestByCurrentDisease = function (id) {
        PatientService.getPatientVisitTest($state.params.id).get(function (response) {
            if (200 == response.code) {
                if ($scope.nurseTest = [], $scope.doctorTest = [], response.data) {
                    if (response.data.nurseTest) {
                        $scope.nurseTest = response.data.nurseTest;
                        for (var i = 0; i < $scope.nurseTest.length; i++) "" == $scope.nurseTest[i].comment ? $scope.nurseTest[i].isChecked = !1 : $scope.nurseTest[i].isChecked = !0
                    }
                    if (response.data.doctorTest) {
                        $scope.doctorTest = response.data.doctorTest;
                        for (var i = 0; i < $scope.doctorTest.length; i++) "" == $scope.doctorTest[i].comment ? $scope.doctorTest[i].isChecked = !1 : $scope.doctorTest[i].isChecked = !0
                    }
                }
            } else logger.logError(response.message)
        })
    }, $scope.getDoctorList = function () {
        PatientService.getDoctorList().get(function (response) {
            if (200 == response.code) {
                $scope.drlist = response.data;
                for (var i = 0; i < $scope.drlist.length; i++) $scope.drlist[i]._id == $scope.visitData.refferedTo && ($scope.doctorName = $scope.drlist[i].firstname + "   " + $scope.drlist[i].lastname)
            } else logger.logError(response.message)
        })
    }, $scope.getTriageTestByVisitId = function (id) {
        PatientService.getTriageTestByVisitId($state.params.id).get(function (response) {
            200 == response.code ? response.data && response.data.triageTest && ($scope.triageData = response.data, $scope.triageTestList = response.data.triageTest) : logger.logError(response.message)
        })
    }, $scope.getVisitDoctorExamById = function (id) {
        PatientService.getVisitById($state.params.id).get(function (response) {
            if (response.data.patientId && ($scope.allergies = response.data.patientId.allergies.join(" , ")), 200 == response.code) {
                for (var i = 0; i < response.data.phyExam.length; i++)
                    for (var j = 0; j < $scope.tabs.length; j++) $scope.tabs[j].checked = response.data.phyExam[j].value, $scope.tabs[j].finding = response.data.phyExam[j].finding;
                $scope.visitData = response.data
            } else logger.logError(response.message)
        })
    }, $scope.getPatientEmcPrescription = function () {
        PatientService.getPrescriptions($state.params.id).get(function (response) {
            200 == response.code ? response.data && response.data.emcOrder && ($scope.emcOrders = response.data.emcOrder) : logger.logError(response.message)
        })
    }, $scope.emcOrders = [], $scope.extOrders = [], $scope.drOrders = [], $scope.getPrescriptionById = function (id) {
        $scope.isExtOrderSaved = !1, PatientService.getPrescriptions($state.params.id).get(function (response) {
            200 == response.code ? response.data && (response.data.emcOrder && ($scope.emcOrders = response.data.emcOrder), response.data.extOrder && ($scope.extOrders = response.data.extOrder, response.data.extOrder.length > 1 && ($scope.isExtOrderSaved = !0))) : logger.logError(response.message)
        })
    }, $scope.getPaymentDetailsByVisitId = function () {
        PatientService.getPaymentDetailsByVisitId($state.params.id).get(function (response) {
            if (200 == response.code) {
                response.data && response.data.paymentInfo && response.data.paymentInfo.billList && ($scope.billList = response.data.paymentInfo.billList);
                for (var i = 0; i < $scope.billList.length; i++) {
                    for (var billableItems = $scope.billList[i].billableItems, total = 0, j = 0; j < billableItems.length; j++) total += billableItems[j].price;
                    $scope.billList[i].total = total + $scope.billList[i].previousDebt + $scope.billList[i].visitPayment
                }
            } else logger.logError(response.message)
        })
    }
}]), angular.module("Patients").factory("PatientService", ["$http", "communicationService", "$resource", function ($http, communicationService, $resource) {
    var getActivePatientList = function () {
            return $resource("/api/getActivePatientList", null, {
                get: {
                    method: "POST"
                }
            })
        },
        getPatientList = function () {
            return $resource("/api/getAllPatient", null, {
                get: {
                    method: "GET"
                }
            })
        },
        getPatientById = function (id) {
            return $resource("/api/getPatientById/" + id, null, {
                get: {
                    method: "GET",
                    id: "@id"
                }
            })
        },
        getVisitById = function (id) {
            return $resource("/api/getVisitById/" + id, null, {
                get: {
                    method: "GET",
                    id: "@id"
                }
            })
        },
        addVisitReason = function () {
            return $resource("/api/addVisitReason", null, {
                save: {
                    method: "POST"
                }
            })
        },
        addNewVisitReason = function () {
            return $resource("/api/addNewVisitReason", null, {
                save: {
                    method: "POST"
                }
            })
        },
        addVisitDetails = function () {
            return $resource("/api/addVisitDetails", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getFamilyDoctor = function () {
            return $resource("/api/getFamilyDoctor", null, {
                get: {
                    method: "GET"
                }
            })
        },
        getKCforpatientId = function () {
            return $resource("/api/getKCforpatientId", null, {
                get: {
                    method: "GET"
                }
            })
        },
        addTriageDetails = function () {
            return $resource("/api/addTriage", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getTriageTestByVisitId = function (id) {
            return $resource("/api/getTriageTestByVisitId/" + id, null, {
                get: {
                    method: "GET",
                    id: "@id"
                }
            })
        },
        addPatient = function () {
            return $resource("/api/addPatient", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getPatientVisitTest = function (id) {
            return $resource("/api/getPatientVisitTest/" + id, null, {
                get: {
                    method: "GET",
                    id: "@id"
                }
            })
        },
        addNurseExamination = function () {
            return $resource("/api/addNurseExamination", null, {
                save: {
                    method: "POST"
                }
            })
        },
        addDoctorExamination = function () {
            return $resource("/api/addDoctorExamination", null, {
                save: {
                    method: "POST"
                }
            })
        },
        addDoctorPrescription = function () {
            return $resource("/api/addDoctorPrescription", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getPrescriptions = function (id) {
            return $resource("/api/getPrescriptions/" + id, null, {
                get: {
                    method: "GET",
                    id: "@id"
                }
            })
        },
        issueInvoice = function () {
            return $resource("/api/issueInvoice", null, {
                save: {
                    method: "POST"
                }
            })
        },
        emailInvoice = function () {
            return $resource("/api/emailInvoice", null, {
                save: {
                    method: "POST"
                }
            })
        },
        addTreatmentDetails = function () {
            return $resource("/api/addTreatmentDetails", null, {
                save: {
                    method: "POST"
                }
            })
        },
        addTreatmentResultDetails = function () {
            return $resource("/api/addTreatmentResultDetails", null, {
                save: {
                    method: "POST"
                }
            })
        },
        issueInternalReferral = function () {
            return $resource("/api/issueInternalReferral", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getDoctorList = function () {
            return $resource("/api/getDoctorList", null, {
                get: {
                    method: "GET"
                }
            })
        },
        getPatientDashboardCount = function () {
            return $resource("/api/patientDashboardCount", null, {
                get: {
                    method: "GET"
                }
            })
        },
        updateStatus = function () {
            return $resource("/api/updateStatus", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getStageInfoById = function (id) {
            return $resource("/api/getStageInfoById/" + id, null, {
                get: {
                    method: "GET",
                    id: "@id"
                }
            })
        },
        issueDocument = function () {
            return $resource("/api/issueDocument", null, {
                save: {
                    method: "POST"
                }
            })
        },
        closeVisitAndSendSurvey = function () {
            return $resource("/api/closeVisitAndSendSurvey", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getVisitDocumentInfoById = function (id) {
            return $resource("/api/getVisitDocumentInfoById/" + id, null, {
                get: {
                    method: "GET",
                    id: "@id"
                }
            })
        },
        getPatientVisitHistory = function () {
            return $resource("/api/getPatientVisitHistory", null, {
                get: {
                    method: "POST"
                }
            })
        },
        getVisitHistory = function () {
            return $resource("/api/getVisitHistory", null, {
                get: {
                    method: "POST"
                }
            })
        },
        getPatientEmcPrescription = function (id) {
            return $resource("/api/getPatientEmcPrescription/" + id, null, {
                get: {
                    method: "GET",
                    id: "@id"
                }
            })
        },
        addPatientDrugs = function () {
            return $resource("/api/addPatientDrugs", null, {
                save: {
                    method: "POST"
                }
            })
        },
        sendSummaryToFamilyDoctor = function () {
            return $resource("/api/sendSummaryToFamilyDoctor", null, {
                save: {
                    method: "POST"
                }
            })
        },
        addVisitComment = function () {
            return $resource("/api/addVisitComment", null, {
                save: {
                    method: "POST"
                }
            })
        },
        savePaymentDetails = function () {
            return $resource("/api/addPaymentDetails", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getPaymentDetailsByVisitId = function (id) {
            return $resource("/api/getPaymentDetailsByVisitId/" + id, null, {
                get: {
                    method: "GET",
                    id: "@id"
                }
            })
        },
        checkVisitPaymentDone = function () {
            return $resource("/api/checkVisitPaymentDone", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getPatientDebt = function () {
            return $resource("/api/getPatientDebt", null, {
                get: {
                    method: "POST"
                }
            })
        },
        disableAlert = function () {
            return $resource("/api/disableAlert", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getkupatCholim = function () {
            return $resource("/api/getkupatCholim", null, {
                get: {
                    method: "GET"
                }
            })
        },
        visitbyId = function (id) {
            return $resource("/api/visitbyId/" + id, null, {
                get: {
                    method: "GET",
                    id: "@id"
                }
            })
        },
        decrementPatientWaitCount = function () {
            return $resource("/api/decrementPatientWaitCount", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getAllergies = function () {
            return $resource("/api/getAllergies", null, {
                get: {
                    method: "GET"
                }
            })
        },
        getCities = function () {
            return $resource("/api/getCities", null, {
                get: {
                    method: "GET"
                }
            })
        },
        getdashboardCount = function () {
            return $resource("/api/getPatientDashboardCount", null, {
                get: {
                    method: "POST"
                }
            })
        },
        addDoctorOrder = function () {
            return $resource("/api/addDoctorOrder", null, {
                save: {
                    method: "POST"
                }
            })
        },
        addDoctorTreatment = function () {
            return $resource("/api/addDoctorTreatment", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getActivePatientListByDr = function () {
            return $resource("/api/getActivePatientListByDr", null, {
                get: {
                    method: "POST"
                }
            })
        };
    return {
        getActivePatientList: getActivePatientList,
        getPatientList: getPatientList,
        getPatientById: getPatientById,
        addVisitReason: addVisitReason,
        getVisitById: getVisitById,
        getFamilyDoctor: getFamilyDoctor,
        addNewVisitReason: addNewVisitReason,
        addVisitDetails: addVisitDetails,
        addTriageDetails: addTriageDetails,
        getTriageTestByVisitId: getTriageTestByVisitId,
        addPatient: addPatient,
        visitbyId: visitbyId,
        getPatientVisitTest: getPatientVisitTest,
        addNurseExamination: addNurseExamination,
        addDoctorExamination: addDoctorExamination,
        addDoctorPrescription: addDoctorPrescription,
        getPrescriptions: getPrescriptions,
        issueInvoice: issueInvoice,
        emailInvoice: emailInvoice,
        addDoctorOrder: addDoctorOrder,
        addDoctorTreatment: addDoctorTreatment,
        addTreatmentDetails: addTreatmentDetails,
        addTreatmentResultDetails: addTreatmentResultDetails,
        issueInternalReferral: issueInternalReferral,
        getDoctorList: getDoctorList,
        getPatientDashboardCount: getPatientDashboardCount,
        getKCforpatientId: getKCforpatientId,
        updateStatus: updateStatus,
        getStageInfoById: getStageInfoById,
        issueDocument: issueDocument,
        getVisitDocumentInfoById: getVisitDocumentInfoById,
        closeVisitAndSendSurvey: closeVisitAndSendSurvey,
        getPatientVisitHistory: getPatientVisitHistory,
        getVisitHistory: getVisitHistory,
        getPatientEmcPrescription: getPatientEmcPrescription,
        addPatientDrugs: addPatientDrugs,
        sendSummaryToFamilyDoctor: sendSummaryToFamilyDoctor,
        addVisitComment: addVisitComment,
        savePaymentDetails: savePaymentDetails,
        getPaymentDetailsByVisitId: getPaymentDetailsByVisitId,
        checkVisitPaymentDone: checkVisitPaymentDone,
        getPatientDebt: getPatientDebt,
        disableAlert: disableAlert,
        getkupatCholim: getkupatCholim,
        decrementPatientWaitCount: decrementPatientWaitCount,
        getAllergies: getAllergies,
        getCities: getCities,
        getdashboardCount: getdashboardCount,
        getActivePatientListByDr: getActivePatientListByDr
    }
}]), angular.module("Inventory"), MCSIApp.controller("inventoryController", ["$scope", "$rootScope", "$location", "$ocLazyLoad", "$localStorage", "ngTableParams", "ngTableParamsService", "$state", "logger", "CommonService", "InventoryService", function ($scope, $rootScope, $location, $ocLazyLoad, $localStorage, ngTableParams, ngTableParamsService, $state, logger, CommonService, InventoryService) {
    var getData = ngTableParamsService.get();
    $scope.searchTextField = getData.searchText, $scope.searching1 = function (searchTextField) {
        ngTableParamsService.set("", "", $scope.searchTextField, ""), $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.inventoryList = [], InventoryService.getDrugList().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.inventoryList = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.getDrugList = function () {
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.inventoryList = [], InventoryService.getDrugList().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.inventoryList = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.getDrugs = function () {
        var drugDetails = [];
        InventoryService.getDrugs().get(function (response) {
            if (200 == response.code) {
                void 0 == response.data ? $scope.inventoryList = [] : $scope.inventoryList = response.data;
                for (var i = 0; i < $scope.inventoryList.length; i++) drugDetails.push(response.data[i].drugDetails);
                $scope.drugDetails = drugDetails
            }
        })
    }, $scope.showPredefinedDosage = 1, $scope.showPredefinedDosagefunc = function () {
        0 == $scope.showPredefinedDosage ? ($scope.drug && ($scope.drug.dosageNumber = 0, $scope.drug.dosageValue = ""), $scope.showPredefinedDosage = 1) : ($scope.drug && ($scope.drug.stockNow = 0), $scope.showPredefinedDosage = 0)
    }, $scope.addNewDrug = function (drug) {
        isNaN(parseFloat($scope.drug.stockNow)) && ($scope.drug.stockNow = 0);
        var quantity = $scope.drug.stockNow + $scope.drug.addToStock,
            isDosageAlreadyPresent = 0;
        if ($scope.drug.dosageNumber && $scope.drug.dosageValue) {
            var dosage = $scope.drug.dosageNumber.toString() + $scope.drug.dosageValue;
            if ($scope.selectedObject && $scope.selectedObject.originalObject && $scope.selectedObject.originalObject.drugDetails)
                for (var i = 0; i < $scope.selectedObject.originalObject.drugDetails.length; i++)
                    if (dosage == $scope.selectedObject.originalObject.drugDetails[i].dosage) {
                        isDosageAlreadyPresent = 1;
                        break
                    }
        }
        quantity >= 0 && 0 == isDosageAlreadyPresent ? (drug.drugDetails = {
            quantity: $scope.drug.stockNow + $scope.drug.addToStock
        }, void 0 == $scope.selectedObject.originalObject.drugName ? drug.drugName = $scope.selectedObject.title : drug._id = $scope.selectedObject.originalObject._id, void 0 == $scope.dosage_id ? drug.drugDetails.dosage = $scope.drug.dosageNumber + $scope.drug.dosageValue : drug.drugDetails._id = $scope.dosage_id, drug.drugDetails.updateQuantity = drug.updateQuantity, InventoryService.addNewDrug().save(drug, function (response) {
            200 == response.code ? (logger.logSuccess(response.message), $scope.getDrugs()) : logger.logError(response.message)
        })) : quantity <= 0 ? logger.logError("Operation not allowed") : 1 == isDosageAlreadyPresent && logger.logError("Dosage is already present,Please update already present dosage")
    }, $scope.drugNameFocusOut = function () {
        $scope.dosageList = [], setTimeout(function () {
            if (void 0 != $scope.selectedObject.originalObject && $scope.selectedObject.originalObject.drugDetails && $scope.selectedObject.originalObject.drugDetails.length > 0)
                for (var drugDetials = $scope.selectedObject.originalObject.drugDetails, i = 0; i < drugDetials.length; i++) $scope.dosageList.push({
                    id: drugDetials[i]._id,
                    dosage: drugDetials[i].dosage
                });
            $scope.$apply()
        }, 200)
    }, $scope.drug = {}, $scope.changeDosage = function (dosage) {
        dosage && ($scope.selectedDosage = dosage, $scope.drug.dosage = dosage.dosage, $scope.drug.stockNow = dosage.quantity, $scope.dosage_id = dosage._id, $scope.drug.updateQuantity = dosage.updateQuantity)
    }, $scope.deleteDrug = function (drugId, drugDetailId) {
        bootbox.confirm("Are you sure you want to delete this Drug", function (r) {
            r && InventoryService.deleteDrug()["delete"]({
                id: drugId,
                to: drugDetailId
            }, function (response) {
                200 == response.code ? ($scope.getDrugList(), logger.logSuccess(response.message)) : logger.logError(response.message)
            })
        })
    }, $scope.remove = function (id) {
        bootbox.confirm("Are you sure you want to remove this drug details")
    }, $scope.exportToExcel = function () {
        window.open(baseUrl + "/exportToExcelInvList/", "_blank")
    }
}]), angular.module("Inventory").factory("InventoryService", ["$http", "communicationService", "$resource", function ($http, communicationService, $resource) {
    var getDrugList = function () {
            return $resource("/api/getDrugList", null, {
                get: {
                    method: "GET"
                }
            })
        },
        getDrugs = function () {
            return $resource("/api/getDrugs", null, {
                get: {
                    method: "GET"
                }
            })
        },
        addNewDrug = function () {
            return $resource("/api/addNewDrug", null, {
                save: {
                    method: "POST"
                }
            })
        },
        deleteDrug = function (id, to) {
            return $resource("/api/deleteDrug/:id/:to", null, {
                "delete": {
                    method: "DELETE",
                    id: "@id",
                    to: "@to"
                }
            })
        };
    return {
        getDrugList: getDrugList,
        getDrugs: getDrugs,
        addNewDrug: addNewDrug,
        deleteDrug: deleteDrug
    }
}]), angular.module("Kupat"), MCSIApp.controller("kupatCholimController", ["$scope", "$rootScope", "$location", "$ocLazyLoad", "$localStorage", "ngTableParams", "ngTableParamsService", "$state", "logger", "CommonService", "kupatCholimService", function ($scope, $rootScope, $location, $ocLazyLoad, $localStorage, ngTableParams, ngTableParamsService, $state, logger, CommonService, kupatCholimService) {
    $scope.kupatCholim = {};
    var startDate = "Friday: 07:00 AM-Sunday: 06:59 AM";
    $scope.kupatCholim.weekendDayRange = startDate, $scope.addkupatCholim = function (kupatCholim) {
        var data = kupatCholim;
        data.weekendPriceSet = $scope.weekendPriceList, kupatCholimService.addkupatCholim().save(data, function (response) {
            200 == response.code ? (logger.logSuccess(response.message), $state.go("kupatCholim_list")) : logger.logError(response.message)
        })
    };
    var getData = ngTableParamsService.get();
    $scope.searchTextField = getData.searchText, $scope.searching = function () {
        ngTableParamsService.set("", "", $scope.searchTextField, ""), $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.kupatCholimlist = [], kupatCholimService.getkupatCholim().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.kupatCholimlist = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.getkupatCholim = function () {
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            counts: [],
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.kupatCholimlist = [], kupatCholimService.getkupatCholim().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.kupatCholimlist = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.deletekupatCholimbyId = function (id) {
        bootbox.confirm("Are you sure you want to delete this kupatCholim", function (r) {
            r && kupatCholimService.deletekupatCholimbyId(id)["delete"](function (response) {
                200 == response.code ? logger.logSuccess(response.message) : logger.logError(response.message), $scope.getkupatCholim()
            })
        })
    }, $scope.getkupatCholimbyId = function (id) {
        kupatCholimService.getkupatCholimbyId($state.params.id).get(function (response) {
                200 == response.code ? ($scope.kupatid = response.data, $scope.weekendPriceList = response.data.weekendPriceSet) : logger.logError(response.message)
            }),
            function (response) {
                logger.logError(response.message)
            }
    }, $scope.updatekupatCholim = function (kupatCholim, id) {
        kupatCholim.weekendPriceSet = $scope.weekendPriceList, kupatCholimService.updatekupatCholim($state.params.id).save(kupatCholim, function (response) {
            200 == response.code ? (logger.logSuccess(response.message), $state.go("kupatCholim_list")) : logger.logError(response.message)
        })
    }, $scope.weekendPriceList = [], $scope.addNewWeekendPriceSet = function ($event) {
        $scope.weekendPriceList.push({
            title: "",
            dateRange: "",
            price: 0
        }), $event.preventDefault()
    }, $scope.removeWeekendPriceSet = function () {
        var newDataList = [];
        $scope.selectedAll = !1, angular.forEach($scope.weekendPriceList, function (selected) {
            selected.selected || newDataList.push(selected)
        }), $scope.weekendPriceList = newDataList
    }
}]), angular.module("Kupat").factory("kupatCholimService", ["$http", "communicationService", "$resource", function ($http, communicationService, $resource) {
    var addkupatCholim = function () {
            return $resource("/api/addkupatCholim", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getkupatCholim = function () {
            return $resource("/api/getkupatCholim", null, {
                get: {
                    method: "GET"
                }
            })
        },
        deletekupatCholimbyId = function (id) {
            return $resource("/api/deletekupatCholimbyId/" + id, null, {
                "delete": {
                    method: "DELETE",
                    id: "@id"
                }
            })
        },
        updatekupatCholim = function (id) {
            return $resource("/api/updatekupatCholim/" + id, null, {
                save: {
                    method: "PUT",
                    id: "@id"
                }
            })
        },
        getkupatCholimbyId = function (id) {
            return $resource("/api/getkupatCholimbyId/" + id, null, {
                get: {
                    method: "GET",
                    id: "@id"
                }
            })
        };
    return {
        addkupatCholim: addkupatCholim,
        getkupatCholim: getkupatCholim,
        deletekupatCholimbyId: deletekupatCholimbyId,
        updatekupatCholim: updatekupatCholim,
        getkupatCholimbyId: getkupatCholimbyId
    }
}]), angular.module("Reports"), MCSIApp.controller("reportController", ["$scope", "$rootScope", "$location", "$ocLazyLoad", "$localStorage", "ngTableParams", "ngTableParamsService", "logger", "ReportService", "CommonService", "PatientService", "$window", function ($scope, $rootScope, $location, $ocLazyLoad, $localStorage, ngTableParams, ngTableParamsService, logger, ReportService, CommonService, PatientService, $window) {
    $scope.showVisitResultsReport = !1, $scope.loader = !1;
    ngTableParamsService.get();
    $scope.generateVisitResultsReport = function () {
        var dateRange = angular.element($("#dateRange")).val();
        $scope.showVisitResultsReport = !0, $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), "", params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.list = [], $scope.paramUrl.dateRange = dateRange, ReportService.getVisitResultsReport().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.list = response.data.data, $scope.fileToExport = response.data.file;
                    var data = response.data;
                    $scope.totalLength = response.data.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.exportToExcel = function (type) {
        var id = type + "_" + $scope.fileToExport;
        window.open(baseUrl + "/exportToExcel/" + id, "_blank")
    };
    ngTableParamsService.get();
    $scope.generateCurrentDiseaseReport = function () {
        var dateRange = angular.element($("#dateRange")).val();
        $scope.showCurrentDiseaseReport = !0, $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), "", params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.currentDiseaseList = [], $scope.paramUrl.dateRange = dateRange, ReportService.getCurrentDiseaseReport().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.currentDiseaseList = response.data.data, $scope.fileToExport = response.data.file;
                    var data = response.data;
                    $scope.totalLength = response.data.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    };
    ngTableParamsService.get();
    $scope.generateInvChangesReport = function () {
        var dateRange = angular.element($("#dateRange")).val();
        $scope.showInvChangesReport = !0, $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), "", params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.invChangeList = [], $scope.paramUrl.dateRange = dateRange, ReportService.getInvChangesReport().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.invChangeList = response.data.data, $scope.fileToExport = response.data.file;
                    var data = response.data;
                    $scope.totalLength = response.data.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.generateDrugsGiveAwayReport = function () {
        var dateRange = angular.element($("#dateRange")).val();
        $scope.showDrugGiveAwayReport = !0, $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), "", params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.drugsGiveAwayList = [], $scope.paramUrl.dateRange = dateRange, ReportService.getDrugsGiveAwayReport().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.drugsGiveAwayList = response.data.data, $scope.fileToExport = response.data.file;
                    var data = response.data;
                    $scope.totalLength = response.data.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.getReportGeneratedHistory = function (reportType) {
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), "", params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.list = [], $scope.paramUrl.reportType = reportType, ReportService.getReportGeneratedHistory().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.list = response.data;
                    var data = response.data;
                    $scope.totalLength = response.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.downloadOrViewReport = function (reportType, reportId) {
        var id = reportType + "_" + reportId;
        window.open(baseUrl + "/downloadOrViewReport/" + id, "_blank"), window.close()
    }, $scope.generateKupatCholimReport = function () {
        var dateRange = angular.element($("#dateRange")).val(),
            kupatKholim = $scope.kupatCholim;
        $scope.showKupatCholimReport = !0, $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function ($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), "", params.sorting()), $scope.paramUrl = params.url(), $scope.tableLoader = !0, $scope.list = [], $scope.paramUrl.dateRange = dateRange, $scope.paramUrl.kupatKholim = kupatKholim, ReportService.getKupatCholimReport().get($scope.paramUrl, function (response) {
                    $scope.tableLoader = !1, $scope.list = response.data.data;
                    var data = response.data;
                    $scope.fileToExport = response.data.file, $scope.totalLength = response.data.totalLength, params.total(response.totalLength), $defer.resolve(data)
                })
            }
        })
    }, $scope.getkupatCholim = function () {
        PatientService.getkupatCholim().get(function (response) {
            200 == response.code ? $scope.kupatCholimlist = response.data : logger.logError(response.message)
        })
    }, $scope.showReport = function (reportType, reportId) {
        var id = reportType + "_" + reportId;
        ReportService.showReport(id).get(function (response) {
            if (200 == response.code) {
                var newWindow = window.open();
                newWindow.document.writeln(response.data.html), newWindow.document.close()
            } else logger.logError(response.message)
        })
    }
}]), angular.module("Reports").factory("ReportService", ["$http", "communicationService", "$resource", function ($http, communicationService, $resource) {
    var getVisitResultsReport = function () {
            return $resource("/api/getVisitResultsReport", null, {
                get: {
                    method: "POST"
                }
            })
        },
        exportToExcelVisitResultsReport = function () {
            return $resource("/api/exportToExcelVisitResultsReport", null, {
                save: {
                    method: "POST"
                }
            })
        },
        getCurrentDiseaseReport = function () {
            return $resource("/api/getCurrentDiseaseReport", null, {
                get: {
                    method: "POST"
                }
            })
        },
        getInvChangesReport = function () {
            return $resource("/api/getInvChangesReport", null, {
                get: {
                    method: "POST"
                }
            })
        },
        getDrugsGiveAwayReport = function () {
            return $resource("/api/getDrugsGiveAwayReport", null, {
                get: {
                    method: "POST"
                }
            })
        },
        getReportGeneratedHistory = function () {
            return $resource("/api/getReportGeneratedHistory", null, {
                get: {
                    method: "POST"
                }
            })
        },
        getKupatCholimReport = function () {
            return $resource("/api/getKupatCholimReport", null, {
                get: {
                    method: "POST"
                }
            })
        },
        showReport = function (id) {
            return $resource("/api/showReport/" + id, null, {
                get: {
                    method: "GET",
                    id: "@id"
                }
            })
        };
    return {
        getVisitResultsReport: getVisitResultsReport,
        exportToExcelVisitResultsReport: exportToExcelVisitResultsReport,
        getCurrentDiseaseReport: getCurrentDiseaseReport,
        getInvChangesReport: getInvChangesReport,
        getDrugsGiveAwayReport: getDrugsGiveAwayReport,
        getReportGeneratedHistory: getReportGeneratedHistory,
        getKupatCholimReport: getKupatCholimReport,
        showReport: showReport
    }
}]);