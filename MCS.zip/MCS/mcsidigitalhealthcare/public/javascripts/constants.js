var baseUrl = location.protocol + '//' + location.hostname + (location.port ? ':' + location.port : '');
console.log("baseUrl:", baseUrl);

var webservices = {
	"authenticate": baseUrl + "/api/userLogin",
	"forgot_password": baseUrl + "/api/forgotPassword",
	"logout": baseUrl + "/api/userLogOut",
	//addDisease
	"addDisease": baseUrl + "/disease/add",
	//user
	"addUser": baseUrl + "/users/add",
	"userList": baseUrl + "/users/list",
}

var appConstants = {
	"authorizationKey": "dGF4aTphcHBsaWNhdGlvbg=="
}

var headerConstants = {
	"json": "application/json"

}

var pagingConstants = {
	"defaultPageSize": 10,
	"defaultPageNumber": 1
}

var messagesConstants = {}