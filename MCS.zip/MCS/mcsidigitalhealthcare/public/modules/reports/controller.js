"use strict";

angular.module("Reports")

MCSIApp.controller('reportController', ['$scope', '$rootScope', '$location', '$ocLazyLoad', '$localStorage', 'ngTableParams', 'ngTableParamsService', 'logger', 'ReportService', 'CommonService', 'PatientService', '$window',
    function ($scope, $rootScope, $location, $ocLazyLoad, $localStorage, ngTableParams, ngTableParamsService, logger, ReportService, CommonService, PatientService, $window) {

        $scope.showVisitResultsReport = false;
        $scope.loader = false;

        var getData = ngTableParamsService.get();
        $scope.generateVisitResultsReport = function () {
            var dateRange = angular.element($('#dateRange')).val();
            $scope.showVisitResultsReport = true;
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function ($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), '', params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.list = [];
                    $scope.paramUrl.dateRange = dateRange;
                    ReportService.getVisitResultsReport().get($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        $scope.list = response.data.data;
                        $scope.fileToExport = response.data.file;
                        var data = response.data;
                        $scope.totalLength = response.data.totalLength;
                        params.total(response.totalLength);
                        $defer.resolve(data);
                    });
                }
            });
        };

        $scope.exportToExcel = function (type) {
            var id = type + '_' + $scope.fileToExport;
            window.open(baseUrl + '/exportToExcel/' + id, '_blank');
        };

        var getData = ngTableParamsService.get();
        $scope.generateCurrentDiseaseReport = function () {
            var dateRange = angular.element($('#dateRange')).val();
            $scope.showCurrentDiseaseReport = true;
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function ($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), '', params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.currentDiseaseList = [];
                    $scope.paramUrl.dateRange = dateRange;
                    ReportService.getCurrentDiseaseReport().get($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        $scope.currentDiseaseList = response.data.data;
                        $scope.fileToExport = response.data.file;
                        var data = response.data;
                        $scope.totalLength = response.data.totalLength;
                        params.total(response.totalLength);
                        $defer.resolve(data);
                    });
                }
            });
        };

        var getData = ngTableParamsService.get();
        $scope.generateInvChangesReport = function () {
            var dateRange = angular.element($('#dateRange')).val();
            $scope.showInvChangesReport = true;
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function ($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), '', params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.invChangeList = [];
                    $scope.paramUrl.dateRange = dateRange;
                    ReportService.getInvChangesReport().get($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        $scope.invChangeList = response.data.data;
                        $scope.fileToExport = response.data.file;
                        var data = response.data;
                        $scope.totalLength = response.data.totalLength;
                        params.total(response.totalLength);
                        $defer.resolve(data);
                    });
                }
            });
        };

        $scope.generateDrugsGiveAwayReport = function () {
            var dateRange = angular.element($('#dateRange')).val();
            $scope.showDrugGiveAwayReport = true;
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function ($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), '', params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.drugsGiveAwayList = [];
                    $scope.paramUrl.dateRange = dateRange;
                    ReportService.getDrugsGiveAwayReport().get($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        $scope.drugsGiveAwayList = response.data.data;
                        $scope.fileToExport = response.data.file;
                        var data = response.data;
                        $scope.totalLength = response.data.totalLength;
                        params.total(response.totalLength);
                        $defer.resolve(data);
                    });
                }
            });
        };

        $scope.getReportGeneratedHistory = function (reportType) {
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function ($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), '', params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.list = [];
                    $scope.paramUrl.reportType = reportType;
                    ReportService.getReportGeneratedHistory().get($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        $scope.list = response.data;
                        var data = response.data;
                        $scope.totalLength = response.totalLength;
                        params.total(response.totalLength);
                        $defer.resolve(data);
                    });
                }
            });

        };

        $scope.downloadOrViewReport = function (reportType, reportId) {
            var id = reportType + '_' + reportId;
            window.open(baseUrl + '/downloadOrViewReport/' + id, '_blank');
            window.close();
        };

        $scope.generateKupatCholimReport = function () {
            var dateRange = angular.element($('#dateRange')).val();
            var kupatKholim = $scope.kupatCholim;
            $scope.showKupatCholimReport = true;
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function ($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), '', params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.list = [];
                    $scope.paramUrl.dateRange = dateRange;
                    $scope.paramUrl.kupatKholim = kupatKholim;
                    ReportService.getKupatCholimReport().get($scope.paramUrl, function (response) {
                        $scope.tableLoader = false;
                        $scope.list = response.data.data;
                        var data = response.data;
                        $scope.fileToExport = response.data.file;
                        $scope.totalLength = response.data.totalLength;
                        params.total(response.totalLength);
                        $defer.resolve(data);
                    });
                }
            });
        };

        $scope.getkupatCholim = function () {
            PatientService.getkupatCholim().get(function (response) {
                if (response.code == 200) {
                    $scope.kupatCholimlist = response.data;
                } else {
                    logger.logError(response.message);
                }
            });
        };

        $scope.showReport = function (reportType, reportId) {
            var id = reportType + '_' + reportId;
            ReportService.showReport(id).get(function (response) {
                if (response.code == 200) {
                    var newWindow = window.open();
                    newWindow.document.writeln(response.data.html);
                    newWindow.document.close();
                } else {
                    logger.logError(response.message);
                }
            });
        };
    }]);