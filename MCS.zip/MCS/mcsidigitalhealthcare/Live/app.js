'use strict';

var SwaggerExpress = require('swagger-express-mw');
var favicon = require('serve-favicon');
var express = require('express'),
    http = require('http'),
    fs = require('fs'),
    https = require('https');    
var app = express();

//----------- Node Security Section-------------------------
var helmet = require('helmet');
app.use(helmet());

//TODO
// app.use(helmet.contentSecurityPolicy({
//   directives: {
//     defaultSrc: ["'self'"],
//     styleSrc: ["'self'", "'unsafe-inline'"],
//     connectSrc: ["'self'"]
//   }
// }));

// Sets "X-DNS-Prefetch-Control: off".
app.use(helmet.dnsPrefetchControl());

//app.use(helmet.noCache());
app.use(helmet.hidePoweredBy());
app.use(helmet.ieNoOpen());

// // Sets "X-Content-Type-Options: nosniff".
app.use(helmet.noSniff());

// //Sets "X-Frame-Options: DENY".
app.use(helmet({  frameguard: {    action: 'deny'  }}));

// // Sets "X-XSS-Protection: 1; mode=block".
app.use(helmet.xssFilter({ setOnOldIE: true }));
app.use(helmet.referrerPolicy({ policy: 'same-origin' }))

//-----------------------------------

var path = require('path');
var bodyParser = require('body-parser');
module.exports = app;
require('./config/db');
var utils = require('./api/lib/utility');
var config = {
    appRoot: __dirname // required config
};

app.use(bodyParser.json());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));

app.use(express.static(path.join(__dirname, 'public')));

SwaggerExpress.create(config, function (err, swaggerExpress) {
    if (err) {
        console.log("err:", err);
        throw err;
    }

    // All api requests
    app.use(function (req, res, next) {
        // CORS headers
        res.header("Access-Control-Allow-Origin", "*"); // restrict it to the required domain
        res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
        // Set custom headers for CORS
        res.header('Access-Control-Allow-Headers', 'Content-type,Accept,X-Access-Token,X-Key,If-Modified-Since,Authorization');

        if (req.method == 'OPTIONS') {
            res.status(200).end();
        } else {
            next();
        }
    });

    //TODO: AuthenticationModule: Check to call web services where token is not required//
    app.use('/api/*', function (req, res, next) {
        // next();
        var freeAuthPath = [
            '/api/userLogin',
            '/api/forgotPassword',
            '/api/loggedin',
            '/api/survey',
            '/api/getSurveySetByAdmin',
            '/api/getSurveyById',
            '/api/submitSurvey',
            '/api/resetPassword'
            
        ];
        var available = false;
        for (var i = 0; i < freeAuthPath.length; i++) {
            if (freeAuthPath[i] == req.baseUrl) {
                available = true;
                break;
            }
        }
        if (!available) {
            utils.ensureAuthorized(req, res, next);
        } else {
            next();
        }
    });

    // enable SwaggerUI
    app.use(swaggerExpress.runner.swaggerTools.swaggerUi());

    // install middleware
    swaggerExpress.register(app);

    //  var port = process.env.PORT || 5040;
    var port = 80;

    // app.listen(port);


    if (swaggerExpress.runner.swagger.paths['/hello']) {
        console.log('try this:\ncurl http://127.0.0.1:' + port);
    }

    var authCtrl = require('./api/controllers/patient_ctrl');
    var reportCtrl = require('./api/controllers/report_ctrl');
    var surveyCtrl = require('./api/controllers/survey_ctrl');
    var auth1Ctrl = require('./api/controllers/auth_ctrl');
    var visitCtrl = require('./api/controllers/visit_ctrl');
    var invCtrl = require('./api/controllers/inventory_ctrl');
    
    app.get('/download-file/:id', function (req, res, next) {
        authCtrl.download(req, res);
    });

    app.get('/viewVisitDocument/:id', function (req, res, next) {
        authCtrl.viewVisitDocument(req, res);
    });
    
    app.get('/exportToExcel/:id', function (req, res, next) {
        reportCtrl.exportToExcel(req, res);
    });

    app.get('/downloadOrViewReport/:id', function (req, res, next) {
        reportCtrl.downloadOrViewReport(req, res);
    });

    app.get('/getdoc/:id', function (req, res, next) {
          visitCtrl.getdoc(req, res);
    });

    app.get('/auth/verifyLink/:id', function(req, res, next) {
        auth1Ctrl.verifyLink(req, res);
    });

    app.get('/exportToExcelInvList/', function (req, res, next) {
        invCtrl.exportToExcelInvList(req, res);
    });
   
    //----------------------------- Socket.io Communication-----------------------
  
    var privateKey = fs.readFileSync( path.resolve('./config/', 'emcefrat_private_key.key'), 'utf8');
    console.log('ky path--->', path.resolve('./config/', 'emcefrat_private_key.key'));
    var certificate = fs.readFileSync(path.resolve('./config/', 'emcefrat_ssl_certificate.cer'), 'utf8');
    console.log('cert path--->', path.resolve('./config/', 'emcefrat_ssl_certificate.cer'));
    var ca = fs.readFileSync(path.resolve('./config/', 'emcefrat.org_INTERMEDIATE.cer'), 'utf8');
    console.log('cert path--->', path.resolve('./config/', 'emcefrat.org_INTERMEDIATE.cer'));
    var credentials = { key: privateKey, cert: certificate, ca: ca };
    var server = https.createServer(credentials, app);
   // var server = http.createServer(app);
   
    var io = require('socket.io').listen(server);
    server.on('secureConnection', function (cleartextStream, encryptedStream) {
      if(!cleartextStream.authorized){
        console.error("TLS error: " + cleartextStream.authorizationError)
      }
      else{
           console.error("TLS done: ", cleartextStream.authorized);
      }
   })
    server.listen(port, function () {
        console.log('server up and running at port', port);
    });
   
   // Socket.io Communication
    //io.sockets.on('connection', require('./socket'));
   require('./socket')(io);
});


