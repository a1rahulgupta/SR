'use strict';

var mongoose = require('mongoose');

/* DB */
require('../api/models/users');
require('../api/models/status');
require('../api/models/disease');
require('../api/models/roles');
require('../api/models/auditLog');
require('../api/models/permissions');
require('../api/models/patient');
require('../api/models/survey');
require('../api/models/visitsurvey');
require('../api/models/visitInfo');
require('../api/models/triage');
require('../api/models/patientTest');
require('../api/models/orders');
require('../api/models/inventory');
require('../api/models/triagePatientTest');
require('../api/models/kupatCholim');
require('../api/models/visitStage');
require('../api/models/reportHistory');
require('../api/models/alert');
require('../api/models/visitPayment');
require('../api/models/setting');
require('../api/models/allergy');
require('../api/models/citi');




//var uri = 'ds159998.mlab.com:59998';
//mongoose.connect("mongodb://localhost:27017/MCSI_Healthcare");
mongoose.connect('mongodb://mcsidigital:mgh%232ew90@localhost:52189/mcsidigital');
mongoose.Promise = global.Promise;
var db = mongoose.connection;
db.on('error', console.error.bind(console, "connection failed"));
db.once('open', function() {
    console.log("Database conencted successfully!");
});
// mongoose.set('debug', true);

/* end DB */

// U/P :  mcsidigital/D@Fde@3e3

// DB : mcsidigital

// Mongo port : 57170