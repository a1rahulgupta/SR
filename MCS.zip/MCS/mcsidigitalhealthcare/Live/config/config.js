'use strict';

module.exports =  {
        SECRET  : 'crm@$12&*01',       
        SALTKEY : '$2a$10$8NNrP7ODP9DGWtcW37DSWO',
        webUrl: 'http://35.176.186.91:80',  
        //DIR_NAME: '/app',
        SMTP: {
            service: 'gmail',
            host: 'smtp.gmail.com',
            secure: true,
            port: 465,
            auth: {
                user: 'techteamsdn@gmail.com',
                pass: 'tech@sdn'
            }
        },
        EMAIL_FROM : '"Tech Group" <techteamsdn@gmail.com>',
        EMAIL_BCC : '"LexHelper" <techteamsdn@gmail.com>',
        //EMAIL_TEMP : 'stephanie.daniels@lexhelper.com, support2@lexhelper.com',
        EMAIL_TEMP : 'techteamsdn@gmail.com'
};