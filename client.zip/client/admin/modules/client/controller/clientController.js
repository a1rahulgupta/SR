"use strict";

angular.module("Client")

interpreterApp.controller("clientController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger', 'ClientService','dashboardService', 'ngTableParams','CommonService', 'ngTableParamsService',
    function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal, logger, ClientService,dashboardService, ngTableParams, CommonService, ngTableParamsService) {
       
        /**
        * Variable is used for update client
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 1-Feb-2017
        **/
        if ($state.params.id) {
            $scope.isUpdate = true;
        } else {
            $scope.isUpdate = false;
        }; 

        $scope.client={};
        $scope.client.gender='Male';
        $scope.selectAgency = {};
        
        /**
        * Variable is used to active class on leftbar
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $rootScope.menuClient = ['admin_listClients', 'admin_viewClient', 'admin_addClient', 'admin_editClient'];
        
        /**
        * Function and variable is used to check format of image upload
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.myImage='';
        $scope.myCroppedImage='';
        $scope.isImageSelected=false;
        $scope.isCropVisible=false;
        var handleFileSelect=function(evt) {
            $scope.isImageSelected=false;
            $scope.isCropVisible=true;
          var file=evt.currentTarget.files[0];
          var reader = new FileReader();
          reader.onload = function (evt) {
            $scope.$apply(function($scope){
              $scope.myImage=evt.target.result;
            });
          };
          reader.readAsDataURL(file);
        };
        angular.element(document.querySelector('#fileInput')).on('change',handleFileSelect);
        $scope.openFileBrowse = function(fileInputSelector) {
            angular.element(document.querySelector(fileInputSelector)).trigger('click');
        };

        var formDataFileUpload = '';
        $scope.imageBase64 = '';
        angular.element(document).ready(function() {
            setTimeout(function() {
                if(document.getElementById('fileInput')!=null){
                    document.getElementById('fileInput').addEventListener('change', function(evt) {
                        var files = evt.target.files;
                        var file = files[0];
                        if (files && file) {
                            var splitFileName = file.name.split('.');
                            var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                            if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {
                                if (file.size > 6291456) {
                                    logger.log('File size cannot exceed limit of 6 mb');
                                    document.getElementById("fileInput").value = "";
                                } else {
                                    formDataFileUpload = file;
                                    var reader = new FileReader();
                                    reader.onload = function(readerEvt) {
                                        $scope.imageBase64 = btoa(readerEvt.target.result);
                                        $scope.$apply();
                                        document.querySelector('#imgTag').src = 'data:image/' + ext + ';base64,' + $scope.imageBase64;
                                    };
                                    reader.readAsBinaryString(file);
                                }
                            } else {
                                document.getElementById("fileInput").value = "";
                                bootbox.alert('Invalid image format');
                            }
                        }
                    });
                }
            }, 500);
        });
        
        $scope.localLang = {
            selectAll       : "Tick all",
            selectNone      : "Tick none",
            reset           : "Undo all",
            search          : "Type here to search...",
            nothingSelected : "Nothing is selected"         //default-label is deprecated and replaced with this.
        };

        /**
        * Function is used to get clients by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $rootScope.listClientsSuperAdmin = function() {
            ngTableParamsService.set('', '', '', '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    if($scope.selectAgency.agency_id != '' && $scope.selectAgency.agency_id != null && $scope.selectAgency.agency_id != undefined){
                        $scope.paramUrl.agency_id = $scope.selectAgency.agency_id;
                    }
                    $scope.clientList = [];
                    ClientService.listClientsSuperAdmin().save($scope.paramUrl, function(response, err) {
                        if (response.status == 1) {
                            $scope.clientList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };

        /**
        * Function is used to get clients searching by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.listClientsSearchingSuperAdmin = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    if($scope.selectAgency.agency_id != '' && $scope.selectAgency.agency_id != null && $scope.selectAgency.agency_id != undefined){
                        $scope.paramUrl.agency_id = $scope.selectAgency.agency_id;
                    }
                    $scope.clientList = [];
                    ClientService.listClientsSuperAdmin().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.clientList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        /**
        * Function is used to add client by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.addClientSuperAdmin = function() {
            if($scope.isImageSelected==true){
                $scope.client.imageFile = $scope.myCroppedImage;
            }
            ClientService.addClientSuperAdmin().save($scope.client, function(response) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $state.go('admin_listClients');
                } else {
                    logger.logError(response.message);
                }

            });
        };

        /**
        * Function is used to get client view by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 1-Feb-2018
        **/
        $scope.getClientViewSuperAdmin = function(){
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            if($stateParams.id){
                ClientService.getClientViewSuperAdmin().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var client = response.data;
                        if(client.profile_pic!='' && client.profile_pic!=undefined){
                            $scope.userDefaultImage=client.profile_pic;
                        }
                        $scope.client = client;
                    }else{
                        $scope.client = {};
                    }
                })
            }
        };

        /**
        * Function is used to update the client by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 5-Feb-2018
        **/
        $scope.updateClientSuperAdmin = function() {
            if($scope.isImageSelected==true){
                $scope.client.imageFile = $scope.myCroppedImage;
            }
            var client = $scope.client;
            var languageArray = $scope.languageArray;
            var hasFound = false;
            var tmp = {};
            for(var i=0; i< languageArray.length; i++){
                hasFound = false;
                for(var j=0; j< client.languages.length; j++){
                    if(languageArray[i].language_id == client.languages[j]._id){
                        hasFound = true;
                        break;
                    }
                }
                if(!hasFound){
                    tmp = languageArray[i];
                    tmp._id=tmp.language_id;
                    tmp.ticked = false;
                    client.languages.push(tmp);
                }
            }
            ClientService.updateClientSuperAdmin().save(client, function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $state.go('admin_listClients');
                } else {
                    logger.logError(response.message);
                }
            });
        };
        
        /**
        * Function is used to delete the client by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 5-Feb-2018
        **/
        $scope.deleteClientSuperAdmin = function(id,$event) {
            $event.stopPropagation();
            bootbox.confirm('Are you sure, you want to delete this account?', function(r) {
                if (r) {
                    ClientService.deleteClientSuperAdmin().delete({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listClientsSuperAdmin();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        /**
        * Function is used to change the status of the client by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 5-Feb-2018
        **/
        $scope.changeClientStatusSuperAdmin = function(id,status) {
            var client = {
                id: id,
                status: status
            }
            ClientService.changeClientStatusSuperAdmin().save(client,function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $scope.listClientsSuperAdmin();
                } else {
                    logger.log(response.message);
                }
            });
        };

        /**
        * Function is used to list client booking in view Client by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 1-Feb-2018
        **/
        $scope.listClientBookingSuperAdmin = function() {
            ngTableParamsService.set('', '', '', '');
            if($state.params.id){
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    getData: function($defer, params) {
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.paramUrl.client_id = $state.params.id;
                        $scope.bookingList = [];
                        ClientService.listClientBookingSuperAdmin().save($scope.paramUrl, function(response, err) {
                            if (response.status == 1) {
                                $scope.bookingList = response.data;
                                var data = response.data;
                                $scope.totalCount = response.count;
                                params.total(response.count);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                }); 
            }
        };

        /**
        * Function is used to search list clients by super admin
        * @access private
        * @return json
        * Created by ramiz
        * @smartData Enterprises (I) Ltd
        * Created Date 05-Jan-2018
        **/
        $scope.listBookingOfClientInAgencyBySearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.paramUrl.client_id = $state.params.id;
                    $scope.bookingList = [];
                    ClientService.listClientBookingSuperAdmin().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        /**
        * Function is used to get agency by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.listAgencySuperAdmin = function(){
            ClientService.listAgencySuperAdmin().get({},function(response, err){
                if(response.status == 1){
                    $scope.agencyList = response.data;
                }else{
                    $scope.agencyList = {};
                }
            })
        }

        /**
        * Function is used to get countries by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.getAllCountriesInSuperAdmin = function(){
            ClientService.getAllCountriesInSuperAdmin().get({},function(response, err){
                if(response.status == 1){
                    $scope.superAdminCountries = response.data;
                    $scope.superAdmin = {};
                    for(var i=0; i<$scope.superAdminCountries.length; i++){
                        if($scope.superAdminCountries[i].country_code == 'us'){
                            $scope.superAdmin.country_id = $scope.superAdminCountries[i]._id 
                        }
                    }
                }else{
                    $scope.superAdminCountries = {};
                }
            })
        }

        /**
        * Function is used to get all languages in multiselect
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.getAllLanguagesSuperAdmin = function(){
            ClientService.getAllLanguagesSuperAdmin().get({},function(response, err){
                if(response.status == 1){
                    $scope.languageList = response.data;
                    console.log("$scope.languageList",$scope.languageList);
                }else{
                    $scope.languageList = {};
                }
            })
        }

        /**
        * Function is used to get client by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.getClientBySuperAdmin = function(){
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            if($stateParams.id){
                ClientService.getClientBySuperAdmin().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var client = response.data;
                        console.log("client",client);
                        client.email = client.email;

                        //Multilple language status changed
                        $scope.languageArray = angular.copy(client.languages); 
                        //End

                        setTimeout(function() {
                            for(var i=0;i<$scope.languageList.length;i++){
                                for (var j=0;j<client.languages.length;j++) {
                                    if($scope.languageList[i].name == client.languages[j].name
                                        && client.languages[j].ticked==true){
                                        $scope.languageList[i].ticked=true;
                                        break;
                                    }
                                }
                            }
                            if(client.profile_pic!='' && client.profile_pic!=undefined){
                                $scope.userDefaultImage=client.profile_pic;
                            }
                            $scope.$apply();
                        }, 500);
                        $scope.client = client;
                    }else{
                        $scope.client = {};
                    }
                })
            }
        };

        /**
        * Uib Modal is used to activate client by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.activateClientModal = function(clientData){
            if(clientData.userInfo.activation_key != '' || clientData.userInfo.activation_key != null || clientData.userInfo.activation_key != undefined){
                $uibModal.open({
                    templateUrl: 'modules/client/views/activateClientModal.html',
                    size: 'md',
                    controller: function($scope,$rootScope, $uibModalInstance){
                    
                        $scope.closeuib = function() {
                            $uibModalInstance.close();
                        }
                        
                        var client = {};
                        client._id = clientData._id;
                        client.user_id =  clientData.userInfo._id;
                        client.email =  clientData.userInfo.email;
                        $scope.client = client;

                        $scope.activateClientSuperAdmin = function(form){
                            if(form.$valid){
                                $scope.loader = true;
                                $scope.disabled = true;
                                if($scope.client.confirm_password == true){    
                                    ClientService.activateClientSuperAdmin().save($scope.client,function(response, err) {
                                        if (response.status == 1) {
                                            logger.logSuccess(response.message);
                                            $uibModalInstance.close();
                                            $state.reload();
                                        } else {
                                            logger.log(response.message);
                                        }
                                    });          
                                }else{
                                    $scope.disabled = false;
                                    logger.log("Confirm password does not match with password!");
                                }
                            }
                        }
                    }
                });
            }else{
                logger.logError("Oops something is wrong! Please try again.");
            }
        }
                
    }
]);
