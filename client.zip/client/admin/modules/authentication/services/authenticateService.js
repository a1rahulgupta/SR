'use strict'

angular.module('Authentication')

.factory('AuthenticationService', ['$http', '$resource', function($http, $resource) {

    var adminLogin = function() {
        return $resource(webservices.adminLogin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var userForgotPassword = function() {
        return $resource(webservices.userForgotPassword, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var setNewPassword = function() {
        return $resource(webservices.setNewPassword, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getEmailUsingPassword = function() {
        return $resource(webservices.getEmailUsingPassword, null, {
            get: {
                method: 'GET'
            }
        });
    }


    return {
        adminLogin: adminLogin,
        userForgotPassword: userForgotPassword,
        setNewPassword: setNewPassword,
        getEmailUsingPassword: getEmailUsingPassword
    }

}]);
