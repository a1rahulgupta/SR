"use strict";


angular.module("Authentication");

interpreterApp.controller('loginController', ['$scope', '$rootScope', '$location', 'AuthenticationService', '$localStorage', 'logger', '$stateParams', '$state',
    function($scope, $rootScope, $location, AuthenticationService, $localStorage, logger, $stateParams, $state) {

        var inputJSON = "";
        $scope.imageBase64 = '';
        var formDataFileUpload = '';
        // $scope.user = {};
        $scope.forgotPass = {};
        $scope.isPasswordSent = false;
        $scope.disabled = false;
        $scope.loader = false;
        // $scope.user.email = $stateParams.email;
        // $scope.user = null;

        /**
         * Function is use to verify Init
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.verifyInit = function() {
            $scope.parmas = $location.search();
            $scope.success = $scope.parmas.success;
        }

        /**
         * Function is use to image Init
         * @access private
         * @return json
         * Created by sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.findOne = function() {
            $scope.imageError = false;

            document.getElementById('filePicker').addEventListener('change', function(evt) {

                var files = evt.target.files;
                var file = files[0];
                if (files && file) {
                    var splitFileName = file.name.split('.');
                    var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                    if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {                       
                        if (file.size > 10485760) {  //6291456 1093533
                            // logger.log('File size cannot exceed limit of 6 mb');
                            document.getElementById("filePicker").value = "";
                            $scope.imageError = true;
                            $scope.$apply();
                        } else {
                            formDataFileUpload = file;
                            // formDataFileUpload.append('file', file);
                            var reader = new FileReader();
                            reader.onload = function(readerEvt) {
                                $scope.preview = true;
                                $scope.imageBase64 = 'data:image/' + ext + ';base64,' + btoa(readerEvt.target.result);
                                document.getElementById('imgTag').src = $scope.imageBase64;
                                $scope.$apply();
                            };
                            reader.readAsBinaryString(file);
                        }
                    } else {
                        document.getElementById("filePicker").value = "";
                        bootbox.alert('File format is not supported, please upload a file with one of the following extensions: .jpg,.jpeg,.png');
                    }
                }
            }, false);
        }

        /**
         * Function is use to login organization
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 18-Sep-2017
         */
        $scope.login = function(form) {

            if (form.$valid) {
                $scope.loader = true;
                $scope.disabled = true;
                AuthenticationService.adminLogin().save($scope.user, function(response, err) {
                    // console.log("$scope.user######", response.data);
                    var errorMessage = '';
                    $scope.disabled = false;
                    $scope.loader = false;
                    if(response.status == 1 && response.data.user.role == 'super_admin'){
                        $localStorage.userLoggedIn = true;
                        $rootScope.userLoggedIn = true;
                        $localStorage.user = response.data.user.role;                        
                        $localStorage.token = response.data.token;                        
                        $state.go('admin_dashboard');
                    }else{
                        logger.logError('Invalid email and password');
                    }
                });
            }

        }

        
        /**
         * Function is use to logout 
         * @access private
         * @return json
         * Created by sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.logout = function() {
            delete $localStorage.userLoggedIn;
            delete $localStorage.user;
            delete $localStorage.token;        
            $rootScope.userLoggedIn = false;
            $location.path('/login');   
        }

        /**
         * Function is use to user Register
         * @access private
         * @return json
         * Created by sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.userRegister = function(form) {
            if (form.$valid) {
                $scope.loader = true;
                $scope.disabled = true;

                // $scope.user.token = result.token.id;
                AuthenticationService.userRegister().save($scope.user, function(response, err) {

                    var errorMessage = '';
                    $scope.disabled = false;
                    $scope.loader = false;
                    if (response.code == statusCode.ok) {
                        console.log('formDataFileUpload: -',formDataFileUpload);
                        
                        if (formDataFileUpload) {

                            var formData = new FormData();
                            formData.append('id', response.data.userDataNew._id);
                            formData.append('file', formDataFileUpload);
                            console.log('formData: -',formData);

                            AuthenticationService.uploadImage().save(formData, function(resp, err) {
                                if (resp.code == statusCode.ok) {
                                    $state.go('verify-email');
                                } else {
                                    logger.logError(response.message);
                                }
                            });
                        } else {
                            console.log('No Image: -');
                            logger.logError(response.message);
                            $state.go('verify-email');
                        }
                    } else {
                        logger.logError(response.message);
                    }
                });
            }
        };

        // Stripe payment gateway integration sign process code plz don't delete  
        /*$scope.userRegister = function(form) {

            if (form.$valid) {
                $scope.loader = true;
                $scope.disabled = true;

                stripe.createToken($scope.card).then(function(result) {
                    if (result.error) { // Inform the user if there was an error                    
                        $scope.loader = false;
                        var errorElement = document.getElementById('card-errors');
                        errorElement.textContent = result.error.message;
                    } else { // Send the token to your server    

                        $scope.user.token = result.token.id;
                        AuthenticationService.userRegister().save($scope.user, function(response, err) {

                            var errorMessage = '';
                            $scope.disabled = false;
                            $scope.loader = false;
                            if (response.code == statusCode.ok) {
                                if (formDataFileUpload) {
                                    var formData = new FormData();
                                    formData.append('id', response.data.userDataNew._id);
                                    formData.append('file', formDataFileUpload);

                                    AuthenticationService.uploadImage().save(formData, function(resp) {
                                        if (resp.code == statusCode.ok) {
                                            $state.go('verify-email');
                                        } else {
                                            logger.logError(response.message);
                                        }
                                    });
                                } else {
                                    $state.go('verify-email');
                                }
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                });
            }
        };*/


        /**
         * Function is use to get Invite User list
         * @access private
         * @return json
         * Created by sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.getInviteUser = function() {
            if($stateParams.token){
                AuthenticationService.getInviteUser().save({ token: $stateParams.token }, function(response, err) {
                    if (response.code == statusCode.ok) {
                        $scope.registerForm = response.data
                    } else {
                        logger.logError(response.message);
                    }
                });                
            }
        }

        /**
         * Function is use to update Complete Register
         * @access private
         * @return json
         * Created by sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.updateCompleteRegister = function(form) {

            if (form.$valid) {
                $scope.loader = true;
                $scope.disabled = true;

                AuthenticationService.updateCompleteRegister().save($scope.registerForm, function(response, err) {

                    var errorMessage = '';
                    $scope.disabled = false;
                    $scope.loader = false;
                    if (response.code == statusCode.ok) {
                        if (formDataFileUpload) {
                            var formData = new FormData();
                            formData.append('id', response.data._id);
                            formData.append('file', formDataFileUpload);

                            AuthenticationService.uploadImage().save(formData, function(resp) {
                                if (resp.code == statusCode.ok) {
                                    logger.logSuccess(resp.message);
                                    $state.go('login');
                                } else {
                                    logger.logError(resp.message);
                                }
                            });
                        } else {
                            logger.logSuccess(response.message);
                            $state.go('login');
                        }
                    } else {
                        logger.logError(response.message);
                    }
                });
            }
        };



        //Stripe Card init
        /*var stripe = Stripe('pk_test_aWNJaATrgKB34tDpFwGGX8nI');
        $scope.stripeCard = function() {
            var elements = stripe.elements();
            var style = {
                base: {
                    color: '#333',
                    lineHeight: '24px',
                    fontSmoothing: 'antialiased',
                    fontSize: '12px',
                    '::placeholder': {
                        color: '#999'
                    }
                },
                invalid: {
                    color: '#a94442',
                    iconColor: '#a94442'
                }
            };

            $scope.card = elements.create('card', { hidePostalCode: true, style: style });
            $scope.card.mount('#card-element');

            $scope.card.addEventListener('change', function(event) {
                var displayError = document.getElementById('card-errors');
                if (event.error) {
                    displayError.textContent = event.error.message;
                } else {
                    displayError.textContent = '';
                }
            });
        }*/

        /**
         * Function is use user Forgot Password
         * @access private
         * @return json
         * Created by sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.userForgotPassword = function(loginform){
            console.log("INSIDE FORGOT Password");
            $scope.forgot_password = loginform;
            console.log($scope.forgot_password);
            AuthenticationService.userForgotPassword().save($scope.forgot_password, function(response) {
                console.log("RESPONSE", response);
                // $scope.disabled = false;
                // $scope.loader = false;
                if (response.status == 1) {
                    console.log("INSIDE STATUS");
                    // $scope.isPasswordSent = true;
                    logger.logSuccess(response.message);
                    $state.go('login');
                } else {
                    console.log("INSIDE Error");
                    logger.logError(response.message);
                }
            });
        }

        $scope.setNewPassword = function(loginform){
            console.log("INSIDE setNewPassword");
            var set_new_password = loginform;
            console.log("Confirm New Password", set_new_password);
            if(set_new_password.password === set_new_password.confirm_password){
                    var obj = {
                        password: set_new_password.password,
                        forgot_token: $stateParams.forgot_token
                    }
                    AuthenticationService.setNewPassword().save(obj, function(response) {
                    console.log("RESPONSE", response);
                    if (response.status == 1) {
                        console.log("INSIDE STATUS");
                        logger.logSuccess(response.message);
                        $state.go('login');
                    } else {
                        console.log("INSIDE Error");
                        logger.logError(response.message);
                    }
                });
            } else{
                logger.log("Confirm password does not match with password!");
            }
            
        }


        /**
         * Function is use reset Password
         * @access private
         * @return json
         * Created by sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.resetPassword = function(formData, form) {
            if (form.$valid) {
                $scope.loader = true;
                $scope.disabled = true;
                $scope.userData = new Object();
                $scope.userData.reset_key = $stateParams.reset_key;
                $scope.userData.password = formData.password;

                AuthenticationService.resetPassword().save($scope.userData, function(response) {
                    $scope.disabled = true;
                    $scope.loader = true;
                    if (response.code == statusCode.ok) {
                        logger.logSuccess(response.message);
                        $state.go('login');
                    } else if (response.code == statusCode.warning) {
                        logger.logWarning(response.message);
                        $state.go('login');
                    } else {
                        logger.logError(response.message);
                    }
                })

                
            }
        };

        /**
        * Function is used to get email using activation_key for complete registration
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.getEmailUsingKey = function(){
            if($stateParams.activation_key){
                AuthenticationService.getEmailUsingKey().get({id:$stateParams.activation_key},function(response, err){
                    if(response.status == 1){
                        $scope.user = response.data;
                        $scope.status = response.status; 
                    }else{
                        $scope.user = {};
                        $scope.status = response.status; 
                        
                    }
                })
            }
        };


        $scope.getEmailUsingPassword = function(){
            console.log("EmailUsing PAsspword",$stateParams.forgot_token);
            if($stateParams.forgot_token){
                AuthenticationService.getEmailUsingPassword().get({id:$stateParams.forgot_token},function(response, err){
                    if(response.status == 1){
                        $scope.user = response.data;
                        $scope.status = response.status; 
                    }else{
                        $scope.user = {};
                        $scope.status = response.status; 
                        
                    }
                })
            }
        };
        

        $scope.completeUserRegistration = function(form){
            if (form.$valid) {
                $scope.disabled = true;
                var user = $scope.user;
                user.activation_key = $stateParams.activation_key;
                if($scope.user.password == $scope.user.confirm_password){    
                    AuthenticationService.completeUserRegistration().save(user, function(response) {
                        $scope.disabled = false;
                        if(response.status == 1){
                            logger.logSuccess(response.message);
                            $state.go('login');
                        }else{
                            logger.logError(response.message);
                        }
                    })
                }else{
                    logger.logError("Confirm password does not match with password!");
                }
            }
        };


    }
]);
