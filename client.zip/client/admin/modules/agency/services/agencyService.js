"use strict"

angular.module("Agency")

.factory('AgencyService', ['$http', '$resource', function($http, $resource) {
 
    var listAgencyBySuperAdmin = function() {
        return $resource(webservices.listAgencyBySuperAdmin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteAgencyBySuperAdmin = function(id) {
        return $resource(webservices.deleteAgencyBySuperAdmin, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }


    var addAgencyBySuperAdmin = function() {
        return $resource(webservices.addAgencyBySuperAdmin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAgencyByIdBySuperAdmin = function(id) {
        return $resource(webservices.getAgencyByIdBySuperAdmin, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var updateAgencyBySuperAdmin = function() {
        return $resource(webservices.updateAgencyBySuperAdmin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var changeAgencyStatusBySuperAdmin = function() {
        return $resource(webservices.changeAgencyStatusBySuperAdmin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllCountriesInSuperAdmin = function() {
        return $resource(webservices.getAllCountriesInSuperAdmin, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getAllSubscriptionsBySuperAdmin = function() {
        return $resource(webservices.getAllSubscriptionsBySuperAdmin, null, {
            get: {
                method: 'GET'
            }
        });
    }

    var agencySubscriptionActivateSuperAdmin = function() {
        return $resource(webservices.agencySubscriptionActivateSuperAdmin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    return {
        listAgencyBySuperAdmin: listAgencyBySuperAdmin,
        deleteAgencyBySuperAdmin: deleteAgencyBySuperAdmin,
        addAgencyBySuperAdmin: addAgencyBySuperAdmin,
        getAgencyByIdBySuperAdmin: getAgencyByIdBySuperAdmin,
        updateAgencyBySuperAdmin: updateAgencyBySuperAdmin,
        changeAgencyStatusBySuperAdmin: changeAgencyStatusBySuperAdmin,
        getAllCountriesInSuperAdmin: getAllCountriesInSuperAdmin,
        getAllSubscriptionsBySuperAdmin: getAllSubscriptionsBySuperAdmin,
        agencySubscriptionActivateSuperAdmin: agencySubscriptionActivateSuperAdmin
    }

}]);
