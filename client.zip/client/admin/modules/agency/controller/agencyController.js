"use strict";

angular.module("Agency")

interpreterApp.controller("agencyController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger', 'ngTableParams', 'ngTableParamsService', 'AgencyService','blockUI',
    function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal, logger, ngTableParams, ngTableParamsService, AgencyService , blockUI) {
               
        /**
        * Variable is used for update agency
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Nov-2017
        **/
        if ($state.params.id) {
            $scope.isUpdate = true;
        } else {
            $scope.isUpdate = false;
        };

        /**
        * Variable is used to active class on leftbar
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Nov-2017
        **/
        $rootScope.menuAgency = ['admin_listAgency', 'admin_addAgency', 'admin_viewAgency', 'admin_editAgency'];
        
        /**
        * Function and variable is used to check format of image upload
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Nov-2017
        **/
        $scope.myImage='';
        $scope.myCroppedImage='';
        $scope.isImageSelected=false;
        $scope.isCropVisible=false;
        var handleFileSelect=function(evt) {
            $scope.isImageSelected=false;
            $scope.isCropVisible=true;
          var file=evt.currentTarget.files[0];
          var reader = new FileReader();
          reader.onload = function (evt) {
            $scope.$apply(function($scope){
              $scope.myImage=evt.target.result;
            });
          };
          reader.readAsDataURL(file);
        };
        angular.element(document.querySelector('#fileInput')).on('change',handleFileSelect);
        $scope.openFileBrowse = function(fileInputSelector) {
            angular.element(document.querySelector(fileInputSelector)).trigger('click');
        };

        var formDataFileUpload = '';
        $scope.imageBase64 = '';
        angular.element(document).ready(function() {
            setTimeout(function() {
                if(document.getElementById('fileInput')!=null){
                    document.getElementById('fileInput').addEventListener('change', function(evt) {
                        var files = evt.target.files;
                        var file = files[0];
                        if (files && file) {
                            var splitFileName = file.name.split('.');
                            var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                            if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {
                                if (file.size > 6291456) {
                                    logger.log('File size cannot exceed limit of 6 mb');
                                    document.getElementById("fileInput").value = "";
                                } else {
                                    formDataFileUpload = file;
                                    // formDataFileUpload.append('file', file);
                                    var reader = new FileReader();
                                    reader.onload = function(readerEvt) {
                                        $scope.imageBase64 = btoa(readerEvt.target.result);
                                        $scope.$apply();
                                        document.querySelector('#imgTag').src = 'data:image/' + ext + ';base64,' + $scope.imageBase64;
                                    };
                                    reader.readAsBinaryString(file);
                                }
                            } else {
                                document.getElementById("fileInput").value = "";
                                bootbox.alert('Invalid image format');
                            }
                        }
                    });
                }
            }, 500);
        });

        /**
        * Function is used to get agency by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Nov-2017
        **/
        $scope.listAgencyBySuperAdmin = function() {
            ngTableParamsService.set('', '', '', '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.clientList = [];
                    AgencyService.listAgencyBySuperAdmin().save($scope.paramUrl, function(response, err) {
                        if (response.status == 1) {
                            $scope.agencyList = response.data;
                            console.log("$scope.agencyList", $scope.agencyList);
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };

        /**
        * Function is used to get agency by super admin through searching
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Nov-2017
        **/
        $scope.listAgencyBySuperAdminSearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.clientList = [];
                    AgencyService.listAgencyBySuperAdmin().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.agencyList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        /**
        * Function is used to add agency by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Nov-2017
        **/
        $scope.addAgencyBySuperAdmin = function() {
            if($scope.isImageSelected==true){
                $scope.agency.imageFile = $scope.myCroppedImage;
            }    
            AgencyService.addAgencyBySuperAdmin().save($scope.agency, function(response) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $state.go('admin_listAgency');
                } else {
                    logger.logError(response.message);
                }

            });
        };

        /**
        * Function is used to get agency by super admin through id
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Nov-2017
        **/
        $scope.getAgencyByIdBySuperAdmin = function(){
            $scope.userDefaultImage = "./../../../assets/images/default-img.png";
                if($stateParams.id){
                    AgencyService.getAgencyByIdBySuperAdmin().get({id:$stateParams.id},function(response, err){
                        if(response.status == 1){
                            // setTimeout(function(){
                            var agency = response.data.result;
                            agency.email = agency.user_id.email;
                            if(agency.profile_pic!='' && agency.profile_pic!=undefined){
                                $scope.userDefaultImage=agency.profile_pic;
                            }
                            $scope.agency = agency;
                            $scope.agencySubscriptionDetails = response.data.agencySubscriptionData;
                            // },150)
                        }else{
                            $scope.agency = {};
                        }
                    })
                }
        };

        /**
        * Function is used to update agency by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Nov-2017
        **/
        $scope.updateAgencyBySuperAdmin = function() {
            if($scope.isImageSelected==true){
                $scope.agency.imageFile = $scope.myCroppedImage;
            }
            AgencyService.updateAgencyBySuperAdmin().save($scope.agency, function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $state.go('admin_listAgency');
                } else {
                    logger.logError(response.message);
                }
            });
        };
        
        /**
        * Function is used to delete the agency by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Nov-2017
        **/
        $scope.deleteAgencyBySuperAdmin = function(id,$event) {
            $event.stopPropagation();
            bootbox.confirm('Are you sure, you want to delete this agency?', function(r) {
                if (r) {
                    AgencyService.deleteAgencyBySuperAdmin().delete({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listAgencyBySuperAdmin();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        
        /**
        * Function is used to view agency by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Nov-2017
        **/
        $scope.viewAgencyBySuperAdmin = function(agency) {
            $state.go('admin_viewAgency', {id:agency._id});
        };

        /**
        * Function is used to change the status of the agency by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Nov-2017
        **/
        $scope.changeAgencyStatusBySuperAdmin = function(id,status) {
            var agency = {
                id: id,
                status: status
            }
            AgencyService.changeAgencyStatusBySuperAdmin().save(agency,function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $scope.listAgencyBySuperAdmin();
                } else {
                    logger.log(response.message);
                }
            });
        };

        /**
        * Function is used to get All countries in drop down
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 29-Jan-2017
        **/
        $scope.getAllCountriesInSuperAdmin = function(){
            AgencyService.getAllCountriesInSuperAdmin().get({},function(response, err){
                if(response.status == 1){
                    $scope.superAdminCountries = response.data;
                    $scope.agency = {};
                    for(var i=0; i<$scope.superAdminCountries.length; i++){
                        if($scope.superAdminCountries[i].country_code == 'us'){
                            $scope.agency.country_id = $scope.superAdminCountries[i]._id 
                        }
                    }
                }else{
                    $scope.superAdminCountries = {};
                }
            })
        }

        /**
        * Uib Modal is used to activate agency by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 28-Feb-2018
        **/
        $scope.activateAgencyModal = function(agencyData){
            if(agencyData.activation_key != '' || agencyData.activation_key != null || agencyData.activation_key != undefined){
                $uibModal.open({
                    templateUrl: 'modules/agency/views/activateAgencyModal.html',
                    size: 'md',
                    controller: function($scope,$rootScope, $uibModalInstance){
                    
                        $scope.closeuib = function() {
                            $uibModalInstance.close();
                        }
                        
                        var agency = {};
                        agency._id = agencyData._id;
                        agency.user_id =  agencyData.user_id;
                        agency.email =  agencyData.email;
                        $scope.agency = agency;

                        $scope.activateAgencySuperAdmin = function(form){
                            if(form.$valid){
                                $scope.loader = true;
                                $scope.disabled = true;
                                if($scope.agency.confirm_password == true){    
                                    // AgencyService.activateAgencySuperAdmin().save($scope.agency,function(response, err) {
                                    //     if (response.status == 1) {
                                    //         logger.logSuccess(response.message);
                                    //         $uibModalInstance.close();
                                    //         $state.reload();
                                    //     } else {
                                    //         logger.log(response.message);
                                    //     }
                                    // });
                                    $localStorage.agencyData = agency;
                                    $scope.closeuib();
                                    $state.go('admin_subscriptionPlan');          
                                }else{
                                    $scope.disabled = false;
                                    logger.log("Confirm password does not match with password!");
                                }
                            }
                        }
                    }
                });
            }else{
                logger.logError("Oops something is wrong! Please try again.");
            }
        }

        /**
        * Uib Modal is used to back to the agency listing by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 28-Feb-2018
        **/
        $scope.backToAgencyListing = function(){
            delete $localStorage.agencyData;
            delete $localStorage.subscription_id;
            delete $localStorage.plan_name;
            delete $localStorage.amount;
            delete $state.go('admin_listAgency');
        }

        /**
        * Uib Modal is used to get all subscription plans
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 28-Feb-2018
        **/
        $scope.getAllSubscriptionsBySuperAdmin = function() {
            AgencyService.getAllSubscriptionsBySuperAdmin().get(function(response, err) {
                if (response.status == 1) {
                    $scope.subscriptions = response.data;
                    console.log("$scope.subscriptions",$scope.subscriptions);
                } else {
                    $scope.subscriptions = [];
                    logger.logError(response.message);
                }
            });
        };

        /**
        * Function is used to view subscription modal 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 28-Feb-2018
        **/
        $scope.viewCardDetailModel = function(subscription) {
            $localStorage.subscription_id = subscription._id;
            $localStorage.plan_name = subscription.plan_name;
            $localStorage.amount = subscription.amount;
            $uibModal.open({
                templateUrl: 'modules/agency/views/subscriptionModal.html',
                size: "md",
                controller: function($scope,$rootScope, $uibModalInstance) {
                    
                    var stripe = Stripe(stripe_published_key);
                    var elements = stripe.elements();

                    setTimeout(function(){
                        stripeCard();                  
                    },200)

                    $scope.closeuib = function() {
                        $uibModalInstance.close();
                    }

                    $scope.getData = function(){
                        $scope.plan_name = $localStorage.plan_name;
                        $scope.amount = $localStorage.amount;
                    }

                    function stripeCard() {
                        var style = {
                            base: {
                                color: '#333',
                                lineHeight: '24px',
                                fontSmoothing: 'antialiased',
                                fontSize: '14px',
                                '::placeholder': {
                                    color: '#999'
                                }
                            },
                            invalid: {
                                color: '#a94442',
                                iconColor: '#a94442'
                            }
                        };

                        $scope.card = elements.create('card', { hidePostalCode: true, style: style });
                        $scope.card.mount('#card-element');

                        $scope.card.addEventListener('change', function(event) {
                            var displayError = document.getElementById('card-errors');
                            if (event.error) {
                                displayError.textContent = event.error.message;
                            } else {
                                displayError.textContent = '';
                            }
                        });

                        $scope.agencySubscriptionActivateSuperAdmin = function() {
                            $scope.closeuib();
                            blockUI.start('Payment is in Process. Please wait...');
                            stripe.createToken($scope.card).then(function(result) {
                                if (result.error) {
                                    // Inform the user if there was an error
                                    var errorElement = document.getElementById('card-errors');
                                    errorElement.textContent = result.error.message;
                                } else {
                                    // Send the token to your server
                                    var agency =  $localStorage.agencyData;
                                    agency.subscription_id = $localStorage.subscription_id;
                                    agency.card_holder_name = $scope.card_holder_name;
                                    agency.token = result.token.id;
                                    console.log("token",result.token.id);
                                    console.log("card_holder_name",$scope.card_holder_name);
                                    console.log("subscription_id",$localStorage.subscription_id);    
                                    console.log("agency",agency);
                                    
                                    AgencyService.agencySubscriptionActivateSuperAdmin().save(agency, function(response) {
                                        if (response.status == 1) {
                                            delete $localStorage.agencyData;
                                            delete $localStorage.subscription_id;
                                            delete $localStorage.plan_name;
                                            delete $localStorage.amount;
                                            blockUI.stop();
                                            logger.logSuccess(response.message); 
                                            $state.go('admin_listAgency');
                                        } else {
                                            delete $localStorage.agencyData;
                                            delete $localStorage.subscription_id;
                                            delete $localStorage.plan_name;
                                            delete $localStorage.amount;
                                            blockUI.stop();
                                            logger.logError(response.message);
                                            $state.go('admin_listAgency');
                                        }
                                    })
                                }
                                $scope.$emit('stop', true);
                            });
                        }


                    }

                }
            });
        };
       
                
    }
]);
