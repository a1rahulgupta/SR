"use strict"

angular.module("Interpreter")

.factory('InterpreterService', ['$http', '$resource', function($http, $resource) {
 
    var listAgencySuperAdmin = function() {
        return $resource(webservices.listAgencySuperAdmin, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var listInterpretersSuperAdmin = function() {
        return $resource(webservices.listInterpretersSuperAdmin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteInterpreterSuperAdmin = function(id) {
        return $resource(webservices.deleteInterpreterSuperAdmin, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var changeInterpreterStatusSuperAdmin = function() {
        return $resource(webservices.changeInterpreterStatusSuperAdmin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getInterpreterViewBySuperAdmin = function(id) {
        return $resource(webservices.getInterpreterViewBySuperAdmin, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getAllServicesBySuperAdmin = function() {
        return $resource(webservices.getAllServicesBySuperAdmin, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var listBookingInterpreterSuperAdmin = function() {
        return $resource(webservices.listBookingInterpreterSuperAdmin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getInterpreterSchedulingDetailsSuperAdmin = function() {
        return $resource(webservices.getInterpreterSchedulingDetailsSuperAdmin, null, {
            post: {
                method: 'POST'
            }
        });
    }


    var getBookingDetailCalendarSuperAdmin = function() {
        return $resource(webservices.getBookingDetailCalendarSuperAdmin, null, {
            get: {
                method: 'POST'
            }
        });
    }

    var getInterpreterBySuperAdmin = function(id) {
        return $resource(webservices.getInterpreterBySuperAdmin, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getAllLanguagesSuperAdmin = function() {
        return $resource(webservices.getAllLanguagesSuperAdmin, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var addInterpreterBySuperAdmin = function(formData) {
        return $resource(webservices.addInterpreterBySuperAdmin, null, {
            save: {
                method: 'POST',
                transformRequest: angular.identity,
                headers: { 'Content-Type': undefined }
            }
        });
    }

    var getAllCountriesInSuperAdmin = function() {
        return $resource(webservices.getAllCountriesInSuperAdmin, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var updateInterpreterBySuperAdmin = function() {
        return $resource(webservices.updateInterpreterBySuperAdmin, null, {
            save: {
                method: 'POST',
                transformRequest: angular.identity,
                headers: { 'Content-Type': undefined }
            }
        });
    }

    var activateInterpreterSuperAdmin = function() {
        return $resource(webservices.activateInterpreterSuperAdmin, null, {
            get: {
                method: 'POST'
            }
        });
    }

    return {

        listAgencySuperAdmin: listAgencySuperAdmin,
        listInterpretersSuperAdmin: listInterpretersSuperAdmin,
        deleteInterpreterSuperAdmin: deleteInterpreterSuperAdmin,
        changeInterpreterStatusSuperAdmin: changeInterpreterStatusSuperAdmin,
        getInterpreterViewBySuperAdmin: getInterpreterViewBySuperAdmin,
        getAllServicesBySuperAdmin: getAllServicesBySuperAdmin,
        listBookingInterpreterSuperAdmin: listBookingInterpreterSuperAdmin,
        getInterpreterSchedulingDetailsSuperAdmin: getInterpreterSchedulingDetailsSuperAdmin,
        getBookingDetailCalendarSuperAdmin: getBookingDetailCalendarSuperAdmin,
        getInterpreterBySuperAdmin: getInterpreterBySuperAdmin,
        getAllLanguagesSuperAdmin: getAllLanguagesSuperAdmin,
        addInterpreterBySuperAdmin: addInterpreterBySuperAdmin,
        getAllCountriesInSuperAdmin: getAllCountriesInSuperAdmin,
        updateInterpreterBySuperAdmin: updateInterpreterBySuperAdmin,
        activateInterpreterSuperAdmin: activateInterpreterSuperAdmin,

    }

}]);
