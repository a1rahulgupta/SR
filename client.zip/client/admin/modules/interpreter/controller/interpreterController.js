"use strict";

angular.module("Interpreter")
interpreterApp.controller("interpreterController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger', 'InterpreterService', 'ngTableParams', 'ngTableParamsService', 'CommonService',
    function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal, logger, InterpreterService, ngTableParams, ngTableParamsService, CommonService) {

        
        /**
        * Variable is used for active class on leftbar
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 01-Feb-2018
        **/
        $rootScope.menuInterpreter = ['admin_listInterpreters', 'admin_addInterpreter', 'admin_viewInterpreter', 'admin_editInterpreter'];

        /**
        * Function is used block the view while fetching data
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 02-Feb-2018
        **/
        $scope.noBlock = function() {
            blockUIConfig.requestFilter = function(config) {
                return false;
            }
        };

        /**
        * Variable is used for update interpreter
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        if ($state.params.id) {
            $scope.isUpdate = true;
        } else {
            $scope.isUpdate = false;
        }; 
        $scope.interpreter={};
        $scope.interpreter.gender='Male';
        $scope.interpreter.working_status = 'full time';
        $scope.selectAgency = {};
        $scope.interpreter.certificate = false;
        $scope.interpreter.court_certified = false;
        $scope.interpreter.court_screened = false;
        $scope.interpreter.working_status = 'full time';
        $scope.interpreter.working_days = {
            monday: true,
            tuesday: true,
            wednesday: true,
            thursday: true,
            friday: true,
            saturday: false,
            sunday: false
        }
        
        /**
        * Function and variable is used for image format
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.isCropVisible=false;
        $scope.myImage='';
        $scope.myCroppedImage='';
        $scope.isImageSelected=false;
        var handleFileSelect=function(evt) {
            $scope.isImageSelected=false;
            $scope.isCropVisible=true;
            var file=evt.currentTarget.files[0];
            var reader = new FileReader();
            reader.onload = function (evt) {
                $scope.$apply(function($scope){
                    $scope.myImage=evt.target.result;
                });
            };
            reader.readAsDataURL(file);
        };
        angular.element(document.querySelector('#fileInput')).on('change',handleFileSelect);
        $scope.openFileBrowse = function(fileInputSelector) {
            angular.element(document.querySelector(fileInputSelector)).trigger('click');
        };
      
        var formDataFileUpload = '';
        $scope.imageBase64 = '';
        angular.element(document).ready(function() {
            setTimeout(function() {
                if(document.getElementById('fileInput')!=null){
                    document.getElementById('fileInput').addEventListener('change', function(evt) {
                        var files = evt.target.files;
                        var file = files[0];
                        if (files && file) {
                            var splitFileName = file.name.split('.');
                            var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                            if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {
                                if (file.size > 6291456) {
                                    logger.log('File size cannot exceed limit of 6 mb');
                                    document.getElementById("fileInput").value = "";
                                } else {
                                    formDataFileUpload = file;
                                    // formDataFileUpload.append('file', file);
                                    var reader = new FileReader();
                                    reader.onload = function(readerEvt) {
                                        $scope.imageBase64 = btoa(readerEvt.target.result);
                                        $scope.$apply();
                                        document.querySelector('#imgTag').src = 'data:image/' + ext + ';base64,' + $scope.imageBase64;
                                    };
                                    reader.readAsBinaryString(file);
                                }
                            } else {
                                document.getElementById("fileInput").value = "";
                                bootbox.alert('Invalid image format');
                            }
                        }
                    });
                }
            }, 500);
        });

        /**
        * variable and function is used for multiple language select 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.languages=[{}];
        $scope.addMoreLanguage =function(){
            $scope.languages.push({isRemovable:true});
        };

        $scope.removeLanguageAt =function(elementIndex){
            $scope.languages.splice(elementIndex, 1);
            if($scope.interpreter.languages!=undefined && $scope.interpreter.languages[elementIndex]!=undefined){
                $scope.interpreter.languages.splice(elementIndex, 1);
            }
        };

        /**
        * Variable is used for service list
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.localLang = {
            selectAll       : "Tick all",
            selectNone      : "Tick none",
            reset           : "Undo all",
            search          : "Type here to search...",
            nothingSelected : "Nothing is selected"         //default-label is deprecated and replaced with this.
        };        

        /**
        * Function is used for timepicker reflection 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Nov-2017
        **/
        $scope.fromDateChanged = function() {
            var minutesAdded = 30;
            $scope.working_to_full = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
            $scope.minTime = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
            setTimeout(function(){
                angular.element(document.querySelector('#working_from_id')).trigger('change');
                angular.element(document.querySelector('#working_to_id')).trigger('change');
            },1000);

        } 

        /**
        * Function is used to validate certificate upload 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Nov-2017
        **/
        $scope.toggleFileSelection = function(){
            if(!$scope.interpreter.court_certified){
                if($scope.interpreter.certificates!=undefined){
                    $scope.interpreter.certificates.court_certified = undefined;    
                }
                
            }
            if(!$scope.interpreter.court_screened){
                if($scope.interpreter.certificates!=undefined){
                    $scope.interpreter.certificates.court_screened = undefined;
                }
                

            }
        };

        /**
        * Function is used to check extension of a file 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.ckhExtension = function(filePath){
            var fileType = filePath;
            if(fileType!=undefined && typeof fileType=='string'){
                var fileName = fileType.split('/').reverse()[0];
                var file_ext = fileName.split('.').reverse()[0];
                var file_ext = file_ext.toLowerCase();
            }else{
                return file_ext='';
            }
            return file_ext;            
        }

        /**
        * Function is used to set availability of interpreter by super admin 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.currentDate='';
        $scope.switchdesabled =  false;
        $scope.setAvailabilityOnClick = function(data) {
            $scope.eventData = data;
            $scope.switchdesabled =  false;
            if(typeof data['_start'] == "undefined"){
                $scope.currentDate = new Date();
            }else{
                $scope.currentDate = data._start._d;
            }
            $scope.serviceprovider = {
                isAvailable: true
            }
            if(data.title !='Not Working'){             
                if(data.title==='Working'){
                    $scope.serviceprovider.isAvailable=true;
                }
                else{
                    $scope.serviceprovider.isAvailable=false; 
                }
            }else{
                $scope.serviceprovider.isAvailable=false;
                $scope.switchdesabled =  true;
            }
        }

        /**
        * Function is used to set schedule of interpreter by super admin 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.setSchedule = function(formData){
            var data = $scope.eventData;
            console.log("eventData", data);
            InterpreterService.getBookingDetailForInterpreterCalendarInAgency().get({}, function(response) {
              console.log("INSIDE getBookingDetailForInterpreterCalendarInAgency", $scope.scheduleData);
            })
            if(data.title == 'Working'){
                bootbox.confirm('Are you sure you want to change availablity for date '+moment($scope.currentDate).format('DD-MM-YYYY')+  ' ?', function(r) {
                    if (r) {
                        if(formData.isAvailable){ 
                            $scope.scheduleData = {
                                'status': true,
                                'date': $scope.currentDate,
                                'interpreter_id': $state.params.id
                            };
                        }else{
                             $scope.scheduleData = {
                                'status': false,
                                'date': $scope.currentDate,
                                'interpreter_id': $state.params.id
                            };
                        }
                        var data = $scope.scheduleData;    
                        InterpreterService.addInterpreterLeaveInAgency().save($scope.scheduleData, function(response) {
                            $scope.disabled = false;
                            $scope.loader = false;
                            if (response.status == 1) {
                                logger.logSuccess(response.message);
                                $state.reload();
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }  
                })
            } else {
                bootbox.confirm('Are you sure you want to change availablity for date '+moment($scope.currentDate).format('DD-MM-YYYY')+  ' ?', function(r) {
                    if (r) {
                        if(formData.isAvailable){ 
                            $scope.scheduleData = {
                                'status': true,
                                'date': $scope.currentDate
                            };
                        }else{
                            $scope.scheduleData = {
                                'status': false,
                                'date': $scope.currentDate
                            };
                        }
                        InterpreterService.updateInterpreterLeaveInAgency().save({id: data.id}, function(response) {
                            if (response.status == 1) {
                                logger.logSuccess(response.message);
                                $state.reload();
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                   
                })
            }
        }

        /**
        * Function is used to get agency by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Feb-2018
        **/
        $scope.listAgencySuperAdmin = function(){
            InterpreterService.listAgencySuperAdmin().get({},function(response, err){
                if(response.status == 1){
                    $scope.agencyList = response.data;
                }else{
                    $scope.agencyList = {};
                }
            })
        };

        /**
        * Function is used to list interpreters by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Feb-2018
        **/
        $rootScope.listInterpretersSuperAdmin = function() {
            ngTableParamsService.set('', '', '', '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    if($scope.selectAgency.agency_id != '' && $scope.selectAgency.agency_id != null && $scope.selectAgency.agency_id != undefined){
                        $scope.paramUrl.agency_id = $scope.selectAgency.agency_id;
                    }
                    $scope.interpreterList = [];
                    InterpreterService.listInterpretersSuperAdmin().save($scope.paramUrl, function(response, err) {
                        if (response.status == 1) {
                            $scope.interpreterList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };

        /**
        * Function is used to search interpreters by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Feb-2018
        **/
        $scope.listInterpretersSearchingSuperAdmin = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    if($scope.selectAgency.agency_id != '' && $scope.selectAgency.agency_id != null && $scope.selectAgency.agency_id != undefined){
                        $scope.paramUrl.agency_id = $scope.selectAgency.agency_id;
                    }
                    $scope.interpreterList = [];
                    InterpreterService.listInterpretersSuperAdmin().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.interpreterList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

         /**
        * Function is used to delete the interpreter by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Feb-2018
        **/
        $scope.deleteInterpreterSuperAdmin = function(id,$event) {
            $event.stopPropagation();
            bootbox.confirm('Are you sure, you want to delete this interpreter?', function(r) {
                if (r) {
                    InterpreterService.deleteInterpreterSuperAdmin().delete({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listInterpretersSuperAdmin();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        /**
        * Function is used to change the status of a interpreter by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Feb-2017
        **/
        $scope.changeInterpreterStatusSuperAdmin = function(id,status) {
            var interpreter = {
                id: id,
                status: status
            }
            InterpreterService.changeInterpreterStatusSuperAdmin().save(interpreter,function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $scope.listInterpretersSuperAdmin();
                } else {
                    logger.logError(response.message);
                }
            });
        };

        /**
        * Function is used to view interpreter of an interpreter by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Feb-2017
        **/
        $scope.getInterpreterViewBySuperAdmin = function(){
            /* Variables is used to initialize the working hours on document ready */
            var currentDate = new Date();
            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
            $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
            
            setTimeout(function(){
                angular.element(document.querySelector('#working_from_id')).trigger('change');
                angular.element(document.querySelector('#working_to_id')).trigger('change');
            },1000); 
            /* End */
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            if($stateParams.id){
                InterpreterService.getInterpreterViewBySuperAdmin().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var interpreter = response.data;
                        if(interpreter.working_from !=undefined && interpreter.working_to !=undefined){
                            var tmpTime,tmpTime1;
                            tmpTime = CommonService.convertTo24Format(interpreter.working_from);
                            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                            $scope.minTime = $scope.working_from_full1;
                            tmpTime1 = CommonService.convertTo24Format(interpreter.working_to);
                            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime1.hour,tmpTime1.minute,0);
                        }

                        //Copy services array due to multilple languages status changed
                        $scope.languageArray = angular.copy(interpreter.languages); 
                        //End

                        if(interpreter.languages!=undefined && interpreter.languages.length>0){
                            $scope.languages=[];
                            var tmpObj={};
                            angular.forEach(interpreter.languages, function(language, key) {
                                tmpObj = language;
                                if(key!=0){
                                    tmpObj.isRemovable=true;
                                }else{
                                    tmpObj.isRemovable=false;
                                }
                                $scope.languages.push(tmpObj);
                            });
                            interpreter.languages = interpreter.languages;
                        }else{
                            $scope.languages=[{}];
                        }
                        if(interpreter.working_days!=undefined){
                            interpreter.working_days = interpreter.working_days;
                        }
                        
                        if(interpreter.profile_pic!='' && interpreter.profile_pic!=undefined){
                            $scope.userDefaultImage=interpreter.profile_pic;
                        }

                        if(interpreter.certificates!=undefined && interpreter.certificates.court_certified != undefined){
                            interpreter.court_certified = true;
                        }
                        if(interpreter.certificates!=undefined && interpreter.certificates.court_screened != undefined){
                            interpreter.court_screened = true;
                        }
                        if(interpreter.certificates==undefined){ 
                            interpreter.certificates={};
                        }

                        //Copy services array due to multilple services status changed
                        $scope.serviceArray = angular.copy(interpreter.services); 
                        //End

                        setTimeout(function() {
                            for(var i=0; i<$scope.serviceList.length;i++){
                                for (var j=0;j<interpreter.services.length;j++) {
                                    if($scope.serviceList[i].name == interpreter.services[j].name
                                        && interpreter.services[j].ticked == true){
                                        $scope.serviceList[i].ticked=true;
                                        break;
                                    }
                                }
                            }
                            $scope.interpreter = interpreter;
                        }, 50);
                    }else{
                          $scope.interpreter = {};
                    }
                })
            }
        };

        /**
        * Function is used to get all service list by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Feb-2017
        **/
        $scope.getAllServicesBySuperAdmin = function(){
            InterpreterService.getAllServicesBySuperAdmin().get({},function(response, err){
                if(response.status == 1){
                    $scope.serviceList = response.data;
                }else{
                    $scope.serviceList = {};
                }
            })
        }

        /**
        * Function is used to list interpreters of an agency by interpreter id
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 08-Feb-2018
        **/
        $scope.listBookingInterpreterSuperAdmin = function() {
            ngTableParamsService.set('', '', '', '');
            if($state.params.id){
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    getData: function($defer, params) {
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.paramUrl.interpreter_id = $state.params.id;
                        $scope.bookingList = [];
                        InterpreterService.listBookingInterpreterSuperAdmin().save($scope.paramUrl, function(response, err) {
                            if (response.status == 1) {
                                $scope.bookingList = response.data;
                                var data = response.data;
                                $scope.totalCount = response.count;
                                params.total(response.count);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                }); 
            }
            
        };

        /**
        * Function is used to search interpreter booking by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Feb-2018
        **/
        $scope.listBookingInterpreterSearchingSuperAdmin = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            if($state.params.id){
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    getData: function($defer, params) {
                        ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.paramUrl.interpreter_id = $state.params.id;
                        $scope.bookingList = [];
                        InterpreterService.listBookingInterpreterSuperAdmin().save($scope.paramUrl, function(response) {
                            if (response.status == 1) {
                                $scope.bookingList = response.data;
                                var data = response.data;
                                $scope.totalCount = response.count;
                                params.total(response.count);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                })
            }    
        };

        /**
        * Variable and function is used to interpreter scheduling by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 08-Feb-2018
        **/
        $scope.eventSources = [
            function(start, end, timezone, callback){
                if($state.params.id){
                    InterpreterService.getInterpreterSchedulingDetailsSuperAdmin().post({interpreter_id: $state.params.id, startDate: start._d, endDate: end._d}, function(response) {
                        if(response.status == 1){
                            var events = []; 
                            $scope.interpreterSchedulingList = response.data;
                            angular.forEach($scope.interpreterSchedulingList,function(value, index) {
                                if(moment(value.startDate).format('MM-DD-YYYY') == moment().format('MM-DD-YYYY')){
                                    if (value.status) {
                                        var data = {                                                  
                                            title: 'Working',
                                        }
                                        $scope.setAvailabilityOnClick(data);
                                    }else{
                                        var data = {                                                  
                                            title: 'Not Working', 
                                        }
                                        $scope.setAvailabilityOnClick(data);

                                    }
                                }
                                if(value.status == true) {
                                    events.push({
                                        end: new Date(value.endDate),
                                        start: new Date(value.startDate),
                                        title: 'Working',
                                        color: '#167F45',
                                    });
                                } else if (value.leave_status == true){
                                    events.push({
                                        end: new Date(value.endDate), 
                                        start: new Date(value.startDate),
                                        id: value.id, 
                                        title: 'On leave',
                                        color: '#F35321',
                                    });
                                } else{
                                    events.push({
                                        end: new Date(value.endDate), 
                                        start: new Date(value.startDate), 
                                        title: 'Not Working',
                                        color: '#D40C00',
                                    });
                                }
                            });
                            callback(events);
                            $scope.calendarLoader = false;
                        }
                    })  
                }
            }
        ];

        /**
        * Function is used to interpreter scheduling details by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 08-Feb-2018
        **/
        $rootScope.getInterpreterSchedulingDetailsSuperAdmin = function() {
            var events = [];
            $scope.uiConfig = {
                calendar: {
                    height: 500,
                    editable: true,
                    displayEventTime: false,
                    ignoreTimezone: false,
                    header: {
                        left: 'prev',
                        center: 'title',
                        right: 'next' //'month basicWeek basicDay agendaWeek agendaDay'
                    },
                    eventClick: function(event, description) { 
                        $scope.getBookingDetailCalendarSuperAdmin(event.start._d);
                        if(event.title=='Not Working'||event.title=='Working' || event.title=='On leave'){
                            $scope.currentDate = '';
                            $scope.setAvailabilityOnClick(event);
                        }
                        else{
                            $scope.currentDate = '';
                        }
                    }
                }
            }
        }

        /**
        * Function is used to get interpreter booking detail of current date  by super admin on view
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Feb-2018
        **/
        $scope.getBookingDetailCalendarSuperAdmin = function(startDate){
            if($state.params.id) {
                if(!startDate){
                    startDate = new Date();
                    startDate = moment(startDate).format();
                }
                $scope.interpreterBookingDetails = [];
                InterpreterService.getBookingDetailCalendarSuperAdmin().get({interpreter_id:$state.params.id ,startDate: startDate, interpreter_id: $stateParams.id }, function(response) {
                    if (response.status == 1) {
                        $scope.interpreterBookingList = response.data;
                        $scope.interpreterBookingList.forEach(function(value, index) {
                            $scope.interpreterBookingDetails.push(value)
                        });
                    }
                })
            } 
        };

        /**
        * Function is used to get interpreter by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 9-Feb-2018
        **/
        $scope.getInterpreterBySuperAdmin = function(){
            /* Variables is used to initialize the working hours on document ready */
            var currentDate = new Date();
            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),12,0,0);
            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
            $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
            
            setTimeout(function(){
                angular.element(document.querySelector('#working_from_id')).trigger('change');
                angular.element(document.querySelector('#working_to_id')).trigger('change');
            },1000); 
            /* End */
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            if($stateParams.id){
                InterpreterService.getInterpreterBySuperAdmin().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var interpreter = response.data;
                        console.log("interpreter",interpreter);
                        if(interpreter.working_from !=undefined && interpreter.working_to !=undefined){
                            var tmpTime,tmpTime1;
                            tmpTime = CommonService.convertTo24Format(interpreter.working_from);
                            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                            $scope.minTime = $scope.working_from_full1;
                            tmpTime1 = CommonService.convertTo24Format(interpreter.working_to);
                            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime1.hour,tmpTime1.minute,0);
                        }

                        //Copy services array due to multilple languages status changed
                        $scope.languageArray = angular.copy(interpreter.languages); 
                        //End

                        if(interpreter.languages!=undefined && interpreter.languages.length>0){
                            $scope.languages=[];
                            var tmpObj={};
                            angular.forEach(interpreter.languages, function(language, key) {
                                tmpObj = language;
                                if(key!=0){
                                    tmpObj.isRemovable=true;
                                }else{
                                    tmpObj.isRemovable=false;
                                }
                                $scope.languages.push(tmpObj);
                            });
                            interpreter.languages = interpreter.languages;
                        }else{
                            $scope.languages=[{}];
                        }
                        if(interpreter.working_days!=undefined){
                            interpreter.working_days = interpreter.working_days;
                        }
                        
                        if(interpreter.profile_pic!='' && interpreter.profile_pic!=undefined){
                            $scope.userDefaultImage=interpreter.profile_pic;
                        }

                        if(interpreter.certificates!=undefined && interpreter.certificates.court_certified != undefined){
                            interpreter.court_certified = true;
                        }
                        if(interpreter.certificates!=undefined && interpreter.certificates.court_screened != undefined){
                            interpreter.court_screened = true;
                        }
                        if(interpreter.certificates==undefined){ 
                            interpreter.certificates={};
                        }

                        //Copy services array due to multilple services status changed
                        $scope.serviceArray = angular.copy(interpreter.services); 
                        //End

                        setTimeout(function() {
                            for(var i=0; i<$scope.serviceList.length;i++){
                                for (var j=0;j<interpreter.services.length;j++) {
                                    if($scope.serviceList[i].name == interpreter.services[j].name
                                        && interpreter.services[j].ticked == true){
                                        $scope.serviceList[i].ticked=true;
                                        break;
                                    }
                                }
                            }
                            $scope.$apply();
                        }, 500);
                        $scope.interpreter = interpreter;
                    }else{
                          $scope.interpreter = {};
                    }
                })
            }
        };

        /**
        * Function is used get all languages by super admin 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 9-Feb-2018
        **/
        $scope.getAllLanguagesSuperAdmin = function(){
            InterpreterService.getAllLanguagesSuperAdmin().get({},function(response, err){
                if(response.status == 1){
                    $scope.interpreterLanguages = response.data;
                }else{
                    $scope.interpreterLanguages = {};
                }
            })
        };

        /**
        * Function is used to add interpreter by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 9-Feb-2018
        **/
        $scope.addInterpreterBySuperAdmin = function() {
            if ($scope.form.$valid) {
                $scope.loader = true;
                $scope.disabled = true;

                if($scope.isImageSelected==true){
                    $scope.interpreter.imageFile = $scope.myCroppedImage;
                }
                var address = $scope.interpreter.address1+' '+$scope.interpreter.city+' '+ $scope.interpreter.state+' '+$scope.interpreter.zip;
                // Initialize the Geocoder
                var geocoder = new google.maps.Geocoder();
                if (geocoder) {
                    geocoder.geocode({
                        'address': address
                    }, function (results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            $scope.interpreter.lat = results[0].geometry.location.lat();
                            $scope.interpreter.lng = results[0].geometry.location.lng();
                            var formData = new FormData();
                            formData.append('interpreter',angular.toJson($scope.interpreter));
                            if($scope.interpreter.certificates){
                                if(typeof $scope.interpreter.certificates.court_certified == 'object'){
                                    formData.append('court_certified',$scope.interpreter.certificates.court_certified);
                                }
                                if(typeof $scope.interpreter.certificates.court_screened == 'object'){
                                    formData.append('court_screened',$scope.interpreter.certificates.court_screened);    
                                }
                            }
                            InterpreterService.addInterpreterBySuperAdmin().save(formData, function(response) {
                                var errorMessage = '';
                                $scope.disabled = false;
                                $scope.loader = false;
                                if (response.status == 1) {
                                    logger.logSuccess(response.message); 
                                    $state.go('admin_listInterpreters');
                                } else {
                                    logger.logError(response.message);
                                }

                            });
                        }else {
                            logger.logError('Please enter valid address this address does not find latitude and longitude of interpreter');
                            return false;
                        }
                    });
                }else{
                    logger.logError('Oops something is wrong! Please try agin.');
                }
            }
        };


        /**
        * Function is used to get all countries by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 9-Feb-2018
        **/
        $scope.getAllCountriesInSuperAdmin = function(){
            InterpreterService.getAllCountriesInSuperAdmin().get({},function(response, err){
                if(response.status == 1){
                    $scope.interpreterCountries = response.data;
                    for(var i=0;i<$scope.interpreterCountries.length;i++){
                        if($scope.interpreterCountries[i].country_code == 'us'){
                            $scope.interpreter.country_id = $scope.interpreterCountries[i]._id; 
                        }
                    }
                }else{
                    $scope.interpreterCountries = {};
                }
            })
        };

        /**
        * Function is used to update interpreter by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 9-Feb-2017
        **/
        $scope.updateInterpreterBySuperAdmin = function() {
            if ($scope.form.$valid) {
                $scope.loader = true;
                $scope.disabled = true;

                if($scope.isImageSelected==true){
                    $scope.interpreter.imageFile = $scope.myCroppedImage;
                }
                var interpreter = $scope.interpreter;
                var serviceArray = $scope.serviceArray;
                var hasFound = false;
                var tmp = {};
                for(var i=0; i< serviceArray.length; i++){
                    hasFound = false;
                    for(var j=0; j< interpreter.services.length; j++){
                        if(serviceArray[i].service_id == interpreter.services[j]._id){
                            hasFound = true;
                            break;
                        }
                    }
                    if(!hasFound){
                        tmp = serviceArray[i];
                        tmp._id=tmp.service_id;
                        tmp.ticked = false;
                        interpreter.services.push(tmp);
                    }
                }

                var languageArray = $scope.languageArray;
                var hasFound = false;
                var tmp = {};
                for(var i=0; i< languageArray.length; i++){
                    hasFound = false;
                    for(var j=0; j< interpreter.languages.length; j++){
                        if(languageArray[i].language_id == interpreter.languages[j].language_id){
                            hasFound = true;
                            break;
                        }
                    }
                    if(!hasFound){
                        tmp = languageArray[i];
                        tmp.language_id=tmp.language_id;
                        tmp.spoken = tmp.spoken;
                        tmp.written = tmp.written;
                        tmp.is_deleted = true;
                        interpreter.languages.push(tmp);
                    }
                }

                var address = $scope.interpreter.address1+' '+$scope.interpreter.city+' '+ $scope.interpreter.state+' '+$scope.interpreter.zip;
                // Initialize the Geocoder
                var geocoder = new google.maps.Geocoder();
                if (geocoder) {
                    geocoder.geocode({
                        'address': address
                    }, function (results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            $scope.interpreter.lat = results[0].geometry.location.lat();
                            $scope.interpreter.lng = results[0].geometry.location.lng();
                            var formData = new FormData();
                            formData.append('interpreter',angular.toJson(interpreter));
                            if(typeof $scope.interpreter.certificates.court_certified == 'object'){
                                formData.append('court_certified',$scope.interpreter.certificates.court_certified);
                            }
                            if(typeof $scope.interpreter.certificates.court_screened == 'object'){
                                formData.append('court_screened',$scope.interpreter.certificates.court_screened);    
                            }

                            InterpreterService.updateInterpreterBySuperAdmin().save(formData, function(response, err) {
                                var errorMessage = '';
                                $scope.disabled = false;
                                $scope.loader = false;
                                if (response.status == 1) {
                                    logger.logSuccess(response.message); 
                                    $state.go('admin_listInterpreters');
                                } else {
                                    logger.logError(response.message);
                                }
                            });
                        }else {
                            logger.logError('Please enter valid address this address does not find latitude and longitude of interpreter');
                            return false;
                        }
                    });
                }else{
                    logger.logError('Oops something is wrong! Please try agin.');
                }
            }
        };
        
        /**
        * Uib Modal is used to activate interpreter by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 9-Feb-2018
        **/
        $scope.activateInterpreterModal = function(interpreterData){
            if(interpreterData.userInfo.activation_key != '' || interpreterData.userInfo.activation_key != null || interpreterData.userInfo.activation_key != undefined){
                $uibModal.open({
                    templateUrl: 'modules/interpreter/views/activateInterpreterModal.html',
                    size: 'md',
                    controller: function($scope,$rootScope, $uibModalInstance){
                    
                        $scope.closeuib = function() {
                            $uibModalInstance.close();
                        }
                        
                        var interpreter = {};
                        interpreter._id = interpreterData._id;
                        interpreter.user_id =  interpreterData.userInfo._id;
                        interpreter.email =  interpreterData.userInfo.email;
                        $scope.interpreter = interpreter;

                        $scope.activateInterpreterSuperAdmin = function(form){
                            if(form.$valid){
                                $scope.loader = true;
                                $scope.disabled = true;
                                if($scope.interpreter.confirm_password == true){    
                                    InterpreterService.activateInterpreterSuperAdmin().save($scope.interpreter,function(response, err) {
                                        if (response.status == 1) {
                                            logger.logSuccess(response.message);
                                            $uibModalInstance.close();
                                            $state.reload();
                                        } else {
                                            logger.log(response.message);
                                        }
                                    });          
                                }else{
                                    $scope.disabled = false;
                                    logger.log("Confirm password does not match with password!");
                                }
                            }
                        }
                    }
                });
            }else{
                logger.logError("Oops something is wrong! Please try again.");
            }
        }

        $scope.changeTimeOnStatusChanged = function(status){
            if(status == 'full time'){
                var currentDate = new Date();
                $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),0,0,0);
                $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                
                setTimeout(function(){
                    angular.element(document.querySelector('#working_from_id')).trigger('change');
                    angular.element(document.querySelector('#working_to_id')).trigger('change');
                },1000); 
            }else{
                var currentDate = new Date();
                $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
                $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),15,0,0);
                $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                
                setTimeout(function(){
                    angular.element(document.querySelector('#working_from_id')).trigger('change');
                    angular.element(document.querySelector('#working_to_id')).trigger('change');
                },1000); 
            }
        }

    }
]);
