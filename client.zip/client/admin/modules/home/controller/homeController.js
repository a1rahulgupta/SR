"use strict";

angular.module("Home")

interpreterApp.controller("homeController", ['$scope', '$rootScope', '$localStorage', 'logger', 'homeService', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal',
    function($scope, $rootScope, $localStorage, logger, homeService, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal) {
        
        $scope.contact = {};
        $scope.mailinglist = {};
        $scope.loader = false;

        // Testimonial section starts here
        $scope.owlOptions = {
            navigation: true, 
            rewindNav : false,
            items : 3, //10 items above 1000px browser width
            pagination: false,            
            responsiveClass:true,
            responsive:{
                0:{
                    items:1,               
                },
                320:{
                    items:1,                
                },
                600:{
                    items:1,                
                },
                1000:{
                    items:2,               
                },
                1200:{
                    items:3,           
                }                  
            }
        };

        $scope.testimonial = [
            {name: 'Andrew Williams1', company: 'Company A from California', image: 'user.jpg', content: 'Uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).'}, 
            {name: 'Andrew Williams2', company: 'Company B from California', image: 'user.jpg', content: 'Uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).'}, 
            {name: 'Andrew Williams3', company: 'Company C from California', image: 'user.jpg', content: 'Uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).'}, 
            {name: 'Andrew Williams4', company: 'Company D from California', image: 'user.jpg', content: 'Uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).'}, 
        ];
        // Testimonial section ends here


        $scope.redirectLogin = function(user) {
            $state.go('login', { email: user.email });
        }


        /**
         * Function is use to add email for newslater
         * @access private
         * @return json
         * Created by Ashwini
         * @smartData Enterprises (I) Ltd
         * Created Date 24-Aug-2017
         */
        $scope.addMailingList = function(form) {

            if (form.$valid) {
                $scope.loader = true;
                $scope.disabled = true;               

                homeService.addMailingList().save($scope.mailinglist, function(response, err) {

                    $scope.disabled = false;
                    $scope.loader = false;
                    if (response.code == statusCode.ok) {
                        logger.logSuccess(response.message);
                        $scope.mailinglist = {};                         
                    } else {
                        logger.logError(response.message);
                        $scope.mailinglist = {}; 
                    }
                });
            }
        };

        
        // $scope.getMailCategory = function() {
        //     homeService.getMailCategory().get({}, function(response, err) {
        //         if (response.code == 200) {
        //             console.log('response:- ',response)
        //             $scope.mailCategory =  response.data;
        //         } else {
        //             $scope.mailCategory = {};
        //         }
        //     });
        // }
        

        /**
         * Function is use to open contactUs popup
         * @access private
         * @return json
         * Created by Ashwini
         * @smartData Enterprises (I) Ltd
         * Created Date 21-Aug-2017
         */
        $scope.contactUs = function(data) {

            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: '/users/modules/home/views/contactModal.html',
                controller: 'contactUsCtrl',
                size: 'md',
                resolve: {
                    modalData: function() {
                        return data
                    }
                },
                selectedDate: null
            });
        };

        
    }

]);
