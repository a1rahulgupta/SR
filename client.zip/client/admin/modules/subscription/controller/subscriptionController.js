"use strict";

angular.module("Subscription")

interpreterApp.controller("subscriptionController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger', 'SubscriptionService', 'ngTableParams', 'ngTableParamsService',
    function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal, logger, SubscriptionService, ngTableParams, ngTableParamsService) {
       
        if ($state.params.id) {
            $scope.isUpdate = true;
        } else {
            $scope.isUpdate = false;
        }; 
        
        /**
        * Variable is used to active class on leftbar
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $rootScope.menuSubscription = ['admin_listSubscription', 'admin_addSubscription', 'admin_viewSubscription', 'admin_editSubscription'];
        
        /**
        * Function and variable is used to check format of image upload
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.myImage='';
        $scope.myCroppedImage='';
        $scope.isImageSelected=false;
        $scope.isCropVisible=false;
        var handleFileSelect=function(evt) {
            $scope.isImageSelected=false;
            $scope.isCropVisible=true;
            var file=evt.currentTarget.files[0];
            var reader = new FileReader();
            reader.onload = function (evt) {
                $scope.$apply(function($scope){
                  $scope.myImage=evt.target.result;
              });
            };
            reader.readAsDataURL(file);
        };
        angular.element(document.querySelector('#fileInput')).on('change',handleFileSelect);
        $scope.openFileBrowse = function(fileInputSelector) {
            angular.element(document.querySelector(fileInputSelector)).trigger('click');
        };

        var formDataFileUpload = '';
        $scope.imageBase64 = '';
        angular.element(document).ready(function() {
            setTimeout(function() {
                if(document.getElementById('fileInput')!=null){
                    document.getElementById('fileInput').addEventListener('change', function(evt) {
                        var files = evt.target.files;
                        var file = files[0];
                        if (files && file) {
                            var splitFileName = file.name.split('.');
                            var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                            if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {
                                if (file.size > 6291456) {
                                    logger.log('File size cannot exceed limit of 6 mb');
                                    document.getElementById("fileInput").value = "";
                                } else {
                                    formDataFileUpload = file;
                                    // formDataFileUpload.append('file', file);
                                    var reader = new FileReader();
                                    reader.onload = function(readerEvt) {
                                        $scope.imageBase64 = btoa(readerEvt.target.result);
                                        $scope.$apply();
                                        document.querySelector('#imgTag').src = 'data:image/' + ext + ';base64,' + $scope.imageBase64;
                                    };
                                    reader.readAsBinaryString(file);
                                }
                            } else {
                                document.getElementById("fileInput").value = "";
                                bootbox.alert('Invalid image format');
                            }
                        }
                    });
                }
            }, 500);
        });

        /**
        * Variables is used to list the language
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.languageList = [
        {
            _id: 'Polish',
            name: 'Polish',
            ticked: false
        },
        {
            _id: 'English',
            name: 'English',
            ticked: false
        },
        {
            _id: 'Spanish',
            name: 'Spanish',
            ticked: false
        }
        ];
        $scope.localLang = {
            selectAll       : "Tick all",
            selectNone      : "Tick none",
            reset           : "Undo all",
            search          : "Type here to search...",
            nothingSelected : "Nothing is selected"         //default-label is deprecated and replaced with this.
        };

        /**
        * Function is used to subscription of superadmin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.listSubscription = function() {
            ngTableParamsService.set('', '', '', '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.subscriptionList = [];
                    SubscriptionService.getAllSubscription().save($scope.paramUrl, function(response, err) {
                        if (response.status == 1) {
                            $scope.subscriptionList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };

        $scope.getSubscriptionById = function(){
            if($stateParams.id){
                SubscriptionService.getSubscriptionById().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        $scope.subscription = response.data;

                    }else{
                        logger.logError(response.message);
                    }
                })
            }
        };

        /**
        * Function is used to get subscription of superadmin by searching
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.listSubscriptionSearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.subscriptionList = [];
                    SubscriptionService.getAllSubscription().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.subscriptionList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        /**
        * Function is used to add subscription of a superadmin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.addSubscription = function(subscription) {
            var subscription = $scope.subscription    
            SubscriptionService.addSubscription().save(subscription, function(response) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $location.path('listSubscription');
                } else {
                    logger.logError(response.message);
                }

            });
        };
        /**
        * Function is used to update subscription of a superadmin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.updateSubscription = function() {
            SubscriptionService.updateSubscription().save($scope.subscription, function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $location.path('listSubscription');
                } else {
                    logger.logError(response.message);
                }
            });
        };
        /**
        * Function is used to view subscription of a superadmin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.viewSubscription = function(subscription) {
            $state.go('admin_viewSubscription', {id:subscription._id});
        };

        /**
        * Function is used to delete subscription of a superadmin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.deleteSubscription = function(id,$event) {
            $event.stopPropagation();
            bootbox.confirm('Are you sure, you want to delete this subscription?', function(r) {
                if (r) {
                    SubscriptionService.deleteSubscription().delete({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listSubscription();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };
        /**
        * Function is used to change subscription status of a superadmin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.changeSubscriptionStatus = function(id,status) {
            var subscription = {
                id: id,
                status: status
            }
            SubscriptionService.changeSubscriptionStatus().save(subscription,function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $scope.listSubscription();
                } else {
                    logger.log(response.message);
                }
            });
        };

        
    }

    ]);
