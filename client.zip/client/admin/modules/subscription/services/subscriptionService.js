"use strict"

angular.module("Subscription")

.factory('SubscriptionService', ['$http', '$resource', function($http, $resource) {
   
    var getAllSubscription = function() {
        return $resource(webservices.getAllSubscription, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteSubscription = function(id) {
        return $resource(webservices.deleteSubscription, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }


    var addSubscription = function() {
        return $resource(webservices.addSubscription, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getSubscriptionById = function(id) {
        return $resource(webservices.getSubscriptionById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var updateSubscription = function() {
        return $resource(webservices.updateSubscription, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var changeSubscriptionStatus = function() {
        return $resource(webservices.changeSubscriptionStatus, null, {
            save: {
                method: 'POST'
            }
        });
    }


    return {
        getAllSubscription: getAllSubscription,
        deleteSubscription: deleteSubscription,
        addSubscription: addSubscription,
        getSubscriptionById: getSubscriptionById,
        updateSubscription: updateSubscription,
        changeSubscriptionStatus: changeSubscriptionStatus

    }

}]);
