"use strict"

angular.module("Setting")

.factory('SettingService', ['$http', '$resource', function($http, $resource) {

    var addStripeKeys = function() {
        return $resource(webservices.addStripeKeys, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getStripeKeys = function() {
        return $resource(webservices.getStripeKeys, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getStripeKeysById = function(id) {
        return $resource(webservices.getStripeKeysById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var updateStripeKeys = function() {
        return $resource(webservices.updateStripeKeys, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var addTwilioKeys = function() {
        return $resource(webservices.addTwilioKeys, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getTwilioKeys = function() {
        return $resource(webservices.getTwilioKeys, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getTwilioKeysById = function(id) {
        return $resource(webservices.getTwilioKeysById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var updateTwilioKeys = function() {
        return $resource(webservices.updateTwilioKeys, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var addOpentokKeys = function() {
        return $resource(webservices.addOpentokKeys, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getOpentokKeys = function() {
        return $resource(webservices.getOpentokKeys, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getOpentokKeysById = function(id) {
        return $resource(webservices.getOpentokKeysById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var updateOpentokKeys = function() {
        return $resource(webservices.updateOpentokKeys, null, {
            save: {
                method: 'POST'
            }
        });
    }

    return {
        addStripeKeys: addStripeKeys,
        getStripeKeys: getStripeKeys,
        getStripeKeysById: getStripeKeysById,
        updateStripeKeys: updateStripeKeys,
        addTwilioKeys: addTwilioKeys,
        getTwilioKeys: getTwilioKeys,
        getTwilioKeysById: getTwilioKeysById,
        updateTwilioKeys: updateTwilioKeys,
        addOpentokKeys: addOpentokKeys,
        getOpentokKeys: getOpentokKeys,
        getOpentokKeysById: getOpentokKeysById,
        updateOpentokKeys: updateOpentokKeys
    }

}]);
