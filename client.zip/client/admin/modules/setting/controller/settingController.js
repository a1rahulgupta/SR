"use strict";

angular.module("Setting")

interpreterApp.controller("settingController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger', 'SettingService', 'ngTableParams', 'ngTableParamsService',
    function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal, logger, SettingService, ngTableParams, ngTableParamsService) {

        /**
        * Variable is used to active class on leftbar
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $rootScope.menuSetting = ['admin_listSetting', 'admin_viewStripeSetting', 'admin_viewOpentokSetting', 'admin_viewTwillioSetting', 'admin_addStripeKeys', 'admin_editStripeKeys', 'admin_addOpentokKeys', 'admin_editOpentokKeys', 'admin_addTwilioKeys', 'admin_editTwilioKeys'];

        /**
        * Variable is used for update interpreter
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        if ($state.params.id) {
            $scope.isUpdate = true;
        } else {
            $scope.isUpdate = false;
        };
        
        $scope.addStripeKeys = function(stripekeys) {
            if($scope.form.$valid){
                SettingService.addStripeKeys().save(stripekeys, function(response) {
                    if (response.status == 1) {
                        logger.logSuccess(response.message); 
                        $location.path('viewStripeSetting');
                    } else {
                        logger.logError(response.message);
                    }

                });
            }
            
        };

        $scope.getStripeKeys = function(){
            SettingService.getStripeKeys().get(function(response, err){
                if(response.status == 1){
                    $scope.stripeKeys = response.data;
                }else{
                    $scope.stripeKeys = {};
                }
            })
        };

        $scope.getStripeKeysById = function(){
            if($stateParams.id){
                SettingService.getStripeKeysById().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        $scope.stripeKeys = response.data;

                    }else{
                        $scope.stripeKeys = {};
                        logger.logError(response.message);
                        $state.go("admin_viewStripeSetting");
                    }
                })
            }
        };

        $scope.updateStripeKeys = function(){
            if($scope.form.$valid){
               var stripeKeysData = $scope.stripeKeys;
                var id = $state.params.id;
                SettingService.updateStripeKeys().save({id: $state.params.id, publishable_key: stripeKeysData.publishable_key, secret_key: stripeKeysData.secret_key}, function(response) {
                    if (response.status == 1) {
                        logger.logSuccess(response.message);
                        $location.path('viewStripeSetting');
                    } else {
                        logger.logError(response.message);
                        $state.go("admin_viewStripeSetting");
                    }
                }); 
            }
            
        };

        $scope.addTwilioKeys = function(twiliokeys) {
            if($scope.form.$valid){
                SettingService.addTwilioKeys().save(twiliokeys, function(response) {
                    if (response.status == 1) {
                        logger.logSuccess(response.message); 
                        $location.path('viewTwilioSetting');
                    } else {
                        logger.logError(response.message);
                    }

                });
            }
            
        };

        $scope.getTwilioKeys = function(){
            SettingService.getTwilioKeys().get(function(response, err){
                if(response.status == 1){
                    $scope.twilioKeys = response.data;
                }else{
                    $scope.twilioKeys = {};
                }
            })
        };

        $scope.getTwilioKeysById = function(){
            if($stateParams.id){
                SettingService.getTwilioKeysById().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        $scope.twilioKeys = response.data;

                    }else{
                        $scope.twilioKeys = {};
                        logger.logError(response.message);
                        $state.go("admin_viewTwilioSetting");
                    }
                })
            }
        };

        $scope.updateTwilioKeys = function(){
            if($scope.form.$valid){
                var twilioKeysData = $scope.twilioKeys;
                var id = $state.params.id;
                SettingService.updateTwilioKeys().save({id: $state.params.id, accountSid: twilioKeysData.accountSid, authToken: twilioKeysData.authToken, toll_free_number: twilioKeysData.toll_free_number, application_sid: twilioKeysData.application_sid}, function(response) {
                    if (response.status == 1) {
                        logger.logSuccess(response.message);
                        $location.path('viewTwilioSetting');
                    } else {
                        logger.logError(response.message);
                        $state.go("admin_viewTwilioSetting");
                    }
                });
            }
            
        };

        $scope.addOpentokKeys = function(opentokkeys) {
            if($scope.form.$valid){
                SettingService.addOpentokKeys().save(opentokkeys, function(response) {
                    if (response.status == 1) {
                        logger.logSuccess(response.message); 
                        $location.path('viewOpentokSetting');
                    } else {
                        logger.logError(response.message);
                    }

                });
            }
            
        };

        $scope.getOpentokKeys = function(){
            SettingService.getOpentokKeys().get(function(response, err){
                if(response.status == 1){
                    $scope.opentokKeys = response.data;
                }else{
                    $scope.opentokKeys = {};
                }
            })
        };

        $scope.getOpentokKeysById = function(){
            if($stateParams.id){
                SettingService.getOpentokKeysById().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        $scope.opentokKeys = response.data;

                    }else{
                        $scope.opentokKeys = {};
                        logger.logError(response.message);
                        $state.go("admin_viewOpentokSetting");
                    }
                })
            }
        };

        $scope.updateOpentokKeys = function(){
            if($scope.form.$valid){
                var opentokKeysData = $scope.opentokKeys;
                var id = $state.params.id;
                SettingService.updateOpentokKeys().save({id: $state.params.id, apiKey: opentokKeysData.apiKey, apiSecret: opentokKeysData.apiSecret}, function(response) {
                    if (response.status == 1) {
                        logger.logSuccess(response.message);
                        $location.path('viewOpentokSetting');
                    } else {
                        logger.logError(response.message);
                        $state.go("admin_viewOpentokSetting");
                    }
                });
            }
            
        };
    }

]);
