"use strict"

angular.module("Cms")

.factory('CmsService', ['$http', '$resource', function($http, $resource) {
 
    var listClientsSuperAdmin = function() {
        return $resource(webservices.listClientsSuperAdmin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteClientSuperAdmin = function(id) {
        return $resource(webservices.deleteClientSuperAdmin, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }


    var addClientSuperAdmin = function() {
        return $resource(webservices.addClientSuperAdmin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getClientBySuperAdmin = function(id) {
        return $resource(webservices.getClientBySuperAdmin, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var updateClientSuperAdmin = function() {
        return $resource(webservices.updateClientSuperAdmin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var changeClientStatusSuperAdmin = function() {
        return $resource(webservices.changeClientStatusSuperAdmin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllLanguagesSuperAdmin = function() {
        return $resource(webservices.getAllLanguagesBySuperAdmin, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var listAgencySuperAdmin = function() {
        return $resource(webservices.listAgencySuperAdmin, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getClientViewSuperAdmin = function(id) {
        return $resource(webservices.getClientViewSuperAdmin, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    
    var listClientBookingSuperAdmin = function() {
        return $resource(webservices.listClientBookingSuperAdmin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllCountriesInSuperAdmin = function() {
        return $resource(webservices.getAllCountriesInSuperAdmin, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var activateClientSuperAdmin = function() {
        return $resource(webservices.activateClientSuperAdmin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    //Start*****************************

    var listCarouselSuperAdmin = function() {
        return $resource(webservices.listCarouselSuperAdmin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var addCarouselImage = function(formData) {
        return $resource(webservices.addCarouselImage, null, {
            save: {
                method: 'POST',
                transformRequest: angular.identity,
                headers: { 'Content-Type': undefined }
            }
        });
    }

    var getUploadedCarouselBySuperAdmin = function(id) {
        return $resource(webservices.getUploadedCarouselBySuperAdmin, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var updateCarouselDetailBySuperAdmin = function() {
        return $resource(webservices.updateCarouselDetailBySuperAdmin, null, {
            save: {
                method: 'POST',
                transformRequest: angular.identity,
                headers: { 'Content-Type': undefined }
            }
        });
    }

    var deleteCarouselBySuperAdmin = function(id) {
        return $resource(webservices.deleteCarouselBySuperAdmin, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var changeCarouselStatusBySuperAdmin = function() {
        return $resource(webservices.changeCarouselStatusBySuperAdmin, null, {
            save: {
                method: 'POST'
            }
        });
    }

    return {
        listClientsSuperAdmin: listClientsSuperAdmin,
        deleteClientSuperAdmin: deleteClientSuperAdmin,
        addClientSuperAdmin: addClientSuperAdmin,
        getClientBySuperAdmin: getClientBySuperAdmin,
        updateClientSuperAdmin: updateClientSuperAdmin,
        changeClientStatusSuperAdmin: changeClientStatusSuperAdmin,
        getAllLanguagesSuperAdmin: getAllLanguagesSuperAdmin,
        listAgencySuperAdmin: listAgencySuperAdmin,
        getClientViewSuperAdmin: getClientViewSuperAdmin,
        listClientBookingSuperAdmin: listClientBookingSuperAdmin,
        getAllCountriesInSuperAdmin: getAllCountriesInSuperAdmin,
        activateClientSuperAdmin: activateClientSuperAdmin,

        listCarouselSuperAdmin: listCarouselSuperAdmin,
        addCarouselImage: addCarouselImage,
        getUploadedCarouselBySuperAdmin: getUploadedCarouselBySuperAdmin,
        updateCarouselDetailBySuperAdmin: updateCarouselDetailBySuperAdmin,
        deleteCarouselBySuperAdmin: deleteCarouselBySuperAdmin,
        changeCarouselStatusBySuperAdmin: changeCarouselStatusBySuperAdmin
    }

}]);
