"use strict";

angular.module("Cms")

interpreterApp.controller("cmsController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger', 'ClientService','dashboardService', 'ngTableParams','CommonService', 'ngTableParamsService','CmsService',
    function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal, logger, ClientService,dashboardService, ngTableParams, CommonService, ngTableParamsService, CmsService) {
       
        /**
        * Variable is used for update client
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 19-Feb-2018
        **/
        if ($state.params.id) {
            $scope.isUpdate = true;
        } else {
            $scope.isUpdate = false;
        }; 
        
        /**
        * Variable is used to active class on leftbar
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 19-Feb-2018
        **/
        $rootScope.menuCms = ['admin_addCarousel', 'admin_listCarousels', 'admin_addSetting', 'admin_listSettings'];
        $rootScope.menuCarousels = ['admin_addCarousel', 'admin_listCarousels'];
        $rootScope.menuSettingConfigures = ['admin_addSetting', 'admin_listSettings'];

        /**
        * Function is used to get clients by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $rootScope.listClientsSuperAdmin = function() {
            ngTableParamsService.set('', '', '', '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    if($scope.selectAgency.agency_id != '' && $scope.selectAgency.agency_id != null && $scope.selectAgency.agency_id != undefined){
                        $scope.paramUrl.agency_id = $scope.selectAgency.agency_id;
                    }
                    $scope.clientList = [];
                    ClientService.listClientsSuperAdmin().save($scope.paramUrl, function(response, err) {
                        if (response.status == 1) {
                            $scope.clientList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };

        /**
        * Function is used to get clients searching by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.listClientsSearchingSuperAdmin = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    if($scope.selectAgency.agency_id != '' && $scope.selectAgency.agency_id != null && $scope.selectAgency.agency_id != undefined){
                        $scope.paramUrl.agency_id = $scope.selectAgency.agency_id;
                    }
                    $scope.clientList = [];
                    ClientService.listClientsSuperAdmin().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.clientList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        /**
        * Function is used to add client by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.addClientSuperAdmin = function() {
            if($scope.isImageSelected==true){
                $scope.client.imageFile = $scope.myCroppedImage;
            }
            ClientService.addClientSuperAdmin().save($scope.client, function(response) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $state.go('admin_listClients');
                } else {
                    logger.logError(response.message);
                }

            });
        };

        /**
        * Function is used to get client view by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 1-Feb-2018
        **/
        $scope.getClientViewSuperAdmin = function(){
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            if($stateParams.id){
                ClientService.getClientViewSuperAdmin().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var client = response.data;
                        if(client.profile_pic!='' && client.profile_pic!=undefined){
                            $scope.userDefaultImage=client.profile_pic;
                        }
                        $scope.client = client;
                    }else{
                        $scope.client = {};
                    }
                })
            }
        };

        /**
        * Function is used to update the client by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 5-Feb-2018
        **/
        $scope.updateClientSuperAdmin = function() {
            if($scope.isImageSelected==true){
                $scope.client.imageFile = $scope.myCroppedImage;
            }
            var client = $scope.client;
            var languageArray = $scope.languageArray;
            var hasFound = false;
            var tmp = {};
            for(var i=0; i< languageArray.length; i++){
                hasFound = false;
                for(var j=0; j< client.languages.length; j++){
                    if(languageArray[i].language_id == client.languages[j]._id){
                        hasFound = true;
                        break;
                    }
                }
                if(!hasFound){
                    tmp = languageArray[i];
                    tmp._id=tmp.language_id;
                    tmp.ticked = false;
                    client.languages.push(tmp);
                }
            }
            ClientService.updateClientSuperAdmin().save(client, function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $state.go('admin_listClients');
                } else {
                    logger.logError(response.message);
                }
            });
        };
        
        /**
        * Function is used to delete the client by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 5-Feb-2018
        **/
        $scope.deleteClientSuperAdmin = function(id,$event) {
            $event.stopPropagation();
            bootbox.confirm('Are you sure, you want to delete this account?', function(r) {
                if (r) {
                    ClientService.deleteClientSuperAdmin().delete({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listClientsSuperAdmin();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        /**
        * Function is used to change the status of the client by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 5-Feb-2018
        **/
        $scope.changeClientStatusSuperAdmin = function(id,status) {
            var client = {
                id: id,
                status: status
            }
            ClientService.changeClientStatusSuperAdmin().save(client,function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $scope.listClientsSuperAdmin();
                } else {
                    logger.log(response.message);
                }
            });
        };

        /**
        * Function is used to list client booking in view Client by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 1-Feb-2018
        **/
        $scope.listClientBookingSuperAdmin = function() {
            ngTableParamsService.set('', '', '', '');
            if($state.params.id){
                $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    getData: function($defer, params) {
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.paramUrl.client_id = $state.params.id;
                        $scope.bookingList = [];
                        ClientService.listClientBookingSuperAdmin().save($scope.paramUrl, function(response, err) {
                            if (response.status == 1) {
                                $scope.bookingList = response.data;
                                var data = response.data;
                                $scope.totalCount = response.count;
                                params.total(response.count);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                }); 
            }
        };

        /**
        * Function is used to search list interpreters of an agency
        * @access private
        * @return json
        * Created by ramiz
        * @smartData Enterprises (I) Ltd
        * Created Date 05-Jan-2018
        **/
        $scope.listBookingOfClientInAgencyBySearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.paramUrl.client_id = $state.params.id;
                    $scope.bookingList = [];
                    ClientService.listBookingOfClientInAgency().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        /**
        * Function is used to get agency by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.listAgencySuperAdmin = function(){
            ClientService.listAgencySuperAdmin().get({},function(response, err){
                if(response.status == 1){
                    $scope.agencyList = response.data;
                }else{
                    $scope.agencyList = {};
                }
            })
        }

        /**
        * Function is used to get countries by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.getAllCountriesInSuperAdmin = function(){
            ClientService.getAllCountriesInSuperAdmin().get({},function(response, err){
                if(response.status == 1){
                    $scope.superAdminCountries = response.data;
                    $scope.superAdmin = {};
                    for(var i=0; i<$scope.superAdminCountries.length; i++){
                        if($scope.superAdminCountries[i].country_code == 'us'){
                            $scope.superAdmin.country_id = $scope.superAdminCountries[i]._id 
                        }
                    }
                }else{
                    $scope.superAdminCountries = {};
                }
            })
        }

        /**
        * Function is used to get all languages in multiselect
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.getAllLanguagesSuperAdmin = function(){
            ClientService.getAllLanguagesSuperAdmin().get({},function(response, err){
                if(response.status == 1){
                    $scope.languageList = response.data;
                    console.log("$scope.languageList",$scope.languageList);
                }else{
                    $scope.languageList = {};
                }
            })
        }

        /**
        * Function is used to get client by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.getClientBySuperAdmin = function(){
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            if($stateParams.id){
                ClientService.getClientBySuperAdmin().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var client = response.data;
                        console.log("client",client);
                        client.email = client.email;

                        //Multilple language status changed
                        $scope.languageArray = angular.copy(client.languages); 
                        //End

                        setTimeout(function() {
                            for(var i=0;i<$scope.languageList.length;i++){
                                for (var j=0;j<client.languages.length;j++) {
                                    if($scope.languageList[i].name == client.languages[j].name
                                        && client.languages[j].ticked==true){
                                        $scope.languageList[i].ticked=true;
                                        break;
                                    }
                                }
                            }
                            if(client.profile_pic!='' && client.profile_pic!=undefined){
                                $scope.userDefaultImage=client.profile_pic;
                            }
                            $scope.client = client;
                        }, 500);
                    }else{
                        $scope.client = {};
                    }
                })
            }
        };

        /**
        * Uib Modal is used to activate client by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Feb-2018
        **/
        $scope.activateClientModal = function(clientData){
            if(clientData.userInfo.activation_key != '' || clientData.userInfo.activation_key != null || clientData.userInfo.activation_key != undefined){
                $uibModal.open({
                    templateUrl: 'modules/client/views/activateClientModal.html',
                    size: 'md',
                    controller: function($scope,$rootScope, $uibModalInstance){
                    
                        $scope.closeuib = function() {
                            $uibModalInstance.close();
                        }
                        
                        var client = {};
                        client._id = clientData._id;
                        client.user_id =  clientData.userInfo._id;
                        client.email =  clientData.userInfo.email;
                        $scope.client = client;

                        $scope.activateClientSuperAdmin = function(form){
                            if(form.$valid){
                                $scope.loader = true;
                                $scope.disabled = true;
                                if($scope.client.confirm_password == true){    
                                    ClientService.activateClientSuperAdmin().save($scope.client,function(response, err) {
                                        if (response.status == 1) {
                                            logger.logSuccess(response.message);
                                            $uibModalInstance.close();
                                            $state.reload();
                                        } else {
                                            logger.log(response.message);
                                        }
                                    });          
                                }else{
                                    $scope.disabled = false;
                                    logger.log("Confirm password does not match with password!");
                                }
                            }
                        }
                    }
                });
            }else{
                logger.logError("Oops something is wrong! Please try again.");
            }
        }

        //start
        
        /**
        * Function is used to get carousel list by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 20-Feb-2018
        **/
        $scope.listCarouselSuperAdmin = function() {
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.carouselList = [];
                    CmsService.listCarouselSuperAdmin().save($scope.paramUrl, function(response, err) {
                        if (response.status == 1) {
                            $scope.carouselList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                            $scope.carouselList = [];
                        }
                    });
                }
            });
        };

        /**
        * Function is used to get carousel searching by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 23-Feb-2018
        **/
        $scope.listCarouselSearchingSuperAdmin = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            console.log("searchTextField",searchTextField);
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.carouselList = [];
                    CmsService.listCarouselSuperAdmin().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.carouselList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                            $scope.carouselList = [];
                        }
                    });
                }
            })
        };

        /**
        * Function and variable is used for carousel image upload 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 20-Feb-2018
        **/
        var formDataImageUpload = '';
        $scope.imageBase64 = '';
        $scope.carouselImageUpload = function(){
            if(document.getElementById('fileCarouselInput')!=null){
                document.getElementById('fileCarouselInput').addEventListener('change', function(evt) {
                    var files = evt.target.files;
                    var file  =  files[0];
                    if (files && file) {
                        var splitFileName = file.name.split('.');
                        var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                        if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {
                            if (file.size > 6291456) {
                                bootbox.alert('File size cannot exceed limit of 6 mb');
                                document.getElementById("fileCarouselInput").value = "";
                                $scope.imageBase64 = '';
                                $scope.$digest();
                            } else {
                                formDataImageUpload = file;
                                var reader = new FileReader();
                                reader.onload = function(readerEvt) {
                                    var img = new Image;
                                    img.onload = function() {
                                        if(img.width == 1600 && img.height == 800){
                                            var fr = new FileReader();
                                            fr.onload = function(readerEvt) {
                                                $scope.imageBase64 = btoa(readerEvt.target.result);
                                                $scope.$apply();
                                                document.getElementById('imgTag').src = 'data:image/' + ext + ';base64,' + $scope.imageBase64;
                                            };
                                            fr.readAsBinaryString(file);
                                        }else{
                                            bootbox.alert('Invalid image format, Dimension should be 1600 x 800');
                                        }
                                    };
                                    img.src = reader.result;
                                };
                                reader.readAsDataURL(file);
                            }
                        } else {
                            bootbox.alert('Invalid image format, please upload a image with .png or .jpeg or .jpg extension');
                            document.getElementById("fileCarouselInput").value = "";
                            $scope.imageBase64 = '';
                            $scope.$digest();
                        }
                    }
                });
            }
        };

        /**
        * Function is used to add carousel image 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 20-Feb-2018
        **/
        $scope.addCarouselImage = function(form) {
            if (form.$valid) {
                $scope.loader = true;
                $scope.disabled = true;

                var formData = new FormData();
                formData.append('carouselObj',angular.toJson($scope.carouselObj));
                if (formDataImageUpload) {
                    formData.append('imageFile', formDataImageUpload);
                    CmsService.addCarouselImage().save(formData, function(response) {
                        var errorMessage = '';
                        $scope.disabled = false;
                        $scope.loader = false;
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $state.go('admin_listCarousels');
                        } else {
                            logger.logError(response.message);
                        }

                    });
                }else{
                    logger.logError("Please select an image to upload");    
                }
            }else{
                logger.logError("Please enter the required fields");
            }
        };

        /**
        * Function is used to get carousel details by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 22-Feb-2018
        **/
        $scope.getUploadedCarouselBySuperAdmin = function(){
            if($stateParams.id){
                CmsService.getUploadedCarouselBySuperAdmin().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        $scope.carouselObj = response.data;
                    }else{
                        $scope.carouselObj = {};
                    }
                })
            }
        };

        /**
        * Function is used to update the Carousel details
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 22-Feb-2018
        **/
        $scope.updateCarouselDetailBySuperAdmin = function(form) {
            if (form.$valid) {
                $scope.loader = true;
                $scope.disabled = true;
                var formData = new FormData();
                var carouselObj = angular.toJson($scope.carouselObj);
                formData.append('carouselObj', carouselObj);
                if (formDataImageUpload) {
                    formData.append('imageFile', formDataImageUpload);   
                }
                CmsService.updateCarouselDetailBySuperAdmin().save(formData, function(response) {
                    var errorMessage = '';
                    $scope.disabled = false;
                    $scope.loader = false;
                    if (response.status == 1) {
                        logger.logSuccess(response.message); 
                        $state.go('admin_listCarousels');
                    } else {
                        logger.logError(response.message);
                    }

                });
            }else{
                logger.logError("Please enter the required fields");
            }
        };

        /**
        * Function is to delete the carousel detail by super admin
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 22-Feb-2017
        **/
        $scope.deleteCarouselBySuperAdmin = function(id) {
            bootbox.confirm('Are you sure, you want to delete this banner?', function(r) {
                if (r) {
                    CmsService.deleteCarouselBySuperAdmin().delete({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listCarouselSuperAdmin();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        /**
        * Function is used to change the status of the carousel status
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 22-Feb-2017
        **/
        $scope.changeCarouselStatusBySuperAdmin = function(id,status) {
            var carouse = {
                id: id,
                status: status
            }
            CmsService.changeCarouselStatusBySuperAdmin().save(carouse,function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $scope.listCarouselSuperAdmin();
                } else {
                    logger.logError(response.message);
                }
            });
        };

                
    }
]);
