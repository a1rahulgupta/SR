"use strict"

angular.module("Dashboard")

.factory('dashboardService', ['$http', '$resource', function($http, $resource) {

    var getUserList = function() {
        return $resource(webservices.getUserList, null, {
            save: {
                method: 'POST'
            }
        });
    }
    var getCustomerById = function() {
        return $resource(webservices.getCustomerById, null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }
    var changeCustomerStatus = function() {
        return $resource(webservices.changeCustomerStatus, null, {
            save: {
                method: 'POST'
            }
        });
    }
    var updateCustomer = function() {
        return $resource(webservices.updateCustomer, null, {
            save: {
                method: 'POST',
            }
        });
    }

    var deleteCustomer = function() {
        return $resource(webservices.deleteCustomerById, null, {
            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var getSuperAdminProfileById = function() {
        return $resource(webservices.getSuperAdminProfileById, null, {
            get: {
                method: 'GET'
            }
        });
    }

    var updateSuperAdminProfile = function() {
        return $resource(webservices.updateSuperAdminProfile, null, {
            save: {
                method: 'POST',
            }
        });
    }

    var superAdminChangePassword = function() {
        return $resource(webservices.superAdminChangePassword, null, {
            save: {
                method: 'POST',
            }
        });
    }

    var getAllCountriesInSuperAdmin = function() {
        return $resource(webservices.getAllCountriesInSuperAdmin, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getCountOfSuperAdmin = function() {
        return $resource(webservices.getCountOfSuperAdmin, null, {
            get: {
                method: 'GET'
            }
        });
    }

    return {
        getUserList: getUserList,
        getCustomerById: getCustomerById,
        updateCustomer: updateCustomer,
        changeCustomerStatus: changeCustomerStatus,
        deleteCustomer: deleteCustomer,
        getSuperAdminProfileById: getSuperAdminProfileById,
        updateSuperAdminProfile: updateSuperAdminProfile,
        superAdminChangePassword: superAdminChangePassword,
        getAllCountriesInSuperAdmin: getAllCountriesInSuperAdmin,
        getCountOfSuperAdmin: getCountOfSuperAdmin
    }

}]);
