"use strict";

angular.module("Header")

interpreterApp.controller("headerController", ['$scope', '$rootScope', '$localStorage','$state',
    '$location', 'logger', '$uibModal', 'CommonService', 'dashboardService',
    function($scope, $rootScope, $localStorage, $state, $location, logger, $uibModal,CommonService, dashboardService) {

        $scope.getSuperAdminProfileById = function(){
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            dashboardService.getSuperAdminProfileById().get(function(response, err){
                if(response.status == 1){
                    var superAdmin = response.data;
                    superAdmin.email = superAdmin.user_id.email;
                    if(superAdmin.profile_pic!='' && superAdmin.profile_pic!=undefined){
                        $scope.userDefaultImage=superAdmin.profile_pic;
                    }
                    $scope.superAdmin = superAdmin;
                }else{
                    $scope.superAdmin = {};
                }
            })
        };

        $scope.superAdminChangePasswordModal = function() {
            $uibModal.open({
                templateUrl: 'modules/dashboard/views/superAdminChangePasswordModal.html',
                size: "md",
                controller: function($scope,$rootScope, $uibModalInstance,ngTableParams,ngTableParamsService) {

                    $scope.closeuib = function() {
                        $uibModalInstance.close();
                    };

                    // $scope.superAdminChangePassword = function(form){
                    //     if (form.$valid) {
                    //         $scope.loader = true;
                    //         $scope.disabled = true;
                    //         if($scope.changePassword.newPassword == $scope.changePassword.confirmPassword){
                                 
                    //             dashboardService.superAdminChangePassword().save(changePassword, function(response) {
                    //                 var errorMessage = '';
                    //                 $scope.disabled = false;
                    //                 $scope.loader = false;   
                    //                 if(response.status == 1){
                    //                     logger.logSuccess(response.message);
                    //                     $scope.closeuib();
                    //                     $state.go('admin_dashboard');
                    //                 }else{
                    //                     logger.log(response.message);
                    //                 }
                    //             })
                    //         }else{
                    //             logger.log("Confirm password does not match with new password!");
                    //         }
                    //     }
                    // };

                    $scope.superAdminChangePassword = function(form){
                        if (form.$valid) {
                            var passwordObj = {
                                oldPassword: $scope.oldPassword,
                                newPassword: $scope.newPassword
                            }
                            $scope.loader = true;
                            $scope.disabled = true;
                            if($scope.newPassword == $scope.confirmPassword){    
                                dashboardService.superAdminChangePassword().save(passwordObj, function(response) {
                                    $scope.disabled = false;
                                    $scope.loader = false;   
                                    if(response.status == 1){
                                        logger.logSuccess(response.message);
                                        $scope.closeuib();
                                        $state.go('client_dashboard');
                                    }else{
                                        logger.log(response.message);
                                    }
                                })
                            }else{
                                $scope.disabled = false;
                                logger.log("Confirm password does not match with new password!");
                            }
                        }
                    };

                }
            });
        };
        
    }
]);
