  "use strict";

  angular.module("LeftBar")

  interpreterApp.controller("leftBarController", ['$scope', '$rootScope', '$localStorage',
      'ngTableParams', '$routeParams', '$route', '$location', '$filter', 'logger',
      'ngTableParamsService', '$state', '$stateParams', '$uibModal', 'dashboardService',
      function($scope, $rootScope, $localStorage, ngTableParams, $routeParams,
          $route, $location, $filter, logger, ngTableParamsService, $state, $stateParams,
          $uibModal, dashboardService) {
          $scope.imageBase64 = '';
          $scope.add = false;
          $scope.preview = false;
          $scope.customer = {};
          $scope.disabled = false;
          $scope.loader = false;
          //$scope.loggedInUserData = $rootScope.loggedInUserData;
          $scope.loggedInUserData = $localStorage.user;


          $scope.getSuperAdminProfileById = function(){
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            dashboardService.getSuperAdminProfileById().get(function(response, err){
                if(response.status == 1){
                    var superAdmin = response.data;
                    superAdmin.email = superAdmin.user_id.email;
                    if(superAdmin.profile_pic!='' && superAdmin.profile_pic!=undefined){
                        $scope.userDefaultImage=superAdmin.profile_pic;
                    }
                    $scope.superAdmin = superAdmin;
                }else{
                    $scope.superAdmin = {};
                }
            })  
          };
          
          $scope.expandCollapseLeftSideBar = function(){
            if (window.innerWidth > 767) {
                
            }
            else{
               $("body").addClass("sidebar-collapse");
               $("body").removeClass("sidebar-open");
            }
          }


      }

  ]);


