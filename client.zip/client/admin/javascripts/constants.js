var baseUrl = location.protocol + '//' + location.hostname + (location.port ? ':' + location.port : '');
const stripe_published_key = "pk_test_jTfeZ7U3RCzKqZJk6NmYAGMV";

var webservices = {

    //Authenticate
    "adminLogin": baseUrl + "/api/v1/admin/login",
    "userForgotPassword": baseUrl + "/api/v1/user/forgotPassword",
    "setNewPassword": baseUrl + "/api/v1/user/setNewPassword",
    "getEmailUsingPassword": baseUrl + "/api/v1/user/getEmailUsingPassword/:id",

    //agency
    "listAgencyBySuperAdmin": baseUrl + "/api/v1/agency/listAgencyBySuperAdmin",
    "deleteAgencyBySuperAdmin": baseUrl + "/api/v1/agency/deleteAgencyBySuperAdmin/:id",
    "addAgencyBySuperAdmin": baseUrl + "/api/v1/agency/addAgencyBySuperAdmin",
    "getAgencyByIdBySuperAdmin": baseUrl + "/api/v1/agency/getAgencyByIdBySuperAdmin/:id",
    "updateAgencyBySuperAdmin": baseUrl + "/api/v1/agency/updateAgencyBySuperAdmin",
    "changeAgencyStatusBySuperAdmin": baseUrl + "/api/v1/agency/changeAgencyStatusBySuperAdmin",
    //Dashboard
    "getDashboardCount": baseUrl + "/api/getDashboardCount",
    "getDashboardLatestOrder": baseUrl + "/api/getDashboardLatestOrder",
    "getDashboardLatestUser": baseUrl + "/api/getDashboardLatestUser",


    //leftNavigation
    "getPermissionById": baseUrl + "/api/getPermissionById/:id",

    //user
    // "userList": baseUrl + "/api/users/list",
    // "findOneUser": baseUrl + "/api/users/userOne",
    // "bulkUpdateUser": baseUrl + "/api/users/bulkUpdate",
    // "update": baseUrl + "/api/users/update",
    "getUserList": baseUrl + "/api/users/getUserList",
    "getDesignation": baseUrl + "/api/users/getDesignation",
    "addUser": baseUrl + "/api/users/addUser",
    "inviteUser": baseUrl + "/api/users/inviteUser",
    "getInviteUserList": baseUrl + "/api/users/getInviteUserList",
    "getUserByUserOrgId": baseUrl + "/api/users/getUserByUserOrgId/:id",
    "getPerByUserOrgId": baseUrl + "/api/users/getPerByUserOrgId",
    "updateUser": baseUrl + "/api/users/updateUser",
    // "getUserFromOrg": baseUrl + "/api/users/getUserFromOrg",
    "deleteUserByUserOrgId": baseUrl + "/api/users/deleteUserByUserOrgId/:id",
    "cancelInviteById": baseUrl + "/api/users/cancelInviteById/:id",
    "updateUserPermission": baseUrl + "/api/users/updateUserPermission",
    "getUserListLeftTab": baseUrl + "/api/users/getUserListLeftTab",
    "getUserListSearchLeftTab": baseUrl + "/api/users/getUserListSearchLeftTab",
    "setOrganization":baseUrl + "/api/users/setOrganization",
    "updateOrgData":baseUrl + "/api/users/updateOrgData",
    "setUserAccess": baseUrl + "/api/users/setUserAccess",

    //task

    //twitter + facebook + instagram
    "connectTwitterProfile": baseUrl + "/api/connectTwitterProfile/:acc_type",
    "removeSocialProfile" : baseUrl + "/api/removeSocialProfile/:id/:network",
    "connectFacebookProfile" : baseUrl + "/api/connectFacebookProfile/:acc_type",
    "connectInstagramProfile" : baseUrl + "/api/connectInstagramProfile/:acc_type",

    //Channels
    "getUserChannelsList": baseUrl + "/api/getUserChannelsList/:id",
    "switchSocialAccType" : baseUrl + "/api/switchSocialAccType/",

    //start Interpreter
    "getBookingList": baseUrl + "/api/v1/bookings/listBookings",
    "getAgencyBookingList": baseUrl + "/api/v1/bookings/getAgencyBookingList",
    "getAgencyInterpreters": baseUrl + "/api/v1/interpreters/listAgencyInterpreters",
    "getAgencyClients": baseUrl + "/api/v1/clients/listAgencyClients",
    "addBooking": baseUrl + "/api/v1/bookings/addBooking",
    "getBookingById": baseUrl + "/api/v1/bookings/getBooking/:id",
    "deleteBooking": baseUrl + "/api/v1/bookings/deleteBooking/:id",
    "updateBooking": baseUrl + "/api/v1/bookings/updateBooking",
    "listAgencyInterpreters": baseUrl + "/api/v1/interpreters/listInterpreters",
    "deleteInterpreter": baseUrl + "/api/v1/interpreters/deleteInterpreter/:id",
    "addInterpreter": baseUrl + "/api/v1/interpreters/addInterpreter",
    "getInterpreterById": baseUrl + "/api/v1/interpreters/getInterpreter/:id",
    "updateInterpreter": baseUrl + "/api/v1/interpreters/updateInterpreter",
    "changeInterpreterStatus": baseUrl + "/api/v1/interpreters/changeInterpreterStatus",
    "listAgencyClients": baseUrl + "/api/v1/clients/listClients",
    "addClientSuperAdmin": baseUrl + "/api/v1/clients/addClientSuperAdmin",
    "deleteClientSuperAdmin": baseUrl + "/api/v1/clients/deleteClientSuperAdmin/:id",
    "getClientBySuperAdmin": baseUrl + "/api/v1/clients/getClientBySuperAdmin/:id",
    "updateClientSuperAdmin": baseUrl + "/api/v1/clients/updateClientSuperAdmin",
    "changeClientStatusSuperAdmin": baseUrl + "/api/v1/clients/changeClientStatusSuperAdmin",

    "getEmailUsingKey": baseUrl + "/api/v1/user/getEmailUsingKey/:id",
    "completeUserRegistration": baseUrl + "/api/v1/user/completeUserRegistration",

    "listBookingByInterpreterId": baseUrl + "/api/v1/bookings/listBookingByInterpreterId",
    "getInterpreterBookingById": baseUrl + "/api/v1/bookings/getInterpreterBookingById/:id",
    "getBookingInterpreterById": baseUrl + "/api/v1/bookings/getBookingInterpreterById/:id",

    "listBookingByClientId": baseUrl + "/api/v1/bookings/listBookingByClientId",
    "addBookingByClient": baseUrl + "/api/v1/bookings/addBookingByClient",
    "getClientBookingById": baseUrl + "/api/v1/bookings/getClientBookingById/:id",
    "getClientBookingViewById": baseUrl + "/api/v1/bookings/getClientBookingViewById/:id",
    "updateBookingByClient": baseUrl + "/api/v1/bookings/updateBookingByClient",
    "cancelBookingByClient": baseUrl + "/api/v1/bookings/cancelBookingByClient",
    "closeBookingByClient": baseUrl + "/api/v1/bookings/closeBookingByClient",
    // "getBookingListByClientId": baseUrl + "/api/v1/bookings/getBookingListByClientId",
    "getBookingByClientId": baseUrl + "/api/v1/bookings/getBookingByClientId/:id",
    "bulkUploadInterpreter": baseUrl + "/api/v1/interpreters/bulkUploadInterpreter",
    "webCallToInterpreter": baseUrl + "/api/v1/web_call/webCallToInterpreter",

    //admin
    "adminLogin": baseUrl + "/api/v1/admin/login",

    //subscription
    "getAllSubscription": baseUrl + "/api/v1/subscription",
    "getSubscriptionById": baseUrl + "/api/v1/subscription/:id",
    "addSubscription": baseUrl + "/api/v1/subscription/add",
    "updateSubscription": baseUrl + "/api/v1/subscription/updatesubscription/:id",
    "deleteSubscription": baseUrl + "/api/v1/subscription/deletesubscription/:id",
    "changeSubscriptionStatus": baseUrl + "/api/v1/subscription/changeSubscriptionStatus",
    "getSuperAdminProfileById": baseUrl + "/api/v1/admin/getSuperAdminProfileById",
    "updateSuperAdminProfile": baseUrl + "/api/v1/admin/updateSuperAdminProfile",
    "superAdminChangePassword": baseUrl + "/api/v1/user/changePassword",
    "getAllCountriesInSuperAdmin": baseUrl + "/api/v1/admin/getAllCountries",

    //Accounts
    "listClientsSuperAdmin": baseUrl + "/api/v1/clients/listClientsSuperAdmin",
    "listAgencySuperAdmin": baseUrl + "/api/v1/agency/listAgencySuperAdmin",
    "getClientViewSuperAdmin": baseUrl + "/api/v1/clients/getClientViewSuperAdmin/:id",
    "listClientBookingSuperAdmin": baseUrl + "/api/v1/bookings/listClientBookingSuperAdmin",
    "getAllLanguagesBySuperAdmin": baseUrl+ "/api/v1/admin/getAllLanguagesForMultiselect",
    "activateClientSuperAdmin": baseUrl + "/api/v1/clients/activateClientSuperAdmin",

    //Interpreters
    "listInterpretersSuperAdmin": baseUrl + "/api/v1/interpreters/listInterpretersSuperAdmin",
    "deleteInterpreterSuperAdmin": baseUrl + "/api/v1/interpreters/deleteInterpreterSuperAdmin/:id",
    "changeInterpreterStatusSuperAdmin": baseUrl + "/api/v1/interpreters/changeInterpreterStatusSuperAdmin",
    "getInterpreterViewBySuperAdmin": baseUrl + "/api/v1/interpreters/getInterpreterViewBySuperAdmin/:id",
    "getAllServicesBySuperAdmin": baseUrl + "/api/v1/admin/getAllServicesForMultiselect",
    "listBookingInterpreterSuperAdmin": baseUrl + "/api/v1/bookings/listBookingInterpreterSuperAdmin",
    "getInterpreterSchedulingDetailsSuperAdmin": baseUrl + "/api/v1/interpreters/getInterpreterSchedulingDetailsSuperAdmin",
    "getBookingDetailCalendarSuperAdmin": baseUrl + "/api/v1/bookings/getBookingDetailCalendarSuperAdmin",
    "getInterpreterBySuperAdmin": baseUrl + "/api/v1/interpreters/getInterpreterBySuperAdmin/:id",
    "getAllLanguagesSuperAdmin": baseUrl + "/api/v1/admin/getAllLanguages",
    "addInterpreterBySuperAdmin": baseUrl + "/api/v1/interpreters/addInterpreterBySuperAdmin",
    "updateInterpreterBySuperAdmin": baseUrl + "/api/v1/interpreters/updateInterpreterBySuperAdmin",
    "activateInterpreterSuperAdmin": baseUrl + "/api/v1/interpreters/activateInterpreterSuperAdmin",
    "getCountOfSuperAdmin": baseUrl + "/api/v1/admin/getCountOfSuperAdmin",

    //cms
    "listCarouselSuperAdmin": baseUrl + "/api/v1/cms/listCarouselSuperAdmin",
    "addCarouselImage": baseUrl + "/api/v1/cms/addCarouselImage", 
    "getUploadedCarouselBySuperAdmin": baseUrl + "/api/v1/cms/getUploadedCarouselBySuperAdmin/:id",
    "updateCarouselDetailBySuperAdmin": baseUrl + "/api/v1/cms/updateCarouselDetailBySuperAdmin",
    "deleteCarouselBySuperAdmin": baseUrl + "/api/v1/cms/deleteCarouselBySuperAdmin/:id",
    "changeCarouselStatusBySuperAdmin": baseUrl + "/api/v1/cms/changeCarouselStatusBySuperAdmin",
    "getAllSubscriptionsBySuperAdmin": baseUrl + "/api/v1/subscription/getAllSubscriptionsBySuperAdmin",
    "agencySubscriptionActivateSuperAdmin": baseUrl + "/api/v1/agency/agencySubscriptionActivateSuperAdmin",

    //settings
    "addStripeKeys": baseUrl+ "/api/v1/admin/addStripeKeys",
    "getStripeKeys": baseUrl+ "/api/v1/admin/getStripeKeys",
    "updateStripeKeys": baseUrl+ "/api/v1/admin/updateStripeKeys",
    "addTwilioKeys": baseUrl+ "/api/v1/admin/addTwilioKeys",
    "getTwilioKeys": baseUrl+ "/api/v1/admin/getTwilioKeys",
    "updateTwilioKeys": baseUrl+ "/api/v1/admin/updateTwilioKeys",
    "addOpentokKeys": baseUrl+ "/api/v1/admin/addOpentokKeys",
    "getOpentokKeys": baseUrl+ "/api/v1/admin/getOpentokKeys",
    "updateOpentokKeys": baseUrl+ "/api/v1/admin/updateOpentokKeys",
    "getOpentokKeysById": baseUrl+ "/api/v1/admin/getOpentokKeysById/:id",
    "getTwilioKeysById": baseUrl + "/api/v1/admin/getTwilioKeysById/:id",
    "getStripeKeysById": baseUrl + "/api/v1/admin/getStripeKeysById/:id", 
    
    
}

var statusCode = {
    "ok": 200,
    "error": 401,
    "permission": 403,
    "warning": 404,
    "failed": 1002,
    "unauth": 1003,
    "internalError": 1004
}

var googleConstants = {
    "google_client_id": "54372597586-09u72notkj8g82vl3jt77h7cbutvr7ep.apps.googleusercontent.com",
}

var appConstants = {
    "authorizationKey": "dGF4aTphcHBsaWNhdGlvbg=="
}


var headerConstants = {
    "json": "application/json"
}

var regex = {
    "NAME": /^[a-zA-Z . \-\']*$/,
    "CITY": /^[a-zA-Z . \-\']*$/,
    "MATERIAL": /^([a-zA-Z0123456789-]+\s)*[a-zA-Z0123456789-]+$/,
    "EMAIL": /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
    "POSTAL_CODE": /(^\d{5}$)|(^\d{5}-\d{4}$)/,
    "PHONE_NO": /\(?\d{3}\)?-? *\d{3}-? *-?\d{4}/,
    "PASSWORD": /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{6,}/,
    "DESCRIPTION": /^[ A-Za-z0-9_@./#&+-;]*$/,
    "TASK_CODE": /^[0-9999]{1,4}$/,
    "SUB_DOMAIN": /^[/a-z/A-Z][a-zA-Z0-9-]*[^/-/./0-9]$/,
    "PHONE_NO_MASK": ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/],
    "RADIUS": /^[1-9][0-9]*(?:.)([0-9])+$/,
    "LATLONG": /^\s*(\-?\d+(\.\d+)?)$/,

    "name": /^([a-zA-ZàèìòùÀÈÌÒÙáéíóúýÁÉÍÓÚÝâêîôûÂÊÎÔÛãñõÃÑÕäëïöüÿÄËÏÖÜŸçÇßØøÅåÆæœ@¿?!¡:/',.-]+\s)*[a-zA-ZàèìòùÀÈÌÒÙáéíóúýÁÉÍÓÚÝâêîôûÂÊÎÔÛãñõÃÑÕäëïöüÿÄËÏÖÜŸçÇßØøÅåÆæœ',.-]+$/,
    "address": /^([a-zA-Z0123456789àèìòùÀÈÌÒÙáéíóúýÁÉÍÓÚÝâêîôûÂÊÎÔÛãñõÃÑÕäëïöüÿÄËÏÖÜŸçÇßØøÅåÆæœ@¿?!¡:/',.-]+\s)*[a-zA-Z0123456789àèìòùÀÈÌÒÙáéíóúýÁÉÍÓÚÝâêîôûÂÊÎÔÛãñõÃÑÕäëïöüÿÄËÏÖÜŸçÇßØøÅåÆæœ@',.-]+$/
}

var messagesConstants = {

    //users
    "saveUser": "User saved successfully",
    "updateUser": "User updated successfully",
    "updateStatus": "Status updated successfully",
    "deleteUser": "User(s) deleted successfully",
    "unAuthorize": "User email or password are not correct"

}
