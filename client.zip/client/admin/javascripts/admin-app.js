"use strict";

angular.module("Authentication", []);
angular.module("Home", []);
angular.module("Dashboard", []);
angular.module("Header", []);
angular.module("LeftBar", []);
angular.module("Subscription", []);
angular.module("Agency", []);
angular.module("Client", []);
angular.module("Interpreter", []);
angular.module("Cms", []);
angular.module("Setting", []);


var interpreterApp = angular.module('interpreterApp', ['ui.router','ngAnimate', 'ui.bootstrap',
    'ngRoute', 'ngStorage', 'ngTable', 'ngResource', 'oc.lazyLoad','Authentication', 'Home', 'Dashboard', 
    'Header','LeftBar', 'Subscription', 'ui.calendar','ngImgCrop','isteven-multi-select','kendo.directives',
    'ui.calendar','ngImgCrop','isteven-multi-select','kendo.directives', 'ngIntlTelInput','Agency','Client', 
    'Interpreter', 'Cms', 'blockUI', 'Setting'
])

.factory("CommonService", ["$http", "$resource", "$rootScope", function($http, $resource, $rootScope) {
    
        var user = {};
        var getUser = function() {
            return user;
        };
        var setUser = function(userData) {
            user = '';
            user = userData;
            return user;
        };

        var convertTo24Format = function(timeStr){
            var tmp=timeStr;
            var tmpArr = tmp.split(':');
            var t = tmpArr[1].split(' ')[1];
            var hour= tmpArr[0].trim();
            var minute= tmpArr[1].split(' ')[0];
            if(t=='PM'){
                if(hour!=12){
                    hour = parseInt(hour) + 12;
                }
            } else if(t=='AM'){
                if(hour==12){
                    hour=0;
                }
            }
            return { 'hour': hour, 'minute': minute};
        };

        return {
            getUser: getUser,
            setUser: setUser,
            convertTo24Format: convertTo24Format
        }

    }])
    .config(["blockUIConfig", function (blockUIConfig) {
        blockUIConfig.requestFilter = function (config) {
            //Perform a global, case-insensitive search on the request url for 'noblockui' ...
            if (config.url.match(/checklogin/gi) || config.url.match(/getPermissionById/gi)) {
                // console.log("Yes"); 
                return false; // ... don't block it.
                // return true; // ... block it.
            }
        };
    }])
    .config(['$routeProvider', '$httpProvider', '$locationProvider', '$stateProvider', '$urlRouterProvider', '$injector', function(
        $routeProvider, $httpProvider, $locationProvider, $stateProvider, $urlRouterProvider) {
        $httpProvider.interceptors.push(function($q, $location, $window, $rootScope, $localStorage, $injector) {
            var numLoadings = 0;
            return {
                request: function(config) {
                    config.headers = config.headers || {};
                    config.headers['authorization'] = 'Bearer ' + $localStorage.token;
                    // config.headers['client-type'] = 'browser'; // this is used to detect the request is from the browser
                    return config;
                },
                response: function(response) {
                    if (response.status == 0) {
                        delete $localStorage.token;
                        delete $localStorage.user;
                        delete $localStorage.userLoggedIn;
                        $location.path('/login'); // handle the case where the user is not authenticated
                    }else if (response.status == 3) {
                        $location.path('/login'); // handle the case where the user is not authenticated
                        bootbox.alert(response.data.message);
                    }       
                    return response || $q.when(response);           
                },
                responseError: function(response) {                    
                    return $q.reject(response);
                }
            };
        });
        var checkLoggedin = function($q, $timeout, $http, $location, $rootScope, $state, $localStorage, CommonService) {
            var deferred = $q.defer(); // Initialize a new promise
            // Make an AJAX call to check if the user is logged in
            $http.get('/api/v1/user/checklogin').success(function(response) { // Authenticated

                var user = response.user;
                if (response.status == '1') {
                    $rootScope.userLoggedIn = true;
                    var user = response.user;
                    CommonService.setUser(user); // this will set the user in the session to the application model
                    switch(user.role){
                        case "super_admin":
                        case "admin_staff":
                            $rootScope.CurrPath = 'admin_dashboard';
                            $state.go('admin_dashboard');
                        break;
                    }    
                } else { // Not Authenticated
                    $rootScope.userLoggedIn = false;
                    $timeout(function() {
                        deferred.resolve();
                    }, 0);
                }
            }).error(function(error) {
                $rootScope.userLoggedIn = false;
                $timeout(function() {
                    deferred.resolve();
                }, 0);
            });
            return deferred.promise;
        };
        var checkLoggedout = function() {
            return ['$q', '$timeout', '$http', '$location', '$rootScope', '$state', 'CommonService','$localStorage',
                function($q, $timeout, $http, $location, $rootScope, $state, CommonService, $localStorage) {

                    var deferred = $q.defer(); // Initialize a new promise 
                    // Make an AJAX call to check if the user is logged in
                    var user_role  = $localStorage.user;
                    // console.log("checlllll",user);
                    $http.get('/api/v1/user/checklogin').success(function(response) {
                        if (response.status == '1') { // Authenticated
                            // console.log("Here it comes");
                            $rootScope.userLoggedIn = true;
                            var user = response.user;  
                            CommonService.setUser(user); 
                            switch(user.role){
                                case "super_admin":
                                case "admin_staff":
                                    var stateName = $rootScope.CurrPath;
                                    if(/^admin/.test(stateName)){
                                        $timeout(deferred.resolve, 0);
                                    }else{
                                        $state.go('admin_dashboard');
                                        $rootScope.CurrPath = 'admin_dashboard';
                                    }
                                break;
                                
                            }
                        } else { // Not Authenticated
                            
                            $rootScope.userLoggedIn = false;
                            $timeout(function() {
                                deferred.resolve();
                            }, 0);
                            $state.go('login');
                        }
                    }).error(function(error) {
                        $rootScope.userLoggedIn = false;
                        $timeout(function() {
                            deferred.resolve();
                        }, 0);
                        $state.go('login');
                    });
                    return deferred.promise;
                }
            ];
        };


        $urlRouterProvider.otherwise('/login');
        $stateProvider
            .state('login', {
                url: '/login',
                views: {
                    'beforeContent': {
                        templateUrl: 'modules/authentication/views/login.html',
                        controller: "loginController"
                    }
                },
                params: { 'email': null },
                data: {
                    isAuthenticate: false
                },
                resolve: {
                    loggedin: checkLoggedin,
                }
            })

            .state('forgot-password', {
                url: '/forgotPassword',
                views: {
                    'beforeContent': {
                        templateUrl: 'modules/authentication/views/forgot-password.html',
                        controller: "loginController"
                    }
                },
                params: { 'email': null },
                data: {
                    isAuthenticate: false
                },
                resolve: {
                    loggedin: checkLoggedin,
                }
            })

            .state('forgot_Password', {
                url: '/forgot_password/:forgot_token',
                views: {
                    'beforeContent': {
                        templateUrl: 'modules/authentication/views/forgot-password-page.html',
                        controller: "loginController"
                    }
                },
                params: { 'email': null },
                data: {
                    isAuthenticate: false
                },
                resolve: {
                    loggedin: checkLoggedin,
                }
            })

            .state('contact', {
                url: '/contact',
                views: {
                    'beforeHeader': {
                        templateUrl: 'agency/modules/home/views/header.html'
                    },
                    'beforeContent': {
                        templateUrl: 'agency/modules/home/views/contact.html',
                        controller: "homeController"
                    },
                    'beforeFooter': {
                        templateUrl: 'agency/modules/home/views/footer.html',
                        controller: "homeController"
                    }
                },
                data: { },
                resolve: { }
            })
            .state('about', {
                url: '/about',
                views: {
                    'beforeHeader': {
                        templateUrl: 'agency/modules/home/views/header.html'
                    },
                    'beforeContent': {
                        templateUrl: 'agency/modules/home/views/about.html',
                        controller: "homeController"
                    },
                    'beforeFooter': {
                        templateUrl: 'agency/modules/home/views/footer.html',
                        controller: "homeController"
                    }
                },
                data: { },
                resolve: { }
            })
            
            .state('signup', {
                url: '/signup',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/org-signup.html',
                        controller: "loginController"
                    }
                },
                data: {
                    // isAuthenticate: false
                },
                resolve: {
                    // loggedin: checkLoggedin,
                    // loadPlugin: function($ocLazyLoad) {
                    //     return $ocLazyLoad.load([
                    //         '/users/modules/authentication/controller/authenticateController.js',
                    //         '/users/modules/authentication/services/authenticateService.js',
                    //         '/assets/js/stripe-v3.js'
                    //     ]);
                    // }
                }
            })
            .state('complete-registration', {
                url: '/complete-registration/:token',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/complete-registration.html',
                        controller: "loginController"
                    }
                },
                data: {
                    // isAuthenticate: false
                },
                resolve: {
                    // loggedin: checkLoggedin,
                    // loadPlugin: function($ocLazyLoad) {
                    //     return $ocLazyLoad.load([
                    //         '/users/modules/authentication/controller/authenticateController.js',
                    //         '/users/modules/authentication/services/authenticateService.js',
                    //         '/assets/js/stripe-v3.js'
                    //     ]);
                    // }
                }
            })
            .state('cancel-invitation', {
                url: '/cancel-invitation',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/cancel-invitation.html',
                        controller: "loginController"
                    }
                },
                data: {
                    // isAuthenticate: false
                },
                resolve: {
                    // loggedin: checkLoggedin,
                    // loadPlugin: function($ocLazyLoad) {
                    //     return $ocLazyLoad.load([
                    //         '/users/modules/authentication/controller/authenticateController.js',
                    //         '/users/modules/authentication/services/authenticateService.js',
                    //         '/assets/js/stripe-v3.js'
                    //     ]);
                    // }
                }
            })
            .state('verify-email', {
                url: '/verify-email',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/verify-email.html',
                        controller: "loginController"
                    }
                },
                data: {},
                resolve: {}
            })
            .state('forgot_password', {
                url: '/forgot-password',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/forgot-password.html',
                        controller: "loginController"
                    }
                },
                data: {},
                resolve: {
                    // loggedin: checkLoggedin,
                    // loadPlugin: function($ocLazyLoad) {
                    //     return $ocLazyLoad.load([
                    //         '/users/modules/authentication/controller/authenticateController.js',
                    //         '/users/modules/authentication/services/authenticateService.js',
                    //     ]);
                    // }
                }
            })
            .state('reset_password', {
                url: '/reset-password/:reset_key',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/reset-password.html',
                        controller: "loginController"
                    }
                },
                data: {},
                resolve: {
                    // loggedin: checkLoggedin,
                    // loadPlugin: function($ocLazyLoad) {
                    //     return $ocLazyLoad.load([
                    //         '/users/modules/authentication/controller/authenticateController.js',
                    //         '/users/modules/authentication/services/authenticateService.js',
                    //     ]);
                    // }
                }
            })
            .state('verifying_link', {
                url: '/verifying-link',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/verifing-link.html',
                        controller: "loginController"
                    }
                },
                data: {},
                resolve: {
                    // loadPlugin: function($ocLazyLoad) {
                    //     return $ocLazyLoad.load([
                    //         '/users/modules/authentication/controller/authenticateController.js',
                    //         '/users/modules/authentication/services/authenticateService.js',
                    //     ]);
                    // }
                }
            })
            
            .state('404', {
                url: '/page-not-found',
                views: {
                    'content': {
                        templateUrl: 'agency/modules/home/views/404.html',
                    },
                },
            })
            
            .state('admin_dashboard', {
                url: '/dashboard',
                views: {
                    'header': {
                        templateUrl: "modules/dashboard/views/header.html",
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'modules/dashboard/views/home.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: 'modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('admin_profile', {
                url: '/adminProfile',
                views: {
                    'header': {
                        templateUrl: "modules/dashboard/views/header.html",
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'modules/dashboard/views/adminProfile.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: 'modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('admin_listAgency', {
                url: '/listAgency',
                views: {
                    'header': {
                        templateUrl: "modules/dashboard/views/header.html",
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'modules/agency/views/listAgency.html',
                        controller: "agencyController"
                    },
                    'footer': {
                        templateUrl: 'modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('admin_addAgency', {
                url: '/addAgency',
                views: {
                    'header': {
                        templateUrl: "modules/dashboard/views/header.html",
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'modules/agency/views/addAgency.html',
                        controller: "agencyController"
                    },
                    'footer': {
                        templateUrl: 'modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('admin_editAgency', {
                url: '/editAgency/:id',
                views: {
                    'header': {
                        templateUrl: "modules/dashboard/views/header.html",
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'modules/agency/views/addAgency.html',
                        controller: "agencyController"
                    },
                    'footer': {
                        templateUrl: 'modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('admin_viewAgency', {
                url: '/viewAgency/:id',
                views: {
                    'header': {
                        templateUrl: "modules/dashboard/views/header.html",
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'modules/agency/views/viewAgency.html',
                        controller: "agencyController"
                    },
                    'footer': {
                        templateUrl: 'modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('admin_editClient', {
                url: '/editClient/:id',
                views: {
                    'header': {
                        templateUrl: "modules/dashboard/views/header.html",
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'modules/client/views/addClient.html',
                        controller: "clientController"
                    },
                    'footer': {
                        templateUrl: 'modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('admin_activateClient', {
                url: '/activateClient/:id',
                views: {
                    'header': {
                        templateUrl: "modules/dashboard/views/header.html",
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'modules/client/views/activateClient.html',
                        controller: "clientController"
                    },
                    'footer': {
                        templateUrl: 'modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('admin_listCarousels', {
                url: '/listCarousels',
                views: {
                    'header': {
                        templateUrl: "modules/dashboard/views/header.html",
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'modules/cms/views/listCarousels.html',
                        controller: "cmsController"
                    },
                    'footer': {
                        templateUrl: 'modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('admin_addCarousel', {
                url: '/addCarousel',
                views: {
                    'header': {
                        templateUrl: "modules/dashboard/views/header.html",
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'modules/cms/views/addCarousel.html',
                        controller: "cmsController"
                    },
                    'footer': {
                        templateUrl: 'modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('admin_listSettings', {
                url: '/listSettings',
                views: {
                    'header': {
                        templateUrl: "modules/dashboard/views/header.html",
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'modules/cms/views/listSettings.html',
                        controller: "cmsController"
                    },
                    'footer': {
                        templateUrl: 'modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('admin_addSetting', {
                url: '/addSetting',
                views: {
                    'header': {
                        templateUrl: "modules/dashboard/views/header.html",
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'modules/cms/views/addSetting.html',
                        controller: "cmsController"
                    },
                    'footer': {
                        templateUrl: 'modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('admin_editCarousel', {
                url: '/editCarousel/:id',
                views: {
                    'header': {
                        templateUrl: "modules/dashboard/views/header.html",
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'modules/cms/views/addCarousel.html',
                        controller: "cmsController"
                    },
                    'footer': {
                        templateUrl: 'modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('admin_subscriptionPlan', {
                url: '/subscriptionPlan',
                views: {
                    'header': {
                        templateUrl: "modules/dashboard/views/header.html",
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'modules/agency/views/subscriptionPlan.html',
                        controller: "agencyController"
                    },
                    'footer': {
                        templateUrl: 'modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

        /**************************Interpreter*******************************/
        .state('admin_listInterpreters', {
            url: '/listInterpreters',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/interpreter/views/listInterpreter.html',
                    controller: "interpreterController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_viewInterpreter', {
            url: '/viewInterpreter/:id',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/interpreter/views/viewInterpreter.html',
                    controller: "interpreterController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_addInterpreter', {
            url: '/addInterpreter',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/interpreter/views/addInterpreter.html',
                    controller: "interpreterController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_editInterpreter', {
            url: '/editInterpreter/:id',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/interpreter/views/addInterpreter.html',
                    controller: "interpreterController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })
        /**************************** Client **********************************/
        .state('client_dashboard', {
            url: '/client/dashboard',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/dashboard/views/clientDashboard.html',
                    controller: "clientDashboardController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_listBooking', {
            url: '/client/listBooking',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/booking/views/listBooking.html',
                    controller: "clientBookingController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        }) 

        .state('client_addBooking', {
            url: '/client/addBooking',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/booking/views/addBooking.html',
                    controller: "clientBookingController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        }) 

        .state('client_viewBooking', {
            url: '/client/viewBooking/:id',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/booking/views/viewBooking.html',
                    controller: "clientBookingController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        }) 

        .state('client_editBooking', {
            url: '/client/editBooking/:id',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/booking/views/addBooking.html',
                    controller: "clientBookingController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_listCalendarBooking', {
            url: '/client/listCalendarBooking',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/booking/views/listCalendarBooking.html',
                    controller: "clientBookingController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_addSubscription', {
            url: '/addSubscription',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/subscription/views/addSubscription.html',
                    controller: "subscriptionController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_listSubscription', {
            url: '/listSubscription',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/subscription/views/listSubscription.html',
                    controller: "subscriptionController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_viewSubscription', {
            url: '/viewSubscription/:id',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/subscription/views/viewSubscription.html',
                    controller: "subscriptionController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_editSubscription', {
            url: '/editSubscription/:id',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/subscription/views/addSubscription.html',
                    controller: "subscriptionController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_listClients', {
            url: '/listClients',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/client/views/listClient.html',
                    controller: "clientController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_addClient', {
            url: '/addClient',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/client/views/addClient.html',
                    controller: "clientController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_viewClient', {
            url: '/viewClient/:id',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/client/views/viewClient.html',
                    controller: "clientController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        /*****************Setting module**************************/
        .state('admin_listSetting', {
            url: '/listSetting',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/setting/views/listSetting.html',
                    controller: "settingController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_viewStripeSetting', {
            url: '/viewStripeSetting',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/setting/views/viewStripeSetting.html',
                    controller: "settingController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_viewOpentokSetting', {
            url: '/viewOpentokSetting',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/setting/views/viewOpentokSetting.html',
                    controller: "settingController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_viewTwilioSetting', {
            url: '/viewTwilioSetting',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/setting/views/viewTwillioSetting.html',
                    controller: "settingController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_addStripeKeys', {
            url: '/addStripeKeys',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/setting/views/addStripeKeys.html',
                    controller: "settingController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_editStripeKeys', {
            url: '/editStripeKeys/:id',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/setting/views/addStripeKeys.html',
                    controller: "settingController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_addOpentokKeys', {
            url: '/addOpentokKeys',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/setting/views/addOpentokKeys.html',
                    controller: "settingController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_editOpentokKeys', {
            url: '/editOpentokKeys/:id',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/setting/views/addOpentokKeys.html',
                    controller: "settingController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_addTwilioKeys', {
            url: '/addTwilioKeys',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/setting/views/addTwilioKeys.html',
                    controller: "settingController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('admin_editTwilioKeys', {
            url: '/editTwilioKeys/:id',
            views: {
                'header': {
                    templateUrl: "modules/dashboard/views/header.html",
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'modules/setting/views/addTwilioKeys.html',
                    controller: "settingController"
                },
                'footer': {
                    templateUrl: 'modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        //to remove the # from the URL
        // $locationProvider.html5Mode({enabled : true, requireBase : false});
    }])

.run(['$rootScope', '$location', '$http', '$localStorage', '$state',
        function($rootScope, $location, $http, $localStorage, $state) {
            $rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState) {
                $rootScope.CurrPath = toState.name;
                // if (fromState.name != 'worker') {
                //     ngTableParamsService.set('', '', '', '', '');
                // }
                // if (toState.data) {
                //     if (!$localStorage.token && toState.data.isAuthenticate) {
                //         event.preventDefault();
                //         $state.go('home');
                //     }
                // }
            });
            $rootScope.capitalize = function (string) {
                if (string) {
                    return string.charAt(0).toUpperCase() + string.slice(1);
                } else {
                    return;
                }
            } 

        }
    ])

    .filter('capitalize', function() {
        return function(input) {
            return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
        }
    })
    .filter('capitalizeFirstLetterEachWord', function() {
        return function(input){
            if(input.indexOf(' ') !== -1){
              var inputPieces,
                  i;

              input = input.toLowerCase();
              inputPieces = input.split(' ');

              for(i = 0; i < inputPieces.length; i++){
                inputPieces[i] = capitalizeString(inputPieces[i]);
              }

              return inputPieces.toString().replace(/,/g, ' ');
            }
            else {
              input = input.toLowerCase();
              return capitalizeString(input);
            }

            function capitalizeString(inputString){
              return inputString.substring(0,1).toUpperCase() + inputString.substring(1);
            }
        };
    })

    
   