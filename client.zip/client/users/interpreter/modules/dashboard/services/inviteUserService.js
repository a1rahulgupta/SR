"use strict"

angular.module("InviteUser")

.factory('InviteUserService', ['$http', '$resource', function($http, $resource) {

    var inviteUser = function(userPerId) {
        var permissionObj = { p : userPerId, m: 'users', a : 'add' }
        return $resource(webservices.inviteUser, null, {
            save: {
                method: 'POST',
                headers: {authentication: JSON.stringify(permissionObj) }
            }
        });
    }
    var cancelInviteById = function(userPerId) {
        var permissionObj = { p : userPerId, m: 'users', a : 'cancel' }
        return $resource(webservices.cancelInviteById, null, {
            delete: {
                method: 'DELETE',
                id: '@id',
                headers: {authentication: JSON.stringify(permissionObj) }
            }
        });
    }
    var getDesignation = function() {
        return $resource(webservices.getDesignation, null, {
            get: {
                method: 'GET'
            }
        });
    }
    var getInviteUserList = function() {
        return $resource(webservices.getInviteUserList, null, {
            save: {
                method: 'POST'
            }
        });
    }
    
    return {
        inviteUser: inviteUser,
        getDesignation: getDesignation,
        getInviteUserList: getInviteUserList,
        cancelInviteById: cancelInviteById

    }

}]);
