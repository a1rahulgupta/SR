"use strict"

angular.module("InterpreterDashboard")

.factory('interpreterDashboardService', ['$http', '$resource', function($http, $resource) {

    var getUserList = function() {
        return $resource(webservices.getUserList, null, {
            save: {
                method: 'POST'
            }
        });
    }
    var getCustomerById = function() {
        return $resource(webservices.getCustomerById, null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }
    var changeCustomerStatus = function() {
        return $resource(webservices.changeCustomerStatus, null, {
            save: {
                method: 'POST'
            }
        });
    }
    var updateCustomer = function() {
        return $resource(webservices.updateCustomer, null, {
            save: {
                method: 'POST',
            }
        });
    }

    var deleteCustomer = function() {
        return $resource(webservices.deleteCustomerById, null, {
            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var getInterpreterProfileDetailById = function() {
        return $resource(webservices.getInterpreterProfileDetailById, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getInterpreterRatingById = function() {
        return $resource(webservices.getInterpreterRatingById, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var interpreterChangePassword = function() {
        return $resource(webservices.interpreterChangePassword, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllCountriesInInterpreter = function() {
        return $resource(webservices.getAllCountriesInInterpreter, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var updateInterpreterProfile = function() {
        return $resource(webservices.updateInterpreterProfile, null, {
            save: {
                method: 'POST',
                transformRequest: angular.identity,
                headers: { 'Content-Type': undefined }
            }
        });
    }

    var getCountOfInterpreter = function() {
        return $resource(webservices.getCountOfInterpreter, null, {
            get: {
                method: 'GET'
            }
        });
    }

    return {
        getUserList: getUserList,
        getCustomerById: getCustomerById,
        updateCustomer: updateCustomer,
        changeCustomerStatus: changeCustomerStatus,
        deleteCustomer: deleteCustomer,
        getInterpreterProfileDetailById: getInterpreterProfileDetailById,
        getInterpreterRatingById: getInterpreterRatingById,
        interpreterChangePassword: interpreterChangePassword,
        getAllCountriesInInterpreter: getAllCountriesInInterpreter,
        updateInterpreterProfile: updateInterpreterProfile,
        getCountOfInterpreter: getCountOfInterpreter
    }

}]);
