"use strict";

angular.module("InterpreterHeader")

interpreterApp.controller("interpreterHeaderController", ['$scope', '$rootScope', '$localStorage','$state',
    '$location', 'logger', '$uibModal', 'CommonService', 'interpreterDashboardService',
    function($scope, $rootScope, $localStorage, $state, $location, logger, $uibModal,
        CommonService, interpreterDashboardService) {

        $scope.getInterpreterProfileDetailById = function(){  
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            $scope.agencyDefaultImage = "./../../../../assets/images/logo_single.png";
            interpreterDashboardService.getInterpreterProfileDetailById().get(function(response, err){
                if(response.status == 1){
                    var interpreter = response.data;
                    interpreter.email = interpreter.user_id.email;
                    if(interpreter.profile_pic!='' && interpreter.profile_pic!=undefined){
                        $scope.userDefaultImage=interpreter.profile_pic;
                    }
                    if(interpreter.agency_id.profile_pic!='' && interpreter.agency_id.profile_pic!=undefined){
                        $scope.agencyDefaultImage = interpreter.agency_id.profile_pic;   
                    }  
                    $scope.interpreter = interpreter;
                }else{
                    $scope.interpreter = {};
                }
            })
        };

        $scope.interpreterChangePasswordModal = function() {
            $uibModal.open({
                templateUrl: 'interpreter/modules/dashboard/views/interpreterChangePasswordModal.html',
                size: "md",
                controller: function($scope,$rootScope, $uibModalInstance,ngTableParams,ngTableParamsService) {

                    $scope.closeuib = function() {
                        $uibModalInstance.close();
                    };

                    $scope.interpreterChangePassword = function(form){
                        if (form.$valid) {
                            var passwordObj = {
                                oldPassword: $scope.oldPassword,
                                newPassword: $scope.newPassword
                            }
                            $scope.disabled = true;
                            $scope.loader = true;
                            if($scope.newPassword == $scope.confirmPassword){    
                                interpreterDashboardService.interpreterChangePassword().save(passwordObj, function(response) {
                                    $scope.disabled = false;
                                    $scope.loader = false;
                                    if(response.status == 1){
                                        logger.logSuccess(response.message);
                                        $scope.closeuib();
                                        $state.go('interpreter_dashboard');
                                    }else{
                                        logger.log(response.message);
                                    }
                                })
                            }else{
                                $scope.disabled = false;
                                logger.log("Confirm password does not match with new password!");
                            }
                        }
                    };

                }
            });
        };
    }
]);
