"use strict";

angular.module("InviteUser")

interpreterApp.controller("inviteUserCtrl", ['$scope', '$rootScope', '$localStorage',
    '$location', 'logger', '$uibModal', 'CommonService', 'InviteUserService', 
    'UserService', '$uibModalInstance','ngTableParamsService','ngTableParams',
    function($scope, $rootScope, $localStorage, $location, logger, $uibModal,
        CommonService, InviteUserService, UserService, $uibModalInstance, 
        ngTableParamsService, ngTableParams) {

        $scope.user = {};
        $scope.loggedInUserData = $localStorage.user;
        $scope.closeuib = function() {
            $uibModalInstance.close('a');
        }

        /**
         * Function is use to get Designation for User
         * @access private
         * @return json
         * Created by Ashwini
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.getDesignation = function() {
            InviteUserService.getDesignation().get({}, function(response, err) {
                if (response.code == 200) {
                    $scope.designation = response.data
                } else {
                    $scope.designation = {};
                }
            });
        }

        /**
         * Function is use to get Invite User List
         * @access private
         * @return json
         * Created by Ashwini
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.getInviteUserList = function() {
            var organizationId = $localStorage.user.defaultOrg.organization._id;
            InviteUserService.getInviteUserList().save({ organizationId: organizationId }, function(response, err) {
                if (response.code == 200) {
                    $scope.inviteUserList = response.data
                } else {
                    $scope.inviteUserList = {};
                }
            });
        }

        /**
         * Function is use to send Invitation User for add in Org
         * @access private
         * @return json
         * Created by Ashwini
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         * Modified Date 19-Aug-2017
         */
        $scope.inviteUser = function(form) {
            if (form.$valid) {
                $scope.loader = true;
                $scope.disabled = true;

                var inviteData = $scope.user;
                inviteData.senderId = $localStorage.user._id;
                inviteData.organizationId = $localStorage.user.defaultOrg.organization._id;

                InviteUserService.inviteUser($localStorage.user.permission._id).save(inviteData, function(response, err) {

                    var errorMessage = '';
                    $scope.disabled = false;
                    $scope.loader = false;
                    if (response.code == statusCode.ok) {
                        $scope.getUserListLeftTab();
                        $scope.getUserList();
                        logger.logSuccess(response.message);
                        $scope.closeuib();
                    } else if (response.code == statusCode.permission) {
                        $scope.closeuib();
                    } else {
                        logger.logError(response.message);
                        $scope.closeuib();
                    }
                });


            }
        }

        $scope.getUserList = function() {
            console.log('innnn funnn')

            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.paramUrl.organizationId = $localStorage.user.defaultOrg.organization._id;
                    $scope.tableLoader = true;
                    $scope.userList = [];

                    UserService.getUserList().save($scope.paramUrl, function(response) {
                        $scope.tableLoader = false;
                        $scope.userList = response.data;
                        params.total(response.totalCount);
                        $defer.resolve(response.data);
                    });

                }
            });
        }

        /**
         * Function is use to cancel Invitation ById in Org
         * @access private
         * @return json
         * Created by Ashwini
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.cancelInviteById = function(id) {
            bootbox.confirm('Are you sure you want to cancel invitation', function(r) {
                if (r) {
                    InviteUserService.cancelInviteById($localStorage.user.permission._id).delete({ id: id }, function(response) {
                        if (response.code == statusCode.ok) {
                            logger.logSuccess(response.message);
                            $scope.getInviteUserList();
                        } else if (response.code == statusCode.permission) {
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        }



    }
]);
