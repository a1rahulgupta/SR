  "use strict";

  angular.module("InterpreterLeftBar")

  interpreterApp.controller("interpreterLeftBarController", ['$scope', '$rootScope', '$localStorage',
      'ngTableParams', '$routeParams', '$route', '$location', '$filter', 'logger',
      'ngTableParamsService', '$state', '$stateParams', '$uibModal', 'interpreterDashboardService','CommonService',
      function($scope, $rootScope, $localStorage, ngTableParams, $routeParams,
          $route, $location, $filter, logger, ngTableParamsService, $state, $stateParams,
          $uibModal, interpreterDashboardService,CommonService) {
          $scope.imageBase64 = '';
          $scope.add = false;
          $scope.preview = false;
          $scope.customer = {};
          $scope.disabled = false;
          $scope.loader = false;
          //$scope.loggedInUserData = $rootScope.loggedInUserData;
          $scope.loggedInUserData = $localStorage.user;



          $scope.serviceList = [
            {
                _id: 'Face-to-Face Translation',
                name: 'Face-to-Face Translation',
                ticked: false
            },
            {
                _id: 'Speech Translation',
                name: 'Speech Translation',
                ticked: false
            },
            {
                _id: 'Audio Translation',
                name: 'Audio Translation',
                ticked: false
            }
        ];

          $scope.getInterpreterProfileDetailById = function(){
            /* Variables is used to initialize the working hours on document ready */
              var currentDate = new Date();
              $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
              $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
              $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
              $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
              
              setTimeout(function(){
                  angular.element(document.querySelector('#working_from_id')).trigger('change');
                  angular.element(document.querySelector('#working_to_id')).trigger('change');
              },1000);                
              /* End */
              $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                  // if($stateParams.id){
                      interpreterDashboardService.getInterpreterProfileDetailById().get(function(response, err){
                        // console.log("RESPONSE", response);
                          if(response.status == 1){
                              var interpreter = response.data;
                              if(interpreter.working_from!=undefined && interpreter.working_to){
                                  var tmpTime,tmpTime1;
                                  tmpTime = CommonService.convertTo24Format(interpreter.working_from);
                                  $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                                  $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                                  $scope.minTime = $scope.working_from_full1;
                                  tmpTime1 = CommonService.convertTo24Format(interpreter.working_to);
                                  $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime1.hour,tmpTime1.minute,0);
                              }
                              if(interpreter.languages!=undefined && interpreter.languages.length>0){
                                  $scope.languages=[];
                                  var tmpObj={};
                                  angular.forEach(interpreter.languages, function(language, key) {
                                      tmpObj = language;
                                      if(key!=0){
                                          tmpObj.isRemovable=true;
                                      }else{
                                          tmpObj.isRemovable=false;
                                      }
                                      $scope.languages.push(tmpObj);
                                  });
                                  
                                  interpreter.languages = interpreter.languages[0];
                              }else{
                                  $scope.languages=[{}];
                              }
                              if(interpreter.working_days!=undefined){
                                  interpreter.working_days = interpreter.working_days[0];
                              }
                              
                              interpreter.email = interpreter.user_id.email

                              for(var i=0;i<$scope.serviceList.length;i++){
                                  for (var j=0;j<interpreter.services.length;j++) {
                                      if($scope.serviceList[i].name==interpreter.services[j].name
                                          && interpreter.services[j].ticked==true){
                                          $scope.serviceList[j].ticked=true;
                                          break;
                                      }
                                  }
                              }
                              if(interpreter.profile_pic!='' && interpreter.profile_pic!=undefined){
                                  $scope.userDefaultImage=interpreter.profile_pic;
                              }

                              if(interpreter.certificates!=undefined && interpreter.certificates.court_certified != undefined){
                                  interpreter.court_certified = true;
                              }
                              if(interpreter.certificates!=undefined && interpreter.certificates.court_screened != undefined){
                                  interpreter.court_screened = true;
                              }
                              if(interpreter.certificates==undefined){
                                  interpreter.certificates={};
                              }
                              
                              $scope.interpreter = interpreter;
                              $scope.interpreterName = $scope.interpreter.first_name +' '+ $scope.interpreter.last_name;
                          }
                      })
                  // }
          };

          /**
        * variable and function is used for multiple language select 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.languages=[{}];
        $scope.addMoreLanguage =function(){
            $scope.languages.push({isRemovable:true});
        };

        $scope.removeLanguageAt =function(elementIndex){
            $scope.languages.splice(elementIndex, 1);
            if($scope.interpreter.languages!=undefined && $scope.interpreter.languages[elementIndex]!=undefined){
                delete $scope.interpreter.languages[elementIndex];
            }
        };

          $scope.expandCollapseLeftSideBar = function(){
            if (window.innerWidth > 767) {
                
            }
            else{
               $("body").addClass("sidebar-collapse");
               $("body").removeClass("sidebar-open");
            }
          }



      }

  ]);


