
interpreterApp.controller('orgSettingCtrl', ['$rootScope','$scope', '$state',
	 '$uibModalInstance', '$uibModal', '$location', 'logger', 'data','CommonService', 
    'AuthenticationService', 'UserService', '$localStorage', 'InviteUserService',
  function($rootScope, $scope, $state, $uibModalInstance, $uibModal, $location, logger, 
    data , CommonService, AuthenticationService, UserService, $localStorage, InviteUserService) { 
    

    $rootScope.user = CommonService.getUser();
    $scope.inviteUserObj = {};

    $scope.imageBase64 = '';
    var formDataFileUpload = '';

    //console.log('$localStorage.user.defaultOrg.organization:- ',$localStorage.user.defaultOrg.organization);
    $scope.organization = $localStorage.user.defaultOrg.organization;

    //Tabing feature code starts
    $rootScope.tab1 = 1;
    $scope.tab = 1;
		if ($rootScope.tab1) {
        $scope.tab = $rootScope.tab1;
    } else {
        $scope.tab = 1;
    }
    $scope.isSet = function(tabId) {
        if ($rootScope.tab1 === tabId) {
            return true;
        }
    };
    $scope.setViewTab = function(tabId) {
        $rootScope.tab1 = tabId;
        $scope.tab = tabId;       
    };
    //Tabing feature code starts


    $scope.closeuib = function() {
        $uibModalInstance.close('a');
    }

    /**
     * Function is use to update Profile
     * @access private
     * @return json
     * Created by Ashwini
     * @smartData Enterprises (I) Ltd
     * Created Date 11-09-2017
     */
    $scope.updateOrgData = function(form) {
        if (form.$valid) {
            $scope.loader = true;
            $scope.disabled = true;
            UserService.updateOrgData($localStorage.user.permission._id).save($scope.organization, function(response, err) {
                var errorMessage = '';
                $scope.disabled = false;
                $scope.loader = false;
                if (response.code == statusCode.ok) {
                  $uibModalInstance.close({});
                  $state.reload();
                  logger.logSuccess(response.message);
                } else if (response.code == statusCode.permission) {
                    $uibModalInstance.close({});
                } else {
                    logger.logError(response.message);
                }
            });
        }
    }; 

    /**
     * Function is use to get Timezone List
     * @access private
     * @return json
     * Created by Ashwini
     * @smartData Enterprises (I) Ltd
     * Created Date 11-09-2017
     */
    /*$scope.getTimezoneList = function() {
        AuthenticationService.getTimezoneList().get({}, function(response, err) {
            if (response.code == statusCode.ok) {
                $scope.timezoneList = response.data;
            } else {
                logger.logError(response.message);
            }
        });        
    }*/

    /**
     * Function is use to get Designation for User
     * @access private
     * @return json
     * Created by Ashwini
     * @smartData Enterprises (I) Ltd
     * Created Date 19-Aug-2017
     */
    $scope.getDesignation = function() {
        InviteUserService.getDesignation().get({}, function(response, err) {
            if (response.code == 200) {
                $scope.designation = response.data
            } else {
                $scope.designation = {};
            }
        });
    }
    //alert($rootScope.capitalize('hello'));

    /**
     * Function is use to get Invite User List
     * @access private
     * @return json
     * Created by Ashwini
     * @smartData Enterprises (I) Ltd
     * Created Date 19-Aug-2017
     */
    $scope.getInviteUserList = function() {
        var organizationId = $localStorage.user.defaultOrg.organization._id;
        InviteUserService.getInviteUserList().save({ organizationId: organizationId }, function(response, err) {
            if (response.code == 200) {
                $scope.inviteUserList = response.data
            } else {
                $scope.inviteUserList = {};
            }
        });
    }

    /**
     * Function is use to send Invitation User for add in Org
     * @access private
     * @return json
     * Created by Ashwini
     * @smartData Enterprises (I) Ltd
     * Created Date 19-Aug-2017
     * Modified Date 19-Aug-2017
     */
    $scope.inviteUser = function(form) {

        if (form.$valid) {
            $scope.loader = true;
            $scope.disabled = true;

            $scope.inviteUserObj.senderId = $localStorage.user._id;
            $scope.inviteUserObj.organizationId = $localStorage.user.defaultOrg.organization._id;
            
            InviteUserService.inviteUser().save($scope.inviteUserObj, function(response, err) {

                var errorMessage = '';
                $scope.disabled = false;
                $scope.loader = false;
                if (response.code == statusCode.ok) {
                    $scope.getInviteUserList();
                    $scope.getUserListLeftTab();
                    $scope.getUserList();
                    logger.logSuccess(response.message);
                    //$scope.closeuib();
                } else {
                    logger.logError(response.message);
                    //$scope.closeuib();
                }
            });
        }
    }

    $scope.getUserList = function() {
            //console.log('innnn funnn')

            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                counts: [],
                getData: function($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.paramUrl.organizationId = $localStorage.user.defaultOrg.organization._id;
                    $scope.tableLoader = true;
                    $scope.userList = [];

                    UserService.getUserList().save($scope.paramUrl, function(response) {
                        $scope.tableLoader = false;
                        $scope.userList = response.data;
                        params.total(response.totalCount);
                        $defer.resolve(response.data);
                    });

                }
            });
        }

        /**
         * Function is use to cancel Invitation ById in Org
         * @access private
         * @return json
         * Created by Ashwini
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.cancelInviteById = function(id) {
            bootbox.confirm('Are you sure you want to cancel invitation', function(r) {
                if (r) {
                    InviteUserService.cancelInviteById().delete({ id: id }, function(response) {
                        if (response.code == statusCode.ok) {
                            logger.logSuccess(response.message);
                            $scope.getInviteUserList();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        }

       


}])

