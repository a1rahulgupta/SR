	"use strict";

	angular.module("InterpreterDashboard")

	interpreterApp.controller("interpreterDashboardController", ['$scope', '$rootScope', '$localStorage',
	    'ngTableParams', '$routeParams', '$route', '$location', '$filter', 'logger',
	    'ngTableParamsService', '$state', '$stateParams', '$uibModal', 'interpreterDashboardService','InterpreterService','CommonService',
	    function($scope, $rootScope, $localStorage, ngTableParams, $routeParams,
	        $route, $location, $filter, logger, ngTableParamsService, $state, $stateParams,
	        $uibModal, interpreterDashboardService,InterpreterService,CommonService) {
	        $scope.imageBase64 = '';
	        $scope.add = false;
	        $scope.preview = false;
	        $scope.customer = {};
	        $scope.disabled = false;
	        $scope.loader = false;

            $scope.interpreter={};
            $scope.interpreter.certificate = false;
            $scope.interpreter.court_certified = false;
            $scope.interpreter.court_screened = false;
            $scope.interpreter.gender='Male';
            $scope.interpreter.working_status = 'full time';
            $scope.interpreter.working_days = {
                monday: true,
                tuesday: true,
                wednesday: true,
                thursday: true,
                friday: true,
                saturday: false,
                sunday: false
            }
	        //$scope.loggedInUserData = $rootScope.loggedInUserData;
	        $scope.loggedInUserData = $localStorage.user;

	        $scope.isCropVisible=false;
        $scope.myImage='';
        $scope.myCroppedImage='';
        $scope.isImageSelected=false;
        var handleFileSelect=function(evt) {
            $scope.isImageSelected=false;
            $scope.isCropVisible=true;
            var file=evt.currentTarget.files[0];
            var reader = new FileReader();
            reader.onload = function (evt) {
                $scope.$apply(function($scope){
                    $scope.myImage=evt.target.result;
                });
            };
            reader.readAsDataURL(file);
        };
        angular.element(document.querySelector('#fileInput')).on('change',handleFileSelect);
        $scope.openFileBrowse = function(fileInputSelector) {
            angular.element(document.querySelector(fileInputSelector)).trigger('click');
        };
      
        var formDataFileUpload = '';
        $scope.imageBase64 = '';
        angular.element(document).ready(function() {
            setTimeout(function() {
                if(document.getElementById('fileInput')!=null){
                    document.getElementById('fileInput').addEventListener('change', function(evt) {
                        var files = evt.target.files;
                        var file = files[0];
                        if (files && file) {
                            var splitFileName = file.name.split('.');
                            var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                            if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {
                                if (file.size > 6291456) {
                                    logger.log('File size cannot exceed limit of 6 mb');
                                    document.getElementById("fileInput").value = "";
                                } else {
                                    formDataFileUpload = file;
                                    // formDataFileUpload.append('file', file);
                                    var reader = new FileReader();
                                    reader.onload = function(readerEvt) {
                                        $scope.imageBase64 = btoa(readerEvt.target.result);
                                        $scope.$apply();
                                        document.querySelector('#imgTag').src = 'data:image/' + ext + ';base64,' + $scope.imageBase64;
                                    };
                                    reader.readAsBinaryString(file);
                                }
                            } else {
                                document.getElementById("fileInput").value = "";
                                bootbox.alert('Invalid image format');
                            }
                        }
                    });
                }
            }, 500);
        });


	    /**
        * Variable is used for service list
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        * Modified Date 27-Dec-2017
        **/
        $scope.localLang = {
            selectAll       : "Tick all",
            selectNone      : "Tick none",
            reset           : "Undo all",
            search          : "Type here to search...",
            nothingSelected : "Nothing is selected"         //default-label is deprecated and replaced with this.
        };

        /**
        * Function is used to get all service list 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Dec-2017
        **/
        $scope.getAllServicesInInterpreterProfile = function(){
            InterpreterService.getAllServicesInInterpreter().get({},function(response, err){
                if(response.status == 1){
                    $scope.serviceList = response.data;
                }else{
                    $scope.serviceList = {};
                }
            })
        }

        /**
        * variable and function is used for multiple language select 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Dec-2017
        **/
        $scope.languages=[{}];
        $scope.addMoreLanguage =function(){
            $scope.languages.push({isRemovable:true});
        };

        $scope.removeLanguageAt =function(elementIndex){
            $scope.languages.splice(elementIndex, 1);
            if($scope.interpreter.languages!=undefined && $scope.interpreter.languages[elementIndex]!=undefined){
                $scope.interpreter.languages.splice(elementIndex, 1);
            }
        };

        /**
        * variable and function is used get all languages 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Dec-2017
        **/
        $scope.getAllLanguagesInInterpreterProfile = function(){
            InterpreterService.getAllLanguagesInInterpreter().get({},function(response, err){
                if(response.status == 1){
                    $scope.interpreterLanguages = response.data;
                }else{
                    $scope.interpreterLanguages = {};
                }
            })
        }

        /**
        * Function is used to check extension of a file 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Nov-2017
        **/
        $scope.ckhExtension = function(filePath){
            var fileType = filePath;
            if(fileType!=undefined && typeof fileType=='string'){
                var fileName = fileType.split('/').reverse()[0];
                var file_ext = fileName.split('.').reverse()[0];
                var file_ext = file_ext.toLowerCase();
            }else{
                return file_ext='';
            }
            return file_ext;            
        }

        $scope.getInterpreterProfileById = function(){
        	/* Variables is used to initialize the working hours on document ready */
            var currentDate = new Date();
            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),0,0,0);
            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
            $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
            
            setTimeout(function(){
                angular.element(document.querySelector('#working_from_id')).trigger('change');
                angular.element(document.querySelector('#working_to_id')).trigger('change');
            },1000);                
            /* End */
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            interpreterDashboardService.getInterpreterProfileDetailById().get(function(response, err){
                if(response.status == 1){
                    var interpreter = response.data;
                    if(interpreter.working_from !=undefined && interpreter.working_to !=undefined){
                        var tmpTime,tmpTime1;
                        tmpTime = CommonService.convertTo24Format(interpreter.working_from);
                        $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                        $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                        $scope.minTime = $scope.working_from_full1;
                        tmpTime1 = CommonService.convertTo24Format(interpreter.working_to);
                        $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime1.hour,tmpTime1.minute,0);
                    }

                    //Copy services array due to multilple languages status changed
                    $scope.languageArray = angular.copy(interpreter.languages); 
                    //End

                    if(interpreter.languages!=undefined && interpreter.languages.length>0){
                        $scope.languages=[];
                        var tmpObj={};
                        angular.forEach(interpreter.languages, function(language, key) {
                            tmpObj = language;
                            if(key!=0){
                                tmpObj.isRemovable=true;
                            }else{
                                tmpObj.isRemovable=false;
                            }
                            $scope.languages.push(tmpObj);
                        });
                        interpreter.languages = interpreter.languages;
                    }else{
                        $scope.languages=[{}];
                    }
                    if(interpreter.working_days!=undefined){
                        interpreter.working_days = interpreter.working_days;
                    }
                    
                    if(interpreter.profile_pic!='' && interpreter.profile_pic!=undefined){
                        $scope.userDefaultImage=interpreter.profile_pic;
                    }

                    if(interpreter.certificates!=undefined && interpreter.certificates.court_certified != undefined){
                        interpreter.court_certified = true;
                    }
                    if(interpreter.certificates!=undefined && interpreter.certificates.court_screened != undefined){
                        interpreter.court_screened = true;
                    }
                    if(interpreter.certificates==undefined){ 
                        interpreter.certificates={};
                    }

                    //Copy services array due to multilple services status changed
                    $scope.serviceArray = angular.copy(interpreter.services); 
                    //End

                    setTimeout(function() {
                        for(var i=0; i<$scope.serviceList.length;i++){
                            for (var j=0;j<interpreter.services.length;j++) {
                                if($scope.serviceList[i].name == interpreter.services[j].name
                                    && interpreter.services[j].ticked == true){
                                    $scope.serviceList[i].ticked=true;
                                    break;
                                }
                            }
                        }
                        $scope.$apply();
                        // console.log("$scope.interpreter",$scope.interpreter.certificates);
                    }, 500);
                    $scope.interpreter = interpreter;
                }else{
                      $scope.interpreter = {};
                }
            })
        };

        	// $scope.updateInterpreter = function() {
	        //     if($scope.isImageSelected==true){
	        //         $scope.interpreter.imageFile = $scope.myCroppedImage;
	        //     }
	        //     var formData = new FormData();
	        //     formData.append('interpreter',angular.toJson($scope.interpreter));
	        //     if(typeof $scope.interpreter.certificates.court_certified == 'object'){
	        //         formData.append('court_certified',$scope.interpreter.certificates.court_certified);
	        //     }
	        //     if(typeof $scope.interpreter.certificates.court_screened == 'object'){
	        //         formData.append('court_screened',$scope.interpreter.certificates.court_screened);    
	        //     }
            
         //    // console.log("$scope.interpreter",$scope.interpreter);

	        //     InterpreterService.updateInterpreter().save(formData, function(response, err) {
	        //         if (response.status == 1) {
	        //             logger.logSuccess(response.message); 
	        //             $location.path('/listInterpreter');
	        //         } else {
	        //             logger.logError(response.message);
	        //         }
	        //     });
        	// };
        	$scope.updateInterpreterProfile = function() {
	            // if (!isMobileValid) {
	                $scope.loader = true;
	                $scope.disabled = true;

	                if($scope.isImageSelected==true){
	                    $scope.interpreter.imageFile = $scope.myCroppedImage;
	                }
	                var interpreter = $scope.interpreter;
	                var serviceArray = $scope.serviceArray;
	                var hasFound = false;
	                var tmp = {};
	                for(var i=0; i< serviceArray.length; i++){
	                    hasFound = false;
	                    for(var j=0; j< interpreter.services.length; j++){
	                        if(serviceArray[i].service_id == interpreter.services[j]._id){
	                            hasFound = true;
	                            break;
	                        }
	                    }
	                    if(!hasFound){
	                        tmp = serviceArray[i];
	                        tmp._id=tmp.service_id;
	                        tmp.ticked = false;
	                        interpreter.services.push(tmp);
	                    }
	                }

	                var languageArray = $scope.languageArray;
	                var hasFound = false;
	                var tmp = {};
	                for(var i=0; i< languageArray.length; i++){
	                    hasFound = false;
	                    for(var j=0; j< interpreter.languages.length; j++){
	                        if(languageArray[i].language_id == interpreter.languages[j].language_id){
	                            hasFound = true;
	                            break;
	                        }
	                    }
	                    if(!hasFound){
	                        tmp = languageArray[i];
	                        tmp.language_id=tmp.language_id;
	                        tmp.spoken = tmp.spoken;
	                        tmp.written = tmp.written;
	                        tmp.is_deleted = true;
	                        interpreter.languages.push(tmp);
	                    }
	                }

	                var formData = new FormData();
	                formData.append('interpreter',angular.toJson(interpreter));
	                if(typeof $scope.interpreter.certificates.court_certified == 'object'){
	                    formData.append('court_certified',$scope.interpreter.certificates.court_certified);
	                }
	                if(typeof $scope.interpreter.certificates.court_screened == 'object'){
	                    formData.append('court_screened',$scope.interpreter.certificates.court_screened);    
	                }

	                interpreterDashboardService.updateInterpreterProfile().save(formData, function(response, err) {
	                    var errorMessage = '';
	                    $scope.disabled = false;
	                    $scope.loader = false;
	                    if (response.status == 1) {
	                        logger.logSuccess(response.message); 
	                        $location.path('/interpreter_dashboard');
	                    } else {
	                        logger.logError(response.message);
	                    }
	                });
	            // }
	            
	        };

        	$scope.dateModel = {};
            $scope.today = function() {
                $scope.dt = new Date();
            };
            $scope.dateformat = "dd/MM/yyyy";
            $scope.today();
            $scope.showcalendar = function($event) {
                $scope.dateModel.showdp = true;
            };
            $scope.showcalendar1 = function($event) {
                $scope.dateModel.showdp1 = true;
            };
            $scope.dateModel.showdp = false;
            $scope.dateModel.showdp1 = false;
            $scope.dtmax = new Date();
            
		    $scope.calculateAge = function(DOB) {
	    	console.log('DOB', DOB);
            var birthDay = DOB.getDate();
            var birthMonth = DOB.getMonth();
            var birthYear = DOB.getFullYear();
            var todayDate = new Date();
            var todayYear = todayDate.getFullYear();
            var todayMonth = todayDate.getMonth();
            var todayDay = todayDate.getDate();
            var age = todayYear - birthYear;

            if (todayMonth < birthMonth - 1) {
                age--;
            }

            if (birthMonth - 1 == todayMonth && todayDay < birthDay) {
                age--;
            }
            $scope.interpreter.age = age;
            console.log("age", $scope.interpreter.age);
        }

        $scope.testFunc = function(rating){
		    var displatRating=[];
		    for(var i=0;i<5;i++){
		      if(rating-i>=1){
		        displatRating.push({starType:'fa-star'}); 
		      }else if(rating-i<1 && rating-i>0){
		        displatRating.push({starType:'fa-star-half-o'}); 
		      }else{
		        displatRating.push({starType:'fa-star-o'}); 
		      }
		    }
		    return displatRating;
		}

		$scope.getInterpreterRatingById = function(){
			interpreterDashboardService.getInterpreterRatingById().get(function(response, err) {
                if (response.status == 1) {
                	var ratingArr = [];
                    var rate = response.data;
                    $scope.ratingArr = $scope.testFunc(rate);
                } else {
                	$scope.ratingArr = [];
                    logger.logError(response.message);
                }
            });
		}

		$scope.getAllCountriesInInterpreter = function(){
            interpreterDashboardService.getAllCountriesInInterpreter().get({},function(response, err){
                if(response.status == 1){
                    $scope.interpreterCountries = response.data;
                }else{
                    $scope.interpreterCountries = {};
                }
            })
        }

        $scope.getCountOfInterpreter  = function(){
            console.log("in get count interpreter");
            interpreterDashboardService.getCountOfInterpreter().get(function(response, err){
                if(response.status == 1){
                    $scope.count = response.data;
                } else{
                    $scope.count = {};
                }
            })
        }

        $scope.changeTimeOnStatusChanged = function(status){
            if(status == 'full time'){
                var currentDate = new Date();
                $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),0,0,0);
                $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                
                setTimeout(function(){
                    angular.element(document.querySelector('#working_from_id')).trigger('change');
                    angular.element(document.querySelector('#working_to_id')).trigger('change');
                },1000); 
            }else{
                var currentDate = new Date();
                $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
                $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),15,0,0);
                $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                
                setTimeout(function(){
                    angular.element(document.querySelector('#working_from_id')).trigger('change');
                    angular.element(document.querySelector('#working_to_id')).trigger('change');
                },1000); 
            }
        }


	    }
	]);
