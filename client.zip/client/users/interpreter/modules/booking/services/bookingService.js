"use strict"

angular.module("InterpreterBooking")

.factory('InterpreterBookingService', ['$http', '$resource', function($http, $resource) {
    
    var listBookingByInterpreterId = function() {
        return $resource(webservices.listBookingByInterpreterId, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAgencyInterpreters = function() {
        return $resource(webservices.getAgencyInterpreters, null, {
            save: {
                method: 'GET'
            }
        });
    }
           
    var getAgencyClients = function() {
        return $resource(webservices.getAgencyClients, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var addBooking = function() {
        return $resource(webservices.addBooking, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getInterpreterBookingById = function(id) {
        return $resource(webservices.getInterpreterBookingById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getBookingInterpreterById = function(id) {
        return $resource(webservices.getBookingInterpreterById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var deleteBooking = function(id) {
        return $resource(webservices.deleteBooking, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

     var updateBooking = function() {
        return $resource(webservices.updateBooking, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getBookingList = function() {
        return $resource(webservices.getBookingList, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var initializeTwilio = function() {
        return $resource(webservices.initializeTwilio, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getReviewByBookingId = function(id) {
        return $resource(webservices.getReviewByBookingId, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var downloadPaperVoucher = function() {
        return $resource(webservices.downloadPaperVoucher, null, {
            save: {
                method: 'GET'
            }
        });
    }

    return {
        getBookingList: getBookingList,
        getAgencyInterpreters: getAgencyInterpreters,
        getAgencyClients: getAgencyClients,
        addBooking: addBooking,
        deleteBooking:deleteBooking,
        updateBooking: updateBooking,
        getBookingInterpreterById:getBookingInterpreterById,
        
        listBookingByInterpreterId: listBookingByInterpreterId,
        getInterpreterBookingById: getInterpreterBookingById,
        initializeTwilio: initializeTwilio,
        getReviewByBookingId: getReviewByBookingId,
        downloadPaperVoucher: downloadPaperVoucher


    }

}]);
