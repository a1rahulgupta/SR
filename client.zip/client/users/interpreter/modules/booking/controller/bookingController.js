"use strict";

angular.module("InterpreterBooking")

interpreterApp.controller("interpreterBookingController", ['$scope', '$rootScope', '$localStorage',
    'ngTableParams', '$routeParams', '$route', '$location', '$state',
    '$stateParams', 'logger', 'ngTableParamsService', 'CommonService', 'InterpreterBookingService','BookingService', '$uibModal','blockUI','blockUIConfig','$window',
    function($scope, $rootScope, $localStorage, ngTableParams, $routeParams,
        $route, $location, $state, $stateParams, logger, ngTableParamsService,
        CommonService, InterpreterBookingService,BookingService, $uibModal,blockUI,blockUIConfig,$window) {


            if ($state.params.id) {
                $scope.isUpdate = true;
            } else {
                $scope.isUpdate = false;
            }

            /**
            * Variable is used for active class on leftbar
            * @access private
            * @return json
            * Created by sunny
            * @smartData Enterprises (I) Ltd
            * Created Date 27-Sep-2017
            **/
            $rootScope.menuBooking = ['interpreter_listBooking', 'interpreter_viewBooking', 'interpreter_calendarBooking', 'interpreter_viewBookingModal'];
            
            $scope.timeSettings = {};
            $scope.eventSources = [
                function(start, end, timezone, callback) {
                    InterpreterBookingService.getBookingList().get({}, function(response) {
                        var events = []; 
                        if (response.status == 1) {
                            $scope.scheduleBookingList = response.data;
                                                             
                            $scope.scheduleBookingList.forEach(function(value, index) {
                                $scope.colorName = $scope.getRandomColor();

                                events.push({
                                    start: new Date(moment(value.booking_from)), //$filter('dateFilter')(hol.HOLIDAY_START),
                                    end: new Date(moment(value.booking_to)), //$filter('dateFilter')(hol.HOLIDAY_END),
                                    title: value.service_title, //hol.HOLIDAY_TITLE,
                                    color: $scope.colorName,//'#c23333', //$filter('colorEventFilter')(hol.HOLIDAY_EVENT_STATE_ID)
                                    bookingDetail: value
                                });
                            });

                            callback(events);
                            $scope.calendarLoader = false;
                        }

                    });
                    
                }
            ];

            $scope.orderAll = [];
            $scope.calendarLoader = true;
            $scope.getScheduleBookingList = function() {
                $scope.uiConfig = {
                    calendar: {
                            displayEventTime: false,
                            editable: true,
                            eventLimit: true,   
                            timezone:'local',
                            views: {
                             month: {
                               eventLimit: 4
                             }
                            },
                    height: 550,
                    navLinks: true,
                    timeFormat: 'hh:mm a',
                    // editable: true,
                    header:{
                      left: 'month basicWeek basicDay agendaWeek agendaDay',
                      center: 'title',
                      right: 'today prev,next'
                    },
                    eventClick: function(calEvent, jsEvent, view) {

                      $scope.viewBookingModel(calEvent.bookingDetail._id)
                    },
                    eventDrop: $scope.alertOnDrop,
                    eventResize: $scope.alertOnResize,
                
                    }   
                }
            }


            $scope.viewBookingModel  = function(data) {
                $uibModal.open({
                        templateUrl: 'interpreter/modules/booking/views/viewBookingModal.html',
                        size: "lg",
                        // windowClass: 'app-per-modal-window',
                        controller: function($scope,$rootScope, $uibModalInstance) {
                            $scope.timeSettings = {};

                            $scope.closeuib = function() {
                                $uibModalInstance.close('a');
                            }
                            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                            InterpreterBookingService.getBookingInterpreterById().get({id:data},function(response, err){
                                if(response.status == 1){
                                    var booking = response.data;
                                    booking.booking_from = new Date(moment(booking.booking_from));
                                    booking.booking_to = new Date(moment(booking.booking_to));
                                    $scope.booking = booking; 
                                    if(booking.client_id.profile_pic!='' && booking.client_id.profile_pic!=undefined){
                                        $scope.userDefaultImage = booking.client_id.profile_pic;
                                    }
                                    $scope.getPlace(booking.lat,booking.lng,booking.address);
                                }else{
                                    $scope.bookingDetail = {};
                                }
                            })

                            $scope.getAgencyInterpreters = function(){
                                InterpreterBookingService.getAgencyInterpreters().get({},function(response, err){
                                    if(response.status == 1){
                                        $scope.agencyInterpreters = response.data;
                                    }else{
                                        $scope.agencyInterpreters = {};
                                    }
                                })
                            }  

                            $scope.getAgencyClients = function(){
                                InterpreterBookingService.getAgencyClients().get({},function(response, err){
                                    if(response.status == 1){
                                        $scope.agencyClients = response.data;
                                    }else{
                                        $scope.agencyClients = {};
                                    }
                                })
                            } 

                            $scope.dateModel = {};
                            $scope.today = function() {
                                $scope.dt = new Date();
                            };
                            $scope.dateformat = "MM/dd/yyyy";
                            $scope.today();
                            $scope.showcalendar = function($event) {
                                $scope.dateModel.showdp = true;
                            };
                            $scope.showcalendar1 = function($event) {
                                $scope.dateModel.showdp1 = true;
                            };
                            $scope.dateModel.showdp = false;
                            $scope.dateModel.showdp1 = false;
                            $scope.dtmax = new Date(); 

                            var infowindow,marker,infowindowContent,autocomplete,map;
                            $scope.initMap = function () {
                                map = new google.maps.Map(document.getElementById('map'), {
                                  center: {lat: 41.310726, lng: -72.929916},
                                  zoom: 15,
                                });

                                var input = document.getElementById('pac-input');
                                autocomplete = new google.maps.places.Autocomplete(input);
                                autocomplete.bindTo('bounds', map);
                                infowindow = new google.maps.InfoWindow();
                                infowindowContent = document.getElementById('infowindow-content');
                                infowindow.setContent(infowindowContent);
                                marker = new google.maps.Marker({
                                  map: map
                                });

                                setTimeout(function() {
                                   google.maps.event.trigger(map, 'resize');
                                }, 1000);

                                autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
                                 
                            }

                              $scope.fetchAutocomplete = function(){
                                  infowindow.close();
                                  marker.setVisible(false);
                                  var place = autocomplete.getPlace();
                                  if (!place.geometry) {
                                    // User entered the name of a Place that was not suggested and
                                    // pressed the Enter key, or the Place Details request failed.
                                    window.alert("No details available for input: '" + place.name + "'");
                                    return;
                                  }
                                  var lat = place.geometry.location.lat();
                                  var lng = place.geometry.location.lng();
                                  var address = place.formatted_address;
                                  $scope.lat = lat;
                                  $scope.lng = lng;  
                                  // If the place has a geometry, then present it on a map.
                                  if (place.geometry.viewport) {
                                    map.fitBounds(place.geometry.viewport);
                                  } else {
                                    map.setCenter(place.geometry.location);
                                    map.setZoom(15);  // Why 17? Because it looks good.
                                  }
                                  marker.setPosition(place.geometry.location);
                                  marker.setVisible(true);

                                  infowindowContent.children['place-icon'].src = place.icon;
                                  infowindowContent.children['place-name'].textContent = place.name;
                                  infowindowContent.children['place-address'].textContent = address;
                                  infowindow.open(map, marker);

                                 
                                  
                              }
                              $scope.getPlace = function(lat,lng,address) {
                                  var latlng = new google.maps.LatLng(lat, lng);
                                  var geocoder = new google.maps.Geocoder();
                                  geocoder.geocode({'latLng': latlng}, function(results, status) {
                                    if (status == google.maps.GeocoderStatus.OK) {
                                      if (results[1]) { 
                                        marker = new google.maps.Marker({
                                            position: latlng,
                                            map: map
                                        });

                                        map.setCenter(marker.getPosition());
                                        map.setZoom(15); 
                                        $scope.lat = lat;
                                        $scope.lng = lng;
                                        infowindowContent.children['place-address'].textContent = address;
                                        marker.setIcon(null);
                                        infowindow.open(map, marker);
                                      }
                                      else {
                                        //handle error status accordingly
                                      }
                                    }
                                  })
                                }


                        }
                    });
            };

            $scope.getRandomColor = function() {
                var letters = 'DGABA'.split('');
                var color = '#';
                for (var i=0; i<3; i++ ) {
                    color += letters[Math.floor(Math.random() * letters.length)];
                }
                return color;
            }
            
           

            $scope.getBookingListByInterpreterId = function(){
                InterpreterBookingService.getBookingList().get({},function(response, err){
                    if(response.status == 1){
                        $scope.bookingList = response.data;
                    }else{
                        $scope.bookingList = {};
                    }
                })
            }  

            /**
        * Function is used to get booking list of an interpreter
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 12-Oct-2017
        **/
        $scope.listBookingByInterpreterId = function() {
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.bookingList = [];
                    InterpreterBookingService.listBookingByInterpreterId().save($scope.paramUrl, function(response, err) {
                        if (response.status == 1) {
                            $scope.tableLoader = false;
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };

        /**
        * Function is used to get booking list of an interpreter by searching
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 12-Oct-2017
        **/
        $scope.listBookingByInterpreterIdSearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.bookingList = [];
                    InterpreterBookingService.listBookingByInterpreterId().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };


            $scope.getAgencyInterpreters = function(){
                InterpreterBookingService.getAgencyInterpreters().get({},function(response, err){
                    if(response.status == 1){
                        $scope.agencyInterpreters = response.data;
                    }else{
                        $scope.agencyInterpreters = {};
                    }
                })
            }  

            $scope.getAgencyClients = function(){
                BookingService.getAgencyClients().get({},function(response, err){
                    if(response.status == 1){
                        $scope.agencyClients = response.data;
                    }else{
                        $scope.agencyClients = {};
                    }
                })
            } 

            $scope.addBooking = function(form) {
                if (form.$valid) {
                    $scope.loader = true;
                    $scope.disabled = true;
                        
                    $scope.booking.working_from = $scope.timeSettings.fromHour+':'+$scope.timeSettings.fromMinute;
                    $scope.booking.working_to = $scope.timeSettings.toHour+':'+$scope.timeSettings.toMinute;
                    $scope.booking.lat = $scope.lat;
                    $scope.booking.lng = $scope.lng;
                    // $scope.booking.address = $scope.address;
                    BookingService.addBooking().save($scope.booking, function(response, err) {

                        var errorMessage = '';
                        $scope.disabled = false;
                        $scope.loader = false;
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $location.path('listBooking');
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }

            };

            $scope.dateModel = {};
            $scope.today = function() {
                $scope.dt = new Date();
            };
            $scope.dateformat = "MM/dd/yyyy";
            $scope.today();
            $scope.showcalendar = function($event) {
                $scope.dateModel.showdp = true;
            };
            $scope.showcalendar1 = function($event) {
                $scope.dateModel.showdp1 = true;
            };
            $scope.dateModel.showdp = false;
            $scope.dateModel.showdp1 = false;
            $scope.dtmax = new Date(); 

            $scope.getInterpreterBookingById = function(){
                if($stateParams.id){
                    $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                    InterpreterBookingService.getInterpreterBookingById().get({id:$stateParams.id},function(response, err){
                        if(response.status == 1){
                            var booking = response.data;
                            booking.booking_from = new Date(moment(booking.booking_from));
                            booking.booking_to = new Date(moment(booking.booking_to));
                            if(booking.client_id.profile_pic!='' && booking.client_id.profile_pic!=undefined){
                                $scope.userDefaultImage = booking.client_id.profile_pic;
                            }
                            $scope.booking = booking;
                            $scope.getPlace(booking.lat,booking.lng,booking.address);
                        }
                    })
                }
            }

            $scope.deleteBooking = function(id) {
                bootbox.confirm('Are you sure, you want to delete this booking?', function(r) {
                    if (r) {
                        BookingService.deleteBooking().delete({id:id},function(response, err) {
                            if (response.status == 1) {
                                logger.logSuccess(response.message); 
                                $scope.getBookingListByInterpreterId();
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                })

            }  

            $scope.updateBooking = function(form) {
                 if (form.$valid) {
                    $scope.loader = true;
                    $scope.disabled = true;
                        $scope.booking.working_from = $scope.timeSettings.fromHour+':'+$scope.timeSettings.fromMinute;
                        $scope.booking.working_to = $scope.timeSettings.toHour+':'+$scope.timeSettings.toMinute;
                        $scope.booking.lat = $scope.lat;
                        $scope.booking.lng = $scope.lng;
                        console.log("update booking",$scope.booking);
                        BookingService.updateBooking().save($scope.booking, function(response, err) {
                            var errorMessage = '';
                            $scope.disabled = false;
                            $scope.loader = false;
                            if (response.status == 1) {
                                logger.logSuccess(response.message); 
                                $location.path('/listBooking');
                            } else {
                                logger.logError(response.message);

                            }
                        });
                    }

            }

        // $scope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams){ 
        //     window.dispatchEvent(new Event('resize'));
        // });
        
        var infowindow,marker,infowindowContent,autocomplete,map;
        $scope.initMap = function () {

            map = new google.maps.Map(document.getElementById('map'), {
              center: {lat: 41.310726, lng: -72.929916},
              zoom: 15,
            });

            var input = document.getElementById('pac-input');
            autocomplete = new google.maps.places.Autocomplete(input);

            autocomplete.bindTo('bounds', map);
            infowindow = new google.maps.InfoWindow();
            infowindowContent = document.getElementById('infowindow-content');
            infowindow.setContent(infowindowContent);
            marker = new google.maps.Marker({
              map: map
            });

            autocomplete.addListener('place_changed', $scope.fetchAutocomplete);

            
          }


          $scope.fetchAutocomplete = function(){
              infowindow.close();
              marker.setVisible(false);
              var place = autocomplete.getPlace();
              if (!place.geometry) {
                // User entered the name of a Place that was not suggested and
                // pressed the Enter key, or the Place Details request failed.
                window.alert("No details available for input: '" + place.name + "'");
                return;
              }
              var lat = place.geometry.location.lat();
              var lng = place.geometry.location.lng();
              var address = place.formatted_address;
              $scope.lat = lat;
              $scope.lng = lng;  
              // If the place has a geometry, then present it on a map.
              if (place.geometry.viewport) {
                map.fitBounds(place.geometry.viewport);
              } else {
                map.setCenter(place.geometry.location);
                map.setZoom(15);  // Why 17? Because it looks good.
              }
              marker.setPosition(place.geometry.location);
              marker.setVisible(true);

              infowindowContent.children['place-icon'].src = place.icon;
              infowindowContent.children['place-name'].textContent = place.name;

              infowindowContent.children['place-address'].textContent = address;
              infowindow.open(map, marker);
          }
          $scope.getPlace = function(lat,lng,address) {
              var latlng = new google.maps.LatLng(lat, lng);
              var geocoder = new google.maps.Geocoder();
              geocoder.geocode({'latLng': latlng}, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                  if (results[1]) { 
                    marker = new google.maps.Marker({
                        position: latlng,
                        map: map
                    });

                    map.setCenter(marker.getPosition());
                    map.setZoom(15); 
                    $scope.lat = lat;
                    $scope.lng = lng;
                    infowindowContent.children['place-address'].textContent = address;
                    marker.setIcon(null);
                    infowindow.open(map, marker);
                  }
                  else {
                    //handle error status accordingly
                  }
                }
              })
            }

         /**
        * Function is used to view the booking of interpreter
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 13-Oct-2017
        **/
        $scope.viewBooking = function(booking) {
            $state.go('interpreter_viewBooking', {id:booking._id});
        };

        /**
        * Function and variable is used to make web phone call
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Nov-2017
        **/
        $scope.twilioCall={};
        $scope.isInCall=false;
        var selectedClientToCallIndex = -1;
        $scope.webCallToInterpreter = function(phoneNo,selectedIndex){
            var params = {"phoneNumber": phoneNo};
            Twilio.Device.connect(params);
            selectedClientToCallIndex = selectedIndex;
        }
        

        /**
        * Function is used to disconnect web phone call
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Nov-2017
        **/
        $scope.endWebCall = function(selectedIndex){
            selectedClientToCallIndex = selectedIndex;
            Twilio.Device.disconnectAll();
        }
        
        /**
        * Function is used to intialize twilio
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Nov-2017
        **/
        $scope.initializeTwilio = function(){
            var data = {
                page: 'customer'
            }
            InterpreterBookingService.initializeTwilio().save(data, function(response, err) {
                console.log("Token response", response);
                if (response.status == 1) {
                    Twilio.Device.setup(response.data.token);
                    logger.logSuccess(response.message); 
                } else {
                    logger.logError(response.message);
                }
            });

            /* Report any errors to the call status display */
            Twilio.Device.error(function (error) {
                alert("ERROR: " + error.message);
            });
            
            /* Callback for when Twilio Client initiates a new connection */
            Twilio.Device.connect(function (connection) {
                if ("phoneNumber" in connection.message) {
                    if(selectedClientToCallIndex>-1){
                        $scope.$apply(function () {
                            $scope.isInCall= true;
                            $scope.twilioCall[selectedClientToCallIndex]['is_calling']=true;
                            $scope.twilioCall[selectedClientToCallIndex]['user_msg']="End Call";
                       });
                    }
                }
            });
            
            /* Callback for when a call ends */
            Twilio.Device.disconnect(function(connection) {
                if(selectedClientToCallIndex>-1){
                    $scope.isInCall= false;
                    $scope.twilioCall[selectedClientToCallIndex]['is_calling']=false;
                    $scope.twilioCall[selectedClientToCallIndex]['user_msg']="Make Call";
                }
            });
        }

        $scope.testFunc = function(rating){
            var displatRating=[];
            for(var i=0;i<5;i++){
              if(rating-i>=1){
                displatRating.push({starType:'fa-star'}); 
              }else if(rating-i<1 && rating-i>0){
                displatRating.push({starType:'fa-star-half-o'}); 
              }else{
                displatRating.push({starType:'fa-star-o'}); 
              }
            }
            return displatRating;
        }

        $scope.getReviewByBookingId = function() {
            if($stateParams.id){
                InterpreterBookingService.getReviewByBookingId().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var ratingArr = [];
                        if(response.data != undefined && response.data != '' && response.data != null){
                            $scope.reviewRating = response.data;
                            $scope.ratingArr = $scope.testFunc($scope.reviewRating.rating);
                        }else{
                            $scope.ratingArr = [];
                            $scope.reviewRating = {};    
                        }
                    } else {
                        $scope.reviewRating = {};
                        $scope.ratingArr = [];
                    }
                })
            } 
        }; 

        /**
        * Function is used to download paper voucher
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 30-Jan-2017
        **/
        $scope.downloadPaperVoucher = function(id){
            InterpreterBookingService.downloadPaperVoucher().get({id: id}, function(response) {
                if (response.status == 1) {
                    blockUI.start();    
                    var fileName = response.data;
                    console.log("fileName",fileName);
                    $scope.str =  fileName.substring(17, 68);
                    var fileURL = baseUrl+$scope.str;
                    if(fileName !=undefined && fileName !=null && fileName !=''){
                        $window.open(fileURL); 
                    }
                    blockUI.stop();
                } else {
                    $scope.str = {};
                    logger.logError(response.message);
                }
            });
        }   
    

    }
]);
