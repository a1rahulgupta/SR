"use strict"

angular.module("InterpreterManualCheck")

.factory('InterpreterManualCheckService', ['$http', '$resource', function($http, $resource) {

    var getBookindIdsByInterpreterId = function() {
        return $resource(webservices.getBookindIdsByInterpreterId, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getBookingDetailByBookingId = function(id) {
        return $resource(webservices.getBookingDetailByBookingId, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var addManualCheckInOut = function() {
        return $resource(webservices.addManualCheckInOut, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getTodaysBookingForManualCheckInOut = function() {
        return $resource(webservices.getTodaysBookingForManualCheckInOut, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getBookingForManualCheckInOut = function(id) {
        return $resource(webservices.getBookingForManualCheckInOut, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    return {
        
        getBookindIdsByInterpreterId: getBookindIdsByInterpreterId,
        getBookingDetailByBookingId: getBookingDetailByBookingId,
        addManualCheckInOut: addManualCheckInOut,
        getTodaysBookingForManualCheckInOut: getTodaysBookingForManualCheckInOut,
        getBookingForManualCheckInOut: getBookingForManualCheckInOut

    }

}]);
