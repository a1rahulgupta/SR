"use strict";

angular.module("InterpreterManualCheck")

interpreterApp.controller("interpreterManualCheckController", ['$scope', '$rootScope', '$localStorage',
    '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger',
    'ngTableParams', 'ngTableParamsService', 'InterpreterManualCheckService', 'CommonService',
    function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams,
        $http, $uibModal, logger, ngTableParams, ngTableParamsService, InterpreterManualCheckService, CommonService) {
       
        $scope.fromDateChanged = function() {
            var minutesAdded = 30;
            $scope.check_out_time_full = new Date($scope.check_out_time_full.getTime() + minutesAdded*60000);
            $scope.check_in_time_full1 = new Date($scope.check_in_time_full.getTime() + minutesAdded*60000);
            $scope.minTime = new Date($scope.check_in_time_full.getTime() + minutesAdded*60000);
            setTimeout(function(){
                angular.element(document.querySelector('#check_in_id')).trigger('change');
                angular.element(document.querySelector('#check_out_id')).trigger('change');
            },1000);

        } 
        /**
        * Variable is used to active class on leftbar
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 12-Dec-2017
        **/
        $rootScope.menuManualCheck = ['interpreter_manualcheck'];

        /**
        * Function is used to get All booking id's
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 12-Dec-2017
        **/
        $scope.getBookindIdsByInterpreterId = function(){
            
            /* Variables is used to initialize the working hours on document ready */
            var currentDate = new Date();
            $scope.checkInOut = {};
            $scope.check_in_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
            $scope.check_in_time_full1 = new Date($scope.check_in_time_full.getTime() + 30*60000);
            $scope.check_out_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
            $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
            
            setTimeout(function(){
                angular.element(document.querySelector('#check_in_id')).trigger('change');
                angular.element(document.querySelector('#check_out_id')).trigger('change');
            },1000);                
            /* End */

            InterpreterManualCheckService.getBookindIdsByInterpreterId().get(function(response){
                if(response.status == 1){
                  $scope.bookingServiceTitles = response.data;
                } else{
                  $scope.bookingServiceTitles = {};  
                  logger.logError(response.message);
                }
            })
        }

        /**
        * Function is used to get bookind detail by booking id
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 12-Dec-2017
        **/
        $scope.getBookingDetailByBookingId = function(id){
            InterpreterManualCheckService.getBookingDetailByBookingId().get({id:id},function(response, err){
                if(response.status == 1){
                    var booking = response.data;
                    booking.clientName = booking.client_id.first_name + ' ' + booking.client_id.last_name;
                    booking.client_id = booking.client_id._id;
                    $scope.booking = booking;
                } else{
                    $scope.checkInOut = {}
                    logger.logError(response.message);
                }
            })
        }

        /**
        * Function is used to add manual check-in/out
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 13-Dec-2017
        **/
        $scope.addManualCheckInOut = function(){
            var checkInOut = $scope.checkInOut;
            
            var check_in_date = new Date();
            var check_out_date = new Date();
            var tmpStartTime = CommonService.convertTo24Format(checkInOut.check_in_time);
            var tmpEndTime = CommonService.convertTo24Format(checkInOut.check_out_time);
            check_in_date.setHours(tmpStartTime.hour);
            check_in_date.setMinutes(tmpStartTime.minute);
            check_out_date.setHours(tmpEndTime.hour);
            check_out_date.setMinutes(tmpEndTime.minute);

            // date.setDate(date.getDate() + 2);
            var checkInOutObj = {
                booking_id: checkInOut._id,
                client_id: $scope.booking.client_id,
                check_in_time: checkInOut.check_in_time,
                check_in_date: check_in_date,
                check_out_time: checkInOut.check_out_time,
                check_out_date: check_out_date,
                reason_manual:  checkInOut.reason_manual,
                time_confirmation:  checkInOut.time_confirmation ? checkInOut.time_confirmation : false,
                verification_type: 'Manual' 
            }
            console.log("checkInOutObj#########",checkInOutObj); 
            InterpreterManualCheckService.addManualCheckInOut().save(checkInOutObj, function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message);
                    $state.go('interpreter_completed_bookings'); 
                } else {
                    logger.logError(response.message);
                }
            });
        }
        /* End */

        /**
        * Function is used to get todays bookings of interpreter for manual check-in/out 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 05-Apr-2018
        **/
        $scope.getTodaysBookingForManualCheckInOut = function(){
            
            /* Variables is used to initialize the working hours on document ready */
            var currentDate = new Date();
            $scope.checkInOut = {};
            $scope.check_in_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
            $scope.check_in_time_full1 = new Date($scope.check_in_time_full.getTime() + 30*60000);
            $scope.check_out_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
            $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
            
            setTimeout(function(){
                angular.element(document.querySelector('#check_in_id')).trigger('change');
                angular.element(document.querySelector('#check_out_id')).trigger('change');
            },1000);                
            /* End */

            InterpreterManualCheckService.getTodaysBookingForManualCheckInOut().get(function(response){
                if(response.status == 1){
                  $scope.bookingServiceTitles = response.data;
                } else{
                  $scope.bookingServiceTitles = {};  
                  logger.logError(response.message);
                }
            })
        }

        /**
        * Function is used to get bookind detail by booking id
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 12-Dec-2017
        **/
        $scope.getBookingForManualCheckInOut = function(id){
            InterpreterManualCheckService.getBookingForManualCheckInOut().get({id:id},function(response, err){
                if(response.status == 1){
                    var booking = response.data;
                    booking.clientName = booking.client_id.first_name + ' ' + booking.client_id.last_name;
                    booking.client_id = booking.client_id._id;
                    $scope.booking = booking;
                } else{
                    $scope.checkInOut = {}
                    logger.logError(response.message);
                }
            })
        }
                
    }

]);