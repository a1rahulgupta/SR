"use strict";

angular.module("InterpreterCheckIn")

interpreterApp.controller("interpreterCheckInController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger', 'InterpreterCheckInService', 'ngTableParams', 'ngTableParamsService', 'BookingService','CommonService', 'geolocation', 'SchedulerService',
    function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal, logger, InterpreterCheckInService, ngTableParams, ngTableParamsService,BookingService,CommonService, geolocation, SchedulerService) {
       
               
        /**
        * Variable is used to active class on leftbar
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $rootScope.menuCheckIn= ['interpreter_checkIn'];

        /**
        * Function is uesd to initialize map
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 14-Dec-2017
        **/
        $scope.initMap = function(){
            var map;
            map = new google.maps.Map(document.getElementById('map'), {
              center: {lat: 41.310726, lng: -72.929916},
              zoom: 15
            });
        }

        /**
        * Function is uesd get booking view by id and locate booking location with geolocation points
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 14-Dec-2017
        **/
        $scope.getBookingViewById = function(){
            if($stateParams.id){
                SchedulerService.getEventViewById().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var booking = response.data;
                        booking.start_date = new Date(moment(booking.start_date));
                        booking.end_date = new Date(moment(booking.end_date));
                        var clientName = booking.client_id.first_name + ' '+ booking.client_id.last_name;
                        //Time in AM/PM format
                        var dt = new Date();
                        var h =  dt.getHours(), m = (dt.getMinutes()/10<1)? ("0"+dt.getMinutes()):dt.getMinutes();
                        var checkInTime = (h > 12) ? (h-12 + ':' + m +' PM') : (h + ':' + m +' AM');
                        //End
                        booking.clientName =  clientName;
                        booking.checkInTime =  checkInTime;
                        $scope.booking = booking;

                        // Locate the booking location and check-in location in map
                        var bookingPoint = {
                            point: new google.maps.LatLng(booking.lat,booking.lng),
                            radius: 0.5,
                            color: '#00AA00',
                        }
                        $scope.coords = geolocation.getLocation().then(function(data){
                            $scope.latitude = data.coords.latitude;
                            $scope.longitude = data.coords.longitude;
                            $scope.getLocationPoint($scope.latitude,$scope.longitude);
                        });
                        //render the geolocation
                        $scope.getLocationPoint = function(lati, longi){
                            var point = new google.maps.LatLng($scope.latitude, $scope.longitude)
                            var marker = new google.maps.Marker({
                                map: map,
                                position: point,
                                title: "My Location"
                            });
                        }
                        
                        var zoom = 15;
                        var map;
                        var elevator;
                        var mapOptions = {
                            zoom: zoom,
                            center: bookingPoint.point,
                            mapTypeId: google.maps.MapTypeId.ROADMAP,
                        };

                        map = new google.maps.Map(document.getElementById('map'), mapOptions);
                        //render the range
                        var subjectMarker = new google.maps.Marker({
                            map: map,
                            position: bookingPoint.point,
                            title: 'Booking Location'
                        });
                        var subjectRange = new google.maps.Circle({
                            map: map,
                            radius: bookingPoint.radius * 1000,    // metres
                            fillColor: bookingPoint.color,
                        });
                        subjectRange.bindTo('center', subjectMarker, 'position');
                        //End
                    }
                })
            }
        }

        /* Functions is used set timepicker on changing the time */
        $scope.fromDateChanged = function() {
            var minutesAdded = 30;
            $scope.end_time_full = new Date($scope.start_time_full.getTime() + minutesAdded*60000);
            $scope.start_time_full1 = new Date($scope.start_time_full.getTime() + minutesAdded*60000);
            $scope.minTime = new Date($scope.start_time_full.getTime() + minutesAdded*60000);
            setTimeout(function(){
                angular.element(document.querySelector('#start_time_id')).trigger('change');
                angular.element(document.querySelector('#end_time_id')).trigger('change');
            },1000);
        }
        /* End */

        /**
        * Function is uesd get booking view by id for check-out and locate booking location with geolocation points
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 18-Dec-2017
        **/
        $scope.getBookingViewByIdOut = function(){
            /* Variables is used to initialize the working hours on document ready */
            var currentDate = new Date();
            $scope.start_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
            $scope.start_time_full1 = new Date($scope.start_time_full.getTime() + 30*60000);
            $scope.end_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
            $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
            
            setTimeout(function(){
                angular.element(document.querySelector('#start_time_id')).trigger('change');
                angular.element(document.querySelector('#end_time_id')).trigger('change');
            },1000);

            if($stateParams.id){
                SchedulerService.getEventViewById().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var booking = response.data;
                        booking.start_date = new Date(moment(booking.start_date));
                        booking.end_date = new Date(moment(booking.end_date));
                        
                        var clientName = booking.client_id.first_name + ' '+ booking.client_id.last_name;
                        //Time in AM/PM format
                        var dt = new Date();
                        var h =  dt.getHours(), m = (dt.getMinutes()/10<1)? ("0"+dt.getMinutes()):dt.getMinutes();
                        var checkOutTime = (h > 12) ? (h-12 + ':' + m +' PM') : (h + ':' + m +' AM');
                        //End
                        booking.clientName =  clientName;
                        booking.checkOutTime =  checkOutTime;
                        $scope.booking = booking;

                        // Locate the booking location and check-in location in map
                        var bookingPoint = {
                            point: new google.maps.LatLng(booking.lat,booking.lng),
                            radius: 0.5,
                            color: '#00AA00',
                        }
                        $scope.coords = geolocation.getLocation().then(function(data){
                            $scope.latitude = data.coords.latitude;
                            $scope.longitude = data.coords.longitude;
                            $scope.getLocationPoint($scope.latitude,$scope.longitude);
                        });
                        //render the geolocation
                        $scope.getLocationPoint = function(lati, longi){
                            var point = new google.maps.LatLng($scope.latitude, $scope.longitude)
                            var marker = new google.maps.Marker({
                                map: map,
                                position: point,
                                title: "My Location"
                            });
                        }
                        
                        var zoom = 15;
                        var map;
                        var elevator;
                        var mapOptions = {
                            zoom: zoom,
                            center: bookingPoint.point,
                            mapTypeId: google.maps.MapTypeId.ROADMAP,
                        };
                        map = new google.maps.Map(document.getElementById('map'), mapOptions);
                        //render the range
                        var subjectMarker = new google.maps.Marker({
                            map: map,
                            position: bookingPoint.point,
                            title: 'Booking Location'
                        });
                        var subjectRange = new google.maps.Circle({
                            map: map,
                            radius: bookingPoint.radius * 1000,    // metres
                            fillColor: bookingPoint.color,
                        });
                        subjectRange.bindTo('center', subjectMarker, 'position');
                        //End
                    }
                })
            }
        }

        
        $scope.addGeoCheckIn = function(){
            var gpsCheckIn = $scope.booking;
            var date = new Date();
            // date.setDate(date.getDate() + 2);

            var gpsCheckInObj = {
                booking_id: gpsCheckIn._id,
                client_id: gpsCheckIn.client_id._id,
                check_in_time: gpsCheckIn.checkInTime,
                check_in_date: date,
                booking_lat:  gpsCheckIn.lat,
                booking_long: gpsCheckIn.lng,
                // latitude: "41.3163244" ,
                // longitude: "-72.9223430",
                latitude: $scope.latitude,
                longitude: $scope.longitude,
                radius: 500,
                time_confirmation:  $scope.time_confirmation ? $scope.time_confirmation : false
            }
            InterpreterCheckInService.addGeoCheckIn().save(gpsCheckInObj, function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message);
                    $state.go('interpreter_todays_booking'); 
                } else {
                    logger.logError(response.message);
                }
            });
        }

        $scope.addGeoCheckOut = function(){
            var gpsCheckOut = $scope.booking;
            
            var date = new Date();
            // date.setDate(date.getDate() + 2);

            var gpsCheckOutObj = {
                booking_id: gpsCheckOut._id,
                check_out_time: gpsCheckOut.checkOutTime,
                check_out_date: date,
                booking_lat:  gpsCheckOut.lat,
                booking_long: gpsCheckOut.lng,
                // latitude: "41.3163244" ,
                // longitude: "-72.9223430",
                latitude: $scope.latitude,
                longitude: $scope.longitude,
                radius: 500,
                time_confirmation_out:  $scope.time_confirmation ? $scope.time_confirmation : false
            }
            InterpreterCheckInService.addGeoCheckOut().save(gpsCheckOutObj, function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message);
                    $state.go('interpreter_todays_booking'); 
                } else {
                    logger.logError(response.message);
                }
            });
        }

    }

]);