"use strict"

angular.module("InterpreterCheckIn")

.factory('InterpreterCheckInService', ['$http', '$resource', function($http, $resource) {


    var addSubscription = function() {
        return $resource(webservices.addSubscription, null, {
            save: {
                method: 'POST'
            }
        });
    }

     var addGeoCheckIn = function() {
        return $resource(webservices.addGeoCheckIn, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var addGeoCheckOut = function() {
        return $resource(webservices.addGeoCheckOut, null, {
            save: {
                method: 'POST'
            }
        });
    }
    
    return {
        
        addSubscription: addSubscription,
        addGeoCheckIn: addGeoCheckIn,
        addGeoCheckOut: addGeoCheckOut

    }

}]);
