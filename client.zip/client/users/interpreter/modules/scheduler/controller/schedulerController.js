"use strict";

angular.module("Scheduler")

interpreterApp.controller("interpreterSchedulerController", ['$scope', '$rootScope', '$localStorage','ngTableParams',
'$routeParams', '$route', '$location', '$state', '$stateParams', 'logger', 'ngTableParamsService',
'CommonService', 'InterpreterSchedulerService', '$uibModal','$timeout', '$window',
function($scope, $rootScope, $localStorage, ngTableParams, $routeParams, $route, $location, $state, $stateParams, logger, ngTableParamsService,
CommonService, InterpreterSchedulerService, $uibModal,$timeout,$window) {

    /* Variable is used for active class on leftbar */
    $rootScope.menuScheduler = ['interpreter_listSchedulerTable', 'interpreter_listScheduler', 'interpreter_todays_booking', 'interpreter_completed_bookings', 'interpreter_pending_bookings', 'interpreter_viewBookingDetails'];
    $rootScope.menuSchedulerSubTab = ['interpreter_listSchedulerTable', 'interpreter_listScheduler', 'interpreter_viewBookingDetails'];
    $rootScope.menuSchedulerSubTab1 = ['interpreter_todays_booking'];
    $rootScope.menuSchedulerSubTab2 = ['interpreter_completed_bookings'];
    $rootScope.menuSchedulerSubTab3 = ['interpreter_pending_bookings'];
    /* End */

    /* Variable needed to declare first */
    $scope.scheduler = {};
    $scope.calendarLoader = true;
    /* End */

    /* Variables and functions used for 3 datepickers */
    $scope.dateModel = {};
    $scope.today = function() {
        $scope.dt = new Date();
    };
    $scope.dateformat = "MM/dd/yyyy";
    $scope.today();
    $scope.showcalendar = function($event) {
        $scope.dateModel.showdp = true;

    };
    $scope.showcalendar1 = function($event) {
        $scope.dateModel.showdp1 = true;
    };

    $scope.showcalendar2 = function($event) {
        $scope.dateModel.showdp2 = true;
    };

    $scope.dateModel.showdp = false;
    $scope.dateModel.showdp1 = false;
    $scope.dateModel.showdp2 = false;
    $scope.dtmax = new Date();
    /* End */

    /**
    * Variable and function is used to fetch all bookings on the basis of month start and end date then render on full calendar
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 5-March-2018
    **/
    $scope.eventSources = [
        function(start, end, timezone, callback) {
            var events = []; 
            var schedulerObj = {
                month_start_date: start,
                month_end_date: end
            }

            InterpreterSchedulerService.getAllBookings().save(schedulerObj, function(response) {
                if (response.status == 1) {
                    $scope.scheduleBookingList = response.data;
                    $scope.scheduleBookingList.forEach(function(value, index) {
                        events.push({
                            start: moment(value.start).format(), 
                            end: moment(value.end).format(), 
                            title: value.title, 
                            color: value.color,
                            EndsOn : moment(value.EndsOn).format(),
                            parentId : value.parentId,
                            bookingDetail: value.bookingDetail
                        });
                    });
                    callback(events);
                    $scope.calendarLoader = false;
                }
            });
        }
    ];
    /* End */
    
    /**
    * Function is used to set the configuration of full calendar and calling on init
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 5-March-2018
    **/        
    $scope.getScheduleBookingList = function() {
        $scope.uiConfig = {
            calendar: {           
                displayEventTime: true,             
                editable: true,
                timezone: 'local',
                nextDayThreshold: '00:00',
                views: {
                    month: {
                        eventLimit: 2
                    }
                },
                navLinks: true,
                timeFormat: 'hh:mm A',
                header:{
                    left: 'month basicWeek basicDay',
                    center: 'title',
                    right: 'today prev,next'
                },
                eventClick: function(calEvent, jsEvent, view) {
                    var eventDetailObject = calEvent.bookingDetail;
                    eventDetailObject.parent_start_date = calEvent.bookingDetail.start_date;
                    eventDetailObject.parent_end_date = calEvent.bookingDetail.end_date;
                    eventDetailObject.start_date = calEvent.start;
                    eventDetailObject.end_date = calEvent.end;
                    $rootScope.editCurrentEvent(eventDetailObject);
                },
                eventMouseover: function (data, event, view) {                 
                    var  tooltip = '<div class="tooltiptopicevent" style="color:white;width:auto;height:auto;background:#2b2925;position:absolute;z-index:10001;padding:5px 5px 5px 5px; font-size:12px;line-height: 200%;">' + 'Title: ' + data.bookingDetail.service_title + '</br>' + 'Description: ' +  data.bookingDetail.booking_description + '</br>' + 'Starts On: ' + data.start.format("MM-DD-YYYY h:mm A") + '</br>' + 'Ends On: ' + data.end.format("MM-DD-YYYY h:mm A") +'</div>';
                    $("body").append(tooltip);
                    $(this).mouseover(function (e) {
                        $(this).css('z-index', 10000);
                        $('.tooltiptopicevent').fadeIn('500');
                        $('.tooltiptopicevent').fadeTo('10', 1.9);
                    }).mousemove(function (e) {
                        $('.tooltiptopicevent').css('top', e.pageY + 10);
                        $('.tooltiptopicevent').css('left', e.pageX + 20);
                    });
                },
                eventMouseout: function (data, event, view) {
                    $(this).css('z-index', 8);
                    $('.tooltiptopicevent').remove();
                }
            }
        }
    }        
    /* End */

    /**
    * Function is used to get booking list of an interpreter
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 12-Oct-2017
    **/
    $scope.getInterpreterBookingList = function() {
        ngTableParamsService.set('', '', '', '');
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                $scope.paramUrl = params.url();
                $scope.tableLoader = true;
                $scope.bookingList = [];
                InterpreterSchedulerService.getInterpreterBookingList().save($scope.paramUrl, function(response, err) {
                    if (response.status == 1) {
                        $scope.tableLoader = false;
                        $scope.bookingList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.count;
                        params.total(response.count);
                        $defer.resolve(data);
                    } else {
                        logger.logError(response.message);
                    }
                });
            }
        });
    };
    /* End */

    /**
    * Function is used to get booking list of an interpreter by searching
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 12-Oct-2017
    **/
    $scope.getInterpreterListSearching = function(searchTextField) {
        ngTableParamsService.set('', '', searchTextField, '');
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                $scope.paramUrl = params.url();
                $scope.bookingList = [];
                InterpreterSchedulerService.getInterpreterBookingList().save($scope.paramUrl, function(response) {
                    if (response.status == 1) {
                        $scope.bookingList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.count;
                        params.total(response.count);
                        $defer.resolve(data);
                    } else {
                        logger.logError(response.message);
                    }
                });
            }
        })
    };
    /* End */

    /**
    * Function is used to get todays booking list of an interpreter
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 03-Apr-2018
    **/
    $scope.getTodaysInterpreterBookingList = function() {
        ngTableParamsService.set('', '', '', '');
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                $scope.paramUrl = params.url();
                $scope.tableLoader = true;
                $scope.bookingList = [];
                InterpreterSchedulerService.getTodaysInterpreterBookingList().save($scope.paramUrl, function(response, err) {
                    if (response.status == 1) {
                        $scope.tableLoader = false;
                        $scope.bookingList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.count;
                        params.total(response.count);
                        $defer.resolve(data);
                    } else {
                        logger.logError(response.message);
                    }
                });
            }
        });
    };
    /* End */

    /**
    * Function is used to get completed booking list of an interpreter
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 12-Oct-2017
    **/
    $scope.getInterpreterCompletedBooking = function() {
        ngTableParamsService.set('', '', '', '');
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                $scope.paramUrl = params.url();
                $scope.tableLoader = true;
                $scope.bookingList = [];
                InterpreterSchedulerService.getInterpreterCompletedBooking().save($scope.paramUrl, function(response, err) {
                    if (response.status == 1) {
                        $scope.tableLoader = false;
                        $scope.bookingList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.count;
                        params.total(response.count);
                        $defer.resolve(data);
                    } else {
                        logger.logError(response.message);
                    }
                });
            }
        });
    };
    /* End */

    /**
    * Function is used to get pending booking list of an interpreter
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 12-Oct-2017
    **/
    $scope.getInterpreterPendingBookings = function() {
        ngTableParamsService.set('', '', '', '');
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                $scope.paramUrl = params.url();
                $scope.tableLoader = true;
                var before_week_date = new Date();
                before_week_date.setDate(before_week_date.getDate() - 8);
                var yesterday_date = new Date();
                yesterday_date.setDate(yesterday_date.getDate() - 1);
                $scope.paramUrl.before_week_date = before_week_date;
                $scope.paramUrl.yesterday_date = yesterday_date;
                $scope.bookingList = [];
                InterpreterSchedulerService.getInterpreterPendingBookings().save($scope.paramUrl, function(response, err) {
                    if (response.status == 1) {
                        $scope.tableLoader = false;
                        $scope.bookingList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.count;
                        params.total(response.count);
                        $defer.resolve(data);
                    } else {
                        logger.logError(response.message);
                    }
                });
            }
        });
    };
    /* End */
    
    /**
    * Function is search bookings with in the range of two dates 
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 18-Sep-2017
    **/
    $scope.searchBookingByDate = function() {
        var date = {};
        date.searchFrom = $scope.bookingFrom;
        date.searchTo = $scope.bookingTo;
        ngTableParamsService.set('', '', '', '');
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                $scope.paramUrl = params.url();
                $scope.tableLoader = true;
                $scope.bookingList = [];
                $scope.paramUrl.searchFrom = $scope.bookingFrom;
                $scope.paramUrl.searchTo = $scope.bookingTo;
                SchedulerService.searchBookingByDateScheduler().save($scope.paramUrl, function(response, err) {
                    if (response.status == 1) {
                        $scope.tableLoader = false;
                        $scope.bookingList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.count;
                        params.total(response.count);
                        $defer.resolve(data);
                    } else {
                        logger.logError(response.message);
                    }
                });
            }
        });
    };
    
    /* Function is used to clear the dates input and reload the state */
    $scope.clearSearch = function(){
        $scope.bookingFrom = "";
        $scope.bookingTo = "";
        $state.reload();
    }
    /* End */

    /* Function is used to view booking details on click of tabular row */
    $scope.viewBooking = function(booking) {
        $state.go('interpreter_viewBookingDetails', {id:booking._id});
    };
    /* End */    
  
    /**
    * Function is used to get booking detail for view using booking id 
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 18-Sep-2017
    **/
    $scope.getBookingViewByInterpreterId = function(){
        if($stateParams.id){
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            InterpreterSchedulerService.getBookingViewByInterpreterId().get({id:$stateParams.id},function(response, err){
                if(response.status == 1){
                    var booking = response.data;
                    var repeating_interval; 
                    if(booking.recurrence_rule == 'daily'){
                        $scope.repeating_interval = 'Day'
                    }else if(booking.recurrence_rule == 'weekly' || booking.recurrence_rule == 'custom (weekly)'){
                        $scope.repeating_interval = 'Week'
                    }else if(booking.recurrence_rule == 'monthly'){
                        $scope.repeating_interval = 'Month'
                    }else{
                        $scope.repeating_interval = 'Year'
                    }
                    booking.start_date = new Date(moment(booking.start_date));
                    booking.end_date = new Date(moment(booking.end_date));
                    if(booking.client_id.profile_pic!='' && booking.client_id.profile_pic!=undefined){
                        $scope.userDefaultImage = booking.client_id.profile_pic;
                    }
                    $scope.booking = booking;
                    $scope.getPlace(booking.lat,booking.lng,booking.address);
                }else{
                    logger.logError(response.message);
                    $state.go('interpreter_listSchedulerTable');
                }
            })
        }
    }
    /* End */

    /* Functions and variables is used for map load and get lat/long on the basis of google place address bar selection */
    var infowindow,marker,infowindowContent,autocomplete,map;
    $scope.initMap = function () {

        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: 41.310726, lng: -72.929916},
          zoom: 15,
        });

        var input = document.getElementById('pac-input');

        autocomplete = new google.maps.places.Autocomplete(input);
        autocomplete.bindTo('bounds', map);
        infowindow = new google.maps.InfoWindow();
        infowindowContent = document.getElementById('infowindow-content');
        infowindow.setContent(infowindowContent);
        marker = new google.maps.Marker({
          map: map
        });

        autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
        function selectFirstAddress (input) {
            google.maps.event.trigger(input, 'keydown', {keyCode:40});
            // google.maps.event.trigger(input, 'keydown', {keyCode:13});
        }
        angular.element(document).on('focusout', '#pac-input', function() {
            selectFirstAddress(this);
        });
    }

    $scope.fetchAutocomplete = function(){
        infowindow.close();
        marker.setVisible(false);
        var place = autocomplete.getPlace();
        if (!place.geometry) {
            // User entered the name of a Place that was not suggested and
            // pressed the Enter key, or the Place Details request failed.
            window.alert("No details available for input: '" + place.name + "'");
            return;
        }
        var lat = place.geometry.location.lat();
        var lng = place.geometry.location.lng();
        var address = place.formatted_address;
        $scope.lat = lat;
        $scope.lng = lng;
        // If the place has a geometry, then present it on a map.
        if (place.geometry.viewport) {
            map.fitBounds(place.geometry.viewport);
        } else {
            map.setCenter(place.geometry.location);
            map.setZoom(15);  // Why 17? Because it looks good.
        }
        marker.setPosition(place.geometry.location);
        marker.setVisible(true);

        infowindowContent.children['place-icon'].src = place.icon;
        infowindowContent.children['place-name'].textContent = place.name;
        infowindowContent.children['place-address'].textContent = address;
        var address_long_name =  place.address_components[0].long_name; 
        if(address_long_name == place.name){
            $scope.scheduler.address = address;     
        }else{
            $scope.scheduler.address = place.name  + ', '+ address;
        }

        $scope.$apply();
        infowindow.open(map, marker);
    }
    /* End */

    /* Functions is used to set place in map while edit or view on the basis of lat/long and address */
    $scope.getPlace = function(lat,lng,address) {
        var latlng = new google.maps.LatLng(lat, lng);
        var geocoder = new google.maps.Geocoder();
        geocoder.geocode({'latLng': latlng}, function(results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[1]) { 
                    marker = new google.maps.Marker({
                        position: latlng,
                        map: map
                    });

                    map.setCenter(marker.getPosition());
                    map.setZoom(15); 
                    $scope.lat = lat;
                    $scope.lng = lng;
                    infowindowContent.children['place-address'].textContent = address;
                    marker.setIcon(null);
                    infowindow.open(map, marker);
                }else {
                //handle error status accordingly
                }
            }
        })
    }
    /* End */

    /* Function is uesd to set the rating on the basis of rating value */
    $scope.testFunc = function(rating){
        var displatRating=[];
        for(var i=0;i<5;i++){
          if(rating-i>=1){
            displatRating.push({starType:'fa-star'}); 
          }else if(rating-i<1 && rating-i>0){
            displatRating.push({starType:'fa-star-half-o'}); 
          }else{
            displatRating.push({starType:'fa-star-o'}); 
          }
        }
        return displatRating;
    }
    /* End */

    /**
    * Function is used to open uib modal for edit current event and performing it's operations
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 18-Sep-2017
    **/
    $rootScope.editCurrentEvent = function(data){
        $uibModal.open({
            templateUrl: 'interpreter/modules/scheduler/views/viewBookingModal.html',
            size: "lg",
            controller: function($scope,$rootScope, $uibModalInstance) {
                /* Function is used to close the pop-up */
                $scope.closeuib = function() {
                    $uibModalInstance.close();
                }
                /* End */

                /* Functions and variables is used for map load and get lat/long on the basis of google place address bar selection */
                var infowindow,marker,infowindowContent,autocomplete,map;
                $scope.initMap = function () {
                    map = new google.maps.Map(document.getElementById('map'), {
                        center: {lat: 41.310726, lng: -72.929916},
                        zoom: 15,
                    });

                    var input = document.getElementById('pac-input');
                    autocomplete = new google.maps.places.Autocomplete(input);
                    autocomplete.bindTo('bounds', map);
                    infowindow = new google.maps.InfoWindow();
                    infowindowContent = document.getElementById('infowindow-content');
                    infowindow.setContent(infowindowContent);
                    marker = new google.maps.Marker({
                        map: map
                    });

                    setTimeout(function() {
                        google.maps.event.trigger(map, 'resize');
                    }, 1000);
                    autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
                    function selectFirstAddress (input) {
                        google.maps.event.trigger(input, 'keydown', {keyCode:40});
                        // google.maps.event.trigger(input, 'keydown', {keyCode:13});
                    }
                    angular.element(document).on('focusout', '#pac-input', function() {
                        selectFirstAddress(this);
                    });    
                }

                $scope.fetchAutocomplete = function(){
                    infowindow.close();
                    marker.setVisible(false);
                    var place = autocomplete.getPlace();
                    if (!place.geometry) {
                        // User entered the name of a Place that was not suggested and
                        // pressed the Enter key, or the Place Details request failed.
                        window.alert("No details available for input: '" + place.name + "'");
                        return;
                    }
                    var lat = place.geometry.location.lat();
                    var lng = place.geometry.location.lng();
                    var address = place.formatted_address;
                    $scope.lat = lat;
                    $scope.lng = lng;
                    // If the place has a geometry, then present it on a map.
                    if (place.geometry.viewport) {
                        map.fitBounds(place.geometry.viewport);
                    } else {
                        map.setCenter(place.geometry.location);
                        map.setZoom(15);  // Why 17? Because it looks good.
                    }
                    marker.setPosition(place.geometry.location);
                    marker.setVisible(true);

                    infowindowContent.children['place-icon'].src = place.icon;
                    infowindowContent.children['place-name'].textContent = place.name;
                    infowindowContent.children['place-address'].textContent = address;
                    var address_long_name =  place.address_components[0].long_name; 
                    if(address_long_name == place.name){
                        $scope.booking.address = address;     
                    }else{
                        $scope.booking.address = place.name  + ','+ address;
                    }
                    $scope.$apply();
                    infowindow.open(map, marker);
                }
                /* End */

                /* Functions is used to set place in map while edit or view on the basis of lat/long and address  */
                $scope.getPlace = function(lat,lng,address) {
                    var latlng = new google.maps.LatLng(lat, lng);
                    var geocoder = new google.maps.Geocoder();
                    geocoder.geocode({'latLng': latlng}, function(results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            if (results[1]) { 
                                marker = new google.maps.Marker({
                                    position: latlng,
                                    map: map
                                });

                                map.setCenter(marker.getPosition());
                                map.setZoom(15); 
                                $scope.lat = lat;
                                $scope.lng = lng;
                                infowindowContent.children['place-address'].textContent = address;
                                marker.setIcon(null);
                                infowindow.open(map, marker);
                            }else {
                                //handle error status accordingly
                            }
                        }
                    })
                }
                /* End */

                /* For data binding to edit modal on open this pop-up */
                $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                InterpreterSchedulerService.getBookingViewByBookingId().get({id:data._id},function(response, err){
                    if(response.status == 1){
                        var booking = response.data;
                        booking.start_date = new Date(moment(data.start_date));
                        booking.end_date = new Date(moment(data.end_date));
                        if(booking.client_id.profile_pic!='' && booking.client_id.profile_pic!=undefined){
                            $scope.userDefaultImage = booking.client_id.profile_pic;
                        }
                        $scope.booking = booking;
                        $scope.getPlace(booking.lat,booking.lng,booking.address);
                    }else{
                        $scope.booking = {};
                    }
                })
                /* End data binding modal */
            }
        });
    }
    /* End the edit modal pop-up */

    /* Function is used to view today and pending booking on click of tabular row */
    $scope.viewTodayAndPendingBooking = function(bookingObj, typeBooking) {
        $uibModal.open({
            templateUrl: 'interpreter/modules/scheduler/views/viewTodayAndPendingBookingModal.html',
            size: "lg",
            controller: function($scope,$rootScope, $uibModalInstance) {
                /* Function is used to close the pop-up */                
                $scope.closeuib = function() {
                    $uibModalInstance.close();
                }
                /* End */

                /* Functions and variables is used for map load and get lat/long on the basis of google place address bar selection */
                var infowindow,marker,infowindowContent,autocomplete,map;
                $scope.initMap = function () {

                    map = new google.maps.Map(document.getElementById('map'), {
                      center: {lat: 41.310726, lng: -72.929916},
                      zoom: 15,
                    });

                    var input = document.getElementById('pac-input');
                    autocomplete = new google.maps.places.Autocomplete(input);
                    autocomplete.bindTo('bounds', map);
                    infowindow = new google.maps.InfoWindow();
                    infowindowContent = document.getElementById('infowindow-content');
                    infowindow.setContent(infowindowContent);
                    marker = new google.maps.Marker({
                      map: map
                    });

                    setTimeout(function() {
                       google.maps.event.trigger(map, 'resize');
                    }, 1000);
                    autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
                    function selectFirstAddress (input) {
                        google.maps.event.trigger(input, 'keydown', {keyCode:40});
                        // google.maps.event.trigger(input, 'keydown', {keyCode:13});
                    }
                    angular.element(document).on('focusout', '#pac-input', function() {
                        selectFirstAddress(this);
                    });
                    
                }
                /* End */

                /* Functions is used to set place in map while edit or view on the basis of lat/long and address */
                $scope.getPlace = function(lat,lng,address) {
                    var latlng = new google.maps.LatLng(lat, lng);
                    var geocoder = new google.maps.Geocoder();
                    geocoder.geocode({'latLng': latlng}, function(results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            if (results[1]) { 
                                marker = new google.maps.Marker({
                                    position: latlng,
                                    map: map
                                });

                                map.setCenter(marker.getPosition());
                                map.setZoom(15); 
                                $scope.lat = lat;
                                $scope.lng = lng;
                                infowindowContent.children['place-address'].textContent = address;
                                marker.setIcon(null);
                                infowindow.open(map, marker);
                            }else {
                                //handle error status accordingly
                            }
                        }
                    })
                }
                /* End */

                /* Variables is used to bind the value to the pop-up */                
                var start_date = bookingObj.start_date;
                var end_date = bookingObj.end_date;
                var booking = bookingObj.bookingDetail;
                $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                $scope.userDefaultImage1 = "./../../../../assets/images/default-img.png";
                var repeating_interval; 
                if(booking.recurrence_rule == 'daily'){
                    $scope.repeating_interval = 'Day'
                }else if(booking.recurrence_rule == 'weekly' || booking.recurrence_rule == 'custom (weekly)'){
                    $scope.repeating_interval = 'Week'
                }else if(booking.recurrence_rule == 'monthly'){
                    $scope.repeating_interval = 'Month'
                }else{
                    $scope.repeating_interval = 'Year'
                }
                booking.start_date = new Date(moment(start_date));
                booking.end_date = new Date(moment(end_date));
                booking.todays_status = bookingObj.todays_status;
                if(typeBooking == 'pending'){
                    booking.status = 'Pending';
                }
                if(booking.clientInfo && booking.clientInfo.profile_pic!='' && booking.clientInfo.profile_pic!=undefined){
                    $scope.userDefaultImage = booking.clientInfo.profile_pic;
                }
                if(booking.interpreterInfo && booking.interpreterInfo.profile_pic!='' && booking.interpreterInfo.profile_pic!=undefined){
                    $scope.userDefaultImage1 = booking.interpreterInfo.profile_pic;
                }
                $scope.booking = booking;
                /* End */
                $scope.getPlace(booking.lat,booking.lng,booking.address);
            }
        });
    };
    /* End */

    /* Function is used to view completed booking on click of tabular row */
    $scope.viewCompletedBooking = function(bookingObj) {
        $uibModal.open({
            templateUrl: 'interpreter/modules/scheduler/views/viewCompletedBookingModal.html',
            size: "lg",
            controller: function($scope,$rootScope, $uibModalInstance) {
                /* Function is used to close the pop-up */                
                $scope.closeuib = function() {
                    $uibModalInstance.close();
                }
                /* End */

                /* Function is used to assigned star rating to stars */
                $scope.testFunc = function(rating){
                    var displatRating=[];
                    for(var i=0;i<5;i++){
                      if(rating-i>=1){
                        displatRating.push({starType:'fa-star'}); 
                      }else if(rating-i<1 && rating-i>0){
                        displatRating.push({starType:'fa-star-half-o'}); 
                      }else{
                        displatRating.push({starType:'fa-star-o'}); 
                      }
                    }
                    return displatRating;
                }
                /* End */

                /* Functions and variables is used for map load and get lat/long on the basis of google place address bar selection */
                var infowindow,marker,infowindowContent,autocomplete,map;
                $scope.initMap = function () {

                    map = new google.maps.Map(document.getElementById('map'), {
                      center: {lat: 41.310726, lng: -72.929916},
                      zoom: 15,
                    });

                    var input = document.getElementById('pac-input');
                    autocomplete = new google.maps.places.Autocomplete(input);
                    autocomplete.bindTo('bounds', map);
                    infowindow = new google.maps.InfoWindow();
                    infowindowContent = document.getElementById('infowindow-content');
                    infowindow.setContent(infowindowContent);
                    marker = new google.maps.Marker({
                      map: map
                    });

                    setTimeout(function() {
                       google.maps.event.trigger(map, 'resize');
                    }, 1000);
                    autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
                    function selectFirstAddress (input) {
                        google.maps.event.trigger(input, 'keydown', {keyCode:40});
                        // google.maps.event.trigger(input, 'keydown', {keyCode:13});
                    }
                    angular.element(document).on('focusout', '#pac-input', function() {
                        selectFirstAddress(this);
                    });
                    
                }
                /* End */

                /* Functions is used to set place in map while edit or view on the basis of lat/long and address */
                $scope.getPlace = function(lat,lng,address) {
                    var latlng = new google.maps.LatLng(lat, lng);
                    var geocoder = new google.maps.Geocoder();
                    geocoder.geocode({'latLng': latlng}, function(results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            if (results[1]) { 
                                marker = new google.maps.Marker({
                                    position: latlng,
                                    map: map
                                });

                                map.setCenter(marker.getPosition());
                                map.setZoom(15); 
                                $scope.lat = lat;
                                $scope.lng = lng;
                                infowindowContent.children['place-address'].textContent = address;
                                marker.setIcon(null);
                                infowindow.open(map, marker);
                            }else {
                                //handle error status accordingly
                            }
                        }
                    })
                }
                /* End */

                /* Variables is used to bind the value to the pop-up */      
                var ratingArr = [];             
                var start_date = bookingObj.check_in_date;
                var end_date = bookingObj.check_out_date;
                var booking = bookingObj.bookingInfo;
                $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                $scope.userDefaultImage1 = "./../../../../assets/images/default-img.png";
                var repeating_interval = ''; 
                if(booking.recurrence_rule == 'daily'){
                    $scope.repeating_interval = 'Day'
                }else if(booking.recurrence_rule == 'weekly' ||  booking.recurrence_rule == 'custom (weekly)'){
                    $scope.repeating_interval = 'Week'
                }else if(booking.recurrence_rule == 'monthly'){
                    $scope.repeating_interval = 'Month'
                }else if(booking.recurrence_rule == 'yearly'){
                    $scope.repeating_interval = 'Year'
                }
                booking.start_date = new Date(moment(start_date));
                booking.end_date = new Date(moment(end_date));
                booking.languageFromInfo = bookingObj.languageFromInfo;
                booking.languageIntoInfo = bookingObj.languageIntoInfo;
                booking.clientInfo = bookingObj.clientInfo;
                booking.interpreterInfo = bookingObj.interpreterInfo;
                booking.status = 'Completed';
                if(bookingObj.clientInfo && bookingObj.clientInfo.profile_pic!='' && bookingObj.clientInfo.profile_pic!=undefined){
                    $scope.userDefaultImage = bookingObj.clientInfo.profile_pic;
                }
                if(bookingObj.interpreterInfo && bookingObj.interpreterInfo.profile_pic!='' && bookingObj.interpreterInfo.profile_pic!=undefined){
                    $scope.userDefaultImage1 = bookingObj.interpreterInfo.profile_pic;
                }
                if(bookingObj.is_review_rating_done == true){
                    booking.review = bookingObj.review;
                    booking.is_review_rating_done = true;
                    $scope.ratingArr = $scope.testFunc(bookingObj.rating);
                }else{
                    booking.is_review_rating_done = false;
                    $scope.ratingArr = [];
                }
                $scope.booking = booking;
                $scope.getPlace(booking.lat,booking.lng,booking.address);
                /* End */
            }
        });
    };
    /* End */

    /**
    * Function is used to download paper voucher
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 30-Jan-2017
    **/
    $scope.downloadPaperVoucherByInterpreter = function(booking){
        var obj = {
            id: booking._id,
            start_date: booking.start_date,
            end_date: booking.end_date
        }
        InterpreterSchedulerService.downloadPaperVoucherByInterpreter().save(obj, function(response) {
            if (response.status == 1) {
                var fileName = response.data;
                console.log("fileName",fileName);
                $scope.str =  fileName.substring(17, 68);
                var fileURL = baseUrl+$scope.str;
                if(fileName !=undefined && fileName !=null && fileName !=''){
                    $window.open(fileURL); 
                }
            } else {
                $scope.str = {};
                logger.logError(response.message);
            }
        });
    }

}]);
