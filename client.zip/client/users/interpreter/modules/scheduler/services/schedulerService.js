"use strict"

angular.module("Scheduler")

.factory('InterpreterSchedulerService', ['$http', '$resource', function($http, $resource) {

    var getInterpreterBookingList = function() {
        return $resource(webservices.getInterpreterBookingList, null, {
            save: {
                method: 'POST'
            }
        });
    }    

    var getBookingViewByInterpreterId = function(id) {
        return $resource(webservices.getBookingViewByInterpreterId, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getBookingViewByBookingId = function(id) {
        return $resource(webservices.getBookingViewByBookingId, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getAllBookings = function() {
        return $resource(webservices.getAllBookings, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getTodaysInterpreterBookingList = function() {
        return $resource(webservices.getTodaysInterpreterBookingList, null, {
            save: {
                method: 'POST'
            }
        });
    } 

    var getInterpreterCompletedBooking = function() {
        return $resource(webservices.getInterpreterCompletedBooking, null, {
            save: {
                method: 'POST'
            }
        });
    } 

    var getInterpreterPendingBookings = function() {
        return $resource(webservices.getInterpreterPendingBookings, null, {
            save: {
                method: 'POST'
            }
        });
    } 

    var downloadPaperVoucherByInterpreter = function() {
        return $resource(webservices.downloadPaperVoucherByInterpreter, null, {
            save: {
                method: 'POST'
            }
        });
    }

    return {
        getInterpreterBookingList: getInterpreterBookingList,
        getBookingViewByInterpreterId: getBookingViewByInterpreterId,
        getBookingViewByBookingId: getBookingViewByBookingId,
        getAllBookings: getAllBookings,
        getTodaysInterpreterBookingList: getTodaysInterpreterBookingList,
        getInterpreterCompletedBooking: getInterpreterCompletedBooking,
        getInterpreterPendingBookings: getInterpreterPendingBookings,
        downloadPaperVoucherByInterpreter: downloadPaperVoucherByInterpreter
    }

}]);
