"use strict";

angular.module("InterpreterVideoCall")

interpreterApp.controller("interpreterVideoCallController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger', 'InterpreterVideoCallService', 'InterpreterBookingService', 'ngTableParams', 'ngTableParamsService', 'socket', 'CommonService', 'InterpreterSchedulerService',
    function ($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal, logger, InterpreterVideoCallService, InterpreterBookingService, ngTableParams, ngTableParamsService, socket, CommonService, InterpreterSchedulerService) {

        /**
        * Variable is used to active class on leftbar
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        // $rootScope.menuClient = ['agency_listClient', 'agency_addClient', 'agency_viewClient', 'agency_editClient'];
        $rootScope.menuVideoCall = ['interpreter_listVideoCall', 'interpreter_viewVideoCall', 'interpreter_videoCall'];
        $scope.user = CommonService.getUser();
        // console.log("$scope.user",$scope.user);
        /**
        * Function is used to get interpreter booking by id 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Nov-2017
        **/
        $scope.getInterpreterBookingById = function(){
            if($stateParams.id){
                $scope.interpreterPic = "./../../../../assets/images/default-img.png";
                $scope.clientPic = "./../../../../assets/images/default-img.png";
                InterpreterSchedulerService.getBookingViewByInterpreterId().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var booking = response.data;
                        booking.start_date = new Date(booking.start_date);
                        booking.end_date = new Date(booking.end_date);
                        if(booking.client_id.profile_pic!='' && booking.client_id.profile_pic!=undefined){
                            $scope.clientPic = booking.client_id.profile_pic;
                        }
                        if(booking.interpreter_id.profile_pic!='' && booking.interpreter_id.profile_pic!=undefined){
                            $scope.interpreterPic = booking.interpreter_id.profile_pic;
                        }
                        $scope.booking = booking;
                        // console.log("video call",$scope.booking);
                        $scope.createTokenAndSessionId(booking);
                    }
                })
            }
        }

        $scope.messageCommentShow = false;
        $scope.createTokenAndSessionId = function (booking) {
            if($stateParams.video_id != null){
                var videoCall = {
                    video_id: $stateParams.video_id
                }
                // console.log("in params");
            }else{
                var videoCall = {
                    booking_id: booking._id,
                    agency_id: booking.agency_id,
                    client_id: booking.client_id._id,
                    interpreter_id: booking.interpreter_id._id 
                }  
                // console.log("Not in params");  
            }
            InterpreterVideoCallService.createTokenAndSessionId().save(videoCall, function (response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message);
                    // console.log("sessionId and token in interpreter", response.data);

                    var apiKey = response.data.api_key;
                    var sessionId = response.data.sessionConnect.session_id;
                    var token = response.data.sessionConnect.token;
                    
                    // Handling all of our errors here by alerting them
                    function handleError(error) {
                        if (error) {
                            alert(error.message);
                        }
                    }
                    
                    function initializeSession() {
                        var session = OT.initSession(apiKey, sessionId);
                        $scope.session = session;
                        session.on("sessionDisconnected", function(event) {
                             logger.log("Call is disconnected");
                        });
                        // session.disconnect();
                        
                        // Subscribe to a newly created stream
                        session.on('streamCreated', function (event) {
                            session.subscribe(event.stream, 'subscriber', {
                                insertMode: 'append',
                                width: '100%',
                                height: '550px'
                            }, handleError);
                            $scope.messageCommentShow = true;
                            $scope.$apply();
                            angular.element(document.querySelector('#publisher')).addClass('publisher');
                            angular.element(document.querySelector('#publisher')).find('div:first').css({'width':'200px','height':'200px'});
                        });

                        // Create a publisher
                        var publisher = OT.initPublisher('publisher', {
                            insertMode: 'append',
                            width: '100%',
                            height: '550px'
                        }, handleError);

                        // Connect to the session
                        session.connect(token, function (error) {

                            // If the connection is successful, publish to the session
                            if (error) {
                                handleError(error);
                            } else {
                                angular.element(document.querySelector('#publisher')).removeClass('publisher');
                                angular.element(document.querySelector('#publisher')).find('div:first').css({'width':'100%','height':'550px'});
                                var videoData = {
                                    receiver_id: booking.client_id.user_id,
                                    sender_id: $scope.user.id,
                                    sender_first_name: booking.interpreter_id.first_name,
                                    sender_last_name: booking.interpreter_id.last_name,
                                    booking_id: booking._id,
                                    video_id: response.data.sessionConnect._id
                                }
                                $scope.videoData = videoData;
                                socket.emit('notify', {
                                    videoData: videoData,
                                    notificationType:'VIDEO_CALL_STARTED'
                                  },function(){alert("here")});
                                session.publish(publisher, handleError);       
                            }
                        });
                        socket.on('notify_disconnects',function(notification){
                            session.disconnect();
                            $state.go("interpreter_todays_booking");
                        })  
                    }
                    initializeSession();
                      
                }
            })
        }

        $scope.sessionDisconnectNow = function(){
            var session = $scope.session;
            session.disconnect();
            $state.go("interpreter_todays_booking");
            socket.emit('notify_disconnect', {
               videoData: $scope.videoData,
               notificationType:'VIDEO_CALL_DISCONNECT'
            },function(){alert("here")});
        }

        $rootScope.conversations = [];
        $scope.sendMessage = function(message){
            if(message!=undefined && message!=''){
                var dt = new Date();
                var h =  dt.getHours(), m = (dt.getMinutes()/10<1)? ("0"+dt.getMinutes()):dt.getMinutes();
                var checkInTime = (h > 12) ? (h-12 + ':' + m +' PM') : (h + ':' + m +' AM');
                $rootScope.conversations.push({
                    user: $scope.videoData.receiver_id,
                    messageTime: checkInTime,
                    message : message,
                    sentBy  : $scope.user.id
                });
                
                setTimeout(function(){
                    angular.element(document.querySelector('#video-session-chat')).scrollTop(document.querySelector('#video-session-chat').scrollHeight+50);
                },100);

                socket.emit('message', {
                    user: $scope.videoData.receiver_id,
                    message : message,
                    messageTime: checkInTime,
                    sentBy  : $scope.user.id,
                    booking_id: $scope.booking._id,
                    video_call_id: $scope.videoData.video_id,
                    client_id: $scope.booking.client_id._id,
                    interpreter_id: $scope.booking.interpreter_id._id
                  },function(){});

                $scope.message = '';
            }
        }

        $scope.messageKeyPress = function(keyEvent,message){
            if (keyEvent.which === 13){
                $scope.sendMessage(message);
            }
        }

        /**
        * Function is used to list  video call logs in interpreter by id
        * @access private
        * @return json
        * Created by ramiz
        * @smartData Enterprises (I) Ltd
        * Created Date 09-Jan-2018
        **/
        $scope.listVideoCallBookingByInterpreterId = function() {
            ngTableParamsService.set('', '', '', '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.videoBookingList = [];
                    InterpreterVideoCallService.listVideoCallBookingByInterpreterId().save($scope.paramUrl, function(response, err) {
                        if (response.status == 1) {
                            $scope.tableLoader = false;
                            $scope.videoBookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            $scope.videoBookingList = {}
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };

        // $scope.listVideoCallBookingByInterpreterIdSearching = function(searchTextField) {
        //     ngTableParamsService.set('', '', searchTextField, '');
        //     $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
        //         getData: function($defer, params) {
        //             ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
        //             $scope.paramUrl = params.url();
        //             $scope.tableLoader = true;
        //             // $scope.videoBookingList = [];
        //             InterpreterVideoCallService.listVideoCallBookingByInterpreterId().save($scope.paramUrl, function(response) {
        //                 if (response.status == 1) {
        //                     $scope.tableLoader = false;
        //                     $scope.videoBookingList = response.data;
        //                     var data = response.data;
        //                     $scope.totalCount = response.count;
        //                     params.total(response.count);
        //                     $defer.resolve(data);
        //                 } else {
        //                     $scope.videoBookingList = {}
        //                     logger.logError(response.message);
        //                 }
        //             });
        //         }
        //     })
        // };

        /**
        * Function is used to view the detail of video call in interpreter
        * @access private
        * @return json
        * Created by ramiz
        * @smartData Enterprises (I) Ltd
        * Created Date 09-Jan-2018
        **/
        $scope.viewVideoCall = function(videoBookingData) {
            $state.go('interpreter_viewVideoCall', {id:videoBookingData._id});
        };

        /**
        * Function is used to get the detail of video call by id in interpreter
        * @access private
        * @return json
        * Created by ramiz
        * @smartData Enterprises (I) Ltd
        * Created Date 09-Jan-2018
        **/
        $scope.getVideoCallDetailsByIdInInterpreter = function(){
            $scope.interpreterPic = "./../../../../assets/images/default-img.png";
            $scope.clientPic = "./../../../../assets/images/default-img.png";
            if($stateParams.id){
              InterpreterVideoCallService.getVideoCallDetailsByIdInInterpreter().get({id:$stateParams.id},function(response, err){
                if(response.status == 1){
                    var videoCallDetails = response.data.result;
                    if(videoCallDetails.client_id.profile_pic!='' && videoCallDetails.client_id.profile_pic!=undefined){
                        $scope.clientPic = videoCallDetails.client_id.profile_pic;
                    }
                    if(videoCallDetails.interpreter_id.profile_pic!='' && videoCallDetails.interpreter_id.profile_pic!=undefined){
                        $scope.interpreterPic = videoCallDetails.interpreter_id.profile_pic;
                    }
                    // var videoCallDetails = response.data.result;
                    $scope.videoCallDetails = videoCallDetails;
                    $scope.conversations = response.data.chatData;
                    for(var i=0; i<$scope.conversations.length;i++){
                        var dtt = moment($scope.conversations[i].createdAt)
                        var dt = new Date(dtt);
                        var h =  dt.getHours(), m = (dt.getMinutes()/10<1)? ("0"+dt.getMinutes()):dt.getMinutes();
                        var msgTime = (h > 12) ? (h-12 + ':' + m +' PM') : (h + ':' + m +' AM');
                        videoCallDetails.msgTime = msgTime;
                        console.log("dt", msgTime);
                    }
                    console.log("$scope.videoCallDetails", $scope.videoCallDetails);
                }else{
                    $scope.videoCallDetails= {};
                    $scope.conversations= {};
                    logger.logError(response.message);
                }
            })
          }
        };

        /**
        * Function is used to implement toggle class on chat messenger
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 10-Jan-2018
        **/
        $scope.toggleClassChat = function() {
            angular.element(document.querySelectorAll('div')).toggleClass('expanded');
        };
    } 
        
]);
