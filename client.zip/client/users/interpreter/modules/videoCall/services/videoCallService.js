"use strict"

angular.module("InterpreterVideoCall")

.factory('InterpreterVideoCallService', ['$http', '$resource', function($http, $resource) {
 
    var listAgencyClients = function() {
        return $resource(webservices.listAgencyClients, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteAgencyClient = function(id) {
        return $resource(webservices.deleteAgencyClient, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }


    var addAgencyClients = function() {
        return $resource(webservices.addAgencyClients, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAgencyClientById = function(id) {
        return $resource(webservices.getAgencyClientById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var updateAgencyClient = function() {
        return $resource(webservices.updateAgencyClient, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var changeClientStatus = function() {
        return $resource(webservices.changeClientStatus, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var createTokenAndSessionId = function() {
        return $resource(webservices.createTokenAndSessionId, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var senderStartedVideoCall = function() {
        return $resource(webservices.senderStartedVideoCall, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var listVideoCallBookingByInterpreterId = function() {
        return $resource(webservices.listVideoCallBookingByInterpreterId, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getVideoCallDetailsByIdInInterpreter = function(id) {
        return $resource(webservices.getVideoCallDetailsByIdInInterpreter, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }


    return {
        listAgencyClients: listAgencyClients,
        deleteAgencyClient: deleteAgencyClient,
        addAgencyClients: addAgencyClients,
        getAgencyClientById: getAgencyClientById,
        updateAgencyClient: updateAgencyClient,
        changeClientStatus: changeClientStatus,

        createTokenAndSessionId: createTokenAndSessionId,
        senderStartedVideoCall: senderStartedVideoCall,
        listVideoCallBookingByInterpreterId: listVideoCallBookingByInterpreterId,
        getVideoCallDetailsByIdInInterpreter: getVideoCallDetailsByIdInInterpreter

    }

}]);
