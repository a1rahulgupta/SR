"use strict"

angular.module("InterpreterScheduling")

.factory('InterpreterSchedulingService', ['$http', '$resource', function($http, $resource) {

        var getInterpreterSchedulingDetails = function() {
            return $resource(webservices.getInterpreterSchedulingDetails, null, {
                post: {
                    method: 'POST'
                }
            });
        }

        var addInterpreterLeave = function() {
            return $resource(webservices.addInterpreterLeave, null, {
                post: {
                    method: 'POST'
                }
            });
        }

        var updateInterpreterLeave = function() {
            return $resource(webservices.updateInterpreterLeave, null, {
                post: {
                    method: 'POST'
                }
            });
        }

        var getBookingDetailForInterpreterCalendar = function() {
            return $resource(webservices.getBookingDetailForInterpreterCalendar, null, {
                get: {
                    method: 'POST'
                }
            });
        }

        var getInterpreterBookingViewById = function(id) {
        return $resource(webservices.getInterpreterBookingViewById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }
    
    
    return {
        getInterpreterSchedulingDetails:getInterpreterSchedulingDetails,
        addInterpreterLeave:addInterpreterLeave,
        updateInterpreterLeave:updateInterpreterLeave,
        getBookingDetailForInterpreterCalendar:getBookingDetailForInterpreterCalendar,
        getInterpreterBookingViewById:getInterpreterBookingViewById
    }

}]);
