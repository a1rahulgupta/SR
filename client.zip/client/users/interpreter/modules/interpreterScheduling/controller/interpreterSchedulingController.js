"use strict";

angular.module("InterpreterScheduling")

interpreterApp.controller("interpreterSchedulingController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger','InterpreterSchedulingService', 'ngTableParams', 'ngTableParamsService', 'socket', 'CommonService',
    function ($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal, logger, InterpreterSchedulingService, ngTableParams, ngTableParamsService, socket, CommonService) {

        /**
        * Variable is used to active class on leftbar
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $rootScope.menuInterpreterScheduling = ['interpreter_calendarScheduling'];

        /**
        * Function is used show status of interpreter in calendar
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 26-Dec-2017
        **/
        $scope.eventSources = [
              function(start, end, timezone, callback){
                InterpreterSchedulingService.getInterpreterSchedulingDetails().post({startDate: start._d, endDate: end._d}, function(response) {
                  if(response.status == 1){
                    var events = []; 
                    $scope.interpreterSchedulingList = response.data;
                    angular.forEach($scope.interpreterSchedulingList,function(value, index) {
                      if(moment(value.startDate).format('MM-DD-YYYY') == moment().format('MM-DD-YYYY')){
                        if (value.status) {
                          var data = {                                                  
                                  title: 'Working',
                          }
                          $scope.setAvailabilityOnClick(data);
                        }else{
                          var data = {                                                  
                                  title: 'Not Working', 
                          }
                          $scope.setAvailabilityOnClick(data);

                        }
                      }
                      if(value.status == true) {
                        events.push({
                            end: new Date(value.endDate),
                            start: new Date(value.startDate),
                            title: 'Working',
                            color: '#167F45',
                        });
                      } else if (value.leave_status == true){
                          events.push({
                              end: new Date(value.endDate), 
                              start: new Date(value.startDate),
                              id: value.id, 
                              title: 'On leave',
                              color: '#F35321',
                          });
                      } else{
                          events.push({
                              end: new Date(value.endDate), 
                              start: new Date(value.startDate), 
                              title: 'Not Working',
                              color: '#D40C00',
                          });
                      }
                    });
                    callback(events);
                    $scope.calendarLoader = false;
                  }
                  // if(response.status == 1){
                  //   var events = []; 
                  //   $scope.interpreterSchedulingList = response.data;
                  //   angular.forEach($scope.interpreterSchedulingList,function(value, index) {
                  //     if(value.status == true) {
                  //       events.push({
                  //           end: new Date(value.endDate),
                  //           start: new Date(value.startDate),
                  //           title: 'Working',
                  //           color: '#167F45',
                  //       });
                  //     } else if (value.leave_status == true){
                  //         events.push({
                  //             end: new Date(value.endDate), 
                  //             start: new Date(value.startDate), 
                  //             title: 'On leave',
                  //             color: '#F35321',
                  //         });
                  //     } else{
                  //         events.push({
                  //             end: new Date(value.endDate), 
                  //             start: new Date(value.startDate), 
                  //             title: 'Not Working',
                  //             color: '#D40C00',
                  //         });
                  //     }
                  //   });
                  //   callback(events);
                  //   $scope.calendarLoader = false;
                  // }
                })
              }
        ];

        $rootScope.getInterpreterSchedulingDetails = function() {
          var events = [];
          $scope.uiConfig = {
            calendar: {
             
              height: 500,
              editable: true,
              displayEventTime: false,
              ignoreTimezone: false,
              header: {
                  left: 'prev',
                  center: 'title',
                  right: 'next' //'month basicWeek basicDay agendaWeek agendaDay'
              },
              eventClick: function(event, description) { 
                $scope.getBookingDetailForInterpreterCalendar(event.start._d);
                if(event.title=='Not Working'||event.title=='Working' || event.title=='On leave'){
                  $scope.currentDate = '';
                  // $scope.setAvailabilityOnClick(event);
                }
                else{
                  // $scope.alertEventOnClick(event);
                }
              }
            }
          }
        }

        $scope.currentDate='';
        $scope.switchdesabled =  false;
        $scope.setAvailabilityOnClick = function(data) {
          $scope.eventData = data;
          $scope.switchdesabled =  false;
          if(typeof data['_start'] == "undefined"){
            $scope.currentDate = new Date();
          }else{
            $scope.currentDate = data._start._d;
          }
          $scope.serviceprovider = {
            isAvailable: true
          }
          if(data.title !='Not Working'){             
            if(data.title==='Working'){
              $scope.serviceprovider.isAvailable=true;
            }
            else{
              $scope.serviceprovider.isAvailable=false; 
            }
          }else{
            $scope.serviceprovider.isAvailable=false;
            $scope.switchdesabled =  true;
          }
        }

        $scope.setSchedule = function(formData){
            var data = $scope.eventData;
            console.log("eventData", data);
            InterpreterSchedulingService.getBookingDetailForInterpreterCalendar().get({}, function(response) {
              console.log("INSIDE getBookingDetailForInterpreterCalendar", $scope.scheduleData);
            })
            if(data.title == 'Working'){
                  bootbox.confirm('Are you sure you want to change availablity for date '+moment($scope.currentDate).format('DD-MM-YYYY')+  ' ?', function(r) {
                      if (r) {
                        if(formData.isAvailable){ 
                          $scope.scheduleData = {
                            'status': true,
                            'date': $scope.currentDate
                          };
                        }else{
                          $scope.scheduleData = {
                            'status': false,
                            'date': $scope.currentDate
                          };
                        }
                    InterpreterSchedulingService.addInterpreterLeave().save($scope.scheduleData, function(response) {
                        $scope.disabled = false;
                        $scope.loader = false;
                        if (response.status == 1) {
                            logger.logSuccess(response.message);
                            $state.reload();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                  }else{
                    $state.reload();
                  }
               
              })
                } else {
                      bootbox.confirm('Are you sure you want to change availablity for date '+moment($scope.currentDate).format('DD-MM-YYYY')+  ' ?', function(r) {
                          if (r) {
                            if(formData.isAvailable){ 
                              $scope.scheduleData = {
                                'status': true,
                                'date': $scope.currentDate
                              };
                            }else{
                              $scope.scheduleData = {
                                'status': false,
                                'date': $scope.currentDate
                              };
                            }

                            // alert("Hello");
                        InterpreterSchedulingService.updateInterpreterLeave().save({id: data.id}, function(response) {
                            // $scope.disabled = false;
                            // $scope.loader = false;

                            if (response.status == 1) {
                                logger.logSuccess(response.message);
                                $state.reload();
                            } else {
                                logger.logError(response.message);
                                // $scope.cancelAction();
                            }
                        });
                      }else{
                        $state.reload();
                      }
                   
                  })
                }
            
        }

      $scope.getBookingDetailForInterpreterCalendar = function(startDate){
          if(!startDate){
            startDate = new Date();
            startDate = moment(startDate).format();
          }
          $scope.interpreterBookingDetails = [];
          InterpreterSchedulingService.getBookingDetailForInterpreterCalendar().get({startDate: startDate }, function(response) {
              if (response.status == 1) {
                  $scope.interpreterBookingList = response.data;
                  $scope.interpreterBookingList.forEach(function(value, index) {
                    $scope.interpreterBookingDetails.push(value)
                  });
              }
          })
        }

        $scope.viewInterpreterBookingModal = function(data) {
              $uibModal.open({
                  templateUrl: 'interpreter/modules/interpreterScheduling/views/viewInterpreterBookingModal.html',
                  size: 'lg',
                  controller: function($scope,$rootScope, $uibModalInstance){
                    $scope.closeuib = function() {
                        $uibModalInstance.close('a');
                    }

                    InterpreterSchedulingService.getInterpreterBookingViewById().get({id:data},function(response, err){
                        if(response.status == 1){
                            var currentDate = new Date();   
                            var booking = response.data;
                            booking.booking_from = new Date(booking.booking_from.split('.000Z')[0]);
                            booking.booking_to = new Date(booking.booking_to.split('.000Z')[0]);
                            var tmpTime = CommonService.convertTo24Format(booking.working_from);
                            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                            tmpTime = CommonService.convertTo24Format(booking.working_to);
                            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                            $scope.booking = booking; 
                            $scope.getPlace(booking.lat,booking.lng,booking.address);
                        }else{
                            $scope.booking = {};
                        }
                    })

                var infowindow,marker,infowindowContent,autocomplete,map;
                $scope.initMap = function () {
                    map = new google.maps.Map(document.getElementById('map'), {
                      center: {lat: 41.310726, lng: -72.929916},
                      zoom: 15,
                    });

                    var input = document.getElementById('pac-input');
                    autocomplete = new google.maps.places.Autocomplete(input);
                    autocomplete.bindTo('bounds', map);
                    infowindow = new google.maps.InfoWindow();
                    infowindowContent = document.getElementById('infowindow-content');
                    infowindow.setContent(infowindowContent);
                    marker = new google.maps.Marker({
                      map: map
                    });

                    setTimeout(function() {
                       google.maps.event.trigger(map, 'resize');
                    }, 1000);

                    autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
                    function selectFirstAddress (input) {
                        google.maps.event.trigger(input, 'keydown', {keyCode:40});
                        google.maps.event.trigger(input, 'keydown', {keyCode:13});
                    }
                    angular.element(document).on('focusout', '#pac-input', function() {
                        selectFirstAddress(this);
                    });
                     
                  }

                  $scope.fetchAutocomplete = function(){
                      infowindow.close();
                      marker.setVisible(false);
                      var place = autocomplete.getPlace();
                      if (!place.geometry) {
                        // User entered the name of a Place that was not suggested and
                        // pressed the Enter key, or the Place Details request failed.
                        window.alert("No details available for input: '" + place.name + "'");
                        return;
                      }
                      var lat = place.geometry.location.lat();
                      var lng = place.geometry.location.lng();
                      var address = place.formatted_address;
                      $scope.lat = lat;
                      $scope.lng = lng;  
                      // If the place has a geometry, then present it on a map.
                      if (place.geometry.viewport) {
                        map.fitBounds(place.geometry.viewport);
                      } else {
                        map.setCenter(place.geometry.location);
                        map.setZoom(15);  // Why 17? Because it looks good.
                      }
                      marker.setPosition(place.geometry.location);
                      marker.setVisible(true);

                      infowindowContent.children['place-icon'].src = place.icon;
                      infowindowContent.children['place-name'].textContent = place.name;

                      infowindowContent.children['place-address'].textContent = address;
                      infowindow.open(map, marker);

                     
                      
                  }
                  $scope.getPlace = function(lat,lng,address) {
                      var latlng = new google.maps.LatLng(lat, lng);
                      var geocoder = new google.maps.Geocoder();
                      geocoder.geocode({'latLng': latlng}, function(results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                          if (results[1]) { 
                            marker = new google.maps.Marker({
                                position: latlng,
                                map: map
                            });

                            map.setCenter(marker.getPosition());
                            map.setZoom(15); 
                            $scope.lat = lat;
                            $scope.lng = lng;
                            infowindowContent.children['place-address'].textContent = address;
                            marker.setIcon(null);
                            infowindow.open(map, marker);
                          }
                          else {
                            //handle error status accordingly
                          }
                        }
                      })
                    }
                  }
              });
          };

    }    
]);
