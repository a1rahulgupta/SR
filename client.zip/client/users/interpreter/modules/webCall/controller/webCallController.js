"use strict";

angular.module("InterpreterWebCall")

interpreterApp.controller("interpreterWebCallController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger', 'InterpreterWebCallService','InterpreterBookingService', 'ngTableParams', 'ngTableParamsService', 'InterpreterSchedulerService',
    function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal, logger, InterpreterWebCallService, InterpreterBookingService, ngTableParams, ngTableParamsService, InterpreterSchedulerService) {
               
        /**
        * Variable is used to active class on leftbar
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $rootScope.menuInterpreterWebCall = ['interpreter_webCall'];
        
        /**
        * Function is used to get client booking by id 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Nov-2017
        **/
        $scope.getInterpreterBookingById = function(){
            if($stateParams.id){
                $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                InterpreterSchedulerService.getBookingViewByInterpreterId().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var booking = response.data;
                        booking.start_date = new Date(moment(booking.start_date));
                        booking.end_date = new Date(moment(booking.end_date));
                        if(booking.client_id.profile_pic!='' && booking.client_id.profile_pic!=undefined){
                            $scope.userDefaultImage = booking.client_id.profile_pic;
                        }
                        $scope.booking = booking;
                        $scope.webCallToInterpreter(booking.client_id.mobile_no);
                    }
                })
            }
            }

        /**
        * Function is used to disconnect web phone call
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Nov-2017
        **/
        $scope.endWebCall = function(){
            Twilio.Device.disconnectAll();
            $state.go('interpreter_todays_booking');
        }

         /**
        * Function and variable is used to make web phone call
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Nov-2017
        **/
        $scope.twilioCall={};
        $scope.webCallToInterpreter = function(phoneNo){
            if($state.params.id){
                InterpreterWebCallService.webCallToInterpreter().save({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var params = {"phoneNumber": phoneNo};
                        // console.log("sadfsd");
                        var connection = Twilio.Device.connect(params);     
                        // Twilio.Device.incoming(function (conn) {
                        //   console.log('Incoming connection from ' + conn.parameters.From);
                        //   // accept the incoming connection and start two-way audio
                        //   conn.accept();
                        // });
                        // do awesome ui stuff here
                        // $('#call-status').text("you're on a call!");       
                    }else{
                        logger.logError(response.message);
                    }
                })
            }
            
        }

        $scope.$on('webCallDisconnected', function (event, args) {
            logger.log("Call is disconnected");
            $state.go('interpreter_todays_booking');

         });

        $scope.$on('webCallConnected', function (event, args) {
            var connection = args.connectionObj;
             if ("phoneNumber" in connection.message) {
                logger.log("Call is connecting...");
            }
        });

                
    }

]);
