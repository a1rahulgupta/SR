"use strict";

angular.module("Authentication", []);
angular.module("Home", []);
angular.module("Dashboard", []);
angular.module("Header", []);
angular.module("LeftBar", []);
angular.module("Booking", []);
angular.module("Interpreter", []);
angular.module("Client", []);
angular.module("Invoice", []);
angular.module("InterpreterBooking", []);
angular.module("InterpreterDashboard", []);
angular.module("InterpreterHeader", []);
angular.module("InterpreterLeftBar", []);
angular.module("ClientDashboard", []);
angular.module("ClientHeader", []);
angular.module("ClientLeftBar", []);
angular.module("ClientBooking", []);
angular.module("WebCall", []);
angular.module("InterpreterWebCall", []);
angular.module("InterpreterVideoCall", []);
angular.module("VideoCall", []);
angular.module("InterpreterManualCheck", []);
angular.module("InterpreterCheckIn", []);
angular.module("ClientComplaint", []);
angular.module("AgencyComplaint", []);
angular.module("Report", []);
angular.module("InterpreterScheduling", []);
angular.module("Scheduler", []);
angular.module("InterpreterScheduler", []);
angular.module("ClientScheduler", []);

angular.module("InviteUser", []); //stripe 
angular.module("ConnectProfile", []); //ConnectProfiles 

var interpreterApp = angular.module('interpreterApp', ['ui.router', 'ui.bootstrap',
    'ngRoute', 'ngStorage', 'ngTable', 'ngResource', 'oc.lazyLoad',
    'Authentication', 'Home', 'Dashboard', 'Header', 
    'Booking','ui.calendar','Interpreter','ngImgCrop','isteven-multi-select','Client','Invoice',
    'InterpreterBooking','InterpreterDashboard','InterpreterHeader','InterpreterLeftBar','ClientHeader',
    'ClientDashboard', 'ClientLeftBar', 'ClientBooking', 'kendo.directives','WebCall', 'InterpreterWebCall',
    'InterpreterVideoCall','InterpreterManualCheck','InterpreterCheckIn','ClientComplaint','AgencyComplaint',
    'Report','VideoCall','blockUI','geolocation','720kb.tooltips','ngMap', 'ngSanitize','ngIntlTelInput','InterpreterScheduling',
    'yaru22.angular-timeago','ui.select', 'Scheduler','ui.bootstrap.carousel', 'InterpreterScheduler', 'ClientScheduler',
])

.factory("CommonService", ["$http", "$resource", "$rootScope", function($http, $resource, $rootScope) {
        
        var user = {};
        var getUser = function() {
            return user;
        };
        var setUser = function(userData) {
            user = '';
            user = userData;
            return user;
        };

        var convertTo24Format = function(timeStr){
            var tmp=timeStr;
            var tmpArr = tmp.split(':');
            var t = tmpArr[1].split(' ')[1];
            var hour= tmpArr[0].trim();
            var minute= tmpArr[1].split(' ')[0];
            if(t=='PM'){
                if(hour!=12){
                    hour = parseInt(hour) + 12;
                }
            } else if(t=='AM'){
                if(hour==12){
                    hour=0;
                }
            }
            return { 'hour': hour, 'minute': minute};
        };

        return {
            getUser: getUser,
            setUser: setUser,
            convertTo24Format: convertTo24Format
        }

    }])
    .factory('socket', function ($rootScope) {
        var socket = io.connect();
        return {
          on: function (eventName, callback) {
            socket.on(eventName, function () {  
              var args = arguments;
              $rootScope.$apply(function () {
                callback.apply(socket, args);
              });
            });
          },
          emit: function (eventName, data, callback) {
            socket.emit(eventName, data, function () {
              var args = arguments;
              $rootScope.$apply(function () {
                if (callback) {
                  callback.apply(socket, args);
                }
              });
            })
          }
        };
      })
    .config(["blockUIConfig", function (blockUIConfig) {
        blockUIConfig.requestFilter = function (config) {
            //Perform a global, case-insensitive search on the request url for 'noblockui' ...
            if (config.url.match(/checklogin/gi) || config.url.match(/getPermissionById/gi)) {
                // console.log("Yes");
                return false; // ... don't block it.
                // return true; // ... block it.
            }
        };
    }])
    .config(['$routeProvider', '$httpProvider', '$locationProvider', '$stateProvider', '$urlRouterProvider', '$injector','timeAgoSettings', function(
        $routeProvider, $httpProvider, $locationProvider, $stateProvider, $urlRouterProvider) {
        $httpProvider.interceptors.push(function($q, $location, $window, $rootScope, $localStorage, $injector, timeAgoSettings) {
            // angular.config(function (timeAgoSettings) {
            // timeAgoSettings.overrideLang = 'es_LA';
            var oneDay = 60*60*24;
                timeAgoSettings.fullDateAfterSeconds = oneDay;
            // });
            var numLoadings = 0;
            return {
                request: function(config) {
                    config.headers = config.headers || {};
                    config.headers['authorization'] = 'Bearer ' + $localStorage.token;
                    // config.headers['client-type'] = 'browser'; // this is used to detect the request is from the browser
                    return config;
                },
                response: function(response) {
                    if (response.status == 0) {
                        delete $localStorage.token;
                        delete $localStorage.user;
                        delete $localStorage.userLoggedIn;
                        $location.path('/login'); // handle the case where the user is not authenticated
                    }else if (response.status == 3) {
                        // $location.path('/login'); // handle the case where the user is not authenticated
                        bootbox.alert(response.data.message);
                    }       
                    return response || $q.when(response);           
                },
                responseError: function(response) {                    
                    return $q.reject(response);
                }
            };
        });
        var checkLoggedin = function($q, $timeout, $http, $location, $rootScope, $state, $localStorage, CommonService) {
            var deferred = $q.defer(); // Initialize a new promise
            // Make an AJAX call to check if the user is logged in
            $http.get('/api/v1/user/checklogin').success(function(response) { // Authenticated

                var user = response.user;
                if (response.status == '1') {
                    $rootScope.userLoggedIn = true;
                    var user = response.user;
                    console.log("user in application",user);
                    CommonService.setUser(user); // this will set the user in the session to the application model
                    switch(user.role){
                        case "agency_admin":
                        case "agency_staff":
                            $rootScope.CurrPath = 'agency_dashboard';
                            $state.go('agency_dashboard');
                        break;
                        case "interpreter":
                            $rootScope.CurrPath = 'interpreter_dashboard';                            
                            $state.go('interpreter_dashboard');
                        break;
                        case "client":
                            $rootScope.CurrPath = 'client_dashboard';                        
                            $state.go('client_dashboard');
                        break;
                    }    
                } else { // Not Authenticated
                    $rootScope.userLoggedIn = false;
                    $timeout(function() {
                        deferred.resolve();
                    }, 0);
                }
            }).error(function(error) {
                $rootScope.userLoggedIn = false;
                $timeout(function() {
                    deferred.resolve();
                }, 0);
            });
            return deferred.promise;
        };
        var checkLoggedout = function() {
            return ['$q', '$timeout', '$http', '$location', '$rootScope', '$state', 'CommonService','$localStorage',
                function($q, $timeout, $http, $location, $rootScope, $state, CommonService, $localStorage) {

                    var deferred = $q.defer(); // Initialize a new promise 
                    // Make an AJAX call to check if the user is logged in
                    var user_role  = $localStorage.user;
                    // console.log("checlllll",user);
                    $http.get('/api/v1/user/checklogin').success(function(response) {
                        if (response.status == '1') { // Authenticated
                            // console.log("Here it comes");
                            $rootScope.userLoggedIn = true;
                            var user = response.user; 
                            // console.log("user in application 1",user);
                            CommonService.setUser(user); 
                            switch(user.role){
                                case "agency_admin":
                                case "agency_staff":
                                    var stateName = $rootScope.CurrPath;
                                    if(/^agency_/.test(stateName)){
                                        $timeout(deferred.resolve, 0);
                                    }else{
                                        $state.go('agency_dashboard');
                                        $rootScope.CurrPath = 'agency_dashboard';
                                    }
                                break;
                                case "interpreter":
                                    var stateName = $rootScope.CurrPath;
                                    if(/^interpreter_/.test(stateName)){
                                        $timeout(deferred.resolve, 0);
                                    }else{
                                        $state.go('interpreter_dashboard');
                                        $rootScope.CurrPath = 'interpreter_dashboard';
                                    }
                                break;
                                case "client":
                                    var stateName = $rootScope.CurrPath;
                                    if(/^client_/.test(stateName)){
                                        $timeout(deferred.resolve, 0);
                                    }else{
                                        $state.go('client_dashboard');
                                        $rootScope.CurrPath = 'client_dashboard';
                                    }
                                break;    
                            }
                        } else { // Not Authenticated
                            
                            $rootScope.userLoggedIn = false;
                            $timeout(function() {
                                deferred.resolve();
                            }, 0);
                            $state.go('login');
                        }
                    }).error(function(error) {
                        $rootScope.userLoggedIn = false;
                        $timeout(function() {
                            deferred.resolve();
                        }, 0);
                        $state.go('login');
                    });
                    return deferred.promise;
                }
            ];
        };

        $urlRouterProvider.otherwise('/login');

        $stateProvider
            .state('login', {
                url: '/login',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/login.html',
                        controller: "loginController"
                    }
                },
                params: { 'email': null },
                data: {
                    isAuthenticate: false 
                },
                resolve: {
                    loggedin: checkLoggedin
                }
            })

            .state('home', {
                url: '/home',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/home.html',
                        controller: "loginController"
                    }
                },
                data: {
                    isAuthenticate: false
                },
                resolve: {
                    loggedin: checkLoggedin
                }
            })

            .state('404', {
                url: '/page-not-found',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/404.html',
                        controller: "loginController"
                    }
                }
            })

            .state('forgot-password', {
                url: '/forgotPassword',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/forgot-password.html',
                        controller: "loginController"
                    }
                },
                params: { 'email': null },
                data: {
                    isAuthenticate: false
                },
                resolve: {
                    loggedin: checkLoggedin
                }
            })

            .state('forgot_Password', {
                url: '/forgot_password/:forgot_token',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/forgot-password-page.html',
                        controller: "loginController"
                    }
                },
                params: { 'email': null },
                data: {
                    // isAuthe  nticate: false
                },
                resolve: {
                    // loggedin: checkLoggedin
                }
            })

            .state('contact', {
                url: '/contact',
                views: {
                    'beforeHeader': {
                        templateUrl: 'agency/modules/home/views/header.html'
                    },
                    'beforeContent': {
                        templateUrl: 'agency/modules/home/views/contact.html',
                        controller: "homeController"
                    },
                    'beforeFooter': {
                        templateUrl: 'agency/modules/home/views/footer.html',
                        controller: "homeController"
                    }
                },
                data: { },
                resolve: { }
            })
            .state('about', {
                url: '/about',
                views: {
                    'beforeHeader': {
                        templateUrl: 'agency/modules/home/views/header.html'
                    },
                    'beforeContent': {
                        templateUrl: 'agency/modules/home/views/about.html',
                        controller: "homeController"
                    },
                    'beforeFooter': {
                        templateUrl: 'agency/modules/home/views/footer.html',
                        controller: "homeController"
                    }
                },
                data: { },
                resolve: { }
            })
        
            .state('complete-registration', {
                url: '/complete-registration/:token',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/complete-registration.html',
                        controller: "loginController"
                    }
                },
                data: {
                    // isAuthenticate: false
                },
                resolve: {
                    // loggedin: checkLoggedin,
                    // loadPlugin: function($ocLazyLoad) {
                    //     return $ocLazyLoad.load([
                    //         '/users/modules/authentication/controller/authenticateController.js',
                    //         '/users/modules/authentication/services/authenticateService.js',
                    //         '/assets/js/stripe-v3.js'
                    //     ]);
                    // }
                }
            })
            .state('cancel-invitation', {
                url: '/cancel-invitation',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/cancel-invitation.html',
                        controller: "loginController"
                    }
                },
                data: {
                    // isAuthenticate: false
                },
                resolve: {
                    // loggedin: checkLoggedin,
                    // loadPlugin: function($ocLazyLoad) {
                    //     return $ocLazyLoad.load([
                    //         '/users/modules/authentication/controller/authenticateController.js',
                    //         '/users/modules/authentication/services/authenticateService.js',
                    //         '/assets/js/stripe-v3.js'
                    //     ]);
                    // }
                }
            })
            .state('verify-email', {
                url: '/verify-email',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/verify-email.html',
                        controller: "loginController"
                    }
                },
                data: {},
                resolve: {}
            })
            .state('forgot_password', {
                url: '/forgot-password',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/forgot-password.html',
                        controller: "loginController"
                    }
                },
                data: {},
                resolve: {
                    // loggedin: checkLoggedin,
                    // loadPlugin: function($ocLazyLoad) {
                    //     return $ocLazyLoad.load([
                    //         '/users/modules/authentication/controller/authenticateController.js',
                    //         '/users/modules/authentication/services/authenticateService.js',
                    //     ]);
                    // }
                }
            })
            .state('reset_password', {
                url: '/reset-password/:reset_key',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/reset-password.html',
                        controller: "loginController"
                    }
                },
                data: {},
                resolve: {
                    // loggedin: checkLoggedin,
                    // loadPlugin: function($ocLazyLoad) {
                    //     return $ocLazyLoad.load([
                    //         '/users/modules/authentication/controller/authenticateController.js',
                    //         '/users/modules/authentication/services/authenticateService.js',
                    //     ]);
                    // }
                }
            })
            .state('verifying_link', {
                url: '/verifying-link',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/verifing-link.html',
                        controller: "loginController"
                    }
                },
                data: {},
                resolve: {
                    // loadPlugin: function($ocLazyLoad) {
                    //     return $ocLazyLoad.load([
                    //         '/users/modules/authentication/controller/authenticateController.js',
                    //         '/users/modules/authentication/services/authenticateService.js',
                    //     ]);
                    // }
                }
            })
            .state('agency_dashboard', {
                url: '/dashboard',
                views: {
                    'header': {
                        templateUrl: "agency/modules/dashboard/views/header.html",
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/dashboard/views/home.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_profile', {
                url: '/agencyProfile',
                views: {
                    'header': {
                        templateUrl: "agency/modules/dashboard/views/header.html",
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/dashboard/views/agencyProfile.html',
                        controller: "dashboardController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            // .state('404', {
            //     url: '/page-not-found',
            //     views: {
            //         'content': {
            //             templateUrl: 'agency/modules/home/views/404.html',
            //         },
            //     },
            // })
            
            //Start Interpreter
            .state('agency_registration', {
                url: '/signup',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/agencyRegistration.html',
                        controller: "loginController"
                    }
                },
                data: {
                    isAuthenticate: false
                },
                resolve: {
                    loggedin: checkLoggedin
                }
            })

            .state('agency_subscription', {
                url: '/subscription',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/agencySubscription.html',
                        controller: "loginController"
                    }
                },
                data: {
                    isAuthenticate: false
                },
                resolve: {
                    loggedin: checkLoggedin
                }
            })
            .state('agency_carddetails', {
                url: '/carddetails',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/cardDetails.html',
                        controller: "loginController"
                    }
                },
                data: {
                    isAuthenticate: false
                },
                resolve: {
                    loggedin: checkLoggedin
                }
            })

            .state('agency_listBooking', {
                url: '/listBooking',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/booking/views/listBooking.html',
                        controller: "bookingController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_addBooking', {
                url: '/addBooking',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/booking/views/addBooking.html',
                        controller: "bookingController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_viewBooking', {
                url: '/viewBooking/:id',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/booking/views/viewBooking.html',
                        controller: "bookingController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_calenderBooking', {
                url: '/calenderBooking',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/booking/views/calenderBooking.html',
                        controller: "bookingController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_editBooking', {
                url: '/editBooking/:id',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/booking/views/addBooking.html',
                        controller: "bookingController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_listInterpreter', {
                url: '/listInterpreter',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/interpreter/views/listInterpreter.html',
                        controller: "interpreterController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_addInterpreter', {
                url: '/addInterpreter',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/interpreter/views/addInterpreter.html',
                        controller: "interpreterController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_editInterpreter', {
                url: '/editInterpreter/:id',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/interpreter/views/addInterpreter.html',
                        controller: "interpreterController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('setPassword', {
                url: '/setPassword/:activation_key',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/setPassword.html',
                        controller: "loginController"
                    }
                },
                params: { 'email': null },
            })

            .state('activateAgency', {
                url: '/activateAgency/:activation_key',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/activateAgency.html',
                        controller: "loginController"
                    }
                },
                params: { 'email': null },
            })

            .state('acceptRequest', {
                url: '/acceptRequest/:request_token',
                views: {
                    'beforeContent': {
                        templateUrl: 'agency/modules/authentication/views/acceptRequest.html',
                        controller: "loginController"
                    }
                }
            })

            .state('agency_viewInterpreter', {
                url: '/viewInterpreter/:id',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/interpreter/views/viewInterpreter.html',
                        controller: "interpreterController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_bulkUploadInterpreter', {
                url: '/bulkUploadInterpreter',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/interpreter/views/bulkUploadInterpreter.html',
                        controller: "interpreterController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_listClient', {
                url: '/listClient',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/client/views/listClient.html',
                        controller: "clientController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_addClient', {
                url: '/addClient',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/client/views/addClient.html',
                        controller: "clientController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_editClient', {
                url: '/editClient/:id',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/client/views/addClient.html',
                        controller: "clientController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_viewClient', {
                url: '/viewClient/:id',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/client/views/viewClient.html',
                        controller: "clientController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_listInvoice', {
                url: '/listInvoice',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/invoice/views/listInvoice.html',
                        controller: "invoiceController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_viewInvoice', {
                url: '/viewInvoice/:id',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/invoice/views/viewInvoice.html',
                        controller: "invoiceController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_addComplaint', {
                url: '/addComplaint',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/complaint/views/addComplaint.html',
                        controller: "complaintController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_editComplaint', {
                url: '/editComplaint/:id',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/complaint/views/editComplaint.html',
                        controller: "complaintController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_listComplaint', {
                url: '/listComplaint',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/complaint/views/listComplaint.html',
                        controller: "complaintController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })
            .state('agency_viewComplaint', {
                url: '/viewComplaint/:id',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/complaint/views/viewComplaint.html',
                        controller: "complaintController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_reportHome', {
                url: '/report',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/report/views/report_home.html',
                        controller: "reportController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_listReportForInterpreter', {
                url: '/reportInterpreter/:id',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/report/views/listReportForInterpreter.html',
                        controller: "reportController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_listReportForCustomer', {
                url: '/reporCustomer/:id',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/report/views/listReportForCustomer.html',
                        controller: "reportController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_listReportForLanguage', {
                url: '/reportLanguage/:language',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/report/views/listReportForLanguage.html',
                        controller: "reportController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_listTopAccounts', {
                url: '/listTopAccounts',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/report/views/listTopTenCustomers.html',
                        controller: "reportController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_listTopLanguage', {
                url: '/listTopLanguage',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/report/views/listTopTenLanguages.html',
                        controller: "reportController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_listScheduler', {
                url: '/listScheduler',
                views:{    
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/scheduler/views/schedulerListing.html',
                        controller: "schedulerController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_listSchedulerTable', {
                url: '/listSchedulerTable',
                views:{    
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/scheduler/views/listBooking.html',
                        controller: "schedulerController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_assignInterpreter', {
                url: '/assignInterpreter/:id',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/booking/views/assignInterpreter.html',
                        controller: "bookingController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            //29 Mar 2018
            .state('agency_viewEvent', {
                url: '/viewEvent/:id',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/scheduler/views/viewEvent.html',
                        controller: "schedulerController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_addEvent', {
                url: '/addEvent',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/scheduler/views/addEvent.html',
                        controller: "schedulerController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })  

            .state('agency_today_bookings', {
                url: '/list_of_todays_bookings',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/scheduler/views/listTodayBookings.html',
                        controller: "schedulerController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_completed_bookings', {
                url: '/completed_bookings',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/scheduler/views/listCompletedBookings.html',
                        controller: "schedulerController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

            .state('agency_pending_bookings', {
                url: '/pending_bookings',
                views: {
                    'header': {
                        templateUrl: 'agency/modules/dashboard/views/header.html',
                        controller: "headerController"
                    },
                    'leftBar': {
                        templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                        controller: "leftBarController"
                    },
                    'content': {
                        templateUrl: 'agency/modules/scheduler/views/listPendingBookings.html',
                        controller: "schedulerController"
                    },
                    'footer': {
                        templateUrl: 'agency/modules/dashboard/views/footer.html'
                    }
                },
                data: {
                    isAuthenticate: true
                },
                resolve: {
                    loggedin: checkLoggedout()
                }
            })

        /**************************Interpreter*******************************/
        .state('interpreter_dashboard', {
            url: '/interpreter/dashboard',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/dashboard/views/interpreterDashboard.html',
                    controller: "interpreterDashboardController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('interpreter_profile', {
            url: '/interpreter/profile',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/dashboard/views/interpreterProfile.html',
                    controller: "interpreterDashboardController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('interpreter_listBooking', {
            url: '/interpreter/listBooking',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/booking/views/listBooking.html',
                    controller: "interpreterBookingController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })    

        .state('interpreter_calendarBooking', {
            url: '/interpreter/calendarBooking',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/booking/views/calendarBooking.html',
                    controller: "interpreterBookingController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })  

        .state('interpreter_viewBooking', {
            url: '/interpreter/viewBooking/:id',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/booking/views/viewBooking.html',
                    controller: "interpreterBookingController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('interpreter_webCall', {
            url: '/interpreter/interpreter_webCall/:id',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/webCall/views/webCall.html',
                    controller: "interpreterWebCallController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        }) 

        .state('interpreter_videoCall', {
            url: '/interpreter/videoCall/:id',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/videoCall/views/videoCall.html',
                    controller: "interpreterVideoCallController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            params:{
                video_id: null
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('interpreter_listVideoCall', {
            url: '/interpreter/listVideoCall',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/videoCall/views/listVideoCall.html',
                    controller: "interpreterVideoCallController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            params:{
                video_id: null
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('interpreter_viewVideoCall', {
            url: '/interpreter/viewVideoCall/:id',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/videoCall/views/viewVideoCall.html',
                    controller: "interpreterVideoCallController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            params:{
                video_id: null
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('interpreter_manualcheck', {
            url: '/interpreter/manualCheck',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/manualCheck/views/addManualCheck.html',
                    controller: "interpreterManualCheckController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('interpreter_checkIn', {
            url: '/interpreter/checkIn/:id',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/checkIn/views/addCheckIn.html',
                    controller: "interpreterCheckInController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('interpreter_checkOut', {
            url: '/interpreter/checkOut/:id',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/checkIn/views/addCheckOut.html',
                    controller: "interpreterCheckInController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('interpreter_calendarScheduling', {
            url: '/interpreter/calendarScheduling',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/interpreterScheduling/views/calendarInterpreterScheduling.html',
                    controller: "interpreterSchedulingController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })
        //Start
        .state('interpreter_listSchedulerTable', {
            url: '/interpreter/listSchedulerTable',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/scheduler/views/listBooking.html',
                    controller: "interpreterSchedulerController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('interpreter_viewBookingDetails', {
            url: '/interpreter/viewBookingDetails/:id',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/scheduler/views/viewEvent.html',
                    controller: "interpreterSchedulerController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('interpreter_listScheduler', {
            url: '/interpreter/listScheduler',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/scheduler/views/schedulerListing.html',
                    controller: "interpreterSchedulerController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('interpreter_todays_booking', {
            url: '/interpreter/today_bookings',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/scheduler/views/listTodaysBooking.html',
                    controller: "interpreterSchedulerController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('interpreter_completed_bookings', {
            url: '/interpreter/completed_bookings',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/scheduler/views/listCompletedBookings.html',
                    controller: "interpreterSchedulerController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('interpreter_pending_bookings', {
            url: '/interpreter/pending_bookings',
            views: {
                'header': {
                    templateUrl: "interpreter/modules/dashboard/views/header.html",
                    controller: "interpreterHeaderController"
                },
                'leftBar': {
                    templateUrl: 'interpreter/modules/dashboard/views/leftBar.html',
                    controller: "interpreterLeftBarController"
                },
                'content': {
                    templateUrl: 'interpreter/modules/scheduler/views/listPendingBookings.html',
                    controller: "interpreterSchedulerController"
                },
                'footer': {
                    templateUrl: 'interpreter/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })
        
        /**************************** Client **********************************/
        .state('client_dashboard', {
            url: '/client/dashboard',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/dashboard/views/clientDashboard.html',
                    controller: "clientDashboardController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_profile', {
            url: '/client/profile',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/dashboard/views/clientProfile.html',
                    controller: "clientDashboardController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_listBooking', {
            url: '/client/listBooking',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/booking/views/listBooking.html',
                    controller: "clientBookingController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        }) 

        .state('client_addBooking', {
            url: '/client/addBooking',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/booking/views/addBooking.html',
                    controller: "clientBookingController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        }) 

        .state('client_viewBooking', {
            url: '/client/viewBooking/:id',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/booking/views/viewBooking.html',
                    controller: "clientBookingController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        }) 

        .state('client_editBooking', {
            url: '/client/editBooking/:id',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/booking/views/addBooking.html',
                    controller: "clientBookingController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_listCalendarBooking', {
            url: '/client/listCalendarBooking',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/booking/views/listCalendarBooking.html',
                    controller: "clientBookingController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_webCall', {
            url: '/client/client_webCall/:id',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/webCall/views/webCall.html',
                    controller: "webCallController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        }) 

        .state('client_videoCall', {
            url: '/client/videoCall/:id',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/videoCall/views/videoCall.html',
                    controller: "videoCallController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            params:{
                video_id: null
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_listVideoCall', {
            url: '/client/listVideoCall',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/videoCall/views/listVideoCall.html',
                    controller: "videoCallController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            params:{
                video_id: null
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_viewVideoCall', {
            url: '/client/viewVideoCall/:id',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/videoCall/views/viewVideoCall.html',
                    controller: "videoCallController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            params:{
                video_id: null
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_listComplaint', {
            url: '/client/listComplaint',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/complaint/views/listComplaint.html',
                    controller: "clientComplaintController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_addComplaint', {
            url: '/client/addComplaint',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/complaint/views/addComplaint.html',
                    controller: "clientComplaintController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_viewComplaint', {
            url: '/client/viewComplaint/:id',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/complaint/views/viewComplaint.html',
                    controller: "clientComplaintController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_editComplaint', {
            url: '/client/editComplaint/:id',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/complaint/views/editComplaint.html',
                    controller: "clientComplaintController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('agency_viewCurrentPlan', {
            url: '/viewCurrentPlan',
            views: {
                'header': {
                    templateUrl: 'agency/modules/dashboard/views/header.html',
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'agency/modules/invoice/views/viewCurrentPlan.html',
                    controller: "invoiceController"
                },
                'footer': {
                    templateUrl: 'agency/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('agency_upgradeSubscriptionPlan', {
            url: '/upgradeSubscriptionPlan',
            views: {
                'header': {
                    templateUrl: 'agency/modules/dashboard/views/header.html',
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'agency/modules/invoice/views/upgradeSubscriptionPlan.html',
                    controller: "invoiceController"
                },
                'footer': {
                    templateUrl: 'agency/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('agency_editCurrentOccurrenceEvent', {
            url: '/editCurrentOccurrenceEvent/:id',
            views: {
                'header': {
                    templateUrl: 'agency/modules/dashboard/views/header.html',
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'agency/modules/scheduler/views/editScheduling.html',
                    controller: "schedulerController"
                },
                'footer': {
                    templateUrl: 'agency/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('agency_editScheduling', {
            url: '/editScheduling/:id',
            views: {
                'header': {
                    templateUrl: 'agency/modules/dashboard/views/header.html',
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'agency/modules/scheduler/views/addEvent.html',
                    controller: "schedulerController"
                },
                'footer': {
                    templateUrl: 'agency/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('agency_assigningInterpreter', {
            url: '/assigningInterpreter/:id',
            views: {
                'header': {
                    templateUrl: 'agency/modules/dashboard/views/header.html',
                    controller: "headerController"
                },
                'leftBar': {
                    templateUrl: 'agency/modules/dashboard/views/leftBar.html',
                    controller: "leftBarController"
                },
                'content': {
                    templateUrl: 'agency/modules/scheduler/views/assignInterpreter.html',
                    controller: "schedulerController"
                },
                'footer': {
                    templateUrl: 'agency/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_listSchedulerTable', {
            url: '/client/listSchedulerTable',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/scheduler/views/listBooking.html',
                    controller: "clientSchedulerController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_viewBookingDetails', {
            url: '/client/viewBookingDetails/:id',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/scheduler/views/viewBooking.html',
                    controller: "clientSchedulerController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_listScheduler', {
            url: '/client/listScheduler',
            views: {
                'header': {
                    templateUrl: "client/modules/dashboard/views/header.html",
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/scheduler/views/schedulerListing.html',
                    controller: "clientSchedulerController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_editEvent', {
            url: '/client/editEvent/:id',
            views: {
                'header': {
                    templateUrl: 'client/modules/dashboard/views/header.html',
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/scheduler/views/addEvent.html',
                    controller: "clientSchedulerController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_todays_booking', {
            url: '/client/todays_booking',
            views: {
                'header': {
                    templateUrl: 'client/modules/dashboard/views/header.html',
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/scheduler/views/listTodaysBooking.html',
                    controller: "clientSchedulerController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_completed_bookings', {
            url: '/client/completed_bookings',
            views: {
                'header': {
                    templateUrl: 'client/modules/dashboard/views/header.html',
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/scheduler/views/listCompletedBookings.html',
                    controller: "clientSchedulerController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })

        .state('client_pending_bookings', {
            url: '/client/pending_bookings',
            views: {
                'header': {
                    templateUrl: 'client/modules/dashboard/views/header.html',
                    controller: "clientHeaderController"
                },
                'leftBar': {
                    templateUrl: 'client/modules/dashboard/views/leftBar.html',
                    controller: "clientLeftBarController"
                },
                'content': {
                    templateUrl: 'client/modules/scheduler/views/listPendingBookings.html',
                    controller: "clientSchedulerController"
                },
                'footer': {
                    templateUrl: 'client/modules/dashboard/views/footer.html'
                }
            },
            data: {
                isAuthenticate: true
            },
            resolve: {
                loggedin: checkLoggedout()
            }
        })


        //to remove the # from the URL
        // $locationProvider.html5Mode({enabled : true, requireBase : false});
    }])

.run(['$rootScope', '$location', '$http', '$localStorage', '$state','ClientBookingService', 'logger',
    function($rootScope, $location, $http, $localStorage, $state, ClientBookingService, logger) {
        $rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState) {
            $rootScope.CurrPath = toState.name;
            // if (fromState.name != 'worker') {
            //     ngTableParamsService.set('', '', '', '', '');
            // }
            // if (toState.data) {
            //     if (!$localStorage.token && toState.data.isAuthenticate) {
            //         event.preventDefault();
            //         $state.go('home');
            //     }
            // }
        });
        $rootScope.capitalize = function (string) {
            if (string) {
                return string.charAt(0).toUpperCase() + string.slice(1);
            } else {
                return;
            }
        } 
            

        /**
        * Function is used to intialize twilio
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Nov-2017
        **/
        $rootScope.initializeTwilio = function(){
            var data = {
                page: 'customer'
            }
            ClientBookingService.initializeTwilio().save(data, function(response, err) {
                // console.log("Token response", response);
                if (response.status == 1) {
                    Twilio.Device.setup(response.data.token);
                    // logger.logSuccess(response.message); 
                } else {
                    // logger.logError(response.message);
                }
            });

            /* Report any errors to the call status display */
            Twilio.Device.error(function (error) {
                logger.logError("ERROR: " + error.message);
            });
            
            /* Callback for when Twilio Client initiates a new connection */
            Twilio.Device.connect(function (connection) {
                if ("phoneNumber" in connection.message) {
                    var msg =  'Call Connected'; 
                    $rootScope.$broadcast('webCallConnected', { message: msg, connectionObj: connection  });
                    
                }
            });
            
            /* Callback for when a call ends */
            Twilio.Device.disconnect(function(connection) {
                var msg =  'Call disconnect'; 
                $rootScope.$broadcast('webCallDisconnected', { message: msg , connectionObj: connection });
               
            });
        }
        
        $rootScope.initializeTwilio();

        }
    ])

    .filter('capitalize', function() {
        return function(input) {
            return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
        }
    })
    .filter('capitalizeFirstLetterEachWord', function() {
        return function(input){
            if(input.indexOf(' ') !== -1){
              var inputPieces,
                  i;

              input = input.toLowerCase();
              inputPieces = input.split(' ');

              for(i = 0; i < inputPieces.length; i++){
                inputPieces[i] = capitalizeString(inputPieces[i]);
              }

              return inputPieces.toString().replace(/,/g, ' ');
            }
            else {
              input = input.toLowerCase();
              return capitalizeString(input);
            }

            function capitalizeString(inputString){
              return inputString.substring(0,1).toUpperCase() + inputString.substring(1);
            }
        };
    })
    .filter('trustAsResourceUrl', ['$sce', function($sce) {
        return function(val) {
            return $sce.trustAsResourceUrl(val);
        };
    }]);


    
   