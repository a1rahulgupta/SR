var baseUrl = location.protocol + '//' + location.hostname + (location.port ? ':' + location.port : '');
const stripe_published_key = "pk_test_jTfeZ7U3RCzKqZJk6NmYAGMV";

var webservices = {

    //Authenticate
    "authenticate": baseUrl + "/api/v1/user/login",
    "adminAuthenticate": baseUrl + "/api/adminLogin",
    "userRegister": baseUrl + "/api/userRegister",
    "userForgotPassword": baseUrl + "/api/v1/user/forgotPassword",
    "setNewPassword": baseUrl + "/api/v1/user/setNewPassword",
    "resetPassword": baseUrl + "/api/resetPassword",
    "uploadImage": baseUrl + "/api/uploadImage",
    "getInviteUser": baseUrl + "/api/getInviteUser",
    "updateCompleteRegister": baseUrl + "/api/updateCompleteRegister",
    "getTimezoneList": baseUrl + "/api/getTimezoneList",
    "updateProfile": baseUrl + "/api/updateProfile",
    "changePassword": baseUrl + "/api/changePassword",

    //Home
    "getHomeList": baseUrl + "/api/getHomeList",
    "getHomeItem" : baseUrl + "/api/getHomeItem",
    "getMailCategory": baseUrl + "/api/getMailCategory",
    "addContactUs" : baseUrl + "/api/addContactUs",
    "addMailingList" : baseUrl + "/api/addMailingList",
    

    //Dashboard
    "getCountOfAgency": baseUrl + "/api/v1/agency/getCountOfAgency",
    "getDashboardCount": baseUrl + "/api/getDashboardCount",
    "getDashboardLatestOrder": baseUrl + "/api/getDashboardLatestOrder",
    "getDashboardLatestUser": baseUrl + "/api/getDashboardLatestUser",


    //leftNavigation
    "getPermissionById": baseUrl + "/api/getPermissionById/:id",

    //user
    // "userList": baseUrl + "/api/users/list",
    // "findOneUser": baseUrl + "/api/users/userOne",
    // "bulkUpdateUser": baseUrl + "/api/users/bulkUpdate",
    // "update": baseUrl + "/api/users/update",
    "getUserList": baseUrl + "/api/users/getUserList",
    "getDesignation": baseUrl + "/api/users/getDesignation",
    "addUser": baseUrl + "/api/users/addUser",
    "inviteUser": baseUrl + "/api/users/inviteUser",
    "getInviteUserList": baseUrl + "/api/users/getInviteUserList",
    "getUserByUserOrgId": baseUrl + "/api/users/getUserByUserOrgId/:id",
    "getPerByUserOrgId": baseUrl + "/api/users/getPerByUserOrgId",
    "updateUser": baseUrl + "/api/users/updateUser",
    // "getUserFromOrg": baseUrl + "/api/users/getUserFromOrg",
    "deleteUserByUserOrgId": baseUrl + "/api/users/deleteUserByUserOrgId/:id",
    "cancelInviteById": baseUrl + "/api/users/cancelInviteById/:id",
    "updateUserPermission": baseUrl + "/api/users/updateUserPermission",
    "getUserListLeftTab": baseUrl + "/api/users/getUserListLeftTab",
    "getUserListSearchLeftTab": baseUrl + "/api/users/getUserListSearchLeftTab",
    "setOrganization":baseUrl + "/api/users/setOrganization",
    "updateOrgData":baseUrl + "/api/users/updateOrgData",
    "setUserAccess": baseUrl + "/api/users/setUserAccess",

    //task

    //twitter + facebook + instagram
    "connectTwitterProfile": baseUrl + "/api/connectTwitterProfile/:acc_type",
    "removeSocialProfile" : baseUrl + "/api/removeSocialProfile/:id/:network",
    "connectFacebookProfile" : baseUrl + "/api/connectFacebookProfile/:acc_type",
    "connectInstagramProfile" : baseUrl + "/api/connectInstagramProfile/:acc_type",

    //Channels
    "getUserChannelsList": baseUrl + "/api/getUserChannelsList/:id",
    "switchSocialAccType" : baseUrl + "/api/switchSocialAccType/",

    //start Interpreter
    "getAgencyInvoiceById": baseUrl + "/api/v1/invoice/getAgencyInvoiceById/:id",
    "listAgencyInvoice": baseUrl + "/api/v1/invoice/listAgencyInvoice",
    "getAllSubscriptionData": baseUrl + "/api/v1/subscription",
    "agencyRegister": baseUrl + "/api/v1/agency/registration",
    "agencyRegisterEmailCheck": baseUrl + "/api/v1/agency/agencyRegisterEmailCheck",
    "getBookingList": baseUrl + "/api/v1/bookings/listBookings",
    "getAgencyBookingList": baseUrl + "/api/v1/bookings/getAgencyBookingList",
    "getAgencyInterpreters": baseUrl + "/api/v1/interpreters/listAgencyInterpreters",
    "getAgencyClients": baseUrl + "/api/v1/clients/listAgencyClients",
    "addBooking": baseUrl + "/api/v1/bookings/addBooking",
    "getBookingById": baseUrl + "/api/v1/bookings/getBooking/:id",
    "getBookingViewById": baseUrl + "/api/v1/bookings/getBookingViewById/:id",
    "deleteBooking": baseUrl + "/api/v1/bookings/deleteBooking/:id",
    "updateBooking": baseUrl + "/api/v1/bookings/updateBooking",
    "searchBookingByDate": baseUrl + "/api/v1/bookings/searchBookingByDate",
    "listAgencyInterpreters": baseUrl + "/api/v1/interpreters/listInterpreters",
    "deleteInterpreter": baseUrl + "/api/v1/interpreters/deleteInterpreter/:id",
    "addInterpreter": baseUrl + "/api/v1/interpreters/addInterpreter",
    "getInterpreterById": baseUrl + "/api/v1/interpreters/getInterpreter/:id",
    "updateInterpreter": baseUrl + "/api/v1/interpreters/updateInterpreter",
    "changeInterpreterStatus": baseUrl + "/api/v1/interpreters/changeInterpreterStatus",
    "listAgencyClients": baseUrl + "/api/v1/clients/listClients",
    "addAgencyClients": baseUrl + "/api/v1/clients/addAgencyClients",
    "deleteAgencyClient": baseUrl + "/api/v1/clients/deleteAgencyClient/:id",
    "getAgencyClientById": baseUrl + "/api/v1/clients/getAgencyClientById/:id",
    "updateAgencyClient": baseUrl + "/api/v1/clients/updateAgencyClient",
    "changeClientStatus": baseUrl + "/api/v1/clients/changeClientStatus",
    "getAllBookings": baseUrl + "/api/v1/agency/getAllBookings",


    "getEmailUsingKey": baseUrl + "/api/v1/user/getEmailUsingKey/:id",
    "completeUserRegistration": baseUrl + "/api/v1/user/completeUserRegistration",

    "listBookingByInterpreterId": baseUrl + "/api/v1/bookings/listBookingByInterpreterId",
    "getInterpreterBookingById": baseUrl + "/api/v1/bookings/getInterpreterBookingById/:id",
    "getBookingInterpreterById": baseUrl + "/api/v1/bookings/getBookingInterpreterById/:id",

    "listBookingByClientId": baseUrl + "/api/v1/bookings/listBookingByClientId",
    "addBookingByClient": baseUrl + "/api/v1/bookings/addBookingByClient",
    "getClientBookingById": baseUrl + "/api/v1/bookings/getClientBookingById/:id",
    "getClientBookingViewById": baseUrl + "/api/v1/bookings/getClientBookingViewById/:id",
    "updateBookingByClient": baseUrl + "/api/v1/bookings/updateBookingByClient",
    "cancelBookingByClient": baseUrl + "/api/v1/bookings/cancelBookingByClient",
    "closeBookingByClient": baseUrl + "/api/v1/bookings/closeBookingByClient",
    // "getBookingListByClientId": baseUrl + "/api/v1/bookings/getBookingListByClientId",
    "getBookingByClientId": baseUrl + "/api/v1/bookings/getBookingByClientId/:id",
    "bulkUploadInterpreter": baseUrl + "/api/v1/interpreters/bulkUploadInterpreter",
    "webCallToInterpreter": baseUrl + "/api/v1/web_call/webCallToInterpreter",
    "initializeTwilio": baseUrl + "/api/v1/web_call/initializeTwilio",
    "createTokenAndSessionId": baseUrl + "/api/v1/video_call/createTokenAndSessionId",
    "senderStartedVideoCall": baseUrl + "/api/v1/video_call/senderStartedVideoCall",
    "listVideoCallBookingByClientId": baseUrl + "/api/v1/video_call/listVideoCallBookingByClientId",
    "listVideoCallBookingByInterpreterId": baseUrl + "/api/v1/video_call/listVideoCallBookingByInterpreterId",
    "getEmailUsingPassword": baseUrl + "/api/v1/user/getEmailUsingPassword/:id",
    "getBookingIdsByClientId": baseUrl + "/api/v1/customercomplaint/getBookingIdsByClientId",
    "getBookingsByAgencyId": baseUrl + "/api/v1/customercomplaint/getBookingsByAgencyId",
    "getComplaintById": baseUrl + "/api/v1/customercomplaint/getComplaintById/:id",
    "addComplaint": baseUrl + "/api/v1/customercomplaint/addcustomercomplaint",
    
    "listComplaintOfAgency": baseUrl + "/api/v1/customercomplaint/listComplaints",
    "listComplaintByClientId": baseUrl + "/api/v1/customercomplaint/listComplaints",
    
    "updateComplaint": baseUrl + "/api/v1/customercomplaint/updatecustomercomplaint",
    "deleteComplaint": baseUrl + "/api/v1/customercomplaint/deleteComplaint/:id",
    "searchComplaintByDate": baseUrl + "/api/v1/customercomplaint/searchComplaintByDate",

    "getInterpreterProfileDetailById": baseUrl + "/api/v1/interpreters/getInterpreterProfile",
    "getClientProfileDetailById": baseUrl + "/api/v1/clients/getClientProfileDetailById",
    "getAgencyProfileById": baseUrl + "/api/v1/agency/getAgencyProfileById",
    "updateAgencyProfile": baseUrl + "/api/v1/agency/updateAgencyProfile",
    "changePassword": baseUrl + "/api/v1/user/changePassword",
    "clientChangePassword": baseUrl + "/api/v1/user/changePassword",
    "interpreterChangePassword": baseUrl + "/api/v1/user/changePassword",

    
    "getReviewByBookingId": baseUrl + "/api/v1/review/getReviewRatingByBookingId/:id",
    "addReviewRatingByClient": baseUrl + "/api/v1/review/addReviewRatingByClient",
    "getInterpreterRatingById": baseUrl + "/api/v1/review/getInterpreterRatingById",
    "listAgencyClientsInReport": baseUrl + "/api/v1/clients/listAgencyClientsInReports",  
    "getClientCompletedBookings": baseUrl + "/api/v1/report/getClientCompletedBookings",
    "getLanguageCompletedBookings": baseUrl + "/api/v1/report/getLanguageCompletedBookings",
    "exportClientCompletedBookingsToPdf": baseUrl + "/api/v1/report/exportClientCompletedBookingsToPdf/:id",
    "exportPerLanguageToPdf": baseUrl + "/api/v1/report/exportPerLanguageToPdf/:language",

    "getBookindIdsByInterpreterId": baseUrl + "/api/v1/check_in_out/getBookindIdsByInterpreterId",
    "getBookingDetailByBookingId": baseUrl + "/api/v1/check_in_out/getBookingDetailByBookingId/:id",
    "addManualCheckInOut": baseUrl + "/api/v1/check_in_out/addManualCheckInOut",
    "getCheckInOutDetailByBookingId": baseUrl + "/api/v1/check_in_out/getCheckInOutDetailByBookingId/:id",
    "checkInOutApproval": baseUrl + "/api/v1/check_in_out/checkInOutApproval",
    "getTopTenClients": baseUrl + "/api/v1/report/getTopTenClients",
    "getTopTenLanguageReport": baseUrl + "/api/v1/report/getTopTenLanguageReport",
    "exportTopTenClientsToPdf": baseUrl + "/api/v1/report/exportTopTenClientsToPdf",
    "exportTopTenLaguageToPdf": baseUrl + "/api/v1/report/exportTopTenLaguageToPdf",
    "addGeoCheckIn": baseUrl + "/api/v1/check_in_out/addGeoCheckIn",
    "addGeoCheckOut": baseUrl + "/api/v1/check_in_out/addGeoCheckOut",

    "getAllLanguagesInBooking": baseUrl + "/api/v1/admin/getAllLanguages",
    "getAllLanguagesInInterpreter": baseUrl + "/api/v1/admin/getAllLanguages",
    "getAllLanguagesInClient": baseUrl + "/api/v1/admin/getAllLanguagesForMultiselect",

    "getAllCountriesInAgency": baseUrl + "/api/v1/admin/getAllCountries",
    "getAllCountriesInClient": baseUrl + "/api/v1/admin/getAllCountries",
    "getAllCountriesInInterpreter": baseUrl + "/api/v1/admin/getAllCountries",
    "getAllCountriesInClientInAgency": baseUrl + "/api/v1/admin/getAllCountries",
    "getAllCountriesInInterpreterInAgency": baseUrl + "/api/v1/admin/getAllCountries",
    "getAllServicesInInterpreter": baseUrl + "/api/v1/admin/getAllServicesForMultiselect",
    "getAllLanguagesInInterpreter": baseUrl + "/api/v1/admin/getAllLanguagesInInterpreter",
    "updateAgencyClientLanguage": baseUrl + "/api/v1/clients/updateAgencyClientLanguage",
    "updateClientProfile": baseUrl + "/api/v1/clients/updateClientProfile",
    "getInterpreterViewById": baseUrl + "/api/v1/interpreters/getInterpreterViewById/:id",
    "getInterpreterSchedulingDetails": baseUrl + "/api/v1/interpreters/getInterpreterDetailForCalendar",
    "addInterpreterLeave": baseUrl + "/api/v1/interpreters/addInterpreterLeave",
    "updateInterpreterLeave": baseUrl + "/api/v1/interpreters/updateInterpreterLeave",
    "updateInterpreterProfile": baseUrl + "/api/v1/interpreters/updateInterpreterProfile",
    "getBookingDetailForInterpreterCalendar": baseUrl + "/api/v1/bookings/getBookingDetailForInterpreterCalendar",
    "getInterpreterBookingViewById": baseUrl + "/api/v1/bookings/getInterpreterBookingViewById/:id",
    "getInterpreterBookingViewByIdInAgency": baseUrl + "/api/v1/bookings/getInterpreterBookingViewByIdInAgency",
    "getAllLanguagesInClientBooking": baseUrl + "/api/v1/admin/getAllLanguages",
    "getInterpreterSchedulingDetailsInAgency": baseUrl + "/api/v1/interpreters/getInterpreterDetailForCalendarByAgency",
    "getBookingDetailForInterpreterCalendarInAgency": baseUrl + "/api/v1/bookings/getBookingDetailForInterpreterCalendarInAgency",
    "addInterpreterLeaveInAgency": baseUrl + "/api/v1/interpreters/addInterpreterLeaveInAgency",
    "updateInterpreterLeaveInAgency": baseUrl + "/api/v1/interpreters/updateInterpreterLeaveInAgency",
    "listBookingOfInterpreterInAgency": baseUrl + "/api/v1/bookings/listBookingOfInterpreterInAgency",
    "deleteBookingOfInterpreterInAgency": baseUrl + "/api/v1/bookings/deleteBooking/:id",
    "getInterpreterBookingByIdInAgency": baseUrl + "/api/v1/bookings/getInterpreterBookingViewByIdInAgency",
    "listBookingOfClientInAgency": baseUrl + "/api/v1/bookings/listBookingOfClientInAgency",
    "deleteBookingOfClientInAgency": baseUrl + "/api/v1/bookings/deleteBooking/:id",
    "getClientBookingByIdInAgency": baseUrl + "/api/v1/bookings/getClientBookingByIdInAgency",
    "getVideoCallDetailsByIdInInterpreter": baseUrl + "/api/v1/video_call/getVideoCallDetailsByIdInInterpreter/:id",
    "getVideoCallDetailsByIdInClient": baseUrl + "/api/v1/video_call/getVideoCallDetailsByIdInClient/:id",
    "getAllLanguagesInReport": baseUrl + "/api/v1/admin/getAllLanguages",
    "getInterpreterNamesByLanguageId": baseUrl + "/api/v1/interpreters/getInterpreterNamesByLanguageId/:id",
    "getClientNameByClientIdInReport": baseUrl + "/api/v1/clients/getClientNameByClientIdInReport/:id",
    "getLanguageNameByLanguageIdInReport": baseUrl + "/api/v1/agency/getLanguageNameByLanguageIdInReport/:id",
    // "getInterpreterNamesByLanguageIdInClient": baseUrl + "/api/v1/interpreters/getInterpreterNamesByLanguageIdInClient/:id",

    "getCountOfInterpreter": baseUrl + "/api/v1/interpreters/getCountOfInterpreter",
    "getBookingInterpretersLocation": baseUrl + "/api/v1/bookings/getBookingInterpretersLocation",
    "sendRequestToInterpreters": baseUrl + "/api/v1/bookings/sendRequestToInterpreters",
    "getBookingDetails": baseUrl + "/api/v1/user/getBookingDetails/:id",
    "saveBookingRequest": baseUrl + "/api/v1/user/saveBookingRequest",
    "downloadPaperVoucher": baseUrl + "/api/v1/bookings/downloadPaperVoucher",
    "activateInterpreterByAgency": baseUrl + "/api/v1/interpreters/activateInterpreterByAgency",
    "subscribe": baseUrl + "/api/v1/admin/subscribe",
    "getCountOfClient": baseUrl + "/api/v1/clients/getCountOfClient",
    "getCarouselDetails": baseUrl + "/api/v1/cms/getCarouselDetails",
    "activateAgencyWithSubscription": baseUrl + "/api/v1/agency/activateAgencyWithSubscription",
    "getClientListByAgency": baseUrl + "/api/v1/clients/getClientListByAgency",
    "listAgencyInterpretersInReport": baseUrl + "/api/v1/interpreters/listAgencyInterpretersInReports",  
    "getInterpreterNameByInterpreterIdInReport": baseUrl + "/api/v1/interpreters/getInterpreterNameByInterpreterIdInReport/:id",
    "getInterpreterCompletedBookings": baseUrl + "/api/v1/report/getInterpreterCompletedBookings",
    "exportInterpreterCompletedBookingsToPdf": baseUrl + "/api/v1/report/exportInterpreterCompletedBookingsToPdf/:id",
    
    //Agency Scheduler Work
    "getEventName": baseUrl + "/api/v1/scheduler/getEventName",
    "addSchedule": baseUrl + "/api/v1/scheduler/addSchedule",
    "getAllBookings": baseUrl + "/api/v1/scheduler/getAllBookings",
    "updateCurrentOccurenceEvent": baseUrl + "/api/v1/scheduler/updateCurrentOccurenceEvent",
    "deleteCurrentEvent": baseUrl + "/api/v1/scheduler/deleteCurrentEvent",
    "deleteAllEvent": baseUrl + "/api/v1/scheduler/deleteAllEvent",
    "deleteEvent": baseUrl + "/api/v1/scheduler/deleteEvent/:id",
    "deleteCurrentAndFollowingEvents": baseUrl + "/api/v1/scheduler/deleteCurrentAndFollowingEvents",
    "getAgencyEventList": baseUrl + "/api/v1/scheduler/getAgencyEventList",
    "searchBookingByDateScheduler": baseUrl + "/api/v1/scheduler/searchBookingByDateScheduler",
    "getEventViewById": baseUrl + "/api/v1/scheduler/getEventViewById/:id",
    "getEventById": baseUrl + "/api/v1/scheduler/getEventById/:id",
    "getEventInterpretersLocation": baseUrl + "/api/v1/scheduler/getEventInterpretersLocation",
    "sendEventRequestToInterpreters": baseUrl + "/api/v1/scheduler/sendEventRequestToInterpreters",
    "acceptEventRequest": baseUrl + "/api/v1/user/saveEventRequest",
    "getTodaysAgencyBookingList": baseUrl + "/api/v1/scheduler/getTodaysAgencyBookingList",
    "getAgencyCompletedBookings": baseUrl + "/api/v1/scheduler/getAgencyCompletedBookings",
    "getAgencyPendingBookings": baseUrl + "/api/v1/scheduler/getAgencyPendingBookings",
    "getCompletedBookingsByAgency": baseUrl + "/api/v1/customercomplaint/getCompletedBookingsByClientId",
    "lodgeComplaintByAgency": baseUrl + "/api/v1/customercomplaint/lodgeComplaintByAgency",
    "makeComplaintInProcess": baseUrl + "/api/v1/customercomplaint/makeComplaintInProcess",
    "makeComplaintStatusCompleted": baseUrl + "/api/v1/customercomplaint/makeComplaintStatusCompleted",
    
    //Interpreter Scheduler work
    "getInterpreterBookingList": baseUrl + "/api/v1/scheduler/getInterpreterBookingList",
    "getBookingViewByInterpreterId": baseUrl + "/api/v1/scheduler/getBookingViewByInterpreterId/:id",
    "getBookingViewByBookingId": baseUrl + "/api/v1/scheduler/getBookingViewByBookingId/:id",
    "getTodaysInterpreterBookingList": baseUrl + "/api/v1/scheduler/getTodaysInterpreterBookingList",
    "getInterpreterCompletedBooking": baseUrl + "/api/v1/scheduler/getInterpreterCompletedBooking",
    "getInterpreterPendingBookings": baseUrl + "/api/v1/scheduler/getInterpreterPendingBookings",
    "getTodaysBookingForManualCheckInOut": baseUrl + "/api/v1/check_in_out/getTodaysBookingForManualCheckInOut",
    "getBookingForManualCheckInOut": baseUrl + "/api/v1/check_in_out/getBookingForManualCheckInOut/:id",
    "downloadPaperVoucherByInterpreter": baseUrl + "/api/v1/scheduler/downloadPaperVoucherByInterpreter",
    
    //Client Scheduler work
    "getClientBookingList": baseUrl + "/api/v1/scheduler/getClientBookingList",
    "getBookingViewByClientId": baseUrl + "/api/v1/scheduler/getBookingViewByClientId/:id",
    "addEventByClient": baseUrl + "/api/v1/scheduler/addEventByClient",
    "getTodaysClientBookingList": baseUrl + "/api/v1/scheduler/getTodaysClientBookingList",
    "getClientCompletedBooking": baseUrl + "/api/v1/scheduler/getClientCompletedBooking",
    "getClientPendingBookings": baseUrl + "/api/v1/scheduler/getClientPendingBookings",
    "getCompletedBookingsByClientId": baseUrl + "/api/v1/customercomplaint/getCompletedBookingsByClientId",
    "getSelectedBookingDetail": baseUrl + "/api/v1/customercomplaint/getSelectedBookingDetail",
    "lodgeComplaintByClient": baseUrl + "/api/v1/customercomplaint/lodgeComplaintByClient",
    "getCompletedBookingsForUpdate": baseUrl + "/api/v1/customercomplaint/getCompletedBookingsForUpdate",
    "approveComplaint": baseUrl + "/api/v1/customercomplaint/approveComplaint",
         
    "getCurrentPlanDetails": baseUrl + "/api/v1/invoice/getCurrentPlanDetails",
    "stopRecurringPayment": baseUrl + "/api/v1/invoice/stopRecurringPayment",
    "startRecurringPayment": baseUrl + "/api/v1/invoice/startRecurringPayment",

    "getAllSubscriptionPlanByAgency": baseUrl + "/api/v1/subscription/getAllSubscriptionPlanByAgency",
    "upgradeSubscriptionPlan": baseUrl + "/api/v1/agency/upgradeSubscriptionPlan",

    

}

var statusCode = {
    "ok": 200,
    "error": 401,
    "permission": 403,
    "warning": 404,
    "failed": 1002,
    "unauth": 1003,
    "internalError": 1004
}

var googleConstants = {
    "google_client_id": "54372597586-09u72notkj8g82vl3jt77h7cbutvr7ep.apps.googleusercontent.com",
}

var appConstants = {
    "authorizationKey": "dGF4aTphcHBsaWNhdGlvbg=="
}


var headerConstants = {
    "json": "application/json"
}

var regex = {
    "NAME": /^[a-zA-Z . \-\']*$/,
    "CITY": /^[a-zA-Z . \-\']*$/,
    "MATERIAL": /^([a-zA-Z0123456789-]+\s)*[a-zA-Z0123456789-]+$/,
    "EMAIL": /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
    "POSTAL_CODE": /(^\d{5}$)|(^\d{5}-\d{4}$)/,
    "PHONE_NO": /\(?\d{3}\)?-? *\d{3}-? *-?\d{4}/,
    "PASSWORD": /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{6,}/,
    "DESCRIPTION": /^[ A-Za-z0-9_@./#&+-;]*$/,
    "TASK_CODE": /^[0-9999]{1,4}$/,
    "SUB_DOMAIN": /^[/a-z/A-Z][a-zA-Z0-9-]*[^/-/./0-9]$/,
    "PHONE_NO_MASK": ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/],
    "RADIUS": /^[1-9][0-9]*(?:.)([0-9])+$/,
    "LATLONG": /^\s*(\-?\d+(\.\d+)?)$/,

    "name": /^([a-zA-ZàèìòùÀÈÌÒÙáéíóúýÁÉÍÓÚÝâêîôûÂÊÎÔÛãñõÃÑÕäëïöüÿÄËÏÖÜŸçÇßØøÅåÆæœ@¿?!¡:/',.-]+\s)*[a-zA-ZàèìòùÀÈÌÒÙáéíóúýÁÉÍÓÚÝâêîôûÂÊÎÔÛãñõÃÑÕäëïöüÿÄËÏÖÜŸçÇßØøÅåÆæœ',.-]+$/,
    "address": /^([a-zA-Z0123456789àèìòùÀÈÌÒÙáéíóúýÁÉÍÓÚÝâêîôûÂÊÎÔÛãñõÃÑÕäëïöüÿÄËÏÖÜŸçÇßØøÅåÆæœ@¿?!¡:/',.-]+\s)*[a-zA-Z0123456789àèìòùÀÈÌÒÙáéíóúýÁÉÍÓÚÝâêîôûÂÊÎÔÛãñõÃÑÕäëïöüÿÄËÏÖÜŸçÇßØøÅåÆæœ@',.-]+$/
}

var messagesConstants = {

    //users
    "saveUser": "User saved successfully",
    "updateUser": "User updated successfully",
    "updateStatus": "Status updated successfully",
    "deleteUser": "User(s) deleted successfully",
    "unAuthorize": "User email or password are not correct",


}
