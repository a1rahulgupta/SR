/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
  interpreterApp.directive('validPasswordC', function() {
  return {
    require: 'ngModel',
    scope: {

      reference: '=validPasswordC'

    },
    link: function(scope, elm, attrs, ctrl) {
      ctrl.$parsers.unshift(function(viewValue, $scope) {

        var noMatch = viewValue != scope.reference
        ctrl.$setValidity('noMatch', !noMatch);
        return (noMatch)?noMatch:!noMatch;
      });

      scope.$watch("reference", function(value) {;
        ctrl.$setValidity('noMatch', value === ctrl.$viewValue);

      });
    }
  }
});

interpreterApp.directive("raty", function() {
    return {
        restrict: 'AE',
        link: function(scope, elem, attrs) {
            $(elem).raty({score: attrs.score, number: attrs.number, readOnly: attrs.readonly});
        }
    }
});

interpreterApp.directive("masonry", function () {
    var NGREPEAT_SOURCE_RE = '<!-- ngRepeat: ((.*) in ((.*?)( track by (.*))?)) -->';
    return {
        compile: function(element, attrs) {
            // auto add animation to brick element
            var animation = attrs.ngAnimate || "'masonry'";
            var $brick = element.children();
            $brick.attr("ng-animate", animation);
            
            // generate item selector (exclude leaving items)
            var type = $brick.prop('tagName');
            var itemSelector = type+":not([class$='-leave-active'])";
            
            return function (scope, element, attrs) {
                var options = angular.extend({
                    itemSelector: itemSelector
                }, scope.$eval(attrs.masonry));
                
                // try to infer model from ngRepeat
                if (!options.model) { 
                    var ngRepeatMatch = element.html().match(NGREPEAT_SOURCE_RE);
                    if (ngRepeatMatch) {
                        options.model = ngRepeatMatch[4];
                    }
                }
                
                // initial animation
                element.addClass('masonry');
                
                // Wait inside directives to render
                setTimeout(function () {
                    element.masonry(options);
                    
                    element.on("$destroy", function () {
                        element.masonry('destroy')
                    });
                    
                    if (options.model) {
                        scope.$apply(function() {
                            scope.$watchCollection(options.model, function (_new, _old) {
                                if(_new == _old) return;
                                
                                // Wait inside directives to render
                                setTimeout(function () {
                                    element.masonry("reload");
                                    });
                                });
                            });
                        }
                    });
                };
            }
        };
    });

 interpreterApp.directive('timeFilter', function () {
  return {
        restrict: 'E',
            replace: true,
            template: 
            '<div class="col-sm-12">'+
            '<div class="row">'+
            '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">'+
          'Start:'+
            '<select class="custom-select" ng-model="startingHour" id="startHour" ng-change="applyTimeRangeFilter();updateTimeRange();">'+
              '<option ng-repeat="option in startingTimeHoursRange" ng-disabled="option.disabled" value="{{option.value}}">{{option.name}}</option>'+
            '</select>'+
            ':'+
            '<select class="custom-select" ng-model="startingMinute" ng-change="applyTimeRangeFilter();updateTimeRange();">'+
              '<option ng-repeat="option in startingTimeHMinutesRange" ng-disabled="option.disabled" value="{{option.value}}">{{option.name}}</option>'+
            '</select>'+
          '</div>'+
          '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">'+
            'End:'+
            '<select class="custom-select" ng-model="endingHour" ng-change="applyTimeRangeFilter();updateTimeRange();">'+
              '<option ng-repeat="option in endingTimeHoursRange" ng-disabled="option.disabled" value="{{option.value}}">{{option.name}}</option>'+
            '</select>'+
            ':'+
            '<select class="custom-select" ng-model="endingMinute" ng-change="applyTimeRangeFilter();updateTimeRange();">'+
              '<option ng-repeat="option in endingTimeHMinutesRange" ng-disabled="option.disabled" value="{{option.value}}">{{option.name}}</option>'+
            '</select>'+
        '</div>'+
        '</div>'+
      '</div>',
            scope: {
                timeSettings: '=',
                applyCallback: '&',
                clearCallback: '&'
            },
            link: function (scope) {
                var i;
                var timeHoursRange = [],
                    timeMinutesRange = [];
                scope.startingTimeHoursRange = [];
                scope.endingTimeHoursRange = [];
                scope.startingTimeHMinutesRange = [];
                scope.endingTimeHMinutesRange = [];

                scope.timeDropDownToggleState = false;

                // For hours dropdown (0 - 23)
                for (i = 0; i < 24; i++) {
                    timeHoursRange.push({
                        name: (i < 10) ? ('0' + i) : i + '',
                        value: (i < 10) ? ('0' + i) : i + ''
                    });
                }

                // For minutes dropdown (0 - 59)
                for (i = 0; i < 60; i++) {
                    timeMinutesRange.push({
                        name: (i < 10) ? ('0' + i) : i + '',
                        value: (i < 10) ? ('0' + i) : i + ''
                    });
                }

                // making a copy so each dropdown for time filter works independently
                angular.copy(timeHoursRange, scope.startingTimeHoursRange);
                angular.copy(timeHoursRange, scope.endingTimeHoursRange);

                angular.copy(timeMinutesRange, scope.startingTimeHMinutesRange);
                angular.copy(timeMinutesRange, scope.endingTimeHMinutesRange);

                /**
                 * Update the time being shown in time filter once its being updated and the req is being sent
                 */
                scope.updateTimeRangeFilter = function () {
                    scope.timeSettings.fromHour = scope.startingHour;
                    scope.timeSettings.toHour = scope.endingHour;

                    scope.timeSettings.fromMinute = scope.startingMinute;
                    scope.timeSettings.toMinute = scope.endingMinute;
                };

                /**
                 * set (00:00 - 23:59) to be the default time which is the entire time duraion for a particular day
                 */
                scope.setInitialTimeRange = function () {
                    scope.startingHour = scope.timeSettings.fromHour = scope.startingTimeHoursRange[0].value;
                    scope.endingHour = scope.timeSettings.toHour = scope.startingTimeHoursRange[23].value;

                    scope.startingMinute = scope.timeSettings.fromMinute = scope.endingTimeHMinutesRange[0].value;
                    scope.endingMinute = scope.timeSettings.toMinute = scope.endingTimeHMinutesRange[59].value;
                };
                scope.setInitialTimeRange();

                scope.updateTimeRange = function () {
                    scope.startingHour = scope.timeSettings.fromHour;
                    scope.endingHour = scope.timeSettings.toHour;

                    scope.startingMinute = scope.timeSettings.fromMinute;
                    scope.endingMinute = scope.timeSettings.toMinute;
                };

                scope.$on('updateTimeDirective', function(event, data){
                   scope.updateTimeRange();
                });


                scope.clearTimeRange = function () {
                    scope.isCustomTimeFilter = false;
                    scope.clearCallback({data: {
                        isCustomTimeFilter: scope.isCustomTimeFilter
                    }});
                    scope.closeTimeFilterDropdown();
                };

                /**
                 * Set time filter flag, update the time shown in time filter and finally update the sessions list
                 */
                scope.applyTimeRangeFilter = function () {
                    scope.isCustomTimeFilter = true;
                    scope.updateTimeRangeFilter();
                    scope.applyCallback({data: {
                        isCustomTimeFilter: scope.isCustomTimeFilter
                    }});
                    scope.closeTimeFilterDropdown();
                };
                /**
                 * CLoses time filter and reset the dropdown values if time filter is not applied
                 */
                scope.closeTimeFilterDropdown = function () {
                    scope.timeDropDownToggleState = false;

                    scope.startingHour = scope.timeSettings.fromHour;
                    scope.startingMinute = scope.timeSettings.fromMinute;
                    scope.endingHour = scope.timeSettings.toHour;
                    scope.endingMinute = scope.timeSettings.toMinute;
                };

                /**
                 * Whenever hours changed, need to validate the time (start time < end time)
                 * Also, make the items in dropdown disabled if not applicable
                 */
                scope.updateHour = function () {
                    if (scope.startingHour !== scope.endingHour) {
                        for (i = 0; i < timeMinutesRange.length; i++) {
                            scope.startingTimeHMinutesRange[i].disabled = false;
                            scope.endingTimeHMinutesRange[i].disabled = false;
                        }
                    } else if (scope.startingMinute > scope.endingMinute) {
                        scope.startingMinute = scope.endingMinute - 1;
                        if (scope.endingMinute === '00') {
                            scope.endingMinute = '01';
                        }
                        else {
                            scope.updateStartingMinuteTime();
                        }
                    } else if (scope.startingHour === scope.endingHour) {
                        scope.updateStartingMinuteTime();
                        scope.updateEndingMinuteTime();
                    }
                };

                /**
                 * Whenever starting minutes changed, need to validate the time (start time < end time)
                 * Also, make the items in dropdown disabled if not applicable
                 */
                scope.updateStartingMinuteTime = function () {
                    for (var i = 0; i < timeMinutesRange.length; i++) {
                        if (i > (parseInt(scope.endingMinute, 10) - 1) && i < timeMinutesRange.length) {
                            scope.startingTimeHMinutesRange[i].disabled = true;
                        }
                        else {
                            scope.startingTimeHMinutesRange[i].disabled = false;
                        }
                    }
                };

                /**
                 * Whenever ending minutes changed, need to validate the time (start time < end time)
                 * Also, make the items in dropdown disabled if not applicable
                 */
                scope.updateEndingMinuteTime = function () {
                    for (var i = 0; i < timeMinutesRange.length; i++) {
                        if (i >= 0 && i < (parseInt(scope.startingMinute, 10) + 1)) {
                            scope.endingTimeHMinutesRange[i].disabled = true;
                        }
                        else {
                            scope.endingTimeHMinutesRange[i].disabled = false;
                        }
                    }
                };

                scope.$watch('startingHour', function (newValue, oldValue) {
                    if (!newValue || newValue === oldValue) { return; }
                    
                    var i;
                    for (i = 0; i < timeHoursRange.length; i++) {
                        if (i >= 0 && i < parseInt(scope.startingHour, 10)) {
                            scope.endingTimeHoursRange[i].disabled = true;
                        }
                        else {
                            scope.endingTimeHoursRange[i].disabled = false;
                        }
                    }
                    scope.updateHour(scope.startingHour, scope.endingTimeHoursRange);
                });

                scope.$watch('endingHour', function (newValue, oldValue) {
                    if (!newValue || newValue === oldValue) { return; }

                    var i;
                    for (i = 0; i < timeHoursRange.length; i++) {
                        if (i > parseInt(scope.endingHour, 10) && i < timeHoursRange.length) {
                            scope.startingTimeHoursRange[i].disabled = true;
                        }
                        else {
                            scope.startingTimeHoursRange[i].disabled = false;
                        }
                    }
                    scope.updateHour(scope.endingHour, scope.startingTimeHoursRange);
                });

                scope.$watch('startingMinute', function (newValue, oldValue) {
                    if (!newValue || newValue === oldValue || scope.startingHour !== scope.endingHour) { return; }
                    scope.updateEndingMinuteTime();
                });

                scope.$watch('endingMinute', function (newValue, oldValue) {
                    if (!newValue || newValue === oldValue || scope.startingHour !== scope.endingHour) { return; }
                    scope.updateStartingMinuteTime();
                });

                // Whenevr custom time filter is reset, reset the time filter applied time and set the initial default values
                // (00:00 - 23:59)
                scope.$watch('isCustomTimeFilter', function (newValue) {
                    // if time filter is not applied / reset
                    if (!newValue) {
                        scope.setInitialTimeRange();
                    }
                });
            }
  };
});

interpreterApp.directive('googleplace', function() {
     return {
        require: 'ngModel',
        scope: {
            ngModel: '=',
            details: '=?'
        },
        link: function(scope, element, attrs, model) {
            var options = {
                types: ['(cities)'],
                componentRestrictions: {}
            };

            scope.gPlace = new google.maps.places.Autocomplete(element[0], options);

            google.maps.event.addListener(scope.gPlace, 'place_changed', function() {
                var geoComponents = scope.gPlace.getPlace();
                var latitude = geoComponents.geometry.location.lat();
                var longitude = geoComponents.geometry.location.lng();
                var addressComponents = geoComponents.address_components;

                addressComponents = addressComponents.filter(function(component){
                    switch (component.types[0]) {
                        case "locality": // city
                            $scope.user.city = component.long_name;
                            break;
                        case "administrative_area_level_1": // state
                            $scope.user.state = component.long_name;
                            break;
                        case "postal_code": //  postal_code
                            $scope.user.zipcode = component.long_name;
                            break;
                        case "country": // country
                            $scope.user.country = component.long_name;
                            break;
                        default:
                            return false;
                    }
                }).map(function(obj) {
                    return obj.long_name;
                });

                addressComponents.push(latitude, longitude);

                scope.$apply(function() {
                    scope.details = addressComponents; // array containing each location component
                    model.$setViewValue(element.val());
                });
            });
        }
    };
});

interpreterApp.directive('bindFile', [function () {
    return {
        require: "ngModel",
        restrict: 'A',
        link: function ($scope, el, attrs, ngModel) {
            el.bind('change', function (event) {
                var file = event.target.files[0];
                if(file){
                    var splitFileName = file.name.split('.');
                    var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                    if (ext == 'pdf' || ext == 'doc') {
                        if (file.size > 6291456) {
                            ngModel.$setViewValue('');
                            bootbox.alert('File size cannot exceed limit of 6 mb');
                        } else {
                            ngModel.$setViewValue(event.target.files[0]);
                            $scope.$apply();
                        }
                    } else {
                        ngModel.$setViewValue('');
                        bootbox.alert('Invalid file format, please upload a file with .pdf or .doc extension');
                    }
                }
                
            });
            
            $scope.$watch(function () {
                return ngModel.$viewValue;
            }, function (value) {
                if (!value) {
                    el.val("");
                }
            });
        }
    };
}]);

interpreterApp.filter('reverse', function() {
  return function(items) {
    return items.slice().reverse();
  };
});

interpreterApp.directive("averageStarRating", function() {
  return {
    restrict : "EA",
    template : "<div class='average-rating-container'>" +
               "  <ul class='rating background' class='readonly'>" +
               "    <li ng-repeat='star in stars' class='star'>" +
               "      <i class='fa fa-star'></i>" + //&#9733
               "    </li>" +
               "  </ul>" +
               "  <ul class='rating foreground' class='readonly' style='width:{{filledInStarsContainerWidth}}%'>" +
               "    <li ng-repeat='star in stars' class='star filled'>" +
               "      <i class='fa fa-star'></i>" + //&#9733
               "    </li>" +
               "  </ul>" +
               "</div>",
    scope : {
      averageRatingValue : "=ngModel",
      max : "=?", //optional: default is 5
    },
    link : function(scope, elem, attrs) {
      if (scope.max == undefined) { scope.max = 5; }
      function updateStars() {
        scope.stars = [];
        for (var i = 0; i < scope.max; i++) {
          scope.stars.push({});
        }
        var starContainerMaxWidth = 100; //%
        scope.filledInStarsContainerWidth = scope.averageRatingValue / scope.max * starContainerMaxWidth;
      };
      scope.$watch("averageRatingValue", function(oldVal, newVal) {
        if (newVal) { updateStars(); }
      });
    }
  };
});
