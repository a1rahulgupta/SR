  "use strict";

  angular.module("ClientLeftBar")

  interpreterApp.controller("clientLeftBarController", ['$scope', '$rootScope', '$localStorage',
      'ngTableParams', '$routeParams', '$route', '$location', '$filter', 'logger',
      'ngTableParamsService', '$state', '$stateParams', '$uibModal', 'clientDashboardService',
      function($scope, $rootScope, $localStorage, ngTableParams, $routeParams,
          $route, $location, $filter, logger, ngTableParamsService, $state, $stateParams,
          $uibModal, clientDashboardService) {
          $scope.imageBase64 = '';
          $scope.add = false;
          $scope.preview = false;
          $scope.customer = {};
          $scope.disabled = false;
          $scope.loader = false;
          //$scope.loggedInUserData = $rootScope.loggedInUserData;
          $scope.loggedInUserData = $localStorage.user;

          $scope.languageList = [
                  {
                      _id: 'Polish',
                      name: 'Polish',
                      ticked: false
                  },
                  {
                      _id: 'English',
                      name: 'English',
                      ticked: false
                  },
                  {
                      _id: 'Spanish',
                      name: 'Spanish',
                      ticked: false
                  }
              ];
              $scope.localLang = {
                  selectAll       : "Tick all",
                  selectNone      : "Tick none",
                  reset           : "Undo all",
                  search          : "Type here to search...",
                  nothingSelected : "Nothing is selected"         //default-label is deprecated and replaced with this.
              };

              $scope.getClientProfileDetailById = function(){
                $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                clientDashboardService.getClientProfileDetailById().get(function(response, err){
                    if(response.status == 1){
                        var client = response.data;
                        client.email = client.user_id.email;
                        for(var i=0;i<$scope.languageList.length;i++){
                            for (var j=0;j<client.languages.length;j++) {
                                if($scope.languageList[i].name==client.languages[j].name
                                    && client.languages[j].ticked==true){
                                    // $scope.languageList[j].ticked=true;
                                    break;
                                }
                            }
                        }
                        if(client.profile_pic!='' && client.profile_pic!=undefined){
                            $scope.userDefaultImage=client.profile_pic;
                        }
                        $scope.client = client;
                        $scope.clientName = $scope.client.first_name +' '+ $scope.client.last_name;

                    }else{
                        $scope.client = {};
                    }
                })  
              };

              $scope.expandCollapseLeftSideBar = function(){
                if (window.innerWidth > 767) {
                    
                }
                else{
                   $("body").addClass("sidebar-collapse");
                   $("body").removeClass("sidebar-open");
                }
              }

      }

  ]);


