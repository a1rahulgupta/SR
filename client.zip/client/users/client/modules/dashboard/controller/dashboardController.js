	"use strict";

	angular.module("ClientDashboard")

	interpreterApp.controller("clientDashboardController", ['$scope', '$rootScope', '$localStorage',
	    'ngTableParams', '$routeParams', '$route', '$location', '$filter', 'logger',
	    'ngTableParamsService', '$state', '$stateParams', '$uibModal', 'clientDashboardService','ClientService',
	    function($scope, $rootScope, $localStorage, ngTableParams, $routeParams,
	        $route, $location, $filter, logger, ngTableParamsService, $state, $stateParams,
	        $uibModal, clientDashboardService,ClientService) {

	    		/**
		        * Function and variable is used to check format of image upload
		        * @access private
		        * @return json
		        * Created by sunny
		        * @smartData Enterprises (I) Ltd
		        * Created Date 7-Oct-2017
		        **/
		        $scope.imageBase64 = '';
		        $scope.add = false;
		        $scope.preview = false;
		        $scope.customer = {};
		        $scope.disabled = false;
		        $scope.loader = false;
		        //$scope.loggedInUserData = $rootScope.loggedInUserData;
		        $scope.loggedInUserData = $localStorage.user;

		        $scope.myImage='';
		        $scope.myCroppedImage='';
		        $scope.isImageSelected=false;
		        $scope.isCropVisible=false;
			        var handleFileSelect=function(evt) {
			            $scope.isImageSelected=false;
			            $scope.isCropVisible=true;
			          var file=evt.currentTarget.files[0];
			          var reader = new FileReader();
			          reader.onload = function (evt) {
			            $scope.$apply(function($scope){
			              $scope.myImage=evt.target.result;
			            });
			          };
			          reader.readAsDataURL(file);
			        };
			        angular.element(document.querySelector('#fileInput')).on('change',handleFileSelect);
			        $scope.openFileBrowse = function(fileInputSelector) {
			            angular.element(document.querySelector(fileInputSelector)).trigger('click');
			        };

		        	var formDataFileUpload = '';
		        	$scope.imageBase64 = '';
			        angular.element(document).ready(function() {
			            setTimeout(function() {
			                if(document.getElementById('fileInput')!=null){
			                    document.getElementById('fileInput').addEventListener('change', function(evt) {
			                        var files = evt.target.files;
			                        var file = files[0];
			                        if (files && file) {
			                            var splitFileName = file.name.split('.');
			                            var ext = splitFileName[splitFileName.length - 1].toLowerCase();
			                            if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {
			                                if (file.size > 6291456) {
			                                    logger.log('File size cannot exceed limit of 6 mb');
			                                    document.getElementById("fileInput").value = "";
			                                } else {
			                                    formDataFileUpload = file;
			                                    // formDataFileUpload.append('file', file);
			                                    var reader = new FileReader();
			                                    reader.onload = function(readerEvt) {
			                                        $scope.imageBase64 = btoa(readerEvt.target.result);
			                                        $scope.$apply();
			                                        document.querySelector('#imgTag').src = 'data:image/' + ext + ';base64,' + $scope.imageBase64;
			                                    };
			                                    reader.readAsBinaryString(file);
			                                }
			                            } else {
			                                document.getElementById("fileInput").value = "";
			                                bootbox.alert('Invalid image format');
			                            }
			                        }
			                    });
			                }
			            }, 500);
			        });

			        $scope.localLang = {
			            selectAll       : "Tick all",
			            selectNone      : "Tick none",
			            reset           : "Undo all",
			            search          : "Type here to search...",
			            nothingSelected : "Nothing is selected"         //default-label is deprecated and replaced with this.
			        };


		        	/**
			        * Function is used to get client profile by id
			        * @access private
			        * @return json
			        * Created by sunny
			        * @smartData Enterprises (I) Ltd
			        * Created Date 7-Oct-2017
			        **/
		        	$scope.getClientProfileDetailById = function(){
			            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
	                    clientDashboardService.getClientProfileDetailById().get(function(response, err){
	                        if(response.status == 1){
	                            var client = response.data;
	                            client.email = client.email;
	                            //Multilple language status changed
	                            $scope.languageArray = angular.copy(client.languages); 
	                            //End    
	                            
	                            setTimeout(function() {
	                                for(var i=0;i<$scope.languageList.length;i++){
	                                    for (var j=0;j<client.languages.length;j++) {
	                                        if($scope.languageList[i].name == client.languages[j].name
	                                            && client.languages[j].ticked==true){
	                                            $scope.languageList[i].ticked=true;
	                                            break;
	                                        }
	                                    }
	                                }
	                                if(client.profile_pic!='' && client.profile_pic!=undefined){
	                                    $scope.userDefaultImage=client.profile_pic;
	                                }
	                                $scope.$apply();
	                            }, 500);
	                            $scope.client = client;
	                        }else{
	                            $scope.client = {};
	                        }
	                    })
			        };

		        	/**
			        * Function is used to update a prfile of client
			        * @access private
			        * @return json
			        * Created by sunny
			        * @smartData Enterprises (I) Ltd
			        * Created Date 7-Oct-2017
			        **/
			        $scope.updateClientProfile = function() {
			            if($scope.isImageSelected==true){
			                $scope.client.imageFile = $scope.myCroppedImage;
			            }
			            var client = $scope.client;
			            var languageArray = $scope.languageArray;
			            var hasFound = false;
			            var tmp = {};
			            for(var i=0; i< languageArray.length; i++){
			                hasFound = false;
			                for(var j=0; j< client.languages.length; j++){
			                    if(languageArray[i].language_id == client.languages[j]._id){
			                        hasFound = true;
			                        break;
			                    }
			                }
			                if(!hasFound){
			                    tmp = languageArray[i];
			                    tmp._id=tmp.language_id;
			                    tmp.ticked = false;
			                    client.languages.push(tmp);
			                }
			            }
			            clientDashboardService.updateClientProfile().save(client, function(response, err) {
			                if (response.status == 1) {
			                    logger.logSuccess(response.message); 
			                    $location.path('/client/dashboard');
			                } else {
			                    logger.logError(response.message);
			                }
			            });
			        };

			        $scope.dateModel = {};
	                $scope.today = function() {
	                    $scope.dt = new Date();
	                };
	                $scope.dateformat = "dd/MM/yyyy";
	                $scope.today();
	                $scope.showcalendar = function($event) {
	                    $scope.dateModel.showdp = true;
	                };
	                $scope.showcalendar1 = function($event) {
	                    $scope.dateModel.showdp1 = true;
	                };
	                $scope.dateModel.showdp = false;
	                $scope.dateModel.showdp1 = false;
	                $scope.dtmax = new Date();

	                /**
			        * Function is used to calculate age on the basis of date
			        * @access private
			        * @return json
			        * Created by ramiz
			        * @smartData Enterprises (I) Ltd
			        * Created Date 20-Dec-2017
			        **/
				    $scope.calculateAge = function(DOB) {
			            var birthDay = DOB.getDate();
			            var birthMonth = DOB.getMonth();
			            var birthYear = DOB.getFullYear();
			            var todayDate = new Date();
			            var todayYear = todayDate.getFullYear();
			            var todayMonth = todayDate.getMonth();
			            var todayDay = todayDate.getDate();
			            var age = todayYear - birthYear;

			            if (todayMonth < birthMonth - 1) {
			                age--;
			            }

			            if (birthMonth - 1 == todayMonth && todayDay < birthDay) {
			                age--;
			            }
			            $scope.client.age = age;
			            console.log("AGE", age);
		        	}

        	        /**
			        * Function is used to get all countries
			        * @access private
			        * @return json
			        * Created by ramiz
			        * @smartData Enterprises (I) Ltd
			        * Created Date 20-Dec-2017
			        **/

			        $scope.getAllCountriesInClient = function(){
			            clientDashboardService.getAllCountriesInClient().get({},function(response, err){
			                if(response.status == 1){
			                    $scope.clientCountries = response.data;
			                }else{
			                    $scope.clientCountries = {};
			                }
			            })
			        }

			        /**
			        * Function is used to get all languages in multiselect and taken from client section in agency portal 
			        * @access private
			        * @return json
			        * Created by ramiz
			        * @smartData Enterprises (I) Ltd
			        * Created Date 20-Dec-2017
			        **/
			        $scope.getAllLanguagesInClient = function(){
			            ClientService.getAllLanguagesInClient().get({},function(response, err){
			                if(response.status == 1){
			                    $scope.languageList = response.data;
			                }else{
			                    $scope.languageList = {};
			                }
			            })
			        }

			        $scope.getCountOfClient  = function(){
			            clientDashboardService.getCountOfClient().get(function(response, err){
			                if(response.status == 1){
			                	console.log("response.data",response.data);
			                    $scope.count = response.data;
			                } else{
			                    $scope.count = {};
			                }
			            })
			        }

		    }
	]);


