"use strict";

angular.module("ClientHeader")

interpreterApp.controller("clientHeaderController", ['$scope', '$rootScope', '$localStorage','$state',
    '$location', 'logger', '$uibModal', 'CommonService', 'clientDashboardService',
    function($scope, $rootScope, $localStorage, $state, $location, logger, $uibModal,
        CommonService, clientDashboardService) {

        $scope.getClientProfileDetailById = function(){
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            $scope.agencyDefaultImage = "./../../../../assets/images/logo_single.png";
            clientDashboardService.getClientProfileDetailById().get(function(response, err){
                if(response.status == 1){
                    var client = response.data;
                    if(client.profile_pic!='' && client.profile_pic!=undefined){
                        $scope.userDefaultImage=client.profile_pic;
                    }
                    if(client.agency_id.profile_pic!='' && client.agency_id.profile_pic!=undefined){
                        $scope.agencyDefaultImage = client.agency_id.profile_pic;   
                    } 
                    $scope.client = client;
                }else{
                    $scope.client = {};
                }
            })
        };

        $scope.clientChangePasswordModal = function() {
            $uibModal.open({
                templateUrl: 'client/modules/dashboard/views/clientChangePasswordModal.html',
                size: "md",
                controller: function($scope,$rootScope, $uibModalInstance,ngTableParams,ngTableParamsService) {

                    $scope.closeuib = function() {
                        $uibModalInstance.close();
                    };

                    $scope.clientChangePassword = function(form){
                        if (form.$valid) {
                            var passwordObj = {
                                oldPassword: $scope.oldPassword,
                                newPassword: $scope.newPassword
                            }
                            $scope.loader = true;
                            $scope.disabled = true;
                            if($scope.newPassword == $scope.confirmPassword){    
                                clientDashboardService.clientChangePassword().save(passwordObj, function(response) {
                                    $scope.loader = false;
                                    $scope.disabled = false;
                                    if(response.status == 1){
                                        logger.logSuccess(response.message);
                                        $scope.closeuib();
                                        $state.go('client_dashboard');
                                    }else{
                                        logger.log(response.message);
                                    }
                                })
                            }else{
                                $scope.disabled = false;
                                logger.log("Confirm password does not match with new password!");
                            }
                        }
                    };

                }
            });
        };

    }
]);
