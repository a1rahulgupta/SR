"use strict"

angular.module("ClientDashboard")

.factory('clientDashboardService', ['$http', '$resource', function($http, $resource) {

    var getUserList = function() {
        return $resource(webservices.getUserList, null, {
            save: {
                method: 'POST'
            }
        });
    }
    var getCustomerById = function() {
        return $resource(webservices.getCustomerById, null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }
    var changeCustomerStatus = function() {
        return $resource(webservices.changeCustomerStatus, null, {
            save: {
                method: 'POST'
            }
        });
    }
    var updateCustomer = function() {
        return $resource(webservices.updateCustomer, null, {
            save: {
                method: 'POST',
            }
        });
    }

    var deleteCustomer = function() {
        return $resource(webservices.deleteCustomerById, null, {
            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var getClientProfileDetailById = function() {
        return $resource(webservices.getClientProfileDetailById, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var clientChangePassword = function() {
        return $resource(webservices.clientChangePassword, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllCountriesInClient = function() {
        return $resource(webservices.getAllCountriesInClient, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getAllLanguagesInClient = function() {
        return $resource(webservices.getAllLanguagesInClient, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var updateClientProfile = function() {
        return $resource(webservices.updateClientProfile, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getCountOfClient = function() {
        return $resource(webservices.getCountOfClient, null, {
            get: {
                method: 'GET'
            }
        });
    }

    return {
        getUserList: getUserList,
        getCustomerById: getCustomerById,
        updateCustomer: updateCustomer,
        changeCustomerStatus: changeCustomerStatus,
        deleteCustomer: deleteCustomer,
        getClientProfileDetailById: getClientProfileDetailById,
        clientChangePassword: clientChangePassword,
        getAllCountriesInClient: getAllCountriesInClient,
        updateClientProfile: updateClientProfile,
        getCountOfClient: getCountOfClient
    }

}]);
