"use strict";

angular.module("Scheduler")

interpreterApp.controller("clientSchedulerController", ['$scope', '$rootScope', '$localStorage','ngTableParams',
'$routeParams', '$route', '$location', '$state', '$stateParams', 'logger', 'ngTableParamsService',
'CommonService', 'ClientSchedulerService', '$uibModal','$timeout',
function($scope, $rootScope, $localStorage, ngTableParams, $routeParams, $route, $location, $state, $stateParams, logger, ngTableParamsService,
CommonService, ClientSchedulerService, $uibModal,$timeout) {

    /* Variable is used for active class on leftbar */
    $rootScope.menuScheduler = ['client_listScheduler', 'client_listSchedulerTable', 'client_todays_booking', 'client_completed_bookings', 'client_pending_bookings', 'client_viewBookingDetails', 'client_editEvent'];
    $rootScope.menuSchedulerSubTab = ['client_listScheduler', 'client_listSchedulerTable', 'client_viewBookingDetails', 'client_editEvent'];
    $rootScope.menuSchedulerSubTab1 = ['client_todays_booking'];
    $rootScope.menuSchedulerSubTab2 = ['client_completed_bookings'];
    $rootScope.menuSchedulerSubTab3 = ['client_pending_bookings'];
    /* End */

    /* For edit set update true else false*/
    if ($state.params.id) {
        $scope.isUpdate = true;
    } else {
        $scope.isUpdate = false;
    }
    /* End */

    /* Variable needed to declare first */
    $scope.selectClient = {};
    $scope.scheduler = {};
    $scope.custom_weekly = false;
    $scope.scheduler.is_recurring = false; 
    $scope.repeat_every = false;;
    $scope.scheduler.repeating_every_no = 1;
    $scope.calendarLoader = true;
    /* End */

    /* Variables and functions used for 3 datepickers */
    $scope.dateModel = {};
    $scope.today = function() {
        $scope.dt = new Date();
    };
    $scope.dateformat = "MM/dd/yyyy";
    $scope.today();
    $scope.showcalendar = function($event) {
        $scope.dateModel.showdp = true;

    };
    $scope.showcalendar1 = function($event) {
        $scope.dateModel.showdp1 = true;
    };

    $scope.showcalendar2 = function($event) {
        $scope.dateModel.showdp2 = true;
    };

    $scope.dateModel.showdp = false;
    $scope.dateModel.showdp1 = false;
    $scope.dateModel.showdp2 = false;
    $scope.dtmax = new Date();
    /* End */

    /* Functions is used to initialize the working hours on document ready */
    $scope.initializeWorkingHours = function(){
        var currentDate = new Date();
        $scope.start_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
        $scope.start_time_full1 = new Date($scope.start_time_full.getTime() + 30*60000);
        $scope.end_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
        $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
        
        setTimeout(function(){
            angular.element(document.querySelector('#start_time_id')).trigger('change');
            angular.element(document.querySelector('#end_time_id')).trigger('change');
        },1000);
    } 
    /* End */

    /* Functions is used set timepicker on changing the time */
    $scope.fromDateChanged = function() {
        var minutesAdded = 30;
        $scope.end_time_full = new Date($scope.start_time_full.getTime() + minutesAdded*60000);
        $scope.start_time_full1 = new Date($scope.start_time_full.getTime() + minutesAdded*60000);
        $scope.minTime = new Date($scope.start_time_full.getTime() + minutesAdded*60000);
        setTimeout(function(){
            angular.element(document.querySelector('#start_time_id')).trigger('change');
            angular.element(document.querySelector('#end_time_id')).trigger('change');
        },1000);

    }
    /* End */

    /**
    * Variable and function is used to fetch all bookings on the basis of month start and end date then render on full calendar
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 5-March-2018
    **/
    $scope.eventSources = [
        function(start, end, timezone, callback) {
            var events = []; 
            var schedulerObj = {
                month_start_date: start,
                month_end_date: end
            }

            ClientSchedulerService.getAllBookings().save(schedulerObj, function(response) {
                if (response.status == 1) {
                    $scope.scheduleBookingList = response.data;
                    $scope.scheduleBookingList.forEach(function(value, index) {
                        events.push({
                            start: moment(value.start).format(), 
                            end: moment(value.end).format(), 
                            title: value.title, 
                            color: value.color,
                            EndsOn : moment(value.EndsOn).format(),
                            parentId : value.parentId,
                            bookingDetail: value.bookingDetail
                        });
                    });
                    callback(events);
                    $scope.calendarLoader = false;
                }

            });
        }
    ];
    /* End */
    
    /**
    * Function is used to set the configuration of full calendar and calling on init
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 5-March-2018
    **/        
    $scope.getScheduleBookingList = function() {
        $scope.uiConfig = {
            calendar: {           
                displayEventTime: true,             
                editable: true,
                timezone: 'local',
                nextDayThreshold: '00:00',
                views: {
                    month: {
                        eventLimit: 2
                    }
                },
                navLinks: true,
                timeFormat: 'hh:mm A',
                header:{
                    left: 'month basicWeek basicDay',
                    center: 'title',
                    right: 'today prev,next'
                },
                eventClick: function(calEvent, jsEvent, view) {
                    var eventDetailObject = calEvent.bookingDetail;
                    eventDetailObject.parent_start_date = calEvent.bookingDetail.start_date;
                    eventDetailObject.parent_end_date = calEvent.bookingDetail.end_date;
                    eventDetailObject.start_date = calEvent.start;
                    eventDetailObject.end_date = calEvent.end;
                    if(jsEvent.target.className == "removeEventClass"){
                        if(calEvent.parentId == ""){
                            var id = eventDetailObject._id;
                            bootbox.confirm('Are you sure, you want to delete this event?', function(r) {
                                if (r) {
                                    ClientSchedulerService.deleteEvent().delete({id:id},function(response, err) {
                                        if (response.status == 1) {
                                            logger.logSuccess(response.message); 
                                            $state.reload();
                                        } else {
                                            logger.logError(response.message);
                                        }
                                    }); 
                                }
                            })
                        }else{
                            $scope.viewSchedulerDeleteModel(eventDetailObject)
                        }  
                    }else{
                        if(calEvent.parentId == ""){
                            eventDetailObject.editEventName = 'single';
                            $rootScope.editCurrentEvent(eventDetailObject);
                        }else{
                            $scope.viewSchedulerEditModel(eventDetailObject)
                        }
                    }
                },
                eventDrop: $scope.alertOnDrop,
                eventResize: $scope.alertOnResize,
                eventRender : function(event, element, view) {                                                
                    element.children(".fc-content")
                    .append(`<span @click="removeEventPopupShow"
                        class="removeEventClass"
                        style="
                        float: right;
                        margin-right: 5px;
                        color: white;
                        ">X</span>`); 
                },
                eventMouseover: function (data, event, view) {                 
                    var  tooltip = '<div class="tooltiptopicevent" style="color:white;width:auto;height:auto;background:#2b2925;position:absolute;z-index:10001;padding:5px 5px 5px 5px; font-size:12px;line-height: 200%;">' + 'Title: ' + data.bookingDetail.service_title + '</br>' + 'Description: ' +  data.bookingDetail.booking_description + '</br>' + 'Starts On: ' + data.start.format("MM-DD-YYYY h:mm A") + '</br>' + 'Ends On: ' + data.end.format("MM-DD-YYYY h:mm A") +'</div>';
                    $("body").append(tooltip);
                    $(this).mouseover(function (e) {
                        $(this).css('z-index', 10000);
                        $('.tooltiptopicevent').fadeIn('500');
                        $('.tooltiptopicevent').fadeTo('10', 1.9);
                    }).mousemove(function (e) {
                        $('.tooltiptopicevent').css('top', e.pageY + 10);
                        $('.tooltiptopicevent').css('left', e.pageX + 20);
                    });
                },
                eventMouseout: function (data, event, view) {
                    $(this).css('z-index', 8);
                    $('.tooltiptopicevent').remove();
                }, 
                dayClick: function(date, allDay, jsEvent, view) {
                    var currentDate = new Date();
                    var clickedDate = new Date(date.toString());
                    currentDate.setHours(0);
                    clickedDate.setHours(0);
                    var timeDiff = clickedDate.getTime() - currentDate.getTime();
                    var diffDays = Math.round(timeDiff / (1000 * 3600 * 24));
                    if(diffDays>=0){
                        $rootScope.clickedDate = new Date(date.toString());
                        $scope.addEventModal("dc");
                    }
                }
            }
        }
    }        
    /* End */

    /**
    * Function is used to refetched full calendar events by Agency
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 5-March-2018
    **/
    $scope.getBookingOnClientSelection = function(){
        $('#providerDiv').fullCalendar('refetchEvents');
    }

    /**
    * Function is used to get booking list of an client
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 18-Sep-2017
    **/
    $rootScope.getClientBookingList = function() {
        ngTableParamsService.set('', '', '', '');
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                $scope.paramUrl = params.url();
                $scope.bookingList = [];
                ClientSchedulerService.getClientBookingList().save($scope.paramUrl, function(response, err) {
                    if (response.status == 1) {
                        $scope.tableLoader = false;
                        $scope.bookingList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.count;
                        params.total(response.count);
                        $defer.resolve(data);
                    } else {
                        logger.logError(response.message);
                    }
                });
            }
        });
    };

    /**
    * Function is used to get booking list of an agency by searching
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 18-Sep-2017
    **/
    $scope.getBookingListSearching = function(searchTextField) {
        ngTableParamsService.set('', '', searchTextField, '');
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                $scope.paramUrl = params.url();
                $scope.bookingList = [];
                ClientSchedulerService.getClientBookingList().save($scope.paramUrl, function(response) {
                    if (response.status == 1) {
                        $scope.bookingList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.count;
                        params.total(response.count);
                        $defer.resolve(data);
                    } else {
                        logger.logError(response.message);
                    }
                });
            }
        })
    };
    /* End */

    /**
    * Function is used to get today's booking list of an client
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 03-Apr-2018
    **/
    $rootScope.getTodaysClientBookingList = function() {
        ngTableParamsService.set('', '', '', '');
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                $scope.paramUrl = params.url();
                $scope.bookingList = [];
                ClientSchedulerService.getTodaysClientBookingList().save($scope.paramUrl, function(response, err) {
                    if (response.status == 1) {
                        $scope.tableLoader = false;
                        $scope.bookingList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.count;
                        params.total(response.count);
                        $defer.resolve(data);
                    } else {
                        logger.logError(response.message);
                    }
                });
            }
        });
    };
    /* End */

    /**
    * Function is used to get completed booking list of an client
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 18-Sep-2017
    **/
    $rootScope.getClientCompletedBooking = function() {
        ngTableParamsService.set('', '', '', '');
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                $scope.paramUrl = params.url();
                $scope.bookingList = [];
                ClientSchedulerService.getClientCompletedBooking().save($scope.paramUrl, function(response, err) {
                    if (response.status == 1) {
                        $scope.tableLoader = false;
                        $scope.bookingList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.count;
                        params.total(response.count);
                        $defer.resolve(data);
                    } else {
                        logger.logError(response.message);
                    }
                });
            }
        });
    };
    /* End */

     /**
    * Function is used to get pending booking list of an client
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 18-Sep-2017
    **/
    $rootScope.getClientPendingBookings = function() {
        ngTableParamsService.set('', '', '', '');
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                $scope.paramUrl = params.url();
                var before_week_date = new Date();
                before_week_date.setDate(before_week_date.getDate() - 8);
                var yesterday_date = new Date();
                yesterday_date.setDate(yesterday_date.getDate() - 1);
                $scope.paramUrl.before_week_date = before_week_date;
                $scope.paramUrl.yesterday_date = yesterday_date;
                $scope.bookingList = [];
                ClientSchedulerService.getClientPendingBookings().save($scope.paramUrl, function(response, err) {
                    if (response.status == 1) {
                        $scope.tableLoader = false;
                        $scope.bookingList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.count;
                        params.total(response.count);
                        $defer.resolve(data);
                    } else {
                        logger.logError(response.message);
                    }
                });
            }
        });
    };
    /* End */

    /**
    * Function is search bookings with in the range of two dates 
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 18-Sep-2017
    **/
    $scope.searchBookingByDate = function() {
        var date = {};
        date.searchFrom = $scope.bookingFrom;
        date.searchTo = $scope.bookingTo;
        ngTableParamsService.set('', '', '', '');
        $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
            getData: function($defer, params) {
                ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                $scope.paramUrl = params.url();
                $scope.tableLoader = true;
                $scope.bookingList = [];
                $scope.paramUrl.searchFrom = $scope.bookingFrom;
                $scope.paramUrl.searchTo = $scope.bookingTo;
                ClientSchedulerService.searchBookingByDateScheduler().save($scope.paramUrl, function(response, err) {
                    if (response.status == 1) {
                        $scope.tableLoader = false;
                        $scope.bookingList = response.data;
                        var data = response.data;
                        $scope.totalCount = response.count;
                        params.total(response.count);
                        $defer.resolve(data);
                    } else {
                        logger.logError(response.message);
                    }
                });
            }
        });
    };
    
    /* Function is used to clear the dates input and reload the state */
    $scope.clearSearch = function(){
        $scope.bookingFrom = "";
        $scope.bookingTo = "";
        $state.reload();
    }
    /* End */

    /* Function is used to view booking on click of tabular row */
    $scope.viewBooking = function(booking) {
        $state.go('client_viewBookingDetails', {id:booking._id});
    };
    /* End */    
    
    /**
    * Function is used to get booking detail for view using booking id 
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 18-Sep-2017
    **/
    $scope.getBookingViewByClientId = function(){
        if($stateParams.id){
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            ClientSchedulerService.getBookingViewByClientId().get({id:$stateParams.id},function(response, err){
                if(response.status == 1){
                    var booking = response.data;
                    var repeating_interval; 
                    if(booking.recurrence_rule == 'daily'){
                        $scope.repeating_interval = 'Day'
                    }else if(booking.recurrence_rule == 'weekly' || booking.recurrence_rule == 'custom (weekly)'){
                        $scope.repeating_interval = 'Week'
                    }else if(booking.recurrence_rule == 'monthly'){
                        $scope.repeating_interval = 'Month'
                    }else{
                        $scope.repeating_interval = 'Year'
                    }
                    booking.start_date = new Date(moment(booking.start_date));
                    booking.end_date = new Date(moment(booking.end_date));
                    if(booking.interpreter_id && booking.interpreter_id.profile_pic!='' && booking.interpreter_id.profile_pic!=undefined){
                        $scope.userDefaultImage = booking.interpreter_id.profile_pic;
                    }

                    $scope.booking = booking;
                    $scope.getPlace(booking.lat,booking.lng,booking.address);
                }
            })
        }
    } 
    /* End */

    /* Functions and variables is used for map load and get lat/long on the basis of google place address bar selection */
    var infowindow,marker,infowindowContent,autocomplete,map;
    $scope.initMap = function () {

        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: 41.310726, lng: -72.929916},
          zoom: 15,
        });

        var input = document.getElementById('pac-input');

        autocomplete = new google.maps.places.Autocomplete(input);
        autocomplete.bindTo('bounds', map);
        infowindow = new google.maps.InfoWindow();
        infowindowContent = document.getElementById('infowindow-content');
        infowindow.setContent(infowindowContent);
        marker = new google.maps.Marker({
          map: map
        });

        autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
        function selectFirstAddress (input) {
            google.maps.event.trigger(input, 'keydown', {keyCode:40});
            // google.maps.event.trigger(input, 'keydown', {keyCode:13});
        }
        angular.element(document).on('focusout', '#pac-input', function() {
            selectFirstAddress(this);
        });
    }

    $scope.fetchAutocomplete = function(){
        infowindow.close();
        marker.setVisible(false);
        var place = autocomplete.getPlace();
        if (!place.geometry) {
            // User entered the name of a Place that was not suggested and
            // pressed the Enter key, or the Place Details request failed.
            window.alert("No details available for input: '" + place.name + "'");
            return;
        }
        var lat = place.geometry.location.lat();
        var lng = place.geometry.location.lng();
        var address = place.formatted_address;
        $scope.lat = lat;
        $scope.lng = lng;
        // If the place has a geometry, then present it on a map.
        if (place.geometry.viewport) {
            map.fitBounds(place.geometry.viewport);
        } else {
            map.setCenter(place.geometry.location);
            map.setZoom(15);  // Why 17? Because it looks good.
        }
        marker.setPosition(place.geometry.location);
        marker.setVisible(true);

        infowindowContent.children['place-icon'].src = place.icon;
        infowindowContent.children['place-name'].textContent = place.name;
        infowindowContent.children['place-address'].textContent = address;
        var address_long_name =  place.address_components[0].long_name; 
        if(address_long_name == place.name){
            $scope.scheduler.address = address;     
        }else{
            $scope.scheduler.address = place.name  + ', '+ address;
        }

        $scope.$apply();
        infowindow.open(map, marker);
    }
    /* End */

    /* Functions is used to set place in map while edit or view on the basis of lat/long and address */
    $scope.getPlace = function(lat,lng,address) {
        var latlng = new google.maps.LatLng(lat, lng);
        var geocoder = new google.maps.Geocoder();
        geocoder.geocode({'latLng': latlng}, function(results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[1]) { 
                    marker = new google.maps.Marker({
                        position: latlng,
                        map: map
                    });

                    map.setCenter(marker.getPosition());
                    map.setZoom(15); 
                    $scope.lat = lat;
                    $scope.lng = lng;
                    infowindowContent.children['place-address'].textContent = address;
                    marker.setIcon(null);
                    infowindow.open(map, marker);
                }else {
                //handle error status accordingly
                }
            }
        })
    }
    /* End */

    /* Functions is used to get all languages in dropdown */
    $scope.getAllLanguagesInBookingModal = function(){
        ClientSchedulerService.getAllLanguagesInBooking().get({},function(response, err){
            if(response.status == 1){
                $scope.agencyLanguages = response.data;
            }else{
                $scope.agencyLanguages = {};
            }
        })
    }
    /* End */

    /* Functions is used to get event names in repeat dropdown */
    $scope.getEventName = function(){
        ClientSchedulerService.getEventName().get({},function(response, err){
            if(response.status == 1){
                $scope.events = response.data;
            }else{
                $scope.events = {};
            }
        })  
    }
    /* End */

    /* Functions is used for clear the field which is not needed in non-recurring*/        
    $scope.clearRepeatEndsOnField = function(){
        $scope.scheduler.event_id = undefined;
        $scope.scheduler.event_end_date = undefined;
        $scope.repeat_every = false;
        $scope.custom_weekly = false;
        $scope.scheduler.repeating_every_no = undefined;
    }
    /* End */

    /* Functions is used to check all event name on selection of event in repeat dropdown */
    $scope.checkEventName = function(event_id){
        var events = $scope.events;
        events.forEach(function(value, index) {
            if(value.event_name == 'custom (weekly)'){
                if(value._id == event_id){
                    $scope.custom_weekly = true;
                    $scope.scheduler.custom_weekly_repeat_on.sunday = false;
                    $scope.scheduler.custom_weekly_repeat_on.monday = false;
                    $scope.scheduler.custom_weekly_repeat_on.tuesday = false;
                    $scope.scheduler.custom_weekly_repeat_on.wednesday = false;
                    $scope.scheduler.custom_weekly_repeat_on.thursday = false;
                    $scope.scheduler.custom_weekly_repeat_on.friday = false;
                    $scope.scheduler.custom_weekly_repeat_on.saturday = false;
                    $scope.repeat_event_name = value.event_name;
                    $scope.repeat_every = true;
                    $scope.scheduler.repeating_every_no = "1";
                    return;
                }else{
                    $scope.custom_weekly = false;
                    $scope.scheduler.custom_weekly_repeat_on.sunday = false;
                    $scope.scheduler.custom_weekly_repeat_on.monday = false;
                    $scope.scheduler.custom_weekly_repeat_on.tuesday = false;
                    $scope.scheduler.custom_weekly_repeat_on.wednesday = false;
                    $scope.scheduler.custom_weekly_repeat_on.thursday = false;
                    $scope.scheduler.custom_weekly_repeat_on.friday = false;
                    $scope.scheduler.custom_weekly_repeat_on.saturday = false;
                }
            }else if(value._id == event_id){
                if($scope.scheduler.start_date != undefined){
                    var d = new Date($scope.scheduler.start_date);
                    var year = d.getFullYear();
                    var month = d.getMonth();
                    var day = d.getDate();
                    var c;
                    if(value.event_name == 'daily'){
                        c = new Date(year + 1, month, day);
                    }else if(value.event_name == 'weekly'){
                        c = new Date(year + 2, month, day);
                    }else if(value.event_name == 'monthly'){
                        c = new Date(year + 5, month, day);
                    }else if(value.event_name == 'yearly'){
                        c = new Date(year + 10, month, day);
                    }else if(value.event_name == 'custom (weekly)'){
                        c = new Date(year + 2, month, day);
                    }   
                    $scope.maxiDate = c;
                }
                $scope.repeat_event_name = value.event_name;
                $scope.repeat_every = true;
                $scope.scheduler.repeating_every_no = "1";
            }else{
                return;
            }
        })      
    }
    /* End */

    /* Function is used to check event name and validate some input fields during edit event details by id */
    $scope.checkEventName1 = function(event_id){
        var events = $scope.events;
        events.forEach(function(value, index) {
            if(value.event_name == 'custom (weekly)'){
                if(value._id == event_id){
                    $scope.custom_weekly = true;
                    $scope.repeat_event_name = value.event_name;
                    return;
                }else{
                    $scope.custom_weekly = false;
                }
            }else{
                return;
            }
        })      
    }
    /* End */

    /* Functions is used to validate event end date on the basis of start date selection */
    $scope.setEventEndDate = function(start_date){
        var d = new Date(start_date);
        var year = d.getFullYear();
        var month = d.getMonth();
        var day = d.getDate();
        if($scope.repeat_event_name == 'daily'){
            var c = new Date(year + 1, month, day);
        }else if($scope.repeat_event_name == 'weekly'){
            var c = new Date(year + 2, month, day);
        }else if($scope.repeat_event_name == 'monthly'){
            var c = new Date(year + 5, month, day);
        }else if($scope.repeat_event_name == 'yearly'){
            var c = new Date(year + 10, month, day);
        }else if($scope.repeat_event_name == 'custom (weekly)'){
            var c = new Date(year + 2, month, day);
        }   
        $scope.maxiDate = c; 
    }   
    /* End */

    /**
    * Function is used to add booking by agency 
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 5-Mar-2018
    **/
    $scope.addEventByClient = function(form){
        if (form.$valid) {
            $scope.loader = true;
            $scope.disabled = true;
            
            $scope.scheduler.lat = $scope.lat;
            $scope.scheduler.lng = $scope.lng;

            var tmpStartTime = CommonService.convertTo24Format($scope.scheduler.start_time);
            var tmpEndTime = CommonService.convertTo24Format($scope.scheduler.end_time);

            //Set Start Date
            var new_start_date =  new Date($scope.scheduler.start_date);
            new_start_date.setHours(tmpStartTime.hour);
            new_start_date.setMinutes(tmpStartTime.minute);
            $scope.scheduler.start_date = new_start_date; 
            //End

            //Set End Date
            var new_end_date =  new Date($scope.scheduler.end_date);
            new_end_date.setHours(tmpEndTime.hour);
            new_end_date.setMinutes(tmpEndTime.minute);
            $scope.scheduler.end_date = new_end_date; 
            //End

            //Set End Event Date
            if($scope.scheduler.is_recurring == true ){
                var new_event_end_date =  new Date($scope.scheduler.event_end_date);
                new_event_end_date.setHours(tmpEndTime.hour);
                new_event_end_date.setMinutes(tmpEndTime.minute);
                $scope.scheduler.event_end_date = new_event_end_date; 
            }
            
            console.log("$scope.scheduler",$scope.scheduler);
            ClientSchedulerService.addEventByClient().save($scope.scheduler, function(response, err) {
                var errorMessage = '';
                $scope.disabled = false;
                $scope.loader = false;
                if (response.status == 1) {
                    logger.logSuccess(response.message);
                    $state.go('client_listSchedulerTable');
                } else {
                    logger.logError(response.message);
                }
            });
        }else{
            logger.logError("You have missed the required fields to fill the form.");
        }
    }
    /* End */

    /**
    * Function is used to get booking for edit using booking id 
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 5-Mar-2018
    **/
    $scope.getEventById = function(){
        /* Variables is used to initialize the working hours on document ready */
        var currentDate = new Date();
        $scope.start_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
        $scope.start_time_full1 = new Date($scope.start_time_full.getTime() + 30*60000);
        $scope.end_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
        $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
        
        setTimeout(function(){
            angular.element(document.querySelector('#start_time_id')).trigger('change');
            angular.element(document.querySelector('#end_time_id')).trigger('change');
        },1000);           
        /* End */

        if($stateParams.id){
            ClientSchedulerService.getEventById().get({id:$stateParams.id},function(response, err){
                if(response.status == 1){
                    var scheduler = response.data;
                    scheduler.start_date = new Date(moment(scheduler.start_date));
                    scheduler.end_date = new Date(moment(scheduler.end_date));
                    var tmpTime;
                    if(scheduler.start_time){
                        tmpTime = CommonService.convertTo24Format(scheduler.start_time);
                        $scope.start_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                        $scope.start_time_full1 = new Date($scope.start_time_full.getTime() + 30*60000);
                        $scope.minTime = $scope.start_time_full1;
                    }
                    if(scheduler.end_time){
                        tmpTime = CommonService.convertTo24Format(scheduler.end_time);
                        $scope.end_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                    }
                    if(scheduler.repeating_every_no && scheduler.repeating_every_no != null && scheduler.is_recurring == true){
                        $scope.repeat_every = true;
                        ClientSchedulerService.getEventName().get({},function(response, err){
                            if(response.status == 1){
                                $scope.events = response.data;
                                if($scope.events){
                                    $scope.checkEventName1(scheduler.event_id);
                                }
                            }else{
                                $scope.events = {};
                            }
                         }) 
                    }else{
                        $scope.repeat_every = false;
                    }
                    $scope.repeat_every = true;
                    $scope.scheduler = scheduler;
                    $scope.getPlace(scheduler.lat, scheduler.lng, scheduler.address);
                    
                }else{
                    logger.logError(response.message);
                    $state.go('agency_listSchedulerTable');
                }
            })
        }
    }
    /* End */

    /**
    * Function is used to update booking by Client 
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 5-Mar-2018
    **/
    $scope.updateEventbyClient = function() {
        // if ($scope.form.$valid) {
        $scope.scheduler.lat = $scope.lat;
        $scope.scheduler.lng = $scope.lng;

        var tmpStartTime = CommonService.convertTo24Format($scope.scheduler.start_time);
        var tmpEndTime = CommonService.convertTo24Format($scope.scheduler.end_time);

        //Set Start Date
        var new_start_date =  new Date($scope.scheduler.start_date);
        new_start_date.setHours(tmpStartTime.hour);
        new_start_date.setMinutes(tmpStartTime.minute);
        $scope.scheduler.start_date = new_start_date; 
        //End

        //Set End Date
        var new_end_date =  new Date($scope.scheduler.end_date);
        new_end_date.setHours(tmpEndTime.hour);
        new_end_date.setMinutes(tmpEndTime.minute);
        $scope.scheduler.end_date = new_end_date; 
        //End

        //Set End Event Date
        if($scope.scheduler.is_recurring == true ){
            var new_event_end_date =  new Date($scope.scheduler.event_end_date);
            new_event_end_date.setHours(tmpEndTime.hour);
            new_event_end_date.setMinutes(tmpEndTime.minute);
            $scope.scheduler.event_end_date = new_event_end_date; 
        }else{
            $scope.scheduler.event_id = undefined;
            $scope.scheduler.event_end_date = undefined;
            $scope.scheduler.repeating_every_no = undefined;
        }

        $scope.scheduler.editEventName = 'series';
        console.log("scope.scheduler", $scope.scheduler);
        ClientSchedulerService.updateCurrentOccurenceEvent().save($scope.scheduler, function(response, err) {
            if (response.status == 1) {
                logger.logSuccess(response.message); 
                $state.go('client_listSchedulerTable');
            } else {
                logger.logError(response.message);
            }
        });
    }
    /* End */

    /**
    * Function is used to delete booking by Client 
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 5-Mar-2018
    **/
    $scope.deleteEvent = function(id, $event) {
        $event.stopPropagation();
        bootbox.confirm('Are you sure, you want to delete this event?', function(r) {
            if (r) {
                ClientSchedulerService.deleteEvent().delete({id:id},function(response, err) {
                    if (response.status == 1) {
                        logger.logSuccess(response.message); 
                        $scope.getClientBookingList();
                    } else {
                        logger.logError(response.message);
                    }
                });
            }
        })
    }
    /* End */

    /* Function is uesd to initialize map on interpreter assignment */
    $scope.initilizeMap = function(){
        var map;
        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: 41.310726, lng: -72.929916},
          zoom: 13
        });
    }
    /* End */

    /* Function is uesd to set the rating on the basis of rating value */
    $scope.testFunc = function(rating){
        var displatRating=[];
        for(var i=0;i<5;i++){
          if(rating-i>=1){
            displatRating.push({starType:'fa-star'}); 
          }else if(rating-i<1 && rating-i>0){
            displatRating.push({starType:'fa-star-half-o'}); 
          }else{
            displatRating.push({starType:'fa-star-o'}); 
          }
        }
        return displatRating;
    }
    /* End */

    /**
    * Function is used to get booking and interpreters location and showing on assign interpreter form 
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 5-Mar-2018
    **/
    $scope.getBookingInterpretersLocation = function() {
        if($stateParams.id){
            var locationMarker = {
                radiusInMeter: $scope.radiusInMeter ? parseFloat($scope.radiusInMeter) * 1609.34 : 1609.34, //1 Mile = 1609.34 meter
                id: $stateParams.id 
            }
            
            SchedulerService.getEventInterpretersLocation().save(locationMarker,function(response, err){
                if(response.status == 1){
                    if(response.interpretersArray.length == 0){
                        logger.log(response.message);
                    }
                    var booking = response.data;
                    $scope.booking = booking;
                    // console.log("booking data", $scope.booking);
                    $scope.interpretersArray = response.interpretersArray;
                    var interpretersData = response.interpretersData; 
                    var selectedInterpretersArray = response.selectedInterpretersArray;
                    for(var i=0; i< interpretersData.length; i++){
                        var rate = interpretersData[i].rate;
                        interpretersData[i].ratingArr = $scope.testFunc(rate);
                    }
                    $scope.interpretersData = interpretersData;
                    for(var i=0; i< selectedInterpretersArray.length; i++){
                        var rate = selectedInterpretersArray[i].interpreter_id.rate;
                        selectedInterpretersArray[i].interpreter_id.ratingArr = $scope.testFunc(rate);
                    }
                    $scope.selectedInterpretersArray = selectedInterpretersArray;
                    $scope.radiusInMeter = $scope.radiusInMeter ? $scope.radiusInMeter : 1;
                    // Locate the booking location and check-in location in map
                    var bookingPoint = {
                        point: new google.maps.LatLng(booking.lat,booking.lng),
                        radius: locationMarker.radiusInMeter,
                        color: '#00AA00',
                    }
                                           
                    var zoom = 13;
                    var map;
                    var elevator;
                    var mapOptions = {
                        zoom: zoom,
                        center: bookingPoint.point,
                        mapTypeId: google.maps.MapTypeId.ROADMAP,
                    };
                    map = new google.maps.Map(document.getElementById('map'), mapOptions);
                    //render the range
                    var subjectMarker = new google.maps.Marker({
                        map: map,
                        position: bookingPoint.point,
                        title: 'Booking Location'
                    });
                    var subjectRange = new google.maps.Circle({
                        map: map,
                        radius: bookingPoint.radius,    // metres
                        fillColor: bookingPoint.color,
                    });
                    subjectRange.bindTo('center', subjectMarker, 'position');
                    
                    //render the geolocation
                    for (var i = 0; i < response.interpretersArray.length; i++){
                        var point = new google.maps.LatLng(response.interpretersArray[i].lat,response.interpretersArray[i].lng);
                        var marker = new google.maps.Marker({
                            map: map,
                            position: point,
                            title: response.interpretersArray[i].first_name+ ' ' + response.interpretersArray[i].last_name
                        });
                    }
                    //End

                }
            })
        }else{
            $state.go('agency_listSchedulerTable');
        }
    }
    /* End */

    /**
    * Uib modal is used for add event modal pop-up on full calendar and performing related operations
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 18-Sep-2017
    **/
    $scope.addEventModal = function(data) {
        $uibModal.open({
            templateUrl: 'client/modules/scheduler/views/addEventModal.html',
            size: "lg",
            controller: function($scope,$rootScope, $uibModalInstance) {
                /* Needed variable to declare first */
                $scope.scheduler = {};
                $scope.custom_weekly = false;
                $scope.scheduler.is_recurring = false;
                $scope.scheduler.custom_weekly_repeat_on = {};
                /* End */

                /* Variables and functions used for 3 datepickers */
                $scope.dateModel = {};
                $scope.dateformat = "MM/dd/yyyy";
                $scope.today = function() {
                    $scope.dt = new Date();
                };
                $scope.today();
                $scope.showcalendar = function($event) {
                    $scope.dateModel.showdp = true;

                };
                $scope.showcalendar1 = function($event) {
                    $scope.dateModel.showdp1 = true;
                };

                $scope.showcalendar2 = function($event) {
                    $scope.dateModel.showdp2 = true;
                };

                $scope.dateModel.showdp = false;
                $scope.dateModel.showdp1 = false;
                $scope.dateModel.showdp2 = false;
                $scope.dtmax = new Date();
                /* End */
                
                /* Function used for close modal pop-up */
                $scope.closeuib = function() {
                    $uibModalInstance.close();
                }
                /* End */

                /* Functions is used to initialize the working hours on document ready */
                $scope.initializeWorkingHours = function(){
                    if(data == 'dc'){
                        $scope.scheduler.start_date = $rootScope.clickedDate;
                        $scope.scheduler.end_date = $rootScope.clickedDate;
                    }
                    var currentDate = new Date();
                    $scope.start_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
                    $scope.start_time_full1 = new Date($scope.start_time_full.getTime() + 30*60000);
                    $scope.end_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
                    $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                    
                    setTimeout(function(){
                        angular.element(document.querySelector('#start_time_id')).trigger('change');
                        angular.element(document.querySelector('#end_time_id')).trigger('change');
                    },1000);
                } 
                /* End */

                /* Functions is used set timepicker on changing the time */
                $scope.fromDateChanged = function() {
                    var minutesAdded = 30;
                    $scope.end_time_full = new Date($scope.start_time_full.getTime() + minutesAdded*60000);
                    $scope.start_time_full1 = new Date($scope.start_time_full.getTime() + minutesAdded*60000);
                    $scope.minTime = new Date($scope.start_time_full.getTime() + minutesAdded*60000);
                    setTimeout(function(){
                        angular.element(document.querySelector('#start_time_id')).trigger('change');
                        angular.element(document.querySelector('#end_time_id')).trigger('change');
                    },1000);

                } 
                /* End */

                /* Functions is used for clear the field which is not needed in non-recurring*/
                $scope.clearRepeatEndsOnField = function(){
                    $scope.scheduler.event_id = undefined;
                    $scope.scheduler.event_end_date = undefined;
                    $scope.repeat_every = false;
                    $scope.custom_weekly = false;
                    $scope.scheduler.repeating_every_no = undefined;
                }
                /* End */ 

                /* Functions is used to get event names in repeat dropdown */
                $scope.getEventName = function(){
                    var booking = {};
                    ClientSchedulerService.getEventName().get({},function(response, err){
                        if(response.status == 1){
                            $scope.events = response.data;
                        }else{
                            $scope.events = {};
                        }
                    })  
                }
                /* End */

                /* Functions is used to get all languages in dropdown */
                $scope.getAllLanguagesInBookingModal = function(){
                    ClientSchedulerService.getAllLanguagesInBooking().get({},function(response, err){
                        if(response.status == 1){
                            $scope.agencyLanguages = response.data;
                        }else{
                            $scope.agencyLanguages = {};
                        }
                    })
                }
                /* End */

                /* Functions is used to check all event name on selection of event in repeat dropdown */
                $scope.checkEventName = function(event_id){
                    var events = $scope.events;
                    events.forEach(function(value, index) {
                        if(value.event_name == 'custom (weekly)'){
                            if(value._id == event_id){
                                $scope.custom_weekly = true;
                                $scope.scheduler.custom_weekly_repeat_on.sunday = false;
                                $scope.scheduler.custom_weekly_repeat_on.monday = false;
                                $scope.scheduler.custom_weekly_repeat_on.tuesday = false;
                                $scope.scheduler.custom_weekly_repeat_on.wednesday = false;
                                $scope.scheduler.custom_weekly_repeat_on.thursday = false;
                                $scope.scheduler.custom_weekly_repeat_on.friday = false;
                                $scope.scheduler.custom_weekly_repeat_on.saturday = false;
                                $scope.repeat_event_name = value.event_name;
                                $scope.repeat_every = true;
                                $scope.scheduler.repeating_every_no = "1";
                                return;
                            }else{
                                $scope.custom_weekly = false;
                                $scope.scheduler.custom_weekly_repeat_on.sunday = false;
                                $scope.scheduler.custom_weekly_repeat_on.monday = false;
                                $scope.scheduler.custom_weekly_repeat_on.tuesday = false;
                                $scope.scheduler.custom_weekly_repeat_on.wednesday = false;
                                $scope.scheduler.custom_weekly_repeat_on.thursday = false;
                                $scope.scheduler.custom_weekly_repeat_on.friday = false;
                                $scope.scheduler.custom_weekly_repeat_on.saturday = false;
                            }
                        }else if(value._id == event_id){
                            if($scope.scheduler.start_date != undefined){
                                var d = new Date($scope.scheduler.start_date);
                                var year = d.getFullYear();
                                var month = d.getMonth();
                                var day = d.getDate();
                                var c;
                                if(value.event_name == 'daily'){
                                    c = new Date(year + 1, month, day);
                                }else if(value.event_name == 'weekly'){
                                    c = new Date(year + 2, month, day);
                                }else if(value.event_name == 'monthly'){
                                    c = new Date(year + 5, month, day);
                                }else if(value.event_name == 'yearly'){
                                    c = new Date(year + 10, month, day);
                                }else if(value.event_name == 'custom (weekly)'){
                                    c = new Date(year + 2, month, day);
                                }   
                                $scope.maxiDate = c;
                            }
                            $scope.repeat_event_name = value.event_name;
                            $scope.repeat_every = true;
                            $scope.scheduler.repeating_every_no = "1";
                        }else{
                            return;
                        }
                    })      
                }
                /* End */

                /* Functions is used to validate event end date on the basis of start date selection */
                $scope.setEventEndDate = function(start_date){
                    var d = new Date(start_date);
                    var year = d.getFullYear();
                    var month = d.getMonth();
                    var day = d.getDate();
                    if($scope.repeat_event_name == 'daily'){
                        var c = new Date(year + 1, month, day);
                    }else if($scope.repeat_event_name == 'weekly'){
                        var c = new Date(year + 2, month, day);
                    }else if($scope.repeat_event_name == 'monthly'){
                        var c = new Date(year + 5, month, day);
                    }else if($scope.repeat_event_name == 'yearly'){
                        var c = new Date(year + 10, month, day);
                    }else if($scope.repeat_event_name == 'custom (weekly)'){
                        var c = new Date(year + 2, month, day);
                    }   
                    $scope.maxiDate = c; 
                }
                /* End */

                /* Function is used to refetched full calendar events by Agency */
                $scope.getBookingOnClientSelection = function(){
                    $('#providerDiv').fullCalendar('refetchEvents');
                }
                /* End */

                /* Functions is used to add event by client */
                $scope.addEventByClient = function(form){
                    if (form.$valid) {
                        $scope.loader = true;
                        $scope.disabled = true;
                        
                        $scope.scheduler.lat = $scope.lat;
                        $scope.scheduler.lng = $scope.lng;

                        var tmpStartTime = CommonService.convertTo24Format($scope.scheduler.start_time);
                        var tmpEndTime = CommonService.convertTo24Format($scope.scheduler.end_time);

                        //Set Start Date
                        var new_start_date =  new Date($scope.scheduler.start_date);
                        new_start_date.setHours(tmpStartTime.hour);
                        new_start_date.setMinutes(tmpStartTime.minute);
                        $scope.scheduler.start_date = new_start_date; 
                        //End

                        //Set End Date
                        var new_end_date =  new Date($scope.scheduler.end_date);
                        new_end_date.setHours(tmpEndTime.hour);
                        new_end_date.setMinutes(tmpEndTime.minute);
                        $scope.scheduler.end_date = new_end_date; 
                        //End

                        //Set Event End Date
                        if($scope.scheduler.is_recurring == true ){
                            var new_event_end_date =  new Date($scope.scheduler.event_end_date);
                            new_event_end_date.setHours(tmpEndTime.hour);
                            new_event_end_date.setMinutes(tmpEndTime.minute);
                            $scope.scheduler.event_end_date = new_event_end_date; 
                        }
                        
                        console.log("$scope.scheduler",$scope.scheduler);
                        ClientSchedulerService.addEventByClient().save($scope.scheduler, function(response, err) {
                            var errorMessage = '';
                            $scope.disabled = false;
                            $scope.loader = false;
                            if (response.status == 1) {
                                logger.logSuccess(response.message);
                                $scope.closeuib(); 
                                $scope.getBookingOnClientSelection();
                            } else {
                                logger.logError(response.message);

                            }
                        });
                    }else{
                        logger.logError("You have missed the required fields to fill the form.");
                    }
                }
                /* End */

                /* Functions and variables is used for map load and get lat/long on the basis of google place address bar selection */
                var infowindow,marker,infowindowContent,autocomplete,map;
                $scope.initMap = function () {

                    map = new google.maps.Map(document.getElementById('map'), {
                      center: {lat: 41.310726, lng: -72.929916},
                      zoom: 15,
                    });

                    var input = document.getElementById('pac-input');
                    autocomplete = new google.maps.places.Autocomplete(input);
                    autocomplete.bindTo('bounds', map);
                    infowindow = new google.maps.InfoWindow();
                    infowindowContent = document.getElementById('infowindow-content');
                    infowindow.setContent(infowindowContent);
                    marker = new google.maps.Marker({
                      map: map
                    });

                    setTimeout(function() {
                       google.maps.event.trigger(map, 'resize');
                    }, 1000);
                    autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
                    function selectFirstAddress (input) {
                        google.maps.event.trigger(input, 'keydown', {keyCode:40});
                        // google.maps.event.trigger(input, 'keydown', {keyCode:13});
                    }
                    angular.element(document).on('focusout', '#pac-input', function() {
                        selectFirstAddress(this);
                    });
                    
                }

                $scope.fetchAutocomplete = function(){
                    infowindow.close();
                    marker.setVisible(false);
                    var place = autocomplete.getPlace();
                    if (!place.geometry) {
                        // User entered the name of a Place that was not suggested and
                        // pressed the Enter key, or the Place Details request failed.
                        window.alert("No details available for input: '" + place.name + "'");
                        return;
                    }
                    var lat = place.geometry.location.lat();
                    var lng = place.geometry.location.lng();
                    var address = place.formatted_address;
                    $scope.lat = lat;
                    $scope.lng = lng;
                    // If the place has a geometry, then present it on a map.
                    if (place.geometry.viewport) {
                        map.fitBounds(place.geometry.viewport);
                    } else {
                        map.setCenter(place.geometry.location);
                        map.setZoom(15);  // Why 15? Because it looks good.
                    }
                    marker.setPosition(place.geometry.location);
                    marker.setVisible(true);

                    infowindowContent.children['place-icon'].src = place.icon;
                    infowindowContent.children['place-name'].textContent = place.name;
                    infowindowContent.children['place-address'].textContent = address;
                    var address_long_name =  place.address_components[0].long_name; 
                    if(address_long_name == place.name){
                        $scope.scheduler.address = address;     
                    }else{
                        $scope.scheduler.address = place.name  + ','+ address;
                    }
                    $scope.$apply();
                    infowindow.open(map, marker);
                }
                /* End */

                /* Functions is used to set place in map while edit or view on the basis of lat/long and address */
                $scope.getPlace = function(lat,lng,address) {
                    var latlng = new google.maps.LatLng(lat, lng);
                    var geocoder = new google.maps.Geocoder();
                    geocoder.geocode({'latLng': latlng}, function(results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            if (results[1]) { 
                                marker = new google.maps.Marker({
                                    position: latlng,
                                    map: map
                                });

                                map.setCenter(marker.getPosition());
                                map.setZoom(15); 
                                $scope.lat = lat;
                                $scope.lng = lng;
                                infowindowContent.children['place-address'].textContent = address;
                                marker.setIcon(null);
                                infowindow.open(map, marker);
                            }else {
                                //handle error status accordingly
                            }
                        }
                    })
                }
                /* End */
            }
        });
    };
    /* End add event modal pop-up */

    /**
    * Uib modal is used for view edit events options during using the full calendar
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 18-Sep-2017
    **/
    $scope.viewSchedulerEditModel = function(data){
        $uibModal.open({
            templateUrl: 'client/modules/scheduler/views/viewScheduleEditModel.html',
            size: "sm",
            controller: function($scope,$rootScope, $uibModalInstance) {
                /* Function is used to close the pop-up */
                $scope.closeuib = function() {
                    $uibModalInstance.close();
                } 
                /* End */

                /* Function is used on while choosing edit current occurrence event */
                $scope.editCurrentOccurrenceEvent = function(){
                    $scope.closeuib();
                    $rootScope.editCurrentEvent(data);
                }
                /* End */

                /* Function is used on while choosing edit series events */
                $scope.editSeriesEvent = function(){
                    data.editEventName = 'series';
                    $scope.closeuib();
                    $rootScope.editCurrentEvent(data);
                }
                /* End */

                /* Function is used on while choosing this and following events */
                $scope.editCurrentAndFollowingEvents = function(){
                    data.editEventName = 'following';
                    $scope.closeuib();
                    $rootScope.editCurrentEvent(data);
                }
                /* End */
            }
        });
    }

    /**
    * Function is used to open uib modal for edit current event and performing it's operations
    * @access private
    * @return json
    * Created by sunny
    * @smartData Enterprises (I) Ltd
    * Created Date 18-Sep-2017
    **/
    $rootScope.editCurrentEvent = function(data){
        $uibModal.open({
            templateUrl: 'client/modules/scheduler/views/editCurrentEventModal.html',
            size: "lg",
            controller: function($scope,$rootScope, $uibModalInstance) {
                /* Needed variables to declare first */
                $scope.scheduler = {};
                $scope.custom_weekly = false;
                $scope.weekly == true;
                $scope.scheduler.custom_weekly_repeat_on = {};
                /* End */

                /* Variables and functions used for 3 datepickers */
                $scope.dateModel = {};
                $scope.today = function() {
                    $scope.dt = new Date();
                };
                $scope.dateformat = "MM/dd/yyyy";
                $scope.today();
                $scope.showcalendar = function($event) {
                    $scope.dateModel.showdp = true;
                };
                $scope.showcalendar1 = function($event) {
                    $scope.dateModel.showdp1 = true;
                };

                $scope.showcalendar2 = function($event) {
                    $scope.dateModel.showdp2 = true;
                };
                $scope.dateModel.showdp = false;
                $scope.dateModel.showdp1 = false;
                $scope.dateModel.showdp2 = false;
                $scope.dtmax = new Date();
                /* End */ 

                /* Function is used to close the pop-up */
                $scope.closeuib = function() {
                    $uibModalInstance.close();
                }
                /* End */

                /* Variables is used to initialize the working hours on document ready */
                var currentDate = new Date();
                $scope.start_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
                $scope.start_time_full1 = new Date($scope.start_time_full.getTime() + 30*60000);
                $scope.end_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
                $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
              
                setTimeout(function(){
                    angular.element(document.querySelector('#start_time_id')).trigger('change');
                    angular.element(document.querySelector('#end_time_id')).trigger('change');
                },500);
                /* End */

                /* Function is used to set the time on using timepicker */
                $scope.fromDateChanged = function() {
                    var minutesAdded = 30;
                    $scope.end_time_full = new Date($scope.start_time_full.getTime() + minutesAdded*60000);
                    $scope.start_time_full1 = new Date($scope.start_time_full.getTime() + minutesAdded*60000);
                    $scope.minTime = new Date($scope.start_time_full.getTime() + minutesAdded*60000);
                    setTimeout(function(){
                        angular.element(document.querySelector('#start_time_id')).trigger('change');
                        angular.element(document.querySelector('#end_time_id')).trigger('change');
                    },500);
                }  
                /* End */

                /* Functions and variables is used for map load and get lat/long on the basis of google place address bar selection */
                var infowindow,marker,infowindowContent,autocomplete,map;
                $scope.initMap = function () {
                    map = new google.maps.Map(document.getElementById('map'), {
                        center: {lat: 41.310726, lng: -72.929916},
                        zoom: 15,
                    });

                    var input = document.getElementById('pac-input');
                    autocomplete = new google.maps.places.Autocomplete(input);
                    autocomplete.bindTo('bounds', map);
                    infowindow = new google.maps.InfoWindow();
                    infowindowContent = document.getElementById('infowindow-content');
                    infowindow.setContent(infowindowContent);
                    marker = new google.maps.Marker({
                        map: map
                    });

                    setTimeout(function() {
                        google.maps.event.trigger(map, 'resize');
                    }, 1000);
                    autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
                    function selectFirstAddress (input) {
                        google.maps.event.trigger(input, 'keydown', {keyCode:40});
                        // google.maps.event.trigger(input, 'keydown', {keyCode:13});
                    }
                    angular.element(document).on('focusout', '#pac-input', function() {
                        selectFirstAddress(this);
                    });    
                }

                $scope.fetchAutocomplete = function(){
                    infowindow.close();
                    marker.setVisible(false);
                    var place = autocomplete.getPlace();
                    if (!place.geometry) {
                        // User entered the name of a Place that was not suggested and
                        // pressed the Enter key, or the Place Details request failed.
                        window.alert("No details available for input: '" + place.name + "'");
                        return;
                    }
                    var lat = place.geometry.location.lat();
                    var lng = place.geometry.location.lng();
                    var address = place.formatted_address;
                    $scope.lat = lat;
                    $scope.lng = lng;
                    // If the place has a geometry, then present it on a map.
                    if (place.geometry.viewport) {
                        map.fitBounds(place.geometry.viewport);
                    } else {
                        map.setCenter(place.geometry.location);
                        map.setZoom(15);  // Why 17? Because it looks good.
                    }
                    marker.setPosition(place.geometry.location);
                    marker.setVisible(true);

                    infowindowContent.children['place-icon'].src = place.icon;
                    infowindowContent.children['place-name'].textContent = place.name;
                    infowindowContent.children['place-address'].textContent = address;
                    var address_long_name =  place.address_components[0].long_name; 
                    if(address_long_name == place.name){
                        $scope.scheduler.address = address;     
                    }else{
                        $scope.scheduler.address = place.name  + ','+ address;
                    }
                    $scope.$apply();
                    infowindow.open(map, marker);
                }
                /* End */

                /* Functions is used to set place in map while edit or view on the basis of lat/long and address  */
                $scope.getPlace = function(lat,lng,address) {
                    var latlng = new google.maps.LatLng(lat, lng);
                    var geocoder = new google.maps.Geocoder();
                    geocoder.geocode({'latLng': latlng}, function(results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            if (results[1]) { 
                                marker = new google.maps.Marker({
                                    position: latlng,
                                    map: map
                                });

                                map.setCenter(marker.getPosition());
                                map.setZoom(15); 
                                $scope.lat = lat;
                                $scope.lng = lng;
                                infowindowContent.children['place-address'].textContent = address;
                                marker.setIcon(null);
                                infowindow.open(map, marker);
                            }else {
                                //handle error status accordingly
                            }
                        }
                    })
                }
                /* End */
                
                /* Functions is used for clear the field which is not needed in non-recurring*/
                $scope.clearRepeatEndsOnField = function(){
                    $scope.scheduler.event_id = undefined;
                    $scope.scheduler.event_end_date = undefined;
                    $scope.repeat_every = false;
                    $scope.scheduler.repeating_every_no = undefined;
                    $scope.event_end_date = undefined;
                    $scope.custom_weekly = false;
                }
                /* End */

                /* Function is used to get event names for repeat dropdown */
                $scope.getEventName = function(){
                    var booking = {};
                    ClientSchedulerService.getEventName().get({},function(response, err){
                        if(response.status == 1){
                            $scope.events = response.data;
                        }else{
                            $scope.events = {};
                        }
                    })  
                }
                /* End */

                /* Function is used to get all languages in edit event */
                $scope.getAllLanguagesInBookingModal = function(){
                    ClientSchedulerService.getAllLanguagesInBooking().get({},function(response, err){
                        if(response.status == 1){
                            $scope.agencyLanguages = response.data;
                        }else{
                            $scope.agencyLanguages = {};
                        }
                    })
                }
                /* End */

                /* Function is used to refetched full calendar events by client */
                $scope.getBookingOnClientSelection = function(){
                    $('#providerDiv').fullCalendar('refetchEvents');
                }
                /* End */

                /* Function is used to update the event by client */
                $scope.updateEventByClient = function() {
                    // if ($scope.form.$valid) {
                    $scope.scheduler.lat = $scope.lat;
                    $scope.scheduler.lng = $scope.lng;

                    var tmpStartTime = CommonService.convertTo24Format($scope.scheduler.start_time);
                    var tmpEndTime = CommonService.convertTo24Format($scope.scheduler.end_time);

                    //Set Start Date
                    var new_start_date =  new Date($scope.scheduler.start_date);
                    new_start_date.setHours(tmpStartTime.hour);
                    new_start_date.setMinutes(tmpStartTime.minute);
                    $scope.scheduler.start_date = new_start_date; 
                    //End

                    //Set End Date
                    var new_end_date =  new Date($scope.scheduler.end_date);
                    new_end_date.setHours(tmpEndTime.hour);
                    new_end_date.setMinutes(tmpEndTime.minute);
                    $scope.scheduler.end_date = new_end_date; 
                    //End

                    //Set End Event Date
                    if($scope.scheduler.is_recurring == true ){
                        var new_event_end_date =  new Date($scope.scheduler.event_end_date);
                        new_event_end_date.setHours(tmpEndTime.hour);
                        new_event_end_date.setMinutes(tmpEndTime.minute);
                        $scope.scheduler.event_end_date = new_event_end_date; 
                    }else{
                        $scope.scheduler.event_id = undefined;
                        $scope.scheduler.event_end_date = undefined;
                        $scope.scheduler.repeating_every_no = undefined;
                    }

                    console.log("scope.scheduler", $scope.scheduler);
                    ClientSchedulerService.updateCurrentOccurenceEvent().save($scope.scheduler, function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.closeuib();
                            $scope.getBookingOnClientSelection();
                        } else {
                            logger.logError(response.message);
                        }
                    });

                // }else{
                //     logger.logError("You have missed the required fields to fill the form.");
                // }
                }
                /* End */

                /* Functions is used to check all event name on selection of event in repeat dropdown */
                $scope.checkEventName = function(event_id){
                    var events = $scope.events;
                    events.forEach(function(value, index) {
                        if(value.event_name == 'custom (weekly)'){
                            if(value._id == event_id){
                                $scope.custom_weekly = true;
                                $scope.scheduler.custom_weekly_repeat_on.sunday = false;
                                $scope.scheduler.custom_weekly_repeat_on.monday = false;
                                $scope.scheduler.custom_weekly_repeat_on.tuesday = false;
                                $scope.scheduler.custom_weekly_repeat_on.wednesday = false;
                                $scope.scheduler.custom_weekly_repeat_on.thursday = false;
                                $scope.scheduler.custom_weekly_repeat_on.friday = false;
                                $scope.scheduler.custom_weekly_repeat_on.saturday = false;
                                $scope.repeat_event_name = value.event_name;
                                $scope.repeat_every = true;
                                $scope.scheduler.repeating_every_no = "1";
                                return;
                            }else{
                                $scope.custom_weekly = false;
                                $scope.scheduler.custom_weekly_repeat_on.sunday = false;
                                $scope.scheduler.custom_weekly_repeat_on.monday = false;
                                $scope.scheduler.custom_weekly_repeat_on.tuesday = false;
                                $scope.scheduler.custom_weekly_repeat_on.wednesday = false;
                                $scope.scheduler.custom_weekly_repeat_on.thursday = false;
                                $scope.scheduler.custom_weekly_repeat_on.friday = false;
                                $scope.scheduler.custom_weekly_repeat_on.saturday = false;
                            }
                        }else 
                        if(value._id == event_id){
                            if($scope.scheduler.start_date != undefined){
                                var d = new Date($scope.scheduler.start_date);
                                var year = d.getFullYear();
                                var month = d.getMonth();
                                var day = d.getDate();
                                var c;
                                if(value.event_name == 'daily'){
                                    c = new Date(year + 1, month, day);
                                }else if(value.event_name == 'weekly'){
                                    c = new Date(year + 2, month, day);
                                }else if(value.event_name == 'monthly'){
                                    c = new Date(year + 5, month, day);
                                }else if(value.event_name == 'yearly'){
                                    c = new Date(year + 10, month, day);
                                }else if(value.event_name == 'custom (weekly)'){
                                    c = new Date(year + 2, month, day);
                                }   
                                $scope.maxiDate = c;
                            }
                            $scope.repeat_event_name = value.event_name;
                            $scope.repeat_every = true;
                            $scope.scheduler.repeating_every_no = "1";
                        }else{
                            return;
                        }
                     })      
                }
                /* End */

                /* Function is used to check event name and validate some input fields during edit event details by id */
                $scope.checkEventName1 = function(event_id){
                    var events = $scope.events;
                    events.forEach(function(value, index) {
                        if(value.event_name == 'custom (weekly)'){
                            if(value._id == event_id){
                                $scope.custom_weekly = true;
                                $scope.repeat_event_name = value.event_name;
                                return;
                            }else{
                                $scope.custom_weekly = false;
                            }
                        }else{
                            return;
                        }
                    })      
                }
                /* End */

                /* Function is used to validate event end date with respect to start date*/
                $scope.setEventEndDate = function(start_date){
                    var d = new Date(start_date);
                    var year = d.getFullYear();
                    var month = d.getMonth();
                    var day = d.getDate();
                    if($scope.repeat_event_name == 'daily'){
                        var c = new Date(year + 1, month, day);
                    }else if($scope.repeat_event_name == 'weekly'){
                        var c = new Date(year + 2, month, day);
                    }else if($scope.repeat_event_name == 'monthly'){
                        var c = new Date(year + 5, month, day);
                    }else if($scope.repeat_event_name == 'yearly'){
                        var c = new Date(year + 10, month, day);
                    }else if($scope.repeat_event_name == 'custom (weekly)'){
                        var c = new Date(year + 2, month, day);
                    }   
                    $scope.maxiDate = c; 
                }
                /* End */


                /* For data binding to edit modal on open this pop-up */
                var currentDate = new Date();   
                var scheduler = data;
                console.log("data",scheduler);
                if(scheduler.editEventName == 'series'){
                    $scope.editEventName = 'Update All';
                    scheduler.start_date = new Date(moment(scheduler.parent_start_date));
                    scheduler.end_date = new Date(moment(scheduler.parent_end_date));
                    scheduler.event_end_date = new Date(moment(scheduler.event_end_date));
                }else if(scheduler.editEventName == 'single'){
                    $scope.editEventName = 'Update';
                    scheduler.start_date = new Date(moment(scheduler.start_date));
                    scheduler.end_date = new Date(moment(scheduler.end_date));
                }else if(scheduler.editEventName == 'following'){
                    $scope.editEventName = 'Update Current And Following';
                    scheduler.start_date = new Date(moment(scheduler.start_date));
                    scheduler.end_date = new Date(moment(scheduler.end_date));
                    scheduler.old_start_date = new Date(moment(scheduler.start_date));
                    scheduler.old_end_date = new Date(moment(scheduler.end_date));
                    scheduler.parent_start_date = new Date(moment(scheduler.parent_start_date));
                    scheduler.parent_end_date = new Date(moment(scheduler.parent_end_date));
                    scheduler.event_end_date = new Date(moment(scheduler.event_end_date));
                }else{
                    $scope.editEventName = 'Update Current';
                    scheduler.start_date = new Date(moment(scheduler.start_date));
                    scheduler.end_date = new Date(moment(scheduler.end_date));
                    scheduler.parent_start_date = new Date(moment(scheduler.start_date));
                    scheduler.parent_end_date = new Date(moment(scheduler.end_date));
                    scheduler.event_end_date = new Date(moment(scheduler.event_end_date));
                }

                var tmpTime;
                if(scheduler.start_time){
                    tmpTime = CommonService.convertTo24Format(scheduler.start_time);
                    $scope.start_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                    $scope.start_time_full1 = new Date($scope.start_time_full.getTime() + 30*60000);
                    $scope.minTime = $scope.start_time_full1;
                }
                if(scheduler.end_time){
                    tmpTime = CommonService.convertTo24Format(scheduler.end_time);
                    $scope.end_time_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                }

                if(scheduler.repeating_every_no && scheduler.repeating_every_no != null && scheduler.is_recurring == true){
                    $scope.repeat_every = true;
                    ClientSchedulerService.getEventName().get({},function(response, err){
                        if(response.status == 1){
                            $scope.events = response.data;
                            if($scope.events){
                                $scope.checkEventName1(scheduler.event_id);
                            }
                        }else{
                            $scope.events = {};
                        }
                    }) 
                }else{
                    $scope.repeat_every = false;
                }

                $scope.scheduler = scheduler; 
                $scope.getPlace(scheduler.lat,scheduler.lng,scheduler.address);
                /* End data binding modal */
            }
        });
    }
    /* End the edit modal pop-up */

    /* Function is used to open the modal pop-up for choosing the delete events and performing related operations*/
    $scope.viewSchedulerDeleteModel = function(data){
        $uibModal.open({
            templateUrl: 'client/modules/scheduler/views/viewSchedulerDeleteModel.html',
            size: "sm",
            controller: function($scope,$rootScope, $uibModalInstance) {
                /* Function is used to close the pop-up */                
                $scope.closeuib = function() {
                    $uibModalInstance.close();
                }
                /* End */

                /* Function is used to refetched full calendar events by Agency */
                $scope.getBookingOnClientSelection = function(){
                    $('#providerDiv').fullCalendar('refetchEvents');
                }
                /* End */

                /* Function is delete all events during using full calendar */
                $scope.deleteAllEvent = function(){
                    $scope.closeuib();
                    var eventId = {
                        id:data._id
                    }
                    bootbox.confirm('Are you sure, you want to delete All series event?', function(r) {
                        if (r) {
                            ClientSchedulerService.deleteAllEvent().save(eventId, function(response, err) {
                                if (response.status == 1) {
                                    logger.logSuccess(response.message); 
                                    $scope.closeuib();
                                    $scope.getBookingOnClientSelection();
                                } else {
                                    logger.logError(response.message);
                                }
                            }); 
                        }
                    })                  
                }
                /* End */

                /* Function is delete current event during using full calendar */
                $scope.deleteCurrentEvent = function(){
                    $scope.closeuib();
                    var eventObj = data;
                    bootbox.confirm('Are you sure, you want to delete this current event?', function(r) {
                        if (r) {
                            ClientSchedulerService.deleteCurrentEvent().save(eventObj, function(response, err) {
                                if (response.status == 1) {
                                    logger.logSuccess(response.message); 
                                    $scope.closeuib();
                                    $scope.getBookingOnClientSelection();
                                } else {
                                    logger.logError(response.message);
                                }
                            }); 
                        }
                    })  
                }
                /* End */

                /* Function is delete this and following events during using full calendar */
                $scope.deleteCurrentAndFollowingEvents = function(){
                    $scope.closeuib();
                    var eventObj = data;
                    bootbox.confirm('Are you sure, you want to delete this and following events?', function(r) {
                        if (r) {
                            ClientSchedulerService.deleteCurrentAndFollowingEvents().save(eventObj, function(response, err) {
                                if (response.status == 1) {
                                    logger.logSuccess(response.message); 
                                    $scope.closeuib();
                                    $scope.getBookingOnClientSelection();
                                } else {
                                    logger.logError(response.message);
                                }
                            }); 
                        }
                    })  
                }
                /* End */
            }
        });
    } 
    /* End delete modal pop-up */ 

    /* Function is used to view today and pending booking on click of tabular row */
    $scope.viewTodayAndPendingBooking = function(bookingObj, typeBooking) {
        $uibModal.open({
            templateUrl: 'interpreter/modules/scheduler/views/viewTodayAndPendingBookingModal.html',
            size: "lg",
            controller: function($scope,$rootScope, $uibModalInstance) {
                /* Function is used to close the pop-up */                
                $scope.closeuib = function() {
                    $uibModalInstance.close();
                }
                /* End */

                /* Functions and variables is used for map load and get lat/long on the basis of google place address bar selection */
                var infowindow,marker,infowindowContent,autocomplete,map;
                $scope.initMap = function () {

                    map = new google.maps.Map(document.getElementById('map'), {
                      center: {lat: 41.310726, lng: -72.929916},
                      zoom: 15,
                    });

                    var input = document.getElementById('pac-input');
                    autocomplete = new google.maps.places.Autocomplete(input);
                    autocomplete.bindTo('bounds', map);
                    infowindow = new google.maps.InfoWindow();
                    infowindowContent = document.getElementById('infowindow-content');
                    infowindow.setContent(infowindowContent);
                    marker = new google.maps.Marker({
                      map: map
                    });

                    setTimeout(function() {
                       google.maps.event.trigger(map, 'resize');
                    }, 1000);
                    autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
                    function selectFirstAddress (input) {
                        google.maps.event.trigger(input, 'keydown', {keyCode:40});
                        // google.maps.event.trigger(input, 'keydown', {keyCode:13});
                    }
                    angular.element(document).on('focusout', '#pac-input', function() {
                        selectFirstAddress(this);
                    });
                    
                }
                /* End */

                /* Functions is used to set place in map while edit or view on the basis of lat/long and address */
                $scope.getPlace = function(lat,lng,address) {
                    var latlng = new google.maps.LatLng(lat, lng);
                    var geocoder = new google.maps.Geocoder();
                    geocoder.geocode({'latLng': latlng}, function(results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            if (results[1]) { 
                                marker = new google.maps.Marker({
                                    position: latlng,
                                    map: map
                                });

                                map.setCenter(marker.getPosition());
                                map.setZoom(15); 
                                $scope.lat = lat;
                                $scope.lng = lng;
                                infowindowContent.children['place-address'].textContent = address;
                                marker.setIcon(null);
                                infowindow.open(map, marker);
                            }else {
                                //handle error status accordingly
                            }
                        }
                    })
                }
                /* End */

                /* Variables is used to bind the value to the pop-up */                
                var start_date = bookingObj.start_date;
                var end_date = bookingObj.end_date;
                var booking = bookingObj.bookingDetail;
                $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                $scope.userDefaultImage1 = "./../../../../assets/images/default-img.png";
                var repeating_interval; 
                if(booking.recurrence_rule == 'daily'){
                    $scope.repeating_interval = 'Day'
                }else if(booking.recurrence_rule == 'weekly' || booking.recurrence_rule == 'custom (weekly)'){
                    $scope.repeating_interval = 'Week'
                }else if(booking.recurrence_rule == 'monthly'){
                    $scope.repeating_interval = 'Month'
                }else{
                    $scope.repeating_interval = 'Year'
                }
                booking.start_date = new Date(moment(start_date));
                booking.end_date = new Date(moment(end_date));
                booking.todays_status = bookingObj.todays_status;
                if(typeBooking == 'pending'){
                    booking.status = 'Pending';
                }
                if(booking.clientInfo && booking.clientInfo.profile_pic!='' && booking.clientInfo.profile_pic!=undefined){
                    $scope.userDefaultImage = booking.clientInfo.profile_pic;
                }
                if(booking.interpreterInfo && booking.interpreterInfo.profile_pic!='' && booking.interpreterInfo.profile_pic!=undefined){
                    $scope.userDefaultImage1 = booking.interpreterInfo.profile_pic;
                }
                $scope.booking = booking;
                /* End */
                $scope.getPlace(booking.lat,booking.lng,booking.address);
            }
        });
    };
    /* End */

    /* Function is used to view completed booking on click of tabular row */
    $scope.viewCompletedBooking = function(bookingObj) {
        $uibModal.open({
            templateUrl: 'interpreter/modules/scheduler/views/viewCompletedBookingModal.html',
            size: "lg",
            controller: function($scope,$rootScope, $uibModalInstance) {
                /* Function is used to close the pop-up */                
                $scope.closeuib = function() {
                    $uibModalInstance.close();
                }
                /* End */

                /* Function is used to assigned star rating to stars */
                $scope.testFunc = function(rating){
                    var displatRating=[];
                    for(var i=0;i<5;i++){
                      if(rating-i>=1){
                        displatRating.push({starType:'fa-star'}); 
                      }else if(rating-i<1 && rating-i>0){
                        displatRating.push({starType:'fa-star-half-o'}); 
                      }else{
                        displatRating.push({starType:'fa-star-o'}); 
                      }
                    }
                    return displatRating;
                }
                /* End */

                /* Functions and variables is used for map load and get lat/long on the basis of google place address bar selection */
                var infowindow,marker,infowindowContent,autocomplete,map;
                $scope.initMap = function () {

                    map = new google.maps.Map(document.getElementById('map'), {
                      center: {lat: 41.310726, lng: -72.929916},
                      zoom: 15,
                    });

                    var input = document.getElementById('pac-input');
                    autocomplete = new google.maps.places.Autocomplete(input);
                    autocomplete.bindTo('bounds', map);
                    infowindow = new google.maps.InfoWindow();
                    infowindowContent = document.getElementById('infowindow-content');
                    infowindow.setContent(infowindowContent);
                    marker = new google.maps.Marker({
                      map: map
                    });

                    setTimeout(function() {
                       google.maps.event.trigger(map, 'resize');
                    }, 1000);
                    autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
                    function selectFirstAddress (input) {
                        google.maps.event.trigger(input, 'keydown', {keyCode:40});
                        // google.maps.event.trigger(input, 'keydown', {keyCode:13});
                    }
                    angular.element(document).on('focusout', '#pac-input', function() {
                        selectFirstAddress(this);
                    });
                    
                }
                /* End */

                /* Functions is used to set place in map while edit or view on the basis of lat/long and address */
                $scope.getPlace = function(lat,lng,address) {
                    var latlng = new google.maps.LatLng(lat, lng);
                    var geocoder = new google.maps.Geocoder();
                    geocoder.geocode({'latLng': latlng}, function(results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            if (results[1]) { 
                                marker = new google.maps.Marker({
                                    position: latlng,
                                    map: map
                                });

                                map.setCenter(marker.getPosition());
                                map.setZoom(15); 
                                $scope.lat = lat;
                                $scope.lng = lng;
                                infowindowContent.children['place-address'].textContent = address;
                                marker.setIcon(null);
                                infowindow.open(map, marker);
                            }else {
                                //handle error status accordingly
                            }
                        }
                    })
                }
                /* End */

                /* Variables is used to bind the value to the pop-up */   
                var ratingArr = [];                
                var start_date = bookingObj.check_in_date;
                var end_date = bookingObj.check_out_date;
                var booking = bookingObj.bookingInfo;
                $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                $scope.userDefaultImage1 = "./../../../../assets/images/default-img.png";
                var repeating_interval = ''; 
                if(booking.recurrence_rule == 'daily'){
                    $scope.repeating_interval = 'Day'
                }else if(booking.recurrence_rule == 'weekly' ||  booking.recurrence_rule == 'custom (weekly)'){
                    $scope.repeating_interval = 'Week'
                }else if(booking.recurrence_rule == 'monthly'){
                    $scope.repeating_interval = 'Month'
                }else if(booking.recurrence_rule == 'yearly'){
                    $scope.repeating_interval = 'Year'
                }
                booking.start_date = new Date(moment(start_date));
                booking.end_date = new Date(moment(end_date));
                booking.languageFromInfo = bookingObj.languageFromInfo;
                booking.languageIntoInfo = bookingObj.languageIntoInfo;
                booking.clientInfo = bookingObj.clientInfo;
                booking.interpreterInfo = bookingObj.interpreterInfo;
                booking.status = 'Completed';
                if(bookingObj.clientInfo && bookingObj.clientInfo.profile_pic!='' && bookingObj.clientInfo.profile_pic!=undefined){
                    $scope.userDefaultImage = bookingObj.clientInfo.profile_pic;
                }
                if(bookingObj.interpreterInfo && bookingObj.interpreterInfo.profile_pic!='' && bookingObj.interpreterInfo.profile_pic!=undefined){
                    $scope.userDefaultImage1 = bookingObj.interpreterInfo.profile_pic;
                }
                 if(bookingObj.is_review_rating_done == true){
                    booking.review = bookingObj.review;
                    booking.is_review_rating_done = true;
                    $scope.ratingArr = $scope.testFunc(bookingObj.rating);
                }else{
                    booking.is_review_rating_done = false;
                    $scope.ratingArr = [];
                }
                $scope.booking = booking;
                $scope.getPlace(booking.lat,booking.lng,booking.address);
                /* End */
            }
        });
    };
    /* End */

    /* Function is used to add feeback to the completed booking */
    $scope.addFeedbackByClient = function(bookingObj) {
        $uibModal.open({
            templateUrl: 'client/modules/scheduler/views/addReviewRatingModal.html',
            size: "md",
            controller: function($scope,$rootScope, $uibModalInstance) {
                /* Variables and function is used for rating handling of bootstrap */
                $scope.rate = 0;
                $scope.max = 5;
                $scope.isReadonly = false;
                $scope.hoveringOver = function(value) {
                    $scope.overStar = value;
                    $scope.percent = 100 * (value / $scope.max);
                };
                /* End */
                
                /* Variables is used to bind value on review and rating modal */
                var booking = bookingObj;
                $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                $scope.interpreterName = booking.interpreterInfo.first_name.charAt(0).toUpperCase()+booking.interpreterInfo.first_name.slice(1).toLowerCase()+ ' ' +booking.interpreterInfo.last_name.charAt(0).toUpperCase()+booking.interpreterInfo.last_name.slice(1).toLowerCase();
                if(booking.interpreterInfo.profile_pic!='' && booking.interpreterInfo.profile_pic!=undefined){
                    $scope.userDefaultImage = booking.interpreterInfo.profile_pic;
                }
                /* End */
                
                /* Function is used to close uib modal */
                $scope.closeuib = function() {
                    $uibModalInstance.close();
                }
                /* End */
                
                /* Function is used to add review and rating to the booking */
                $scope.addReviewRatingByClient = function(form){
                    var reviewRating = $scope.reviewRating;
                    reviewRating.bookingId = booking._id;
                    reviewRating.agency_id = booking.agency_id;
                    reviewRating.rating = $scope.rate;

                    ClientSchedulerService.addReviewRatingByClient().save(reviewRating, function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.closeuib();
                            $state.reload();
                        } else {
                            logger.logError(response.message);

                        }
                    });
                }
                /* End */

            }
        });
    };

}]);
