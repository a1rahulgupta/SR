"use strict";

angular.module("WebCall")

interpreterApp.controller("webCallController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger', 'WebCallService','ClientBookingService', 'ngTableParams', 'ngTableParamsService','ClientSchedulerService',
    function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal, logger, WebCallService, ClientBookingService, ngTableParams, ngTableParamsService, ClientSchedulerService) {
               
        /**
        * Variable is used to active class on leftbar
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $rootScope.menuClientWebCall = ['client_webCall'];
        
        /**
        * Function is used to get client booking by id 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Nov-2017
        **/
        $scope.getClientBookingViewById = function(){
            if($stateParams.id){
                $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                ClientSchedulerService.getBookingViewByClientId().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var booking = response.data;
                        booking.start_date = new Date(moment(booking.start_date));
                        booking.end_date = new Date(moment(booking.end_date));
                        if(booking.interpreter_id.profile_pic!='' && booking.interpreter_id.profile_pic!=undefined){
                            $scope.userDefaultImage = booking.interpreter_id.profile_pic;
                        }
                        $scope.booking = booking;
                        $scope.webCallToInterpreter(booking.interpreter_id.mobile_no);
                        console.log(booking);
                    }
                })
            }
        }

        /**
        * Function is used to disconnect web phone call
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Nov-2017
        **/
        $scope.endWebCall = function(){
            Twilio.Device.disconnectAll();
            $state.go('client_todays_booking');
        }

         /**
        * Function and variable is used to make web phone call
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Nov-2017
        **/
        $scope.twilioCall={};
        $scope.webCallToInterpreter = function(phoneNo){
            var params = {"phoneNumber": phoneNo};
            Twilio.Device.connect(params);
        }

        $scope.$on('webCallDisconnected', function (event, args) {
            logger.log("Call is disconnected");
            $state.go('client_todays_booking');
         });

        $scope.$on('webCallConnected', function (event, args) {
            var connection = args.connectionObj;
             if ("phoneNumber" in connection.message) {
                logger.log("Call is connecting...");
            }
        });

                
    }

]);
