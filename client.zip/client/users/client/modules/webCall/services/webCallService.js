"use strict"

angular.module("WebCall")

.factory('WebCallService', ['$http', '$resource', function($http, $resource) {
 
    var listAgencyClients = function() {
        return $resource(webservices.listAgencyClients, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteAgencyClient = function(id) {
        return $resource(webservices.deleteAgencyClient, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }


    var addAgencyClients = function() {
        return $resource(webservices.addAgencyClients, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAgencyClientById = function(id) {
        return $resource(webservices.getAgencyClientById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var updateAgencyClient = function() {
        return $resource(webservices.updateAgencyClient, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var changeClientStatus = function() {
        return $resource(webservices.changeClientStatus, null, {
            save: {
                method: 'POST'
            }
        });
    }


    return {
        listAgencyClients: listAgencyClients,
        deleteAgencyClient: deleteAgencyClient,
        addAgencyClients: addAgencyClients,
        getAgencyClientById: getAgencyClientById,
        updateAgencyClient: updateAgencyClient,
        changeClientStatus: changeClientStatus

    }

}]);
