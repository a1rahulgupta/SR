"use strict"

angular.module("ClientBooking")

.factory('ClientBookingService', ['$http', '$resource', function($http, $resource) {
    
    var listBookingByClientId = function() {
        return $resource(webservices.listBookingByClientId, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAgencyInterpreters = function() {
        return $resource(webservices.getAgencyInterpreters, null, {
            save: {
                method: 'GET'
            }
        });
    }
           
    var getAgencyClients = function() {
        return $resource(webservices.getAgencyClients, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var addBookingByClient = function() {
        return $resource(webservices.addBookingByClient, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getClientBookingById = function(id) {
        return $resource(webservices.getClientBookingById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getBookingByClientId = function(id) {
        return $resource(webservices.getBookingByClientId, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var cancelBookingByClient = function() {
        return $resource(webservices.cancelBookingByClient, null, {
            save: {
                method: 'POST'
            }
        });
    }

     var updateBookingByClient = function() {
        return $resource(webservices.updateBookingByClient, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getBookingList = function() {
        return $resource(webservices.getBookingList, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getBookingById = function(id) {
        return $resource(webservices.getBookingById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var closeBookingByClient = function() {
        return $resource(webservices.closeBookingByClient, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getBookingListByClientId = function() {
        return $resource(webservices.getBookingListByClientId, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getClientBookingViewById = function(id) {
        return $resource(webservices.getClientBookingViewById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var webCallToInterpreter = function() {
        return $resource(webservices.webCallToInterpreter, null, {
            save: {
                method: 'POST'
            }
        });
        
    }

    var initializeTwilio = function() {
        return $resource(webservices.initializeTwilio, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var addReviewRatingByClient = function() {
        return $resource(webservices.addReviewRatingByClient, null, {
            save: {
                method: 'POST'
            }
        });
        
    }

    var getReviewByBookingId = function(id) {
        return $resource(webservices.getReviewByBookingId, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getAllLanguagesInClientBooking = function() {
        return $resource(webservices.getAllLanguagesInClientBooking, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getInterpreterNamesByLanguageId = function(id) {
        return $resource(webservices.getInterpreterNamesByLanguageId, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }   


    return {
        getBookingList: getBookingList,
        getAgencyInterpreters: getAgencyInterpreters,
        getAgencyClients: getAgencyClients,
        addBookingByClient: addBookingByClient,
        cancelBookingByClient:cancelBookingByClient,
        updateBookingByClient: updateBookingByClient,
        getBookingByClientId:getBookingByClientId,
        
        listBookingByClientId: listBookingByClientId,
        getClientBookingById: getClientBookingById,
        getBookingById: getBookingById,
        closeBookingByClient: closeBookingByClient,
        getBookingListByClientId: getBookingListByClientId,
        getClientBookingViewById: getClientBookingViewById,
        webCallToInterpreter: webCallToInterpreter,
        initializeTwilio: initializeTwilio,
        addReviewRatingByClient: addReviewRatingByClient,
        getReviewByBookingId: getReviewByBookingId,
        getAllLanguagesInClientBooking: getAllLanguagesInClientBooking,
        getInterpreterNamesByLanguageId: getInterpreterNamesByLanguageId


    }

}]);
