"use strict";

angular.module("ClientBooking")

interpreterApp.controller("clientBookingController", ['$scope', '$rootScope', '$localStorage',
    'ngTableParams', '$routeParams', '$route', '$location', '$state',
    '$stateParams', 'logger', 'ngTableParamsService', 'CommonService', 'ClientBookingService', '$uibModal',
    function($scope, $rootScope, $localStorage, ngTableParams, $routeParams,
        $route, $location, $state, $stateParams, logger, ngTableParamsService,
        CommonService, ClientBookingService, $uibModal) {


            if ($state.params.id) {
                $scope.isUpdate = true;
            } else {
                $scope.isUpdate = false;
            }

            $scope.fromDateChanged = function() {
                var minutesAdded = 30;
                $scope.working_to_full = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                $scope.minTime = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                setTimeout(function(){
                    angular.element(document.querySelector('#working_from_id')).trigger('change');
                    angular.element(document.querySelector('#working_to_id')).trigger('change');
                },1000);

            } 

            /**
            * Variable is used for active class on leftbar
            * @access private
            * @return json
            * Created by sunny
            * @smartData Enterprises (I) Ltd
            * Created Date 27-Sep-2017
            **/
            $rootScope.menuBooking = ['client_listBooking', 'client_addBooking', 'client_listCalendarBooking', 'client_viewBooking'];
            
            $scope.timeSettings = {};
            $scope.eventSources = [
                function(start, end, timezone, callback) {
                    ClientBookingService.getBookingList().get({}, function(response) {
                        var events = []; 
                        if (response.status == 1) {
                            $scope.scheduleBookingList = response.data;
                                                             
                            $scope.scheduleBookingList.forEach(function(value, index) {
                                $scope.colorName = $scope.getRandomColor();
                                events.push({
                                    start: new Date(moment(value.booking_from)), //$filter('dateFilter')(hol.HOLIDAY_START),
                                    end: new Date(moment(value.booking_to)), //$filter('dateFilter')(hol.HOLIDAY_END),
                                    title: value.service_title, //hol.HOLIDAY_TITLE,
                                    color: $scope.colorName,//'#c23333', //$filter('colorEventFilter')(hol.HOLIDAY_EVENT_STATE_ID)
                                    bookingDetail: value
                                });
                            });

                            callback(events);
                            $scope.calendarLoader = false;
                        }

                    });
                    
                }
            ];

            $scope.orderAll = [];
            $scope.calendarLoader = true;
            $scope.getScheduleBookingList = function() {
                $scope.uiConfig = {
                calendar: {
                        // events: function(start, end, timezone, callback) {
                            // console.log("herre$$$");
                            // BookingService.getBookingList().get({}, function(response) {
                            //     var events = []; 
                            //     if (response.status == 1) {
                            //         $scope.scheduleBookingList = response.data;
                                                                     
                            //         $scope.scheduleBookingList.forEach(function(value, index) {
                            //             $scope.colorName = $scope.getRandomColor();
                            //             events.push({
                            //                 end: moment(value.booking_to).format(), //$filter('dateFilter')(hol.HOLIDAY_END),
                            //                 start: moment(value.booking_from).format(), //$filter('dateFilter')(hol.HOLIDAY_START),
                            //                 title: value.service_title, //hol.HOLIDAY_TITLE,
                            //                 color: $scope.colorName,//'#c23333', //$filter('colorEventFilter')(hol.HOLIDAY_EVENT_STATE_ID)
                            //                 bookingDetail: value
                            //             });
                            //         });
                            //         callback(events);
                            //         $scope.calendarLoader = false;
                            //     }

                            // });
                            
                        // },
                        displayEventTime: false,
                        editable: true,
                        eventLimit: true,   
                        timezone:'local',
                        views: {
                         month: {
                           eventLimit: 4
                         }
                        },
                height: 550,
                navLinks: true,
                timeFormat: 'hh:mm a',
                // editable: true,
                header:{
                  left: 'month basicWeek basicDay agendaWeek agendaDay',
                  center: 'title',
                  right: 'today prev,next'
                },
                eventClick: function(calEvent, jsEvent, view) {

                  $scope.viewBookingModel(calEvent.bookingDetail._id)
                },
                eventDrop: $scope.alertOnDrop,
                eventResize: $scope.alertOnResize,
                dayClick: function(date, allDay, jsEvent, view) {
                    var currentDate = new Date();
                    var clickedDate = new Date(date.toString());
                    currentDate.setHours(0);
                    clickedDate.setHours(0);
                    var timeDiff = clickedDate.getTime() - currentDate.getTime();
                    var diffDays = Math.round(timeDiff / (1000 * 3600 * 24));
                    if(diffDays>=0){
                        $uibModal.open({
                            templateUrl: 'client/modules/booking/views/addBookingModal.html',
                            size: "lg",
                            // windowClass: 'app-per-modal-window',
                            controller: function($scope,$rootScope, $uibModalInstance) {
                                $scope.timeSettings = {};

                                 /* Functions is used to initialize the working hours on document ready */
                                $scope.initializeWorkingHours = function(){
                                    var currentDate = new Date();
                                    $scope.booking = {};
                                    $scope.booking.booking_from= new Date(date.toString());
                                    $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
                                    $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                                    $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
                                    $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                                    
                                    setTimeout(function(){
                                        angular.element(document.querySelector('#working_from_id')).trigger('change');
                                        angular.element(document.querySelector('#working_to_id')).trigger('change');
                                    },1000);
                                } 
                                /* End */

                                $scope.fromDateChanged = function() {
                                    var minutesAdded = 30;
                                    $scope.working_to_full = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                                    $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                                    $scope.minTime = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                                    setTimeout(function(){
                                        angular.element(document.querySelector('#working_from_id')).trigger('change');
                                        angular.element(document.querySelector('#working_to_id')).trigger('change');
                                    },1000);
                                }  

                                $scope.closeuib = function() {
                                    $uibModalInstance.close('a');
                                }
                                $scope.getAgencyInterpreters = function(){
                                    
                                    ClientBookingService.getAgencyInterpreters().get({},function(response, err){
                                        if(response.status == 1){
                                            $scope.agencyInterpreters = response.data;
                                        }else{
                                            $scope.agencyInterpreters = {};
                                        }
                                    })
                                }  

                                $scope.dateModel = {};
                                $scope.today = function() {
                                    $scope.dt = new Date();
                                };
                                $scope.dateformat = "MM/dd/yyyy";
                                $scope.today();
                                $scope.showcalendar = function($event) {
                                    $scope.dateModel.showdp = true;
                                };
                                $scope.showcalendar1 = function($event) {
                                    $scope.dateModel.showdp1 = true;
                                };
                                $scope.dateModel.showdp = false;
                                $scope.dateModel.showdp1 = false;
                                $scope.dtmax = new Date(); 

                                $scope.addBooking = function(form) {
                                    if (form.$valid) {
                                        $scope.loader = true;
                                        $scope.disabled = true;
                                        $scope.booking.lat = $scope.lat;
                                        $scope.booking.lng = $scope.lng;
                                        ClientBookingService.addBookingByClient().save($scope.booking, function(response, err) {
                                            var errorMessage = '';
                                            $scope.disabled = false;
                                            $scope.loader = false;
                                            if (response.status == 1) {
                                                logger.logSuccess(response.message); 
                                                $scope.closeuib();
                                                $state.reload();
                                            } else {
                                                logger.logError(response.message);

                                            }
                                        });
                                    }else{
                                        logger.logError("You have missed the required fields to fill the form.");
                                    }

                                };


                                var infowindow,marker,infowindowContent,autocomplete,map;
                                $scope.initMap = function () {

                                    map = new google.maps.Map(document.getElementById('map'), {
                                      center: {lat: 41.310726, lng: -72.929916},
                                      zoom: 15,
                                    });

                                    var input = document.getElementById('pac-input');
                                    autocomplete = new google.maps.places.Autocomplete(input);
                                    autocomplete.bindTo('bounds', map);
                                    infowindow = new google.maps.InfoWindow();
                                    infowindowContent = document.getElementById('infowindow-content');
                                    infowindow.setContent(infowindowContent);
                                    marker = new google.maps.Marker({
                                      map: map
                                    });

                                    setTimeout(function() {
                                       google.maps.event.trigger(map, 'resize');
                                    }, 1000);
                                    autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
                                    function selectFirstAddress (input) {
                                        google.maps.event.trigger(input, 'keydown', {keyCode:40});
                                        // google.maps.event.trigger(input, 'keydown', {keyCode:13});
                                    }
                                    angular.element(document).on('focusout', '#pac-input', function() {
                                        selectFirstAddress(this);
                                    });
                                    
                                  }

                                  $scope.fetchAutocomplete = function(){
                                      infowindow.close();
                                      marker.setVisible(false);
                                      var place = autocomplete.getPlace();
                                      if (!place.geometry) {
                                        // User entered the name of a Place that was not suggested and
                                        // pressed the Enter key, or the Place Details request failed.
                                        window.alert("No details available for input: '" + place.name + "'");
                                        return;
                                      }
                                      var lat = place.geometry.location.lat();
                                      var lng = place.geometry.location.lng();
                                      var address = place.formatted_address;
                                      $scope.lat = lat;
                                      $scope.lng = lng;  
                                      // If the place has a geometry, then present it on a map.
                                      if (place.geometry.viewport) {
                                        map.fitBounds(place.geometry.viewport);
                                      } else {
                                        map.setCenter(place.geometry.location);
                                        map.setZoom(15);  // Why 17? Because it looks good.
                                      }
                                      marker.setPosition(place.geometry.location);
                                      marker.setVisible(true);

                                      infowindowContent.children['place-icon'].src = place.icon;
                                      infowindowContent.children['place-name'].textContent = place.name;
                                      infowindowContent.children['place-address'].textContent = address;
                                      var address_long_name =  place.address_components[0].long_name; 
                                      if(address_long_name == place.name){
                                        $scope.booking.address = address;     
                                      }else{
                                        $scope.booking.address = place.name  + ', '+ address;
                                      }

                                      $scope.$apply();
                                      infowindow.open(map, marker);
                                  }

                                  $scope.getAllLanguagesInClientBookingModal = function(){
                                    ClientBookingService.getAllLanguagesInClientBooking().get({},function(response, err){
                                        if(response.status == 1){
                                            $scope.clientLanguages = response.data;
                                        }else{
                                            $scope.clientLanguages = {};
                                        }
                                    })
                                }

                                $scope.getInterpreterNamesByLanguageIdInClientModal = function(languageId){
                                    ClientBookingService.getInterpreterNamesByLanguageId().get({id:languageId},function(response, err){
                                        if(response.status == 1){
                                            $scope.intepreterName = response.data;
                                        }else{
                                            $scope.intepreterName = {};
                                        }
                                    })
                                } 
                                

                            }
                        });
                    }

                }
            
            }
        }
            }


            $scope.viewBookingModel = function(data) {
                $uibModal.open({
                        templateUrl: 'client/modules/booking/views/viewBookingModal.html',
                        size: "lg",
                        // windowClass: 'app-per-modal-window',
                        controller: function($scope,$rootScope, $uibModalInstance) {

                            $scope.closeuib = function() {
                                $uibModalInstance.close('a');
                            }
                            /** Variables is used to initialize the working hours on document ready */
                            var currentDate = new Date();
                            $scope.booking = {};
                            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
                            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
                            $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                            
                            setTimeout(function(){
                                angular.element(document.querySelector('#working_from_id')).trigger('change');
                                angular.element(document.querySelector('#working_to_id')).trigger('change');
                            },1000);
                            /* End */

                            $scope.fromDateChanged = function() {
                                var minutesAdded = 30;
                                $scope.working_to_full = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                                $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                                $scope.minTime = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                                setTimeout(function(){
                                    angular.element(document.querySelector('#working_from_id')).trigger('change');
                                    angular.element(document.querySelector('#working_to_id')).trigger('change');
                                },1000);

                            }  

                            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                            ClientBookingService.getBookingByClientId().get({id:data},function(response, err){
                                if(response.status == 1){
                                    var currentDate = new Date();  
                                    var booking = response.data;
                                    booking.booking_from = new Date(moment(booking.booking_from));
                                    booking.booking_to = new Date(moment(booking.booking_to));
                                    var tmpTime = CommonService.convertTo24Format(booking.working_from);
                                    $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                                    tmpTime = CommonService.convertTo24Format(booking.working_to);
                                    $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                                    $scope.booking = booking; 
                                    if(booking.client_id.profile_pic!='' && booking.client_id.profile_pic!=undefined){
                                        $scope.userDefaultImage = booking.client_id.profile_pic;
                                    }
                                    // $scope.getInterpreterNamesByLanguageIdModal(booking.language_id);
                                    $scope.getPlace(booking.lat,booking.lng,booking.address);
                                }else{
                                    $scope.booking = {};
                                }
                            })

                            $scope.getAgencyInterpreters = function(){
                                ClientBookingService.getAgencyInterpreters().get({},function(response, err){
                                    if(response.status == 1){
                                        $scope.agencyInterpreters = response.data;
                                    }else{
                                        $scope.agencyInterpreters = {};
                                    }
                                })
                            }  

                            $scope.getAgencyClients = function(){
                                InterpreterBookingService.getAgencyClients().get({},function(response, err){
                                    if(response.status == 1){
                                        $scope.agencyClients = response.data;
                                    }else{
                                        $scope.agencyClients = {};
                                    }
                                })
                            } 

                            $scope.updateBooking = function(form) {
                                 if (form.$valid) {
                                    $scope.loader = true;
                                    $scope.disabled = true;
                                    $scope.booking.lat = $scope.lat;
                                    $scope.booking.lng = $scope.lng;
                                    ClientBookingService.updateBookingByClient().save($scope.booking, function(response, err) {
                                        var errorMessage = '';
                                        $scope.disabled = false;
                                        $scope.loader = false;
                                        if (response.status == 1) {
                                            logger.logSuccess(response.message); 
                                            $scope.closeuib();
                                            $state.reload();
                                        } else {
                                            logger.logError(response.message);

                                        }
                                    });
                                }else{
                                    logger.logError("You have missed the required fields to fill the form.");
                                }


                            }

                             $scope.closeBookingByClient = function(id) {
                                bootbox.confirm('Are you sure, you want to close this booking?', function(r) {
                                    if (r) {
                                        ClientBookingService.closeBookingByClient().save({id:id},function(response, err) {
                                            if (response.status == 1) {
                                                logger.logSuccess(response.message); 
                                                $scope.closeuib();
                                            } else {
                                                logger.logError(response.message);
                                            }
                                        });
                                    }
                                })

                            }  

                            $scope.cancelBookingByClient = function(id) {
                                bootbox.confirm('Are you sure, you want to cancel this booking?', function(r) {
                                    if (r) {
                                        ClientBookingService.cancelBookingByClient().save({id:id},function(response, err) {
                                            if (response.status == 1) {
                                                logger.logSuccess(response.message); 
                                                $scope.closeuib();
                                            } else {
                                                logger.logError(response.message);
                                            }
                                        });
                                    }
                                })

                            } 

                            $scope.dateModel = {};
                            $scope.today = function() {
                                $scope.dt = new Date();
                            };
                            $scope.dateformat = "MM/dd/yyyy";
                            $scope.today();
                            $scope.showcalendar = function($event) {
                                $scope.dateModel.showdp = true;
                            };
                            $scope.showcalendar1 = function($event) {
                                $scope.dateModel.showdp1 = true;
                            };
                            $scope.dateModel.showdp = false;
                            $scope.dateModel.showdp1 = false;
                            $scope.dtmax = new Date(); 

                            var infowindow,marker,infowindowContent,autocomplete,map;
                            $scope.initMap = function () {
                                map = new google.maps.Map(document.getElementById('map'), {
                                  center: {lat: 41.310726, lng: -72.929916},
                                  zoom: 15,
                                });

                                var input = document.getElementById('pac-input');
                                autocomplete = new google.maps.places.Autocomplete(input);
                                autocomplete.bindTo('bounds', map);
                                infowindow = new google.maps.InfoWindow();
                                infowindowContent = document.getElementById('infowindow-content');
                                infowindow.setContent(infowindowContent);
                                marker = new google.maps.Marker({
                                  map: map
                                });

                                setTimeout(function() {
                                   google.maps.event.trigger(map, 'resize');
                                }, 1000);

                                autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
                                function selectFirstAddress (input) {
                                    google.maps.event.trigger(input, 'keydown', {keyCode:40});
                                    // google.maps.event.trigger(input, 'keydown', {keyCode:13});
                                }
                                angular.element(document).on('focusout', '#pac-input', function() {
                                    selectFirstAddress(this);
                                });
                                
                                 
                              }

                            $scope.fetchAutocomplete = function(){
                                infowindow.close();
                                marker.setVisible(false);
                                var place = autocomplete.getPlace();
                                if (!place.geometry) {
                                // User entered the name of a Place that was not suggested and
                                // pressed the Enter key, or the Place Details request failed.
                                window.alert("No details available for input: '" + place.name + "'");
                                return;
                                }
                                var lat = place.geometry.location.lat();
                                var lng = place.geometry.location.lng();
                                var address = place.formatted_address;
                                $scope.lat = lat;
                                $scope.lng = lng;  
                                  // If the place has a geometry, then present it on a map.
                                if (place.geometry.viewport) {
                                map.fitBounds(place.geometry.viewport);
                                } else {
                                    map.setCenter(place.geometry.location);
                                    map.setZoom(15);  // Why 17? Because it looks good.
                                }
                                marker.setPosition(place.geometry.location);
                                marker.setVisible(true);

                                infowindowContent.children['place-icon'].src = place.icon;
                                infowindowContent.children['place-name'].textContent = place.name;
                                infowindowContent.children['place-address'].textContent = address;
                                var address_long_name =  place.address_components[0].long_name; 
                                if(address_long_name == place.name){
                                    $scope.booking.address = address;     
                                }else{
                                    $scope.booking.address = place.name  + ', '+ address;
                                }

                                $scope.$apply();
                                infowindow.open(map, marker);  
                            }
                            $scope.getPlace = function(lat,lng,address) {
                                var latlng = new google.maps.LatLng(lat, lng);
                                var geocoder = new google.maps.Geocoder();
                                geocoder.geocode({'latLng': latlng}, function(results, status) {
                                    if (status == google.maps.GeocoderStatus.OK) {
                                        if (results[1]) { 
                                            marker = new google.maps.Marker({
                                                position: latlng,
                                                map: map
                                            });
                                            map.setCenter(marker.getPosition());
                                            map.setZoom(15); 
                                            $scope.lat = lat;
                                            $scope.lng = lng;
                                            infowindowContent.children['place-address'].textContent = address;
                                            marker.setIcon(null);
                                            infowindow.open(map, marker);
                                        }
                                        else {
                                        //handle error status accordingly
                                        }
                                    }
                                })
                            }

                            $scope.getAllLanguagesInClientBookingModal = function(){
                                ClientBookingService.getAllLanguagesInClientBooking().get({},function(response, err){
                                    if(response.status == 1){
                                        $scope.clientLanguages = response.data;
                                    }else{
                                        $scope.clientLanguages = {};
                                    }
                                })
                            }

                            $scope.getInterpreterNamesByLanguageIdModal = function(languageId){
                                ClientBookingService.getInterpreterNamesByLanguageId().get({id:languageId},function(response, err){
                                    if(response.status == 1){
                                        $scope.intepreterName = response.data;
                                    }else{
                                        $scope.intepreterName = {};
                                    }
                                })
                            }

                        }
                    });
            };

            $scope.getRandomColor = function() {
                var letters = 'DGABA'.split('');
                var color = '#';
                for (var i=0; i<3; i++ ) {
                    color += letters[Math.floor(Math.random() * letters.length)];
                }
                return color;
            }
            
           

            $scope.getBookingListByClientId = function(){
                ClientBookingService.getBookingList().get({},function(response, err){
                    if(response.status == 1){
                        $scope.bookingList = response.data;
                    }else{
                        $scope.bookingList = {};
                    }
                })
            }  

        /**
        * Function is used to get booking list of an client
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 16-Oct-2017
        **/
        $scope.listBookingByClientId = function() {
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.bookingList = [];
                    ClientBookingService.listBookingByClientId().save($scope.paramUrl, function(response, err) {
                        if (response.status == 1) {
                            $scope.tableLoader = false;
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };

        /**
        * Function is used to get booking list of an client by searching
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 12-Oct-2017
        **/
        $scope.listBookingByClientIdSearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.bookingList = [];
                    ClientBookingService.listBookingByClientId().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };


        $scope.getAgencyInterpreters = function(){
            ClientBookingService.getAgencyInterpreters().get({},function(response, err){
                if(response.status == 1){
                    $scope.agencyInterpreters = response.data;
                }else{
                    $scope.agencyInterpreters = {};
                }
            })
        }  

        $scope.getAgencyClients = function(){
            ClientBookingService.getAgencyClients().get({},function(response, err){
                if(response.status == 1){
                    $scope.agencyClients = response.data;
                }else{
                    $scope.agencyClients = {};
                }
            })
        } 

        $scope.addBookingByClient = function(form) {
            if (form.$valid) {
                $scope.loader = true;
                $scope.disabled = true;
                    
                $scope.booking.lat = $scope.lat;
                $scope.booking.lng = $scope.lng;
                ClientBookingService.addBookingByClient().save($scope.booking, function(response, err) {

                    var errorMessage = '';
                    $scope.disabled = false;
                    $scope.loader = false;
                    if (response.status == 1) {
                        logger.logSuccess(response.message); 
                        $state.go('client_listBooking');
                    } else {
                        logger.logError(response.message);

                    }
                });
            }else{
                logger.logError("You have missed the required fields to fill the form.");
            }   

        };

        $scope.dateModel = {};
        $scope.today = function() {
            $scope.dt = new Date();
        };
        $scope.dateformat = "MM/dd/yyyy";
        $scope.today();
        $scope.showcalendar = function($event) {
            $scope.dateModel.showdp = true;
        };
        $scope.showcalendar1 = function($event) {
            $scope.dateModel.showdp1 = true;
        };
        $scope.dateModel.showdp = false;
        $scope.dateModel.showdp1 = false;
        $scope.dtmax = new Date(); 

        $scope.getClientBookingById = function(){
            var currentDate = new Date();
            $scope.booking = {};
            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
            $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
            
            setTimeout(function(){
                angular.element(document.querySelector('#working_from_id')).trigger('change');
                angular.element(document.querySelector('#working_to_id')).trigger('change');
            },1000);  
            if($stateParams.id){
                $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                ClientBookingService.getClientBookingById().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var booking = response.data;
                        booking.booking_from = new Date(moment(booking.booking_from));
                        booking.booking_to = new Date(moment(booking.booking_to));
                        var tmpTime;
                        
                        if(booking.working_from){
                            tmpTime = CommonService.convertTo24Format(booking.working_from);
                            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                            $scope.minTime = $scope.working_from_full1;
                        }

                        if(booking.working_to){
                            tmpTime = CommonService.convertTo24Format(booking.working_to);
                            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                        }

                        // if(booking.interpreter_id.profile_pic!='' && booking.interpreter_id.profile_pic!=undefined){
                        //     $scope.userDefaultImage = booking.interpreter_id.profile_pic;
                        // }

                        // var interpreterId = booking.interpreter_id._id;
                        // booking.interpreterId = interpreterId;
                        $scope.booking = booking;
                        $scope.getInterpreterNamesByLanguageIdInClient(booking.language_id);
                        $scope.getPlace(booking.lat,booking.lng,booking.address);
                    }
                })
            }
        }

        $scope.getClientBookingViewById = function(){
            if($stateParams.id){
                $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                ClientBookingService.getClientBookingViewById().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var booking = response.data;
                        booking.booking_from = new Date(moment(booking.booking_from));
                        booking.booking_to = new Date(moment(booking.booking_to));
                        console.log("booking.interpreter_id.profile_pic", booking.interpreter_id.profile_pic);
                        if(booking.interpreter_id.profile_pic!='' && booking.interpreter_id.profile_pic!=undefined){
                            $scope.userDefaultImage = booking.interpreter_id.profile_pic;
                        }
                        $scope.booking = booking;
                        $scope.getPlace(booking.lat,booking.lng,booking.address);
                    }
                })
            }
        } 

        $scope.cancelBookingByClient = function(id) {
            bootbox.confirm('Are you sure, you want to cancel this booking?', function(r) {
                if (r) {
                    ClientBookingService.cancelBookingByClient().save({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listBookingByClientId();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })

        }  


        $scope.updateBookingByClient = function(form) {
            if (form.$valid) {
                $scope.loader = true;
                $scope.disabled = true;
                $scope.booking.lat = $scope.lat;
                $scope.booking.lng = $scope.lng;
                ClientBookingService.updateBookingByClient().save($scope.booking, function(response, err) {
                    var errorMessage = '';
                    $scope.disabled = false;
                    $scope.loader = false;
                    if (response.status == 1) {
                        logger.logSuccess(response.message); 
                        $location.path('client/listBooking');
                    } else {
                        logger.logError(response.message);
                    }
                });
            }else{
                logger.logError("You have missed the required fields to fill the form.");
            }

        }

        // $scope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams){ 
        //     window.dispatchEvent(new Event('resize'));
        // });
        
        var infowindow,marker,infowindowContent,autocomplete,map;
        $scope.initMap = function () {

            map = new google.maps.Map(document.getElementById('map'), {
              center: {lat: 41.310726, lng: -72.929916},
              zoom: 15,
            });

            var input = document.getElementById('pac-input');
            autocomplete = new google.maps.places.Autocomplete(input);

            autocomplete.bindTo('bounds', map);
            infowindow = new google.maps.InfoWindow();
            infowindowContent = document.getElementById('infowindow-content');
            infowindow.setContent(infowindowContent);
            marker = new google.maps.Marker({
              map: map
            });

            autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
            function selectFirstAddress (input) {
                google.maps.event.trigger(input, 'keydown', {keyCode:40});
                // google.maps.event.trigger(input, 'keydown', {keyCode:13});
            }
            angular.element(document).on('focusout', '#pac-input', function() {
                selectFirstAddress(this);
            });
            
          }


          $scope.fetchAutocomplete = function(){
              infowindow.close();
              marker.setVisible(false);
              var place = autocomplete.getPlace();
              if (!place.geometry) {
                // User entered the name of a Place that was not suggested and
                // pressed the Enter key, or the Place Details request failed.
                window.alert("No details available for input: '" + place.name + "'");
                return;
              }
              var lat = place.geometry.location.lat();
              var lng = place.geometry.location.lng();
              var address = place.formatted_address;
              $scope.lat = lat;
              $scope.lng = lng;  
              // If the place has a geometry, then present it on a map.
              if (place.geometry.viewport) {
                map.fitBounds(place.geometry.viewport);
              } else {
                map.setCenter(place.geometry.location);
                map.setZoom(15);  // Why 17? Because it looks good.
              }
              marker.setPosition(place.geometry.location);
              marker.setVisible(true);

              infowindowContent.children['place-icon'].src = place.icon;
              infowindowContent.children['place-name'].textContent = place.name;
              infowindowContent.children['place-address'].textContent = address;
              var address_long_name =  place.address_components[0].long_name; 
              if(address_long_name == place.name){
                $scope.booking.address = address;     
              }else{
                $scope.booking.address = place.name  + ', '+ address;
              }

              $scope.$apply();
              infowindow.open(map, marker);
          }
          $scope.getPlace = function(lat,lng,address) {
              var latlng = new google.maps.LatLng(lat, lng);
              var geocoder = new google.maps.Geocoder();
              geocoder.geocode({'latLng': latlng}, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                  if (results[1]) { 
                    marker = new google.maps.Marker({
                        position: latlng,
                        map: map
                    });

                    map.setCenter(marker.getPosition());
                    map.setZoom(15); 
                    $scope.lat = lat;
                    $scope.lng = lng;
                    infowindowContent.children['place-address'].textContent = address;
                    marker.setIcon(null);
                    infowindow.open(map, marker);
                  }
                  else {
                    //handle error status accordingly
                  }
                }
            })
        }

        /**
        * Function is used to view the booking of client
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 16-Oct-2017
        **/
        $scope.viewBooking = function(booking) {
            $state.go('client_viewBooking', {id:booking._id});
        }; 

        $scope.closeBookingByClient = function(bookingId) {
            $uibModal.open({
                templateUrl: 'client/modules/booking/views/addReviewRating.html',
                size: "md",
                controller: function($scope,$rootScope, $uibModalInstance) {

                    $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                    ClientBookingService.getClientBookingById().get({id:bookingId},function(response, err){
                        if(response.status == 1){
                            var booking = response.data;
                            var reviewRating = {
                                bookingId: booking._id,
                                agency_id: booking.agency_id,
                            }
                            if(booking.interpreter_id.profile_pic!='' && booking.interpreter_id.profile_pic!=undefined){
                                $scope.userDefaultImage = booking.interpreter_id.profile_pic;
                            }
                            $scope.reviewRating = reviewRating; 
                            $scope.booking = booking;

                        }
                    })
                    
                    $scope.closeuib = function() {
                        $uibModalInstance.close();
                    }
                    
                    $scope.rate = 0;
                    $scope.max = 5;
                    $scope.isReadonly = false;
                    $scope.hoveringOver = function(value) {
                    $scope.overStar = value;
                        $scope.percent = 100 * (value / $scope.max);
                    };

                    $scope.addReviewRatingByClient = function(form){
                        var reviewRating = $scope.reviewRating;
                        reviewRating.rating = $scope.rate;

                        ClientBookingService.addReviewRatingByClient().save(reviewRating, function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.closeuib();
                            $state.reload();
                        } else {
                            logger.logError(response.message);

                        }
                    });
                    }

                }
            });
        };

        $scope.testFunc = function(rating){
            var displatRating=[];
            for(var i=0;i<5;i++){
              if(rating-i>=1){
                displatRating.push({starType:'fa-star'}); 
              }else if(rating-i<1 && rating-i>0){
                displatRating.push({starType:'fa-star-half-o'}); 
              }else{
                displatRating.push({starType:'fa-star-o'}); 
              }
            }
            return displatRating;
        }

        $scope.getReviewByBookingId = function() {
            if($stateParams.id){
                ClientBookingService.getReviewByBookingId().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var ratingArr = [];
                        if(response.data != undefined && response.data != '' && response.data != null){
                            $scope.reviewRating = response.data;
                            $scope.ratingArr = $scope.testFunc($scope.reviewRating.rating);
                        }else{
                            $scope.ratingArr = [];
                            $scope.reviewRating = {};    
                        }
                    } else {
                        $scope.reviewRating = {};
                        $scope.ratingArr = [];
                    }
                })
            } 
        };  

        $scope.getAllLanguagesInClientBooking = function(){
            ClientBookingService.getAllLanguagesInClientBooking().get({},function(response, err){
                if(response.status == 1){
                    $scope.clientLanguages = response.data;
                }else{
                    $scope.clientLanguages = {};
                }
            })
        }

        $scope.getInterpreterNamesByLanguageIdInClient = function(languageId){
            // $scope.booking.interpreter_id = "";
            ClientBookingService.getInterpreterNamesByLanguageId().get({id:languageId},function(response, err){
                if(response.status == 1){
                    $scope.intepreterName = response.data;
                }else{
                    $scope.intepreterName = {};
                }
            })
        } 

        $scope.clearInterpreter = function(focus){
            $scope.booking.interpreter_id = "";

        }    
    }
]);
