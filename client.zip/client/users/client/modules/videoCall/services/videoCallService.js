"use strict"

angular.module("VideoCall")

.factory('VideoCallService', ['$http', '$resource', function($http, $resource) {
 
    var listAgencyClients = function() {
        return $resource(webservices.listAgencyClients, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteAgencyClient = function(id) {
        return $resource(webservices.deleteAgencyClient, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }


    var addAgencyClients = function() {
        return $resource(webservices.addAgencyClients, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAgencyClientById = function(id) {
        return $resource(webservices.getAgencyClientById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var updateAgencyClient = function() {
        return $resource(webservices.updateAgencyClient, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var changeClientStatus = function() {
        return $resource(webservices.changeClientStatus, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var createTokenAndSessionId = function() {
        return $resource(webservices.createTokenAndSessionId, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var listVideoCallBookingByClientId = function() {
        return $resource(webservices.listVideoCallBookingByClientId, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getVideoCallDetailsByIdInClient = function(id) {
        return $resource(webservices.getVideoCallDetailsByIdInClient, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }


    return {
        listAgencyClients: listAgencyClients,
        deleteAgencyClient: deleteAgencyClient,
        addAgencyClients: addAgencyClients,
        getAgencyClientById: getAgencyClientById,
        updateAgencyClient: updateAgencyClient,
        changeClientStatus: changeClientStatus,

        createTokenAndSessionId: createTokenAndSessionId,
        listVideoCallBookingByClientId: listVideoCallBookingByClientId,
        getVideoCallDetailsByIdInClient: getVideoCallDetailsByIdInClient

    }

}]);
