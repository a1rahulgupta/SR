"use strict";

angular.module("ClientComplaint")

interpreterApp.controller("clientComplaintController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger', 'ClientComplaintService', 'ngTableParams', 'ngTableParamsService','geolocation','BookingService','CommonService',
    function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal, logger, ClientComplaintService, ngTableParams, ngTableParamsService,geolocation,BookingService,CommonService) {
        
        /* Variable is used for update and non update condition */
        if ($state.params.id) {
            $scope.isUpdate = true;
        } else {
            $scope.isUpdate = false;
        };
        /* End */ 

        /* Variables is used for bootstrap datepicker */ 
        $scope.dateModel = {};
        $scope.today = function() {
            $scope.dt = new Date();
        };
        $scope.dateformat = "dd/MM/yyyy";
        $scope.today();
        $scope.showcalendar = function($event) {
            $scope.dateModel.showdp = true;
        };
        $scope.showcalendar1 = function($event) {
            $scope.dateModel.showdp1 = true;
        };
        $scope.dateModel.showdp = false;
        $scope.dateModel.showdp1 = false;
        $scope.dtmax = new Date();
        /* End */ 
        
        /* Variable is used to active class on leftbar */
        $rootScope.menuComplaint= ['client_listComplaint','client_addComplaint', 'client_viewComplaint'];
        /* End */

        /**
        * Function is used to get completed bookings for dropdown
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Apr-2018
        **/
        $scope.getCompletedBookingsByClientId = function(){
            ClientComplaintService.getCompletedBookingsByClientId().get(function(response){
                if(response.status == 1){
                    $scope.bookingDetails = response.data;
                } else{ 
                    logger.logError(response.message);
                }
            })
        }
        /* End */

        /**
        * Function is used to get completed bookings for update it includes lodge complaints bookings
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Apr-2018
        **/
        $scope.getCompletedBookingsForUpdate = function(){
            ClientComplaintService.getCompletedBookingsForUpdate().get(function(response){
                if(response.status == 1){
                    $scope.bookingDetails = response.data;
                } else{ 
                    logger.logError(response.message);
                }
            })
        }
        /* End */

        /**
        * Function is used to get selected booking details
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Apr-2018
        **/
        $scope.getSelectedBookingDetail = function(id){
            if(id == undefined || id == null || id == ''){
                $scope.booking = {};
                $scope.complaint = {};
            }else{
                ClientComplaintService.getSelectedBookingDetail().get({id:id},function(response, err){
                    if(response.status == 1){
                        var booking = response.data; 
                        booking.InterpreterName = booking.interpreter_id.first_name.charAt(0).toUpperCase()+booking.interpreter_id.first_name.slice(1).toLowerCase()+ ' '+booking.interpreter_id.last_name.charAt(0).toUpperCase()+booking.interpreter_id.last_name.slice(1).toLowerCase(); 
                        $scope.booking = booking;
                    } else{
                        $scope.booking = {}
                        logger.logError(response.message);
                    }
                })
            }
        }
        /* End */

        /**
        * Function is used to lodge complaint
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Apr-2018
        **/
        $scope.lodgeComplaintByClient = function(){
            var data = {
                booking_id: $scope.booking.booking_id._id,
                client_id: $scope.booking.client_id._id,
                interpreter_id: $scope.booking.interpreter_id._id,
                agency_id: $scope.booking.agency_id._id,
                service_title: $scope.booking.booking_id.service_title,
                booking_description: $scope.booking.booking_id.booking_description,
                complaint_comments: $scope.complaint.complaint_comments,
                check_in_out_id: $scope.complaint.check_in_out_id
            }
            console.log("data", data);
            ClientComplaintService.lodgeComplaintByClient().save(data, function(response){
                if(response.status == 1){
                  logger.logSuccess(response.message); 
                  $state.go("client_listComplaint");
                } else{
                  logger.logError(response.message);
                }
            })
        }
        /* End */

        /**
        * Function is used to list all the lodge complaint
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-oct-2017
        * Modified Date 6-Apr-2018
        **/
        $scope.listComplaintByClientId = function() {
            ngTableParamsService.set('', '', '', '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.complaintList = [];
                    ClientComplaintService.listComplaintByClientId().save($scope.paramUrl, function(response, err) {
                      console.log(response);
                        if (response.status == 1) {
                            $scope.tableLoader = false;
                            $scope.complaintList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };
        /* End */

        /**
        * Function is used to list all the lodge complaint
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-oct-2017
        * Modified Date 6-Apr-2018
        **/
        $scope.listComplaintSearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.complaintList = [];
                    ClientComplaintService.listComplaintByClientId().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.complaintList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };
        /* End */

        /**
        * Function is used to search complaints of an client between dates
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Dec-2017
        * Modified Date 6-Apr-2018
        **/
        $scope.searchComplaintByDate = function() {
            var date = {};
            date.searchFrom = $scope.complaintFrom;
            date.searchTo = $scope.complaintTo;
            ngTableParamsService.set('', '', '', '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.complaintList = [];
                    $scope.paramUrl.searchFrom = $scope.complaintFrom;
                    $scope.paramUrl.searchTo = $scope.complaintTo;
                    ClientComplaintService.searchComplaintByDate().save($scope.paramUrl, function(response, err) {
                        if (response.status == 1) {
                            $scope.tableLoader = false;
                            $scope.complaintList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };
        /* End */

        /**
        * Function is used to get complaint by id
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-oct-2017
        * Modified Date 6-Apr-2018
        **/
        $scope.getComplaintById = function(){
            if($stateParams.id){
                ClientComplaintService.getComplaintById().get({id:$stateParams.id},function(response, err){
                    console.log(response)
                    if(response.status == 1){
                        var complaint = response.data;
                        var booking = {};
                        booking.InterpreterName = complaint.interpreter_id.first_name.charAt(0).toUpperCase()+complaint.interpreter_id.first_name.slice(1).toLowerCase()+ ' '+complaint.interpreter_id.last_name.charAt(0).toUpperCase()+complaint.interpreter_id.last_name.slice(1).toLowerCase(); 
                        booking.booking_id = {
                            booking_short_id : complaint.booking_id.booking_short_id,
                            booking_description: complaint.booking_description
                        };
                        $scope.booking = booking;
                        var check_in_date = moment(complaint.check_in_out_id.check_in_date).format('MM-DD-YYYY');
                        $scope.title_with_date = complaint.service_title+' ('+ check_in_date+')';
                        $scope.complaint = complaint;
                    }else{
                        $scope.booking = {};
                        $scope.complaint = {};
                        logger.logError(response.message);
                        $state.go('client_listComplaint');
                    }
                })
            }
        };
        /* End */

        /**
        * Function is used to update complaint by id
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-oct-2017
        * Modified Date 6-Apr-2018
        **/
        $scope.updateComplaint = function() {
            var data = {
                _id: $scope.complaint._id,
                complaint_comments: $scope.complaint.complaint_comments
            }
            ClientComplaintService.updateComplaint().save(data, function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $state.go('client_listComplaint');
                } else {
                    logger.logError(response.message);
                }
            });
        };
        /* End */

        /**
        * Function is used to delete complaint by id
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-oct-2017
        * Modified Date 6-Apr-2018
        **/
        $scope.deleteComplaint = function(id, $event) {
            $event.stopPropagation();
            bootbox.confirm('Are you sure, you want to delete this complaint?', function(r) {
                if (r) {
                    ClientComplaintService.deleteComplaint().delete({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listComplaintByClientId();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        }
        /* End */

        /* Function is used to view complaint */
        $scope.viewComplaint = function(complaint) {
            $state.go('client_viewComplaint', {id:complaint._id});
        };
        /* End */

        /* Function is used to clear the value of bootstrap datepickers */
        $scope.clearSearch = function(){
            $scope.complaintFrom = "";
            $scope.complaintTo = "";
            $state.reload();
        }
        /* End */

         /**
        * Function is used to approve complaint
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Apr-2018
        **/
        $scope.approveComplaint = function(id, $event) {
            $event.stopPropagation();
            bootbox.confirm('Are you sure, you want to approve this complaint?', function(r) {
                if (r) {
                    ClientComplaintService.approveComplaint().save({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listComplaintByClientId();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        }
        /* End */
                
    }

]);