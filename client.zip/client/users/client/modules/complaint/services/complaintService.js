"use strict"

angular.module("ClientComplaint")

.factory('ClientComplaintService', ['$http', '$resource', function($http, $resource) {

    var deleteComplaint = function(id) {
        return $resource(webservices.deleteComplaint, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var updateComplaint = function() {
        return $resource(webservices.updateComplaint, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getCompletedBookingsByClientId = function() {
        return $resource(webservices.getCompletedBookingsByClientId, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getSelectedBookingDetail = function(id) {
        return $resource(webservices.getSelectedBookingDetail, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var lodgeComplaintByClient = function() {
        return $resource(webservices.lodgeComplaintByClient, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var listComplaintByClientId = function() {
        return $resource(webservices.listComplaintByClientId, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getComplaintById = function(id) {
        return $resource(webservices.getComplaintById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getCompletedBookingsForUpdate = function() {
        return $resource(webservices.getCompletedBookingsForUpdate, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var searchComplaintByDate = function() {
        return $resource(webservices.searchComplaintByDate, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var approveComplaint = function() {
        return $resource(webservices.approveComplaint, null, {
            save: {
                method: 'POST'
            }
        });
    }

    return {
        getComplaintById: getComplaintById,
        listComplaintByClientId: listComplaintByClientId,
        getCompletedBookingsByClientId: getCompletedBookingsByClientId,
        getSelectedBookingDetail: getSelectedBookingDetail,
        lodgeComplaintByClient: lodgeComplaintByClient,
        deleteComplaint: deleteComplaint,
        updateComplaint: updateComplaint,
        getCompletedBookingsForUpdate: getCompletedBookingsForUpdate,
        searchComplaintByDate: searchComplaintByDate,
        approveComplaint: approveComplaint

    }

}]);
