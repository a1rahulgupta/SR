"use strict";

angular.module("Report")

interpreterApp.controller("reportController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams','$window', '$http', '$uibModal', 'logger', 'ReportService','BookingService', 'ngTableParams', 'ngTableParamsService', 'CommonService','blockUI','blockUIConfig',
    function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams,$window, $http, $uibModal, logger, ReportService,BookingService, ngTableParams, ngTableParamsService, CommonService,blockUI,blockUIConfig) {

    	$rootScope.menuReport = ['agency_reportHome', 'agency_listReportForCustomer','agency_listReportForLanguage', 'agency_listTopLanguage', 'agency_listTopAccounts', 'agency_listReportForInterpreter'];
        var baseUrl = location.protocol + '//' + location.hostname + (location.port ? ':' + location.port : '');

        $scope.getClientNameByClientIdInReport = function(){
            ReportService.getClientNameByClientIdInReport().get({id:$state.params.id},function(response, err){
                if(response.status == 1){
                    var clientData = response.data;
                    $scope.clientName = clientData.first_name +' '+ clientData.last_name;
                }else{
                    $scope.clientName = {};
                }
            })
        }

        $scope.getClientCompletedBookings = function() {
            ngTableParamsService.set('', '', '', '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {                
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.bookingList = [];
                    var paramUrl = $scope.paramUrl;
                    paramUrl.clientId = $state.params.id;
                    ReportService.getClientCompletedBookings().save(paramUrl, function(response, err) {                        
                        if (response.status == 1) {
                            $scope.tableLoader = false;
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };

        $scope.getClientBookingListBySearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.bookingList = [];
                    var paramUrl = $scope.paramUrl;
                    paramUrl.clientId = $state.params.id;
                    ReportService.getClientCompletedBookings().save(paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };
        
        $scope.exportClientCompletedBookingsToPdf = function(){
            if($state.params.id){
                ReportService.exportClientCompletedBookingsToPdf().get({id:$stateParams.id}, function(response) {
                    if (response.status == 1) {
                        blockUI.start();    
                        var fileName = response.data;
                        $scope.str =  fileName.substring(17, 68);
                        var fileURL = baseUrl+$scope.str
                        if(fileName !=undefined && fileName !=null && fileName !=''){
                            $window.open(fileURL); 
                        }
                        blockUI.stop();
                    } else {
                        $scope.str = {};
                        logger.logError(response.message);
                    }
                });
            }
        }

        $scope.generateReportModal = function(bookingId) {
            $uibModal.open({
                    templateUrl: 'agency/modules/report/views/generateReportModal.html',
                    size: "md",
                    controller: function($scope,$rootScope, $uibModalInstance,ngTableParams,ngTableParamsService) {

                        $scope.closeuib = function() {
                            $uibModalInstance.close();
                        }

                        $scope.listAgencyClientsInReport = function(){
                            ReportService.listAgencyClientsInReport().get({},function(response, err){ 
                                if(response.status == 1){
                                    $scope.agencyClients = response.data;
                                }else{
                                    $scope.agencyClients = {};
                                }
                            })
                       }
                       $scope.listBookingByClientIdInReport = function(clientId) {
                        if(clientId){
                            $scope.closeuib();
                            $state.go("agency_listReportForCustomer",{id:clientId});
                        }

                    };

                }
            });
        };

        $scope.getLanguageNameByLanguageIdInReport = function(){
            ReportService.getLanguageNameByLanguageIdInReport().get({id:$state.params.language},function(response, err){
                if(response.status == 1){
                    var languageData = response.data;
                    $scope.languageName = languageData.language_name;
                }else{
                    $scope.languageName = {};
                }
            })
        }

        $scope.getLanguageCompletedBookings = function() {
            ngTableParamsService.set('', '', '', '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {                
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.bookingList = [];
                    var paramUrl = $scope.paramUrl;
                    paramUrl.language = $state.params.language;
                    ReportService.getLanguageCompletedBookings().save(paramUrl, function(response, err) {
                        if (response.status == 1) {
                            $scope.tableLoader = false;
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };

        $scope.getLanguageCompletedBookingsBySearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.bookingList = [];
                    var paramUrl = $scope.paramUrl;
                    paramUrl.language = $state.params.language;
                    ReportService.getLanguageCompletedBookings().save(paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        $scope.exportPerLanguageToPdf = function(){
            if($state.params.language){
                ReportService.exportPerLanguageToPdf().get({language:$stateParams.language}, function(response) {
                    if (response.status == 1) {
                        blockUI.start();
                        var fileName = response.data;
                        $scope.str =  fileName.substring(17, 68);
                        var fileURL = baseUrl+$scope.str
                        if(fileName !=undefined && fileName !=null && fileName !=''){
                            $window.open(fileURL); 
                        }
                        blockUI.stop();
                    } else {
                        $scope.str = {};
                        logger.logError(response.message);
                    }
                });
            }
        }

        $scope.languageReportModal = function(bookingId) {
            $uibModal.open({
                    templateUrl: 'agency/modules/report/views/languageReportModal.html',
                    size: "md",
                    controller: function($scope,$rootScope, $uibModalInstance,ngTableParams,ngTableParamsService) {

                        $scope.closeuib = function() {
                            $uibModalInstance.close();
                        }

                       $scope.listLanguageBookingInReport = function(language) {
                        if(language){
                            $scope.closeuib();
                            $state.go("agency_listReportForLanguage",{language:language});
                        }

                    };

                    $scope.getAllLanguagesInReport = function(){
                        ReportService.getAllLanguagesInReport().get({},function(response, err){
                            if(response.status == 1){
                                $scope.reportLanguages = response.data;
                            }else{
                                $scope.reportLanguages = {};
                            }
                        })
                    }
                }
            });
        };

        $scope.topCustomerReportModal = function(bookingId) {
            $uibModal.open({
                    templateUrl: 'agency/modules/report/views/topCustomerReportModal.html',
                    size: "md",
                    controller: function($scope,$rootScope, $uibModalInstance,ngTableParams,ngTableParamsService) {

                        $scope.closeuib = function() {
                            $uibModalInstance.close();
                        }
                }
            });
        };

        $scope.getTopTenClients = function(){
            ReportService.getTopTenClients().get({},function(response, err){ 
                if(response.status == 1){
                    $scope.topTenClientsList = response.data;
                }else{
                    $scope.topTenClients = {};
                }
            })
        }

        $scope.getTopTenLanguageReport = function(){
            ReportService.getTopTenLanguageReport().get({},function(response, err){ 
                if(response.status == 1){
                    $scope.topTenLanguageList = response.data;
                }else{
                    $scope.topTenLanguageList = {};
                }
            })
        }

        $scope.exportTopTenClientsToPdf = function(){
            ReportService.exportTopTenClientsToPdf().get({}, function(response) {
                if (response.status == 1) {
                    blockUI.start();
                    var fileName = response.data;
                    $scope.str =  fileName.substring(17, 68);
                    var fileURL = baseUrl+$scope.str;
                    if(fileName !=undefined && fileName !=null && fileName !=''){
                        $window.open(fileURL); 
                    }
                    blockUI.stop();
                } else {
                    $scope.str = {};
                    logger.logError(response.message);
                }
            })
        }        

        $scope.exportTopTenLaguageToPdf = function(){
            ReportService.exportTopTenLaguageToPdf().get(function(response) {
                if (response.status == 1) {
                    blockUI.start();    
                    var fileName = response.data;
                    $scope.str =  fileName.substring(17, 68);
                    var fileURL = baseUrl+$scope.str
                    if(fileName !=undefined && fileName !=null && fileName !=''){
                        $window.open(fileURL); 
                    }
                    blockUI.stop();
                } else {
                    $scope.str = {};
                    logger.logError(response.message);
                }
            });
        }

        // $scope.getAllLanguagesInReport = function(){
        //     ReportService.getAllLanguagesInReport().get({},function(response, err){
        //         if(response.status == 1){
        //             $scope.reportLanguages = response.data;
        //             console.log("reportLanguages", $scope.reportLanguages);
        //         }else{
        //             $scope.reportLanguages = {};
        //         }
        //     })
        // }

        /**
        * Function is used for generate modal for interpreter booking report
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 06-Mar-2018
        **/
        $scope.generateInterpreterReportModal = function() {
            $uibModal.open({
                templateUrl: 'agency/modules/report/views/generateInterpreterReportModal.html',
                size: "md",
                controller: function($scope,$rootScope, $uibModalInstance,ngTableParams,ngTableParamsService) {

                    $scope.closeuib = function() {
                        $uibModalInstance.close();
                    }

                    $scope.listAgencyInterpretersInReport = function(){
                        ReportService.listAgencyInterpretersInReport().get({},function(response, err){ 
                            if(response.status == 1){
                                $scope.agencyInterpreters = response.data;
                            }else{
                                $scope.agencyInterpreters = {};
                            }
                        })
                    }
                    
                    $scope.listBookingByInterpreterIdInReport = function(interpreterId) {
                        if(interpreterId){
                            $scope.closeuib();
                            $state.go("agency_listReportForInterpreter",{id:interpreterId});
                        }
                    };


                }
            });
        };

        /**
        * Function is used to get the interpreter name by interpreter id 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 06-Mar-2018
        **/
        $scope.getInterpreterNameByInterpreterIdInReport = function(){
            ReportService.getInterpreterNameByInterpreterIdInReport().get({id:$state.params.id},function(response, err){
                if(response.status == 1){
                    var interpreterData = response.data;
                    $scope.interpreterName = interpreterData.first_name +' '+ interpreterData.last_name;
                }else{
                    $scope.interpreterName = {};
                }
            })
        }

        /**
        * Function is used to get interpreter completed bookings 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 06-Mar-2018
        **/
        $scope.getInterpreterCompletedBookings = function() {
            ngTableParamsService.set('', '', '', '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {                
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.bookingList = [];
                    var paramUrl = $scope.paramUrl;
                    paramUrl.interpreterId = $state.params.id;
                    ReportService.getInterpreterCompletedBookings().save(paramUrl, function(response, err) {                        
                        if (response.status == 1) {
                            $scope.tableLoader = false;
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };

        /**
        * Function is used for searching in interpreter completed bookings 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 06-Mar-2018
        **/
        $scope.getInterpreterBookingListBySearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.bookingList = [];
                    var paramUrl = $scope.paramUrl;
                    paramUrl.interpreterId = $state.params.id;
                    ReportService.getInterpreterCompletedBookings().save(paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        /**
        * Function is used export pdf for completed bookings of interpreter 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 06-Mar-2018
        **/
        $scope.exportInterpreterCompletedBookingsToPdf = function(){
            if($state.params.id){
                ReportService.exportInterpreterCompletedBookingsToPdf().get({id:$stateParams.id}, function(response) {
                    if (response.status == 1) {
                        blockUI.start();    
                        var fileName = response.data;
                        $scope.str =  fileName.substring(17, 68);
                        var fileURL = baseUrl+ $scope.str
                        if(fileName !=undefined && fileName !=null && fileName !=''){
                            $window.open(fileURL); 
                        }
                        blockUI.stop();
                    } else if(response.status == 4){
                        $scope.str = {};
                        logger.log(response.message);
                    }else{
                        $scope.str = {};
                        logger.logError(response.message);
                    }
                });
            }
        }

    }

]);
