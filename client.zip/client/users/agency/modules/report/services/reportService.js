"use strict"

angular.module("Report")

.factory('ReportService', ['$http', '$resource', function($http, $resource) {

    var listAgencyClientsInReport = function() {
        return $resource(webservices.listAgencyClientsInReport, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getClientCompletedBookings = function() {
        return $resource(webservices.getClientCompletedBookings, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getLanguageCompletedBookings = function() {
        return $resource(webservices.getLanguageCompletedBookings, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var exportClientCompletedBookingsToPdf = function(id) {
        return $resource(webservices.exportClientCompletedBookingsToPdf, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var exportPerLanguageToPdf = function(language) {
        return $resource(webservices.exportPerLanguageToPdf, null, {
            save: {
                method: 'GET',
                id: '@language'
            }
        });
    }

    var getTopTenClients = function() {
        return $resource(webservices.getTopTenClients, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getTopTenLanguageReport = function() {
        return $resource(webservices.getTopTenLanguageReport, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var exportTopTenClientsToPdf = function() {
        return $resource(webservices.exportTopTenClientsToPdf, null, {
            save: {
                method: 'GET'
            }
        });
    }    
    

    var exportTopTenLaguageToPdf = function() {
        return $resource(webservices.exportTopTenLaguageToPdf, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getAllLanguagesInReport = function() {
        return $resource(webservices.getAllLanguagesInReport, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getClientNameByClientIdInReport = function(id) {
        return $resource(webservices.getClientNameByClientIdInReport, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getLanguageNameByLanguageIdInReport = function(id) {
        return $resource(webservices.getLanguageNameByLanguageIdInReport, null, {
            save: {
                method: 'GET',
                id: '@language'
            }
        });
    }

    var listAgencyInterpretersInReport = function() {
        return $resource(webservices.listAgencyInterpretersInReport, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getInterpreterNameByInterpreterIdInReport = function(id) {
        return $resource(webservices.getInterpreterNameByInterpreterIdInReport, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getInterpreterCompletedBookings = function() {
        return $resource(webservices.getInterpreterCompletedBookings, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var exportInterpreterCompletedBookingsToPdf = function(id) {
        return $resource(webservices.exportInterpreterCompletedBookingsToPdf, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    return {
        
        listAgencyClientsInReport: listAgencyClientsInReport,
        getClientCompletedBookings: getClientCompletedBookings,
        getLanguageCompletedBookings: getLanguageCompletedBookings,
        exportClientCompletedBookingsToPdf: exportClientCompletedBookingsToPdf,
        exportPerLanguageToPdf: exportPerLanguageToPdf,
        getTopTenClients: getTopTenClients,
        getTopTenLanguageReport: getTopTenLanguageReport,
        exportTopTenClientsToPdf: exportTopTenClientsToPdf,
        exportTopTenLaguageToPdf: exportTopTenLaguageToPdf,
        getAllLanguagesInReport: getAllLanguagesInReport,
        getClientNameByClientIdInReport: getClientNameByClientIdInReport,
        getLanguageNameByLanguageIdInReport: getLanguageNameByLanguageIdInReport,
        listAgencyInterpretersInReport: listAgencyInterpretersInReport,
        getInterpreterNameByInterpreterIdInReport: getInterpreterNameByInterpreterIdInReport,
        getInterpreterCompletedBookings: getInterpreterCompletedBookings,
        exportInterpreterCompletedBookingsToPdf: exportInterpreterCompletedBookingsToPdf

    }

}]);