
interpreterApp.controller('profileCtrl', ['$rootScope','$scope', '$state',
	'$uibModalInstance', '$uibModal',
  '$location', 'logger', 'data','CommonService', 'AuthenticationService', 'UserService', '$timeout',
  function($rootScope, $scope, $state, $uibModalInstance, $uibModal, $location, logger, data , 
  CommonService, AuthenticationService, UserService) { 
    
    //var timezone = moment.tz.names();
    //console.log('timezone:- ',timezone);


    $rootScope.user = CommonService.getUser();
    $scope.imageBase64 = '';
    var formDataFileUpload = '';

 
    //Tabing feature code starts
    $rootScope.tab1 = 1;
    $scope.tab = 1;
		if ($rootScope.tab1) {
        $scope.tab = $rootScope.tab1;
    } else {
        $scope.tab = 1;
    }
    $scope.isSet = function(tabId) {
        if ($rootScope.tab1 === tabId) {
            return true;
        }
    };
    $scope.setViewTab = function(tabId) {
        $rootScope.tab1 = tabId;
        $scope.tab = tabId;       
    };
    //Tabing feature code starts


    $scope.closeuib = function() {
        $uibModalInstance.close('a');
    }

    /**
     * Function is use to img Init for image upload
     * @access private
     * @return json
     * Created by Ashwini
     * @smartData Enterprises (I) Ltd
     * Created Date 19-Aug-2017
     */
    $scope.imgInit = function() {
        $scope.imageError = false;

        document.getElementById('filePicker').addEventListener('change', function(evt) {

            var files = evt.target.files;
            var file = files[0];
            if (files && file) {
                var splitFileName = file.name.split('.');
                var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {                    
                    if (file.size > 10485760) { //6291456 1093533
                        // logger.log('File size cannot exceed limit of 6 mb');
                        document.getElementById("filePicker").value = "";
                        $scope.imageError = true;
                        $scope.$apply();
                    } else {

                        formDataFileUpload = file;
                        // formDataFileUpload.append('file', file);
                        var reader = new FileReader();
                        reader.onload = function(readerEvt) {
                            $scope.preview = true;
                            $scope.imageBase64 = 'data:image/' + ext + ';base64,' + btoa(readerEvt.target.result);
                            document.getElementById('imgTag').src = $scope.imageBase64;
                            $scope.$apply();
                        };
                        reader.readAsBinaryString(file);
                    }
                } else {
                    document.getElementById("filePicker").value = "";
                    bootbox.alert('File format is not supported, please upload a file with one of the following extensions: .jpg,.jpeg,.png');
                }
            }
        }, false);
    }


    /**
     * Function is use to get Timezone List
     * @access private
     * @return json
     * Created by Ashwini
     * @smartData Enterprises (I) Ltd
     * Created Date 19-Aug-2017
     */
    $scope.getTimezoneList = function() {
        AuthenticationService.getTimezoneList().get({}, function(response, err) {
            if (response.code == statusCode.ok) {
                $scope.timezoneList = response.data;
            } else {
                logger.logError(response.message);
            }
        });        
    }


    /**
     * Function is use to update Profile
     * @access private
     * @return json
     * Created by Ashwini
     * @smartData Enterprises (I) Ltd
     * Created Date 19-Aug-2017
     */
    $scope.updateProfile = function(form) {

        if (form.$valid) {
            $scope.loader = true;
            $scope.disabled = true;

            UserService.updateProfile().save($scope.user, function(response, err) {

                var errorMessage = '';
                $scope.disabled = false;
                $scope.loader = false;
                if (response.code == statusCode.ok) {

                    if (formDataFileUpload) {
                        var formData = new FormData();
                        formData.append('id', response.data._id);
                        formData.append('file', formDataFileUpload);

                        AuthenticationService.uploadImage().save(formData, function(imgResp, err) {
                            if (imgResp.code == statusCode.ok) {                            	
                            	CommonService.setUser(imgResp.data);
                            	$rootScope.user = CommonService.getUser();
                            	$uibModalInstance.close({});
                              $scope.getUserListLeftTab();
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    } else {
                    	$rootScope.user = CommonService.getUser();
                    	$uibModalInstance.close({});
                    }
                } else {
                    logger.logError(response.message);
                }
            });
        }
    };

    /**
     * Function is use to change Password after login at profile page
     * @access private
     * @return json
     * Created by Ashwini
     * @smartData Enterprises (I) Ltd
     * Created Date 19-Aug-2017
     */
    $scope.changePassword = function(form) {
        if (form.$valid) {
            $scope.disabledUpdate = true;
            $scope.loaderChangePass = true;
            $scope.changePass.userId = CommonService.getUser()._id;
            UserService.changePassword().save($scope.changePass, function(response) {
                $scope.disabledUpdate = false;
                $scope.loaderChangePass = false;
                if (response.code == statusCode.ok) {
                	$uibModalInstance.close({});
                    logger.logSuccess(response.message);
                } else {
                    logger.logError(response.message);
                }
            });
        }
    }


}])

