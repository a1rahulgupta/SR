	"use strict";

	angular.module("Dashboard")

	interpreterApp.controller("dashboardController", ['$scope', '$rootScope', '$localStorage',
	    'ngTableParams', '$routeParams', '$route', '$location', '$filter', 'logger',
	    'ngTableParamsService', '$state', '$stateParams', '$uibModal', 'dashboardService',
	    function($scope, $rootScope, $localStorage, ngTableParams, $routeParams,
	        $route, $location, $filter, logger, ngTableParamsService, $state, $stateParams,
	        $uibModal, dashboardService) {
	        $scope.imageBase64 = '';
	        $scope.add = false;
	        $scope.preview = false;
	        $scope.customer = {};
	        $scope.disabled = false;
	        $scope.loader = false;
	        //$scope.loggedInUserData = $rootScope.loggedInUserData;
	        $scope.loggedInUserData = $localStorage.user;


	        $scope.getCountOfAgency  = function(){
	        	dashboardService.getCountOfAgency().get(function(response, err){
	        		if(response.status == 1){
	        			$scope.count = response.data;
	        		} else{
	        			$scope.count = {};
	        		}
	        	})
	        }

	        $scope.imageBase64 = '';
	        $scope.add = false;
	        $scope.preview = false;
	        $scope.customer = {};
	        $scope.disabled = false;
	        $scope.loader = false;
	        //$scope.loggedInUserData = $rootScope.loggedInUserData;
	        $scope.loggedInUserData = $localStorage.user;

	        $scope.myImage='';
	        $scope.myCroppedImage='';
	        $scope.isImageSelected=false;
	        $scope.isCropVisible=false;
	        var handleFileSelect=function(evt) {
	            $scope.isImageSelected=false;
	            $scope.isCropVisible=true;
	          var file=evt.currentTarget.files[0];
	          var reader = new FileReader();
	          reader.onload = function (evt) {
	            $scope.$apply(function($scope){
	              $scope.myImage=evt.target.result;
	            });
	          };
	          reader.readAsDataURL(file);
	        };
	        angular.element(document.querySelector('#fileInput')).on('change',handleFileSelect);
	        $scope.openFileBrowse = function(fileInputSelector) {
	            angular.element(document.querySelector(fileInputSelector)).trigger('click');
	        };

        	var formDataFileUpload = '';
        	$scope.imageBase64 = '';
	        angular.element(document).ready(function() {
	            setTimeout(function() {
	                if(document.getElementById('fileInput')!=null){
	                    document.getElementById('fileInput').addEventListener('change', function(evt) {
	                        var files = evt.target.files;
	                        var file = files[0];
	                        if (files && file) {
	                            var splitFileName = file.name.split('.');
	                            var ext = splitFileName[splitFileName.length - 1].toLowerCase();
	                            if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {
	                                if (file.size > 6291456) {
	                                    logger.log('File size cannot exceed limit of 6 mb');
	                                    document.getElementById("fileInput").value = "";
	                                } else {
	                                    formDataFileUpload = file;
	                                    // formDataFileUpload.append('file', file);
	                                    var reader = new FileReader();
	                                    reader.onload = function(readerEvt) {
	                                        $scope.imageBase64 = btoa(readerEvt.target.result);
	                                        $scope.$apply();
	                                        document.querySelector('#imgTag').src = 'data:image/' + ext + ';base64,' + $scope.imageBase64;
	                                    };
	                                    reader.readAsBinaryString(file);
	                                }
	                            } else {
	                                document.getElementById("fileInput").value = "";
	                                bootbox.alert('Invalid image format');
	                            }
	                        }
	                    });
	                }
	            }, 500);
	        });

        	$scope.getAgencyProfileById = function(){
	            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                dashboardService.getAgencyProfileById().get(function(response, err){
                    if(response.status == 1){
                        var agency = response.data;
                    	agency.email = agency.user_id.email;
                        if(agency.profile_pic!='' && agency.profile_pic!=undefined){
                            $scope.userDefaultImage=agency.profile_pic;
                        }
                        setTimeout(function() {
	                        $scope.agency = agency;
	                        $scope.$apply();
                        },500)
                    }else{
                        $scope.agency = {};
                    }
                })
	        };

	        $scope.updateAgencyProfile = function() {
	            if($scope.isImageSelected==true){
	                $scope.agency.imageFile = $scope.myCroppedImage;
	            }
	            dashboardService.updateAgencyProfile().save($scope.agency, function(response, err) {
	                if (response.status == 1) {
	                    logger.logSuccess(response.message); 
	                    $location.path('/dashboard');
	                } else {
	                    logger.logError(response.message);
	                }
	            });
	        };

	        $scope.getAllCountriesInAgency = function(){
	            dashboardService.getAllCountriesInAgency().get({},function(response, err){
	                if(response.status == 1){
	                    var agencyCountries = response.data;
	                    $scope.agency = {};
	                    for(var i=0;i<agencyCountries.length;i++){
	                        if(agencyCountries[i].country_code == 'us'){
	                            $scope.agency.country_id = agencyCountries[i]._id;
	                        }
	                    }
	                    $scope.agencyCountries = agencyCountries 
	                }else{
	                    $scope.agencyCountries = {};
	                }
	            })
	        }

	    }

	]);


