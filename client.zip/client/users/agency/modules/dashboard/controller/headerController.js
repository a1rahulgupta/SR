"use strict";

angular.module("Header")

interpreterApp.controller("headerController", ['$scope', '$rootScope', '$localStorage','$state',
    '$location', 'logger', '$uibModal', 'CommonService', 'dashboardService',
    function($scope, $rootScope, $localStorage, $state, $location, logger, $uibModal,
        CommonService, dashboardService) {

        $rootScope.user = CommonService.getUser();
        //$scope.imageBase64 = $scope.user.image;
        $scope.userLeftSearch = false;
        $scope.leftUserSearch = {}
        
        
        /**
         * Function is use to get User List for Left Tab
         * @access private
         * @return json
         * Created by Ashwini
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        // $scope.getUserListLeftTab = function() {
        //     // UserService.getUserListLeftTab().save({ organizationId: $rootScope.user.organizationId._id }, function(response, err) {
        //     //console.log('getUserListLeftTab default organizationid:- ',$localStorage.user.defaultOrg.organization._id)
        //     UserService.getUserListLeftTab().save({ organizationId: $localStorage.user.defaultOrg.organization._id }, function(response, err) {
        //         if (response.code == 200) {
        //             $rootScope.userListLeftTab = response.data
        //         } else {
        //             $rootScope.userListLeftTab = {};
        //         }
        //     });
        // }
        $scope.closeSearch = function() {
            $scope.userLeftSearch = false;
        };

        /**
         * Function is use to set organization as default
         * @access private
         * @return json
         * Created by Ashwini
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.setOrganization = function(organizationId) {
            //console.log('organizationId:- '+organizationId);
            $scope.tableLoader = true;
            UserService.setOrganization().save({ organizationId: organizationId, userId:$localStorage.user._id }, function(response, err) {
                if (response.code == 200) {
                    $scope.tableLoader = false;
                    $state.reload();
                    //$rootScope.userListLeftTab = response.data
                } else {
                    $scope.tableLoader = false;
                    //$rootScope.userListLeftTab = {};
                }
            });
        }
        

        /**
         * Function is use to toggle search data in left tab
         * @access private
         * @return json
         * Created by Ashwini
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.toggle = function() {
            $scope.tableLoader = true;
            $scope.userLeftSearch = !$scope.userLeftSearch;
            var filter = {}
            filter.organizationId = $localStorage.user.defaultOrg.organization._id;
            filter.search = $scope.leftUserSearch.search;
            UserService.getUserListSearchLeftTab().save(filter, function(response) {
                if (response.code == 200) {
                    $scope.tableLoader = false;
                    $scope.userListSearchLeftTab = response.data
                } else {
                    $scope.tableLoader = false;
                    $scope.userListSearchLeftTab = {};
                }
            });
        }

        /**
         * Function is use to get User List Search Left Tab
         * @access private
         * @return json
         * Created by Ashwini
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.getUserListSearchLeftTab = function() {
            $scope.tableLoader = true;
            var filter = {}
            filter.organizationId = $localStorage.user.defaultOrg.organization._id;
            filter.search = $scope.leftUserSearch.search;
            UserService.getUserListSearchLeftTab().save(filter, function(response) {
                if (response.code == 200) {
                    $scope.tableLoader = false;
                    $scope.userListSearchLeftTab = response.data
                } else {
                    $scope.tableLoader = false;
                    $scope.userListSearchLeftTab = {};
                }
            });
        }


        /**
         * Function is use to open orgSetting popup
         * @access private
         * @return json
         * Created by Ashwini
         * @smartData Enterprises (I) Ltd
         * Created Date 11-09-2017
         */
        $scope.orgSetting = function(data) {
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: '/users/modules/dashboard/views/orgSettingModal.html',
                controller: 'orgSettingCtrl',
                size: 'md',
                scope: $scope,
                resolve: {
                    data: function() {
                        return data
                    }
                },
                selectedDate: null
            });
        };


        /**
         * Function is use to open myProfile popup
         * @access private
         * @return json
         * Created by Ashwini
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.myProfile = function(data) {
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: '/users/modules/dashboard/views/myProfileModal.html',
                controller: 'profileCtrl',
                size: 'md',
                scope: $scope,
                resolve: {
                    data: function() {
                        return data
                    }
                },
                // windowClass: 'service_view',
                selectedDate: null
            });
        };


        /**
         * Function is use to open inviteUser popup
         * @access private
         * @return json
         * Created by Ashwini
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.inviteUser = function(data) {
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: '/users/modules/dashboard/views/inviteUser.html',
                controller: 'inviteUserCtrl',
                size: 'md',
                scope: $scope,
                resolve: {
                    data: function() {
                        return data
                    }
                },
                selectedDate: null
            });
        };


        $scope.getAgencyProfileById = function(){
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            dashboardService.getAgencyProfileById().get(function(response, err){
                if(response.status == 1){
                    var agency = response.data;
                    agency.email = agency.user_id.email;
                    if(agency.profile_pic!='' && agency.profile_pic!=undefined){
                        $scope.userDefaultImage=agency.profile_pic;
                    }
                    $scope.agency = agency;
                }else{
                    $scope.agency = {};
                }
            })
        };

        $scope.changePasswordModal = function() {
            $uibModal.open({
                templateUrl: 'agency/modules/dashboard/views/changePasswordModal.html',
                size: "md",
                controller: function($scope,$rootScope, $uibModalInstance,ngTableParams,ngTableParamsService) {

                    $scope.closeuib = function() {
                        $uibModalInstance.close();
                    };

                    $scope.changePassword = function(form){
                        if (form.$valid) {
                            var passwordObj = {
                                oldPassword: $scope.oldPassword,
                                newPassword: $scope.newPassword
                            }
                            $scope.loader = true;
                            $scope.disabled = true;
                            if($scope.newPassword == $scope.confirmPassword){    
                                dashboardService.changePassword().save(passwordObj, function(response) {
                                    var errorMessage = '';
                                    $scope.disabled = false;
                                    $scope.loader = false;
                                    if(response.status == 1){
                                        logger.logSuccess(response.message);
                                        $scope.closeuib();
                                        $state.go('agency_dashboard');
                                    }else{
                                        logger.log(response.message);
                                    }
                                })
                            }else{
                                $scope.disabled = false;
                                logger.log("Confirm password does not match with new password!");
                            }
                        }
                    };

                }
            });
        };
    }
]);
