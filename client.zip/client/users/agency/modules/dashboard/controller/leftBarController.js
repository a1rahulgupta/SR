  "use strict";

  angular.module("LeftBar")

  interpreterApp.controller("leftBarController", ['$scope', '$rootScope', '$localStorage',
      'ngTableParams', '$routeParams', '$route', '$location', '$filter', 'logger',
      'ngTableParamsService', '$state', '$stateParams', '$uibModal', 'dashboardService',
      function($scope, $rootScope, $localStorage, ngTableParams, $routeParams,
          $route, $location, $filter, logger, ngTableParamsService, $state, $stateParams,
          $uibModal, dashboardService) {
          
          $scope.imageBase64 = '';
          $scope.add = false;
          $scope.preview = false;
          $scope.customer = {};
          $scope.disabled = false;
          $scope.loader = false;
          //$scope.loggedInUserData = $rootScope.loggedInUserData;
          $scope.loggedInUserData = $localStorage.user;

          $scope.getAgencyProfileById = function(){
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            dashboardService.getAgencyProfileById().get(function(response, err){
                if(response.status == 1){
                    var agency = response.data;
                    agency.email = agency.user_id.email;
                    if(agency.profile_pic!='' && agency.profile_pic!=undefined){
                        $scope.userDefaultImage=agency.profile_pic;
                    }
                    $scope.agency = agency;
                }else{
                    $scope.agency = {};
                }
            })
          };

          $scope.expandCollapseLeftSideBar = function(){
            if (window.innerWidth > 767) {
                
            }
            else{
               $("body").addClass("sidebar-collapse");
               $("body").removeClass("sidebar-open");
            }
          }
          


      }

  ]);


