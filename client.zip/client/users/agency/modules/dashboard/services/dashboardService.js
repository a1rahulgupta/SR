"use strict"

angular.module("Dashboard")

.factory('dashboardService', ['$http', '$resource', function($http, $resource) {

    var getUserList = function() {
        return $resource(webservices.getUserList, null, {
            save: {
                method: 'POST'
            }
        });
    }
    var getCustomerById = function() {
        return $resource(webservices.getCustomerById, null, {
            get: {
                method: 'GET',
                id: '@id'
            }
        });
    }
    var changeCustomerStatus = function() {
        return $resource(webservices.changeCustomerStatus, null, {
            save: {
                method: 'POST'
            }
        });
    }
    var updateCustomer = function() {
        return $resource(webservices.updateCustomer, null, {
            save: {
                method: 'POST',
            }
        });
    }

    var deleteCustomer = function() {
        return $resource(webservices.deleteCustomerById, null, {
            delete: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var getCountOfAgency = function() {
        return $resource(webservices.getCountOfAgency, null, {
            get: {
                method: 'GET'
            }
        });
    }

    var getAgencyProfileById = function() {
        return $resource(webservices.getAgencyProfileById, null, {
            get: {
                method: 'GET'
            }
        });
    }

    var updateAgencyProfile = function() {
        return $resource(webservices.updateAgencyProfile, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var changePassword = function() {
        return $resource(webservices.changePassword, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllCountriesInAgency = function() {
        return $resource(webservices.getAllCountriesInAgency, null, {
            save: {
                method: 'GET'
            }
        });
    }

    return {
        getUserList: getUserList,
        getCustomerById: getCustomerById,
        updateCustomer: updateCustomer,
        changeCustomerStatus: changeCustomerStatus,
        deleteCustomer: deleteCustomer,
        getCountOfAgency: getCountOfAgency,
        getAgencyProfileById: getAgencyProfileById,
        updateAgencyProfile: updateAgencyProfile,
        changePassword: changePassword,
        getAllCountriesInAgency: getAllCountriesInAgency
    }

}]);
