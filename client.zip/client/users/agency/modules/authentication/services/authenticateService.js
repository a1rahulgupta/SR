'use strict'

angular.module('Authentication')

.factory('AuthenticationService', ['$http', '$resource', function($http, $resource) {

    var userLogin = function() {
        return $resource(webservices.authenticate, null, {
            save: {
                method: 'POST'
            }
        });
    }
    var userRegister = function() {
        return $resource(webservices.userRegister, null, {
            save: {
                method: 'POST'
            }
        });
    }
    var userForgotPassword = function() {
        return $resource(webservices.userForgotPassword, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var setNewPassword = function() {
        return $resource(webservices.setNewPassword, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var resetPassword = function() {
        return $resource(webservices.resetPassword, null, {
            save: {
                method: 'POST'
            }
        });
    }
    var uploadImage = function() {
        return $resource(webservices.uploadImage, null, {
            save: {
                method: 'POST',
                headers: { 'Content-Type': undefined }
            }
        });
    }

    var getInviteUser = function() {
        return $resource(webservices.getInviteUser, null, {
            save: {
                method: 'POST'
            }
        });
    }
    var getEmailUsingKey = function() {
        return $resource(webservices.getEmailUsingKey, null, {
            get: {
                method: 'GET'
            }
        });
    }

    var updateCompleteRegister = function() {
        return $resource(webservices.updateCompleteRegister, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var completeUserRegistration = function() {
        return $resource(webservices.completeUserRegistration, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var agencyRegister = function() {
        return $resource(webservices.agencyRegister, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var agencyRegisterEmailCheck = function() {
        return $resource(webservices.agencyRegisterEmailCheck, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllSubscriptionData = function() {
        return $resource(webservices.getAllSubscriptionData, null, {
            get: {
                method: 'GET'
            }
        });
    }

    var getEmailUsingPassword = function() {
        return $resource(webservices.getEmailUsingPassword, null, {
            get: {
                method: 'GET'
            }
        });
    }

     var getBookingDetails = function() {
        return $resource(webservices.getBookingDetails, null, {
            get: {
                method: 'GET'
            }
        });
    }

    var saveBookingRequest = function() {
        return $resource(webservices.saveBookingRequest, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var subscribe = function() {
        return $resource(webservices.subscribe, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getCarouselDetails = function() {
        return $resource(webservices.getCarouselDetails, null, {
            get: {
                method: 'GET'
            }
        });
    }

    var activateAgencyWithSubscription = function() {
        return $resource(webservices.activateAgencyWithSubscription, null, {
            save: {
                method: 'POST'
            }
        });
    }

    //New 
    var acceptEventRequest = function() {
        return $resource(webservices.acceptEventRequest, null, {
            save: {
                method: 'POST'
            }
        });
    }

    return {
        userLogin: userLogin,
        userRegister: userRegister,
        userForgotPassword: userForgotPassword,
        setNewPassword: setNewPassword,
        resetPassword: resetPassword,
        uploadImage: uploadImage,
        getInviteUser: getInviteUser,
        updateCompleteRegister: updateCompleteRegister,
        getEmailUsingKey: getEmailUsingKey,
        completeUserRegistration: completeUserRegistration,
        agencyRegister: agencyRegister,
        agencyRegisterEmailCheck: agencyRegisterEmailCheck,
        getAllSubscriptionData: getAllSubscriptionData,
        getEmailUsingPassword: getEmailUsingPassword,
        getBookingDetails: getBookingDetails,
        saveBookingRequest: saveBookingRequest,
        subscribe: subscribe,
        getCarouselDetails: getCarouselDetails,
        activateAgencyWithSubscription: activateAgencyWithSubscription,

        acceptEventRequest: acceptEventRequest
    }

}]);
