"use strict";


angular.module("Authentication");

interpreterApp.controller('loginController', ['$scope', '$rootScope', '$location', 'AuthenticationService',
    '$localStorage', 'logger', '$stateParams', '$state', '$uibModal','socket','$timeout',
    function($scope, $rootScope, $location, AuthenticationService, $localStorage, logger, $stateParams, $state,
    $uibModal, socket, $timeout) {

        
        $scope.serviceUrl = "https://youtu.be/zlMAyknlNW8"
        /**
         * Declare and initialize variables for this controller
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        var inputJSON = "";
        $scope.imageBase64 = '';
        var formDataFileUpload = '';
        $scope.forgotPass = {};
        $scope.isPasswordSent = false;
        $scope.disabled = false;
        $scope.loader = false;

        /**
         * Function is use to verify Init
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.verifyInit = function() {
            $scope.parmas = $location.search();
            $scope.success = $scope.parmas.success;
        }

        /**
         * Function is use to image Init
         * @access private
         * @return json
         * Created by sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.findOne = function() {
            $scope.imageError = false;
            document.getElementById('filePicker').addEventListener('change', function(evt) {
                var files = evt.target.files;
                var file = files[0];
                if (files && file) {
                    var splitFileName = file.name.split('.');
                    var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                    if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {                       
                        if (file.size > 10485760) {  //6291456 1093533
                            logger.log('File size cannot exceed limit of 6 mb');
                            document.getElementById("filePicker").value = "";
                            $scope.imageError = true;
                            $scope.$apply();
                        } else {
                            formDataFileUpload = file;
                            var reader = new FileReader();
                            reader.onload = function(readerEvt) {
                                $scope.preview = true;
                                $scope.imageBase64 = 'data:image/' + ext + ';base64,' + btoa(readerEvt.target.result);
                                document.getElementById('imgTag').src = $scope.imageBase64;
                                $scope.$apply();
                            };
                            reader.readAsBinaryString(file);
                        }
                    } else {
                        document.getElementById("filePicker").value = "";
                        bootbox.alert('File format is not supported, please upload a file with one of the following extensions: .jpg,.jpeg,.png');
                    }
                }
            }, false);
        }

        
        /**
         * Function is use to login organization
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 18-Sep-2017
         */
        $scope.login = function(form) {
            if (form.$valid) {
                $scope.loader = true;
                $scope.disabled = true;
                AuthenticationService.userLogin().save($scope.user, function(response, err) {
                    var errorMessage = '';
                    $scope.disabled = false;
                    $scope.loader = false;

                    if (response.status == 1 && response.data.user.role == 'agency_admin') {
                        $localStorage.userLoggedIn = true;
                        $rootScope.userLoggedIn = true;
                        $localStorage.user = response.data.user.role;                        
                        $localStorage.token = response.data.token;
                        $location.path('/dashboard');
                    } else if(response.status == 1 && response.data.user.role == 'interpreter'){
                        $localStorage.userLoggedIn = true;
                        $rootScope.userLoggedIn = true;
                        $localStorage.user = response.data.user.role;                        
                        $localStorage.token = response.data.token;
                        socket.emit('adduser', response.data.user,function(){alert("here")});
                        socket.on('notify_client',function(notification){
                            switch(notification.notificationType){
                                case 'VIDEO_CALL_STARTED': 
                                    if( $state.current.name != 'interpreter_videoCall'){
                                        console.log(notification)
                                        bootbox.confirm(notification.videoData.sender_first_name+' '+notification.videoData.sender_last_name+' is calling you. Wanna join?', function(r) {
                                            if (r) {
                                                $timeout(function(){ 
                                                   $state.go('interpreter_videoCall',{id: notification.videoData.booking_id, video_id: notification.videoData.video_id});
                                                },1);
                                            }else{
                                                socket.emit('notify', {
                                                    user: notification.videoData.sender_id,
                                                    notificationType:'DENY_VIDEO_CALL',
                                                    sentBy: response.data.user.id
                                                },function(){}); 
                                            }
                                        });
                                    }else{
                                        logger.log("Client has joined call");
                                    }
                                break;
                                case 'DENY_VIDEO_CALL': 
                                    logger.log("Call is denied by interpreter");
                                    $location.path('/interpreter/dashboard');      
                                break;
                            }
                        });

                        $rootScope.conversations=[];
                        socket.on('message_client',function(messageData){
                            $rootScope.conversations.push(messageData);
                            $timeout(function(){ 
                               angular.element(document.querySelector('#video-session-chat')).scrollTop(document.querySelector('#video-session-chat').scrollHeight);
                            },100);
                            
                        });
                            
                        $location.path('/interpreter/dashboard');  

                    }else if(response.status == 1 && response.data.user.role == 'client'){
                        $localStorage.userLoggedIn = true;
                        $rootScope.userLoggedIn = true;
                        $localStorage.user = response.data.user.role;                        
                        $localStorage.token = response.data.token;
                        socket.emit('adduser', response.data.user,function(){alert("here")});
                        socket.on('notify_client',function(notification){
                             switch(notification.notificationType){
                                case 'VIDEO_CALL_STARTED': 
                                if( $state.current.name != 'client_videoCall'){
                                    bootbox.confirm(notification.videoData.sender_first_name+' '+notification.videoData.sender_last_name+' is calling you. Wanna join?', function(r) {
                                        if (r) {
                                            $timeout(function(){ 
                                                $state.go('client_videoCall',{id: notification.videoData.booking_id, video_id: notification.videoData.video_id});
                                            },1);  
                                        }else{
                                            socket.emit('notify', {
                                                user: notification.videoData.sender_id,
                                                notificationType:'DENY_VIDEO_CALL',
                                                sentBy: response.data.user.id
                                            },function(){alert("here")}); 
                                        }
                                    });
                                }else{
                                    logger.log(notification.videoData.sender_first_name+ ' '+notification.videoData.sender_last_name+ 'has joined call');
                                }
                                break;
                                case 'DENY_VIDEO_CALL': 
                                    logger.log("Call is denied by interpreter");
                                    $timeout(function(){ 
                                       $location.path('/client/dashboard');
                                    },1);
                                break;
                            }
                           
                        });
                        $rootScope.conversations=[];
                        socket.on('message_client',function(messageData){
                            $rootScope.conversations.push(messageData);
                            $timeout(function(){ 
                               angular.element(document.querySelector('#video-session-chat')).scrollTop(document.querySelector('#video-session-chat').scrollHeight);
                            },100);
                        });
                        $location.path('/client/dashboard');
                    }else{
                        logger.logError('Invalid email and password');
                    }
                });
            }

        }

        /**
        * Function is used to view subscription modal 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.viewCardDetailModel = function(subscription) {
            $localStorage.subscription_id = subscription._id;
            $localStorage.plan_name = subscription.plan_name;
            $localStorage.amount = subscription.amount;
            $uibModal.open({
                templateUrl: 'agency/modules/authentication/views/subscriptionModal.html',
                size: "md",
                controller: function($scope,$rootScope, $uibModalInstance) {
                    
                    
                    var stripe = Stripe(stripe_published_key);
                    var elements = stripe.elements();

                    setTimeout(function(){
                        stripeCard();                  
                    },200)

                    $scope.closeuib = function() {
                        $uibModalInstance.close();
                    }

                    $scope.getData = function(){
                            $scope.plan_name = $localStorage.plan_name;
                            $scope.amount = $localStorage.amount;
                        }

                    function stripeCard() {
                        var style = {
                            base: {
                                color: '#333',
                                lineHeight: '24px',
                                fontSmoothing: 'antialiased',
                                fontSize: '14px',
                                '::placeholder': {
                                    color: '#999'
                                }
                            },
                            invalid: {
                                color: '#a94442',
                                iconColor: '#a94442'
                            }
                        };

                        $scope.card = elements.create('card', { hidePostalCode: true, style: style });
                        $scope.card.mount('#card-element');

                        $scope.card.addEventListener('change', function(event) {
                            var displayError = document.getElementById('card-errors');
                            if (event.error) {
                                displayError.textContent = event.error.message;
                            } else {
                                displayError.textContent = '';
                            }
                        });

                        $scope.agencyRegistration = function() {
                            $scope.closeuib();
                            blockUI.start('Payment is in Process. Please wait...');
                            stripe.createToken($scope.card).then(function(result) {
                                if (result.error) {
                                    // Inform the user if there was an error
                                    var errorElement = document.getElementById('card-errors');
                                    errorElement.textContent = result.error.message;
                                } else {
                                    // Send the token to your server
                                    var agency =  $localStorage.agencyData;
                                    agency.subscription_id = $localStorage.subscription_id;
                                    agency.card_holder_name = $scope.card_holder_name;
                                    agency.token = result.token.id;
                                    if($localStorage.agencyData.activation_key){
                                        AuthenticationService.activateAgencyWithSubscription().save(agency, function(response) {
                                            if (response.status == 1) {
                                                delete $localStorage.agencyData;
                                                delete $localStorage.subscription_id;
                                                delete $localStorage.plan_name;
                                                delete $localStorage.amount;
                                                blockUI.stop();
                                                $location.path('/login');
                                                logger.logSuccess(response.message); 
                                            } else {
                                                delete $localStorage.agencyData;
                                                delete $localStorage.subscription_id;
                                                delete $localStorage.plan_name;
                                                delete $localStorage.amount;
                                                blockUI.stop();
                                                $location.path('/signup');
                                                logger.logError(response.message);
                                            }
                                        })  
                                    } else {
                                        AuthenticationService.agencyRegister().save(agency, function(response) {
                                            if (response.status == 1) {
                                                delete $localStorage.agencyData;
                                                delete $localStorage.subscription_id;
                                                delete $localStorage.plan_name;
                                                delete $localStorage.amount;
                                                blockUI.stop();
                                                $location.path('/login');
                                                logger.logSuccess(response.message); 
                                            } else {
                                                delete $localStorage.agencyData;
                                                delete $localStorage.subscription_id;
                                                delete $localStorage.plan_name;
                                                delete $localStorage.amount;
                                                blockUI.stop();
                                                $location.path('/signup');
                                                logger.logError(response.message);
                                            }
                                        })    
                                    }
                                }
                                $scope.$emit('stop', true);
                            });
                        }
                    }

                }
            });
        };
        
        /**
         * Function is use to logout 
         * @access private
         * @return json
         * Created by sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.logout = function() {
            delete $localStorage.userLoggedIn;
            delete $localStorage.user;
            delete $localStorage.token;        
            $rootScope.userLoggedIn = false;
            $location.path('/login');   
        }

        /**
         * Function is use user Forgot Password
         * @access private
         * @return json
         * Created by sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.userForgotPassword = function(loginform){
            $scope.forgot_password = loginform;
            console.log($scope.forgot_password);
            AuthenticationService.userForgotPassword().save($scope.forgot_password, function(response) {
                if (response.status == 1) {
                    logger.logSuccess(response.message);
                    $state.go('login');
                } else {
                    logger.logError(response.message);
                }
            });
        }

        /**
         * Function is used to set new password
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.setNewPassword = function(loginform){
            var set_new_password = loginform;
            if(set_new_password.password === set_new_password.confirm_password){
                    var obj = {
                        password: set_new_password.password,
                        forgot_token: $stateParams.forgot_token
                    }
                    AuthenticationService.setNewPassword().save(obj, function(response) {
                    if (response.status == 1) {
                        logger.logSuccess(response.message);
                        $state.go('login');
                    } else {
                        logger.logError(response.message);
                    }
                });
            } else{ 
                logger.log("Confirm password does not match with password!");
            }
            
        }

        /**
        * Function is used to get email using activation_key for complete registration
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.getEmailUsingKey = function(){
            if($stateParams.activation_key){
                AuthenticationService.getEmailUsingKey().get({id:$stateParams.activation_key},function(response, err){
                    if(response.status == 1){
                        $scope.user = response.data;
                        $scope.status = response.status; 
                    }else{
                        $scope.user = {};
                        $scope.status = response.status; 
                        
                    }
                })
            }
        };

        /**
        * Function is used to get email using password
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.getEmailUsingPassword = function(){
            if($stateParams.forgot_token){
                AuthenticationService.getEmailUsingPassword().get({id:$stateParams.forgot_token},function(response, err){
                    if(response.status == 1){
                        $scope.user = response.data;
                        $scope.status = response.status; 
                    }else{
                        $scope.user = {};
                        $scope.status = response.status; 
                        
                    }
                })
            }
        };
        
        /**
        * Function is used to complete user registration
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.completeUserRegistration = function(form){
            if (form.$valid) {
                $scope.disabled = true;
                var user = $scope.user;
                user.activation_key = $stateParams.activation_key;
                if($scope.user.password == $scope.user.confirm_password){    
                    AuthenticationService.completeUserRegistration().save(user, function(response) {
                        $scope.disabled = false;
                        if(response.status == 1){
                            logger.logSuccess(response.message);
                            $state.go('login');
                        }else{
                            logger.logError(response.message);
                        }
                    })
                }else{
                    logger.log("Confirm password does not match with password!");
                }
            }
        };

        /**
        * Function is used to get all subscription data
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.getAllSubscriptionData = function() {
            AuthenticationService.getAllSubscriptionData().get(function(response, err) {
                if (response.status == 1) {
                    $scope.subscriptions = response.data;
                } else {
                    logger.logError(response.message);
                }
            });
        };

        /**
        * Function is used to check agency email
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.agencyRegisterEmailCheck = function(register){
            var agRegister = register;
            var obj = {
                email: agRegister.email
            }
            AuthenticationService.agencyRegisterEmailCheck().save(obj, function(response) {
                if(response.status == 4){
                    if(agRegister.password == agRegister.confirm_password){    
                        $localStorage.agencyData = agRegister;
                        $location.path('/subscription');
                    }else{
                        logger.log("Confirm password does not match with password!");
                    }
                }else{
                    logger.log(response.message);
                }
            })
            
        };

        $scope.backToAgencyRegistration = function(){
            delete $localStorage.agencyData;
            $location.path('/signup');
        }

        /**
        * Function is used to get booking detail using request token
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 25-Jan-2017
        **/
        $scope.getBookingDetails = function(){
            if($stateParams.request_token){
                AuthenticationService.getBookingDetails().get({id:$stateParams.request_token},function(response, err){
                    if(response.status == 1){
                        $scope.request = response.data;
                        $scope.status = response.status; 
                    }else{
                        $scope.request = {};
                        $scope.status = response.status; 
                    }
                })
            }
        };

        /**
         * Function is used to set new password
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 19-Aug-2017
         */
        $scope.saveBookingRequest = function(form){
            if(form.$valid){
                var request = $scope.request;
                var requestObj = {
                    booking_request_id: request.booking_request_id,
                    request_token: $stateParams.request_token
                }
                AuthenticationService.saveBookingRequest().save(requestObj, function(response) {
                    if (response.status == 1) {
                        logger.logSuccess(response.message);
                        $state.go('login');
                    } else {
                        logger.logError(response.message);
                    }
                });
            }  
        };

        /**
         * Function is used to save accept event request by interpreter
         * @access private
         * @return json
         * Created by Sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 30-Mar-2018
         */
        $scope.saveEventRequest = function(form){
            if(form.$valid){
                var request = $scope.request;
                var requestObj = {
                    booking_request_id: request.booking_request_id,
                    request_token: $stateParams.request_token
                }
                AuthenticationService.acceptEventRequest().save(requestObj, function(response) {
                    if (response.status == 1) {
                        logger.logSuccess(response.message);
                        $state.go('login');
                    } else {
                        logger.logError(response.message);
                    }
                });
            }  
        };

        /**
         * Function is used to subscribe email
         * @access private
         * @return json
         * Created by sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 12-Feb-2018
         */
        $scope.subscribe = function(subscribeForm){
            if(subscribeForm.$valid){
                $scope.loader = true;
                $scope.disabled = true;
                AuthenticationService.subscribe().save($scope.subscribeEmail, function(response) {
                    var errorMessage = '';
                    $scope.disabled = false;
                    $scope.loader = false;
                    if (response.status == 1) {
                        logger.logSuccess(response.message);
                        $scope.subscribeEmail = "";
                        $state.reload();
                    } else {
                        logger.logError(response.message);
                        $scope.subscribeEmail = "";
                        $state.reload();
                    }
                });
            }
        };

        /**
         * Function is used to get Carousel details
         * @access private
         * @return json
         * Created by sunny
         * @smartData Enterprises (I) Ltd
         * Created Date 23-Feb-2018
         */
        $scope.getCarouselDetails = function(){
            AuthenticationService.getCarouselDetails().get(function(response, err){
                if(response.status == 1){
                    $scope.carouselArray = response.data;
                }else{
                    $scope.carouselArray = {};
                }
            })
        }

        /**
        * Function is used to route to selection of subscription plan
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 3-March-2018
        **/
        $scope.selectSubscriptionsByAgemcy = function(form){
            if (form.$valid) {
                $scope.disabled = true;
                var user = $scope.user;
                user.activation_key = $stateParams.activation_key;
                var agRegister = user;        
                if($scope.user.password == $scope.user.confirm_password){    
                    $localStorage.agencyData = agRegister;
                    $location.path('/subscription');
                }else{
                    logger.log("Confirm password does not match with password!");
                }
            }
            
        };


    }
]);
