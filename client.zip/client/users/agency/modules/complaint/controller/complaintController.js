"use strict";

angular.module("AgencyComplaint")

interpreterApp.controller("complaintController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger', 'ClientComplaintService','ComplaintService', 'ngTableParams', 'ngTableParamsService','geolocation','BookingService','CommonService',
    function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal, logger, ClientComplaintService,ComplaintService, ngTableParams, ngTableParamsService,geolocation,BookingService,CommonService) {
       
        /* Variables is used for update and non update condition */
        if ($state.params.id) {
            $scope.isUpdate = true;
        } else {
            $scope.isUpdate = false;
        };
        $scope.selectClient = {};
        /* End */

        /* Variables is used for bootstrap datepicker */ 
        $scope.dateModel = {};
        $scope.today = function() {
            $scope.dt = new Date();
        };
        $scope.dateformat = "dd/MM/yyyy";
        $scope.today();
        $scope.showcalendar = function($event) {
            $scope.dateModel.showdp = true;
        };
        $scope.showcalendar1 = function($event) {
            $scope.dateModel.showdp1 = true;
        };
        $scope.dateModel.showdp = false;
        $scope.dateModel.showdp1 = false;
        $scope.dtmax = new Date();
        /* End */ 
        
        /* Variable is used to active class on leftbar */
        $rootScope.menuComplaint= ['agency_listComplaint','agency_addComplaint','agency_editComplaint','agency_viewComplaint'];

        /**
        * Function is used to list complaint for agency
        * @access private
        * @return json
        * Created by Ramiz
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Dec-2017
        * Modified Date 6-Apr-2018
        **/
        $scope.listComplaintOfAgency = function() {
            ngTableParamsService.set('', '', '', '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    if($scope.selectClient.client_id != '' && $scope.selectClient.client_id != null && $scope.selectClient.client_id != undefined){
                        $scope.paramUrl.client_id = $scope.selectClient.client_id;
                    }
                    $scope.complaintList = [];
                    ComplaintService.listComplaintOfAgency().save($scope.paramUrl, function(response, err) {
                        if (response.status == 1) {
                            $scope.tableLoader = false;
                            $scope.complaintList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    })
                }
            })
        };
        /* End */

        /**
        * Function is used to get completed bookings for dropdown
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Apr-2018
        **/
        $scope.getCompletedBookingsByAgency = function(){
            ComplaintService.getCompletedBookingsByAgency().get(function(response){
                if(response.status == 1){
                    $scope.bookingDetails = response.data;
                } else{ 
                    logger.logError(response.message);
                }
            })
        }
        /* End */

        /**
        * Function is used to get completed bookings for update it includes lodge complaints bookings
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Apr-2018
        **/
        $scope.getCompletedBookingsForUpdate = function(){
            ComplaintService.getCompletedBookingsForUpdate().get(function(response){
                if(response.status == 1){
                    $scope.bookingDetails = response.data;
                } else{ 
                    logger.logError(response.message);
                }
            })
        }
        /* End */

        /**
        * Function is used to get selected booking details
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Apr-2018
        **/
        $scope.getSelectedBookingDetail = function(id){
            if(id == undefined || id == null || id == ''){
                $scope.booking = {};
                $scope.complaint = {};
            }else{
                ComplaintService.getSelectedBookingDetail().get({id:id},function(response, err){
                    if(response.status == 1){
                        var booking = response.data; 
                        booking.InterpreterName = booking.interpreter_id.first_name.charAt(0).toUpperCase()+booking.interpreter_id.first_name.slice(1).toLowerCase()+ ' '+booking.interpreter_id.last_name.charAt(0).toUpperCase()+booking.interpreter_id.last_name.slice(1).toLowerCase(); 
                        booking.ClientName = booking.client_id.first_name.charAt(0).toUpperCase()+booking.client_id.first_name.slice(1).toLowerCase()+ ' '+booking.client_id.last_name.charAt(0).toUpperCase()+booking.client_id.last_name.slice(1).toLowerCase(); 
                        $scope.booking = booking;
                    } else{
                        $scope.booking = {}
                        logger.logError(response.message);
                    }
                })
            }
        }
        /* End */

        /**
        * Function is used to lodge complaint
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 6-Apr-2018
        **/
        $scope.lodgeComplaintByAgency = function(){
            console.log("check_in_out_id", $scope.complaint);
            var data = {
                booking_id: $scope.booking.booking_id._id,
                client_id: $scope.booking.client_id._id,
                interpreter_id: $scope.booking.interpreter_id._id,
                agency_id: $scope.booking.agency_id._id,
                service_title: $scope.booking.booking_id.service_title,
                booking_description: $scope.booking.booking_id.booking_description,
                complaint_comments: $scope.complaint.complaint_comments,
                check_in_out_id: $scope.complaint.check_in_out_id
            }
            ComplaintService.lodgeComplaintByAgency().save(data, function(response){
                if(response.status == 1){
                  logger.logSuccess(response.message); 
                  $state.go("agency_listComplaint");
                } else{
                  logger.logError(response.message);
                }
            })
        }
        /* End */


        /**
        * Function is used to get complaint by id
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-oct-2017
        * Modified Date 6-Apr-2018
        **/
        $scope.getComplaintById = function(){
            if($stateParams.id){
                ComplaintService.getComplaintById().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var complaint = response.data;
                        var booking = {};
                        booking.InterpreterName = complaint.interpreter_id.first_name.charAt(0).toUpperCase()+complaint.interpreter_id.first_name.slice(1).toLowerCase()+ ' '+complaint.interpreter_id.last_name.charAt(0).toUpperCase()+complaint.interpreter_id.last_name.slice(1).toLowerCase(); 
                        booking.ClientName = complaint.client_id.first_name.charAt(0).toUpperCase()+complaint.client_id.first_name.slice(1).toLowerCase()+ ' '+complaint.client_id.last_name.charAt(0).toUpperCase()+complaint.client_id.last_name.slice(1).toLowerCase(); 
                        booking.booking_id = {
                            booking_short_id : complaint.booking_id.booking_short_id,
                            booking_description: complaint.booking_description
                        };
                        $scope.booking = booking;
                        $scope.complaint = complaint;
                    }else{
                        $scope.booking = {};
                        $scope.complaint = {};
                        logger.logError(response.message);
                        $state.go('client_listComplaint');
                    }
                })
            }
        };
        /* End */

        /**
        * Function is used to update complaint
        * @access private
        * @return json
        * Created by Ramiz
        * Modified by Sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Dec-2017
        **/
        $scope.updateComplaint = function() {
            var data = {
                _id: $scope.complaint._id,
                complaint_comments: $scope.complaint.complaint_comments
            }
            ComplaintService.updateComplaint().save(data, function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $state.go('agency_listComplaint');
                } else {
                    logger.logError(response.message);
                }
            });
        };
        /* End */

        /**
        * Function is used to delete complaint
        * @access private
        * @return json
        * Created by Ramiz
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Dec-2017
        **/
        $scope.deleteComplaint = function(id, $event) {
            $event.stopPropagation();
            bootbox.confirm('Are you sure, you want to delete this complaint?', function(r) {
                if (r) {
                    ComplaintService.deleteComplaint().delete({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listComplaintOfAgency();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        }
        /* End */

        /* Function is used to view complaint */
        $scope.viewComplaint = function(complaint) {
            $state.go('agency_viewComplaint', {id:complaint._id});
        };
        /* End */


        /**
        * Function is used to list complaint of an agency on searching
        * @access private
        * @return json
        * Created by Ramiz
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Dec-2017
        **/
        $scope.listComplaintSearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    if($scope.selectClient.client_id != '' && $scope.selectClient.client_id != null && $scope.selectClient.client_id != undefined){
                        $scope.paramUrl.client_id = $scope.selectClient.client_id;
                    }
                    $scope.complaintList = [];
                    ComplaintService.listComplaintOfAgency().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.complaintList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };
        /* End */

        /**
        * Function is used to search complaints of an agency between dates
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Dec-2017
        * Modified Date 6-Apr-2018
        **/
        $scope.searchComplaintByDate = function() {
            var date = {};
            date.searchFrom = $scope.complaintFrom;
            date.searchTo = $scope.complaintTo;
            ngTableParamsService.set('', '', '', '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.complaintList = [];
                    if($scope.selectClient.client_id != '' && $scope.selectClient.client_id != null && $scope.selectClient.client_id != undefined){
                        $scope.paramUrl.client_id = $scope.selectClient.client_id;
                    }
                    $scope.paramUrl.searchFrom = $scope.complaintFrom;
                    $scope.paramUrl.searchTo = $scope.complaintTo;
                    ComplaintService.searchComplaintByDate().save($scope.paramUrl, function(response, err) {
                        if (response.status == 1) {
                            $scope.tableLoader = false;
                            $scope.complaintList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };
        /* End */

        /* Function is used to clear the value of bootstrap datepickers */
        $scope.clearSearch = function(){
            $scope.complaintFrom = "";
            $scope.complaintTo = "";
            $state.reload();
        }
        /* End */

        /**
        * Function is used to get clients by Agency
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 5-March-2018
        **/
        $scope.getClientListByAgency = function(){
            ComplaintService.getClientListByAgency().get({},function(response, err){
                if(response.status == 1){
                    $scope.clientList = response.data;
                }else{
                    $scope.clientList = {};
                }
            })
        }
        /* End */

        /**
        * Function is used to change complaint status to processing
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Dec-2017
        **/
        $scope.makeComplaintInProcess = function(id, $event) {
            $event.stopPropagation();
            bootbox.confirm('Are you sure, you want to change complaint status to processing?', function(r) {
                if (r) {
                    ComplaintService.makeComplaintInProcess().save({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listComplaintOfAgency();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        }
        /* End */

        /**
        * Function is used to change complaint status to completed
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Dec-2017
        **/
        $scope.makeComplaintStatusCompleted = function(id, $event) {
            $event.stopPropagation();
            bootbox.confirm('Are you sure, you want to change complaint status to completed?', function(r) {
                if (r) {
                    ComplaintService.makeComplaintStatusCompleted().save({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listComplaintOfAgency();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        }
        /* End */

        /**
        * Function is used to change complaint status to approved
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 8-Dec-2017
        **/
        $scope.approveComplaint = function(id, $event) {
            $event.stopPropagation();
            bootbox.confirm('Are you sure, you want to approve this complaint?', function(r) {
                if (r) {
                    ComplaintService.approveComplaint().save({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listComplaintOfAgency();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        }
        /* End */
                
    }
]);


