"use strict"

angular.module("AgencyComplaint")

.factory('ComplaintService', ['$http', '$resource', function($http, $resource) {

    var listComplaintOfAgency = function() {
        return $resource(webservices.listComplaintOfAgency, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getCompletedBookingsByAgency = function() {
        return $resource(webservices.getCompletedBookingsByAgency, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getSelectedBookingDetail = function(id) {
        return $resource(webservices.getSelectedBookingDetail, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var lodgeComplaintByAgency = function() {
        return $resource(webservices.lodgeComplaintByAgency, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getComplaintById = function(id) {
        return $resource(webservices.getComplaintById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getCompletedBookingsForUpdate = function() {
        return $resource(webservices.getCompletedBookingsForUpdate, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var updateComplaint = function() {
        return $resource(webservices.updateComplaint, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteComplaint = function(id) {
        return $resource(webservices.deleteComplaint, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var searchComplaintByDate = function() {
        return $resource(webservices.searchComplaintByDate, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getClientListByAgency = function() {
        return $resource(webservices.getClientListByAgency, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var makeComplaintInProcess = function() {
        return $resource(webservices.makeComplaintInProcess, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var makeComplaintStatusCompleted = function() {
        return $resource(webservices.makeComplaintStatusCompleted, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var approveComplaint = function() {
        return $resource(webservices.approveComplaint, null, {
            save: {
                method: 'POST'
            }
        });
    }

    return {
        listComplaintOfAgency: listComplaintOfAgency,
        getCompletedBookingsByAgency: getCompletedBookingsByAgency,
        getSelectedBookingDetail: getSelectedBookingDetail,
        lodgeComplaintByAgency: lodgeComplaintByAgency,
        getComplaintById: getComplaintById,
        getCompletedBookingsForUpdate: getCompletedBookingsForUpdate,
        updateComplaint: updateComplaint,
        deleteComplaint: deleteComplaint,
        searchComplaintByDate: searchComplaintByDate,
        getClientListByAgency: getClientListByAgency,
        makeComplaintInProcess: makeComplaintInProcess,
        makeComplaintStatusCompleted: makeComplaintStatusCompleted,
        approveComplaint: approveComplaint

    }

}]);
