$scope.checkedProvider = function(provider, index) {
                if (provider.status == '1' && provider.selected == true && provider.type == 'notAvailable') {
                    if ($scope.selectedProvider.length > $scope.order.serviceProviderNo) {
                        // $scope.selectedProvider.splice($scope.selectedProvider.indexOf(provider.providerId), 1)
                        $scope.scheduleOrderDetail.assignProviders[index].selected = false;
                        logger.logError("You are not allow to align service provider more then requested provider number")
                    } else {
                        bootbox.confirm('Are you sure you want to align this provider, as they have already aligned on another request?', function(r) {
                            if (r) {
                                $scope.selectedProvider.indexOf(provider.providerId) == -1 ? $scope.selectedProvider.push(provider.providerId) : $scope.selectedProvider.splice($scope.selectedProvider.indexOf(provider.providerId), 1)
                                if ($scope.selectedProvider.length > $scope.order.serviceProviderNo) {
                                    $scope.selectedProvider.splice($scope.selectedProvider.indexOf(provider.providerId), 1)
                                    $scope.scheduleOrderDetail.assignProviders[index].selected = false;
                                    logger.logError('You are not allow to align service provider more then requested provider number')
                                }
                                $scope.$apply();
                            } else {
                                document.getElementById("checkBoxSel" + index).checked = false;
                                $scope.scheduleOrderDetail.assignProviders[index].selected = false;
                                $scope.$apply();
                            }
                        })
                    }
                } else if (provider.status == '0' && provider.selected == true) {
                    $scope.selectedProvider.indexOf(provider.providerId) == -1 ? $scope.selectedProvider.push(provider.providerId) : $scope.selectedProvider.splice($scope.selectedProvider.indexOf(provider.providerId), 1)

                    if ($scope.selectedProvider.length > $scope.order.serviceProviderNo) {
                        $scope.selectedProvider.splice($scope.selectedProvider.indexOf(provider.providerId), 1)
                        $scope.scheduleOrderDetail.assignProviders[index].selected = false;
                        logger.logError('You are not allow to align service provider more then requested provider number')
                    }
                } else if (provider.status == '1' && provider.selected == false) {

                    $scope.selectedProvider.splice($scope.selectedProvider.indexOf(provider.providerId), 1)

                } else {
                    $scope.selectedProvider.indexOf(provider.providerId) == -1 ? $scope.selectedProvider.push(provider.providerId) : $scope.selectedProvider.splice($scope.selectedProvider.indexOf(provider.providerId), 1)
                    if ($scope.selectedProvider.length >= $scope.order.serviceProviderNo) {
                        $scope.selectedProvider.splice($scope.selectedProvider.indexOf(provider.providerId), 1)
                        $scope.scheduleOrderDetail.assignProviders[index].selected = false;
                        logger.logError('You are not allow to align service provider more then requested provider number')
                    }
                }
            };