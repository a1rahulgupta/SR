"use strict";

angular.module("Booking")

interpreterApp.controller("bookingController", ['$scope', '$rootScope', '$localStorage',
    'ngTableParams', '$routeParams', '$route', '$location', '$state',
    '$stateParams', 'logger', 'ngTableParamsService', 'CommonService', 'BookingService', '$uibModal','$timeout',
    function($scope, $rootScope, $localStorage, ngTableParams, $routeParams,
        $route, $location, $state, $stateParams, logger, ngTableParamsService,
        CommonService, BookingService, $uibModal,$timeout) {


            if ($state.params.id) {
                $scope.isUpdate = true;
            } else {
                $scope.isUpdate = false;
            }
            $scope.selectClient = {};
            $scope.gPlace; 

            $scope.fromDateChanged = function() {
                var minutesAdded = 30;
                $scope.working_to_full = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                $scope.minTime = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                setTimeout(function(){
                    angular.element(document.querySelector('#working_from_id')).trigger('change');
                    angular.element(document.querySelector('#working_to_id')).trigger('change');
                },1000);

            } 

            /**
            * Variable is used for active class on leftbar
            * @access private
            * @return json
            * Created by sunny
            * @smartData Enterprises (I) Ltd
            * Created Date 27-Sep-2017
            **/
            $rootScope.menuBooking = ['agency_listBooking', 'agency_addBooking', 'agency_viewBooking', 'agency_editBooking','agency_calenderBooking', 'agency_assignInterpreter'];
            
            $scope.timeSettings = {};
            $scope.eventSources = [
                function(start, end, timezone, callback) {
                    var client_id;
                    if($scope.selectClient.client_id != '' && $scope.selectClient.client_id != null && $scope.selectClient.client_id != undefined){
                        client_id = $scope.selectClient.client_id;
                    }else{
                        client_id = '';
                    }
                    console.log("client_id",client_id);
                    BookingService.getBookingList().get({client_id}, function(response) {
                        var events = []; 
                        if (response.status == 1) {
                            $scope.scheduleBookingList = response.data;
                                                             
                            $scope.scheduleBookingList.forEach(function(value, index) {
                                $scope.colorName = $scope.getRandomColor();
                             
                                events.push({
                                    start: new Date(moment(value.booking_from)), //$filter('dateFilter')(hol.HOLIDAY_START),
                                    end: new Date(moment(value.booking_to)), //$filter('dateFilter')(hol.HOLIDAY_END),
                                    title: value.service_title, //hol.HOLIDAY_TITLE,
                                    color: $scope.colorName,//'#c23333', //$filter('colorEventFilter')(hol.HOLIDAY_EVENT_STATE_ID)
                                    bookingDetail: value
                                });
                            });

                            callback(events);
                            $scope.calendarLoader = false;
                        }

                    });
                    
                }
            ];
            $scope.orderAll = [];
            $scope.calendarLoader = true;
            $scope.getScheduleBookingList = function() {
                $scope.uiConfig = {
                calendar: {
                        // events: function(start, end, timezone, callback) {
                            // console.log("herre$$$");
                            // BookingService.getBookingList().get({}, function(response) {
                            //     var events = []; 
                            //     if (response.status == 1) {
                            //         $scope.scheduleBookingList = response.data;
                                                                     
                            //         $scope.scheduleBookingList.forEach(function(value, index) {
                            //             $scope.colorName = $scope.getRandomColor();
                            //             events.push({
                            //                 end: moment(value.booking_to).format(), //$filter('dateFilter')(hol.HOLIDAY_END),
                            //                 start: moment(value.booking_from).format(), //$filter('dateFilter')(hol.HOLIDAY_START),
                            //                 title: value.service_title, //hol.HOLIDAY_TITLE,
                            //                 color: $scope.colorName,//'#c23333', //$filter('colorEventFilter')(hol.HOLIDAY_EVENT_STATE_ID)
                            //                 bookingDetail: value
                            //             });
                            //         });
                            //         callback(events);
                            //         $scope.calendarLoader = false;
                            //     }

                            // });
                            
                        // },
                        displayEventTime: false,
                        editable: true,
                        eventLimit: true,   
                        timezone:'local',
                        views: {
                         month: {
                           eventLimit: 4
                         }
                        },
                height: 550,
                navLinks: true,
                timeFormat: 'hh:mm a',
                // editable: true,
                header:{
                  left: 'month basicWeek basicDay agendaWeek agendaDay',
                  center: 'title',
                  right: 'today prev,next'
                },
                eventClick: function(calEvent, jsEvent, view) {

                  $scope.viewBookingModel(calEvent.bookingDetail._id)
                },
                eventDrop: $scope.alertOnDrop,
                eventResize: $scope.alertOnResize,
                dayClick: function(date, allDay, jsEvent, view) {
                    $rootScope.booking = {};
                    if($scope.selectClient.client_id !=null && $scope.selectClient.client_id !=undefined && $scope.selectClient.client_id !=''){
                        $rootScope.booking.client_id = $scope.selectClient.client_id;
                    }else{
                        $rootScope.booking.client_id = '';
                    }
                    var currentDate = new Date();
                    var clickedDate = new Date(date.toString());
                    currentDate.setHours(0);
                    clickedDate.setHours(0);
                    var timeDiff = clickedDate.getTime() - currentDate.getTime();
                    var diffDays = Math.round(timeDiff / (1000 * 3600 * 24));
                    if(diffDays>=0){
                        $uibModal.open({
                            templateUrl: 'agency/modules/booking/views/eventModal.html',
                            size: "lg",
                            // windowClass: 'app-per-modal-window',
                            controller: function($scope,$rootScope, $uibModalInstance) {
                                $scope.booking = {};
                                $scope.selectClient = {};
                                $scope.exist = false;
                                 
                                /* Functions is used to initialize the working hours on document ready */
                                $scope.initializeWorkingHours = function(){

                                    var currentDate = new Date();
                                    $scope.booking = {};
                                    $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
                                    $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                                    $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
                                    $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                                    // Initialize client id 
                                    $scope.booking.client_id = $rootScope.booking.client_id;
                                    if($scope.booking.client_id !=''){
                                        $scope.exist = true;
                                    }
                                    //End
                                    
                                    setTimeout(function(){
                                        angular.element(document.querySelector('#working_from_id')).trigger('change');
                                        angular.element(document.querySelector('#working_to_id')).trigger('change');
                                    },1000);
                                } 
                                /* End */

                                $scope.fromDateChanged = function() {
                                    var minutesAdded = 30;
                                    $scope.working_to_full = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                                    $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                                    $scope.minTime = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                                    setTimeout(function(){
                                        angular.element(document.querySelector('#working_from_id')).trigger('change');
                                        angular.element(document.querySelector('#working_to_id')).trigger('change');
                                    },1000);

                                }  

                                $scope.closeuib = function() {
                                    $uibModalInstance.close('a');
                                }

                                $scope.getAgencyInterpreters = function(){
                                    
                                    BookingService.getAgencyInterpreters().get({},function(response, err){
                                        if(response.status == 1){
                                            $scope.agencyInterpreters = response.data;
                                        }else{
                                            $scope.agencyInterpreters = {};
                                        }
                                    })
                                }  

                                $scope.getAgencyClients = function(){
                                    $scope.booking.booking_from= new Date(date.toString());
                                    BookingService.getAgencyClients().get({},function(response, err){
                                        if(response.status == 1){
                                            $scope.agencyClients = response.data;
                                        }else{
                                            $scope.agencyClients = {};
                                        }
                                    })
                                } 

                                $scope.dateModel = {};
                                $scope.today = function() {
                                    $scope.dt = new Date();
                                };
                                $scope.dateformat = "MM/dd/yyyy";
                                $scope.today();
                                $scope.showcalendar = function($event) {
                                    $scope.dateModel.showdp = true;
                                };
                                $scope.showcalendar1 = function($event) {
                                    $scope.dateModel.showdp1 = true;
                                };
                                $scope.dateModel.showdp = false;
                                $scope.dateModel.showdp1 = false;
                                $scope.dtmax = new Date(); 

                                $scope.addBooking = function(form) {
                                    if (form.$valid) {
                                        $scope.loader = true;
                                        $scope.disabled = true;
                                        
                                        $scope.booking.lat = $scope.lat;
                                        $scope.booking.lng = $scope.lng;
                                        BookingService.addBooking().save($scope.booking, function(response, err) {
                                            var errorMessage = '';
                                            $scope.disabled = false;
                                            $scope.loader = false;
                                            if (response.status == 1) {
                                                logger.logSuccess(response.message); 
                                                $scope.closeuib();
                                                $scope.getBookingOnClientSelection();
                                            } else {
                                                logger.logError(response.message);
                                            }
                                        });
                                    }else{
                                        logger.logError("You have missed the required fields to fill the form.");
                                    }
                                };

                                /**
                                * Function is used to refetched full calendar events by Agency
                                * @access private
                                * @return json
                                * Created by sunny
                                * @smartData Enterprises (I) Ltd
                                * Created Date 5-March-2018
                                **/
                                $scope.getBookingOnClientSelection = function(){
                                    $('#providerDiv').fullCalendar('refetchEvents');
                                }


                                var infowindow,marker,infowindowContent,autocomplete,map;
                                $scope.initMap = function () {

                                    map = new google.maps.Map(document.getElementById('map'), {
                                      center: {lat: 41.310726, lng: -72.929916},
                                      zoom: 15,
                                    });

                                    var input = document.getElementById('pac-input');
                                    autocomplete = new google.maps.places.Autocomplete(input);
                                    autocomplete.bindTo('bounds', map);
                                    infowindow = new google.maps.InfoWindow();
                                    infowindowContent = document.getElementById('infowindow-content');
                                    infowindow.setContent(infowindowContent);
                                    marker = new google.maps.Marker({
                                      map: map
                                    });

                                    setTimeout(function() {
                                       google.maps.event.trigger(map, 'resize');
                                    }, 1000);
                                    autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
                                    function selectFirstAddress (input) {
                                        google.maps.event.trigger(input, 'keydown', {keyCode:40});
                                        // google.maps.event.trigger(input, 'keydown', {keyCode:13});
                                    }
                                    angular.element(document).on('focusout', '#pac-input', function() {
                                        selectFirstAddress(this);
                                    });
                                    
                                  }

                                  $scope.fetchAutocomplete = function(){
                                      infowindow.close();
                                      marker.setVisible(false);
                                      var place = autocomplete.getPlace();
                                      if (!place.geometry) {
                                        // User entered the name of a Place that was not suggested and
                                        // pressed the Enter key, or the Place Details request failed.
                                        window.alert("No details available for input: '" + place.name + "'");
                                        return;
                                      }
                                      var lat = place.geometry.location.lat();
                                      var lng = place.geometry.location.lng();
                                      var address = place.formatted_address;
                                      $scope.lat = lat;
                                      $scope.lng = lng;
                                      // If the place has a geometry, then present it on a map.
                                      if (place.geometry.viewport) {
                                        map.fitBounds(place.geometry.viewport);
                                      } else {
                                        map.setCenter(place.geometry.location);
                                        map.setZoom(15);  // Why 17? Because it looks good.
                                      }
                                      marker.setPosition(place.geometry.location);
                                      marker.setVisible(true);

                                      infowindowContent.children['place-icon'].src = place.icon;
                                      infowindowContent.children['place-name'].textContent = place.name;
                                      infowindowContent.children['place-address'].textContent = address;
                                      var address_long_name =  place.address_components[0].long_name; 
                                      if(address_long_name == place.name){
                                        $scope.booking.address = address;     
                                      }else{
                                        $scope.booking.address = place.name  + ','+ address;
                                      }
                                      $scope.$apply();
                                      infowindow.open(map, marker);
                                  }
                                
                                  $scope.getAllLanguagesInBookingModal = function(){
                                    BookingService.getAllLanguagesInBooking().get({},function(response, err){
                                        if(response.status == 1){
                                            $scope.agencyLanguages = response.data;
                                        }else{
                                            $scope.agencyLanguages = {};
                                        }
                                    })
                                }

                                $scope.getInterpreterNamesByLanguageIdModal = function(languageId){
                                    BookingService.getInterpreterNamesByLanguageId().get({id:languageId},function(response, err){
                                        if(response.status == 1){
                                            $scope.intepreterName = response.data;
                                        }else{
                                            $scope.intepreterName = {};
                                        }
                                    })
                                }
                            }
                        });
                    }

                }
            }
        }
            }


            $scope.viewBookingModel = function(data) {
                $rootScope.booking = {};
                $rootScope.selectClient = {};
                
                if($scope.selectClient.client_id !=null && $scope.selectClient.client_id !=undefined && $scope.selectClient.client_id !=''){
                    $rootScope.booking.client_id = $scope.selectClient.client_id;
                }else{
                    $rootScope.booking.client_id = '';
                }
                $uibModal.open({
                        templateUrl: 'agency/modules/booking/views/viewEventModal.html',
                        size: "lg",
                        // windowClass: 'app-per-modal-window',
                        controller: function($scope,$rootScope, $uibModalInstance) {
                            $scope.timeSettings = {};
                            $scope.exist = false;

                            $scope.closeuib = function() {
                                $uibModalInstance.close('a');
                            }

                            /** Variables is used to initialize the working hours on document ready */
                            var currentDate = new Date();
                            $scope.booking = {};
                            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
                            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
                            $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                            
                            // Initialize client id 
                            $scope.booking.client_id = $rootScope.booking.client_id;
                            if($scope.booking.client_id !=''){
                                $scope.exist = true;
                            }
                            //End
                            
                            setTimeout(function(){
                                angular.element(document.querySelector('#working_from_id')).trigger('change');
                                angular.element(document.querySelector('#working_to_id')).trigger('change');
                            },1000);
                            /* End */

                            $scope.fromDateChanged = function() {
                                var minutesAdded = 30;
                                $scope.working_to_full = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                                $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                                $scope.minTime = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                                setTimeout(function(){
                                    angular.element(document.querySelector('#working_from_id')).trigger('change');
                                    angular.element(document.querySelector('#working_to_id')).trigger('change');
                                },1000);

                            }  

                            BookingService.getBookingById().get({id:data},function(response, err){
                                if(response.status == 1){
                                    var currentDate = new Date();   
                                    var booking = response.data;
                                    booking.booking_from = new Date(moment(booking.booking_from));
                                    booking.booking_to = new Date(moment(booking.booking_to));
                                    var tmpTime = CommonService.convertTo24Format(booking.working_from);
                                    $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                                    tmpTime = CommonService.convertTo24Format(booking.working_to);
                                    $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                                    $scope.booking = booking; 
                                    $scope.getInterpreterNamesByLanguageIdModal(booking.language_id);
                                    $scope.getPlace(booking.lat,booking.lng,booking.address);
                                }else{
                                    $scope.booking = {};
                                }
                            })

                            $scope.getAgencyInterpreters = function(){
                                BookingService.getAgencyInterpreters().get({},function(response, err){
                                    if(response.status == 1){
                                        $scope.agencyInterpreters = response.data;
                                    }else{
                                        $scope.agencyInterpreters = {};
                                    }
                                })
                            }  

                            $scope.getAgencyClients = function(){
                                BookingService.getAgencyClients().get({},function(response, err){
                                    if(response.status == 1){
                                        $scope.agencyClients = response.data;
                                    }else{
                                        $scope.agencyClients = {};
                                    }
                                })
                            } 

                            $scope.updateBooking = function(form) {
                                if (form.$valid) {
                                    $scope.booking.lat = $scope.lat;
                                    $scope.booking.lng = $scope.lng;
                                    BookingService.updateBooking().save($scope.booking, function(response, err) {
                                        if (response.status == 1) {
                                            logger.logSuccess(response.message); 
                                            $scope.closeuib();
                                            $scope.getBookingOnClientSelection();
                                        } else {
                                            logger.logError(response.message);

                                        }
                                    });
                                }else{
                                    logger.logError("You have missed the required fields to fill the form.");
                                }
                            }

                            /**
                            * Function is used to refetched full calendar events by Agency
                            * @access private
                            * @return json
                            * Created by sunny
                            * @smartData Enterprises (I) Ltd
                            * Created Date 5-March-2018
                            **/
                            $scope.getBookingOnClientSelection = function(){
                                $('#providerDiv').fullCalendar('refetchEvents');
                            }

                            $scope.dateModel = {};
                            $scope.today = function() {
                                $scope.dt = new Date();
                            };
                            $scope.dateformat = "MM/dd/yyyy";
                            $scope.today();
                            $scope.showcalendar = function($event) {
                                $scope.dateModel.showdp = true;
                            };
                            $scope.showcalendar1 = function($event) {
                                $scope.dateModel.showdp1 = true;
                            };
                            $scope.dateModel.showdp = false;
                            $scope.dateModel.showdp1 = false;
                            $scope.dtmax = new Date(); 

                            var infowindow,marker,infowindowContent,autocomplete,map;
                            $scope.initMap = function () {
                                map = new google.maps.Map(document.getElementById('map'), {
                                  center: {lat: 41.310726, lng: -72.929916},
                                  zoom: 15,
                                });

                                var input = document.getElementById('pac-input');
                                autocomplete = new google.maps.places.Autocomplete(input);
                                autocomplete.bindTo('bounds', map);
                                infowindow = new google.maps.InfoWindow();
                                infowindowContent = document.getElementById('infowindow-content');
                                infowindow.setContent(infowindowContent);
                                marker = new google.maps.Marker({
                                  map: map
                                });

                                setTimeout(function() {
                                   google.maps.event.trigger(map, 'resize');
                                }, 1000);

                                autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
                                function selectFirstAddress (input) {
                                    google.maps.event.trigger(input, 'keydown', {keyCode:40});
                                    // google.maps.event.trigger(input, 'keydown', {keyCode:13});
                                }
                                angular.element(document).on('focusout', '#pac-input', function() {
                                    selectFirstAddress(this);
                                });
                                 
                              }

                              $scope.fetchAutocomplete = function(){
                                  infowindow.close();
                                  marker.setVisible(false);
                                  var place = autocomplete.getPlace();
                                  if (!place.geometry) {
                                    // User entered the name of a Place that was not suggested and
                                    // pressed the Enter key, or the Place Details request failed.
                                    window.alert("No details available for input: '" + place.name + "'");
                                    return;
                                  }
                                  var lat = place.geometry.location.lat();
                                  var lng = place.geometry.location.lng();
                                  var address = place.formatted_address;
                                  $scope.lat = lat;
                                  $scope.lng = lng;
                                  // If the place has a geometry, then present it on a map.
                                  if (place.geometry.viewport) {
                                    map.fitBounds(place.geometry.viewport);
                                  } else {
                                    map.setCenter(place.geometry.location);
                                    map.setZoom(15);  // Why 17? Because it looks good.
                                  }
                                  marker.setPosition(place.geometry.location);
                                  marker.setVisible(true);

                                  infowindowContent.children['place-icon'].src = place.icon;
                                  infowindowContent.children['place-name'].textContent = place.name;
                                  infowindowContent.children['place-address'].textContent = address;
                                  var address_long_name =  place.address_components[0].long_name; 
                                  if(address_long_name == place.name){
                                    $scope.booking.address = address;     
                                  }else{
                                    $scope.booking.address = place.name  + ','+ address
                                  }
                                  $scope.$apply();
                                  infowindow.open(map, marker);
                                  
                              }

                              $scope.getPlace = function(lat,lng,address) {
                              var latlng = new google.maps.LatLng(lat, lng);
                              var geocoder = new google.maps.Geocoder();
                              geocoder.geocode({'latLng': latlng}, function(results, status) {
                                if (status == google.maps.GeocoderStatus.OK) {
                                  if (results[1]) { 
                                    marker = new google.maps.Marker({
                                        position: latlng,
                                        map: map
                                    });

                                    map.setCenter(marker.getPosition());
                                    map.setZoom(15); 
                                    $scope.lat = lat;
                                    $scope.lng = lng;
                                    infowindowContent.children['place-address'].textContent = address;
                                    marker.setIcon(null);
                                    infowindow.open(map, marker);
                                  }
                                  else {
                                    //handle error status accordingly
                                  }
                                }
                              })
                            }

                           $scope.getAllLanguagesInBookingModal = function(){
                                BookingService.getAllLanguagesInBooking().get({},function(response, err){
                                    if(response.status == 1){
                                        $scope.agencyLanguages = response.data;
                                    }else{
                                        $scope.agencyLanguages = {};
                                    }
                                })
                            }

                            $scope.getInterpreterNamesByLanguageIdModal = function(languageId){
                                BookingService.getInterpreterNamesByLanguageId().get({id:languageId},function(response, err){
                                    if(response.status == 1){
                                        $scope.intepreterName = response.data;
                                    }else{
                                        $scope.intepreterName = {};
                                    }
                                })
                            } 
                        }
                    });
            };

            $scope.getRandomColor = function() {
                var letters = 'DGABA'.split('');
                var color = '#';
                for (var i=0; i<3; i++ ) {
                    color += letters[Math.floor(Math.random() * letters.length)];
                }
                return color;
            }
            
           

            // $scope.getBookingList = function(){
            //     BookingService.getBookingList().get({},function(response, err){
            //         if(response.status == 1){
            //             $scope.bookingList = response.data;
            //         }else{
            //             $scope.bookingList = {};
            //         }
            //     })
            // }  

            /**
        * Function is used to get booking list of an agency
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 18-Sep-2017
        **/
        $rootScope.getAgencyBookingList = function() {
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    if($scope.selectClient.client_id != '' && $scope.selectClient.client_id != null && $scope.selectClient.client_id != undefined){
                        $scope.paramUrl.client_id = $scope.selectClient.client_id;
                    }
                    $scope.bookingList = [];
                    BookingService.getAgencyBookingList().save($scope.paramUrl, function(response, err) {
                        // console.log("getAgencyBookingList", response.count);
                        if (response.status == 1) {
                            $scope.tableLoader = false;
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };

        /**
        * Function is used to get booking list of an agency by searching
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 18-Sep-2017
        **/
        $scope.getBookingListSearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    if($scope.selectClient.client_id != '' && $scope.selectClient.client_id != null && $scope.selectClient.client_id != undefined){
                        $scope.paramUrl.client_id = $scope.selectClient.client_id;
                    }
                    $scope.bookingList = [];
                    BookingService.getAgencyBookingList().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };


            $scope.getAgencyInterpreters = function(){
                BookingService.getAgencyInterpreters().get({},function(response, err){
                    if(response.status == 1){
                        $scope.agencyInterpreters = response.data;
                    }else{
                        $scope.agencyInterpreters = {};
                    }
                })
            }  

            $scope.getAgencyClients = function(){
                BookingService.getAgencyClients().get({},function(response, err){
                    if(response.status == 1){
                        $scope.agencyClients = response.data;
                    }else{
                        $scope.agencyClients = {};
                    }
                })
            } 

            $scope.addBooking = function(form) {
                if (form.$valid) {
                    $scope.loader = true;
                    $scope.disabled = true;
                    
                    $scope.booking.lat = $scope.lat;
                    $scope.booking.lng = $scope.lng;
                    BookingService.addBooking().save($scope.booking, function(response, err) {

                        var errorMessage = '';
                        $scope.disabled = false;
                        $scope.loader = false;
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $location.path('listBooking');
                        } else {
                            logger.logError(response.message);

                        }
                    });
                }else{
                    logger.logError("You have missed the required fields to fill the form.");
                }

            };

           

            $scope.dateModel = {};
            $scope.today = function() {
                $scope.dt = new Date();
            };
            $scope.dateformat = "MM/dd/yyyy";
            $scope.today();
            $scope.showcalendar = function($event) {
                $scope.dateModel.showdp = true;
            };
            $scope.showcalendar1 = function($event) {
                $scope.dateModel.showdp1 = true;
            };
            $scope.dateModel.showdp = false;
            $scope.dateModel.showdp1 = false;
            $scope.dtmax = new Date(); 



            $scope.getBookingById = function(){
                /* Variables is used to initialize the working hours on document ready */
                var currentDate = new Date();
                $scope.booking = {};
                $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
                $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
                $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                
                setTimeout(function(){
                    angular.element(document.querySelector('#working_from_id')).trigger('change');
                    angular.element(document.querySelector('#working_to_id')).trigger('change');
                },1000);                
                /* End */

                if($stateParams.id){
                    BookingService.getBookingById().get({id:$stateParams.id},function(response, err){
                        if(response.status == 1){
                            var booking = response.data;
                            // booking.booking_from = new Date(booking.booking_from);
                            // booking.booking_to = new Date(booking.booking_to);
                            booking.booking_from = new Date(moment(booking.booking_from));
                            booking.booking_to = new Date(moment(booking.booking_to));
                            var tmpTime;
                            if(booking.working_from){
                                tmpTime = CommonService.convertTo24Format(booking.working_from);
                                $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                                $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                                $scope.minTime = $scope.working_from_full1;
                            }
                            if(booking.working_to){
                                tmpTime = CommonService.convertTo24Format(booking.working_to);
                                $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                            }
                            
                            // $scope.booking = booking;
                            $scope.booking = booking;
                            $scope.getInterpreterNamesByLanguageId(booking.language_id);

                            $scope.getPlace(booking.lat,booking.lng,booking.address);
                            // google.maps.event.addListenerOnce(map, 'tilesloaded', function(){
                            //     setTimeout(function(){
                            //         angular.element(document.querySelector('#pac-input')).trigger("focus");
                            //         angular.element(document.querySelector('#service_title')).trigger("focus");
                            //     },1000);
                                
                            // });
                            
                        }
                    })
                }
            }

            $scope.getBookingViewById = function(){
                /* Variables is used to initialize the working hours on document ready */
                var currentDate = new Date();
                $scope.booking = {};
                $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
                $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
                $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                
                setTimeout(function(){
                    angular.element(document.querySelector('#working_from_id')).trigger('change');
                    angular.element(document.querySelector('#working_to_id')).trigger('change');
                },1000);                
                /* End */

                if($stateParams.id){
                    BookingService.getBookingViewById().get({id:$stateParams.id},function(response, err){
                        if(response.status == 1){
                            var booking = response.data;
                            booking.booking_from = new Date(moment(booking.booking_from));
                            booking.booking_to = new Date(moment(booking.booking_to));
                            var tmpTime;
                            if(booking.working_from){
                                tmpTime = CommonService.convertTo24Format(booking.working_from);
                                $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                                $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                                $scope.minTime = $scope.working_from_full1;
                            }
                            if(booking.working_to){
                                tmpTime = CommonService.convertTo24Format(booking.working_to);
                                $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                            }
                            
                            $scope.booking = booking;
                            $scope.getPlace(booking.lat,booking.lng,booking.address);
                            
                            // google.maps.event.addListenerOnce(map, 'tilesloaded', function(){
                            //     setTimeout(function(){
                            //         angular.element(document.querySelector('#pac-input')).trigger("focus");
                            //         angular.element(document.querySelector('#service_title')).trigger("focus");
                            //     },1000);
                                
                            // });
                            
                        }
                    })
                }
            }

            $scope.deleteBooking = function(id, $event) {
                $event.stopPropagation();
                bootbox.confirm('Are you sure, you want to delete this booking?', function(r) {
                    if (r) {
                        BookingService.deleteBooking().delete({id:id},function(response, err) {
                            if (response.status == 1) {
                                logger.logSuccess(response.message); 
                                $scope.getAgencyBookingList();
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                })

            }  

            $scope.updateBooking = function(form) {
                if (form.$valid) {
                    $scope.booking.lat = $scope.lat;
                    $scope.booking.lng = $scope.lng;
                    BookingService.updateBooking().save($scope.booking, function(response, err) {
                        var errorMessage = '';
                        $scope.disabled = false;
                        $scope.loader = false;
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $location.path('/listBooking');
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }else{
                    logger.logError("You have missed the required fields to fill the form.");
                }
            }

            $scope.searchBookingByDate = function() {
            var date = {};
                date.searchFrom = $scope.bookingFrom;
                date.searchTo = $scope.bookingTo;
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.tableLoader = true;
                    $scope.bookingList = [];
                    $scope.paramUrl.searchFrom = $scope.bookingFrom;
                    $scope.paramUrl.searchTo = $scope.bookingTo;
                    BookingService.searchBookingByDate().save($scope.paramUrl, function(response, err) {
                        if (response.status == 1) {
                            $scope.tableLoader = false;
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };
        
        var infowindow,marker,infowindowContent,autocomplete,map;
        $scope.initMap = function () {

            map = new google.maps.Map(document.getElementById('map'), {
              center: {lat: 41.310726, lng: -72.929916},
              zoom: 15,
            });

            var input = document.getElementById('pac-input');
            // To restrict places in google place to us
            // var options = {
            //     types: [],
            //     componentRestrictions: {country: "US"}
            // };
            // autocomplete = new google.maps.places.Autocomplete(input,options);

            autocomplete = new google.maps.places.Autocomplete(input);
            autocomplete.bindTo('bounds', map);
            infowindow = new google.maps.InfoWindow();
            infowindowContent = document.getElementById('infowindow-content');
            infowindow.setContent(infowindowContent);
            marker = new google.maps.Marker({
              map: map
            });

            autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
            function selectFirstAddress (input) {
                google.maps.event.trigger(input, 'keydown', {keyCode:40});
                // google.maps.event.trigger(input, 'keydown', {keyCode:13});
            }
            angular.element(document).on('focusout', '#pac-input', function() {
                selectFirstAddress(this);
            });
          }


          $scope.fetchAutocomplete = function(){
              infowindow.close();
              marker.setVisible(false);
              var place = autocomplete.getPlace();
              if (!place.geometry) {
                // User entered the name of a Place that was not suggested and
                // pressed the Enter key, or the Place Details request failed.
                window.alert("No details available for input: '" + place.name + "'");
                return;
              }
              var lat = place.geometry.location.lat();
              var lng = place.geometry.location.lng();
              var address = place.formatted_address;
              $scope.lat = lat;
              $scope.lng = lng;
              // If the place has a geometry, then present it on a map.
              if (place.geometry.viewport) {
                map.fitBounds(place.geometry.viewport);
              } else {
                map.setCenter(place.geometry.location);
                map.setZoom(15);  // Why 17? Because it looks good.
              }
              marker.setPosition(place.geometry.location);
              marker.setVisible(true);

              infowindowContent.children['place-icon'].src = place.icon;
              infowindowContent.children['place-name'].textContent = place.name;
              infowindowContent.children['place-address'].textContent = address;
              var address_long_name =  place.address_components[0].long_name; 
              if(address_long_name == place.name){
                $scope.booking.address = address;     
              }else{
                $scope.booking.address = place.name  + ', '+ address;
              }

              $scope.$apply();
              infowindow.open(map, marker);
          }
          $scope.getPlace = function(lat,lng,address) {
              var latlng = new google.maps.LatLng(lat, lng);
              var geocoder = new google.maps.Geocoder();
              geocoder.geocode({'latLng': latlng}, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                  if (results[1]) { 
                    marker = new google.maps.Marker({
                        position: latlng,
                        map: map
                    });

                    map.setCenter(marker.getPosition());
                    map.setZoom(15); 
                    $scope.lat = lat;
                    $scope.lng = lng;
                    infowindowContent.children['place-address'].textContent = address;
                    marker.setIcon(null);
                    infowindow.open(map, marker);
                  }
                  else {
                    //handle error status accordingly
                  }
                }
              })
            }

            $scope.viewBooking = function(booking) {
            $state.go('agency_viewBooking', {id:booking._id});
        };

        $scope.testFunc = function(rating){
            var displatRating=[];
            for(var i=0;i<5;i++){
              if(rating-i>=1){
                displatRating.push({starType:'fa-star'}); 
              }else if(rating-i<1 && rating-i>0){
                displatRating.push({starType:'fa-star-half-o'}); 
              }else{
                displatRating.push({starType:'fa-star-o'}); 
              }
            }
            return displatRating;
        }

        $scope.getReviewByBookingId = function() {
            if($stateParams.id){
                BookingService.getReviewByBookingId().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var ratingArr = [];
                        if(response.data != undefined && response.data != '' && response.data != null){
                            $scope.reviewRating = response.data;
                            $scope.ratingArr = $scope.testFunc($scope.reviewRating.rating);
                        }else{
                            $scope.ratingArr = [];
                            $scope.reviewRating = {};    
                        }
                    } else {
                        $scope.reviewRating = {};
                        $scope.ratingArr = [];
                    }
                })
            } 
        };

        $scope.getCheckInOutDetailByBookingId = function(id){
            BookingService.getCheckInOutDetailByBookingId().get({id: id},function(response, err){
                if(response.status == 1){
                    $rootScope.checkInOut = response.data;
                    $uibModal.open({
                        templateUrl: 'agency/modules/booking/views/approvalModal.html',
                        size: "md",
                        controller: function($scope, $uibModalInstance) {
                            $scope.checkInOut = $rootScope.checkInOut;
                            $scope.closeuib = function() {
                                $uibModalInstance.dismiss();
                            };

                            $scope.checkInOutApproval = function(booking_id, approval){
                                var checkInOut = {
                                    booking_id: booking_id,
                                    approval: approval,
                                    checkInOutId: $rootScope.checkInOut._id  
                                }
                                BookingService.checkInOutApproval().save(checkInOut, function(response, err) {
                                    if (response.status == 1) {
                                        logger.logSuccess(response.message); 
                                        $scope.closeuib();
                                        $state.reload();
                                    } else {
                                        logger.logError(response.message);
                                    }
                                });
                            } 
                        }
                    });                   
                } else {
                    $scope.checkInOut = {};
                    logger.logError(response.message);
                }
            })
        }

        $scope.getAllLanguagesInBooking = function(){
            BookingService.getAllLanguagesInBooking().get({},function(response, err){
                if(response.status == 1){
                    $scope.agencyLanguages = response.data;
                }else{
                    $scope.agencyLanguages = {};
                }
            })
        }

        $scope.clearSearch = function(){
            $scope.bookingFrom = "";
            $scope.bookingTo = "";
            $state.reload();
        }

        $scope.getInterpreterNamesByLanguageId = function(languageId){
            BookingService.getInterpreterNamesByLanguageId().get({id:languageId},function(response, err){
                if(response.status == 1){
                    $scope.intepreterName = response.data;
                }else{
                    $scope.intepreterName = {};
                }
            })
        }

        /**
        * Function is uesd to initialize map
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 23-Jan-2017
        **/
        $scope.initilizeMap = function(){
            var map;
            map = new google.maps.Map(document.getElementById('map'), {
              center: {lat: 41.310726, lng: -72.929916},
              zoom: 13
            });
        }

        $scope.testFunc = function(rating){
            var displatRating=[];
            for(var i=0;i<5;i++){
              if(rating-i>=1){
                displatRating.push({starType:'fa-star'}); 
              }else if(rating-i<1 && rating-i>0){
                displatRating.push({starType:'fa-star-half-o'}); 
              }else{
                displatRating.push({starType:'fa-star-o'}); 
              }
            }
            return displatRating;
        }

        $scope.getBookingInterpretersLocation = function() {
            if($stateParams.id){
                var locationMarker = {
                    radiusInMeter: $scope.radiusInMeter ? parseFloat($scope.radiusInMeter) * 1609.34 : 1609.34, //1 Mile = 1609.34 meter
                    id: $stateParams.id 
                }
                
                BookingService.getBookingInterpretersLocation().save(locationMarker,function(response, err){
                    if(response.status == 1){
                        if(response.interpretersArray.length == 0){
                            logger.log(response.message);
                        }
                        var booking = response.data;
                        $scope.booking = booking;
                        console.log("booking data", $scope.booking);
                        $scope.interpretersArray = response.interpretersArray;
                        var interpretersData = response.interpretersData; 
                        var selectedInterpretersArray = response.selectedInterpretersArray;
                        for(var i=0; i< interpretersData.length; i++){
                            var rate = interpretersData[i].rate;
                            interpretersData[i].ratingArr = $scope.testFunc(rate);
                        }
                        $scope.interpretersData = interpretersData;
                        for(var i=0; i< selectedInterpretersArray.length; i++){
                            var rate = selectedInterpretersArray[i].interpreter_id.rate;
                            selectedInterpretersArray[i].interpreter_id.ratingArr = $scope.testFunc(rate);
                        }
                        $scope.selectedInterpretersArray = selectedInterpretersArray;
                        $scope.radiusInMeter = $scope.radiusInMeter ? $scope.radiusInMeter : 1;
                        // Locate the booking location and check-in location in map
                        var bookingPoint = {
                            point: new google.maps.LatLng(booking.lat,booking.lng),
                            radius: locationMarker.radiusInMeter,
                            color: '#00AA00',
                        }
                                               
                        var zoom = 13;
                        var map;
                        var elevator;
                        var mapOptions = {
                            zoom: zoom,
                            center: bookingPoint.point,
                            mapTypeId: google.maps.MapTypeId.ROADMAP,
                        };
                        map = new google.maps.Map(document.getElementById('map'), mapOptions);
                        //render the range
                        var subjectMarker = new google.maps.Marker({
                            map: map,
                            position: bookingPoint.point,
                            title: 'Booking Location'
                        });
                        var subjectRange = new google.maps.Circle({
                            map: map,
                            radius: bookingPoint.radius,    // metres
                            fillColor: bookingPoint.color,
                        });
                        subjectRange.bindTo('center', subjectMarker, 'position');
                        
                        //render the geolocation
                        for (var i = 0; i < response.interpretersArray.length; i++){
                            var point = new google.maps.LatLng(response.interpretersArray[i].lat,response.interpretersArray[i].lng);
                            var marker = new google.maps.Marker({
                                map: map,
                                position: point,
                                title: response.interpretersArray[i].first_name+ ' ' + response.interpretersArray[i].last_name
                            });
                        }
                        //End

                    }
                })
            }else{
                $state.go('agency_listBooking');
            }
        }

        $scope.sendRequestToInterpreters = function(){
            var selectedInterpretersArray = $scope.selectedInterpretersArray;
            var interpreterSelectedArray = [];
            var interpreterUpdateArray = [];
            var interpretersData = $scope.interpretersData;
            var hasFound = false;
            var tmp = {};
            for(var i=0; i<interpretersData.length;i++){
                if(interpretersData[i].selected == true){
                    interpreterSelectedArray.push(interpretersData[i]);
                }
            }
            for(var i=0; i< selectedInterpretersArray.length; i++){
                hasFound = false;
                for(var j=0; j< interpreterSelectedArray.length; j++){
                    if(selectedInterpretersArray[i].interpreter_id._id == interpreterSelectedArray[j]._id){
                        hasFound = true;
                        interpreterSelectedArray[j].request_id = selectedInterpretersArray[i]._id;
                        interpreterSelectedArray[j].text = selectedInterpretersArray[i].text;
                        interpreterSelectedArray[j].request_token = selectedInterpretersArray[i].request_token;
                        break;
                    }
                }
                if(!hasFound){
                    tmp = selectedInterpretersArray[i].interpreter_id;
                    tmp.request_id = selectedInterpretersArray[i]._id;
                    tmp.text = selectedInterpretersArray[i].text;
                    tmp.request_token = selectedInterpretersArray[i].request_token;
                    tmp.selected=false;
                    interpreterSelectedArray.push(tmp);
                }
            }
            if(interpreterSelectedArray.length != 0){
                var selectedObj = {};
                selectedObj.interpreterSelectedArray = interpreterSelectedArray;
                selectedObj.booking = $scope.booking;
                BookingService.sendRequestToInterpreters().save(selectedObj,function(response, err){
                    if(response.status == 1){
                        $state.go('agency_listBooking');
                        logger.logSuccess(response.message);
                    }else{
                        logger.logError(response.message);
                    }
                })
            }else{
                logger.log("Please select at least one interpreter for request");
            }
        }

        /**
        * Function is used to get clients by Agency
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 5-March-2018
        **/
        $scope.getClientListByAgency = function(){
            BookingService.getClientListByAgency().get({},function(response, err){
                if(response.status == 1){
                    $scope.clientList = response.data;
                }else{
                    $scope.clientList = {};
                }
            })
        }

        /**
        * Function is used to refetched full calendar events by Agency
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 5-March-2018
        **/
        $scope.getBookingOnClientSelection = function(){
            $('#providerDiv').fullCalendar('refetchEvents');
        } 
    
    }
]);
