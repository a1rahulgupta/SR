"use strict"

angular.module("Booking")

.factory('BookingService', ['$http', '$resource', function($http, $resource) {


    var updateProfile = function() {
        return $resource(webservices.updateProfile, null, {
            save: {
                method: 'POST'
            }
        });
    }
    
    var getAgencyBookingList = function() {
        return $resource(webservices.getAgencyBookingList, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAgencyInterpreters = function() {
        return $resource(webservices.getAgencyInterpreters, null, {
            save: {
                method: 'GET'
            }
        });
    }
           
    var getAgencyClients = function() {
        return $resource(webservices.getAgencyClients, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var addBooking = function() {
        return $resource(webservices.addBooking, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getBookingById = function(id) {
        return $resource(webservices.getBookingById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getBookingViewById = function(id) {
        return $resource(webservices.getBookingViewById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var deleteBooking = function(id) {
        return $resource(webservices.deleteBooking, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

     var updateBooking = function() {
        return $resource(webservices.updateBooking, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getBookingList = function() {
        return $resource(webservices.getBookingList, null, {
            save: {
                method: 'GET'
            }
        });
    }
    var searchBookingByDate = function() {
        return $resource(webservices.searchBookingByDate, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getReviewByBookingId = function(id) {
        return $resource(webservices.getReviewByBookingId, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getCheckInOutDetailByBookingId = function(id) {
        return $resource(webservices.getCheckInOutDetailByBookingId, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var checkInOutApproval = function() {
        return $resource(webservices.checkInOutApproval, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllLanguagesInBooking = function() {
        return $resource(webservices.getAllLanguagesInBooking, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getInterpreterNamesByLanguageId = function(id) {
        return $resource(webservices.getInterpreterNamesByLanguageId, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getBookingInterpretersLocation = function() {
        return $resource(webservices.getBookingInterpretersLocation, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var sendRequestToInterpreters = function() {
        return $resource(webservices.sendRequestToInterpreters, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getClientListByAgency = function() {
        return $resource(webservices.getClientListByAgency, null, {
            save: {
                method: 'GET'
            }
        });
    }

    return {
        updateProfile: updateProfile,
        getBookingList: getBookingList,
        getAgencyInterpreters: getAgencyInterpreters,
        getAgencyClients: getAgencyClients,
        addBooking: addBooking,
        getBookingById: getBookingById,
        deleteBooking:deleteBooking,
        updateBooking: updateBooking,
        getAgencyBookingList: getAgencyBookingList,
        getBookingViewById: getBookingViewById,
        searchBookingByDate: searchBookingByDate,
        getReviewByBookingId: getReviewByBookingId,
        getCheckInOutDetailByBookingId:getCheckInOutDetailByBookingId,
        checkInOutApproval: checkInOutApproval,
        getAllLanguagesInBooking: getAllLanguagesInBooking,
        getInterpreterNamesByLanguageId: getInterpreterNamesByLanguageId,
        getBookingInterpretersLocation: getBookingInterpretersLocation,
        sendRequestToInterpreters: sendRequestToInterpreters,
        getClientListByAgency: getClientListByAgency
    }

}]);
