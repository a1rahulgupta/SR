"use strict";

angular.module("Invoice")

interpreterApp.controller("invoiceController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger', 'InvoiceService', 'ngTableParams', 'ngTableParamsService', 'CommonService', 'blockUI',
    function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal, logger, InvoiceService, ngTableParams, ngTableParamsService, CommonService, blockUI) {
       
        /**
        * Variable is used for update interpreter
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        if ($state.params.id) {
            $scope.isUpdate = true;
        } else {
            $scope.isUpdate = false;
        };
        /**
        * Variable is used for active class on leftbar
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $rootScope.menuInvoice = ['agency_listInvoice', "agency_viewInvoice"];
        
        /**
        * Function and variable is used for image format
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.isCropVisible=false;
        $scope.myImage='';
        $scope.myCroppedImage='';
        $scope.isImageSelected=false;
        var handleFileSelect=function(evt) {
            $scope.isImageSelected=false;
            $scope.isCropVisible=true;
            var file=evt.currentTarget.files[0];
            var reader = new FileReader();
            reader.onload = function (evt) {
                $scope.$apply(function($scope){
                    $scope.myImage=evt.target.result;
                });
            };
            reader.readAsDataURL(file);
        };
        angular.element(document.querySelector('#fileInput')).on('change',handleFileSelect);
        $scope.openFileBrowse = function(fileInputSelector) {
            angular.element(document.querySelector(fileInputSelector)).trigger('click');
        };
      
        var formDataFileUpload = '';
        $scope.imageBase64 = '';
        angular.element(document).ready(function() {
            setTimeout(function() {
                if(document.getElementById('fileInput')!=null){
                    document.getElementById('fileInput').addEventListener('change', function(evt) {
                        var files = evt.target.files;
                        var file = files[0];
                        if (files && file) {
                            var splitFileName = file.name.split('.');
                            var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                            if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {
                                if (file.size > 6291456) {
                                    logger.log('File size cannot exceed limit of 6 mb');
                                    document.getElementById("fileInput").value = "";
                                } else {
                                    formDataFileUpload = file;
                                    // formDataFileUpload.append('file', file);
                                    var reader = new FileReader();
                                    reader.onload = function(readerEvt) {
                                        $scope.imageBase64 = btoa(readerEvt.target.result);
                                        $scope.$apply();
                                        document.querySelector('#imgTag').src = 'data:image/' + ext + ';base64,' + $scope.imageBase64;
                                    };
                                    reader.readAsBinaryString(file);
                                }
                            } else {
                                document.getElementById("fileInput").value = "";
                                bootbox.alert('Invalid image format');
                            }
                        }
                    });
                }
            }, 500);
        });

        
        /**
        * Function is used to list interpreters of an agency
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/

        $scope.myFunction =  function () {
            window.print();
        }
        $scope.listAgencyInvoice = function() {
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.invoiceList = [];
                    InvoiceService.listAgencyInvoice().save($scope.paramUrl, function(response, err) {
                        // console.log("RESPONSE", response);
                        if (response.status == 1) {
                            $scope.invoiceList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };

        $scope.listAgencyInvoiceSearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.invoiceList = [];
                    InvoiceService.listAgencyInvoice().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.invoiceList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

 
        $scope.getAgencyInvoiceById = function(){
            if($stateParams.id){
                InvoiceService.getAgencyInvoiceById().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        $scope.invoice = response.data;
                    }else{
                        logger.logError(response.message);
                    }
                })
            }
        };

        $scope.getCurrentPlanDetails = function(){
            InvoiceService.getCurrentPlanDetails().get({id:$stateParams.id},function(response, err){
                if(response.status == 1){
                    $scope.invoice = response.data;
                    $localStorage.agencyData = $scope.invoice.agency_id;
                    $localStorage.current_subscription_id = $scope.invoice.subscription_id;
                    console.log("$localStorage.current_subscription_id", $scope.invoice.subscription_id);
                }else{
                    logger.logError(response.message);
                }
            })
        };

        $scope.stopRecurringPayment = function(){
            bootbox.confirm('Are you sure you want to stop recurring payment', function(r) {
                      if (r) {
                    InvoiceService.stopRecurringPayment().save(function(response) {
                        if(response.status == 1){
                            logger.logSuccess(response.message);
                            $state.reload();
                        }else{
                            logger.logError(response.message);
                        }
                    });
                  }
              })
        };

        $scope.viewInvoice = function(invoice) {
            $state.go('agency_viewInvoice', {id:invoice._id});
        };

        $scope.startRecurringPayment = function(){
            var currentPlanId = $scope.invoice._id
            bootbox.confirm('Are you sure you want to start recurring payment', function(r) {
                      if (r) {
                    InvoiceService.startRecurringPayment().save({currentPlanId: currentPlanId},function(response) {
                        if(response.status == 1){
                            logger.logSuccess(response.message);
                            $state.reload();
                        }else{
                            logger.logError(response.message);
                        }
                    });
                  }
              })
        };

        $scope.getAllSubscriptionPlanByAgency = function() {
            InvoiceService.getAllSubscriptionPlanByAgency().get(function(response, err) {
                if (response.status == 1) {
                    $scope.subscriptions = response.data;
                } else {
                    $scope.subscriptions = [];
                    logger.logError(response.message);
                }
            });
        };

        /**
        * Function is used to view subscription modal 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 16-Mar-2018
        **/
        $scope.viewCardDetailModel = function(subscription) {
            $localStorage.subscription_id = subscription._id;
            $localStorage.plan_name = subscription.plan_name;
            $localStorage.amount = subscription.amount;
            $uibModal.open({
                templateUrl: 'agency/modules/invoice/views/subscriptionModal.html',
                size: "md",
                controller: function($scope,$rootScope, $uibModalInstance) {
                    
                    var stripe = Stripe(stripe_published_key);
                    var elements = stripe.elements();

                    setTimeout(function(){
                        stripeCard();                  
                    },200)

                    $scope.closeuib = function() {
                        $uibModalInstance.close();
                    }

                    $scope.getData = function(){
                        $scope.plan_name = $localStorage.plan_name;
                        $scope.amount = $localStorage.amount;
                    }

                    function stripeCard() {
                        var style = {
                            base: {
                                color: '#333',
                                lineHeight: '24px',
                                fontSmoothing: 'antialiased',
                                fontSize: '14px',
                                '::placeholder': {
                                    color: '#999'
                                }
                            },
                            invalid: {
                                color: '#a94442',
                                iconColor: '#a94442'
                            }
                        };

                        $scope.card = elements.create('card', { hidePostalCode: true, style: style });
                        $scope.card.mount('#card-element');

                        $scope.card.addEventListener('change', function(event) {
                            var displayError = document.getElementById('card-errors');
                            if (event.error) {
                                displayError.textContent = event.error.message;
                            } else {
                                displayError.textContent = '';
                            }
                        });

                        $scope.upgradeSubscriptionPlan = function() {
                            console.log("inside upgradeSubscriptionPlan");
                            $scope.closeuib();
                            blockUI.start('Payment is in Process. Please wait...');
                            stripe.createToken($scope.card).then(function(result) {
                                if (result.error) {
                                    // Inform the user if there was an error
                                    var errorElement = document.getElementById('card-errors');
                                    errorElement.textContent = result.error.message;
                                } else {
                                    // Send the token to your server
                                    var agency =  $localStorage.agencyData;
                                    agency.subscription_id = $localStorage.subscription_id;
                                    agency.card_holder_name = $scope.card_holder_name;
                                    agency.token = result.token.id;
                                    agency.previous_subscription_plan_id = $localStorage.current_subscription_id
                                    console.log("token",result.token.id);
                                    console.log("card_holder_name",$scope.card_holder_name);
                                    console.log("subscription_id",$localStorage.subscription_id);    
                                    console.log("agency",agency);
                                    
                                    InvoiceService.upgradeSubscriptionPlan().save(agency, function(response) {
                                        if (response.status == 1) {
                                            delete $localStorage.agencyData;
                                            delete $localStorage.subscription_id;
                                            delete $localStorage.plan_name;
                                            delete $localStorage.amount;
                                            blockUI.stop();
                                            logger.logSuccess(response.message); 
                                            $state.go('agency_listInvoice');
                                        } else {
                                            delete $localStorage.agencyData;
                                            delete $localStorage.subscription_id;
                                            delete $localStorage.plan_name;
                                            delete $localStorage.amount;
                                            blockUI.stop();
                                            logger.logError(response.message);
                                            $state.go('agency_listInvoice');
                                        }
                                    })
                                }
                                $scope.$emit('stop', true);
                            });
                        }


                    }

                }
            });
        };
                
    }

]);
