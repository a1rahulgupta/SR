"use strict"

angular.module("Invoice")

.factory('InvoiceService', ['$http', '$resource', function($http, $resource) {
 
    var listAgencyInvoice = function() {
        return $resource(webservices.listAgencyInvoice, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAgencyInvoiceById = function(id) {
        return $resource(webservices.getAgencyInvoiceById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getCurrentPlanDetails = function() {
        return $resource(webservices.getCurrentPlanDetails, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var stopRecurringPayment = function() {
        return $resource(webservices.stopRecurringPayment, null, {
            save: {
                method: 'POST'
            }
        });
    }
    
    var startRecurringPayment = function() {
        return $resource(webservices.startRecurringPayment, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllSubscriptionPlanByAgency = function() {
        return $resource(webservices.getAllSubscriptionPlanByAgency, null, {
            get: {
                method: 'GET'
            }
        });
    }

    var upgradeSubscriptionPlan = function() {
        return $resource(webservices.upgradeSubscriptionPlan, null, {
            save: {
                method: 'POST'
            }
        });
    }

    return {
        listAgencyInvoice: listAgencyInvoice,
        getAgencyInvoiceById: getAgencyInvoiceById,
        getCurrentPlanDetails: getCurrentPlanDetails,
        stopRecurringPayment: stopRecurringPayment,
        startRecurringPayment: startRecurringPayment,
        getAllSubscriptionPlanByAgency: getAllSubscriptionPlanByAgency,
        upgradeSubscriptionPlan: upgradeSubscriptionPlan

    }

}]);
