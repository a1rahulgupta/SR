"use strict"

angular.module("Client")

.factory('ClientService', ['$http', '$resource', function($http, $resource) {
 
    var listAgencyClients = function() {
        return $resource(webservices.listAgencyClients, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteAgencyClient = function(id) {
        return $resource(webservices.deleteAgencyClient, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }


    var addAgencyClients = function() {
        return $resource(webservices.addAgencyClients, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAgencyClientById = function(id) {
        return $resource(webservices.getAgencyClientById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var updateAgencyClient = function() {
        return $resource(webservices.updateAgencyClient, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var changeClientStatus = function() {
        return $resource(webservices.changeClientStatus, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllLanguagesInClient = function() {
        return $resource(webservices.getAllLanguagesInClient, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getAllCountriesInClientInAgency = function() {
        return $resource(webservices.getAllCountriesInClientInAgency, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var updateAgencyClientLanguage = function() {
        return $resource(webservices.updateAgencyClientLanguage, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var listBookingOfClientInAgency = function() {
        return $resource(webservices.listBookingOfClientInAgency, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteBookingOfClientInAgency = function(id) {
        return $resource(webservices.deleteBookingOfClientInAgency, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var getClientBookingByIdInAgency = function() {
        return $resource(webservices.getClientBookingByIdInAgency, null, {
            get: {
                method: 'POST'
            }
        });
    }

    var getAllLanguagesInBooking = function() {
        return $resource(webservices.getAllLanguagesInBooking, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getAgencyInterpreters = function() {
        return $resource(webservices.getAgencyInterpreters, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getAgencyClients = function() {
        return $resource(webservices.getAgencyClients, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var updateBooking = function() {
        return $resource(webservices.updateBooking, null, {
            save: {
                method: 'POST'
            }
        });
    }

    return {
        listAgencyClients: listAgencyClients,
        deleteAgencyClient: deleteAgencyClient,
        addAgencyClients: addAgencyClients,
        getAgencyClientById: getAgencyClientById,
        updateAgencyClient: updateAgencyClient,
        changeClientStatus: changeClientStatus,
        getAllLanguagesInClient: getAllLanguagesInClient,
        getAllCountriesInClientInAgency: getAllCountriesInClientInAgency,
        updateAgencyClientLanguage: updateAgencyClientLanguage,
        listBookingOfClientInAgency: listBookingOfClientInAgency,
        deleteBookingOfClientInAgency: deleteBookingOfClientInAgency,
        getClientBookingByIdInAgency: getClientBookingByIdInAgency,
        getAllLanguagesInBooking: getAllLanguagesInBooking,
        getAgencyInterpreters: getAgencyInterpreters,
        getAgencyClients: getAgencyClients,
        updateBooking: updateBooking

    }

}]);
