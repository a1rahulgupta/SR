"use strict";

angular.module("Client")

interpreterApp.controller("clientController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger', 'ClientService','dashboardService', 'ngTableParams','CommonService', 'ngTableParamsService',
    function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal, logger, ClientService,dashboardService, ngTableParams, CommonService, ngTableParamsService) {
       
        /**
        * Variable is used for update client
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        if ($state.params.id) {
            $scope.isUpdate = true;
        } else {
            $scope.isUpdate = false;
        }; 

        $scope.client={};
        $scope.client.gender='Male';
        
        /**
        * Variable is used to active class on leftbar
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $rootScope.menuClient = ['agency_listClient', 'agency_addClient', 'agency_viewClient', 'agency_editClient'];
        
        /**
        * Function and variable is used to check format of image upload
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.myImage='';
        $scope.myCroppedImage='';
        $scope.isImageSelected=false;
        $scope.isCropVisible=false;
        var handleFileSelect=function(evt) {
            $scope.isImageSelected=false;
            $scope.isCropVisible=true;
          var file=evt.currentTarget.files[0];
          var reader = new FileReader();
          reader.onload = function (evt) {
            $scope.$apply(function($scope){
              $scope.myImage=evt.target.result;
            });
          };
          reader.readAsDataURL(file);
        };
        angular.element(document.querySelector('#fileInput')).on('change',handleFileSelect);
        $scope.openFileBrowse = function(fileInputSelector) {
            angular.element(document.querySelector(fileInputSelector)).trigger('click');
        };

        var formDataFileUpload = '';
        $scope.imageBase64 = '';
        angular.element(document).ready(function() {
            setTimeout(function() {
                if(document.getElementById('fileInput')!=null){
                    document.getElementById('fileInput').addEventListener('change', function(evt) {
                        var files = evt.target.files;
                        var file = files[0];
                        if (files && file) {
                            var splitFileName = file.name.split('.');
                            var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                            if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {
                                if (file.size > 6291456) {
                                    logger.log('File size cannot exceed limit of 6 mb');
                                    document.getElementById("fileInput").value = "";
                                } else {
                                    formDataFileUpload = file;
                                    var reader = new FileReader();
                                    reader.onload = function(readerEvt) {
                                        $scope.imageBase64 = btoa(readerEvt.target.result);
                                        $scope.$apply();
                                        document.querySelector('#imgTag').src = 'data:image/' + ext + ';base64,' + $scope.imageBase64;
                                    };
                                    reader.readAsBinaryString(file);
                                }
                            } else {
                                document.getElementById("fileInput").value = "";
                                bootbox.alert('Invalid image format');
                            }
                        }
                    });
                }
            }, 500);
        });

        /**
        * Variables is used to list the language
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        // $scope.languageList = [
        //     {
        //         _id: 'Polish',
        //         name: 'Polish',
        //         ticked: false
        //     },
        //     {
        //         _id: 'English',
        //         name: 'English',
        //         ticked: false
        //     },
        //     {
        //         _id: 'Spanish',
        //         name: 'Spanish',
        //         ticked: false
        //     }
        // ];
        $scope.localLang = {
            selectAll       : "Tick all",
            selectNone      : "Tick none",
            reset           : "Undo all",
            search          : "Type here to search...",
            nothingSelected : "Nothing is selected"         //default-label is deprecated and replaced with this.
        };

        /**
        * Function is used to get clients of an agency
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $rootScope.listAgencyClients = function() {
            ngTableParamsService.set('', '', '', '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.clientList = [];
                    ClientService.listAgencyClients().save($scope.paramUrl, function(response, err) {
                        // console.log("listAgencyClients", response);
                        if (response.status == 1) {
                            $scope.clientList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };

        /**
        * Function is used to get clients of an agency by searching
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.listAgencyclientsSearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.clientList = [];
                    ClientService.listAgencyClients().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.clientList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        /**
        * Function is used to add client of an agency
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.addAgencyClients = function() {
            if($scope.isImageSelected==true){
                $scope.client.imageFile = $scope.myCroppedImage;
            }
            ClientService.addAgencyClients().save($scope.client, function(response) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $location.path('listClient');
                } else {
                    logger.logError(response.message);
                }

            });
        };

        /**
        * Function is used to get agency client by id
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.getAgencyClientById = function(){
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                if($stateParams.id){
                    ClientService.getAgencyClientById().get({id:$stateParams.id},function(response, err){
                        if(response.status == 1){
                            var client = response.data;
                            client.email = client.email;

                            //Multilple language status changed
                            $scope.languageArray = angular.copy(client.languages); 
                            //End    
                            
                            setTimeout(function() {
                                for(var i=0;i<$scope.languageList.length;i++){
                                    for (var j=0;j<client.languages.length;j++) {
                                        if($scope.languageList[i].name == client.languages[j].name
                                            && client.languages[j].ticked==true){
                                            $scope.languageList[i].ticked=true;
                                            break;
                                        }
                                    }
                                }
                                if(client.profile_pic!='' && client.profile_pic!=undefined){
                                    $scope.userDefaultImage=client.profile_pic;
                                }
                                $scope.$apply();
                            }, 500);
                            $scope.client = client;
                        }else{
                            $scope.client = {};
                        }
                    })
                }
        };

        /**
        * Function is used to get agency client by id in view
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.getAgencyClientByIdInView = function(){
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
                if($stateParams.id){
                    ClientService.getAgencyClientById().get({id:$stateParams.id},function(response, err){
                        if(response.status == 1){
                            var client = response.data;
                            if(client.profile_pic!='' && client.profile_pic!=undefined){
                                $scope.userDefaultImage=client.profile_pic;
                            }
                            $scope.client = client;
                        }else{
                            $scope.client = {};
                        }
                    })
                }
        };

        /**
        * Function is used to update the client of an agency
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.updateAgencyClient = function() {
            if($scope.isImageSelected==true){
                $scope.client.imageFile = $scope.myCroppedImage;
            }
            var client = $scope.client;
            var languageArray = $scope.languageArray;
            var hasFound = false;
            var tmp = {};
            for(var i=0; i< languageArray.length; i++){
                hasFound = false;
                for(var j=0; j< client.languages.length; j++){
                    if(languageArray[i].language_id == client.languages[j]._id){
                        hasFound = true;
                        break;
                    }
                }
                if(!hasFound){
                    tmp = languageArray[i];
                    tmp._id=tmp.language_id;
                    tmp.ticked = false;
                    client.languages.push(tmp);
                }
            }
            ClientService.updateAgencyClient().save(client, function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $location.path('/listClient');
                } else {
                    logger.logError(response.message);
                }
            });
        };
        
        /**
        * Function is used to delete the client of an agency
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.deleteAgencyClient = function(id,$event) {
            $event.stopPropagation();
            bootbox.confirm('Are you sure, you want to delete this client?', function(r) {
                if (r) {
                    ClientService.deleteAgencyClient().delete({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listAgencyClients();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        
        /**
        * Function is used to view the client of an agency
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.viewClient = function(client) {
            $state.go('agency_viewClient', {id:client._id});
        };

        /**
        * Function is used to change the status of the agency client
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.changeClientStatus = function(id,status) {
            var client = {
                id: id,
                status: status
            }
            ClientService.changeClientStatus().save(client,function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $scope.listAgencyClients();
                } else {
                    logger.log(response.message);
                }
            });
        };

        /**
        * Function is used to get all languages in multiselect
        * @access private
        * @return json
        * Created by ramiz
        * @smartData Enterprises (I) Ltd
        * Created Date 20-Dec-2017
        **/
        $scope.getAllLanguagesInClient = function(){
            ClientService.getAllLanguagesInClient().get({},function(response, err){
                if(response.status == 1){
                    $scope.languageList = response.data;
                }else{
                    $scope.languageList = {};
                }
            })
        }

        /**
        * Function is used to get all countries
        * @access private
        * @return json
        * Created by ramiz
        * @smartData Enterprises (I) Ltd
        * Created Date 20-Dec-2017
        **/
        $scope.getAllCountriesInClientInAgency = function(){
            ClientService.getAllCountriesInClientInAgency().get({},function(response, err){
                if(response.status == 1){
                    $scope.clientCountries = response.data;
                    for(var i=0;i<$scope.clientCountries.length;i++){
                        if($scope.clientCountries[i].country_code == 'us'){
                            $scope.client.country_id = $scope.clientCountries[i]._id;
                        }
                    }
                }else{
                    $scope.clientCountries = {};
                }
            })
        }

        /**
        * Function is used to list interpreters of an agency by interpreter id
        * @access private
        * @return json
        * Created by ramiz
        * @smartData Enterprises (I) Ltd
        * Created Date 05-Jan-2018
        **/
        $scope.listBookingOfClientInAgency = function() {
            if($state.params.id){
                    ngTableParamsService.set('', '', '', '');
                    $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    getData: function($defer, params) {
                        // send an ajax request to your server. in my case MyResource is a $resource.
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.paramUrl.client_id = $state.params.id;
                        $scope.bookingList = [];
                        ClientService.listBookingOfClientInAgency().save($scope.paramUrl, function(response, err) {
                            if (response.status == 1) {
                                $scope.bookingList = response.data;
                                var data = response.data;
                                $scope.totalCount = response.count;
                                params.total(response.count);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                }); 
            }
            
        };

        /**
        * Function is used to search list interpreters of an agency
        * @access private
        * @return json
        * Created by ramiz
        * @smartData Enterprises (I) Ltd
        * Created Date 05-Jan-2018
        **/
        $scope.listBookingOfClientInAgencyBySearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.paramUrl.client_id = $state.params.id;
                    $scope.bookingList = [];
                    ClientService.listBookingOfClientInAgency().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        $scope.deleteBookingOfClientInAgency = function(id, $event) {
            $event.stopPropagation();
            bootbox.confirm('Are you sure, you want to delete this booking?', function(r) {
                if (r) {
                    ClientService.deleteBookingOfClientInAgency().delete({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listBookingOfClientInAgency();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })

        }

        $scope.getClientBookingByIdInAgency = function(){
                /* Variables is used to initialize the working hours on document ready */
            var currentDate = new Date();
            $scope.booking = {};
            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
            $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
            
            setTimeout(function(){
                angular.element(document.querySelector('#working_from_id')).trigger('change');
                angular.element(document.querySelector('#working_to_id')).trigger('change');
            },1000);                
            /* End */

            if($stateParams.id){
                ClientService.getClientBookingByIdInAgency().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var booking = response.data;
                        booking.booking_from = new Date(booking.booking_from.split('.000Z')[0]);
                        booking.booking_to = new Date(booking.booking_to.split('.000Z')[0]);
                        var tmpTime;
                        if(booking.working_from){
                            tmpTime = CommonService.convertTo24Format(booking.working_from);
                            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                            $scope.minTime = $scope.working_from_full1;
                        }
                        if(booking.working_to){
                            tmpTime = CommonService.convertTo24Format(booking.working_to);
                            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                        }
                        
                        $scope.booking = booking;
                        $scope.getPlace(booking.lat,booking.lng,booking.address);
                    }
                })
            }
        }

        $scope.editClientBookingModal = function(data) {
        data.client_id = $state.params.id;
          $uibModal.open({
              templateUrl: 'agency/modules/client/views/editClientBookingModal.html',
              size: 'lg',
              controller: function($scope,$rootScope, $uibModalInstance){
                $scope.closeuib = function() {
                    $uibModalInstance.close('a');
                }
                 /** Variables is used to initialize the working hours on document ready */
                var currentDate = new Date();
                $scope.booking = {};
                $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
                $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
                $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                
                setTimeout(function(){
                    angular.element(document.querySelector('#working_from_id')).trigger('change');
                    angular.element(document.querySelector('#working_to_id')).trigger('change');
                },1000);
                /* End */

                $scope.fromDateChanged = function() {
                    var minutesAdded = 30;
                    $scope.working_to_full = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                    $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                    $scope.minTime = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                    setTimeout(function(){
                        angular.element(document.querySelector('#working_from_id')).trigger('change');
                        angular.element(document.querySelector('#working_to_id')).trigger('change');
                    },1000);

                }
                ClientService.getClientBookingByIdInAgency().get(data,function(response, err){
                    if(response.status == 1){
                        var currentDate = new Date();   
                        var booking = response.data;
                        booking.booking_from = new Date(booking.booking_from.split('.000Z')[0]);
                        booking.booking_to = new Date(booking.booking_to.split('.000Z')[0]);
                        var tmpTime = CommonService.convertTo24Format(booking.working_from);
                        $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                        tmpTime = CommonService.convertTo24Format(booking.working_to);
                        $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                        
                        booking.client_id = booking.client_id._id;
                        booking.interpreter_id = booking.interpreter_id._id;
                        booking.language_id = booking.language_id._id; 
                        $scope.booking = booking; 
                        $scope.getPlace(booking.lat,booking.lng,booking.address);
                    }else{
                        $scope.booking = {};
                    }
                })
                $scope.getAgencyInterpreters = function(){
                    ClientService.getAgencyInterpreters().get({},function(response, err){
                        if(response.status == 1){
                            $scope.agencyInterpreters = response.data;
                        }else{
                            $scope.agencyInterpreters = {};
                        }
                    })
                }

                $scope.getAgencyClients = function(){
                    ClientService.getAgencyClients().get({},function(response, err){
                        if(response.status == 1){
                            $scope.agencyClients = response.data;
                        }else{
                            $scope.agencyClients = {};
                        }
                    })
                }
                $scope.updateBookingInModal = function(form) {
                    $scope.booking.lat = $scope.lat;
                    $scope.booking.lng = $scope.lng;
                    ClientService.updateBooking().save($scope.booking, function(response, err) {
                        var errorMessage = '';
                        $scope.disabled = false;
                        $scope.loader = false;
                        if (response.status == 1) {
                            logger.logSuccess(response.message);
                            $scope.closeuib();
                            // $state.reload(); 
                            $location.path('/listClient');
                        } else {
                            logger.logError(response.message);

                        }
                    });

                }
                $scope.dateModel = {};
                $scope.today = function() {
                    $scope.dt = new Date();
                };
                $scope.dateformat = "dd/MM/yyyy";
                $scope.today();
                $scope.showcalendar = function($event) {
                    $scope.dateModel.showdp = true;
                };
                $scope.showcalendar1 = function($event) {
                    $scope.dateModel.showdp1 = true;
                };
                $scope.dateModel.showdp = false;
                $scope.dateModel.showdp1 = false;
                $scope.dtmax = new Date(); 
                var infowindow,marker,infowindowContent,autocomplete,map;
                $scope.initMap = function () {
                    map = new google.maps.Map(document.getElementById('map'), {
                      center: {lat: 41.310726, lng: -72.929916},
                      zoom: 15,
                    });

                    var input = document.getElementById('pac-input');
                    autocomplete = new google.maps.places.Autocomplete(input);
                    autocomplete.bindTo('bounds', map);
                    infowindow = new google.maps.InfoWindow();
                    infowindowContent = document.getElementById('infowindow-content');
                    infowindow.setContent(infowindowContent);
                    marker = new google.maps.Marker({
                      map: map
                    });

                    setTimeout(function() {
                       google.maps.event.trigger(map, 'resize');
                    }, 1000);

                    autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
                    function selectFirstAddress (input) {
                        google.maps.event.trigger(input, 'keydown', {keyCode:40});
                        google.maps.event.trigger(input, 'keydown', {keyCode:13});
                    }
                    angular.element(document).on('focusout', '#pac-input', function() {
                        selectFirstAddress(this);
                    });
                     
                  }

                $scope.fetchAutocomplete = function(){
                  infowindow.close();
                  marker.setVisible(false);
                  var place = autocomplete.getPlace();
                  if (!place.geometry) {
                    // User entered the name of a Place that was not suggested and
                    // pressed the Enter key, or the Place Details request failed.
                    window.alert("No details available for input: '" + place.name + "'");
                    return;
                  }
                  var lat = place.geometry.location.lat();
                  var lng = place.geometry.location.lng();
                  var address = place.formatted_address;
                  $scope.lat = lat;
                  $scope.lng = lng;  
                  // If the place has a geometry, then present it on a map.
                  if (place.geometry.viewport) {
                    map.fitBounds(place.geometry.viewport);
                  } else {
                    map.setCenter(place.geometry.location);
                    map.setZoom(15);  // Why 17? Because it looks good.
                  }
                  marker.setPosition(place.geometry.location);
                  marker.setVisible(true);

                  infowindowContent.children['place-icon'].src = place.icon;
                  infowindowContent.children['place-name'].textContent = place.name;

                  infowindowContent.children['place-address'].textContent = address;
                  infowindow.open(map, marker);

                 
                  
                }
                $scope.getPlace = function(lat,lng,address) {
                  var latlng = new google.maps.LatLng(lat, lng);
                  var geocoder = new google.maps.Geocoder();
                  geocoder.geocode({'latLng': latlng}, function(results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                      if (results[1]) { 
                        marker = new google.maps.Marker({
                            position: latlng,
                            map: map
                        });

                        map.setCenter(marker.getPosition());
                        map.setZoom(15); 
                        $scope.lat = lat;
                        $scope.lng = lng;
                        infowindowContent.children['place-address'].textContent = address;
                        marker.setIcon(null);
                        infowindow.open(map, marker);
                      }
                      else {
                        //handle error status accordingly
                      }
                    }
                  })
                }
                $scope.getAllLanguagesInBookingModal = function(){
                    ClientService.getAllLanguagesInBooking().get({},function(response, err){
                        if(response.status == 1){
                            $scope.agencyLanguages = response.data;
                        }else{
                            $scope.agencyLanguages = {};
                        }
                    })
                }
              }
          });
      };
                
    }

]);
