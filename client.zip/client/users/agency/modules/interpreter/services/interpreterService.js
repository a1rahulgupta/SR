"use strict"

angular.module("Interpreter")

.factory('InterpreterService', ['$http', '$resource', function($http, $resource) {
 
    var listAgencyInterpreters = function() {
        return $resource(webservices.listAgencyInterpreters, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteInterpreter = function(id) {
        return $resource(webservices.deleteInterpreter, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }


    var addInterpreter = function(formData) {
        return $resource(webservices.addInterpreter, null, {
            save: {
                method: 'POST',
                transformRequest: angular.identity,
                headers: { 'Content-Type': undefined }
            }
        });
    }

    var getInterpreterById = function(id) {
        return $resource(webservices.getInterpreterById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var updateInterpreter = function() {
        return $resource(webservices.updateInterpreter, null, {
            save: {
                method: 'POST',
                transformRequest: angular.identity,
                headers: { 'Content-Type': undefined }
            }
        });
    }

    var changeInterpreterStatus = function() {
        return $resource(webservices.changeInterpreterStatus, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var bulkUploadInterpreter = function(formData) {
        return $resource(webservices.bulkUploadInterpreter, null, {
            save: {
                method: 'POST',
                headers: { 'Content-Type': undefined }
            }
        });
    }

    var getAllLanguagesInInterpreter = function() {
        return $resource(webservices.getAllLanguagesInInterpreter, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getAllCountriesInInterpreterInAgency = function() {
        return $resource(webservices.getAllCountriesInInterpreterInAgency, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getAllServicesInInterpreter = function() {
        return $resource(webservices.getAllServicesInInterpreter, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getAllLanguagesInInterpreter = function() {
        return $resource(webservices.getAllLanguagesInInterpreter, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getInterpreterViewById = function(id) {
        return $resource(webservices.getInterpreterViewById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getInterpreterSchedulingDetailsInAgency = function() {
            return $resource(webservices.getInterpreterSchedulingDetailsInAgency, null, {
                post: {
                    method: 'POST'
                }
            });
        }

    var getBookingDetailForInterpreterCalendarInAgency = function() {
        return $resource(webservices.getBookingDetailForInterpreterCalendarInAgency, null, {
            get: {
                method: 'POST'
            }
        });
    }

    var addInterpreterLeaveInAgency = function() {
            return $resource(webservices.addInterpreterLeaveInAgency, null, {
                post: {
                    method: 'POST'
                }
            });
        }

    var updateInterpreterLeaveInAgency = function() {
        return $resource(webservices.updateInterpreterLeaveInAgency, null, {
            post: {
                method: 'POST'
            }
        });
    }

    var getInterpreterBookingViewByIdInAgency = function() {
        return $resource(webservices.getInterpreterBookingViewByIdInAgency, null, {
            get: {
                method: 'POST'
            }
        });
    }

    var listBookingOfInterpreterInAgency = function() {
        return $resource(webservices.listBookingOfInterpreterInAgency, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getInterpreterBookingByIdInAgency = function() {
        return $resource(webservices.getInterpreterBookingByIdInAgency, null, {
            get: {
                method: 'POST'
            }
        });
    }

    var deleteBookingOfInterpreterInAgency = function(id) {
        return $resource(webservices.deleteBookingOfInterpreterInAgency, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var getAllLanguagesInBooking = function() {
        return $resource(webservices.getAllLanguagesInBooking, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getAgencyInterpreters = function() {
        return $resource(webservices.getAgencyInterpreters, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getAgencyClients = function() {
        return $resource(webservices.getAgencyClients, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var updateBooking = function() {
        return $resource(webservices.updateBooking, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var activateInterpreterByAgency = function() {
        return $resource(webservices.activateInterpreterByAgency, null, {
            get: {
                method: 'POST'
            }
        });
    }

    return {
        listAgencyInterpreters: listAgencyInterpreters,
        deleteInterpreter: deleteInterpreter,
        addInterpreter: addInterpreter,
        getInterpreterById: getInterpreterById,
        updateInterpreter: updateInterpreter,
        changeInterpreterStatus: changeInterpreterStatus,
        bulkUploadInterpreter: bulkUploadInterpreter,
        getAllLanguagesInInterpreter: getAllLanguagesInInterpreter,
        getAllCountriesInInterpreterInAgency: getAllCountriesInInterpreterInAgency,
        getAllServicesInInterpreter: getAllServicesInInterpreter,
        getAllLanguagesInInterpreter: getAllLanguagesInInterpreter,
        getInterpreterViewById: getInterpreterViewById,
        getInterpreterSchedulingDetailsInAgency: getInterpreterSchedulingDetailsInAgency,
        getBookingDetailForInterpreterCalendarInAgency: getBookingDetailForInterpreterCalendarInAgency,
        addInterpreterLeaveInAgency: addInterpreterLeaveInAgency,
        updateInterpreterLeaveInAgency: updateInterpreterLeaveInAgency,
        getInterpreterBookingViewByIdInAgency: getInterpreterBookingViewByIdInAgency,
        listBookingOfInterpreterInAgency: listBookingOfInterpreterInAgency,
        getInterpreterBookingByIdInAgency: getInterpreterBookingByIdInAgency,
        deleteBookingOfInterpreterInAgency: deleteBookingOfInterpreterInAgency,
        getAllLanguagesInBooking: getAllLanguagesInBooking,
        getAgencyInterpreters: getAgencyInterpreters,
        getAgencyClients: getAgencyClients,
        updateBooking: updateBooking,
        activateInterpreterByAgency: activateInterpreterByAgency

    }

}]);
