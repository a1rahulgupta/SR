"use strict";

angular.module("Interpreter")
interpreterApp.controller("interpreterController", ['$scope', '$rootScope', '$localStorage', '$routeParams', '$route', '$location', '$state', '$stateParams', '$http', '$uibModal', 'logger', 'InterpreterService', 'ngTableParams', 'ngTableParamsService', 'CommonService','blockUIConfig',
    function($scope, $rootScope, $localStorage, $routeParams, $route, $location, $state, $stateParams, $http, $uibModal, logger, InterpreterService, ngTableParams, ngTableParamsService, CommonService,blockUIConfig) {

        
        /**
        * Variable is used for active class on leftbar
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $rootScope.menuInterpreter = ['agency_listInterpreter', 'agency_addInterpreter', 'agency_viewInterpreter', 'agency_editInterpreter'];

        /**
        * Function is used block the view while fetching data
        * Created by ramiz
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.noBlock = function() {
            blockUIConfig.requestFilter = function(config) {
                return false;
            }
        };

        /**
        * Variable is used for update interpreter
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/ 
        //for update 
        $scope.interpreter={};
        $scope.interpreter.certificate = false;
        $scope.interpreter.court_certified = false;
        $scope.interpreter.court_screened = false;
        $scope.interpreter.gender='Male';
        $scope.interpreter.working_status = 'full time';
        $scope.interpreter.working_days = {
            monday: true,
            tuesday: true,
            wednesday: true,
            thursday: true,
            friday: true,
            saturday: false,
            sunday: false
        }
        if ($state.params.id) {
            $scope.isUpdate = true;
        } else {
            $scope.isUpdate = false;
        };
        
        /**
        * Function and variable is used for image format
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.isCropVisible=false;
        $scope.myImage='';
        $scope.myCroppedImage='';
        $scope.isImageSelected=false;
        var handleFileSelect=function(evt) {
            $scope.isImageSelected=false;
            $scope.isCropVisible=true;
            var file=evt.currentTarget.files[0];
            var reader = new FileReader();
            reader.onload = function (evt) {
                $scope.$apply(function($scope){
                    $scope.myImage=evt.target.result;
                });
            };
            reader.readAsDataURL(file);
        };
        angular.element(document.querySelector('#fileInput')).on('change',handleFileSelect);
        $scope.openFileBrowse = function(fileInputSelector) {
            angular.element(document.querySelector(fileInputSelector)).trigger('click');
        };
      
        var formDataFileUpload = '';
        $scope.imageBase64 = '';
        angular.element(document).ready(function() {
            setTimeout(function() {
                if(document.getElementById('fileInput')!=null){
                    document.getElementById('fileInput').addEventListener('change', function(evt) {
                        var files = evt.target.files;
                        var file = files[0];
                        if (files && file) {
                            var splitFileName = file.name.split('.');
                            var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                            if (ext == 'jpg' || ext == 'jpeg' || ext == 'png') {
                                if (file.size > 6291456) {
                                    logger.log('File size cannot exceed limit of 6 mb');
                                    document.getElementById("fileInput").value = "";
                                } else {
                                    formDataFileUpload = file;
                                    // formDataFileUpload.append('file', file);
                                    var reader = new FileReader();
                                    reader.onload = function(readerEvt) {
                                        $scope.imageBase64 = btoa(readerEvt.target.result);
                                        $scope.$apply();
                                        document.querySelector('#imgTag').src = 'data:image/' + ext + ';base64,' + $scope.imageBase64;
                                    };
                                    reader.readAsBinaryString(file);
                                }
                            } else {
                                document.getElementById("fileInput").value = "";
                                bootbox.alert('Invalid image format');
                            }
                        }
                    });
                }
            }, 500);
        });

        /**
        * variable and function is used get all languages 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.getAllLanguagesInInterpreter = function(){
            InterpreterService.getAllLanguagesInInterpreter().get({},function(response, err){
                if(response.status == 1){
                    $scope.interpreterLanguages = response.data;
                }else{
                    $scope.interpreterLanguages = {};
                }
            })
        }

        /**
        * variable and function is used for multiple language select 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.languages=[{}];
        $scope.addMoreLanguage =function(){
            $scope.languages.push({isRemovable:true});
        };

        $scope.removeLanguageAt =function(elementIndex){
            $scope.languages.splice(elementIndex, 1);
            if($scope.interpreter.languages!=undefined && $scope.interpreter.languages[elementIndex]!=undefined){
                $scope.interpreter.languages.splice(elementIndex, 1);
            }
        };

        /**
        * Variable is used for service list
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.localLang = {
            selectAll       : "Tick all",
            selectNone      : "Tick none",
            reset           : "Undo all",
            search          : "Type here to search...",
            nothingSelected : "Nothing is selected"         //default-label is deprecated and replaced with this.
        };

        /**
        * Function is used to get all service list
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.getAllServicesInInterpreter = function(){
            InterpreterService.getAllServicesInInterpreter().get({},function(response, err){
                if(response.status == 1){
                    $scope.serviceList = response.data;
                }else{
                    $scope.serviceList = {};
                }
            })
        }
        /**
        * Function is used to list interpreters of an agency
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/

        $rootScope.listAgencyInterpreters = function() {
            ngTableParamsService.set('', '', '', '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    // send an ajax request to your server. in my case MyResource is a $resource.
                    ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.interpreterList = [];
                    InterpreterService.listAgencyInterpreters().save($scope.paramUrl, function(response, err) {
                        // console.log("listAgencyInterpreters", response);
                        if (response.status == 1) {
                            // blockUI.stop();
                            $scope.interpreterList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            });
        };

         /**
        * Function is used to list interpreters of an agency by searching
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.listAgencyInterpretersSearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            console.log("searchtextfield", searchTextField);
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.interpreterList = [];
                    InterpreterService.listAgencyInterpreters().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.interpreterList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        /**
        * Function is used to add interpreter of an agency
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.addInterpreter = function() {
            if ($scope.form.$valid) {
                $scope.loader = true;
                $scope.disabled = true;

                if($scope.isImageSelected==true){
                    $scope.interpreter.imageFile = $scope.myCroppedImage;
                }
                var address = $scope.interpreter.address1+' '+$scope.interpreter.city+' '+ $scope.interpreter.state+' '+$scope.interpreter.zip;
                // Initialize the Geocoder
                var geocoder = new google.maps.Geocoder();
                if (geocoder) {
                    geocoder.geocode({
                        'address': address
                    }, function (results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            $scope.interpreter.lat = results[0].geometry.location.lat();
                            $scope.interpreter.lng = results[0].geometry.location.lng();
                            var formData = new FormData();
                            formData.append('interpreter',angular.toJson($scope.interpreter));
                            if($scope.interpreter.certificates){
                                if(typeof $scope.interpreter.certificates.court_certified == 'object'){
                                    formData.append('court_certified',$scope.interpreter.certificates.court_certified);
                                }
                                if(typeof $scope.interpreter.certificates.court_screened == 'object'){
                                    formData.append('court_screened',$scope.interpreter.certificates.court_screened);    
                                }
                            }
                            InterpreterService.addInterpreter().save(formData, function(response) {
                                var errorMessage = '';
                                $scope.disabled = false;
                                $scope.loader = false;
                                if (response.status == 1) {
                                    logger.logSuccess(response.message); 
                                    $location.path('listInterpreter');
                                } else {
                                    logger.logError(response.message);
                                }

                            });
                        }else {
                            logger.logError('Please enter valid address this address does not find latitude and longitude of interpreter');
                            return false;
                        }
                    });
                }else{
                    logger.logError('Oops something is wrong! Please try agin.');
                }
            }
        };
        
        /**
        * Function is used to get interpreter of an agency by id
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.getInterpreterById = function(){
            /* Variables is used to initialize the working hours on document ready */
            var currentDate = new Date();
            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),0,0,0);
            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
            $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
            
            setTimeout(function(){
                angular.element(document.querySelector('#working_from_id')).trigger('change');
                angular.element(document.querySelector('#working_to_id')).trigger('change');
            },1000); 
            /* End */
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            if($stateParams.id){
                InterpreterService.getInterpreterById().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var interpreter = response.data;
                        console.log("interpreter",interpreter);
                        if(interpreter.working_from !=undefined && interpreter.working_to !=undefined){
                            var tmpTime,tmpTime1;
                            tmpTime = CommonService.convertTo24Format(interpreter.working_from);
                            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                            $scope.minTime = $scope.working_from_full1;
                            tmpTime1 = CommonService.convertTo24Format(interpreter.working_to);
                            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime1.hour,tmpTime1.minute,0);
                        }

                        //Copy services array due to multilple languages status changed
                        $scope.languageArray = angular.copy(interpreter.languages); 
                        //End

                        if(interpreter.languages!=undefined && interpreter.languages.length>0){
                            $scope.languages=[];
                            var tmpObj={};
                            angular.forEach(interpreter.languages, function(language, key) {
                                tmpObj = language;
                                if(key!=0){
                                    tmpObj.isRemovable=true;
                                }else{
                                    tmpObj.isRemovable=false;
                                }
                                $scope.languages.push(tmpObj);
                            });
                            interpreter.languages = interpreter.languages;
                        }else{
                            $scope.languages=[{}];
                        }
                        if(interpreter.working_days!=undefined){
                            interpreter.working_days = interpreter.working_days;
                        }
                        
                        if(interpreter.profile_pic!='' && interpreter.profile_pic!=undefined){
                            $scope.userDefaultImage=interpreter.profile_pic;
                        }

                        if(interpreter.certificates!=undefined && interpreter.certificates.court_certified != undefined){
                            interpreter.court_certified = true;
                        }
                        if(interpreter.certificates!=undefined && interpreter.certificates.court_screened != undefined){
                            interpreter.court_screened = true;
                        }
                        if(interpreter.certificates==undefined){ 
                            interpreter.certificates={};
                        }

                        //Copy services array due to multilple services status changed
                        $scope.serviceArray = angular.copy(interpreter.services); 
                        //End

                        setTimeout(function() {
                            for(var i=0; i<$scope.serviceList.length;i++){
                                for (var j=0;j<interpreter.services.length;j++) {
                                    if($scope.serviceList[i].name == interpreter.services[j].name
                                        && interpreter.services[j].ticked == true){
                                        $scope.serviceList[i].ticked=true;
                                        break;
                                    }
                                }
                            }
                            $scope.$apply();
                        }, 500);
                        $scope.interpreter = interpreter;
                    }else{
                          $scope.interpreter = {};
                    }
                })
            }
        };

        /**
        * Function is used to view interpreter of an agency by id
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Dec-2017
        **/
        $scope.getInterpreterViewById = function(){
            /* Variables is used to initialize the working hours on document ready */
            var currentDate = new Date();
            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
            $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
            
            setTimeout(function(){
                angular.element(document.querySelector('#working_from_id')).trigger('change');
                angular.element(document.querySelector('#working_to_id')).trigger('change');
            },1000); 
            /* End */
            $scope.userDefaultImage = "./../../../../assets/images/default-img.png";
            if($stateParams.id){
                InterpreterService.getInterpreterViewById().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var interpreter = response.data;
                        if(interpreter.working_from !=undefined && interpreter.working_to !=undefined){
                            var tmpTime,tmpTime1;
                            tmpTime = CommonService.convertTo24Format(interpreter.working_from);
                            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                            $scope.minTime = $scope.working_from_full1;
                            tmpTime1 = CommonService.convertTo24Format(interpreter.working_to);
                            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime1.hour,tmpTime1.minute,0);
                        }

                        //Copy services array due to multilple languages status changed
                        $scope.languageArray = angular.copy(interpreter.languages); 
                        //End

                        if(interpreter.languages!=undefined && interpreter.languages.length>0){
                            $scope.languages=[];
                            var tmpObj={};
                            angular.forEach(interpreter.languages, function(language, key) {
                                tmpObj = language;
                                if(key!=0){
                                    tmpObj.isRemovable=true;
                                }else{
                                    tmpObj.isRemovable=false;
                                }
                                $scope.languages.push(tmpObj);
                            });
                            interpreter.languages = interpreter.languages;
                        }else{
                            $scope.languages=[{}];
                        }
                        if(interpreter.working_days!=undefined){
                            interpreter.working_days = interpreter.working_days;
                        }
                        
                        if(interpreter.profile_pic!='' && interpreter.profile_pic!=undefined){
                            $scope.userDefaultImage=interpreter.profile_pic;
                        }

                        if(interpreter.certificates!=undefined && interpreter.certificates.court_certified != undefined){
                            interpreter.court_certified = true;
                        }
                        if(interpreter.certificates!=undefined && interpreter.certificates.court_screened != undefined){
                            interpreter.court_screened = true;
                        }
                        if(interpreter.certificates==undefined){ 
                            interpreter.certificates={};
                        }

                        //Copy services array due to multilple services status changed
                        $scope.serviceArray = angular.copy(interpreter.services); 
                        //End

                        setTimeout(function() {
                            for(var i=0; i<$scope.serviceList.length;i++){
                                for (var j=0;j<interpreter.services.length;j++) {
                                    if($scope.serviceList[i].name == interpreter.services[j].name
                                        && interpreter.services[j].ticked == true){
                                        $scope.serviceList[i].ticked=true;
                                        break;
                                    }
                                }
                            }
                            $scope.interpreter = interpreter;
                        }, 50);
                    }else{
                          $scope.interpreter = {};
                    }
                })
            }
        };

        /**
        * Function is used to update interpreter of an agency
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.updateInterpreter = function() {
            if ($scope.form.$valid) {
                console.log("in update interpreter");
                $scope.loader = true;
                $scope.disabled = true;

                if($scope.isImageSelected==true){
                    $scope.interpreter.imageFile = $scope.myCroppedImage;
                }
                var interpreter = $scope.interpreter;
                var serviceArray = $scope.serviceArray;
                var hasFound = false;
                var tmp = {};
                for(var i=0; i< serviceArray.length; i++){
                    hasFound = false;
                    for(var j=0; j< interpreter.services.length; j++){
                        if(serviceArray[i].service_id == interpreter.services[j]._id){
                            hasFound = true;
                            break;
                        }
                    }
                    if(!hasFound){
                        tmp = serviceArray[i];
                        tmp._id=tmp.service_id;
                        tmp.ticked = false;
                        interpreter.services.push(tmp);
                    }
                }

                var languageArray = $scope.languageArray;
                var hasFound = false;
                var tmp = {};
                for(var i=0; i< languageArray.length; i++){
                    hasFound = false;
                    for(var j=0; j< interpreter.languages.length; j++){
                        if(languageArray[i].language_id == interpreter.languages[j].language_id){
                            hasFound = true;
                            break;
                        }
                    }
                    if(!hasFound){
                        tmp = languageArray[i];
                        tmp.language_id=tmp.language_id;
                        tmp.spoken = tmp.spoken;
                        tmp.written = tmp.written;
                        tmp.is_deleted = true;
                        interpreter.languages.push(tmp);
                    }
                }

                var address = $scope.interpreter.address1+' '+$scope.interpreter.city+' '+ $scope.interpreter.state+' '+$scope.interpreter.zip;
                // Initialize the Geocoder
                var geocoder = new google.maps.Geocoder();
                if (geocoder) {
                    geocoder.geocode({
                        'address': address
                    }, function (results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            $scope.interpreter.lat = results[0].geometry.location.lat();
                            $scope.interpreter.lng = results[0].geometry.location.lng();
                            var formData = new FormData();
                            formData.append('interpreter',angular.toJson(interpreter));
                            if(typeof $scope.interpreter.certificates.court_certified == 'object'){
                                formData.append('court_certified',$scope.interpreter.certificates.court_certified);
                            }
                            if(typeof $scope.interpreter.certificates.court_screened == 'object'){
                                formData.append('court_screened',$scope.interpreter.certificates.court_screened);    
                            }

                            InterpreterService.updateInterpreter().save(formData, function(response, err) {
                                var errorMessage = '';
                                $scope.disabled = false;
                                $scope.loader = false;
                                if (response.status == 1) {
                                    logger.logSuccess(response.message); 
                                    $location.path('/listInterpreter');
                                } else {
                                    logger.logError(response.message);
                                }
                            });
                        }else {
                            logger.logError('Please enter valid address this address does not find latitude and longitude of interpreter');
                            return false;
                        }
                    });
                }else{
                    logger.logError('Oops something is wrong! Please try agin.');
                }
            }
            
        };
         
        /**
        * Function is to delete the interpreter of an agency
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.deleteInterpreter = function(id,$event) {
            $event.stopPropagation();
            bootbox.confirm('Are you sure, you want to delete this interpreter?', function(r) {
                if (r) {
                    InterpreterService.deleteInterpreter().delete({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listAgencyInterpreters();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        /**
        * Function is used to view interpreter of an agency by id
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 27-Sep-2017
        **/
        $scope.viewInterpreter = function(interpreter) {
            $state.go('agency_viewInterpreter', {id:interpreter._id});
        };

        /**
        * Function is used to change the status of the agency interpreter
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 7-Oct-2017
        **/
        $scope.changeInterpreterStatus = function(id,status) {
            var interpreter = {
                id: id,
                status: status
            }
            InterpreterService.changeInterpreterStatus().save(interpreter,function(response, err) {
                if (response.status == 1) {
                    logger.logSuccess(response.message); 
                    $scope.listAgencyInterpreters();
                } else {
                    logger.logError(response.message);
                }
            });
        };

         /**
        * Function is used to view the booking of interpreter
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 13-Oct-2017
        **/
        $scope.viewBooking = function(booking) {
            $state.go('interpreter/viewBooking', {id:booking._id});
        };

        
        $scope.bulkUploadModal = function() {
            $uibModal.open({
                templateUrl: 'agency/modules/interpreter/views/bulkUploadInterpreterModal.html',
                size: "md",
                controller: function($scope, $uibModalInstance) {
                    /**
                    * Function and variable is used for bulk upload 
                    * @access private
                    * @return json
                    * Created by sunny
                    * @smartData Enterprises (I) Ltd
                    * Created Date 24-Oct-2017
                    **/
                    var formDataFileBulkUpload = '';
                    $scope.selectedFileName = 'Browse CSV File';
                    $scope.csvFileBulkUpload = function(){
                        if(document.getElementById('fileBulkInput')!=null){
                            document.getElementById('fileBulkInput').addEventListener('change', function(evt) {
                                var files = evt.target.files;
                                var file = files[0];
                                if (files && file) {
                                    var splitFileName = file.name.split('.');
                                    var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                                    if (ext == 'csv') {
                                        if (file.size > 6291456) {
                                            bootbox.alert('File size cannot exceed limit of 6 mb');
                                            document.getElementById("fileBulkInput").value = "";
                                        } else {
                                            formDataFileBulkUpload = file;
                                            $scope.selectedFileName = file.name;
                                            $scope.$digest();
                                        }
                                    } else {
                                        document.getElementById("fileBulkInput").value = "";
                                        bootbox.alert('Invalid file format, please upload a file with .csv extension');
                                    }
                                }
                            });
                        }
                    }

                    /**
                    * Function is used to close modal 
                    * @access private
                    * @return json
                    * Created by sunny
                    * @smartData Enterprises (I) Ltd
                    * Created Date 24-Oct-2017
                    **/
                    $scope.closeuib = function() {
                        $uibModalInstance.dismiss('cancel');
                    };

                    /**
                    * Function is used to Bulk upload interpreter of an agency
                    * @access private
                    * @return json
                    * Created by sunny
                    * @smartData Enterprises (I) Ltd
                    * Created Date 23-Oct-2017
                    **/
                    $scope.bulkUploadInterpreter = function() {
                        var formData = new FormData();
                        if (formDataFileBulkUpload) {
                            formData.append('file', formDataFileBulkUpload);
                        }
                        InterpreterService.bulkUploadInterpreter().save(formData, function(response) {
                            if (response.status == 1) {
                                logger.logSuccess(response.message); 
                                $scope.closeuib();
                                $state.reload();
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    };
                }
            });
        };

        /**
        * Function is used for timepicker reflection 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Nov-2017
        **/
        $scope.fromDateChanged = function() {
            var minutesAdded = 30;
            $scope.working_to_full = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
            $scope.minTime = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
            setTimeout(function(){
                angular.element(document.querySelector('#working_from_id')).trigger('change');
                angular.element(document.querySelector('#working_to_id')).trigger('change');
            },1000);

        } 

        /**
        * Function is used to validate certificate upload 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Nov-2017
        **/
        $scope.toggleFileSelection = function(){
            if(!$scope.interpreter.court_certified){
                if($scope.interpreter.certificates!=undefined){
                    $scope.interpreter.certificates.court_certified = undefined;    
                }
                
            }
            if(!$scope.interpreter.court_screened){
                if($scope.interpreter.certificates!=undefined){
                    $scope.interpreter.certificates.court_screened = undefined;
                }
                

            }
        };

        /**
        * Function is used to check extension of a file 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 2-Nov-2017
        **/
        $scope.ckhExtension = function(filePath){
            var fileType = filePath;
            if(fileType!=undefined && typeof fileType=='string'){
                var fileName = fileType.split('/').reverse()[0];
                var file_ext = fileName.split('.').reverse()[0];
                var file_ext = file_ext.toLowerCase();
            }else{
                return file_ext='';
            }
            return file_ext;            
        }

        /**
        * Function is used to get all countries 
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 21-Dec-2017
        **/
        $scope.getAllCountriesInInterpreterInAgency = function(){
            InterpreterService.getAllCountriesInInterpreterInAgency().get({},function(response, err){
                if(response.status == 1){
                    $scope.interpreterCountries = response.data;
                    for(var i=0;i<$scope.interpreterCountries.length;i++){
                        if($scope.interpreterCountries[i].country_code == 'us'){
                            $scope.interpreter.country_id = $scope.interpreterCountries[i]._id; 
                        }
                    }
                }else{
                    $scope.interpreterCountries = {};
                }
            })
        }

        $scope.eventSources = [
              function(start, end, timezone, callback){
                if($state.params.id){
                      InterpreterService.getInterpreterSchedulingDetailsInAgency().post({interpreter_id: $state.params.id, startDate: start._d, endDate: end._d}, function(response) {
                      if(response.status == 1){
                        var events = []; 
                        $scope.interpreterSchedulingList = response.data;
                        angular.forEach($scope.interpreterSchedulingList,function(value, index) {
                          if(moment(value.startDate).format('MM-DD-YYYY') == moment().format('MM-DD-YYYY')){
                            if (value.status) {
                              var data = {                                                  
                                  title: 'Working',
                              }
                              $scope.setAvailabilityOnClick(data);
                            }else{
                              var data = {                                                  
                                  title: 'Not Working', 
                              }
                              $scope.setAvailabilityOnClick(data);

                            }
                          }
                          if(value.status == true) {
                            events.push({
                                end: new Date(value.endDate),
                                start: new Date(value.startDate),
                                title: 'Working',
                                color: '#167F45',
                            });
                          } else if (value.leave_status == true){
                              events.push({
                                  end: new Date(value.endDate), 
                                  start: new Date(value.startDate),
                                  id: value.id, 
                                  title: 'On leave',
                                  color: '#F35321',
                              });
                          } else{
                              events.push({
                                  end: new Date(value.endDate), 
                                  start: new Date(value.startDate), 
                                  title: 'Not Working',
                                  color: '#D40C00',
                              });
                          }
                        });
                        callback(events);
                        $scope.calendarLoader = false;
                      }
                    })  
                }
                
              }
        ];
        $rootScope.getInterpreterSchedulingDetailsInAgency = function() {
          var events = [];
          $scope.uiConfig = {
            calendar: {
             
              height: 500,
              editable: true,
              displayEventTime: false,
              ignoreTimezone: false,
              header: {
                  left: 'prev',
                  center: 'title',
                  right: 'next' //'month basicWeek basicDay agendaWeek agendaDay'
              },
              eventClick: function(event, description) { 
                $scope.getBookingDetailForInterpreterCalendarInAgency(event.start._d);
                if(event.title=='Not Working'||event.title=='Working' || event.title=='On leave'){
                  $scope.currentDate = '';
                  // $scope.setAvailabilityOnClick(event);
                }
                else{
                  // $scope.alertEventOnClick(event);
                }
              }
            }
          }
        }

        $scope.currentDate='';
        $scope.switchdesabled =  false;
        $scope.setAvailabilityOnClick = function(data) {
          $scope.eventData = data;
          $scope.switchdesabled =  false;
          if(typeof data['_start'] == "undefined"){
            $scope.currentDate = new Date();
          }else{
            $scope.currentDate = data._start._d;
          }
          $scope.serviceprovider = {
            isAvailable: true
          }
          if(data.title !='Not Working'){             
            if(data.title==='Working'){
              $scope.serviceprovider.isAvailable=true;
            }
            else{
              $scope.serviceprovider.isAvailable=false; 
            }
          }else{
            $scope.serviceprovider.isAvailable=false;
            $scope.switchdesabled =  true;
          }
        }

        $scope.setSchedule = function(formData){
            var data = $scope.eventData;
            console.log("eventData", data);
            InterpreterService.getBookingDetailForInterpreterCalendarInAgency().get({}, function(response) {
              console.log("INSIDE getBookingDetailForInterpreterCalendarInAgency", $scope.scheduleData);
            })
            if(data.title == 'Working'){
                  bootbox.confirm('Are you sure you want to change availablity for date '+moment($scope.currentDate).format('DD-MM-YYYY')+  ' ?', function(r) {
                      if (r) {
                        if(formData.isAvailable){ 
                          $scope.scheduleData = {
                            'status': true,
                            'date': $scope.currentDate,
                            'interpreter_id': $state.params.id
                          };
                        }else{
                          $scope.scheduleData = {
                            'status': false,
                            'date': $scope.currentDate,
                            'interpreter_id': $state.params.id
                          };
                        }
                    var data = $scope.scheduleData;    
                    InterpreterService.addInterpreterLeaveInAgency().save($scope.scheduleData, function(response) {
                        $scope.disabled = false;
                        $scope.loader = false;
                        if (response.status == 1) {
                            logger.logSuccess(response.message);
                            $state.reload();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                  }
               
              })
                } else {
                      bootbox.confirm('Are you sure you want to change availablity for date '+moment($scope.currentDate).format('DD-MM-YYYY')+  ' ?', function(r) {
                          if (r) {
                            if(formData.isAvailable){ 
                              $scope.scheduleData = {
                                'status': true,
                                'date': $scope.currentDate
                              };
                            }else{
                              $scope.scheduleData = {
                                'status': false,
                                'date': $scope.currentDate
                              };
                            }

                            // alert("Hello");
                        InterpreterService.updateInterpreterLeaveInAgency().save({id: data.id}, function(response) {
                            // $scope.disabled = false;
                            // $scope.loader = false;

                            if (response.status == 1) {
                                logger.logSuccess(response.message);
                                $state.reload();
                            } else {
                                logger.logError(response.message);
                                // $scope.cancelAction();
                            }
                        });
                      }
                   
                  })
                }
            
        }

        $scope.getBookingDetailForInterpreterCalendarInAgency = function(startDate){
          if($state.params.id) {
                if(!startDate){
                startDate = new Date();
                startDate = moment(startDate).format();
                }
              $scope.interpreterBookingDetails = [];
              InterpreterService.getBookingDetailForInterpreterCalendarInAgency().get({interpreter_id:$state.params.id ,startDate: startDate }, function(response) {
                  if (response.status == 1) {
                      $scope.interpreterBookingList = response.data;
                      $scope.interpreterBookingList.forEach(function(value, index) {
                        $scope.interpreterBookingDetails.push(value)
                      });
                  }
              })
          }
          
        }

        $scope.viewInterpreterBookingModal = function(data) {
          $uibModal.open({
              templateUrl: 'agency/modules/interpreter/views/viewInterpreterBookingModal.html',
              size: 'lg',
              controller: function($scope,$rootScope, $uibModalInstance){
                $scope.closeuib = function() {
                    $uibModalInstance.close('a');
                }

                InterpreterService.getInterpreterBookingViewByIdInAgency().get({id:data, interpreter_id:$state.params.id},function(response, err){
                    if(response.status == 1){
                        var currentDate = new Date();   
                        var booking = response.data;
                        booking.booking_from = new Date(booking.booking_from.split('.000Z')[0]);
                        booking.booking_to = new Date(booking.booking_to.split('.000Z')[0]);
                        var tmpTime = CommonService.convertTo24Format(booking.working_from);
                        $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                        tmpTime = CommonService.convertTo24Format(booking.working_to);
                        $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                        $scope.booking = booking; 
                        $scope.getPlace(booking.lat,booking.lng,booking.address);
                    }else{
                        $scope.booking = {};
                    }
                })

            var infowindow,marker,infowindowContent,autocomplete,map;
            $scope.initMap = function () {
                map = new google.maps.Map(document.getElementById('map'), {
                  center: {lat: 41.310726, lng: -72.929916},
                  zoom: 15,
                });

                var input = document.getElementById('pac-input');
                autocomplete = new google.maps.places.Autocomplete(input);
                autocomplete.bindTo('bounds', map);
                infowindow = new google.maps.InfoWindow();
                infowindowContent = document.getElementById('infowindow-content');
                infowindow.setContent(infowindowContent);
                marker = new google.maps.Marker({
                  map: map
                });

                setTimeout(function() {
                   google.maps.event.trigger(map, 'resize');
                }, 1000);

                autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
                function selectFirstAddress (input) {
                    google.maps.event.trigger(input, 'keydown', {keyCode:40});
                    google.maps.event.trigger(input, 'keydown', {keyCode:13});
                }
                angular.element(document).on('focusout', '#pac-input', function() {
                    selectFirstAddress(this);
                });
                 
              }

              $scope.fetchAutocomplete = function(){
                  infowindow.close();
                  marker.setVisible(false);
                  var place = autocomplete.getPlace();
                  if (!place.geometry) {
                    // User entered the name of a Place that was not suggested and
                    // pressed the Enter key, or the Place Details request failed.
                    window.alert("No details available for input: '" + place.name + "'");
                    return;
                  }
                  var lat = place.geometry.location.lat();
                  var lng = place.geometry.location.lng();
                  var address = place.formatted_address;
                  $scope.lat = lat;
                  $scope.lng = lng;  
                  // If the place has a geometry, then present it on a map.
                  if (place.geometry.viewport) {
                    map.fitBounds(place.geometry.viewport);
                  } else {
                    map.setCenter(place.geometry.location);
                    map.setZoom(15);  // Why 17? Because it looks good.
                  }
                  marker.setPosition(place.geometry.location);
                  marker.setVisible(true);

                  infowindowContent.children['place-icon'].src = place.icon;
                  infowindowContent.children['place-name'].textContent = place.name;

                  infowindowContent.children['place-address'].textContent = address;
                  infowindow.open(map, marker);

                 
                  
              }
              $scope.getPlace = function(lat,lng,address) {
                  var latlng = new google.maps.LatLng(lat, lng);
                  var geocoder = new google.maps.Geocoder();
                  geocoder.geocode({'latLng': latlng}, function(results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                      if (results[1]) { 
                        marker = new google.maps.Marker({
                            position: latlng,
                            map: map
                        });

                        map.setCenter(marker.getPosition());
                        map.setZoom(15); 
                        $scope.lat = lat;
                        $scope.lng = lng;
                        infowindowContent.children['place-address'].textContent = address;
                        marker.setIcon(null);
                        infowindow.open(map, marker);
                      }
                      else {
                        //handle error status accordingly
                      }
                    }
                  })
                }
              }
          });
      };
      
      /**
        * Function is used to list interpreters of an agency by interpreter id
        * @access private
        * @return json
        * Created by ramiz
        * @smartData Enterprises (I) Ltd
        * Created Date 04-Jan-2018
        **/
      $scope.listBookingOfInterpreterInAgency = function() {
        console.log("inside  listBookingOfInterpreterInAgency");
            if($state.params.id){
                    ngTableParamsService.set('', '', '', '');
                    $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                    getData: function($defer, params) {
                        ngTableParamsService.set(params.page(), params.count(), $scope.searchTextField, params.sorting());
                        $scope.paramUrl = params.url();
                        $scope.paramUrl.interpreter_id = $state.params.id;
                        $scope.bookingList = [];
                        InterpreterService.listBookingOfInterpreterInAgency().save($scope.paramUrl, function(response, err) {
                            if (response.status == 1) {
                                $scope.bookingList = response.data;
                                var data = response.data;
                                $scope.totalCount = response.count;
                                params.total(response.count);
                                $defer.resolve(data);
                            } else {
                                logger.logError(response.message);
                            }
                        });
                    }
                }); 
            }
            
        };
        
        /**
        * Function is used to search list interpreters of an agency
        * @access private
        * @return json
        * Created by ramiz
        * @smartData Enterprises (I) Ltd
        * Created Date 04-Jan-2018
        **/
        $scope.listBookingOfInterpreterInAgencyBySearching = function(searchTextField) {
            ngTableParamsService.set('', '', searchTextField, '');
            $scope.tableParams = new ngTableParams(ngTableParamsService.get(), {
                getData: function($defer, params) {
                    ngTableParamsService.set(params.page(), params.count(), searchTextField, params.sorting());
                    $scope.paramUrl = params.url();
                    $scope.paramUrl.interpreter_id = $state.params.id;
                    $scope.bookingList = [];
                    InterpreterService.listBookingOfInterpreterInAgency().save($scope.paramUrl, function(response) {
                        if (response.status == 1) {
                            $scope.bookingList = response.data;
                            var data = response.data;
                            $scope.totalCount = response.count;
                            params.total(response.count);
                            $defer.resolve(data);
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })
        };

        $scope.deleteBookingOfInterpreterInAgency = function(id, $event) {
        console.log("deleteBooking", id);
            $event.stopPropagation();
            bootbox.confirm('Are you sure, you want to delete this booking?', function(r) {
                if (r) {
                    InterpreterService.deleteBookingOfInterpreterInAgency().delete({id:id},function(response, err) {
                        if (response.status == 1) {
                            logger.logSuccess(response.message); 
                            $scope.listBookingOfInterpreterInAgency();
                        } else {
                            logger.logError(response.message);
                        }
                    });
                }
            })

        }

        $scope.getInterpreterBookingByIdInAgency = function(){
                /* Variables is used to initialize the working hours on document ready */
            var currentDate = new Date();
            $scope.booking = {};
            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
            $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
            
            setTimeout(function(){
                angular.element(document.querySelector('#working_from_id')).trigger('change');
                angular.element(document.querySelector('#working_to_id')).trigger('change');
            },1000);                
            /* End */

            if($stateParams.id){
                InterpreterService.getInterpreterBookingByIdInAgency().get({id:$stateParams.id},function(response, err){
                    if(response.status == 1){
                        var booking = response.data;
                        booking.booking_from = new Date(booking.booking_from.split('.000Z')[0]);
                        booking.booking_to = new Date(booking.booking_to.split('.000Z')[0]);
                        var tmpTime;
                        if(booking.working_from){
                            tmpTime = CommonService.convertTo24Format(booking.working_from);
                            $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                            $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                            $scope.minTime = $scope.working_from_full1;
                        }
                        if(booking.working_to){
                            tmpTime = CommonService.convertTo24Format(booking.working_to);
                            $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                        }
                        
                        $scope.booking = booking;
                        $scope.getPlace(booking.lat,booking.lng,booking.address);
                    }
                })
            }
        }

        $scope.editInterpreterBookingModal = function(data) {
            data.interpreter_id = $state.params.id;
          $uibModal.open({
              templateUrl: 'agency/modules/interpreter/views/editInterpreterBookingModal.html',
              size: 'lg',
              controller: function($scope,$rootScope, $uibModalInstance){
                $scope.closeuib = function() {
                    $uibModalInstance.close('a');
                }
                 /** Variables is used to initialize the working hours on document ready */
                var currentDate = new Date();
                $scope.booking = {};
                $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
                $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),11,0,0);
                $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                
                setTimeout(function(){
                    angular.element(document.querySelector('#working_from_id')).trigger('change');
                    angular.element(document.querySelector('#working_to_id')).trigger('change');
                },1000);
                /* End */

                $scope.fromDateChanged = function() {
                    var minutesAdded = 30;
                    $scope.working_to_full = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                    $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                    $scope.minTime = new Date($scope.working_from_full.getTime() + minutesAdded*60000);
                    setTimeout(function(){
                        angular.element(document.querySelector('#working_from_id')).trigger('change');
                        angular.element(document.querySelector('#working_to_id')).trigger('change');
                    },1000);

                }
                InterpreterService.getInterpreterBookingByIdInAgency().get(data,function(response, err){
                    console.log("res", response);
                    if(response.status == 1){
                        var currentDate = new Date();   
                        var booking = response.data;
                        booking.booking_from = new Date(booking.booking_from.split('.000Z')[0]);
                        booking.booking_to = new Date(booking.booking_to.split('.000Z')[0]);
                        var tmpTime = CommonService.convertTo24Format(booking.working_from);
                        $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                        tmpTime = CommonService.convertTo24Format(booking.working_to);
                        $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),tmpTime.hour,tmpTime.minute,0);
                        
                        booking.client_id = booking.client_id._id;
                        booking.interpreter_id = booking.interpreter_id._id;
                        booking.language_id = booking.language_id._id; 
                        $scope.booking = booking; 
                        $scope.getPlace(booking.lat,booking.lng,booking.address);
                    }else{
                        $scope.booking = {};
                    }
                })
                $scope.getAgencyInterpreters = function(){
                    InterpreterService.getAgencyInterpreters().get({},function(response, err){
                        if(response.status == 1){
                            $scope.agencyInterpreters = response.data;
                        }else{
                            $scope.agencyInterpreters = {};
                        }
                    })
                }

                $scope.getAgencyClients = function(){
                    InterpreterService.getAgencyClients().get({},function(response, err){
                        if(response.status == 1){
                            $scope.agencyClients = response.data;
                        }else{
                            $scope.agencyClients = {};
                        }
                    })
                }
                $scope.updateBookingInModal = function(form) {
                    $scope.booking.lat = $scope.lat;
                    $scope.booking.lng = $scope.lng;
                    InterpreterService.updateBooking().save($scope.booking, function(response, err) {
                        var errorMessage = '';
                        $scope.disabled = false;
                        $scope.loader = false;
                        if (response.status == 1) {
                            logger.logSuccess(response.message);
                            $scope.closeuib();
                            // $state.reload(); 
                            $location.path('/listInterpreter');
                        } else {
                            logger.logError(response.message);

                        }
                    });

                }
                $scope.dateModel = {};
                $scope.today = function() {
                    $scope.dt = new Date();
                };
                $scope.dateformat = "dd/MM/yyyy";
                $scope.today();
                $scope.showcalendar = function($event) {
                    $scope.dateModel.showdp = true;
                };
                $scope.showcalendar1 = function($event) {
                    $scope.dateModel.showdp1 = true;
                };
                $scope.dateModel.showdp = false;
                $scope.dateModel.showdp1 = false;
                $scope.dtmax = new Date(); 
                var infowindow,marker,infowindowContent,autocomplete,map;
                $scope.initMap = function () {
                    map = new google.maps.Map(document.getElementById('map'), {
                      center: {lat: 41.310726, lng: -72.929916},
                      zoom: 15,
                    });

                    var input = document.getElementById('pac-input');
                    autocomplete = new google.maps.places.Autocomplete(input);
                    autocomplete.bindTo('bounds', map);
                    infowindow = new google.maps.InfoWindow();
                    infowindowContent = document.getElementById('infowindow-content');
                    infowindow.setContent(infowindowContent);
                    marker = new google.maps.Marker({
                      map: map
                    });

                    setTimeout(function() {
                       google.maps.event.trigger(map, 'resize');
                    }, 1000);

                    autocomplete.addListener('place_changed', $scope.fetchAutocomplete);
                    function selectFirstAddress (input) {
                        google.maps.event.trigger(input, 'keydown', {keyCode:40});
                        google.maps.event.trigger(input, 'keydown', {keyCode:13});
                    }
                    angular.element(document).on('focusout', '#pac-input', function() {
                        selectFirstAddress(this);
                    });
                     
                  }

                $scope.fetchAutocomplete = function(){
                  infowindow.close();
                  marker.setVisible(false);
                  var place = autocomplete.getPlace();
                  if (!place.geometry) {
                    // User entered the name of a Place that was not suggested and
                    // pressed the Enter key, or the Place Details request failed.
                    window.alert("No details available for input: '" + place.name + "'");
                    return;
                  }
                  var lat = place.geometry.location.lat();
                  var lng = place.geometry.location.lng();
                  var address = place.formatted_address;
                  $scope.lat = lat;
                  $scope.lng = lng;  
                  // If the place has a geometry, then present it on a map.
                  if (place.geometry.viewport) {
                    map.fitBounds(place.geometry.viewport);
                  } else {
                    map.setCenter(place.geometry.location);
                    map.setZoom(15);  // Why 17? Because it looks good.
                  }
                  marker.setPosition(place.geometry.location);
                  marker.setVisible(true);

                  infowindowContent.children['place-icon'].src = place.icon;
                  infowindowContent.children['place-name'].textContent = place.name;

                  infowindowContent.children['place-address'].textContent = address;
                  infowindow.open(map, marker);

                 
                  
                }
                $scope.getPlace = function(lat,lng,address) {
                  var latlng = new google.maps.LatLng(lat, lng);
                  var geocoder = new google.maps.Geocoder();
                  geocoder.geocode({'latLng': latlng}, function(results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                      if (results[1]) { 
                        marker = new google.maps.Marker({
                            position: latlng,
                            map: map
                        });

                        map.setCenter(marker.getPosition());
                        map.setZoom(15); 
                        $scope.lat = lat;
                        $scope.lng = lng;
                        infowindowContent.children['place-address'].textContent = address;
                        marker.setIcon(null);
                        infowindow.open(map, marker);
                      }
                      else {
                        //handle error status accordingly
                      }
                    }
                  })
                }
                $scope.getAllLanguagesInBookingModal = function(){
                    InterpreterService.getAllLanguagesInBooking().get({},function(response, err){
                        if(response.status == 1){
                            $scope.agencyLanguages = response.data;
                        }else{
                            $scope.agencyLanguages = {};
                        }
                    })
                }
              }
          });
        };

        /**
        * Uib Modal is used to activate interpreter by agency
        * @access private
        * @return json
        * Created by sunny
        * @smartData Enterprises (I) Ltd
        * Created Date 12-Feb-2018
        **/
        $scope.activateInterpreterModal = function(interpreterData){
            if(interpreterData.userInfo.activation_key != '' || interpreterData.userInfo.activation_key != null || interpreterData.userInfo.activation_key != undefined){
                $uibModal.open({
                    templateUrl: 'agency/modules/interpreter/views/activateInterpreterModal.html',
                    size: 'md',
                    controller: function($scope,$rootScope, $uibModalInstance){
                    
                        $scope.closeuib = function() {
                            $uibModalInstance.close();
                        }
                        
                        var interpreter = {};
                        interpreter._id = interpreterData._id;
                        interpreter.user_id =  interpreterData.userInfo._id;
                        interpreter.email =  interpreterData.userInfo.email;
                        $scope.interpreter = interpreter;

                        $scope.activateInterpreterByAgency = function(form){
                            if(form.$valid){
                                $scope.loader = true;
                                $scope.disabled = true;
                                if($scope.interpreter.confirm_password == true){    
                                    InterpreterService.activateInterpreterByAgency().save($scope.interpreter,function(response, err) {
                                        if (response.status == 1) {
                                            logger.logSuccess(response.message);
                                            $uibModalInstance.close();
                                            $state.reload();
                                        } else {
                                            logger.log(response.message);
                                        }
                                    });          
                                }else{
                                    $scope.disabled = false;
                                    logger.log("Confirm password does not match with password!");
                                }
                            }
                        }
                    }
                });
            }else{
                logger.logError("Oops something is wrong! Please try again.");
            }
        }

        $scope.changeTimeOnStatusChanged = function(status){
            if(status == 'full time'){
                var currentDate = new Date();
                $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),0,0,0);
                $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                
                setTimeout(function(){
                    angular.element(document.querySelector('#working_from_id')).trigger('change');
                    angular.element(document.querySelector('#working_to_id')).trigger('change');
                },1000); 
            }else{
                var currentDate = new Date();
                $scope.working_from_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),9,0,0);
                $scope.working_from_full1 = new Date($scope.working_from_full.getTime() + 30*60000);
                $scope.working_to_full = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),15,0,0);
                $scope.maxTime = new Date(currentDate.getYear(),currentDate.getMonth(),currentDate.getDay(),23,30,0);
                
                setTimeout(function(){
                    angular.element(document.querySelector('#working_from_id')).trigger('change');
                    angular.element(document.querySelector('#working_to_id')).trigger('change');
                },1000); 
            }
        }



    }

]);
