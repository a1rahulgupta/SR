"use strict"

angular.module("Scheduler")

.factory('SchedulerService', ['$http', '$resource', function($http, $resource) {

    var updateProfile = function() {
        return $resource(webservices.updateProfile, null, {
            save: {
                method: 'POST'
            }
        });
    }
    
    var getAgencyBookingList = function() {
        return $resource(webservices.getAgencyBookingList, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAgencyInterpreters = function() {
        return $resource(webservices.getAgencyInterpreters, null, {
            save: {
                method: 'GET'
            }
        });
    }
           
    var getAgencyClients = function() {
        return $resource(webservices.getAgencyClients, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var addBooking = function() {
        return $resource(webservices.addBooking, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getBookingById = function(id) {
        return $resource(webservices.getBookingById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getBookingViewById = function(id) {
        return $resource(webservices.getBookingViewById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var deleteBooking = function(id) {
        return $resource(webservices.deleteBooking, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var updateBooking = function() {
        return $resource(webservices.updateBooking, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getBookingList = function() {
        return $resource(webservices.getBookingList, null, {
            save: {
                method: 'GET'
            }
        });
    }
    var searchBookingByDate = function() {
        return $resource(webservices.searchBookingByDate, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getReviewByBookingId = function(id) {
        return $resource(webservices.getReviewByBookingId, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getCheckInOutDetailByBookingId = function(id) {
        return $resource(webservices.getCheckInOutDetailByBookingId, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var checkInOutApproval = function() {
        return $resource(webservices.checkInOutApproval, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAllLanguagesInBooking = function() {
        return $resource(webservices.getAllLanguagesInBooking, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getInterpreterNamesByLanguageId = function(id) {
        return $resource(webservices.getInterpreterNamesByLanguageId, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    //start
    var getEventName = function() {
        return $resource(webservices.getEventName, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var addSchedule = function() {
        return $resource(webservices.addSchedule, null, {
            save: {
                method: 'POST'
            }
        });
    }

     var getAllBookings = function() {
        return $resource(webservices.getAllBookings, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var updateCurrentOccurenceEvent = function() {
        return $resource(webservices.updateCurrentOccurenceEvent, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteAllEvent = function() {
        return $resource(webservices.deleteAllEvent, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteCurrentEvent = function() {
        return $resource(webservices.deleteCurrentEvent, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var deleteEvent = function(id) {
        return $resource(webservices.deleteEvent, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var deleteCurrentAndFollowingEvents = function() {
        return $resource(webservices.deleteCurrentAndFollowingEvents, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getClientListByAgency = function() {
        return $resource(webservices.getClientListByAgency, null, {
            save: {
                method: 'GET'
            }
        });
    }

    var getAgencyEventList = function() {
        return $resource(webservices.getAgencyEventList, null, {
            save: {
                method: 'POST'
            }
        });
    }

     var searchBookingByDateScheduler = function() {
        return $resource(webservices.searchBookingByDateScheduler, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getEventViewById = function(id) {
        return $resource(webservices.getEventViewById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var getEventById = function(id) {
        return $resource(webservices.getEventById, null, {
            save: {
                method: 'GET',
                id: '@id'
            }
        });
    }

    var deleteEvent = function(id) {
        return $resource(webservices.deleteEvent, null, {
            save: {
                method: 'DELETE',
                id: '@id'
            }
        });
    }

    var getEventInterpretersLocation = function() {
        return $resource(webservices.getEventInterpretersLocation, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var sendEventRequestToInterpreters = function() {
        return $resource(webservices.sendEventRequestToInterpreters, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getTodaysAgencyBookingList = function() {
        return $resource(webservices.getTodaysAgencyBookingList, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAgencyCompletedBookings = function() {
        return $resource(webservices.getAgencyCompletedBookings, null, {
            save: {
                method: 'POST'
            }
        });
    }

    var getAgencyPendingBookings = function() {
        return $resource(webservices.getAgencyPendingBookings, null, {
            save: {
                method: 'POST'
            }
        });
    }

    return {
        updateProfile: updateProfile,
        getBookingList: getBookingList,
        getAgencyInterpreters: getAgencyInterpreters,
        getAgencyClients: getAgencyClients,
        addBooking: addBooking,
        getBookingById: getBookingById,
        deleteBooking:deleteBooking,
        updateBooking: updateBooking,
        getAgencyBookingList: getAgencyBookingList,
        getBookingViewById: getBookingViewById,
        searchBookingByDate: searchBookingByDate,
        getReviewByBookingId: getReviewByBookingId,
        getCheckInOutDetailByBookingId:getCheckInOutDetailByBookingId,
        checkInOutApproval: checkInOutApproval,
        getAllLanguagesInBooking: getAllLanguagesInBooking,
        getInterpreterNamesByLanguageId: getInterpreterNamesByLanguageId,

        getEventName: getEventName,
        addSchedule: addSchedule,
        getAllBookings: getAllBookings,
        updateCurrentOccurenceEvent: updateCurrentOccurenceEvent,
        deleteAllEvent: deleteAllEvent,
        deleteCurrentEvent: deleteCurrentEvent,
        deleteEvent: deleteEvent,
        deleteCurrentAndFollowingEvents: deleteCurrentAndFollowingEvents,
        getClientListByAgency: getClientListByAgency,
        getAgencyEventList: getAgencyEventList,
        searchBookingByDateScheduler: searchBookingByDateScheduler,
        getEventViewById: getEventViewById,
        getEventById: getEventById,
        deleteEvent: deleteEvent,
        getEventInterpretersLocation:  getEventInterpretersLocation,
        sendEventRequestToInterpreters: sendEventRequestToInterpreters,
        getTodaysAgencyBookingList: getTodaysAgencyBookingList,
        getAgencyCompletedBookings: getAgencyCompletedBookings,
        getAgencyPendingBookings: getAgencyPendingBookings
    }

}]);
