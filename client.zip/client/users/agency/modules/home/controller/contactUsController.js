"use strict";

angular.module("Home")

interpreterApp.controller("contactUsCtrl", ['$scope', '$rootScope', '$localStorage',
    '$location', 'logger', 'CommonService', 'homeService', 'modalData','$uibModal', '$uibModalInstance',
    function($scope, $rootScope, $localStorage, $location, logger, CommonService, 
        homeService, modalData, $uibModal, $uibModalInstance) {

        $scope.contact = {};

        $scope.closeuib = function() {
            $uibModalInstance.close();
        }

        /**
         * Function is use add Contact Us
         * @access private
         * @return json
         * Created by Ashwini
         * @smartData Enterprises (I) Ltd
         * Created Date 21-Aug-2017
         */
        $scope.addContactUs = function(form) {

            if (form.$valid) {
                $scope.loader = true;
                $scope.disabled = true;                
                $scope.contact.contactType = modalData.name;

                homeService.addContactUs().save($scope.contact, function(response, err) {

                    $scope.disabled = false;
                    $scope.loader = false;
                    if (response.code == statusCode.ok) {
                        logger.logSuccess(response.message);
                        $scope.closeuib();                        
                    } else {
                        logger.logError(response.message);
                        $scope.closeuib();
                    }
                });
            }
        };
        
    }
]);
