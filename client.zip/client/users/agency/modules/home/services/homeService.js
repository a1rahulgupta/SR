"use strict"

angular.module("Home")

.factory('homeService', ['$http', '$resource', function($http, $resource) {
    
    
    var getMailCategory = function() {    
        return $resource(webservices.getMailCategory, null, {
            get: {
                method: 'GET'
            }
        });
    } 
    var addContactUs = function() {
        return $resource(webservices.addContactUs, null, {
            save: {
                method: 'POST'
            }
        });
    }
    var addMailingList = function() {
        return $resource(webservices.addMailingList, null, {
            save: {
                method: 'POST'
            }
        });
    }


    
    return {
        getMailCategory: getMailCategory,
        addContactUs: addContactUs,
        addMailingList: addMailingList
    }

}]);

