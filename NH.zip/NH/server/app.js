'use strict';
require('dotenv').config();
var SwaggerExpress = require('swagger-express-mw');
var methodOverride = require('method-override');
var express = require('express');
var path = require('path');
var fs = require('fs');
var i18n = require("i18n");
var join = require('path').join;
var bodyParser = require('body-parser');
var config = require('./config/config');
var http = require('http');
var app = express();
var moment = require('moment');
process.env.TZ =  "America/New_York";

// rootRequired function
global.__rootRequire = function(relpath) {
    return require(path.join(__dirname, relpath));
};

global.__rootPath = function(relpath) {
    return path.join(__dirname, relpath);
};

//custom files
require('./config/db');
require('./api/lib/scheduler.js');

var utils = require('./api/lib/util');
var feedbackCtrl = require('./api/controllers/feedback_ctrl');

i18n.configure({
    // setup some locales - other locales default to the first locale
    locales: 'en',
    directory: __dirname + '/api/locales',
    updateFiles: false
});

app.use(function (req, res, next) {
    i18n.init(req, res);
    next();
});
  
// Make admin view availavle at root
app.use(express.static(path.join(__dirname, 'node_modules')));
app.use('/public', express.static(path.join(__dirname, 'public')));
app.use('/assets', express.static(path.join(__dirname, '/public/dist/assets')));
app.use('/', express.static(path.join(__dirname, './public/dist')));
app.use(express.static(path.join(__dirname, '../client/src')));

var SwaggerConfig = {
    appRoot: __dirname // required config
};

SwaggerExpress.create(SwaggerConfig, function (err, swaggerExpress) {
    if (err) {
        throw err;
    }

    // All api requests
    app.use(function (req, res, next) {
        // CORS headers
        res.header("Access-Control-Allow-Origin", "*"); // restrict it to the required domain
        res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
        // Set custom headers for CORS
        res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type, Authorization, Origin, Host, Accept, Origin, Referer, User-Agent');
        res.setHeader('Access-Control-Allow-Credentials', true);
        if (req.method == 'OPTIONS') {
            res.status(200).end();
        } else {
            next();
        }
    });

    //parse application/x-www-form-urlencoded
    app.use(bodyParser.urlencoded({ //The value can be a string or array (when extended is false), or any type (when extended is true).
        limit: '100mb',
        extended: true
    }));

    app.use(bodyParser.json({
        limit: '100mb',
        type: 'application/json'
    }));
    app.use(methodOverride());

    // view engine setup
    app.engine('html', function (path, opt, fn) {
        fs.readFile(path, 'utf-8', function (error, str) {
        if (error) return str;
        return fn(null, str);
        });
    });
    
    app.set('view engine', 'html');

    //Check to call web services where token is not required//
    app.use('/api/v1/*', function (req, res, next) {
        utils.ensureAuthorized(req,res, next);
    })

    //Webhooks from twilio  
    app.post('/api/callback_twilio_sms', function (req, res) {
        feedbackCtrl.twilioSmsResponse(req, res)
    });
    //End

    // enable SwaggerUI
    app.use(swaggerExpress.runner.swaggerTools.swaggerUi());

    // install middleware
    swaggerExpress.register(app);

    app.get('/*', function(req, res, next) {
        res.sendFile(path.join(__dirname, './public/dist/index.html'));
    })

    var port = process.env.PORT || config.port;

    app.use(logErrors);
    app.use(clientErrorHandler);
    app.use(errorHandler);

    function logErrors(err, req, res, next) {
        console.error(err.stack)
        next(err)
    }
    
    function clientErrorHandler(err, req, res, next) {
        if (req.xhr) {
            res.status(500).send({
            error: i18n.__("INTERNAL_ERROR")
            })
        } else {
            next(err)
        }
    }
    
    function errorHandler(err, req, res, next) {
        if (res.headersSent) {
            return next(err)
        }
        res.status(500)
        res.render('error', {
            error: err
        })
    }

    var server = app.listen(port);
    console.log('Server started At ' + config.server_url + " ENV " + process.env.NODE_ENV);
    
    var io = require('socket.io').listen(server);
    require('./api/lib/socket')(io);

    if (swaggerExpress.runner.swagger.paths['/hello']) {
        console.log('try this:\ncurl http://127.0.0.1:' + port);
    }

});