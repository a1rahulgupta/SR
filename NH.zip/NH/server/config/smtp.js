var config = {};

config.development = {
    options: {},
    connectionURL: {
        host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        auth: {
            user: 'nursinghomereview@gmail.com',
            pass: 'Password@nhr01'
        }
    }
};

config.production = {
    options: {},
    connectionURL: {
        host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        auth: {
            user: 'nursinghomereview@gmail.com',
            pass: 'Password@nhr01'
        }
    }
};

config.aws = {
    options: {
        from: 'no-reply@mylanguagelink.com'
    },
    connectionURL: 'smtps://viralcontentsystem@gmail.com:viral@123@smtp.gmail.com',
};

module.exports = config;