'use strict';

/* DB */
var mongoose = require('mongoose');
mongoose.Promise = global.Promise;

require('../api/models/users');
require('../api/models/company');
require('../api/models/facility');
require('../api/models/userCompany');
require('../api/models/userFacility');
require('../api/models/rssChannel');
require('../api/models/rssFeed');
require('../api/models/facilityRssChannel');
require('../api/models/facilitySavedRssFeed');
require('../api/models/trackingViewedLink');
require('../api/models/defaultEmployeePermission');
require('../api/models/permission');
require('../api/models/appSettings');
require('../api/models/ratingResponseSettings');
require('../api/models/smsSettings');
require('../api/models/notificationSettings');
require('../api/models/facilityRatingResponseSettings');
require('../api/models/facilitySmsSettings');
require('../api/models/facilityAppSettings');
require('../api/models/facilityNotificationSettings');
require('../api/models/todaysChecklist');
require('../api/models/notificationSmsHisitory');
require('../api/models/sendSmsInterval');
require('../api/models/emailHistory');
require('../api/models/feedbackCategoryModel');
require('../api/models/employeeReviewModel');
require('../api/models/employeeComplaintModel');
require('../api/models/patientReviewModel');
require('../api/models/patientComplaintModel');
require('../api/models/visitorsModel');
require('../api/models/checkInOutModel');
require('../api/models/setting');
require('../api/models/smsHistory');
require('../api/models/notificationHistory');
require('../api/models/subLogin');
require('../api/models/incidentReport');
require('../api/models/broadcastMessages');
require('../api/models/responseMessages');
require('../api/models/saveNotes');
require('../api/models/suggestions');
require('../api/models/chat');
require('../api/models/incidentNotes');
require('../api/models/reviewPlatform');
require('../api/models/facilityReview');
require('../api/models/facilityReviewPlatform');
require('../api/models/googleCredentials');
require('../api/models/googleAccountLocation');

switch (process.env.NODE_ENV) {
    case 'development':
        var uri = process.env.LOCAL_DB_URI;
        var options = {
            user: process.env.LOCAL_DB_USER,
            pass: process.env.LOCAL_DB_PASS,
            promiseLibrary: require('bluebird')
        }
        break;
    case 'production':
        var uri = process.env.DEV_DB_URI;
        var options = {
            user: process.env.DEV_DB_USER,
            pass: process.env.DEV_DB_PASS,
            promiseLibrary: require('bluebird')
        }
        break;
    case 'aws':
        var uri = process.env.AWS_DB_URI;
        var options = {
            user: process.env.AWS_DB_USER,
            pass: process.env.AWS_DB_PASS,
            promiseLibrary: require('bluebird')
        }
        break;
}

/**********Connect when local 172.10.1.7:27017 will not work. This connect to staging*****************/
// var uri = 'mongodb://52.34.207.5:27017/nhrms';
// var options = {
//     user: 'nhrms',
//     pass: 'nhrms@201888',
//     promiseLibrary: require('bluebird')
// }
/*********End*************************/
// var uri = process.env.LOCAL_DB_URI;
// var options = {
//     user: process.env.LOCAL_DB_USER,
//     pass: process.env.LOCAL_DB_PASS,
//     promiseLibrary: require('bluebird')
// }
mongoose.connect(uri, options, function (error) {
    // Check error in initial connection. There is no 2nd param to the callback.
    if (error) {
        console.log('connection failed!')
    } else {
        console.log("Database connected successfully!");
    }
});
/* end DB */