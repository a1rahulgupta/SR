var ENV = process.env.ENV || process.env.NODE_ENV || 'development';
var base_url, server_url;
if (ENV == 'production') {
    base_url = "http://52.34.207.5:5115";
    server_url = "http://52.34.207.5:5115"; //Staging server
} else if (ENV == 'aws') {
    // base_url = "http://localhost:5115";
    // server_url = "http://localhost:5115"; //AWS server
    base_url = "https://www.signin-repute.com";
    server_url = "https://www.signin-repute.com"; //AWS server
} else if (ENV == 'development') {
    base_url = "http://localhost:5115";
    server_url = "http://localhost:5115";
}

// console.log(base_url)
// console.log(server_url)
module.exports = {
    port: 5115,
    env: ENV,
    server_url: server_url,
    accessEncKey: 'asjhdf345gsakj$kamskgfhjasg&kjdnsfrkjdsbhfada85sdgfs723dfgfds',
    tokenExpiryTime: '24 hours',
    secret: 'nurshinghomereview',
    cryptoAlgorithm: 'aes-256-ctr',
    cryptoPassword: 'd6F3Efeq',
    secretKey: process.env.SALT_KEY,
    statusCode: {
        'error': 409,
        'success': 200,
        'badRequest': 400,
        'unauthorized': 401,
        'notFound': 404,
        'forbidden': 403,
        'invalid': 406,
        'serviceUnavailable': 503,
        'continue': 100
    },
    pattern: any = {
        'userName': /[a-zA-Z0-9_]{3,15}$/ig,
        'NAME': /^[a-zA-Z . \-\']*$/,
        "CITY": /^[a-zA-Z . \-\']*$/,
        "EMAIL": /^[a-zA-Z0-9]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/,
        "POSTAL_CODE": /(^\d{5}(-\d{4})?$)|(^[ABCEGHJKLMNPRSTVXY]{1}\d{1}[A-Z]{1} *\d{1}[A-Z]{1}\d{1}$)/, // /(^\d{5}$)|(^\d{5}-\d{4}$)/,
        "SUB_DOMAIN": /^[/a-z/A-Z][a-zA-Z0-9-]*[^/-/./0-9]$/,
        "PHONE_NO": /\(?\d{3}\)?-? *\d{3}-? *-?\d{4}/,
        "TASK_CODE": /^[0-9999]{1,4}$/,
        "SSN": /^((\d{3}-?\d{2}-?\d{4})|(X{3}-?X{2}-?X{4}))$/
    },
    email: {
        from: "nursinghomereview@gmail.com",
        abuse_email: "reputesupport@signin-repute.com",
        copyright: (new Date().getFullYear()) + " Copyright Repute",
        logo_url: "/assets/images/logo.png",
        base_url: base_url
    },
    role_type: {
        "SUPER_ADMIN": {
            name: "super_admin"
        },
        "COMPANY_ADMIN": {
            name: "company_admin"
        },
        "FACILITY_ADMIN": {
            name: "facility_admin"
        },
        "EMPLOYEE": {
            name: "employee"
        },
        "COMPANY_USER": {
            name: "company_user"
        }
    },
    textMessageTwilio: {
        'NEGATIVE_RATING_RESPONSE': "We are sorry if your experience wasn't the best. In a few words, please reply with details of your  experience.",
        'POSITIVE_RATING_RESPONSE': "Thank you very much! We are happy you enjoyed your visit. If you have the time, please rate us as well on Google: ",
        'INVALID_RATING_RESPONSE': "We got your response! but we didn't get a valid rating, if you can please reply back a just a number from 1 to 5 so we can record your rating successfully. Thank you!",
        'REVIEW_COMMENT_RESPONSE': "Thank you for your response. We will contact you as soon as possible to discuss your concerns.",
        'CHECKED_IN_RESPONSE': "We got your message! Someone will get back to you as soon as possible!",
        'POSITIVE_SUGGESTION': "which means they are happy! We recommend you reach out to them with a thank you,often visitors may forget or feel up to it at the moment to leave you a great review online;it is good practice to intially thank them for providing a good rating and consider responding to them with a pre-made message or your own,a response can yield great results and increase your odds for recognition and a great review.",
        'NEGATIVE_SUGGESTION': "which means they are probably not too happy something.We suggest you take a quick look and see what the issue is,maybe it's not critical but make note of it incase something needs to be done.Consider responding to them either with a pre-made message or your own,a response will quickly ease the tension and put you in a better position to be recognized for owning the issue",
        'STOP_MESSAGE_REPLY': "Txt STOP to unsub."
    },
    settingModuleSelectType: {
        "APP_STATUS": 'appStatus',
        "APP_SETTINGS": 'appSettings',
        "SMS_SETTINGS": 'smsSettings',
        "RATING_RESPONSE_SETTINGS": 'ratingResSettings',
        "NOTIFICATION_SETTINGS": 'notificationSettings'
    },
    openIncidentPeriod: {
        "ON_SECOND_DAY": 'on_second_day',
        "ON_SEVENTH_DAY": 'on_seventh_day',
        "ON_FIFTEENTH_DAY": 'on_fifteen_day',
        "ON_THIRTHEETH_DAY": 'on_thirtheeth_day'
    },
    selectPeriod: {
        "LAST_THIRTY_DAYS": 'lastThirtyDays',
        "LAST_SIX_MONTH": 'lastSixthMonth',
        "LAST_YEAR": 'lastYear',
        "OVER_ALL": 'overAll'
    },
    upload_dir: {
        "USER_PROFILE_PIC": "/assets/images/default-img.png",
        "BLOG_PIC": '/public/uploads/blogs/',
        "BLOG_CATEGORY_PIC": '/public/uploads/blogs/category/',
        "DEFAULT_MALE_PIC": '/public/assets/icons/male_avatar.png',
        "DEFAULT_FEMALE_PIC": '/assets/images/default-img.png',
        "DEFAULT_MALE_WHITE_PIC": '/public/assets/icons/male_avatar_white.png',
        "DEFAULT_FEMALE_WHITE_PIC": '/public/assets/icons/female_avatar_white.png',
        "COMPANY_LOGO_DIR": '/public/uploads/logos/',
        "DEFAULT_COMPANY_LOGO": '/public/assets/icons/default_logo.png',
        "DOCUMENTS_DIR": '/uploads/'
    },
    files: {
        MAX_IMG_SIZE: 20 * 2000 * 2000
    },
    page: {
        limit: 10,
        orderBy: 'created',
        sortDirection: 'desc'
    },

    aws_ses: {
        accessKeyId: 'AKIAJTB66NAVMZ7FQX6A',
        secretAccessKey: '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',
        region: 'us-east-1',
        fromName: 'ReputeApp <reputeapp@signin-repute.com>'
    },

    openWeather : {
        setAPPID : "f4444eeead26d0e4075caf7b7071ccb0", 
        setCulture : "fr", 
        setForecastType : "daily", 
        iconUrl: "http://openweathermap.org/img/w/",
        iconType: ".png"
    },

    phoneNumber: {
        countryCode: "+1"
    },

    googleConfig: {
        scope: "https://www.googleapis.com/auth/plus.business.manage",
        redirect_uri: base_url+'/admin/setting/googleList'
    },

    visitorType : {
        "FAMILY" : "family", 
        "FRIEND" : "friend", 
        "POA" : "poa", 
        "HCP": "hcp",
        "GUARDIAN": "guardian",
        "ATTORNEY": "attorney",
        "GUESTTOUR": "guest_tour",
        "VENDOR": "vendor"
    },

    reviewPlatformName : {
        "GOOGLE" : {
            name: "google",
            hostname: "google.com"
        },
        "CITEHEALTH": {
            name: "citehealth",
            hostname: "citehealth.com"
        },
        "CARING": {
            name: "caring",
            hostname: "www.caring.com"
        },
        "SENIOR_ADVISOR": {
            name: "seniorAdvisor",
            hostname: "www.senioradvisor.com"
        }, 
        "LOCAL_NURSING_HOMES": {
            name: "localNursingHomes",
            hostname: "local-nursing-homes.com"
        }, 
        "NURSING_HOME_SITE": {
            name: "nursingHomeSite",
            hostname: "www.nursinghomesite.com"
        }, 
        "FAMILY_ASSETS": {
            name: "familyAssets",
            hostname: "www.familyassets.com"
        }, 
        "YELP" : {
            name: "yelp",
            hostname: "www.yelp.com"
        }, 
        "SUPER_PAGES" : {
            name: "superPages",
            hostname: "www.superpages.com"
        }, 
        "YELLOW_PAGES" : {
            name: "yellowPages",
            hostname: "www.yellowpages.com"
        },
        "AGINGCARE": {
            name: "agingCare",
            hostname: "www.agingcare.com"
        },
        "INDEED": {
            name: "indeed",
            hostname: "www.indeed.com"
        },
        "WELLNESS": {
            name: "wellness",
            hostname: "www.wellness.com"
        }, 
        "FACEBOOK" : {
            name: "facebook",
            hostname: "facebook.com"
        }
        
    },

    //Send Sms through Twilio
    TWILIO_ACCOUNT_SID: 'ACe4bca396fcc625235348318d2be36508',
    TWILIO_AUTH_TOKEN: '9c03c854c5643dd1651462f316ea88d8',
    TWILIO_FROM_NUMBER: '(234) 203-5097',
    isValidName: isValidName,
    isMobileNumber: isMobileNumber,
    isEmail: isEmail,
    isGender: isGender,
    isEmpty: isEmpty,
    generateShortId: generateShortId,
    isAddress: isAddress,
    isZipCode: isZipCode,
    isSpokenWritten: isSpokenWritten,

    // Twilio Account For Visitor     
    TWILIO_ACCOUNT_SID: 'ACc961b7fb36858aef271769936a2d1280',
    TWILIO_AUTH_TOKEN: '7f2377f1ee9430b0529c7f4ff6af9852',
    TWILIO_FROM_NUMBER: '(201) 645-4973',


};

function generateShortId() {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

    for (var i = 0; i < 10; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    }
    return text;
}

function isValidName(name) {
    return /^[a-zA-Z '-]+$/.test(name);
}

function isMobileNumber(phone) {
    return /^[+0-9]+$/.test(phone);
}

function isEmail(email) {
    return /^[a-zA-Z0-9]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/.test(email);
}

function isGender(gender) {
    return (gender == "Male" || gender == "Female") ? true : false;
}

function isEmpty(data) {
    if (data && data !== null && data !== undefined && data !== '') {
        return false;
    } else {
        return true;
    }
}

function isAddress(address) {
    return /^[a-zA-Z0-9 .,'/:#-]+$/.test(address);
}

function isZipCode(zip) {
    return /^[A-Z0-9 ]+$/.test(zip);
}

function isSpokenWritten(spoken) {
    var arr = ['Native', 'Fluent', 'Good', 'Basic'];
    var count = 0;
    for (var i = 0; i < arr.length; i++) {
        if (arr[i] === spoken) {
            count++;
            break;
        }
    }
    if (count == 0) {
        return false;
    } else {
        return true;
    }
}