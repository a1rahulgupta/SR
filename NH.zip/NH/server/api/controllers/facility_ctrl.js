'use strict';

var mongoose = require('mongoose'),
    generator = require('generate-password'),
    formidable = require('formidable'),
    fs = require('fs-extra'),
    path = require('path'),
    jwt = require('jsonwebtoken'),
    validator = require('validator'),
    utility = require('../lib/utility.js'),
    crypto = require('./../lib/crypto.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    jwt = require('jsonwebtoken'),
    Joi = require('joi'),
    i18n = require("i18n"),
    moment = require('moment'),
    twilio = require('./../lib/twilio.js'),

    //require collections
    User = mongoose.model('user'),
    Facility = mongoose.model('facility'),
    UserFacility = mongoose.model('userFacility'),
    SubLogin = mongoose.model('subLogin'),
    AppSettings = mongoose.model('appSettings'),
    FacilityAppSettings = mongoose.model('facilityAppSettings'),
    RatingResponseSettings = mongoose.model('ratingResponseSettings'),
    FacilityRatingResponseSettings = mongoose.model('facilityRatingResponseSettings'),
    SmsSettings = mongoose.model('smsSettings'),
    FacilitySmsSettings = mongoose.model('facilitySmsSettings'),
    NotificationSettings = mongoose.model('notificationSettings'),
    FacilityNotificationSettings = mongoose.model('facilityNotificationSettings'),
    TodaysCheckList = mongoose.model('todaysCheckList'),
    NotesMessage = mongoose.model('notesMessage'),

    //require files
    emailSend = __rootRequire('api/core/email'),
    convert = require('xml-js'),
    config = require('../../config/config.js');

module.exports = {
    addFacility: addFacility,
    getAllFacilityList: getAllFacilityList,
    getFacilityById: getFacilityById,
    updateFacility: updateFacility,
    deleteFacility: deleteFacility,
    activateDeactivateFacility: activateDeactivateFacility,
    exportXml: exportXml,
    getNumberList: getNumberList,
    updateFacilityProfile: updateFacilityProfile,
    getLoginDetails: getLoginDetails,
    addFacilitiesTodaysCheckList: addFacilitiesTodaysCheckList,
    getFacilityTodaysChecklist: getFacilityTodaysChecklist,
    updateTodaysCheckList: updateTodaysCheckList,
    saveFacilityNotes: saveFacilityNotes,
    getNotesDetails: getNotesDetails
}

/**
 * Function is use to add facility by admin 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 3-May-2018
 */
function addFacility(req, res) {

    var finalResponse = {};
    finalResponse.userData = {};
    finalResponse.FacData = {};
    finalResponse.userFacilityData = {};
    finalResponse.twilioInfo = {};
    finalResponse.verifyToken = '';
    finalResponse.verifingLink = '';
    var facObj = {
        firstName: req.swagger.params.firstName.value,
        lastName: req.swagger.params.lastName.value,
        facName: req.swagger.params.facName.value,
        userCmpId: req.swagger.params.userCmpId.value,
        email: req.swagger.params.email.value,
        address: req.swagger.params.address.value,
        city: req.swagger.params.city.value,
        state: req.swagger.params.state.value,
        country: req.swagger.params.country.value,
        zipCode: req.swagger.params.zipCode.value,
        phoneNumber: req.swagger.params.phoneNumber.value,
        stateCode: req.swagger.params.stateCode.value,
        googleLink: req.swagger.params.googleLink.value,
        twilioTollFreeNumber: req.swagger.params.twilioTollFreeNumber.value,
        file: req.swagger.params.file.value
    }

    console.log("comes", facObj);
    if (!facObj.firstName || !facObj.lastName || !facObj.email || !facObj.facName || !facObj.address || !facObj.city || !facObj.state || !facObj.zipCode || !facObj.country || !facObj.phoneNumber || !facObj.userCmpId || !facObj.twilioTollFreeNumber) {

        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else if (facObj.email && !config.isEmail(facObj.email)) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("INVALID_EMAIL")
        });
    } else {
        waterfall([
                function (callback) { //Check for already exist Facility
                    Facility.existCheck(facObj.facName.trim(), function (err, exist) {
                        if (err) {
                            callback(err, false);
                        } else {
                            if (!exist) {
                                res.json({
                                    code: config.statusCode.badRequest,
                                    data: {},
                                    message: i18n.__("FACILITY_ALREADY_EXIST")
                                });
                            } else {
                                callback(null, finalResponse);
                            }
                        }
                    });
                },
                function (finalResponse, callback) { //Check for already exist Email of user
                    User.existCheck(facObj.email.trim(), '', function (err, emailExist) {
                        if (err) {
                            callback(err, false);
                        } else {
                            if (!emailExist) {
                                res.json({
                                    code: config.statusCode.badRequest,
                                    data: {},
                                    message: i18n.__("EMAIL_ALREADY_EXIST")
                                });
                            } else {
                                callback(null, finalResponse);
                            }
                        }
                    });
                },
                function (finalResponse, callback) { //Save User data
                    var randomPassword = generator.generate({
                        length: 10,
                        numbers: true
                    });
                    var passEnc = utility.getEncryptText(randomPassword.toString()); //crypto need string in parameter

                    var obj = {
                        firstName: facObj.firstName,
                        lastName: facObj.lastName,
                        userName: facObj.firstName + ' ' + facObj.lastName,
                        role: config.role_type.FACILITY_ADMIN.name,
                        createdBy: config.role_type.SUPER_ADMIN.name,
                        createdById: req.user.uid,
                        phoneNumber: facObj.phoneNumber,
                        email: facObj.email.toLowerCase(),
                        password: passEnc
                    };

                    var userRecord = new User(obj);
                    userRecord.save(function (err, userData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.userData = userData;
                            callback(null, finalResponse);
                        }
                    });
                },
                function (finalResponse, callback) { //Save facility data
                    var newObj = {
                        userCmpId: facObj.userCmpId,
                        facName: facObj.facName,
                        address: facObj.address,
                        city: facObj.city,
                        state: facObj.state,
                        country: facObj.country,
                        zipCode: facObj.zipCode,
                        googleLink: facObj.googleLink,
                        stateCode: facObj.stateCode,
                        twilioTollFreeNumber: facObj.twilioTollFreeNumber
                    };
                    var facRecord = new Facility(newObj);
                    facRecord.save(function (err, facData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.facData = facData;
                            if (facObj.file) { //Save facility logo if file exist
                                var timestamp = Number(new Date()); // current time as number
                                var file = facObj.file;
                                var facilityId = facData._id;
                                var splitFileName = file.originalname.split('.');
                                var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                                var filename = facilityId + '_' + timestamp + '.' + ext;
                                var imagePath = "./../client/src/assets/upload/profiles/" + filename; //Used for write file on this path
                                var base_url = config.server_url;

                                utility.fileUpload(path.resolve(imagePath), file.buffer).then(function () {
                                    facData.facLogo = filename;
                                    facData.save(function (err, updateFacLogo) {
                                        if (err) {
                                            callback(err, false);
                                        } else {
                                            callback(null, finalResponse);
                                        }
                                    })
                                })
                            } else {
                                callback(null, finalResponse);
                            }
                        }
                    });
                },
                function (finalResponse, callback) { //Save User facility data
                    var userFacilityData = {
                        userId: finalResponse.userData._id,
                        facilityId: finalResponse.facData._id
                    };
                    var userFacilityRecord = new UserFacility(userFacilityData);
                    userFacilityRecord.save(function (err, userFacilityData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.userFacilityData = userFacilityData;
                            callback(null, finalResponse);
                        }
                    });
                },
                function (finalResponse, callback) { //Save facility default app setting
                    AppSettings.findOne({
                        status: true,
                        isDelete: false
                    }).lean().exec(function (err, appSettingsData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            var appSettingsObj = {
                                userId: mongoose.Types.ObjectId(finalResponse.userData._id),
                                facId: mongoose.Types.ObjectId(finalResponse.facData._id),
                                userFacId: mongoose.Types.ObjectId(finalResponse.userFacilityData._id),
                                checkInSms: {
                                    status: true,
                                    visitorName: false,
                                    message: "Thanks for checking in at "+finalResponse.facData.facName+"! for any requests or comments you can reply to this text message."
                                },
                                checkInMessageReceivedReplySms: appSettingsData.checkInMessageReceivedReplySms,
                                checkOutSms: {
                                    status: true,
                                    visitorName: false,
                                    message: "You have successfully checked out from "+finalResponse.facData.facName+"! Please rate your experience by replying with a number from 1 to 5(5 being the best)."
                                },
                                negativeRatingFollowUpSms: appSettingsData.negativeRatingFollowUpSms,
                                checkInSmsInterval: appSettingsData.checkInSmsInterval,
                                checkOutSmsInterval: appSettingsData.checkOutSmsInterval,
                                googleRatingSmsInterval: appSettingsData.googleRatingSmsInterval,
                                smsLimits: appSettingsData.smsLimits,
                                welcomeMessage: appSettingsData.welcomeMessage,
                                footerMessage: appSettingsData.footerMessage,
                                goodbyeMessage: appSettingsData.goodbyeMessage,
                                expressResident: appSettingsData.expressResident
                            };
                            var facilityAppSettings = new FacilityAppSettings(appSettingsObj);
                            facilityAppSettings.save(function (err, facilityAppSettingsData) {
                                if (err) {
                                    callback(err, false);
                                } else {
                                    callback(null, finalResponse);
                                }
                            });
                        }
                    });
                },
                function (finalResponse, callback) { //Save facility default rating and response settings
                    RatingResponseSettings.findOne({
                        status: true,
                        isDelete: false
                    }).lean().exec(function (err, ratingResponseSettingsData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            var ratingResponseSettingsObj = {
                                userId: mongoose.Types.ObjectId(finalResponse.userData._id),
                                facId: mongoose.Types.ObjectId(finalResponse.facData._id),
                                userFacId: mongoose.Types.ObjectId(finalResponse.userFacilityData._id),
                                positive: {
                                    from: ratingResponseSettingsData.positive.from,
                                    to: ratingResponseSettingsData.positive.to,
                                    autoResponse: ratingResponseSettingsData.positive.autoResponse,
                                    sendAlerts: ratingResponseSettingsData.positive.sendAlerts,
                                    addReviewLink: ratingResponseSettingsData.positive.addReviewLink,
                                    googleLink: facObj.googleLink
                                },
                                negative: ratingResponseSettingsData.negative
                            };
                            var facilityRatingResponseSettings = new FacilityRatingResponseSettings(ratingResponseSettingsObj);
                            facilityRatingResponseSettings.save(function (err, facilityRatingResponseSettingsData) {
                                if (err) {
                                    callback(err, false);
                                } else {
                                    callback(null, finalResponse);
                                }
                            });
                        }
                    });
                },
                function (finalResponse, callback) { //Save facility default sms settings
                    SmsSettings.findOne({
                        status: true,
                        isDelete: false
                    }).lean().exec(function (err, smsSettingsData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            var smsSettingsObj = {
                                userId: mongoose.Types.ObjectId(finalResponse.userData._id),
                                facId: mongoose.Types.ObjectId(finalResponse.facData._id),
                                userFacId: mongoose.Types.ObjectId(finalResponse.userFacilityData._id),
                                sunday: smsSettingsData.sunday,
                                monday: smsSettingsData.monday,
                                tuesday: smsSettingsData.tuesday,
                                wednesday: smsSettingsData.wednesday,
                                thursday: smsSettingsData.thursday,
                                friday: smsSettingsData.friday,
                                saturday: smsSettingsData.saturday,
                                disableAutoReply: smsSettingsData.disableAutoReply
                            };
                            var facilitySmsSettings = new FacilitySmsSettings(smsSettingsObj);
                            facilitySmsSettings.save(function (err, facilitySmsSettingsData) {
                                if (err) {
                                    callback(err, false);
                                } else {
                                    callback(null, finalResponse);
                                }
                            });
                        }
                    });
                },
                function (finalResponse, callback) { //Save facility default notification settings
                    NotificationSettings.findOne({
                        status: true,
                        isDelete: false
                    }).lean().exec(function (err, notificationSettingsData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            var notificationSettingsObj = {
                                userId: mongoose.Types.ObjectId(finalResponse.userData._id),
                                facId: mongoose.Types.ObjectId(finalResponse.facData._id),
                                userFacId: mongoose.Types.ObjectId(finalResponse.userFacilityData._id),
                                openIncident: notificationSettingsData.openIncident,
                                updateResolvedIncident: notificationSettingsData.updateResolvedIncident,
                                negative_rating_notification: notificationSettingsData.negative_rating_notification,
                                checkInNotification: notificationSettingsData.checkInNotification
                            };
                            var facilityNotificationSettings = new FacilityNotificationSettings(notificationSettingsObj);
                            facilityNotificationSettings.save(function (err, facilitynotificationSettingsData) {
                                if (err) {
                                    callback(err, false);
                                } else {
                                    callback(null, finalResponse);
                                }
                            });
                        }
                    });
                },
                function (finalResponse, callback) { //Create verify link and token to verify the facility
                    var date = new Date();
                    finalResponse.verifyToken = utility.getEncryptText(Math.random().toString(4).slice(2) + date.getTime());
                    finalResponse.verifingLink = config.email.base_url + '/verify_account/' + finalResponse.verifyToken;

                    User.findOneAndUpdate({
                        _id: finalResponse.userData._id
                    }, {
                        $set: {
                            verifyToken: finalResponse.verifyToken
                        }
                    }, function (err, updatedUserdata) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });

                },
                function (finalResponse, callback) { //Send Email to User for verify Account
                    var baseUrl = config.email.base_url;
                    var options = {
                        template: 'verifyAccount.html',
                        from: config.email.from,
                        repalcement: {
                            "{{user.name}}": finalResponse.userData.firstName.charAt(0).toUpperCase() + finalResponse.userData.firstName.slice(1).toLowerCase() + ' ' + finalResponse.userData.lastName.charAt(0).toUpperCase() + finalResponse.userData.lastName.slice(1).toLowerCase(),
                            "{{user.email}}": finalResponse.userData.email,
                            "{{user.password}}": utility.getDecryptText(finalResponse.userData.password),
                            "{{user.url}}": finalResponse.verifingLink,
                            "{{logo_url}}": baseUrl + config.email.logo_url,
                            "{{copyright}}": config.email.copyright,
                            "{{user.login_url}}": baseUrl,
                            "{{link.abuse_email}}": config.email.abuse_email
                        },
                        to: finalResponse.userData.email,
                        subject: 'Verify Account'
                    };
                    emailSend.smtp.sendMail(options, function (err, response) {
                        if (err) {
                            callback(null, finalResponse);
                        } else {
                            callback(null, finalResponse);
                        }
                    })
                },
                function (finalResponse, callback) { //config twilio number
                    var smsData = {
                        tollFreeNumber: facObj.twilioTollFreeNumber,
                        baseUrl: config.email.base_url
                    }
                    twilio.configTwilioNumber(smsData, function (returnData) {
                        finalResponse.twilioInfo = returnData
                        callback(null, finalResponse);
                    });
                }
            ],
            function (err, data) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: data,
                        message: i18n.__("FACILITY_CREATED_SUCCESSFULLY")
                    });
                }
            });

    }
}

/**
 * Function is use to fetch facility list for admin
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 3-May-2018
 */
function getAllFacilityList(req, res) {
    var finalResponse = {};
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);

    waterfall([
        function (callback) { //Company Data

            var condition = {};
            condition.isDelete = false;
            condition['userFacInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;

            if (req.user.role == config.role_type.COMPANY_ADMIN.name) {
                condition.userCmpId = mongoose.Types.ObjectId(req.user.userCmpId);
            }

            var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            if (searchText != undefined && searchText != 'undefined') {
                condition.$or = [{
                        'userInfo.firstName': new RegExp(searchText, 'gi')
                    },
                    {
                        'userInfo.lastName': new RegExp(searchText, 'gi')
                    },
                    {
                        'userInfo.userName': new RegExp(searchText, 'gi')
                    },
                    {
                        'facName': new RegExp(searchText, 'gi')
                    },
                    {
                        'cmpInfo.cmpName': new RegExp(searchText, 'gi')
                    },
                    {
                        'userInfo.phoneNumber': new RegExp(searchText, 'gi')
                    }
                ];
            }

            if (req.body.createdAt) {
                var start_day_date = moment(req.body.createdAt).startOf('day');
                var end_day_date = moment(req.body.createdAt).endOf('day');
                var momentObjFrom = new Date(moment(start_day_date));
                var momentObjTo = new Date(moment(end_day_date));
                condition.$and = [{
                        createdAt: {
                            $gte: momentObjFrom
                        }
                    },
                    {
                        createdAt: {
                            $lte: momentObjTo
                        }
                    }
                ];
            }

            if (req.body.facName) {
                condition['facName'] = new RegExp(req.body.facName, 'gi');
            }
            if (req.body.userName) {
                condition['userInfo.userName'] = new RegExp(req.body.userName, 'gi');
            }
            if (req.body.cmpName) {
                condition['cmpInfo.cmpName'] = new RegExp(req.body.cmpName, 'gi');
            }
            if (req.body.phoneNumber) {
                condition['userInfo.phoneNumber'] = new RegExp(req.body.phoneNumber, 'gi');
            }
            console.log("condition", condition);
            var aggregate = [{
                    $lookup: {
                        from: 'userfacilities',
                        localField: "_id",
                        foreignField: "facilityId",
                        as: "userFacInfo"
                    }
                },
                {
                    $unwind: "$userFacInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userFacInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                }, {
                    $lookup: {
                        from: 'usercompanies',
                        localField: "userCmpId",
                        foreignField: "_id",
                        as: "userCmpInfo"
                    }
                },
                {
                    $unwind: "$userCmpInfo"
                }, {
                    $lookup: {
                        from: 'companies',
                        localField: "userCmpInfo.companyId",
                        foreignField: "_id",
                        as: "cmpInfo"
                    }
                },
                {
                    $unwind: "$cmpInfo"
                },

                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "facName": "$facName",
                    "facLogo": "$facLogo",
                    "cmpName": "$cmpInfo.cmpName",
                    "createdAt": "$userInfo.createdAt",
                    "firstName": "$userInfo.firstName",
                    "lastName": "$userInfo.lastName",
                    "userName": "$userInfo.userName",
                    "phoneNumber": "$userInfo.phoneNumber",
                    "email": "$userInfo.email",
                    "status": "$userInfo.status",
                    "userId": "$userInfo._id",
                    "userFacId": "$userFacInfo._id",
                    "password": "$userInfo.password"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            aggregate.push({
                $sort: sorting
            });
            aggregate.push({
                $skip: parseInt(skip)
            });
            aggregate.push({
                $limit: parseInt(count)
            });
            Facility.aggregate(aggregate).then(function (facData) {
                for (var i = 0; i < facData.length; i++) {
                    facData[i].password = utility.getDecryptText(facData[i].password)

                }
                var data = {};
                data.data = facData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                Facility.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    data.total_count = cnt;
                    callback(null, data);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            console.log("error", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is get facility by id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 03-May-2018
 */
function getFacilityById(req, res) {
    var finalResponse = {};
    var condition = {};
    if (mongoose.Types.ObjectId.isValid(req.query.id)) {
        condition._id = mongoose.Types.ObjectId(req.query.id);
        condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;
        var aggregate = [{
                $lookup: {
                    from: 'userfacilities',
                    localField: "_id",
                    foreignField: "facilityId",
                    as: "userFacInfo"
                }
            },
            {
                $unwind: "$userFacInfo"
            },
            {
                $lookup: {
                    from: 'users',
                    localField: "userFacInfo.userId",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: "$userInfo"
            },
            {
                $match: condition
            },
        ];
        var project = {
            $project: {
                userId: "$userInfo._id",
                userFacId: "$userFacInfo._id",
                firstName: "$userInfo.firstName",
                lastName: "$userInfo.lastName",
                phoneNumber: "$userInfo.phoneNumber",
                email: "$userInfo.email",
                facName: "$facName",
                facLogo: "$facLogo",
                userCmpId: "$userCmpId",
                address: "$address",
                city: "$city",
                state: "$state",
                country: "$country",
                zipCode: "$zipCode",
                stateCode: "$stateCode",
                googleLink: "$googleLink",
                twilioTollFreeNumber: "$twilioTollFreeNumber"
            }
        };

        var countQuery = [].concat(aggregate);
        aggregate.push(project);

        Facility.aggregate(aggregate).then(function (result) {
            finalResponse.data = result[0];
            console.log("finalResponse.data@@@@@@@@@@", finalResponse.data);
            res.json({
                code: config.statusCode.success,
                data: finalResponse.data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }).catch(function (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        });
    } else {
        res.json({
            code: config.statusCode.invalid,
            data: {},
            message: i18n.__("INVALID_URL")
        });
    }
}

/**
 * Function is use to update facility info by id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 03-May-2018
 */
function updateFacility(req, res) {
    var email = req.body.email.toLowerCase();
    var finalResponse = {};
    finalResponse.userData = {};
    finalResponse.userFacilityData = {};
    var facObj = {
        firstName: req.swagger.params.firstName.value,
        lastName: req.swagger.params.lastName.value,
        facName: req.swagger.params.facName.value,
        userCmpId: req.swagger.params.userCmpId.value,
        email: req.swagger.params.email.value,
        address: req.swagger.params.address.value,
        city: req.swagger.params.city.value,
        state: req.swagger.params.state.value,
        country: req.swagger.params.country.value,
        zipCode: req.swagger.params.zipCode.value,
        phoneNumber: req.swagger.params.phoneNumber.value,
        file: req.swagger.params.file.value,
        _id: req.swagger.params._id.value,
        userId: req.swagger.params.userId.value,
        userFacId: req.swagger.params.userFacId.value,
        googleLink: req.swagger.params.googleLink.value,
        stateCode: req.swagger.params.stateCode.value,
        twilioTollFreeNumber: req.swagger.params.twilioTollFreeNumber.value
    }
    waterfall([
        function (callback) { //check email and facility name is already exist
            User.findOne({
                email: facObj.email.trim().toLowerCase(),
                _id: {
                    $ne: facObj.userId
                },
                isDelete: false
            }).lean().exec(function (err, userData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (userData) {
                        res.json({
                            code: config.statusCode.badRequest,
                            data: {},
                            message: i18n.__("EMAIL_ALREADY_EXIST")
                        });
                    } else {
                        Facility.findOne({
                            facName: facObj.facName,
                            _id: {
                                $ne: mongoose.Types.ObjectId(facObj._id)
                            },
                            isDelete: false
                        }).lean().exec(function (err, facData) {
                            if (err) {
                                callback(err, false);
                            } else {
                                if (facData) {
                                    res.json({
                                        code: config.statusCode.badRequest,
                                        data: {},
                                        message: i18n.__("FACILITY_ALREADY_EXIST")
                                    });
                                } else {
                                    callback(null, finalResponse);
                                }
                            }
                        });
                    }
                }
            });
        },
        function (finalResponse, callback) { //Update user record
            User.findById(facObj.userId).exec(function (err, data) {
                if (err) {
                    callback(err, false);
                } else {
                    data.firstName = facObj.firstName;
                    data.lastName = facObj.lastName;
                    data.userName = facObj.firstName + ' ' + facObj.lastName,
                        data.email = facObj.email;
                    data.phoneNumber = facObj.phoneNumber;
                    data.modifiedBy = config.role_type.SUPER_ADMIN.name;
                    data.modifiedById = req.user.uid;
                    data.save(function (err, updatedUserData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.userData = data;
                            callback(null, finalResponse);
                        }
                    })
                }
            });
        },
        function (finalResponse, callback) { //Update Facility record
            Facility.findById(facObj._id).exec(function (err, facData) {
                if (err) {
                    callback(err, false);
                } else {
                    facData.facName = facObj.facName;
                    facData.address = facObj.address;
                    facData.userCmpId = facObj.userCmpId;
                    facData.city = facObj.city;
                    facData.state = facObj.state;
                    facData.country = facObj.country;
                    facData.zipCode = facObj.zipCode;
                    facData.googleLink = facObj.googleLink;
                    facData.twilioTollFreeNumber = facObj.twilioTollFreeNumber;
                    facData.stateCode = facObj.stateCode;
                    facData.save(function (err, updatefacData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            if (facObj.file) { //Update logo if exist
                                var timestamp = Number(new Date()); // current time as number
                                var file = facObj.file;
                                var facilityId = facData._id;
                                var splitFileName = file.originalname.split('.');
                                var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                                var filename = facilityId + '_' + timestamp + '.' + ext;
                                var imagePath = "./../client/src/assets/upload/profiles/" + filename;
                                var base_url = config.server_url;

                                utility.fileUpload(path.resolve(imagePath), file.buffer).then(function () {
                                    facData.facLogo = filename;
                                    facData.save(function (err, updateFacLogo) {
                                        if (err) {
                                            callback(err, false);
                                        } else {
                                            callback(null, finalResponse);
                                        }
                                    })
                                })
                            } else {
                                callback(null, finalResponse);
                            }
                        }
                    })
                }
            });
        },
        function (finalResponse, callback) { //Update user facility record
            UserFacility.findOne({
                _id: facObj.userFacId
            }).exec(function (err, foundUserFacilityData) {
                if (err) {
                    callback(err, false);
                } else {
                    foundUserFacilityData.userId = finalResponse.userData._id;
                    foundUserFacilityData.facilityId = facObj._id;
                    foundUserFacilityData.save(function (err, updateUserfacData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    })
                }
            })
        },
        function (finalResponse, callback) { //Update rating and response setting for online review link
            FacilityRatingResponseSettings.findOneAndUpdate({ userFacId: facObj.userFacId, isDelete: false, status: true }, {
                $set: {
                    "positive.googleLink": facObj.googleLink
                }
            }, function (err, updatedRatingResponseSetting) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("UPDATED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to delete facility account 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 03-May-2018
 */
function deleteFacility(req, res) {
    var finalResponse = {};

    waterfall([
        function (callback) { //Delete company
            Facility.findOneAndUpdate({
                _id: req.body._id
            }, {
                $set: {
                    isDelete: true,
                }
            }, function (err, data) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //delete user facility
            UserFacility.findOneAndUpdate({
                _id: req.body.userFacId
            }, {
                $set: {
                    isDelete: true,
                }
            }, function (err, userfacdata) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //delete user record
            User.findOneAndUpdate({
                _id: req.body.userId
            }, {
                $set: {
                    isDelete: true,
                    isDeletedBy: config.role_type.SUPER_ADMIN.name,
                    isDeletedById: req.user.uid
                }
            }, function (err, userfacdata) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("FACILITY_ACCOUNT_DELETED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to activate-deactivate account 
 * @access private
 * @return json
 * Created by Sunny
 * Updated by VishakaR
 * @smartData Enterprises (I) Ltd
 * Created Date 03-May-2018 ,9-july-2018
 */
function activateDeactivateFacility(req, res) {
    var finalResponse = {};
    waterfall([
        function (callback) { //Activate deactivate facility
            Facility.findOneAndUpdate({
                _id: req.body._id
            }, {
                $set: {
                    status: req.body.status,
                }
            }, function (err, data) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Activate deactivate user facility
            UserFacility.findOneAndUpdate({
                _id: req.body.userFacId
            }, {
                $set: {
                    status: req.body.status,
                }
            }, function (err, userfacdata) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Activate deactivate user record
            if (req.body.status == '1') {
                if (req.body.by == 'super_admin') {
                    var userObj = {
                        isActivatedBy: config.role_type.SUPER_ADMIN.name,
                        isActivatedById: req.user.uid,
                        status: '1'
                    }
                } else {
                    var userObj = {
                        isActivatedBy: config.role_type.SUPER_ADMIN.name,
                        isActivatedById: req.user.uid,
                        status: '1'
                    }

                }

            } else {
                var userObj = {
                    isDeactivatedBy: config.role_type.SUPER_ADMIN.name,
                    isDeactivatedById: req.user.uid,
                    status: '2'
                }
            }
            User.findOneAndUpdate({
                _id: req.body.userId
            }, {
                $set: userObj
            }, function (err, userfacdata) {
                if (err) {
                    callback(err, false);
                } else {
                    if (req.body.by == 'super_admin') {
                        UserFacility.findById(req.body.userFacId).populate('userId').exec(function (err, data) {
                            if (err) {
                                callback(err, false);
                            } else {
                                var baseUrl = config.email.base_url;
                                var options = {
                                    template: 'verifiedAccountBySuperAdmin.html',
                                    from: config.email.from,
                                    repalcement: {
                                        "{{user.name}}": data.userId.firstName.charAt(0).toUpperCase() + data.userId.firstName.slice(1).toLowerCase() + ' ' + data.userId.lastName.charAt(0).toUpperCase() + data.userId.lastName.slice(1).toLowerCase(),
                                        "{{user.email}}": data.userId.email,
                                        "{{user.password}}": utility.getDecryptText(data.userId.password),
                                        "{{user.url}}": finalResponse.verifingLink,
                                        "{{logo_url}}": baseUrl + config.email.logo_url,
                                        "{{copyright}}": config.email.copyright,
                                        "{{user.login_url}}": baseUrl,
                                        "{{link.abuse_email}}": config.email.abuse_email
                                    },
                                    to: data.userId.email,
                                    subject: 'Verified Account By Repute'
                                };
                                emailSend.smtp.sendMail(options, function (err, response) {
                                    if (err) {
                                        callback(null, finalResponse);
                                    } else {
                                        callback(null, finalResponse);
                                    }
                                })
                            }
                        })
                    } else {
                        callback(null, finalResponse);
                    }

                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__('Facility ' + ((req.body.status == 1) ? 'activated' : 'deactivated') + ' successfully')
            });
        }
    });
}

/**
 * Function is use to Export Xml
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 3-May-2018
 */

function exportXml(req, res) {
    var xmlData = req.body;
    var options = {
        compact: true,
        spaces: 4
    };
    var result = convert.json2xml(xmlData, options);
    if (result) {
        res.json({
            code: config.statusCode.success,
            data: result
        });
    }
}

/**
 * Function is use to Get Toll free numbers
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 25-May-2018
 */
function getNumberList(req, res) {
    var twilioNumberData = [];
    twilio.getTwilioNumber({}, function (twilioNumberData) {
        res.json({
            code: config.statusCode.success,
            data: twilioNumberData,
            message: i18n.__("DATA_FOUND_SUCCESSFULLY")
        });
    });

}

/**
 * Function is use to update facility profile
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 02-June-2018
 */
function updateFacilityProfile(req, res) {
    var email = req.body.email.toLowerCase();
    var finalResponse = {};
    finalResponse.userData = {};
    finalResponse.userFacilityData = {};
    var facObj = {
        firstName: req.swagger.params.firstName.value,
        lastName: req.swagger.params.lastName.value,
        facName: req.swagger.params.facName.value,
        email: req.swagger.params.email.value,
        address: req.swagger.params.address.value,
        city: req.swagger.params.city.value,
        state: req.swagger.params.state.value,
        country: req.swagger.params.country.value,
        zipCode: req.swagger.params.zipCode.value,
        phoneNumber: req.swagger.params.phoneNumber.value,
        ownerfile: req.swagger.params.ownerfile.value,
        facfile: req.swagger.params.facfile.value,
        _id: mongoose.Types.ObjectId(req.user.facId),
        userId: req.swagger.params.userId.value,
        userFacId: req.swagger.params.userFacId.value,
        stateCode: req.swagger.params.stateCode.value,
        googleLink: req.swagger.params.googleLink.value,
        twilioTollFreeNumber: req.swagger.params.twilioTollFreeNumber.value,
    }
    waterfall([
        function (callback) { //check email and facility name is already exist
            User.findOne({
                email: facObj.email.trim().toLowerCase(),
                _id: {
                    $ne: facObj.userId
                },
                isDelete: false
            }).lean().exec(function (err, userData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (userData) {
                        res.json({
                            code: config.statusCode.badRequest,
                            data: {},
                            message: i18n.__("EMAIL_ALREADY_EXIST")
                        });
                    } else {
                        Facility.findOne({
                            facName: facObj.facName,
                            _id: {
                                $ne: mongoose.Types.ObjectId(facObj._id)
                            },
                            isDelete: false
                        }).lean().exec(function (err, facData) {
                            if (err) {
                                callback(err, false);
                            } else {
                                if (facData) {
                                    res.json({
                                        code: config.statusCode.badRequest,
                                        data: {},
                                        message: i18n.__("FACILITY_ALREADY_EXIST")
                                    });
                                } else {
                                    callback(null, finalResponse);
                                }
                            }
                        });
                    }
                }
            });
        },
        function (finalResponse, callback) { //Update user record
            User.findById(facObj.userId).exec(function (err, data) {
                if (err) {
                    callback(err, false);
                } else {
                    data.firstName = facObj.firstName;
                    data.lastName = facObj.lastName;
                    data.userName = facObj.firstName + ' ' + facObj.lastName,
                    data.email = facObj.email;
                    data.phoneNumber = facObj.phoneNumber;
                    data.modifiedBy = config.role_type.FACILITY_ADMIN.name;
                    data.modifiedById = req.user.uid;
                    data.save(function (err, updatedUserData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.userData = updatedUserData;
                            if (facObj.ownerfile) { //Update logo if exist
                                var timestamp = Number(new Date()); // current time as number
                                var file = facObj.ownerfile;
                                var userId = data._id;
                                var splitFileName = file.originalname.split('.');
                                var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                                var filename = userId + '_' + timestamp + '.' + ext;
                                var imagePath = "./../client/src/assets/upload/profiles/" + filename;
                                var base_url = config.server_url;

                                utility.fileUpload(path.resolve(imagePath), file.buffer).then(function () {
                                    data.image = filename;
                                    data.save(function (err, updateProfileImage) {
                                        if (err) {
                                            callback(err, false);
                                        } else {
                                            callback(null, finalResponse);
                                        }
                                    })
                                })
                            } else {
                                callback(null, finalResponse);
                            }
                        }
                    })
                }
            });
        },
        function (finalResponse, callback) { //Update facility record
            Facility.findById(facObj._id).exec(function (err, facData) {
                if (err) {
                    callback(err, false);
                } else {
                    facData.facName = facObj.facName;
                    facData.address = facObj.address;
                    facData.city = facObj.city;
                    facData.state = facObj.state;
                    facData.country = facObj.country;
                    facData.zipCode = facObj.zipCode;
                    facData.stateCode = facObj.stateCode;
                    facData.googleLink = facObj.googleLink,
                    facData.twilioTollFreeNumber = facObj.twilioTollFreeNumber
                    facData.save(function (err, updatefacData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            if (facObj.facfile) { //Update logo if exist
                                var timestamp = Number(new Date()); // current time as number
                                var file = facObj.facfile;
                                var facilityId = facData._id;
                                var splitFileName = file.originalname.split('.');
                                var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                                var filename = facilityId + '_' + timestamp + '.' + ext;
                                var imagePath = "./../client/src/assets/upload/profiles/" + filename;
                                var base_url = config.server_url;

                                utility.fileUpload(path.resolve(imagePath), file.buffer).then(function () {
                                    facData.facLogo = filename;
                                    facData.save(function (err, updateFacLogo) {
                                        if (err) {
                                            callback(err, false);
                                        } else {
                                            callback(null, finalResponse);
                                        }
                                    })
                                })
                            } else {
                                callback(null, finalResponse);
                            }
                        }
                    })
                }
            });
        },
        function (finalResponse, callback) { //Update user facility record
            UserFacility.findOne({
                _id: facObj.userFacId
            }).exec(function (err, foundUserFacilityData) {
                if (err) {
                    callback(err, false);
                } else {
                    foundUserFacilityData.userId = finalResponse.userData._id;
                    foundUserFacilityData.facilityId = facObj._id;
                    foundUserFacilityData.save(function (err, updateUserFacData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    })
                }
            })
        },
        function (finalResponse, callback) { //Update rating and response setting for online review link
            FacilityRatingResponseSettings.findOneAndUpdate({ userFacId: facObj.userFacId, isDelete: false, status: true }, {
                $set: {
                    "positive.googleLink": facObj.googleLink
                }
            }, function (err, updatedRatingResponseSetting) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("UPDATED_SUCCESSFULLY")
            });
        }
    });

}

/**
 * Function is use to getLoginDetails
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 09-June-2018
 */


function getLoginDetails(req, res) {
    var finalResponse = {};
    finalResponse.loginData = {};
    console.log("req.query.id", req.query.id);
    waterfall([
        function (callback) { //get login details
            var condition = {
                isDelete: false,
                _id: mongoose.Types.ObjectId(req.query.id)
            };
            User.findOne(condition, {
                password: 0,
                updatedAt: 0,
                createdAt: 0,
                verifyToken: 0
            }).lean().exec(function (err, loginData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.loginData = loginData;
                    console.log("finalResponse", finalResponse);
                    callback(null, finalResponse);
                }
            })
        },
        function (finalResponse, callback) {
            var subLoginData = {};
            var sbLoginData;
            subLoginData.loginId = finalResponse.loginData._id,
                subLoginData.name = finalResponse.loginData.userName
            var subLoginInfo = new SubLogin(subLoginData);
            subLoginInfo.save(function (err, sbLoginDetails) {
                if (err) {
                    callback(err, false);
                } else {
                    sbLoginData = sbLoginDetails
                    UserFacility.findOne({
                        userId: finalResponse.loginData._id
                    }).lean().populate('facilityId', 'userCmpId twilioTollFreeNumber').exec(function (err, userFacData) {
                        if (err) {
                            res.json({
                                code: config.statusCode.error,
                                data: {},
                                message: i18n.__("INTERNAL_ERROR")
                            });
                        } else {
                            // console.log("userFacData", userFacData);
                            var tokenData = {
                                "uid": finalResponse.loginData._id,
                                "userName": finalResponse.loginData.userName,
                                "role": finalResponse.loginData.role,
                                "image": finalResponse.loginData.image,
                                "email": finalResponse.loginData.email,
                                "firstName": finalResponse.loginData.firstName,
                                "lastName": finalResponse.loginData.lastName,
                                "phoneNumber": finalResponse.loginData.phoneNumber,
                                "userFacId": userFacData._id,
                                "facId": userFacData.facilityId._id,
                                "twilioTollFreeNumber": userFacData.facilityId.twilioTollFreeNumber,
                                "userCmpId": userFacData.facilityId.userCmpId
                            };
                            var expirationDuration = 60 * 60 * 24 * 15; // expiration duration format sec:min:hour:day. ie: 8 Hours as per i/p
                            var jwtToken = jwt.sign(tokenData, config.secret, {
                                expiresIn: expirationDuration
                            });
                            var userObj = {};
                            userObj.token = jwtToken;
                            userObj.lastLoginDate = new Date();
                            User.update({
                                _id: finalResponse.loginData._id
                            }, {
                                $set: userObj
                            }, function (err, updatedUserData) {
                                var usData = {
                                    'user': tokenData,
                                    'sublogin': sbLoginData,
                                    'token': jwtToken
                                }
                                finalResponse.usData = usData;
                                callback(null, finalResponse);
                            })
                        }
                    })

                }
            })
        }

    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: finalResponse.usData,
                message: i18n.__("LOGGED_IN_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to add todays checklist of facilities
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 02-July-2018
 */
function addFacilitiesTodaysCheckList(req, res) {
    var finalResponse = {};
    finalResponse.facArray = [];
    waterfall([
        function (callback) { //find all the facilities

            var condition = {};
            condition.isDelete = false;
            condition['userFacInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;

            var aggregate = [{
                    $lookup: {
                        from: 'userfacilities',
                        localField: "_id",
                        foreignField: "facilityId",
                        as: "userFacInfo"
                    }
                },
                {
                    $unwind: "$userFacInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userFacInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                }, {
                    $lookup: {
                        from: 'usercompanies',
                        localField: "userCmpId",
                        foreignField: "_id",
                        as: "userCmpInfo"
                    }
                },
                {
                    $unwind: "$userCmpInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "facName": "$facName",
                    "userId": "$userInfo._id",
                    "userFacId": "$userFacInfo._id"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Facility.aggregate(aggregate).then(function (facArray) {
                finalResponse.facArray = facArray;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Create facilities todays checklist 
            async.eachSeries(finalResponse.facArray, function (facData, next) {
                var checkListObj = {
                    userFacId: facData.userFacId,
                    checkNewNotifications: false,
                    revisitAndRespond: false,
                    reviewYesterdaysRatings: false,
                    thankPositiveRaters: false,
                    checkTheLatestReviews: false,
                    postToSocialMedia: false
                }
                var todaysCheckList = new TodaysCheckList(checkListObj);
                todaysCheckList.save(function (err, checkListData) {
                    if (err) {
                        next();
                    } else {
                        next();
                    }
                });
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })
        },
    ], function (err, data) {
        if (err) {} else {}
    });
}

/**
 * Function is use to get facility todays checklist
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 02-July-2018
 */
function getFacilityTodaysChecklist(req, res) {
    var condition = {};
    var todayDate = req.body.todayDate;
    var start_day_date = moment(todayDate).startOf('day');
    var end_day_date = moment(todayDate).endOf('day');
    var momentObjFrom = new Date(moment(start_day_date));
    var momentObjTo = new Date(moment(end_day_date));
    condition.userFacId = req.user.userFacId;
    condition.isDelete = false;
    condition.status = true;
    condition.$and = [{
            createdAt: {
                $gte: momentObjFrom
            }
        },
        {
            createdAt: {
                $lte: momentObjTo
            }
        }
    ];

    TodaysCheckList.findOne(condition).exec(function (err, todaysCheckList) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else if (todaysCheckList) {
            res.json({
                code: config.statusCode.success,
                data: todaysCheckList,
                message: i18n.__("LOGGED_IN_SUCCESSFULLY")
            });
        } else {
            res.json({
                code: config.statusCode.notFound,
                data: {},
                message: i18n.__("NO_RECORD_FOUND")
            });
        }
    })

}

/**
 * Function is use to update facility todays checklist
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 02-July-2018
 */
function updateTodaysCheckList(req, res) {
    TodaysCheckList.findOneAndUpdate({
        _id: mongoose.Types.ObjectId(req.body._id),
        userFacId: mongoose.Types.ObjectId(req.body.userFacId),
        status: true,
        isDelete: false
    }, {
        $set: {
            checkNewNotifications: req.body.checkNewNotifications,
            revisitAndRespond: req.body.revisitAndRespond,
            reviewYesterdaysRatings: req.body.reviewYesterdaysRatings,
            thankPositiveRaters: req.body.thankPositiveRaters,
            checkTheLatestReviews: req.body.checkTheLatestReviews,
            postToSocialMedia: req.body.postToSocialMedia
        }
    }, function (err, updatedTodaysCheckList) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            if (!updatedTodaysCheckList) {
                res.json({
                    code: config.statusCode.unauthorized,
                    data: {},
                    message: i18n.__("UNAUTHORIZED")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: {},
                    message: i18n.__("UPDATED_SUCCESSFULLY")
                });
            }
        }
    });
}


/**
 * Function is use to Save Notes of Facility
 * @access private
 * @return json
 * Created by VishakaR
 * @smartData Enterprises (I) Ltd
 * Created Date 05-July-2018
 */

function saveFacilityNotes(req, res) {

    var finalResponse = {};
    var NotesObj = {
        userFacId: req.user.userFacId,
        notes: req.body.notes
    }
    if (!NotesObj.userFacId) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } {
        waterfall([
            function (callback) { //check phone Num is already exist
                NotesMessage.findOne({
                    userFacId: req.user.userFacId,
                    isDelete: false
                }).lean().exec(function (err, Notes) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (Notes) {

                            NotesMessage.findOneAndUpdate({
                                userFacId: req.user.userFacId
                            }, {
                                $set: {
                                    notes: req.body.notes
                                }
                            }, function (err, updatedUserdata) {
                                if (err) {
                                    callback(err, false);
                                } else {
                                    callback(null, finalResponse);
                                }
                            });
                        } else {
                            var notesInfo = {};
                            notesInfo.userFacId = req.user.userFacId;
                            notesInfo.notes = req.body.notes;
                            var notesSave = new NotesMessage(notesInfo);
                            notesSave.save(function (err, notesSaveData) {
                                if (err) {
                                    callback(err, false);
                                } else {
                                    callback(null, finalResponse);
                                }
                            });
                        }
                    }
                });
            },
        ], function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: data,
                    message: i18n.__("Your message has been saved!")
                });
            }
        });
    }
}


/**
 * Function is use to get Saved Notes by facility
 * @access private
 * @return json
 * Created by VishakaR
 * @smartData Enterprises (I) Ltd
 * Created Date 05-July-2018
 */


function getNotesDetails(req, res) {

    var finalResponse = {};
    finalResponse.notesCount = 0;
    finalResponse.notesDetails = {};
    waterfall([
        function (callback) { //get Message Count
            var condition = {
                isDelete: false,
                userFacId: mongoose.Types.ObjectId(req.user.userFacId)
            };
            NotesMessage.find(condition).count().exec(function (err, notesCount) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.notesCount = notesCount;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //get Message Details
            var condition = {};
            condition.isDelete = false;
            condition.userFacId = mongoose.Types.ObjectId(req.user.userFacId);

            NotesMessage.find(condition).sort({
                createdAt: -1
            }).exec(function (err, notesDetails) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.notesDetails = notesDetails;
                    callback(null, finalResponse);

                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}