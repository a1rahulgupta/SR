'use strict';

var mongoose = require('mongoose'),
    waterfall = require('async-waterfall'),
    asyncSeries = require('async'),
    async = require('asyncawait/async'),
    await = require('asyncawait/await'),
    i18n = require("i18n"),
    moment = require('moment'),
    parse = require('url-parse'),
    urlExists = require('url-exists'),
    FacilityReviewPlatform = mongoose.model('facilityReviewPlatform'),    
    FacilityReview = mongoose.model('facilityReview'),    
    GoogleCredential = mongoose.model('googleCredential'),  
    GoogleAccountLocation = mongoose.model('googleAccountLocation'),        
    request = require('request'),
    cheerio = require('cheerio'),
    puppeteer = require('puppeteer'),
    config = require('../../config/config.js');
    const {google} = require('googleapis');
    const url = require('url');
    const querystring = require('querystring');
    const opn = require('opn');
    var oauth2Client = {};
    var GMB = require('google_my_business');
    var open = require("open");    

module.exports = {
    getFacilityReviewPlatforms: getFacilityReviewPlatforms,
    searchReviewPlatformPage: searchReviewPlatformPage,
    getFacilityCitehealthReviews: getFacilityCitehealthReviews,
    getGoogleCredentials: getGoogleCredentials,
    addGoogleCredentials: addGoogleCredentials,
    updateGoogleCredentials: updateGoogleCredentials,
    getGoogleCredentialsById: getGoogleCredentialsById,
    activateGoogleCredentials: activateGoogleCredentials,
    checkGoogleAuthorizeOAuth: checkGoogleAuthorizeOAuth,
    searchGoogleReviewPlatformBusiness: searchGoogleReviewPlatformBusiness,
    getFacilityGoogleReviews: getFacilityGoogleReviews,
    searchCaringReviewPlatformPage: searchCaringReviewPlatformPage,
    getFacilityCaringReviews: getFacilityCaringReviews,
    searchSeniorAdvisorReviewPlatformPage: searchSeniorAdvisorReviewPlatformPage,
    getFacilitySeniorAdvisorReviews: getFacilitySeniorAdvisorReviews,
    searchLocalNursingHomeReviewPlatformPage: searchLocalNursingHomeReviewPlatformPage,
    getFacilityLocalNursingHomeReviews: getFacilityLocalNursingHomeReviews,
    searchNursingHomeSiteReviewPlatformPage: searchNursingHomeSiteReviewPlatformPage,
    searchFamilyAssetsReviewPlatformPage: searchFamilyAssetsReviewPlatformPage,
    getFacilityYelpReviews: getFacilityYelpReviews,
    searchYelpReviewPlatformPage: searchYelpReviewPlatformPage,
    getFacilitySuperPagesReviews: getFacilitySuperPagesReviews,
    searchSuperPagesReviewPlatformPage: searchSuperPagesReviewPlatformPage,
    getFacilityYellowPagesReviews: getFacilityYellowPagesReviews,
    searchYellowPagesReviewPlatformPage: searchYellowPagesReviewPlatformPage,
    getFacilityAgingCareReviews: getFacilityAgingCareReviews,
    searchAgingCareReviewPlatformPage: searchAgingCareReviewPlatformPage,
    getFacilityIndeedReviews: getFacilityIndeedReviews,
    searchIndeedReviewPlatformPage: searchIndeedReviewPlatformPage,
    searchWellnessReviewPlatformPage: searchWellnessReviewPlatformPage,
    getFacilityWellnessReviews: getFacilityWellnessReviews

}

/**
 * Function is use to get facility review platforms
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 18-Sep-2018
 */
function getFacilityReviewPlatforms(req, res) {
    var finalResponse = {};
    finalResponse.google = {
        status: false
    };
    finalResponse.citeHealth = {
        status: false        
    };
    finalResponse.caring = {
        status: false        
    };
    finalResponse.seniorAdvisor = {
        status: false        
    };
    finalResponse.localNursingHomes = {
        status: false        
    };
    finalResponse.nursingHomeSite = {
        status: false        
    };
    finalResponse.familyAssets = {
        status: false        
    };
    finalResponse.yelp = {
        status: false
    };
    finalResponse.superPages = {
        status: false
    };
    finalResponse.yellowPages = {
        status: false
    };
    finalResponse.agingCare = {
        status: false
    };
    finalResponse.indeed = {
        status: false
    };
    finalResponse.wellness = {
        status: false
    };
    finalResponse.facebook = {
        status: false
    };
    
    var condition = {
        userFacId: mongoose.Types.ObjectId(req.user.userFacId),
        isDelete: false
    }
    
    FacilityReviewPlatform.find(condition, function(err, facilityReviewArray) { //Get facility review platform
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            asyncSeries.eachSeries(facilityReviewArray, function(facilityReview, next){                
                if(facilityReview.platformName == config.reviewPlatformName.GOOGLE.name){
                    finalResponse.google = facilityReview;
                }else if(facilityReview.platformName == config.reviewPlatformName.CITEHEALTH.name){
                    finalResponse.citeHealth = facilityReview;
                }else if(facilityReview.platformName == config.reviewPlatformName.CARING.name){
                    finalResponse.caring = facilityReview;
                }else if(facilityReview.platformName == config.reviewPlatformName.SENIOR_ADVISOR.name){
                    finalResponse.seniorAdvisor = facilityReview;
                }else if(facilityReview.platformName == config.reviewPlatformName.LOCAL_NURSING_HOMES.name){
                    finalResponse.localNursingHomes = facilityReview;
                }else if(facilityReview.platformName == config.reviewPlatformName.NURSING_HOME_SITE.name){
                    finalResponse.nursingHomeSite = facilityReview;
                }else if(facilityReview.platformName == config.reviewPlatformName.FAMILY_ASSETS.name){
                    finalResponse.familyAssets = facilityReview;
                }else if(facilityReview.platformName == config.reviewPlatformName.YELP.name){
                    finalResponse.yelp = facilityReview;                    
                }else if(facilityReview.platformName == config.reviewPlatformName.SUPER_PAGES.name){
                    finalResponse.superPages = facilityReview;                    
                }else if(facilityReview.platformName == config.reviewPlatformName.YELLOW_PAGES.name){
                    finalResponse.yellowPages = facilityReview;                    
                }else if(facilityReview.platformName == config.reviewPlatformName.AGINGCARE.name){
                    finalResponse.agingCare = facilityReview;                    
                }else if(facilityReview.platformName == config.reviewPlatformName.INDEED.name){
                    finalResponse.indeed = facilityReview;                    
                }else if(facilityReview.platformName == config.reviewPlatformName.WELLNESS.name){
                    finalResponse.wellness = facilityReview;                    
                }else if(facilityReview.platformName == config.reviewPlatformName.FACEBOOK.name){
                    finalResponse.facebook = facilityReview;
                }
                next();
            },function(err){
                if(err){
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                }else{
                    res.json({
                        code: config.statusCode.success,
                        data: finalResponse,
                        message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                    });
                }
            })
        }
    });
}

/**
 * Function is use to search review platform page exist or not
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 19-Sep-2018
 */
function searchReviewPlatformPage(req, res) {
    var finalResponse = {};
    finalResponse.parsed = {};
    finalResponse.facRevPlatData = {};
    finalResponse.overAllRating = 0;
    finalResponse.outOfRating = 0;
    finalResponse.totalReviewCount = 0;
    finalResponse.reviews = [];

    waterfall([
        function (callback) { //parse the url and check it having a valid protocol 
            finalResponse.parsed = parse(req.body.pageUrl);
            if(finalResponse.parsed.protocol != 'https:'){
                res.json({
                    code: config.statusCode.invalid,
                    data: {},
                    message: i18n.__("INVALID_PAGE")
                });
            }else{
                callback(null, finalResponse);
            }
        },
        function (finalResponse, callback) { //Check url request is from valid platform
            switch (req.body.platform) {
                case config.reviewPlatformName.CITEHEALTH.name:
                    if(finalResponse.parsed.hostname != config.reviewPlatformName.CITEHEALTH.hostname){
                        res.json({
                            code: config.statusCode.invalid,
                            data: {},
                            message: i18n.__("INVALID_PLATFORM_PAGE")
                        });    
                    }else{
                        callback(null, finalResponse);        
                    }
                    break;
                case config.reviewPlatformName.GOOGLE.name:
                    if(finalResponse.parsed.hostname != config.reviewPlatformName.GOOGLE.hostname){
                        res.json({
                            code: config.statusCode.invalid,
                            data: {},
                            message: i18n.__("INVALID_PLATFORM_PAGE")
                        });    
                    }else{
                        callback(null, finalResponse);
                    }
                    break;
            }
        },
        function (finalResponse, callback) { //Check Url existance
            urlExists(req.body.pageUrl, function(err, exists) {
                if(err){
                    callback(err, false);
                }else if(exists == false){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PAGE")
                    });
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Save facility review platform
            var reviewPlatform = {
                platformName: req.body.platform,
                scrapeUrl: req.body.pageUrl,
                userFacId: req.user.userFacId,
                userCmpId: req.user.userCmpId
            }
            var facilityReviewPlatform = new FacilityReviewPlatform(reviewPlatform);
            facilityReviewPlatform.save(function (err, facRevPlatData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.facRevPlatData = facRevPlatData;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Scrape the web url
            request(finalResponse.facRevPlatData.scrapeUrl, function(error, response, html){
                if(!error && response.statusCode == 200){
                    
                    const $ = cheerio.load(html);
                    finalResponse.overAllRating = $('.pad > .sml strong').find('span[itemprop="ratingValue"]').text();
                    finalResponse.outOfRating = $('.pad > .sml').find('span[itemprop="bestRating"]').text();
                    finalResponse.totalReviewCount = $('.pad > .sml strong').find('span[itemprop="reviewCount"]').text();

                    $('.easy-click').each((i, el) => {
                        var reviewDate = $(el).find('.easy-click > .box > .body > .right dl').find('dd[itemprop="datePublished"]').text();
                        reviewDate = new Date(reviewDate);
                        var reviewId = Number(reviewDate); // review time as number for review identification for a platform
                        var reviewObj = {
                            rating: $(el).find('.easy-click > .box > .body > .right dl dd').first().find('img[alt="Full Star"]').length,
                            review: $(el).find('.easy-click > .box > .body > .right dl dd').find('p[itemprop="reviewBody"]').text(),
                            author: $(el).find('.easy-click > .box > .body > .right dl').find('dd[itemprop="author"]').text(),
                            reviewDate: reviewDate,
                            reviewId: reviewId,
                            facRevPlatId: finalResponse.facRevPlatData._id,
                            platformName: finalResponse.facRevPlatData.platformName,
                            scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                            userFacId: finalResponse.facRevPlatData.userFacId,
                            userCmpId: finalResponse.facRevPlatData.userCmpId,
                            outOfRating: finalResponse.outOfRating,
                            reviewUrl: finalResponse.parsed.origin+$(el).prop('href')
                        }
                        finalResponse.reviews.push(reviewObj);
                    })
                    callback(null, finalResponse);
                }else{
                    callback(err, false);
                }
            })
        },
        function (finalResponse, callback) { //Save the facility platform reviews
            asyncSeries.eachSeries(finalResponse.reviews, function (facReview, next) {
                var facilityReview = FacilityReview(facReview);
                facilityReview.save(function(err, savedData){
                    if(err){
                        callback(err, false);
                    }else{
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    FacilityReviewPlatform.findOneAndUpdate({
                        _id: mongoose.Types.ObjectId(finalResponse.facRevPlatData._id) 
                    }, {
                        $set: {
                            overAllRating: finalResponse.overAllRating,
                            outOfRating: finalResponse.outOfRating,
                            totalReviews: finalResponse.totalReviewCount
                        }
                    }, function (err, updatedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                }
            })  
        },
    ], function (err, data) {
        if(err){
            console.log("error@", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        }else{
            res.json({
                code: config.statusCode.success,
                data: finalResponse,
                message: i18n.__("PAGE_SEARCHED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get facility citihealth review
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 19-Sep-2018
 */
function getFacilityCitehealthReviews(req, res) {

    var condition = {
        userFacId: mongoose.Types.ObjectId(req.user.userFacId),
        isDelete: false,
        platformName: config.reviewPlatformName.CITEHEALTH.name
    }
    
    FacilityReview.find(condition, function(err, facilityReviewArray) { //Get facility reviews
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: facilityReviewArray,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get google credentials 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 21-Sep-2018
 */
function getGoogleCredentials(req, res) {
    GoogleCredential.find({
        status: true,
        is_deleted: false
    }, function (err, settingData) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        } else {
            res.json({
                code: config.statusCode.success,
                data: settingData,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    }).catch(function (err) {
        res.json({
            code: config.statusCode.error,
            data: {},
            message: i18n.__("ERROR")
        })

    });
}

/**
 * Function is use to add google credentials 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 21-Sep-2018
 */
function addGoogleCredentials(req, res) {
    GoogleCredential.findOneAndUpdate({
        status: true,
        is_deleted: false
    }, {
        $set: {
            status: false
        }
    }, function (err, data) {
        if (err) {
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        } else {
            var obj = {
                account_title: req.body.account_title.trim(),
                client_id: req.body.client_id.trim(),
                client_secret: req.body.client_id.trim()
            }
            var googleCredential = new GoogleCredential(obj);
            googleCredential.status = true;
            googleCredential.save(function (err, settingNewData) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: settingNewData,
                        message: i18n.__("KEY_SAVE_SUCCESSFULLY")
                    });
                }
            }).catch(function (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })

            });
        }
    })
}

/**
 * Function is use to update google credentials  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 21-Sep-2018
 */
function updateGoogleCredentials(req, res) {
    GoogleCredential.findOneAndUpdate({
        _id: mongoose.Types.ObjectId(req.body._id),
        status: true,
        is_deleted: false
    }, {
        status: false,
        isActivate: false
    }, {
        new: true
    }, function (err, settingData) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        } else if (!settingData) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        } else {
            var googleCredential = new GoogleCredential();
            googleCredential.client_id = req.body.client_id;
            googleCredential.client_secret = req.body.client_secret;
            googleCredential.account_title = req.body.account_title;
            googleCredential.save(function (err, savedData) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: savedData,
                        message: i18n.__("KEY_UPDATED_SUCCESSFULLY")
                    });
                }
            })
        }
    })
}

/**
 * Function is use to get google credentials by id 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 21-Sep-2018
 */
function getGoogleCredentialsById(req, res) {
    if (mongoose.Types.ObjectId.isValid(req.query.id)) {
        GoogleCredential.findOne({
            _id: mongoose.Types.ObjectId(req.query.id),
            status: true,
            is_deleted: false
        }, function (err, googleCredentialsData) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: googleCredentialsData,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }
        }).catch(function (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
    
        });
    }else {
        res.json({
            code: config.statusCode.invalid,
            data: {},
            message: i18n.__("INVALID_URL")
        });
    }
}

/**
 * Function is use to activate google credentials and verify google Oauth2 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 21-Sep-2018
 */
function activateGoogleCredentials(req, res) {
    GoogleCredential.findById(req.body.id).exec(function (err, googleCredentialsData) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        } else {
            verifyGoogleOAuth(googleCredentialsData);
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    })
}

/**
 * Function is use to verify oauth2
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 21-Sep-2018
 */
function verifyGoogleOAuth(googleCredentialsData) {
    oauth2Client = new google.auth.OAuth2(
        googleCredentialsData.client_id,
        googleCredentialsData.client_secret,
        'https://www.signin-repute.com/admin/setting/googleList'
        // config.googleConfig.redirect_uri
    );

    const url = oauth2Client.generateAuthUrl({
        // 'online' (default) or 'offline' (gets refresh_token)
        access_type: 'offline',
        
        // If you only need one scope you can pass it as a string
        scope: config.googleConfig.scope,
        
        // every time, forcing a refresh_token to be returned.
        prompt: 'consent'
    });
    
    console.log("url",url, config.googleConfig.redirect_uri);
    // open(url).then((res) => {
    //         console.info(res);
    //     }, (err) => {
    //         console.error(err);
    //     });;
    opn(url).then((res) => {
        console.info(res);
    }, (err) => {
        console.error(err);
    });
    console.log("Done checkGoogleAuthorizeOAuth");
}


/**
 * Function is use to verify oauth2
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 21-Sep-2018
 */
function checkGoogleAuthorizeOAuth(req, res) {
    console.log("checkGoogleAuthorizeOAuth", req.body.code);
    GoogleCredential.findOne({ is_deleted: false, status: true, isActivate: false }).sort({
        createdAt: -1
    }).exec(function (err, googleCredentialsData) {
        if (err) {
            console.log("sadasdasdasda11111", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        } else {
            // console.log("googleCredentialsData", googleCredentialsData);
            var getAccessRefreshToken = async (function() {
                try {
                    const r = await (oauth2Client.getToken(req.body.code));
                    if(r.res && r.res.status == 200){
                        oauth2Client.setCredentials(r.tokens);
                        GoogleCredential.findOneAndUpdate({
                            _id: googleCredentialsData._id
                        }, {
                            $set: {
                                code: req.body.code,
                                access_token: r.tokens.access_token,
                                refresh_token: r.tokens.refresh_token,
                                expiry_date: new Date(r.tokens.expiry_date),
                                isActivate: true,
                            }
                        },
                        {
                            new: true
                        }, 
                        function (err, updateGoogleCredentials) {
                            if (err) {
                                console.log("sadasdasdasda222222",err);
            
                                res.json({
                                    code: config.statusCode.error,
                                    data: {},
                                    message: i18n.__("ERROR")
                                })
                            } else {
                                getAccountAndLocations(updateGoogleCredentials);
                                res.json({
                                    code: config.statusCode.success,
                                    data: {},
                                    message: i18n.__("CREDENTIALS_ACTIVATED_SUCCESSFULLY_REVIEW_FETCHING_ONE_HOUR")
                                });
                            }
                        });
                    }else{
                        res.json({
                            code: config.statusCode.badRequest,
                            data: {},
                            message: i18n.__("NOT_ACTIVATED_TRY_AGAIN")
                        })
                    }   
                } catch (error) {
            console.log("sadasdasdasda333333", error.message);
            
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                }
            });    

            getAccessRefreshToken();   
        }
    })
}

/**
 * Function is use to get account and locations
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 22-Sep-2018
 */
function getAccountAndLocations(updateGoogleCredentials) {
    console.log("updateGoogleCredentials", updateGoogleCredentials, '\n');
    var accountInfo = {};
    //Get account info
    GMB.options({version: 'v4'});
    GMB.setAccessToken(updateGoogleCredentials.access_token);
    GMB.api('accounts', 'get', {}, function (res) {
        // console.log("typeof", typeof(res));        
        var response = JSON.parse(res);
        if(response.error){
            console.log("swdfsf erororpr", response.error);
        }else{
            accountInfo = response.accounts[0];
            console.log("response success: ", accountInfo)
            var locationUrl = accountInfo.name+'/locations'
            GMB.api(locationUrl, 'get', {}, function (res) {
                console.log("typeof", typeof(res));        
                var response = JSON.parse(res);
                if(response.error){
                    console.log("location erororpr", response.error);
                }else{
                    // accountInfo = response.accounts[0];
                    console.log("location response success: ", response);
                    GoogleCredential.findOneAndUpdate({
                        _id: updateGoogleCredentials._id
                    }, {
                        $set: {
                            account_name: accountInfo.name,
                            accountName: accountInfo.accountName,
                            totalSize: response.totalSize
                        }
                    },function (err, updateGoogleCred) {
                        if (err) {} else {
                            asyncSeries.eachSeries(response.locations, function(location, next){
                                var obj = {
                                    googleCredentialId: updateGoogleCredentials._id,
                                    locationName: location.locationName,
                                    location_name: location.name,
                                    websiteUrl: location.websiteUrl,
                                    regularHours: location.regularHours,
                                    serviceArea: location.serviceArea,
                                    locationKey: location.locationKey,
                                    latlng: location.latlng,
                                    openInfo: location.openInfo,
                                    locationState: location.locationState,
                                    metadata: location.metadata,
                                    languageCode: location.languageCode,
                                    address: location.address
                                }
                                var googleAccountLocation = new GoogleAccountLocation(obj);
                                googleAccountLocation.save(function(err, savedData){
                                    if(err){
                                        next();
                                    }else{
                                        next();
                                    }
                                })
                                //end save condition
                            },function(err){
                                if(err){}else{}
                            })   
                        }
                    });
                }
            });    
        }
    });
}

/**
 * Function is use to search google business 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 22-Sep-2018
 */
function searchGoogleReviewPlatformBusiness(req, res) {
    var finalResponse = {};
    finalResponse.locationData = {};
    finalResponse.googleCredentialsData = {};
    finalResponse.updatedGoogleCredentials = {};
    finalResponse.reviews = {};
    finalResponse.facRevPlatData = {};
    finalResponse.averageRating = 0;
    finalResponse.totalReviewCount = 0;

    waterfall([
        function (callback) { //check the business exist 
            GoogleAccountLocation.findOne({ 
                locationName: new RegExp('^'+ req.body.businessName.trim() + '$', "i"),
                is_deleted: false,
                status: true
            }).exec(function(err, accountLocationData){
                if(err){
                    callback(err, false)
                }else if(accountLocationData == null || accountLocationData == undefined){
                    res.json({
                        code: config.statusCode.notFound,
                        data: {},
                        message: i18n.__("BUSINESS_NOT_FOUND")
                    });
                }else{
                    console.log("account: ", accountLocationData);
                    finalResponse.locationData = accountLocationData;
                    callback(null, finalResponse);
                }
            })
        },
        function (finalResponse, callback) { //get access token and reviews 
            GoogleCredential.findOne({
                is_deleted: false, 
                status: true, isActivate: true 
            }).exec(function (err, googleCredentialsData) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                } else if(googleCredentialsData == null || googleCredentialsData == undefined) {
                    res.json({
                        code: config.statusCode.serviceUnavailable,
                        data: {},
                        message: i18n.__("SERVICE_UNAVAILABLE")
                    })
                }else{
                    finalResponse.googleCredentialsData = googleCredentialsData;
                    callback(null, finalResponse);
                }
            })
        },
        function (finalResponse, callback) { //Check Url existance
            var currentDate = new Date().toISOString();
            if(currentDate > finalResponse.googleCredentialsData.expiry_date){
                oauth2Client.refreshAccessToken(function(err, tokens) {
                    if(err){
                        callback(err, false);
                    }else{
                        oauth2Client.setCredentials(tokens);
                        GoogleCredential.findOneAndUpdate({
                            _id: mongoose.Types.ObjectId(finalResponse.googleCredentialsData._id)
                        }, {
                            $set: {
                                access_token: tokens.access_token,
                                refresh_token: tokens.refresh_token,
                                expiry_date: new Date(r.tokens.expiry_date)
                            }
                        },
                        {
                            new: true
                        }, 
                        function (err, updatedGoogleCredentials) {
                            if (err) {
                                callback(err, false);
                            } else {
                                finalResponse.googleCredentialsData = updatedGoogleCredentials;    
                                callback(null, finalResponse);
                            }
                        });
                    }
                });
            }else{
                callback(null, finalResponse);
            }
        },
        function (finalResponse, callback) { //get review specific to this business
            GMB.options({version: 'v4'});
            var access_token = finalResponse.googleCredentialsData.access_token;
            GMB.setAccessToken(access_token);
            var reviewUrl = finalResponse.locationData.location_name+'/reviews'
            GMB.api(reviewUrl, 'get', {}, function (res) {
                var response = JSON.parse(res);
                if(response.error) {
                    callback(err, false);
                }else{
                    console.log("reviews: ", response);
                    finalResponse.reviews = response.reviews;
                    finalResponse.totalReviewCount = response.totalReviewCount;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //save review platform for facility
            var reviewPlatform = {
                platformName: config.reviewPlatformName.GOOGLE.name,
                scrapeUrl: finalResponse.locationData.metadata.mapsUrl,
                userFacId: req.user.userFacId,
                userCmpId: req.user.userCmpId
            }
            var facilityReviewPlatform = new FacilityReviewPlatform(reviewPlatform);
            facilityReviewPlatform.save(function (err, facRevPlatData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.facRevPlatData = facRevPlatData;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Save the facility platform reviews
            asyncSeries.eachSeries(finalResponse.reviews, function (facReview, next) {
                var obj = {
                    facRevPlatId: finalResponse.facRevPlatData._id,
                    reviewId: facReview.reviewId,
                    platformName: finalResponse.facRevPlatData.platformName,
                    scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                    userFacId: finalResponse.facRevPlatData.userFacId,
                    userCmpId: finalResponse.facRevPlatData.userCmpId,
                    outOfRating: 5,
                    author: facReview.reviewer.displayName,
                    reviewDate: new Date(facReview.createTime),
                    updateDate: new Date(facReview.updateTime),
                    authorProfile: facReview.reviewer.profilePhotoUrl,
                    reviewer: facReview.reviewer,
                    review_name: facReview.name,

                }
                if(facReview.comment){
                    obj.review = facReview.comment;
                }
                if(facReview.starRating == 'FIVE'){
                    obj.rating = 5;
                }else if(facReview.starRating == 'FOUR'){
                    obj.rating = 4;
                }else if(facReview.starRating == 'THREE'){
                    obj.rating = 3;
                }else if(facReview.starRating == 'TWO'){
                    obj.rating = 2;
                }else if(facReview.starRating == 'ONE'){
                    obj.rating = 1;
                }
                var facilityReview = FacilityReview(obj);
                facilityReview.save(function(err, savedData){
                    if(err){
                        next();
                    }else{
                        finalResponse.averageRating = finalResponse.averageRating +  obj.rating
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.averageRating = (finalResponse.averageRating)/(finalResponse.totalReviewCount);
                    finalResponse.averageRating = parseFloat(finalResponse.averageRating).toFixed(2);
                    FacilityReviewPlatform.findOneAndUpdate({
                        _id: mongoose.Types.ObjectId(finalResponse.facRevPlatData._id) 
                    }, {
                        $set: {
                            overAllRating: finalResponse.averageRating,
                            outOfRating: 5,
                            totalReviews: finalResponse.totalReviewCount
                        }
                    }, function (err, updatedData) {
                        if (err) {
                            console.log(err);
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                }
            })  
        },
    ], function (err, data) {
        if(err){
            console.log("error1", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        }else{
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("BUSINESS_SEARCHED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get facility google review
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 22-Sep-2018
 */
function getFacilityGoogleReviews(req, res) {
    
    var condition = {
        userFacId: mongoose.Types.ObjectId(req.user.userFacId),
        isDelete: false,
        platformName: config.reviewPlatformName.GOOGLE.name
    }
    
    FacilityReview.find(condition, function(err, facilityReviewArray) { //Get facility reviews
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: facilityReviewArray,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to search caring review platform
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 24-Sep-2018
 */
function searchCaringReviewPlatformPage(req, res) {
    var finalResponse = {};
    finalResponse.parsed = {};
    finalResponse.facRevPlatData = {};
    finalResponse.overAllRating = 0;
    finalResponse.outOfRating = 0;
    finalResponse.totalReviewCount = 0;
    finalResponse.reviews = [];

    waterfall([
        function (callback) { //parse the url and check it having a valid protocol 
            finalResponse.parsed = parse(req.body.pageUrl);
            // console.log("finalResponse.parsed: ", finalResponse.parsed);
            if(finalResponse.parsed.protocol != 'https:'){
                res.json({
                    code: config.statusCode.invalid,
                    data: {},
                    message: i18n.__("INVALID_PAGE")
                });
            }else{ //Check url request is from valid platform
                if(finalResponse.parsed.hostname != config.reviewPlatformName.CARING.hostname){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PLATFORM_PAGE")
                    });    
                }else{
                    callback(null, finalResponse);        
                }
            }
        },
        function (finalResponse, callback) { //Check Url existance
            urlExists(req.body.pageUrl, function(err, exists) {
                if(err){
                    callback(err, false);
                }else if(exists == false){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PAGE")
                    });
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Save facility review platform
            var reviewPlatform = {
                platformName: config.reviewPlatformName.CARING.name,
                scrapeUrl: req.body.pageUrl,
                userFacId: req.user.userFacId,
                userCmpId: req.user.userCmpId
            }
            var facilityReviewPlatform = new FacilityReviewPlatform(reviewPlatform);
            facilityReviewPlatform.save(function (err, facRevPlatData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.facRevPlatData = facRevPlatData;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Scrape the web url
            request(finalResponse.facRevPlatData.scrapeUrl, function(error, response, html){
                if(!error && response.statusCode == 200){
                    
                    const $ = cheerio.load(html);
                    finalResponse.overAllRating = $('.rating').val();
                    finalResponse.outOfRating = 5;
                    var totalReviewCount = $('.inline-stars > .count').text();
                    totalReviewCount = totalReviewCount.split(" ");
                    finalResponse.totalReviewCount = totalReviewCount[0];

                    $('.featured-reviews > .review').each((i, el) => {
                        var reviewDate = $(el).find('.review > .hreview > .extra-info > .dtreviewed').text();
                        reviewDate = new Date(reviewDate.trim());
                        var reviewId = Number(reviewDate); // review time as number for review identification for a platform
                        var reviewObj = {
                            rating: $(el).find('.review > .hreview > .extra-info > .rating').text(),
                            review: $(el).find('.review > .hreview > .body-text > .description').text(),
                            author: $(el).find('.review > .hreview > .extra-info > .reviewer > .url > .fn').text(),
                            reviewDate: reviewDate,
                            reviewId: reviewId,
                            facRevPlatId: finalResponse.facRevPlatData._id,
                            platformName: finalResponse.facRevPlatData.platformName,
                            scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                            userFacId: finalResponse.facRevPlatData.userFacId,
                            userCmpId: finalResponse.facRevPlatData.userCmpId,
                            outOfRating: finalResponse.outOfRating,
                            reviewUrl: req.body.pageUrl,
                            title: $(el).find('.review > .hreview h4 strong').text()
                        }
                        finalResponse.reviews.push(reviewObj);
                    })

                    $('.other-reviews > .review').each((i, el) => {
                        var reviewDate = $(el).find('.review > .hreview > .extra-info > .dtreviewed').text();
                        reviewDate = new Date(reviewDate.trim());
                        var reviewId = Number(reviewDate); // review time as number for review identification for a platform
                        var reviewObj = {
                            rating: $(el).find('.review > .hreview > .extra-info > .rating').text(),
                            review: $(el).find('.review > .hreview > .body-text > .description').text(),
                            author: $(el).find('.review > .hreview > .extra-info > .reviewer > .url > .fn').text(),
                            reviewDate: reviewDate,
                            reviewId: reviewId,
                            facRevPlatId: finalResponse.facRevPlatData._id,
                            platformName: finalResponse.facRevPlatData.platformName,
                            scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                            userFacId: finalResponse.facRevPlatData.userFacId,
                            userCmpId: finalResponse.facRevPlatData.userCmpId,
                            outOfRating: finalResponse.outOfRating,
                            reviewUrl: req.body.pageUrl,
                            title: $(el).find('.review > .hreview h4 strong').text()
                        }
                        finalResponse.reviews.push(reviewObj);
                    })

                    callback(null, finalResponse);
                }else{
                    callback(err, false);
                }
            })
        },
        function (finalResponse, callback) { //Save the facility platform reviews
            asyncSeries.eachSeries(finalResponse.reviews, function (facReview, next) {
                var facilityReview = FacilityReview(facReview);
                facilityReview.save(function(err, savedData){
                    if(err){
                        callback(err, false);
                    }else{
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    FacilityReviewPlatform.findOneAndUpdate({
                        _id: mongoose.Types.ObjectId(finalResponse.facRevPlatData._id) 
                    }, {
                        $set: {
                            overAllRating: finalResponse.overAllRating,
                            outOfRating: finalResponse.outOfRating,
                            totalReviews: finalResponse.totalReviewCount
                        }
                    }, function (err, updatedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                }
            })  
        },
    ], function (err, data) {
        if(err){
            console.log("@error", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        }else{
            res.json({
                code: config.statusCode.success,
                data: finalResponse,
                message: i18n.__("PAGE_SEARCHED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get facility caring platform review
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 24-Sep-2018
 */
function getFacilityCaringReviews(req, res) {
    var condition = {
        userFacId: mongoose.Types.ObjectId(req.user.userFacId),
        isDelete: false,
        platformName: config.reviewPlatformName.CARING.name
    }
    
    FacilityReview.find(condition, function(err, facilityReviewArray) { //Get facility reviews
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: facilityReviewArray,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to search senior advisor platform
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 25-Sep-2018
 */
function searchSeniorAdvisorReviewPlatformPage(req, res) {
    var finalResponse = {};
    finalResponse.parsed = {};
    finalResponse.facRevPlatData = {};
    finalResponse.overAllRating = 0;
    finalResponse.outOfRating = 0;
    finalResponse.totalReviewCount = 0;
    finalResponse.reviews = [];

    waterfall([
        function (callback) { //parse the url and check it having a valid protocol 
            finalResponse.parsed = parse(req.body.pageUrl);
            console.log("finalResponse.parsed: ", finalResponse.parsed);
            if(finalResponse.parsed.protocol != 'https:'){
                res.json({
                    code: config.statusCode.invalid,
                    data: {},
                    message: i18n.__("INVALID_PAGE")
                });
            }else{ //Check url request is from valid platform
                if(finalResponse.parsed.hostname != config.reviewPlatformName.SENIOR_ADVISOR.hostname){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PLATFORM_PAGE")
                    });    
                }else{
                    callback(null, finalResponse);        
                }
            }
        },
        function (finalResponse, callback) { //Check Url existance
            urlExists(req.body.pageUrl, function(err, exists) {
                if(err){
                    callback(err, false);
                }else if(exists == false){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PAGE")
                    });
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Save facility review platform
            var reviewPlatform = {
                platformName: config.reviewPlatformName.SENIOR_ADVISOR.name,
                scrapeUrl: req.body.pageUrl,
                userFacId: req.user.userFacId,
                userCmpId: req.user.userCmpId
            }
            var facilityReviewPlatform = new FacilityReviewPlatform(reviewPlatform);
            facilityReviewPlatform.save(function (err, facRevPlatData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.facRevPlatData = facRevPlatData;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Scrape the web url
            request(finalResponse.facRevPlatData.scrapeUrl, function(error, response, html){
                if(!error && response.statusCode == 200){
                    
                    const $ = cheerio.load(html);
                    finalResponse.overAllRating = $('span.text-hide').attr('data-rating');
                    finalResponse.overAllRating = parseFloat(finalResponse.overAllRating).toFixed(2);
                    finalResponse.outOfRating = 5;
                    finalResponse.totalReviewCount = $('#scroll-to-reviews').find('span').text();

                    $('.review').each((i, el) => {
                        var reviewDate = $(el).find('.review > .row > .col-sm-3 > .date > .posted').prop('content');
                        reviewDate = new Date(reviewDate.trim());
                        var reviewId = Number(reviewDate); // review time as number for review identification for a platform
                        var reviewObj = {
                            rating: $(el).find('.review > .list-inline > .metadata-rating > .text-hide').prop('data-rating'),
                            review: $(el).find('.review > .review-content p').text(),
                            author: $(el).find('.review > .list-inline > .metadata-author').clone()    //clone the element
                            .children() //select all the children
                            .remove()   //remove all the children
                            .end().text(),
                            reviewDate: reviewDate,
                            reviewId: reviewId,
                            facRevPlatId: finalResponse.facRevPlatData._id,
                            platformName: finalResponse.facRevPlatData.platformName,
                            scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                            userFacId: finalResponse.facRevPlatData.userFacId,
                            userCmpId: finalResponse.facRevPlatData.userCmpId,
                            outOfRating: finalResponse.outOfRating,
                            reviewUrl: req.body.pageUrl+'#'+$(el).prop('id'),
                            expSeniorAdvisor: $(el).find('.review > .row > .col-sm-9 > .lead').text()
                        }
                        var title = $(el).find('.review > .row > .col-sm-9 h3').text();
                        if(title !='' || title !=null || title !=undefined){
                            reviewObj.title = title.trim();
                        }else{
                            reviewObj.title = '';
                        }
                        finalResponse.reviews.push(reviewObj);
                    })
                    callback(null, finalResponse);
                }else{
                    callback(err, false);
                }
            })
        },
        function (finalResponse, callback) { //Save the facility platform reviews
            asyncSeries.eachSeries(finalResponse.reviews, function (facReview, next) {
                var facilityReview = FacilityReview(facReview);
                facilityReview.save(function(err, savedData){
                    if(err){
                        callback(err, false);
                    }else{
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    FacilityReviewPlatform.findOneAndUpdate({
                        _id: mongoose.Types.ObjectId(finalResponse.facRevPlatData._id) 
                    }, {
                        $set: {
                            overAllRating: finalResponse.overAllRating,
                            outOfRating: finalResponse.outOfRating,
                            totalReviews: finalResponse.totalReviewCount
                        }
                    }, function (err, updatedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                }
            })  
        },
    ], function (err, data) {
        if(err){
            console.log("@error", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        }else{
            res.json({
                code: config.statusCode.success,
                data: finalResponse,
                message: i18n.__("PAGE_SEARCHED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get facility senior advisor platform review
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 24-Sep-2018
 */
function getFacilitySeniorAdvisorReviews(req, res) {
    var condition = {
        userFacId: mongoose.Types.ObjectId(req.user.userFacId),
        isDelete: false,
        platformName: config.reviewPlatformName.SENIOR_ADVISOR.name
    }
    
    FacilityReview.find(condition, function(err, facilityReviewArray) { //Get facility reviews
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: facilityReviewArray,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to search local nursing homes platform
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Sep-2018
 */
function searchLocalNursingHomeReviewPlatformPage(req, res) {
    var finalResponse = {};
    finalResponse.parsed = {};
    finalResponse.facRevPlatData = {};
    finalResponse.overAllRating = 0;
    finalResponse.outOfRating = 0;
    finalResponse.totalReviewCount = 0;
    finalResponse.reviews = [];

    waterfall([
        function (callback) { //parse the url and check it having a valid protocol 
            finalResponse.parsed = parse(req.body.pageUrl);
            console.log("finalResponse.parsed: ", finalResponse.parsed);
            if(finalResponse.parsed.protocol != 'http:'){
                res.json({
                    code: config.statusCode.invalid,
                    data: {},
                    message: i18n.__("INVALID_PAGE")
                });
            }else{ //Check url request is from valid platform
                if(finalResponse.parsed.hostname != config.reviewPlatformName.LOCAL_NURSING_HOMES.hostname){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PLATFORM_PAGE")
                    });    
                }else{
                    callback(null, finalResponse);        
                }
            }
        },
        function (finalResponse, callback) { //Check Url existance
            urlExists(req.body.pageUrl, function(err, exists) {
                if(err){
                    callback(err, false);
                }else if(exists == false){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PAGE")
                    });
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Save facility review platform
            var reviewPlatform = {
                platformName: config.reviewPlatformName.LOCAL_NURSING_HOMES.name,
                scrapeUrl: req.body.pageUrl,
                userFacId: req.user.userFacId,
                userCmpId: req.user.userCmpId
            }
            var facilityReviewPlatform = new FacilityReviewPlatform(reviewPlatform);
            facilityReviewPlatform.save(function (err, facRevPlatData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.facRevPlatData = facRevPlatData;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Scrape the web url
            request(finalResponse.facRevPlatData.scrapeUrl, function(error, response, html){
                if(!error && response.statusCode == 200){
                    
                    const $ = cheerio.load(html);
                    finalResponse.overAllRating = $('.unstyled li').first().text();
                    finalResponse.overAllRating = finalResponse.overAllRating.trim().split(' ');
                    finalResponse.overAllRating = parseFloat(finalResponse.overAllRating).toFixed(2);
                    finalResponse.outOfRating = 5;

                    $('.span16 > .reviewSnippet').each((i, el) => {
                        finalResponse.totalReviewCount++;
                        var reviewDate = $(el).find('.snippetHeader a time').prop('datetime');
                        reviewDate = new Date(reviewDate.trim());
                        var reviewId = Number(reviewDate); // review time as number for review identification for a platform
                        var reviewObj = {
                            rating: $(el).find('.snippetHeader a span').find('span[itemprop="ratingValue"]').text(),
                            review: $(el).find('p').find('span[itemprop="reviewBody"]').text(),
                            author: $(el).find('meta:nth-child(3)').prop('content'),
                            reviewDate: reviewDate,
                            reviewId: reviewId,
                            facRevPlatId: finalResponse.facRevPlatData._id,
                            platformName: finalResponse.facRevPlatData.platformName,
                            scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                            userFacId: finalResponse.facRevPlatData.userFacId,
                            userCmpId: finalResponse.facRevPlatData.userCmpId,
                            outOfRating: finalResponse.outOfRating,
                            reviewUrl: $(el).find('meta:nth-child(2)').prop('content')
                        }
                        finalResponse.reviews.push(reviewObj);
                    })
                    callback(null, finalResponse);
                }else{
                    callback(err, false);
                }
            })
        },
        function (finalResponse, callback) { //Save the facility platform reviews
            asyncSeries.eachSeries(finalResponse.reviews, function (facReview, next) {
                var facilityReview = FacilityReview(facReview);
                facilityReview.save(function(err, savedData){
                    if(err){
                        callback(err, false);
                    }else{
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    FacilityReviewPlatform.findOneAndUpdate({
                        _id: mongoose.Types.ObjectId(finalResponse.facRevPlatData._id) 
                    }, {
                        $set: {
                            overAllRating: finalResponse.overAllRating,
                            outOfRating: finalResponse.outOfRating,
                            totalReviews: finalResponse.totalReviewCount
                        }
                    }, function (err, updatedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                }
            })  
        },
    ], function (err, data) {
        if(err){
            console.log("@error", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        }else{
            res.json({
                code: config.statusCode.success,
                data: finalResponse,
                message: i18n.__("PAGE_SEARCHED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get facility local nursing homes platform review
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 25-Sep-2018
 */
function getFacilityLocalNursingHomeReviews(req, res) {
    var condition = {
        userFacId: mongoose.Types.ObjectId(req.user.userFacId),
        isDelete: false,
        platformName: config.reviewPlatformName.LOCAL_NURSING_HOMES.name
    }
    
    FacilityReview.find(condition, function(err, facilityReviewArray) { //Get facility reviews
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: facilityReviewArray,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to search nursing home site platform
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Sep-2018
 */
function searchNursingHomeSiteReviewPlatformPage(req, res) {
    var finalResponse = {};
    finalResponse.parsed = {};
    finalResponse.facRevPlatData = {};
    finalResponse.overAllRating = 0;

    waterfall([
        function (callback) { //parse the url and check it having a valid protocol 
            finalResponse.parsed = parse(req.body.pageUrl);
            console.log("finalResponse.parsed: ", finalResponse.parsed);
            if(finalResponse.parsed.protocol != 'https:'){
                res.json({
                    code: config.statusCode.invalid,
                    data: {},
                    message: i18n.__("INVALID_PAGE")
                });
            }else{ //Check url request is from valid platform
                if(finalResponse.parsed.hostname != config.reviewPlatformName.NURSING_HOME_SITE.hostname){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PLATFORM_PAGE")
                    });    
                }else{
                    callback(null, finalResponse);        
                }
            }
        },
        function (finalResponse, callback) { //Check Url existance
            urlExists(req.body.pageUrl, function(err, exists) {
                if(err){
                    callback(err, false);
                }else if(exists == false){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PAGE")
                    });
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Scrape the web url
            var scrapeNursingHomeSitePage = async (function() {
                try {
                    const browser = await (puppeteer.launch({args: ['--no-sandbox', '--disable-setuid-sandbox']}));
                    const page = await (browser.newPage());
                    await (page.goto(req.body.pageUrl));
                    finalResponse.overAllRating = await (page.evaluate(() => {
                        return document.querySelector('.padleft > .padleft div div span strong').textContent
                    }));
                    finalResponse.overAllRating = finalResponse.overAllRating.trim();
                    finalResponse.overAllRating = parseFloat(finalResponse.overAllRating).toFixed(2);
                    browser.close();
                    callback(null, finalResponse)
                } catch (error) {
                    console.log("error: ", error);
                    callback(error, false)
                }
            });    
        
            scrapeNursingHomeSitePage(); 

        },
        function (finalResponse, callback) { //Save facility review platform
            if(finalResponse.overAllRating !=undefined || finalResponse.overAllRating !=null || finalResponse.overAllRating !=' '){
                var reviewPlatform = {
                    platformName: config.reviewPlatformName.NURSING_HOME_SITE.name,
                    scrapeUrl: req.body.pageUrl,
                    overAllRating: finalResponse.overAllRating,
                    outOfRating: 5, 
                    userFacId: req.user.userFacId,
                    userCmpId: req.user.userCmpId
                }
                var facilityReviewPlatform = new FacilityReviewPlatform(reviewPlatform);
                facilityReviewPlatform.save(function (err, facRevPlatData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.facRevPlatData = facRevPlatData;
                        callback(null, finalResponse);
                    }
                });
            }else{

            }
        }
    ], function (err, data) {
        if(err){
            console.log("@error", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        }else{
            res.json({
                code: config.statusCode.success,
                data: finalResponse,
                message: i18n.__("PAGE_SEARCHED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to search family assets platform
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 27-Sep-2018
 */
function searchFamilyAssetsReviewPlatformPage(req, res) {
    var finalResponse = {};
    finalResponse.parsed = {};
    finalResponse.facRevPlatData = {};
    finalResponse.overAllRating = 0;

    waterfall([
        function (callback) { //parse the url and check it having a valid protocol 
            finalResponse.parsed = parse(req.body.pageUrl);
            console.log("finalResponse.parsed: ", finalResponse.parsed);
            if(finalResponse.parsed.protocol != 'https:'){
                res.json({
                    code: config.statusCode.invalid,
                    data: {},
                    message: i18n.__("INVALID_PAGE")
                });
            }else{ //Check url request is from valid platform
                if(finalResponse.parsed.hostname != config.reviewPlatformName.FAMILY_ASSETS.hostname){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PLATFORM_PAGE")
                    });    
                }else{
                    callback(null, finalResponse);        
                }
            }
        },
        function (finalResponse, callback) { //Check Url existance
            urlExists(req.body.pageUrl, function(err, exists) {
                if(err){
                    callback(err, false);
                }else if(exists == false){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PAGE")
                    });
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Scrape the web url
            request(req.body.pageUrl, function(error, response, html){
                if(!error && response.statusCode == 200){
                    
                    const $ = cheerio.load(html);
                    var overAllRatingTemp = $('.nursing-home-page > .top > .container > .row > .col-md-12 > .row > .col-md-3 > .side-info h5 b').text();
                    if(overAllRatingTemp !=''){
                        overAllRatingTemp = overAllRatingTemp.split('/');
                        finalResponse.overAllRating = parseFloat(overAllRatingTemp[0]).toFixed(2);     
                    }else{
                        finalResponse.overAllRating = $('.nursing-home-page > .top > .container > .row > .col-md-12 > .row > .col-md-9 .stars-outer').prop('data-stars');
                        finalResponse.overAllRating = parseFloat(finalResponse.overAllRating).toFixed(2);     
                    }
                    callback(null, finalResponse);
                }else{
                    callback(err, false);
                }
            })
        },
        function (finalResponse, callback) { //Save facility review platform
            if(finalResponse.overAllRating !=undefined || finalResponse.overAllRating !=null || finalResponse.overAllRating !=' '){
                var reviewPlatform = {
                    platformName: config.reviewPlatformName.FAMILY_ASSETS.name,
                    scrapeUrl: req.body.pageUrl,
                    overAllRating: finalResponse.overAllRating,
                    outOfRating: 5, 
                    userFacId: req.user.userFacId,
                    userCmpId: req.user.userCmpId
                }
                var facilityReviewPlatform = new FacilityReviewPlatform(reviewPlatform);
                facilityReviewPlatform.save(function (err, facRevPlatData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.facRevPlatData = facRevPlatData;
                        callback(null, finalResponse);
                    }
                });
            }else{
                res.json({
                    code: config.statusCode.invalid,
                    data: {},
                    message: i18n.__("INVALID_PAGE")
                });
            }
        }
    ], function (err, data) {
        if(err){
            console.log("@error", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        }else{
            res.json({
                code: config.statusCode.success,
                data: finalResponse,
                message: i18n.__("PAGE_SEARCHED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to search local nursing homes platform
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Sep-2018
 */
function searchLocalNursingHomeReviewPlatformPage(req, res) {
    var finalResponse = {};
    finalResponse.parsed = {};
    finalResponse.facRevPlatData = {};
    finalResponse.overAllRating = 0;
    finalResponse.outOfRating = 0;
    finalResponse.totalReviewCount = 0;
    finalResponse.reviews = [];

    waterfall([
        function (callback) { //parse the url and check it having a valid protocol 
            finalResponse.parsed = parse(req.body.pageUrl);
            console.log("finalResponse.parsed: ", finalResponse.parsed);
            if(finalResponse.parsed.protocol != 'http:'){
                res.json({
                    code: config.statusCode.invalid,
                    data: {},
                    message: i18n.__("INVALID_PAGE")
                });
            }else{ //Check url request is from valid platform
                if(finalResponse.parsed.hostname != config.reviewPlatformName.YELP.hostname){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PLATFORM_PAGE")
                    });    
                }else{
                    callback(null, finalResponse);        
                }
            }
        },
        function (finalResponse, callback) { //Check Url existance
            urlExists(req.body.pageUrl, function(err, exists) {
                if(err){
                    callback(err, false);
                }else if(exists == false){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PAGE")
                    });
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Save facility review platform
            var reviewPlatform = {
                platformName: config.reviewPlatformName.YELP.name,
                scrapeUrl: req.body.pageUrl,
                userFacId: req.user.userFacId,
                userCmpId: req.user.userCmpId
            }
            var facilityReviewPlatform = new FacilityReviewPlatform(reviewPlatform);
            facilityReviewPlatform.save(function (err, facRevPlatData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.facRevPlatData = facRevPlatData;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Scrape the web url
            var scrapeNursingHomeSitePage = async (function() {
                try {
                    const browser = await (puppeteer.launch({args: ['--no-sandbox', '--disable-setuid-sandbox']}));
                    const page = await (browser.newPage());
                    await (page.goto(req.body.pageUrl));
                    finalResponse.overAllRating = await (page.evaluate(() => {
                        return document.querySelector('.padleft > .padleft div div span strong').textContent
                    }));
                    finalResponse.overAllRating = finalResponse.overAllRating.trim();
                    finalResponse.overAllRating = parseFloat(finalResponse.overAllRating).toFixed(2);
                    browser.close();
                    callback(null, finalResponse)
                } catch (error) {
                    console.log("error: ", error);
                    callback(error, false)
                }
            });    
        
            scrapeNursingHomeSitePage(); 

        },
        function (finalResponse, callback) { //Save the facility platform reviews
            asyncSeries.eachSeries(finalResponse.reviews, function (facReview, next) {
                var facilityReview = FacilityReview(facReview);
                facilityReview.save(function(err, savedData){
                    if(err){
                        callback(err, false);
                    }else{
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    FacilityReviewPlatform.findOneAndUpdate({
                        _id: mongoose.Types.ObjectId(finalResponse.facRevPlatData._id) 
                    }, {
                        $set: {
                            overAllRating: finalResponse.overAllRating,
                            outOfRating: finalResponse.outOfRating,
                            totalReviews: finalResponse.totalReviewCount
                        }
                    }, function (err, updatedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                }
            })  
        },
    ], function (err, data) {
        if(err){
            console.log("@error", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        }else{
            res.json({
                code: config.statusCode.success,
                data: finalResponse,
                message: i18n.__("PAGE_SEARCHED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get facility yelp platform review
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 3-Oct-2018
 */
function getFacilityYelpReviews(req, res) {
    var condition = {
        userFacId: mongoose.Types.ObjectId(req.user.userFacId),
        isDelete: false,
        platformName: config.reviewPlatformName.YELP.name
    }
    
    FacilityReview.find(condition, function(err, facilityReviewArray) { //Get facility reviews
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: facilityReviewArray,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to search yelp platform
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 3-Oct-2018
 */
function searchYelpReviewPlatformPage(req, res) {
    var finalResponse = {};
    finalResponse.parsed = {};
    finalResponse.facRevPlatData = {};
    finalResponse.overAllRating = 0;
    finalResponse.outOfRating = 0;
    finalResponse.totalReviewCount = 0;
    finalResponse.reviews = [];
    finalResponse.pageArray = [];
    finalResponse.totalPage = 0;

    waterfall([
        function (callback) { //parse the url and check it having a valid protocol 
            finalResponse.parsed = parse(req.body.pageUrl);
            if(finalResponse.parsed.protocol != 'https:'){
                res.json({
                    code: config.statusCode.invalid,
                    data: {},
                    message: i18n.__("INVALID_PAGE")
                });
            }else{ //Check url request is from valid platform
                if(finalResponse.parsed.hostname != config.reviewPlatformName.YELP.hostname){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PLATFORM_PAGE")
                    });    
                }else{
                    callback(null, finalResponse);        
                }
            }
        },
        function (finalResponse, callback) { //Check Url existance
            urlExists(req.body.pageUrl, function(err, exists) {
                if(err){
                    callback(err, false);
                }else if(exists == false){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PAGE")
                    });
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Save facility review platform
            var reviewPlatform = {
                platformName: config.reviewPlatformName.YELP.name,
                scrapeUrl: req.body.pageUrl,
                userFacId: req.user.userFacId,
                userCmpId: req.user.userCmpId
            }
            var facilityReviewPlatform = new FacilityReviewPlatform(reviewPlatform);
            facilityReviewPlatform.save(function (err, facRevPlatData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.facRevPlatData = facRevPlatData;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Scrape the web url
            request(finalResponse.facRevPlatData.scrapeUrl, function(error, response, html){
                if(!error && response.statusCode == 200){
                    
                    var $ = cheerio.load(html);
                    var overAllRatingTemp = $('.rating-info > .biz-rating > .i-stars').prop('title');
                    overAllRatingTemp = overAllRatingTemp.trim().split(' ');
                    finalResponse.overAllRating = overAllRatingTemp[0];
                    finalResponse.overAllRating = parseFloat(overAllRatingTemp[0]).toFixed(2);

                    var totalReviewCountTemp = $('.rating-info > .biz-rating span').text();
                    totalReviewCountTemp = totalReviewCountTemp.trim().split(' ');
                    finalResponse.totalReviewCount = totalReviewCountTemp[0];

                    finalResponse.outOfRating = 5;

                    var totalPageTemp = $('.review-pager > .pagination-block > .arrange > .page-of-pages').text();
                    totalPageTemp = totalPageTemp.trim().split(' ');
                    finalResponse.totalPage = totalPageTemp[totalPageTemp.length - 1];

                    for(var i = 1; i<=finalResponse.totalPage; i++){
                        var obj = {
                            url: (i == 1) ? finalResponse.facRevPlatData.scrapeUrl: finalResponse.facRevPlatData.scrapeUrl+'?start='+(20*(i-1)),
                            iter: i
                        }
                        finalResponse.pageArray.push(obj);
                    }
                    
                    asyncSeries.eachSeries(finalResponse.pageArray, function (pageUrl, next) {
                        if(pageUrl.iter == 1){
                            
                            $('.review-list > .ylist > li:not(:first-child)').each((i, el) => {
                                var reviewDate = $(el).find('li > .review > .review-wrapper > .review-content > .biz-rating .rating-qualifier').children().remove().end().text();
                                reviewDate = new Date(reviewDate.trim());
                                var reviewId = Number(reviewDate); // review time as number for review identification for a platform
                                var rating = $(el).find('li > .review > .review-wrapper > .review-content > .biz-rating > div > .i-stars').prop('title');
                                rating = rating.trim().split(' ');
                                var reviewObj = {
                                    rating: rating[0],
                                    review: $(el).find('li > .review > .review-wrapper > .review-content p').text(),
                                    author: $(el).find('li > .review > .review-sidebar > .review-sidebar-content > .ypassport > .media-story > .user-passport-info > .user-name > .user-display-name').text(),
                                    reviewDate: reviewDate,
                                    reviewId: reviewId,
                                    facRevPlatId: finalResponse.facRevPlatData._id,
                                    platformName: finalResponse.facRevPlatData.platformName,
                                    scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                                    userFacId: finalResponse.facRevPlatData.userFacId,
                                    userCmpId: finalResponse.facRevPlatData.userCmpId,
                                    outOfRating: finalResponse.outOfRating,
                                    reviewUrl: finalResponse.facRevPlatData.scrapeUrl
                                }
                                finalResponse.reviews.push(reviewObj);
                            })
                            next();
                        }else{
                            request(pageUrl.url, function(err, res, body){
                                if(!err && res.statusCode == 200){
                                    var $ = cheerio.load(body);
                                    
                                    $('.review-list > .ylist > li:not(:first-child)').each((i, el) => {
                                        var reviewDate = $(el).find('li > .review > .review-wrapper > .review-content > .biz-rating .rating-qualifier').children().remove().end().text();
                                        reviewDate = new Date(reviewDate.trim());
                                        var reviewId = Number(reviewDate); // review time as number for review identification for a platform
                                        var rating = $(el).find('li > .review > .review-wrapper > .review-content > .biz-rating > div > .i-stars').prop('title');
                                        rating = rating.trim().split(' ');
                                        var reviewObj = {
                                            rating: rating[0],
                                            review: $(el).find('li > .review > .review-wrapper > .review-content p').text(),
                                            author: $(el).find('li > .review > .review-sidebar > .review-sidebar-content > .ypassport > .media-story > .user-passport-info > .user-name > .user-display-name').text(),
                                            reviewDate: reviewDate,
                                            reviewId: reviewId,
                                            facRevPlatId: finalResponse.facRevPlatData._id,
                                            platformName: finalResponse.facRevPlatData.platformName,
                                            scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                                            userFacId: finalResponse.facRevPlatData.userFacId,
                                            userCmpId: finalResponse.facRevPlatData.userCmpId,
                                            outOfRating: finalResponse.outOfRating,
                                            reviewUrl: finalResponse.facRevPlatData.scrapeUrl
                                        }
                                        finalResponse.reviews.push(reviewObj);
                                    })
                                    next();
                                }else{
                                    callback(err, false);
                                }
                            })
                        }
                    }, function (err) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    })  
                }else{
                    callback(err, false);
                }
            })

        },
        function (finalResponse, callback) { //Save the facility platform reviews
            asyncSeries.eachSeries(finalResponse.reviews, function (facReview, next) {
                var facilityReview = FacilityReview(facReview);
                facilityReview.save(function(err, savedData){
                    if(err){
                        callback(err, false);
                    }else{
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    FacilityReviewPlatform.findOneAndUpdate({
                        _id: mongoose.Types.ObjectId(finalResponse.facRevPlatData._id) 
                    }, {
                        $set: {
                            overAllRating: finalResponse.overAllRating,
                            outOfRating: finalResponse.outOfRating,
                            totalReviews: finalResponse.totalReviewCount
                        }
                    }, function (err, updatedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                }
            })  
        },
    ], function (err, data) {
        if(err){
            console.log("@error", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        }else{
            res.json({
                code: config.statusCode.success,
                data: finalResponse,
                message: i18n.__("PAGE_SEARCHED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get facility superpages platform review
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 6-Oct-2018
 */
function getFacilitySuperPagesReviews(req, res) {
    var condition = {
        userFacId: mongoose.Types.ObjectId(req.user.userFacId),
        isDelete: false,
        platformName: config.reviewPlatformName.SUPER_PAGES.name
    }
    
    FacilityReview.find(condition, function(err, facilityReviewArray) { //Get facility reviews
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: facilityReviewArray,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to search superpages platform
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 6-Oct-2018
 */
function searchSuperPagesReviewPlatformPage(req, res) {
    var finalResponse = {};
    finalResponse.parsed = {};
    finalResponse.facRevPlatData = {};
    finalResponse.overAllRating = 0;
    finalResponse.outOfRating = 0;
    finalResponse.totalReviewCount = 0;
    finalResponse.reviews = [];
    finalResponse.pageArray = [];
    finalResponse.totalPage = 0;

    waterfall([
        function (callback) { //parse the url and check it having a valid protocol 
            finalResponse.parsed = parse(req.body.pageUrl);
            if(finalResponse.parsed.protocol != 'https:'){
                res.json({
                    code: config.statusCode.invalid,
                    data: {},
                    message: i18n.__("INVALID_PAGE")
                });
            }else{ //Check url request is from valid platform
                if(finalResponse.parsed.hostname != config.reviewPlatformName.SUPER_PAGES.hostname){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PLATFORM_PAGE")
                    });    
                }else{
                    callback(null, finalResponse);        
                }
            }
        },
        function (finalResponse, callback) { //Check Url existance
            urlExists(req.body.pageUrl, function(err, exists) {
                if(err){
                    callback(err, false);
                }else if(exists == false){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PAGE")
                    });
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Save facility review platform
            var reviewPlatform = {
                platformName: config.reviewPlatformName.SUPER_PAGES.name,
                scrapeUrl: req.body.pageUrl,
                userFacId: req.user.userFacId,
                userCmpId: req.user.userCmpId
            }
            var facilityReviewPlatform = new FacilityReviewPlatform(reviewPlatform);
            facilityReviewPlatform.save(function (err, facRevPlatData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.facRevPlatData = facRevPlatData;
                    console.log("finalResponse.facRevPlatData: ", finalResponse.facRevPlatData);
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Scrape the web url
            var scrapeSuperPagesPage = async (function() {
                try {
                    const browser = await (puppeteer.launch({args: ['--no-sandbox', '--disable-setuid-sandbox']}));
                    const page = await (browser.newPage());
                    await (page.goto(req.body.pageUrl));
                    finalResponse.overAllRating = await (page.evaluate(() => {
                        return document.querySelector('.profile-top-section > .top-top-section > .rate-total-reviews > .rating-star rate-it').getAttribute("data-value");
                    }));

                    var totalReviewCount = await (page.evaluate(() => {
                        return document.querySelector('.profile-top-section > .col-sm-6 > .clearfix > .num-reviews a').textContent;
                    }));
                    totalReviewCount = totalReviewCount.split(new RegExp('[() ]', 'g'));
                    finalResponse.totalReviewCount = totalReviewCount[1];
                    finalResponse.outOfRating = 5;

                    var numberOfPages = (finalResponse.totalReviewCount)%5 == 0 ? ((finalResponse.totalReviewCount)/5) : parseInt((finalResponse.totalReviewCount)/5)+1;
                    // console.log("numberOfPages: ", numberOfPages);
                    // console.log("finalResponse.totalReviewCount: ", finalResponse.totalReviewCount);
                    for(var i = 1; i<=numberOfPages; i++){
                        var obj = {
                            url: (i == 1) ? finalResponse.facRevPlatData.scrapeUrl: finalResponse.facRevPlatData.scrapeUrl+'?reviewpage='+i,
                            iter: i
                        }
                        finalResponse.pageArray.push(obj);
                    }
                    
                    // console.log("finalResponse.pageArray", finalResponse.pageArray);
                    asyncSeries.eachSeries(finalResponse.pageArray, function (pageUrl, next) {
                        if(pageUrl.iter == 1){
                            console.log("pageUrl.iter: ", pageUrl.iter, '\n');
                            var reviewsTemp = await (page.$$eval("#shown-reviews > article", el => 
                            
                                el.map(function (e, label) {
                                    var rating = document.querySelectorAll('.info > div:nth-child(1)')[label].getAttribute("data-value"); 
                                    
                                    var reviewDate = document.querySelectorAll('.info > div:nth-child(2) > .reviewdate')[label].textContent;
                                    var review = document.querySelectorAll('.details > .bp-review-text')[label].textContent;
                                    var authorTemp = document.querySelectorAll('.info > .author-date')[label].textContent;                
                                    authorTemp = authorTemp.split(',');
                                    
                                    var obj = {
                                        rating: rating,
                                        reviewDate: reviewDate,
                                        review: review,
                                        author: authorTemp[0]
                                    } 
                                    return obj;
                                })
                            ));

                            // console.log("reviewsTemp: ", typeof(reviewsTemp), ': ',reviewsTemp[0]);
                            for( var j=0; j<reviewsTemp.length; j++){
                                var reviewDate = new Date(reviewsTemp[j].reviewDate.trim());
                                var reviewId = Number(reviewDate); // review time as number for review identification for a platform
                                
                                var obj = {
                                    rating: reviewsTemp[j].rating,
                                    reviewDate: reviewDate,
                                    review: reviewsTemp[j].review,
                                    author: reviewsTemp[j].author,
                                    reviewId: reviewId,
                                    facRevPlatId: finalResponse.facRevPlatData._id,
                                    platformName: finalResponse.facRevPlatData.platformName,
                                    scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                                    userFacId: finalResponse.facRevPlatData.userFacId,
                                    userCmpId: finalResponse.facRevPlatData.userCmpId,
                                    outOfRating: finalResponse.outOfRating,
                                    reviewUrl: finalResponse.facRevPlatData.scrapeUrl
                                }
                                finalResponse.reviews.push(obj);
                            }

                            next();
                        }else{
                            console.log("pageUrl.iter: ", pageUrl.iter, '\n');                            
                            var browser1 = await (puppeteer.launch({args: ['--no-sandbox', '--disable-setuid-sandbox']}));
                            var page1 = await (browser1.newPage());
                            await (page1.goto(pageUrl.url));
                            var reviewsTemp = await (page1.$$eval("#shown-reviews > article", el => 
                            
                                el.map(function (e, label) {
                                    var rating = document.querySelectorAll('.info > div:nth-child(1)')[label].getAttribute("data-value"); 
                                    var reviewDate = document.querySelectorAll('.info > div:nth-child(2) > .reviewdate')[label].textContent;
                                    var review = document.querySelectorAll('.details > .bp-review-text')[label].textContent;
                                    var authorTemp = document.querySelectorAll('.info > .author-date')[label].textContent;                
                                    authorTemp = authorTemp.split(',');
                                    
                                    var obj = {
                                        rating: rating,
                                        reviewDate: reviewDate,
                                        review: review,
                                        author: authorTemp[0]
                                    } 
                                    return obj;
                                })
                            ));
                            for( var j=0; j<reviewsTemp.length; j++){
                                var reviewDate = new Date(reviewsTemp[j].reviewDate.trim());
                                var reviewId = Number(reviewDate); // review time as number for review identification for a platform
                                
                                var obj = {
                                    rating: reviewsTemp[j].rating,
                                    reviewDate: reviewDate,
                                    review: reviewsTemp[j].review,
                                    author: reviewsTemp[j].author,
                                    reviewId: reviewId,
                                    facRevPlatId: finalResponse.facRevPlatData._id,
                                    platformName: finalResponse.facRevPlatData.platformName,
                                    scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                                    userFacId: finalResponse.facRevPlatData.userFacId,
                                    userCmpId: finalResponse.facRevPlatData.userCmpId,
                                    outOfRating: finalResponse.outOfRating,
                                    reviewUrl: finalResponse.facRevPlatData.scrapeUrl
                                }
                                finalResponse.reviews.push(obj);
                            }
                            next();
                        }
                    }, function (err) {
                        if (err) {
                            callback(err, false);
                        } else {
                            browser.close();
                            callback(null, finalResponse)
                        }
                    })  
                } catch (error) {
                    console.log("error: ", error);
                    callback(error, false)
                }
            });    
        
            scrapeSuperPagesPage(); 

        },
        function (finalResponse, callback) { //Save the facility platform reviews

            // console.log("finalResponse.reviews: ", finalResponse.reviews);
            // return;
            asyncSeries.eachSeries(finalResponse.reviews, function (facReview, next) {
                var facilityReview = FacilityReview(facReview);
                facilityReview.save(function(err, savedData){
                    if(err){
                        callback(err, false);
                    }else{
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    FacilityReviewPlatform.findOneAndUpdate({
                        _id: mongoose.Types.ObjectId(finalResponse.facRevPlatData._id) 
                    }, {
                        $set: {
                            overAllRating: finalResponse.overAllRating,
                            outOfRating: finalResponse.outOfRating,
                            totalReviews: finalResponse.totalReviewCount
                        }
                    }, function (err, updatedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                }
            })  
        },
    ], function (err, data) {
        if(err){
            console.log("@error", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        }else{
            res.json({
                code: config.statusCode.success,
                data: finalResponse,
                message: i18n.__("PAGE_SEARCHED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get facility yellowpages platform review
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 9-Oct-2018
 */
function getFacilityYellowPagesReviews(req, res) {
    var condition = {
        userFacId: mongoose.Types.ObjectId(req.user.userFacId),
        isDelete: false,
        platformName: config.reviewPlatformName.YELLOW_PAGES.name
    }
    
    FacilityReview.find(condition, function(err, facilityReviewArray) { //Get facility reviews
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: facilityReviewArray,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to search yellowpages platform
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 9-Oct-2018
 */
function searchYellowPagesReviewPlatformPage(req, res) {
    var finalResponse = {};
    finalResponse.parsed = {};
    finalResponse.facRevPlatData = {};
    finalResponse.overAllRating = 0;
    finalResponse.outOfRating = 0;
    finalResponse.totalReviewCount = 0;
    finalResponse.reviews = [];
    finalResponse.pageArray = [];
    finalResponse.totalPage = 0;

    waterfall([
        function (callback) { //parse the url and check it having a valid protocol 
            finalResponse.parsed = parse(req.body.pageUrl);
            if(finalResponse.parsed.protocol != 'https:'){
                res.json({
                    code: config.statusCode.invalid,
                    data: {},
                    message: i18n.__("INVALID_PAGE")
                });
            }else{ //Check url request is from valid platform
                if(finalResponse.parsed.hostname != config.reviewPlatformName.YELLOW_PAGES.hostname){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PLATFORM_PAGE")
                    });    
                }else{
                    callback(null, finalResponse);        
                }
            }
        },
        function (finalResponse, callback) { //Check Url existance
            urlExists(req.body.pageUrl, function(err, exists) {
                if(err){
                    callback(err, false);
                }else if(exists == false){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PAGE")
                    });
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Save facility review platform
            var reviewPlatform = {
                platformName: config.reviewPlatformName.YELLOW_PAGES.name,
                scrapeUrl: req.body.pageUrl,
                userFacId: req.user.userFacId,
                userCmpId: req.user.userCmpId
            }
            var facilityReviewPlatform = new FacilityReviewPlatform(reviewPlatform);
            facilityReviewPlatform.save(function (err, facRevPlatData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.facRevPlatData = facRevPlatData;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Scrape the web url
            request(finalResponse.facRevPlatData.scrapeUrl, function(error, response, html){
                if(!error && response.statusCode == 200){
                    
                    var $ = cheerio.load(html);
                    var overAllRatingTemp = $('.primary-info > .ratings > .yp-ratings >  div:nth-child(1)').prop('class');
                    overAllRatingTemp = overAllRatingTemp.trim().split('rating-indicator ');
                    finalResponse.overAllRating = overAllRatingTemp[1];
                    if(finalResponse.overAllRating == 'half'){
                        finalResponse.overAllRating = 0.5;
                    }else if(finalResponse.overAllRating == 'one'){
                        finalResponse.overAllRating = 1;
                    }else if(finalResponse.overAllRating == 'one half'){
                        finalResponse.overAllRating = 1.5;
                    }else if(finalResponse.overAllRating == 'two'){
                        finalResponse.overAllRating = 2;
                    }else if(finalResponse.overAllRating == 'two half'){
                        finalResponse.overAllRating = 2.5;
                    }else if(finalResponse.overAllRating == 'three'){
                        finalResponse.overAllRating = 3;
                    }else if(finalResponse.overAllRating == 'three half'){
                        finalResponse.overAllRating = 3.5;
                    }else if(finalResponse.overAllRating == 'four'){
                        finalResponse.overAllRating = 4;
                    }else if(finalResponse.overAllRating == 'four half'){
                        finalResponse.overAllRating = 4.5;
                    }else if(finalResponse.overAllRating == 'five'){
                        finalResponse.overAllRating = 5;
                    }
                    

                    var totalReviewCountTemp = $('.primary-info > .ratings > .yp-ratings > .count').text();
                    totalReviewCountTemp = totalReviewCountTemp.trim().split(new RegExp('[( ) ]', 'g'));
                    finalResponse.totalReviewCount = totalReviewCountTemp[1];

                    finalResponse.outOfRating = 5;

                    var numberOfPages = (finalResponse.totalReviewCount)%20 == 0 ? ((finalResponse.totalReviewCount)/20) : parseInt((finalResponse.totalReviewCount)/20)+1;
                    var scrapeUrl = finalResponse.facRevPlatData.scrapeUrl;
                    scrapeUrl = scrapeUrl.split('?lid=');
                    scrapeUrl = "https://www.yellowpages.com/listings/"+scrapeUrl[1]+"/reviews?page=";

                    for(var i = 1; i<=numberOfPages; i++){
                        var obj = {
                            url: (i == 1) ? finalResponse.facRevPlatData.scrapeUrl: scrapeUrl+i,
                            iter: i
                        }
                        finalResponse.pageArray.push(obj);
                    }
                    
                    asyncSeries.eachSeries(finalResponse.pageArray, function (pageUrl, next) {
                        if(pageUrl.iter == 1){
                            
                            $('#reviews-container article').each((i, el) => {
                                var reviewDate = $(el).find('.entry > .review-info > .review-dates > .date-posted >  span').text();
                                reviewDate = new Date(reviewDate.trim());
                                var reviewId = Number(reviewDate); // review time as number for review identification for a platform
                                var rating = $(el).find('.entry > .result-ratings > .rating-indicator').prop('class');
                                rating = rating.trim().split('rating-indicator ');
                                rating = rating[1];
                                if(rating == 'half'){
                                    rating = 0.5;
                                }else if(rating == 'one'){
                                    rating = 1;
                                }else if(rating == 'one half'){
                                    rating = 1.5;
                                }else if(rating == 'two'){
                                    rating = 2;
                                }else if(rating == 'two half'){
                                    rating = 2.5;
                                }else if(rating == 'three'){
                                    rating = 3;
                                }else if(rating == 'three half'){
                                    rating = 3.5;
                                }else if(rating == 'four'){
                                    rating = 4;
                                }else if(rating == 'four half'){
                                    rating = 4.5;
                                }else if(rating == 'five'){
                                    rating = 5;
                                }
                                var title = $(el).find('.entry > .review-title').text();
                                var reviewObj = {
                                    rating: rating,
                                    review: $(el).find('.entry > .review-response > p').text(),
                                    author: $(el).find('.entry > .review-info > .author').text(),
                                    reviewDate: reviewDate,
                                    reviewId: reviewId,
                                    facRevPlatId: finalResponse.facRevPlatData._id,
                                    platformName: finalResponse.facRevPlatData.platformName,
                                    scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                                    userFacId: finalResponse.facRevPlatData.userFacId,
                                    userCmpId: finalResponse.facRevPlatData.userCmpId,
                                    outOfRating: finalResponse.outOfRating,
                                    reviewUrl: finalResponse.facRevPlatData.scrapeUrl,
                                    title: title
                                }
                                finalResponse.reviews.push(reviewObj);
                            })
                            next();
                        }else{
                            request(pageUrl.url, function(err, res, body){
                                if(!err && res.statusCode == 200){
                                    var $ = cheerio.load(body);
                                    
                                    $('article').each((i, el) => {
                                        var reviewDate = $(el).find('.entry > .review-info > .review-dates > .date-posted >  span').text();
                                        reviewDate = new Date(reviewDate.trim());
                                        var reviewId = Number(reviewDate); // review time as number for review identification for a platform
                                        var rating = $(el).find('.entry > .result-ratings > .rating-indicator').prop('class');
                                        rating = rating.trim().split('rating-indicator ');
                                        rating = rating[1];
                                        if(rating == 'half'){
                                            rating = 0.5;
                                        }else if(rating == 'one'){
                                            rating = 1;
                                        }else if(rating == 'one half'){
                                            rating = 1.5;
                                        }else if(rating == 'two'){
                                            rating = 2;
                                        }else if(rating == 'two half'){
                                            rating = 2.5;
                                        }else if(rating == 'three'){
                                            rating = 3;
                                        }else if(rating == 'three half'){
                                            rating = 3.5;
                                        }else if(rating == 'four'){
                                            rating = 4;
                                        }else if(rating == 'four half'){
                                            rating = 4.5;
                                        }else if(rating == 'five'){
                                            rating = 5;
                                        }
                                        var title = $(el).find('.entry > .review-title').text();
                                        var reviewObj = {
                                            rating: rating,
                                            review: $(el).find('.entry > .review-response > p').text(),
                                            author: $(el).find('.entry > .review-info > .author').text(),
                                            reviewDate: reviewDate,
                                            reviewId: reviewId,
                                            facRevPlatId: finalResponse.facRevPlatData._id,
                                            platformName: finalResponse.facRevPlatData.platformName,
                                            scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                                            userFacId: finalResponse.facRevPlatData.userFacId,
                                            userCmpId: finalResponse.facRevPlatData.userCmpId,
                                            outOfRating: finalResponse.outOfRating,
                                            reviewUrl: finalResponse.facRevPlatData.scrapeUrl,
                                            title: title
                                        }
                                        finalResponse.reviews.push(reviewObj);
                                    })
                                    next();
                                }else{
                                    callback(err, false);
                                }
                            })
                        }
                    }, function (err) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    })  
                }else{
                    callback(err, false);
                }
            })

        },
        function (finalResponse, callback) { //Save the facility platform reviews
            asyncSeries.eachSeries(finalResponse.reviews, function (facReview, next) {
                var facilityReview = FacilityReview(facReview);
                facilityReview.save(function(err, savedData){
                    if(err){
                        callback(err, false);
                    }else{
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    FacilityReviewPlatform.findOneAndUpdate({
                        _id: mongoose.Types.ObjectId(finalResponse.facRevPlatData._id) 
                    }, {
                        $set: {
                            overAllRating: finalResponse.overAllRating,
                            outOfRating: finalResponse.outOfRating,
                            totalReviews: finalResponse.totalReviewCount
                        }
                    }, function (err, updatedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                }
            })  
        },
    ], function (err, data) {
        if(err){
            console.log("@error", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        }else{
            res.json({
                code: config.statusCode.success,
                data: finalResponse,
                message: i18n.__("PAGE_SEARCHED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get facility agingcare platform review
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 9-Oct-2018
 */
function getFacilityAgingCareReviews(req, res) {
    var condition = {
        userFacId: mongoose.Types.ObjectId(req.user.userFacId),
        isDelete: false,
        platformName: config.reviewPlatformName.AGINGCARE.name
    }
    
    FacilityReview.find(condition, function(err, facilityReviewArray) { //Get facility reviews
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: facilityReviewArray,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to search agingcare review platform
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 9-Oct-2018
 */
function searchAgingCareReviewPlatformPage(req, res) {
    var finalResponse = {};
    finalResponse.parsed = {};
    finalResponse.facRevPlatData = {};
    finalResponse.overAllRating = 0;
    finalResponse.outOfRating = 0;
    finalResponse.totalReviewCount = 0;
    finalResponse.reviews = [];

    waterfall([
        function (callback) { //parse the url and check it having a valid protocol 
            finalResponse.parsed = parse(req.body.pageUrl);
            if(finalResponse.parsed.protocol != 'https:'){
                res.json({
                    code: config.statusCode.invalid,
                    data: {},
                    message: i18n.__("INVALID_PAGE")
                });
            }else{ //Check url request is from valid platform
                if(finalResponse.parsed.hostname != config.reviewPlatformName.AGINGCARE.hostname){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PLATFORM_PAGE")
                    });    
                }else{
                    callback(null, finalResponse);        
                }
            }
        },
        function (finalResponse, callback) { //Check Url existance
            urlExists(req.body.pageUrl, function(err, exists) {
                if(err){
                    callback(err, false);
                }else if(exists == false){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PAGE")
                    });
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Save facility review platform
            var reviewPlatform = {
                platformName: config.reviewPlatformName.AGINGCARE.name,
                scrapeUrl: req.body.pageUrl,
                userFacId: req.user.userFacId,
                userCmpId: req.user.userCmpId
            }
            var facilityReviewPlatform = new FacilityReviewPlatform(reviewPlatform);
            facilityReviewPlatform.save(function (err, facRevPlatData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.facRevPlatData = facRevPlatData;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Scrape the web url
            request(finalResponse.facRevPlatData.scrapeUrl, function(error, response, html){
                if(!error && response.statusCode == 200){
                    const $ = cheerio.load(html);
                    finalResponse.overAllRating = $('.rating-info > span').find('span[itemprop="ratingValue"]').text();
                    finalResponse.outOfRating = 5;
                    finalResponse.totalReviewCount = $('.rating-info > a > span').first().text();

                    $('.reviews-section > .reviews-body > .review-list > .review-item').each((i, el) => {
                        var reviewDate = $(el).find('.review-item-head > .review-date').find('span[itemprop="dateCreated"]').text();
                        reviewDate = new Date(reviewDate.trim());
                        var reviewId = Number(reviewDate); // review time as number for review identification for a platform
                        var author = $(el).find('.review-item-head').find('span[itemprop="author"]').text();
                        var reviewObj = {
                            rating: $(el).find('.review-item-head > .hidden > span').text(),
                            review: $(el).find('.review-item-body > .review-text').text(),
                            author: author.trim(),
                            reviewDate: reviewDate,
                            reviewId: reviewId,
                            facRevPlatId: finalResponse.facRevPlatData._id,
                            platformName: finalResponse.facRevPlatData.platformName,
                            scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                            userFacId: finalResponse.facRevPlatData.userFacId,
                            userCmpId: finalResponse.facRevPlatData.userCmpId,
                            outOfRating: finalResponse.outOfRating,
                            reviewUrl: req.body.pageUrl,
                            title: $(el).find('.review-item-head > .client-status').find('span[itemprop="headline"]').text()
                        }
                        finalResponse.reviews.push(reviewObj);
                    })

                    callback(null, finalResponse);
                }else{
                    callback(err, false);
                }
            })
        },
        function (finalResponse, callback) { //Save the facility platform reviews
            asyncSeries.eachSeries(finalResponse.reviews, function (facReview, next) {
                var facilityReview = FacilityReview(facReview);
                facilityReview.save(function(err, savedData){
                    if(err){
                        callback(err, false);
                    }else{
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    FacilityReviewPlatform.findOneAndUpdate({
                        _id: mongoose.Types.ObjectId(finalResponse.facRevPlatData._id) 
                    }, {
                        $set: {
                            overAllRating: finalResponse.overAllRating,
                            outOfRating: finalResponse.outOfRating,
                            totalReviews: finalResponse.totalReviewCount
                        }
                    }, function (err, updatedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                }
            })  
        },
    ], function (err, data) {
        if(err){
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        }else{
            res.json({
                code: config.statusCode.success,
                data: finalResponse,
                message: i18n.__("PAGE_SEARCHED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get facility indeed platform review
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 10-Oct-2018
 */
function getFacilityIndeedReviews(req, res) {
    var condition = {
        userFacId: mongoose.Types.ObjectId(req.user.userFacId),
        isDelete: false,
        platformName: config.reviewPlatformName.INDEED.name
    }
    
    FacilityReview.find(condition, function(err, facilityReviewArray) { //Get facility reviews
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: facilityReviewArray,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to search indeed review platform
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 10-Oct-2018
 */
function searchIndeedReviewPlatformPage(req, res) {
    var finalResponse = {};
    finalResponse.parsed = {};
    finalResponse.facRevPlatData = {};
    finalResponse.overAllRating = 0;
    finalResponse.outOfRating = 0;
    finalResponse.totalReviewCount = 0;
    finalResponse.pageArray = [];
    finalResponse.reviews = [];

    waterfall([
        function (callback) { //parse the url and check it having a valid protocol 
            finalResponse.parsed = parse(req.body.pageUrl);
            if(finalResponse.parsed.protocol != 'https:'){
                res.json({
                    code: config.statusCode.invalid,
                    data: {},
                    message: i18n.__("INVALID_PAGE")
                });
            }else{ //Check url request is from valid platform
                if(finalResponse.parsed.hostname != config.reviewPlatformName.INDEED.hostname){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PLATFORM_PAGE")
                    });    
                }else{
                    callback(null, finalResponse);        
                }
            }
        },
        function (finalResponse, callback) { //Check Url existance
            urlExists(req.body.pageUrl, function(err, exists) {
                if(err){
                    callback(err, false);
                }else if(exists == false){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PAGE")
                    });
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Save facility review platform
            var reviewPlatform = {
                platformName: config.reviewPlatformName.INDEED.name,
                scrapeUrl: req.body.pageUrl,
                userFacId: req.user.userFacId,
                userCmpId: req.user.userCmpId
            }
            var facilityReviewPlatform = new FacilityReviewPlatform(reviewPlatform);
            facilityReviewPlatform.save(function (err, facRevPlatData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.facRevPlatData = facRevPlatData;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Scrape the web url
            request(finalResponse.facRevPlatData.scrapeUrl, function(error, response, html){
                if(!error && response.statusCode == 200){
                    const $ = cheerio.load(html);
                    finalResponse.overAllRating = $('#cmp-name-and-rating > #cmp-header-rating > .cmp-header-rating-average').text();
                    finalResponse.outOfRating = 5;
                    finalResponse.totalReviewCount = $('#cmp-name-and-rating > #cmp-header-rating > .cmp-note  > a > span').text();
                    
                    var authorRelation = $('#cmp-reviews-header > #cmp-review-featured-container > .cmp-review-container > .cmp-review > .cmp-review-heading > .cmp-review-subtitle > .cmp-reviewer-job-title').children().remove().end().text();
                    authorRelation = authorRelation.trim().split(new RegExp('[()]', 'g'));
                    authorRelation = authorRelation[1];
                    var reviewDate = $('#cmp-reviews-header > #cmp-review-featured-container > .cmp-review-container > .cmp-review > .cmp-review-heading > .cmp-review-subtitle > .cmp-review-date-created').text();
                    reviewDate = new Date(reviewDate.trim());
                    var reviewId = Number(reviewDate); // review time as number for review identification for a platform

                    var headerReviewobj = {
                        rating: $('#cmp-reviews-header > #cmp-review-featured-container > .cmp-review-container > .cmp-review > .cmp-review-heading > .cmp-ratings > .cmp-ratingNumber').text(),
                        review: $('#cmp-reviews-header > #cmp-review-featured-container > .cmp-review-container > .cmp-review > .cmp-review-content-container > .cmp-review-description > .cmp-review-text').text(),
                        author: $('#cmp-reviews-header > #cmp-review-featured-container > .cmp-review-container > .cmp-review > .cmp-review-heading > .cmp-review-title > span:nth-child(2) > meta').prop('content'),
                        reviewDate: reviewDate,
                        reviewId: reviewId,
                        facRevPlatId: finalResponse.facRevPlatData._id,
                        platformName: finalResponse.facRevPlatData.platformName,
                        scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                        userFacId: finalResponse.facRevPlatData.userFacId,
                        userCmpId: finalResponse.facRevPlatData.userCmpId,
                        outOfRating: finalResponse.outOfRating,
                        reviewUrl: req.body.pageUrl+"?id="+$('#cmp-reviews-header > #cmp-review-featured-container > .cmp-review-container > .cmp-review').prop('data-tn-entityid'),
                        authorRelToFac:  authorRelation,
                        title: $('#cmp-reviews-header > #cmp-review-featured-container > .cmp-review-container > .cmp-review > .cmp-review-heading > .cmp-review-title > span').text()
                    }

                    finalResponse.reviews.push(headerReviewobj);

                    var numberOfPages = (finalResponse.totalReviewCount)%20 == 0 ? ((finalResponse.totalReviewCount)/20) : parseInt((finalResponse.totalReviewCount)/20)+1;
                    var scrapeUrl = finalResponse.facRevPlatData.scrapeUrl+"?start=";
                    for(var i = 1; i<=numberOfPages; i++){
                        var obj = {
                            url: (i == 1) ? finalResponse.facRevPlatData.scrapeUrl: scrapeUrl+(20*i),
                            iter: i
                        }
                        finalResponse.pageArray.push(obj);
                    }
                    
                    asyncSeries.eachSeries(finalResponse.pageArray, function (pageUrl, next) {
                        if(pageUrl.iter == 1){
                            
                            $('#cmp-content > .cmp-review-container').each((i, el) => {
                                var reviewDate = $(el).find('.cmp-review > .cmp-review-heading > .cmp-review-subtitle > .cmp-review-date-created').text();
                                reviewDate = new Date(reviewDate.trim());
                                var reviewId = Number(reviewDate); // review time as number for review identification for a platform
                                var author = $(el).find('.cmp-review > .cmp-review-heading > .cmp-review-subtitle > .cmp-reviewer-job-title > .cmp-reviewer').text();
                                var authorRelation = $(el).find('.cmp-review > .cmp-review-heading > .cmp-review-subtitle > .cmp-reviewer-job-title').children().remove().end().text();
                                authorRelation = authorRelation.trim().split(new RegExp('[()]', 'g'));
                                authorRelation = authorRelation[1];
        
                                var reviewObj = {
                                    rating: $(el).find('.cmp-review > .cmp-review-heading > .cmp-ratings > .cmp-ratingNumber').text(),
                                    review: $(el).find('.cmp-review > .cmp-review-content-container > .cmp-review-description > .cmp-review-text').text(),
                                    author: author.trim(),
                                    reviewDate: reviewDate,
                                    reviewId: reviewId,
                                    facRevPlatId: finalResponse.facRevPlatData._id,
                                    platformName: finalResponse.facRevPlatData.platformName,
                                    scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                                    userFacId: finalResponse.facRevPlatData.userFacId,
                                    userCmpId: finalResponse.facRevPlatData.userCmpId,
                                    outOfRating: finalResponse.outOfRating,
                                    authorRelToFac:  authorRelation,
                                    reviewUrl: req.body.pageUrl+"?id="+$(el).find('.cmp-review').prop('data-tn-entityid'),
                                    title: $(el).find('.cmp-review > .cmp-review-heading > .cmp-review-title span').text()
                                }
                                finalResponse.reviews.push(reviewObj);
                            })        
                            next();
                        }else{
                            request(pageUrl.url, function(err, res, body){
                                if(!err && res.statusCode == 200){
                                    var $ = cheerio.load(body);
                                    $('#cmp-content > .cmp-review-container').each((i, el) => {
                                        var reviewDate = $(el).find('.cmp-review > .cmp-review-heading > .cmp-review-subtitle > .cmp-review-date-created').text();
                                        reviewDate = new Date(reviewDate.trim());
                                        var reviewId = Number(reviewDate); // review time as number for review identification for a platform
                                        var author = $(el).find('.cmp-review > .cmp-review-heading > .cmp-review-subtitle > .cmp-reviewer-job-title > .cmp-reviewer').text();
                                        var authorRelation = $(el).find('.cmp-review > .cmp-review-heading > .cmp-review-subtitle > .cmp-reviewer-job-title').children().remove().end().text();
                                        authorRelation = authorRelation.trim().split(new RegExp('[()]', 'g'));
                                        authorRelation = authorRelation[1];
                
                                        var reviewObj = {
                                            rating: $(el).find('.cmp-review > .cmp-review-heading > .cmp-ratings > .cmp-ratingNumber').text(),
                                            review: $(el).find('.cmp-review > .cmp-review-content-container > .cmp-review-description > .cmp-review-text').text(),
                                            author: author.trim(),
                                            reviewDate: reviewDate,
                                            reviewId: reviewId,
                                            facRevPlatId: finalResponse.facRevPlatData._id,
                                            platformName: finalResponse.facRevPlatData.platformName,
                                            scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                                            userFacId: finalResponse.facRevPlatData.userFacId,
                                            userCmpId: finalResponse.facRevPlatData.userCmpId,
                                            outOfRating: finalResponse.outOfRating,
                                            authorRelToFac:  authorRelation,
                                            reviewUrl: req.body.pageUrl+"?id="+$(el).find('.cmp-review').prop('data-tn-entityid'),
                                            title: $(el).find('.cmp-review > .cmp-review-heading > .cmp-review-title span').text()
                                        }
                                        finalResponse.reviews.push(reviewObj);
                                    })
                                    next();
                                }else{
                                    callback(err, false);
                                }
                            })
                        }
                    }, function (err) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    })  
                }else{
                    callback(err, false);
                }
            })
        },
        function (finalResponse, callback) { //Save the facility platform reviews
            asyncSeries.eachSeries(finalResponse.reviews, function (facReview, next) {
                var facilityReview = FacilityReview(facReview);
                facilityReview.save(function(err, savedData){
                    if(err){
                        callback(err, false);
                    }else{
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    FacilityReviewPlatform.findOneAndUpdate({
                        _id: mongoose.Types.ObjectId(finalResponse.facRevPlatData._id) 
                    }, {
                        $set: {
                            overAllRating: finalResponse.overAllRating,
                            outOfRating: finalResponse.outOfRating,
                            totalReviews: finalResponse.totalReviewCount
                        }
                    }, function (err, updatedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                }
            })  
        },
    ], function (err, data) {
        if(err){
            console.log("@error", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        }else{
            res.json({
                code: config.statusCode.success,
                data: finalResponse,
                message: i18n.__("PAGE_SEARCHED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get facility wellness platform review
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Oct-2018
 */
function getFacilityWellnessReviews(req, res) {
    var condition = {
        userFacId: mongoose.Types.ObjectId(req.user.userFacId),
        isDelete: false,
        platformName: config.reviewPlatformName.WELLNESS.name
    }
    
    FacilityReview.find(condition, function(err, facilityReviewArray) { //Get facility reviews
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: facilityReviewArray,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to search wellness platform review 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Oct-2018
 */
function searchWellnessReviewPlatformPage(req, res) {
    var finalResponse = {};
    finalResponse.parsed = {};
    finalResponse.facRevPlatData = {};
    finalResponse.overAllRating = 0;
    finalResponse.outOfRating = 0;
    finalResponse.totalReviewCount = 0;
    finalResponse.pageArray = [];
    finalResponse.reviews = [];

    waterfall([
        function (callback) { //parse the url and check it having a valid protocol 
            finalResponse.parsed = parse(req.body.pageUrl);
            if(finalResponse.parsed.protocol != 'https:'){
                res.json({
                    code: config.statusCode.invalid,
                    data: {},
                    message: i18n.__("INVALID_PAGE")
                });
            }else{ //Check url request is from valid platform
                if(finalResponse.parsed.hostname != config.reviewPlatformName.WELLNESS.hostname){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PLATFORM_PAGE")
                    });    
                }else{
                    callback(null, finalResponse);        
                }
            }
        },
        function (finalResponse, callback) { //Check Url existance
            urlExists(req.body.pageUrl, function(err, exists) {
                if(err){
                    callback(err, false);
                }else if(exists == false){
                    res.json({
                        code: config.statusCode.invalid,
                        data: {},
                        message: i18n.__("INVALID_PAGE")
                    });
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Save facility review platform
            var reviewPlatform = {
                platformName: config.reviewPlatformName.WELLNESS.name,
                scrapeUrl: req.body.pageUrl,
                userFacId: req.user.userFacId,
                userCmpId: req.user.userCmpId
            }
            var facilityReviewPlatform = new FacilityReviewPlatform(reviewPlatform);
            facilityReviewPlatform.save(function (err, facRevPlatData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.facRevPlatData = facRevPlatData;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Scrape the web url
            request(finalResponse.facRevPlatData.scrapeUrl, function(error, response, html){
                if(!error && response.statusCode == 200){
                    const $ = cheerio.load(html);
                    var overAllRating = $('.average-review-container').text();
                    overAllRating = overAllRating.trim().split(' ');
                    finalResponse.overAllRating = overAllRating[0];
                    finalResponse.outOfRating = 5;
                    finalResponse.totalReviewCount = $('.average-review-container > .listing-ratings-total > .count').text();

                    var numberOfPages = (finalResponse.totalReviewCount)%10 == 0 ? ((finalResponse.totalReviewCount)/10) : parseInt((finalResponse.totalReviewCount)/10)+1;
                    var scrapeUrl = finalResponse.facRevPlatData.scrapeUrl+"/";
                    for(var i = 1; i<=numberOfPages; i++){
                        var obj = {
                            url: (i == 1) ? finalResponse.facRevPlatData.scrapeUrl: scrapeUrl+i,
                            iter: i
                        }
                        finalResponse.pageArray.push(obj);
                    }
                    
                    asyncSeries.eachSeries(finalResponse.pageArray, function (pageUrl, next) {
                        if(pageUrl.iter == 1){
                            
                            $('#reviews > .review').each((i, el) => {
                                var reviewDate = $(el).find('div > .reviewer').find('span[itemprop="datePublished"]').text();
                                reviewDate = new Date(reviewDate.trim());
                                var reviewId = Number(reviewDate); // review time as number for review identification for a platform
                                var author = $(el).find('div > .reviewer > .listing-review-name > .review_name').text();
                                var rating = $(el).find('div > .listing-ratings-container').text();
                                rating = rating.trim();
                                var review = $(el).find('div > .review-text-container > .listing-review-text').text();

                                var reviewObj = {
                                    rating: rating,
                                    author: author,
                                    reviewDate: reviewDate,
                                    reviewId: reviewId,
                                    facRevPlatId: finalResponse.facRevPlatData._id,
                                    platformName: finalResponse.facRevPlatData.platformName,
                                    scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                                    userFacId: finalResponse.facRevPlatData.userFacId,
                                    userCmpId: finalResponse.facRevPlatData.userCmpId,
                                    outOfRating: finalResponse.outOfRating,
                                    reviewUrl: finalResponse.facRevPlatData.scrapeUrl
                                }
                                if(review != ''){
                                    reviewObj.review = review;
                                }
                                finalResponse.reviews.push(reviewObj);
                            })        
                            next();
                        }else{
                            request(pageUrl.url, function(err, res, body){
                                if(!err && res.statusCode == 200){
                                    var $ = cheerio.load(body);
                                    $('#reviews > .review').each((i, el) => {
                                        var reviewDate = $(el).find('div > .reviewer').find('span[itemprop="datePublished"]').text();
                                        reviewDate = new Date(reviewDate.trim());
                                        var reviewId = Number(reviewDate); // review time as number for review identification for a platform
                                        var author = $(el).find('div > .reviewer > .listing-review-name > .review_name').text();
                                        var rating = $(el).find('div > .listing-ratings-container').text();
                                        rating = rating.trim();
                                        var review = $(el).find('div > .review-text-container > .listing-review-text').text();
        
                                        var reviewObj = {
                                            rating: rating,
                                            author: author,
                                            reviewDate: reviewDate,
                                            reviewId: reviewId,
                                            facRevPlatId: finalResponse.facRevPlatData._id,
                                            platformName: finalResponse.facRevPlatData.platformName,
                                            scrapeUrl: finalResponse.facRevPlatData.scrapeUrl,
                                            userFacId: finalResponse.facRevPlatData.userFacId,
                                            userCmpId: finalResponse.facRevPlatData.userCmpId,
                                            outOfRating: finalResponse.outOfRating,
                                            reviewUrl: finalResponse.facRevPlatData.scrapeUrl
                                        }
                                        if(review != ''){
                                            reviewObj.review = review;
                                        }
                                        finalResponse.reviews.push(reviewObj);
                                    })  
                                    next();
                                }else{
                                    callback(err, false);
                                }
                            })
                        }
                    }, function (err) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    })  
                }else{
                    callback(err, false);
                }
            })
        },
        function (finalResponse, callback) { //Save the facility platform reviews
            asyncSeries.eachSeries(finalResponse.reviews, function (facReview, next) {
                var facilityReview = FacilityReview(facReview);
                facilityReview.save(function(err, savedData){
                    if(err){
                        callback(err, false);
                    }else{
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    FacilityReviewPlatform.findOneAndUpdate({
                        _id: mongoose.Types.ObjectId(finalResponse.facRevPlatData._id) 
                    }, {
                        $set: {
                            overAllRating: finalResponse.overAllRating,
                            outOfRating: finalResponse.outOfRating,
                            totalReviews: finalResponse.totalReviewCount
                        }
                    }, function (err, updatedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                }
            })  
        },
    ], function (err, data) {
        if(err){
            console.log("@error", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        }else{
            res.json({
                code: config.statusCode.success,
                data: finalResponse,
                message: i18n.__("PAGE_SEARCHED_SUCCESSFULLY")
            });
        }
    });
}
