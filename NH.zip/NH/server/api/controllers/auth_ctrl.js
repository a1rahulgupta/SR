'use strict';

var mongoose = require('mongoose'),
    formidable = require('formidable'),
    fs = require('fs-extra'),
    path = require('path'),
    jwt = require('jsonwebtoken'),
    validator = require('validator'),
    utility = require('../lib/utility.js'),
    crypto = require('./../lib/crypto.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    jwt = require('jsonwebtoken'),
    Joi = require('joi'),
    i18n = require("i18n"),
    twilio = require('./../lib/twilio.js'),
    moment = require('moment'),
    emailSend = __rootRequire('api/core/email'),


    //Models
    User = mongoose.model('user'),
    Company = mongoose.model('company'),
    UserCompany = mongoose.model('userCompany'),
    Facility = mongoose.model('facility'),
    UserFacility = mongoose.model('userFacility'),
    Setting = mongoose.model('setting'),
    Visitor = mongoose.model('visitors'),
    CheckInOut = mongoose.model('checkInOut'),
    SMSHistory = mongoose.model('smsHistory'),
    SubLogin = mongoose.model('subLogin'),


    //required js files
    config = require('../../config/config.js'),
    utils = require('../lib/util');

module.exports = {
    login: login,
    checklogin: checklogin,
    verifyAccount: verifyAccount,
    addSetting: addSetting,
    getAllSetting: getAllSetting,
    getSettingById: getSettingById,
    updateSetting: updateSetting,
    verifyReviewToken: verifyReviewToken,
    addVisitorReview: addVisitorReview,
    getprofile: getprofile,
    updateProfile: updateProfile,
    getCompanyProfileById: getCompanyProfileById,
    getFacilityProfileById: getFacilityProfileById,
    getEmployeeProfile: getEmployeeProfile,
    changePassword: changePassword,
    reqResetPassword: reqResetPassword,
    verifyReSetPwdLink: verifyReSetPwdLink,
    resetPassword: resetPassword
};
/**
 * Function is user login
 * @access private
 * @return json
 * Created by Sunny 
 * @smartData Enterprises (I) Ltd
 * Created Date 24-Apr-2018
 */


function login(req, res) {

    if (validator.isNull(req.body.email) || !req.body.email) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("EMAIL_REQUIRED")
        });
    } else if (req.body.email && !config.isEmail(req.body.email)) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("INVALID_EMAIL")
        });
    } else if (validator.isNull(req.body.password) || !req.body.password) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("PASSWORD_REQUIRED")
        });
    } else {
        var passEnc = utility.getEncryptText(req.body.password);
        var lastLoginDate = new Date();
        var userCredentials = {
            email: req.body.email.trim().toLowerCase(),
            password: passEnc
        };
        User.findOne(userCredentials, {
                password: 0,
                updatedAt: 0,
                createdAt: 0,
                verifyToken: 0
            })
            .sort({ createdAt: -1 })
            .lean()
            .exec(function (err, userData) { // check user credentials 
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                } else {
                    if (!userData) {
                        res.json({
                            code: config.statusCode.notFound,
                            data: {},
                            message: i18n.__("INVALID_CREDENTIALS")
                        });
                    } else if (userData.status == '0') {
                        res.json({
                            code: config.statusCode.unauthorized,
                            data: {},
                            message: i18n.__("ACCOUNT_NOT_ACTIVATED")
                        });
                    } else if (userData.isDelete) {
                        res.json({
                            code: 202,
                            data: {},
                            message: i18n.__("YOUR_ACCOUNT_DELETED")
                        });
                    } else {
                        switch (userData.role) {
                            case config.role_type.SUPER_ADMIN.name:
                                var tokenData = {
                                    "uid": userData._id,
                                    "userName": userData.userName,
                                    "role": userData.role,
                                    "image": userData.image,
                                    "email": userData.email,
                                    "firstName": userData.firstNname,
                                    "lastName": userData.lastName,
                                    "phoneNumber": userData.phoneNumber
                                };
                                render(tokenData); // call function to check user token and send response
                                break;
                            case config.role_type.COMPANY_ADMIN.name:
                                if (userData.status == '2') {
                                    res.json({
                                        code: config.statusCode.error,
                                        data: {},
                                        message: i18n.__("ACCOUNT_DEACTIVATED")
                                    });
                                } else {
                                    UserCompany.findOne({
                                        userId: userData._id
                                    }).lean().exec(function (err, userCmpData) {
                                        if (err) {
                                            res.json({
                                                code: config.statusCode.error,
                                                data: {},
                                                message: i18n.__("INTERNAL_ERROR")
                                            });
                                        } else {
                                            var tokenData = {
                                                "uid": userData._id,
                                                "userName": userData.userName,
                                                "role": userData.role,
                                                "image": userData.image,
                                                "email": userData.email,
                                                "firstName": userData.firstName,
                                                "lastName": userData.lastName,
                                                "phoneNumber": userData.phoneNumber,
                                                "userCmpId": userCmpData._id,
                                                "cmpId": userCmpData.companyId
                                            };
                                            render(tokenData); // call function to check user token and send response
                                        }
                                    })
                                }
                                break;
                            case config.role_type.FACILITY_ADMIN.name:
                                if (userData.status == '2') {
                                    res.json({
                                        code: config.statusCode.error,
                                        data: {},
                                        message: i18n.__("ACCOUNT_DEACTIVATED")
                                    });
                                } else {
                                    UserFacility.findOne({
                                        userId: userData._id
                                    }).lean().populate('facilityId', 'userCmpId twilioTollFreeNumber googleLink').exec(function (err, userFacData) {
                                        if (err) {
                                            res.json({
                                                code: config.statusCode.error,
                                                data: {},
                                                message: i18n.__("INTERNAL_ERROR")
                                            });
                                        } else {
                                            // console.log("userFacData", userFacData);
                                            var tokenData = {
                                                "uid": userData._id,
                                                "userName": userData.userName,
                                                "role": userData.role,
                                                "image": userData.image,
                                                "email": userData.email,
                                                "firstName": userData.firstName,
                                                "lastName": userData.lastName,
                                                "phoneNumber": userData.phoneNumber,
                                                "userFacId": userFacData._id,
                                                "facId": userFacData.facilityId._id,
                                                "facName": userFacData.facilityId.facName, 
                                                "twilioTollFreeNumber": userFacData.facilityId.twilioTollFreeNumber,
                                                "userCmpId": userFacData.facilityId.userCmpId,
                                                "googleLink": userFacData.facilityId.googleLink
                                            };
                                            render(tokenData); // call function to check user token and send response
                                        }
                                    })
                                }

                                break;
                            default:
                                if (userData.status == '2') {
                                    res.json({
                                        code: config.statusCode.error,
                                        data: {},
                                        message: i18n.__("ACCOUNT_DEACTIVATED")
                                    });
                                } else {
                                    UserFacility.findOne({
                                        userId: userData._id
                                    }).lean().populate('facilityId', 'userCmpId twilioTollFreeNumber googleLink').exec(function (err, userFacData) {
                                        if (err) {
                                            res.json({
                                                code: config.statusCode.error,
                                                data: {},
                                                message: i18n.__("INTERNAL_ERROR")
                                            });
                                        } else {
                                            var condition = {};
                                            condition['facilityId'] = mongoose.Types.ObjectId(userFacData.facilityId._id);
                                            condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;
                                            var aggregate = [{
                                                    $lookup: {
                                                        from: 'users',
                                                        localField: "userId",
                                                        foreignField: "_id",
                                                        as: "userInfo"
                                                    }
                                                },
                                                {
                                                    $unwind: "$userInfo"
                                                },
                                                {
                                                    $match: condition
                                                }
                                            ];
                                            var project = {
                                                $project: {
                                                    "facilityId": "$facilityId",
                                                    "userName": "$userInfo.userName",
                                                }
                                            };

                                            aggregate.push(project);
                                            UserFacility.aggregate(aggregate).then(function (userFacilityData) { // Getting userfacility id of facility
                                                var tokenData = {
                                                    "uid": userData._id,
                                                    "userName": userData.userName,
                                                    "role": userData.role,
                                                    "image": userData.image,
                                                    "email": userData.email,
                                                    "firstName": userData.firstName,
                                                    "lastName": userData.lastName,
                                                    "phoneNumber": userData.phoneNumber,
                                                    "userFacId": userFacilityData[0]._id,
                                                    "facId": userFacData.facilityId._id,
                                                    "facName": userFacData.facilityId.facName, 
                                                    "twilioTollFreeNumber": userFacData.facilityId.twilioTollFreeNumber,
                                                    "userCmpId": userFacData.facilityId.userCmpId,
                                                    "googleLink": userFacData.facilityId.googleLink
                                                };
                                                render(tokenData); // call function to check user token and send response    
                                            })
                                        }
                                    })
                                }
                        }

                        function render(tokenData) { //function to check user token and send response
                            var expirationDuration = 60 * 60 * 24 * 15; // expiration duration format sec:min:hour:day. ie: 8 Hours as per i/p
                            var jwtToken = jwt.sign(tokenData, config.secret, {
                                expiresIn: expirationDuration
                            });

                            var userObj = {};
                            userObj.token = jwtToken;
                            userObj.lastLoginDate = new Date();
                            User.update({
                                _id: userData._id
                            }, {
                                $set: userObj
                            }, function (err, updatedUserData) {
                                if (err) {
                                    res.json({
                                        code: config.statusCode.error,
                                        data: {},
                                        message: i18n.__("INTERNAL_ERROR")
                                    });
                                } else {
                                    var subLoginData = {};
                                    var sbLoginData;
                                    subLoginData.loginId = userData._id,
                                        subLoginData.name = userData.userName
                                    var subLoginInfo = new SubLogin(subLoginData);
                                    subLoginInfo.save(function (err, sbLoginDetails) {
                                        if (err) {
                                            res.json({
                                                code: config.statusCode.error,
                                                data: {},
                                                message: i18n.__("INTERNAL_ERROR")
                                            });
                                        } else {

                                            sbLoginData = sbLoginDetails
                                            var usData = {
                                                'user': tokenData,
                                                'sublogin': sbLoginData,
                                                'token': jwtToken
                                            }
                                            // console.log("usData", usData.user);
                                            res.json({
                                                code: config.statusCode.success,
                                                data: usData,
                                                message: i18n.__("LOGGED_IN_SUCCESSFULLY")
                                            });
                                        }
                                    });

                                }
                            });
                        }
                        //End
                    }
                }
            });
    }
}
/**
 * Function is use to check login status
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 25-Apr-2018
 */
function checklogin(req, res, next) {
    utils.ensureAuthorized(req, res, function () {
        res.json({
            code: config.statusCode.success,
            data: req.user,
            message: i18n.__("USER_AUTHENTICATED")
        });
    })
}

/**
 * Function is use to verify account 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 27-Apr-2018
 */
function verifyAccount(req, res) {
    var finalResponse = {};
    finalResponse.userData = {};
    finalResponse.updatedUserData = {};
    finalResponse.userCmpData = {};
    finalResponse.userFacData = {};
    waterfall([
        function (callback) { //Verify token key is valid 
            User.findOne({
                verifyToken: req.body.verifyToken
            }).exec(function (err, userData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (!userData) {
                        res.json({
                            code: config.statusCode.invalid,
                            data: {},
                            message: i18n.__("INVALID_URL")
                        });
                    } else {
                        finalResponse.userData = userData;
                        callback(null, finalResponse);
                    }
                }
            })
        },
        function (finalResponse, callback) { //Verify User  
            if (finalResponse.userData.isDelete == true || finalResponse.userData.status == '1' || finalResponse.userData.status == '2') {
                res.json({
                    code: config.statusCode.serviceUnavailable,
                    data: {},
                    message: i18n.__("LINK_EXPIRED")
                });
            } else {
                User.findOneAndUpdate({
                    verifyToken: req.body.verifyToken
                }, {
                    $set: {
                        status: '1',
                    }
                }, function (err, data) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.updatedUserData = data;
                        callback(null, finalResponse);
                    }
                });
            }
        },
        function (finalResponse, callback) {
            if (finalResponse.updatedUserData.role == config.role_type.COMPANY_ADMIN.name) { //Verify User Company 
                UserCompany.findOneAndUpdate({
                    userId: finalResponse.updatedUserData._id
                }, {
                    $set: {
                        status: '1',
                    }
                }, function (err, userCmpData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.userCmpData = userCmpData;
                        callback(null, finalResponse);
                    }
                });
            } else { //Verify User Facility And Employee 
                UserFacility.findOneAndUpdate({
                    userId: finalResponse.updatedUserData._id
                }, {
                    $set: {
                        status: '1',
                    }
                }, function (err, userFacData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.userFacData = userFacData;
                        callback(null, finalResponse);
                    }
                });
            }

        },
        function (finalResponse, callback) {
            if (finalResponse.updatedUserData.role == config.role_type.COMPANY_ADMIN.name) { //Verify Company
                Company.findOneAndUpdate({
                    _id: finalResponse.userCmpData.companyId
                }, {
                    $set: {
                        status: '1',
                    }
                }, function (err, cmpdata) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            } else {
                if (finalResponse.updatedUserData.role == config.role_type.FACILITY_ADMIN.name) { //Verify Facility
                    Facility.findOneAndUpdate({
                        _id: finalResponse.userFacData.facilityId
                    }, {
                        $set: {
                            status: '1',
                        }
                    }, function (err, facData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            console.log("in facility")
                            callback(null, finalResponse);
                        }
                    });
                } else {
                    console.log("in employee")

                    callback(null, finalResponse);
                }
            }
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("ACCOUNT_VERIFIED")
            });
        }
    });
}

/**
 * Function is use to add Setting Keys 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 15-may-2018
 */

function addSetting(req, res) {
    Setting.findOneAndUpdate({
        status: true,
        is_deleted: false
    }, {
        $set: {
            status: false
        }
    }, function (err, data) {
        if (err) {
            res.json({
                status: req.config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        } else {
            var obj = {
                account_title: req.body.account_title.trim(),
                accountSid: req.body.accountSid.trim(),
                authToken: req.body.authToken.trim()
            }
            var settingData = new Setting(obj);
            settingData.status = true;
            settingData.save(function (err, settingNewData) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: settingNewData,
                        message: i18n.__("KEY_SAVE_SUCCESSFULLY")
                    });
                }
            }).catch(function (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })

            });
        }
    })
}
/**
 * Function is use to get all Setting Keys 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 15-may-2018
 */
function getAllSetting(req, res) {
    Setting.find({
        status: true,
        is_deleted: false
    }, function (err, settingData) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        } else {
            res.json({
                code: config.statusCode.success,
                data: settingData
            });
        }
    }).catch(function (err) {
        res.json({
            code: config.statusCode.error,
            data: {},
            message: i18n.__("ERROR")
        })

    });
}
/**
 * Function is use to update Setting Keys 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 15-may-2018
 */
function updateSetting(req, res) {
    Setting.findOneAndUpdate({
        _id: req.body._id,
        status: true,
        is_deleted: false
    }, {
        status: false
    }, {
        new: true
    }, function (err, settingData) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        } else if (!settingData) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        } else {
            var setting = new Setting();
            setting.accountSid = req.body.accountSid;
            setting.authToken = req.body.authToken;
            setting.account_title = req.body.account_title;
            setting.save(function (err, savedData) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: savedData,
                        message: i18n.__("KEY_UPDATED_SUCCESSFULLY")
                    });
                }
            })
        }
    })
}
/**
 * Function is use to get by id Setting Keys 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 15-may-2018
 */
function getSettingById(req, res) {
    Setting.findOne({
        _id: req.query.id,
        status: true,
        is_deleted: false
    }, function (err, settingData) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        } else {
            res.json({
                code: config.statusCode.success,
                data: settingData
            });
        }
    }).catch(function (err) {
        res.json({
            code: config.statusCode.error,
            data: {},
            message: i18n.__("ERROR")
        })

    });
}
/**
 * Function is use to verify review account 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 15-May-2018
 */
function verifyReviewToken(req, res) {
    var finalResponse = {};
    finalResponse.visitorData = {};
    finalResponse.updatedVisitorData = {};
    waterfall([
        function (callback) { //Verify token key is valid 
            CheckInOut.findOne({
                reviewToken: req.body.reviewToken
            }).exec(function (err, visitorData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (!visitorData) {
                        res.json({
                            code: config.statusCode.invalid,
                            data: {},
                            message: i18n.__("INVALID_URL")
                        });
                    } else {
                        finalResponse.visitorData = visitorData;
                        callback(null, finalResponse);
                    }
                }
            })
        },
        function (finalResponse, callback) { //Verify visitor
            if (finalResponse.visitorData.isDelete == true || finalResponse.visitorData.reviewStatus == '1') {
                res.json({
                    code: config.statusCode.serviceUnavailable,
                    data: {},
                    message: i18n.__("LINK_EXPIRED")
                });
            } else {
                callback(null, finalResponse);
            }
        },
    ], function (err, data) {
        console.log("verifyReviewToken---------->>>>>>>", data);
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("ACCOUNT_VERIFIED")
            });
        }
    });
}
/**
 * Function is use to add Visitor Review
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 15-May-2018
 */
function addVisitorReview(req, res) {
    var finalResponse = {};
    finalResponse.VisitorData = {};
    finalResponse.updatedVisitorData = {};
    finalResponse.returnData = {};
    finalResponse.twilioInfo = {};
    var reviewObj = {
        rating: req.body.rating,
        comments: req.body.comments,
        userFacilityId: req.body.userFacilityId,
        visitorId: req.body.visitorId,
        reviewToken: req.body.reviewToken
    }

    if (!reviewObj.rating || !reviewObj.comments || !reviewObj.userFacilityId || !reviewObj.visitorId || !reviewObj.reviewToken) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } {
        waterfall([
            function (callback) { // update rating and comments
                var ratingStatus;
                if (reviewObj.rating >= 3) {
                    ratingStatus = 'Positive';
                } else {
                    ratingStatus = 'Negative';
                }
                CheckInOut.findOneAndUpdate({
                    reviewToken: reviewObj.reviewToken,
                    visitorId: reviewObj.visitorId,
                    userFacilityId: reviewObj.userFacilityId
                }, {
                    $set: {
                        rating: reviewObj.rating,
                        comments: reviewObj.comments,
                        reviewStatus: '1',
                        ratingStatus: ratingStatus,
                        reviewDate: new Date()
                    }
                }, function (err, updatedVisitorData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.updatedVisitorData = updatedVisitorData;
                        callback(null, finalResponse);
                    }
                });
            },
            function (finalResponse, callback) { //Thank You sms send to visitor
                Visitor.findById({
                    _id: reviewObj.visitorId
                }).exec(function (err, VisitorData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        var text = i18n.__("THANK_YOU_AFTER_RATING");
                        var smsData = {
                            to: VisitorData.phoneNumber,
                            message: text
                        }
                        twilio.sendSMS(smsData, function (returnData) {
                            finalResponse.twilioInfo = returnData
                            finalResponse.VisitorData = VisitorData;
                            callback(null, finalResponse);
                        });
                    }
                });
            },
            function (finalResponse, callback) { //Save sms history
                var messageBody = finalResponse.twilioInfo.message.toJSON();
                var smsInfo = {};
                smsInfo.userFacilityId = reviewObj.userFacilityId,
                    smsInfo.sentTo = reviewObj.visitorId,
                    smsInfo.to = finalResponse.VisitorData.phoneNumber,
                    smsInfo.from = messageBody.from,
                    smsInfo.text = messageBody.body,
                    smsInfo.status = finalResponse.twilioInfo.status
                var smsHistory = new SMSHistory(smsInfo);
                smsHistory.save(function (err, SmsSavedData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            }

        ], function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: data
                });
            }
        });
    }
}


/**
 * Function is use to get by id for admin
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 30-may-2018
 */
function getprofile(req, res) {
    User.findOne({
        _id: req.query.id,
        isDelete: false
    }, function (err, profileData) {
        // console.log("getprofile--------", profileData);
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        } else {
            res.json({
                code: config.statusCode.success,
                data: profileData
            });
        }
    }).catch(function (err) {
        res.json({
            code: config.statusCode.error,
            data: {},
            message: i18n.__("ERROR")
        })

    });
}


/**
 * Function is use to update admin profile
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 01-june-2018
 */
function updateProfile(req, res) {
    // console.log("updateProfile");
    var email = req.body.email.toLowerCase();
    var finalResponse = {};
    finalResponse.userData = {};
    var adminObj = {
        firstName: req.swagger.params.firstName.value,
        lastName: req.swagger.params.lastName.value,
        email: req.swagger.params.email.value,
        phoneNumber: req.swagger.params.phoneNumber.value,
        file: req.swagger.params.file.value,
        _id: req.swagger.params._id.value
    }
    waterfall([
        function (callback) { //check email is already exist
            User.findOne({
                email: adminObj.email.trim().toLowerCase(),
                _id: {
                    $ne: adminObj._id
                },
                isDelete: false
            }).lean().exec(function (err, userData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (userData) {
                        res.json({
                            code: config.statusCode.badRequest,
                            data: {},
                            message: i18n.__("EMAIL_ALREADY_EXIST")
                        });
                    } else {
                        callback(null, finalResponse);
                    }
                }
            });
        },
        function (finalResponse, callback) { //Update record
            User.findById(adminObj._id).exec(function (err, data) {
                if (err) {
                    callback(err, false);
                } else {
                    data.firstName = adminObj.firstName;
                    data.lastName = adminObj.lastName;
                    data.userName = adminObj.firstName + ' ' + adminObj.lastName,
                        data.email = adminObj.email;
                    data.phoneNumber = adminObj.phoneNumber;
                    data.modifiedBy = config.role_type.SUPER_ADMIN.name;
                    data.modifiedById = req.user.uid;
                    data.save(function (err, updatedUserData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            if (adminObj.file) { //Update logo if exist
                                var timestamp = Number(new Date()); // current time as number
                                var file = adminObj.file;
                                var userId = data._id;
                                var splitFileName = file.originalname.split('.');
                                var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                                var filename = userId + '_' + timestamp + '.' + ext;
                                var imagePath = "./../client/src/assets/upload/profiles/" + filename;
                                var base_url = config.server_url;

                                utility.fileUpload(path.resolve(imagePath), file.buffer).then(function () {
                                    data.image = filename;
                                    data.save(function (err, updateProfileData) {
                                        if (err) {
                                            callback(err, false);
                                        } else {
                                            callback(null, finalResponse);
                                        }
                                    })
                                })
                            } else {
                                callback(null, finalResponse);
                            }
                        }
                    })
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("UPDATED_SUCCESSFULLY")
            });
        }
    });
}
/**
 * Function is get company by id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 27-Apr-2018
 */
function getCompanyProfileById(req, res) {
    var finalResponse = {};
    var condition = {};
    if (mongoose.Types.ObjectId.isValid(req.user.cmpId)) {
        condition._id = mongoose.Types.ObjectId(req.user.cmpId);
        condition['userInfo.role'] = config.role_type.COMPANY_ADMIN.name;
        var aggregate = [{
                $lookup: {
                    from: 'usercompanies',
                    localField: "_id",
                    foreignField: "companyId",
                    as: "userCmpInfo"
                }
            },
            {
                $unwind: "$userCmpInfo"
            },
            {
                $lookup: {
                    from: 'users',
                    localField: "userCmpInfo.userId",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: "$userInfo"
            },
            {
                $match: condition
            },
        ];
        var project = {
            $project: {
                userId: "$userInfo._id",
                userCmpId: "$userCmpInfo._id",
                firstName: "$userInfo.firstName",
                lastName: "$userInfo.lastName",
                phoneNumber: "$userInfo.phoneNumber",
                email: "$userInfo.email",
                cmpName: "$cmpName",
                cmpLogo: "$cmpLogo",
                address: "$address",
                city: "$city",
                image: "$userInfo.image",
                state: "$state",
                country: "$country",
                zipCode: "$zipCode",
                stateCode: "$stateCode"
            }
        };

        var countQuery = [].concat(aggregate);
        aggregate.push(project);

        Company.aggregate(aggregate).then(function (result) {
            finalResponse.data = result[0];
            // console.log("finalResponse.data------------", finalResponse.data);
            res.json({
                code: config.statusCode.success,
                data: finalResponse.data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }).catch(function (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        });
    } else {
        res.json({
            code: config.statusCode.invalid,
            data: {},
            message: i18n.__("INVALID_URL")
        });
    }
}

/**
 * Function is get company by id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 27-Apr-2018
 */
function getFacilityProfileById(req, res) {
    var finalResponse = {};
    var condition = {};
    if (mongoose.Types.ObjectId.isValid(req.user.facId)) {
        condition._id = mongoose.Types.ObjectId(req.user.facId);
        condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;
        var aggregate = [{
                $lookup: {
                    from: 'userfacilities',
                    localField: "_id",
                    foreignField: "facilityId",
                    as: "userFacInfo"
                }
            },
            {
                $unwind: "$userFacInfo"
            },
            {
                $lookup: {
                    from: 'usercompanies',
                    localField: "userCmpId",
                    foreignField: "_id",
                    as: "usercompanieInfo"
                }
            },
            {
                $unwind: "$usercompanieInfo"
            },
            {
                $lookup: {
                    from: 'companies',
                    localField: "usercompanieInfo.companyId",
                    foreignField: "_id",
                    as: "companyInfo"
                }
            },
            {
                $unwind: "$companyInfo"
            },
            {
                $lookup: {
                    from: 'users',
                    localField: "userFacInfo.userId",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: "$userInfo"
            },
            {
                $match: condition
            },
        ];
        var project = {
            $project: {
                userId: "$userInfo._id",
                userFacId: "$userFacInfo._id",
                firstName: "$userInfo.firstName",
                lastName: "$userInfo.lastName",
                phoneNumber: "$userInfo.phoneNumber",
                email: "$userInfo.email",
                facName: "$facName",
                facLogo: "$facLogo",
                address: "$address",
                city: "$city",
                image: "$userInfo.image",
                state: "$state",
                country: "$country",
                zipCode: "$zipCode",
                stateCode: "$stateCode",
                cmpName: "$companyInfo.cmpName",
                googleLink: "$googleLink",
                twilioTollFreeNumber: "$twilioTollFreeNumber"
            }
        };

        var countQuery = [].concat(aggregate);
        aggregate.push(project);

        Facility.aggregate(aggregate).then(function (result) {
            finalResponse.data = result[0];
            // console.log("finalResponse.data------------", finalResponse.data);
            res.json({
                code: config.statusCode.success,
                data: finalResponse.data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }).catch(function (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        });
    } else {
        res.json({
            code: config.statusCode.invalid,
            data: {},
            message: i18n.__("INVALID_URL")
        });
    }
}

/**
 * Function is use to get by id for employee profile
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 04-june-2018
 */
function getEmployeeProfile(req, res) {
    User.findOne({
        _id: req.query.id,
        isDelete: false
    }, function (err, profileData) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("ERROR")
            })
        } else {
            Facility.findOne({
                _id: mongoose.Types.ObjectId(
                    req.user.facId
                )
            }, function (err, result) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("ERROR")
                    })
                } else {
                    // var o1 = {
                    //     profileData: profileData
                    // };
                    // var o2 = {
                    //     result: result
                    // };

                    // var resultObj = Object.assign(o1, o2);
                    res.json({
                        code: config.statusCode.success,
                        data: {
                            userData: profileData,
                            facilityData: result
                        }
                    });
                }
            })


        }
    }).catch(function (err) {
        res.json({
            code: config.statusCode.error,
            data: {},
            message: i18n.__("ERROR")
        })

    });
}

/**
 * Function is use to change Pwd By Admin
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 05-june-2018
 */
function changePassword(req, res) {
    var finalResponse = {};
    finalResponse.userData = {};
    var adminObj = {
        currentPassword: req.body.currentPassword,
        password: req.body.password,
        _id: req.user.uid
    }
    waterfall([
        function (callback) { //check current password
            User.findOne({
                password: utility.getEncryptText(adminObj.currentPassword),
                _id: adminObj._id,
                isDelete: false
            }).lean().exec(function (err, userData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (!userData) {
                        res.json({
                            code: config.statusCode.badRequest,
                            data: {},
                            message: i18n.__("PASSWORD_INVALID")
                        });
                    } else {
                        callback(null, finalResponse);
                    }
                }
            });
        },
        function (finalResponse, callback) { //Update new password 
            User.findById(adminObj._id).exec(function (err, data) {
                if (err) {
                    callback(err, false);
                } else {
                    data.password = utility.getEncryptText(adminObj.password);
                    data.save(function (err, updatedUserData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    })
                }
            })
        }

    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("PASSWORD_UPDATED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is request Reset Password
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 06-June-2018
 */

function reqResetPassword(req, res) {
    var finalResponse = {};
    finalResponse.userData = {};
    var userObj = {
        email: req.body.email
    }
    if (!userObj.email) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else {
        waterfall([
                function (callback) { //verify email 
                    User.findOne({
                        email: userObj.email.trim().toLowerCase(),
                        isDelete: false
                    }).lean().exec(function (err, userData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            if (!userData) {
                                res.json({
                                    code: config.statusCode.badRequest,
                                    data: {},
                                    message: i18n.__("FORGOT_PASSWORD_LINK")
                                });
                            } else {
                                finalResponse.userData = userData;
                                callback(null, finalResponse);
                            }
                        }
                    });
                },
                function (finalResponse, callback) { //Create request password link
                    var date = new Date();
                    finalResponse.forgotPwdToken = utility.getEncryptText(Math.random().toString(4).slice(2) + date.getTime());
                    finalResponse.forgotPwdLink = config.email.base_url + '/resetpassword/' + finalResponse.forgotPwdToken;
                    User.findOneAndUpdate({
                        _id: finalResponse.userData._id
                    }, {
                        $set: {
                            forgotPwdToken: finalResponse.forgotPwdToken
                        }
                    }, function (err, updateTokenData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                },
                function (finalResponse, callback) { //Send Email to User for reset password
                    var baseUrl = config.email.base_url;
                    var options = {
                        template: 'forgot_password.html',
                        from: config.email.from,
                        repalcement: {
                            "{{user.name}}": finalResponse.userData.firstName.charAt(0).toUpperCase() + finalResponse.userData.firstName.slice(1).toLowerCase() + ' ' + finalResponse.userData.lastName.charAt(0).toUpperCase() + finalResponse.userData.lastName.slice(1).toLowerCase(),
                            "{{user.forgot_token}}": finalResponse.forgotPwdLink,
                            "{{logo_url}}": baseUrl + config.email.logo_url,
                            "{{copyright}}": config.email.copyright,
                            "{{user.login_url}}": baseUrl,
                            "{{link.abuse_email}}": config.email.abuse_email
                        },
                        to: finalResponse.userData.email,
                        subject: 'Forgot Password'
                    };
                    emailSend.smtp.sendMail(options, function (err, response) {
                        if (err) {
                            callback(null, finalResponse);
                        } else {
                            callback(null, finalResponse);
                        }
                    })
                }
            ],
            function (err, data) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: {},
                        message: i18n.__("FORGOT_PASSWORD_LINK")
                    });
                }
            });

    }
}

/**
 * Function is use to verify reset password link
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 06-June-2018
 */
function verifyReSetPwdLink(req, res) {
    var finalResponse = {};
    finalResponse.userData = {};
    waterfall([
        function (callback) { //Verify token key is valid 
            User.findOne({
                forgotPwdToken: req.body.forgotPwdToken
            }).exec(function (err, userData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (!userData) {
                        res.json({
                            code: config.statusCode.invalid,
                            data: {},
                            message: i18n.__("INVALID_URL")
                        });
                    } else {
                        finalResponse.userData = userData;
                        callback(null, finalResponse);
                    }
                }
            })
        },
        function (finalResponse, callback) { //Verify visitor
            if (finalResponse.userData.isDelete == true || finalResponse.userData.forgotPwdToken == '') {
                res.json({
                    code: config.statusCode.serviceUnavailable,
                    data: {},
                    message: i18n.__("LINK_EXPIRED")
                });
            } else {
                callback(null, finalResponse);
            }
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("ACCOUNT_VERIFIED")
            });
        }
    });
}


/**
 * Function is use to reset Password
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 06-June-2018
 */
function resetPassword(req, res) {
    var finalResponse = {};
    finalResponse.userData = {};
    var adminObj = {
        password: req.body.password,
        forgotPwdToken: req.body.forgotPwdToken
    }
    if (!adminObj.password || !adminObj.forgotPwdToken) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } {
        waterfall([
            function (callback) { // reset password
                User.findOneAndUpdate({
                    forgotPwdToken: adminObj.forgotPwdToken
                }, {
                    $set: {
                        password: utility.getEncryptText(adminObj.password),
                        forgotPwdToken: ''
                    }
                }, function (err, updatedUserData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            },

        ], function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: data,
                    message: i18n.__("PASSWORD_UPDATED_SUCCESSFULLY")
                });
            }
        });
    }
}