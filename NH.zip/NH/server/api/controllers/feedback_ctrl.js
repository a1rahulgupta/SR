'use strict';

var mongoose = require('mongoose'),
    validator = require('validator'),
    utility = require('../lib/utility.js'),
    crypto = require('./../lib/crypto.js'),
    twilio = require('./../lib/twilio.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    i18n = require("i18n"),
    moment = require('moment'),

    //require collections
    User = mongoose.model('user'),
    Facility = mongoose.model('facility'),
    UserFacility = mongoose.model('userFacility'),
    FeebackCategory = mongoose.model('feedbackCategory'),
    EmployeeReview = mongoose.model('employeeReview'),
    EmployeeComplaint = mongoose.model('employeeComplaint'),
    PatientReview = mongoose.model('patientReview'),
    PatientComplaint = mongoose.model('patientComplaint'),
    Visitor = mongoose.model('visitors'),
    CheckInOut = mongoose.model('checkInOut'),
    SMSHistory = mongoose.model('smsHistory'),
    IncidentReports = mongoose.model('incidentReport'),
    FacilityAppSettings = mongoose.model('facilityAppSettings'),
    FacilityRatingResponseSettings = mongoose.model('facilityRatingResponseSettings'),
    FacilitySmsSettings = mongoose.model('facilitySmsSettings'),
    FacilityNotificationSettings = mongoose.model('facilityNotificationSettings'),
    NotificationSmsHistory = mongoose.model('notificationSmsHistory'),
    Suggestions = mongoose.model('suggestion'),
    SendSmsInterval = mongoose.model('sendSmsInterval'),
    TrackingViewedLink = mongoose.model('trackingViewedLink'),

    //require files
    emailSend = __rootRequire('api/core/email'),
    config = require('../../config/config.js'),
    MessagingResponse = require('twilio').twiml.MessagingResponse,

    //Weather 
    weather = require("openweather-node");
    //set your API key if you have one
    weather.setAPPID(config.openWeather.setAPPID);
    //set the culture
    weather.setCulture(config.openWeather.setCulture);
    //set the forecast type
    weather.setForecastType(config.openWeather.setForecastType);

module.exports = {
    addCategory: addCategory,
    getCategoryList: getCategoryList,
    addEmployeeReview: addEmployeeReview,
    addEmployeeComplaint: addEmployeeComplaint,
    addPatientReview: addPatientReview,
    addPatientComplaint: addPatientComplaint,
    getFacilityLogo: getFacilityLogo,
    visitorCheckIn: visitorCheckIn,
    addVisitedInfo: addVisitedInfo,
    getVisitorData: getVisitorData,
    addVisitedInfoById: addVisitedInfoById,
    visitorCheckOut: visitorCheckOut,
    twilioSmsResponse: twilioSmsResponse,
    logoutKioskMode: logoutKioskMode,
    getVisitorTrends: getVisitorTrends,
    getVisitorRatingGraph: getVisitorRatingGraph,
    getActivities: getActivities,
    getSuggestion: getSuggestion,
    updateSuggestion: updateSuggestion,
    sendSmsUsingInterval: sendSmsUsingInterval,
    addResidentAndCheckedIn: addResidentAndCheckedIn,
    addResidentAndCheckedOut: addResidentAndCheckedOut,
    getPopupMessages: getPopupMessages,
    sendMessageOnChatPopup: sendMessageOnChatPopup,
    viewMessageOnChatPopup: viewMessageOnChatPopup,
    getCheckInExpressResident: getCheckInExpressResident
}
/**
 * Function is use to add Category for feedback
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 11-May-2018
 */
function addCategory(req, res) {
    var finalResponse = {};
    finalResponse.categorySavedData = {};
    var categoryObj = {
        category_name: req.body.category_name,
    }

    if (!categoryObj.category_name) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } {
        waterfall([
                function (callback) { //Save category data
                    var obj = {
                        category_name: categoryObj.category_name,
                    };
                    var categoryRecord = new FeebackCategory(obj);
                    categoryRecord.save(function (err, categorySavedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.categorySavedData = categorySavedData;
                            callback(null, finalResponse);
                        }
                    });
                },
            ],
            function (err, data) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: data,
                        message: i18n.__("CATEGORY_SAVED_SUCCESSFULLY")
                    });
                }
            });
    }
}
/**
 * Function is use to get Company List For Facility Admin
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 3-May-2018
 */

function getCategoryList(req, res) {
    waterfall([
        function (callback) { //category Data
            var condition = {};
            condition.isDelete = false;
            condition.status = false;
            var aggregate = [{
                $match: condition
            }, ];
            var project = {
                $project: {
                    "category_name": "$category_name"
                }
            };
            aggregate.push(project);
            FeebackCategory.aggregate(aggregate).then(function (categoryData) {
                var data = {};
                data = categoryData;
                callback(null, data);
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to add Employee Review 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 11-May-2018
 */
function addEmployeeReview(req, res) {
    var finalResponse = {};
    finalResponse.reviewSavedData = {};
    var reviewObj = {
        category_id: req.body.category_id,
        userFacilityId: req.body.userFacilityId,
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        phoneNumber: req.body.phoneNumber,
        rating: req.body.rating,
        comments: req.body.comments
    }

    if (!reviewObj.category_id || !reviewObj.userFacilityId || !reviewObj.firstName || !reviewObj.lastName || !reviewObj.rating || !reviewObj.comments) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else if (reviewObj.email && !config.isEmail(reviewObj.email)) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("INVALID_EMAIL")
        });
    } else {
        waterfall([
                function (callback) { //Save review data
                    var obj = {
                        category_id: reviewObj.category_id,
                        userFacilityId: reviewObj.userFacilityId,
                        firstName: reviewObj.firstName,
                        lastName: reviewObj.lastName,
                        email: reviewObj.email,
                        phoneNumber: reviewObj.phoneNumber,
                        rating: reviewObj.rating,
                        comments: reviewObj.comments
                    };
                    var employeeReviewRecord = new EmployeeReview(obj);
                    employeeReviewRecord.save(function (err, reviewSavedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.reviewSavedData = reviewSavedData;
                            callback(null, finalResponse);
                        }
                    });
                },
            ],
            function (err, data) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: data,
                        message: i18n.__("REVIEW_SUBMITTED_SUCCESSFULLY")
                    });
                }
            });
    }
}
/**
 * Function is use to add Employee Complaint 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 12-May-2018
 */
function addEmployeeComplaint(req, res) {
    var finalResponse = {};
    finalResponse.complaintSavedData = {};
    var complaintObj = {
        category_id: req.body.category_id,
        userFacilityId: req.body.userFacilityId,
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        phoneNumber: req.body.phoneNumber,
        complaint: req.body.complaint
    }
    if (!complaintObj.category_id || !complaintObj.userFacilityId || !complaintObj.firstName || !complaintObj.lastName || !complaintObj.complaint) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else if (complaintObj.email && !config.isEmail(complaintObj.email)) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("INVALID_EMAIL")
        });
    } else {
        waterfall([
                function (callback) { //Save complaint data
                    var obj = {
                        category_id: complaintObj.category_id,
                        userFacilityId: complaintObj.userFacilityId,
                        firstName: complaintObj.firstName,
                        lastName: complaintObj.lastName,
                        email: complaintObj.email,
                        phoneNumber: complaintObj.phoneNumber,
                        complaint: complaintObj.complaint
                    };
                    var employeeComplaintRecord = new EmployeeComplaint(obj);
                    employeeComplaintRecord.save(function (err, complaintSavedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.complaintSavedData = complaintSavedData;
                            callback(null, finalResponse);
                        }
                    });
                },
            ],
            function (err, data) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: data,
                        message: i18n.__("COMPLAINT_SUBMITTED_SUCCESSFULLY")
                    });
                }
            });
    }
}
/**
 * Function is use to add Patient Review 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 12-May-2018
 */
function addPatientReview(req, res) {
    var finalResponse = {};
    finalResponse.reviewSavedData = {};
    var reviewObj = {
        category_id: req.body.category_id,
        userFacilityId: req.body.userFacilityId,
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        phoneNumber: req.body.phoneNumber,
        rating: req.body.rating,
        comments: req.body.comments
    }

    if (!reviewObj.category_id || !reviewObj.userFacilityId || !reviewObj.firstName || !reviewObj.lastName || !reviewObj.rating || !reviewObj.comments) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else if (reviewObj.email && !config.isEmail(reviewObj.email)) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("INVALID_EMAIL")
        });
    } else {
        waterfall([
                function (callback) { //Save review data
                    var obj = {
                        category_id: reviewObj.category_id,
                        userFacilityId: reviewObj.userFacilityId,
                        firstName: reviewObj.firstName,
                        lastName: reviewObj.lastName,
                        email: reviewObj.email,
                        phoneNumber: reviewObj.phoneNumber,
                        rating: reviewObj.rating,
                        comments: reviewObj.comments
                    };
                    var patientReviewRecord = new PatientReview(obj);
                    patientReviewRecord.save(function (err, reviewSavedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.reviewSavedData = reviewSavedData;
                            callback(null, finalResponse);
                        }
                    });
                },
            ],
            function (err, data) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: data,
                        message: i18n.__("REVIEW_SUBMITTED_SUCCESSFULLY")
                    });
                }
            });
    }
}
/**
 * Function is use to add Patient Complaint 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 12-May-2018
 */
function addPatientComplaint(req, res) {
    var finalResponse = {};
    finalResponse.complaintSavedData = {};
    var complaintObj = {
        category_id: req.body.category_id,
        userFacilityId: req.body.userFacilityId,
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        phoneNumber: req.body.phoneNumber,
        complaint: req.body.complaint
    }

    if (!complaintObj.category_id || !complaintObj.userFacilityId || !complaintObj.firstName || !complaintObj.lastName || !complaintObj.complaint) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else if (complaintObj.email && !config.isEmail(complaintObj.email)) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("INVALID_EMAIL")
        });
    } else {
        waterfall([
                function (callback) { //Save complaint data
                    var obj = {
                        category_id: complaintObj.category_id,
                        userFacilityId: complaintObj.userFacilityId,
                        firstName: complaintObj.firstName,
                        lastName: complaintObj.lastName,
                        email: complaintObj.email,
                        phoneNumber: complaintObj.phoneNumber,
                        complaint: complaintObj.complaint
                    };
                    var patientComplaintRecord = new PatientComplaint(obj);
                    patientComplaintRecord.save(function (err, complaintSavedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.complaintSavedData = complaintSavedData;
                            callback(null, finalResponse);
                        }
                    });
                },
            ],
            function (err, data) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: data,
                        message: i18n.__("COMPLAINT_SUBMITTED_SUCCESSFULLY")
                    });
                }
            });
    }
}

/**
 * Function is get facility logo
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 12-May-2018
 * Updated By Sunny
 * Updated Date 14-July-2018
 */
function getFacilityLogo(req, res) {
    var finalResponse = {};
    finalResponse.weatherName = '';
    finalResponse.iconurl = '';
    finalResponse.temp = '';
    var condition = {};
    if (mongoose.Types.ObjectId.isValid(req.query.id)) {
        condition._id = mongoose.Types.ObjectId(req.query.id);
        var aggregate = [{
                $lookup: {
                    from: 'userfacilities',
                    localField: "_id",
                    foreignField: "facilityId",
                    as: "userFacInfo"
                }
            },
            {
                $unwind: "$userFacInfo"
            },
            {
                $match: condition
            },
        ];
        var project = {
            $project: {
                facLogo: "$facLogo",
                city: "$city",
                facName: "$facName",
                zipCode: "$zipCode"
            }
        };
        aggregate.push(project);

        Facility.aggregate(aggregate).then(function (result) {
            finalResponse.data = result[0];
            weather.now(finalResponse.data.zipCode, function (err, aData) {
                if (err) {
                    res.json({
                        code: config.statusCode.success,
                        data: finalResponse,
                        message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                    });
                } else {
                    finalResponse.weatherName = aData.values.weather[0].main;
                    finalResponse.iconurl = config.openWeather.iconUrl + aData.values.weather[0].icon + config.openWeather.iconType;
                    finalResponse.temp = parseInt((aData.getFahrenheitTemp()).temp);
                    res.json({
                        code: config.statusCode.success,
                        data: finalResponse,
                        message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                    });
                }
            })
        }).catch(function (err) {
            console.log("err0r", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        });
    } else {
        res.json({
            code: config.statusCode.invalid,
            data: {},
            message: i18n.__("INVALID_URL")
        });
    }
}

/**
 * Function is check visitor phone number
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 12-May-2018
 */
function visitorCheckIn(req, res) {
    var finalResponse = {};
    finalResponse.visitorData = {};
    var visitorObj = {
        phoneNumber: config.phoneNumber.countryCode + req.body.phoneNumber,
    }
    if (!visitorObj.phoneNumber) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else {
        waterfall([
            function (callback) { //Check for already exist phone number
                var phoneNumber = visitorObj.phoneNumber.trim();
                console.log("phoneNumber------>", phoneNumber);

                var userFacId = mongoose.Types.ObjectId(req.user.userFacId);
                Visitor.existPhoneCheck(phoneNumber, userFacId, function (err, exist) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (!exist) {
                            Visitor.findOne({
                                phoneNumber: visitorObj.phoneNumber.trim(),
                                isDelete: false,
                                userFacilityId: mongoose.Types.ObjectId(req.user.userFacId)
                            }).lean().exec(function (err, checkInData) {
                                if (err) {
                                    callback(err, false);
                                } else {
                                    if (checkInData) {
                                        CheckInOut.findOne({
                                            visitorId: mongoose.Types.ObjectId(checkInData._id),
                                            status: '1'
                                        }).lean().exec(function (err, checkData) {
                                            if (checkData) {
                                                res.json({
                                                    code: config.statusCode.badRequest,
                                                    data: {},
                                                    message: i18n.__("VISITOR_ALREADY_CHECKED_IN")
                                                })
                                            } else {
                                                res.json({
                                                    code: config.statusCode.continue,
                                                    data: checkInData
                                                })
                                            }
                                        });
                                    }
                                }
                            })
                        } else {
                            callback(null, finalResponse);
                        }
                    }
                });
            }
        ],
        function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: visitorObj
                });
            }
        });
    }
}

/**
 * Function is add Visited Info
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 14-May-2018
 * Updated by Vishaka
 * Updated Date 13-July-2018
 * Updated by Sunny
 * Updated Date 18-july-2018
 */
function addVisitedInfo(req, res) {
    
    var finalResponse = {};
    finalResponse.userData = {};
    finalResponse.checkInData = {};
    finalResponse.visitorData = {};
    finalResponse.facilityData = {};
    finalResponse.twilioInfo = {};
    finalResponse.facilityAppSettings = {};

    var visitorObj = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        visitor_type: req.body.visitor_type,
        relation_type: req.body.relation_type,
        vendor_type: req.body.vendor_type,
        phoneNumber: req.body.phoneNumber,
        userFacilityId: req.body.userFacilityId,
        visitedTo: req.body.visitedTo,
        company_name: req.body.company_name,
        room_no: req.body.room_no,
        bed_no: req.body.bed_no,
        checkInDate: req.body.checkInDate
    }
    if (!visitorObj.firstName || !visitorObj.lastName || !visitorObj.visitor_type || !visitorObj.phoneNumber || !visitorObj.userFacilityId) {

        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else if (visitorObj.email && !config.isEmail(visitorObj.email)) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("INVALID_EMAIL")
        });
    } else {
        waterfall([
            function (callback) { //Save visited info
                var obj = {
                    firstName: visitorObj.firstName,
                    lastName: visitorObj.lastName,
                    visitedTo: visitorObj.visitedTo,
                    phoneNumber: visitorObj.phoneNumber,
                    email: visitorObj.email.toLowerCase(),
                    userFacilityId: visitorObj.userFacilityId,
                    visitor_type: visitorObj.visitor_type,
                    relation_type: visitorObj.relation_type,
                    vendor_type: visitorObj.vendor_type,
                    company_name: visitorObj.company_name,
                    room_no: visitorObj.room_no,
                    bed_no: visitorObj.bed_no,
                    checkInDate: visitorObj.checkInDate

                };
                var userRecord = new Visitor(obj);
                userRecord.save(function (err, visitorData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.visitorData = visitorData;
                        callback(null, finalResponse);
                    }
                })
            },
            function (finalResponse, callback) { //Save checkIn data
                var newObj = {
                    visitorId: finalResponse.visitorData._id,
                    userFacilityId: finalResponse.visitorData.userFacilityId,
                    checkInDate: visitorObj.checkInDate,
                    visitedTo: finalResponse.visitorData.visitedTo
                };
                var checkInRecord = new CheckInOut(newObj);
                checkInRecord.save(function (err, checkInData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.checkInData = checkInData;
                        callback(null, finalResponse);
                    }
                });
            },
            function (finalResponse, callback) { // get facility name by facId
                Facility.findById(mongoose.Types.ObjectId(req.user.facId)).exec(function (err, facilityData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.facilityData = facilityData;
                        var sendCheckInObj = {
                            userFacId: visitorObj.userFacilityId,
                            checkInDate: visitorObj.checkInDate,
                            facName: finalResponse.facilityData.facName,
                            twilioTollFreeNumber: finalResponse.facilityData.twilioTollFreeNumber,
                            visitorData: finalResponse.visitorData
                        }
                        sendCheckInNotifications(sendCheckInObj);
                        callback(null, finalResponse);
                    }
                })
            },
            function (finalResponse, callback) { // Get facility app settings
                FacilityAppSettings.findOne({
                    facId: mongoose.Types.ObjectId(finalResponse.facilityData._id),
                    isDelete: false,
                    status: true
                }).exec(function (err, facilityAppSettings) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.facilityAppSettings = facilityAppSettings;
                        // console.log("finalResponse.facilityAppSettings", finalResponse.facilityAppSettings);
                        callback(null, finalResponse);
                    }
                })
            },
            function (finalResponse, callback) { //check sms limit of visitor exist
                if (visitorObj.visitor_type == 'family' || visitorObj.visitor_type == 'poa' || visitorObj.visitor_type == 'guardian') {
                    if (finalResponse.facilityAppSettings.smsLimits.status == true) {
                        var checkSmsLimitObj = {
                            visitorId: finalResponse.visitorData._id,
                            userFacId: visitorObj.userFacilityId,
                            smsLimits: finalResponse.facilityAppSettings.smsLimits,
                            to: visitorObj.phoneNumber
                        }
                        utility.checkSmsLimitExist(checkSmsLimitObj, function (smsLimitExist) {
                            if (smsLimitExist == true) {
                                finalResponse.havingSmsLimit = true;
                                callback(null, finalResponse);
                            } else {
                                finalResponse.havingSmsLimit = false;
                                callback(null, finalResponse);
                            }
                        });
                    } else {
                        finalResponse.havingSmsLimit = true;
                        callback(null, finalResponse);
                    }
                } else {
                    callback(null, finalResponse);
                }

            },
            function (finalResponse, callback) { //send check in sms to the visitor
                if (visitorObj.visitor_type == 'family' || visitorObj.visitor_type == 'poa' || visitorObj.visitor_type == 'guardian') {
                    if (finalResponse.havingSmsLimit == true && finalResponse.visitorData.isSms == true && finalResponse.facilityAppSettings.checkInSms.status == true) { //checking condition of (sms limit/is sms/check in sms)
                        var text; 
                        if(finalResponse.facilityAppSettings.checkInSms.visitorName == true){
                            text = finalResponse.visitorData.firstName+ ', ' +finalResponse.facilityAppSettings.checkInSms.message+', '+config.textMessageTwilio.STOP_MESSAGE_REPLY;                    
                        }else{
                            text = finalResponse.facilityAppSettings.checkInSms.message+', '+config.textMessageTwilio.STOP_MESSAGE_REPLY;                    
                        }
                        if (finalResponse.facilityAppSettings.checkInSmsInterval.status == true) {
                            finalResponse.checkInSmsInterval = true;
                            var dateObj = new Date();
                            var sendSmsObj = {
                                userFacId: visitorObj.userFacilityId,
                                visitorId: finalResponse.visitorData._id,
                                checkInOutId: finalResponse.checkInData._id,
                                message: text,
                                smsType: 'checkIn',
                                to: visitorObj.phoneNumber,
                                from: finalResponse.facilityData.twilioTollFreeNumber,
                                sendingTime: moment(dateObj).add(parseInt(finalResponse.facilityAppSettings.checkInSmsInterval.minutes), 'm').toDate()
                            }
                            var sendSmsInterval = new SendSmsInterval(sendSmsObj);
                            sendSmsInterval.save(function (err, SmsSavedData) {
                                if (err) {
                                    callback(err, false);
                                } else {
                                    callback(null, finalResponse);
                                }
                            });
                        } else {
                            var smsData = {
                                to: visitorObj.phoneNumber,
                                from: finalResponse.facilityData.twilioTollFreeNumber,
                                message: text
                            }
                            twilio.sendSMS(smsData, function (returnData) {
                                if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                                    finalResponse.twilioInfo = returnData;
                                    callback(null, finalResponse);
                                } else {
                                    finalResponse.twilioInfo = returnData;
                                    callback(null, finalResponse);
                                }
                            });
                        }
                    } else {
                        callback(null, finalResponse);
                    }
                } else {
                    callback(null, finalResponse);
                }
            },
            function (finalResponse, callback) { //Save sms history
                if (visitorObj.visitor_type == 'family' || visitorObj.visitor_type == 'poa' || visitorObj.visitor_type == 'guardian') {
                    if (finalResponse.havingSmsLimit == true && finalResponse.visitorData.isSms == true && finalResponse.facilityAppSettings.checkInSms.status == true && finalResponse.checkInSmsInterval == false && finalResponse.twilioInfo.status == config.statusCode.success) {
                        var messageBody = finalResponse.twilioInfo.message.toJSON();
                        var smsInfo = {};
                        smsInfo.userFacilityId = visitorObj.userFacilityId;
                        smsInfo.visitorId = finalResponse.visitorData._id;
                        smsInfo.to = visitorObj.phoneNumber;
                        smsInfo.from = messageBody.from;
                        smsInfo.text = messageBody.body;
                        var smsHistory = new SMSHistory(smsInfo);
                        smsHistory.save(function (err, SmsSavedData) {
                            if (err) {
                                callback(err, false);
                            } else {
                                callback(null, finalResponse);
                            }
                        });
                    } else {
                        callback(null, finalResponse);
                    }
                } else {
                    callback(null, finalResponse);
                }
            },
        ],
        function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: data,
                    message: i18n.__("CHECK_IN_SUCCESSFULLY")
                });
            }
        });
    }
}


/**
 * Function is get get VisitorData
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 14-May-2018
 */
function getVisitorData(req, res) {
    var finalResponse = {};
    var condition = {};
    if (mongoose.Types.ObjectId.isValid(req.query.id)) {
        condition._id = mongoose.Types.ObjectId(req.query.id);
        Visitor.findById(condition).then(function (result) {
            finalResponse.data = result;
            res.json({
                code: config.statusCode.success,
                data: finalResponse.data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }).catch(function (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        });
    } else {
        res.json({
            code: config.statusCode.invalid,
            data: {},
            message: i18n.__("INVALID_URL")
        });
    }
}

/**
 * Function is add Visited Check In
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 14-May-2018
 * Updated by Sunny
 * Updated Date 18-July-2018
 */
function addVisitedInfoById(req, res) {
    // console.log("comes@")
    var finalResponse = {};
    finalResponse.checkInData = {};
    finalResponse.facilityData = {};
    finalResponse.twilioInfo = {};
    finalResponse.visitorData = {};
    finalResponse.facilityAppSettings = {};
    finalResponse.checkInSmsInterval = false;
    finalResponse.havingSmsLimit = false;
    var visitorObj = {
        userFacilityId: req.body.userFacilityId,
        visitedTo: req.body.visitedTo,
        visitorId: req.body.visitorId,
        checkInDate: req.body.checkInDate,
        phoneNumber: req.body.phoneNumber
    }
    if (!visitorObj.visitedTo || !visitorObj.userFacilityId || !visitorObj.visitorId || !visitorObj.checkInDate) {

        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else if (visitorObj.email && !config.isEmail(visitorObj.email)) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("INVALID_EMAIL")
        });
    } else {
        waterfall([
            function (callback) { //Save checkIn data
                var newObj = {
                    visitorId: visitorObj.visitorId,
                    userFacilityId: visitorObj.userFacilityId,
                    checkInDate: visitorObj.checkInDate,
                    visitedTo: visitorObj.visitedTo
                };
                var checkInRecord = new CheckInOut(newObj);
                checkInRecord.save(function (err, checkInData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.checkInData = checkInData;
                        callback(null, finalResponse);
                    }
                });
            },
            function (finalResponse, callback) { // get visitor data
                Visitor.findOne({
                    _id: visitorObj.visitorId,
                    userFacilityId: mongoose.Types.ObjectId(req.user.userFacId)
                }).exec(function (err, visitorData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.visitorData = visitorData;
                        callback(null, finalResponse);
                    }
                })
            },
            function (finalResponse, callback) { // get facility name by facId
                Facility.findById(mongoose.Types.ObjectId(req.user.facId)).exec(function (err, facilityData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.facilityData = facilityData;
                        var sendCheckInObj = {
                            userFacId: visitorObj.userFacilityId,
                            checkInDate: visitorObj.checkInDate,
                            facName: finalResponse.facilityData.facName,
                            twilioTollFreeNumber: finalResponse.facilityData.twilioTollFreeNumber,
                            visitorData: finalResponse.visitorData
                        }
                        sendCheckInNotifications(sendCheckInObj);
                        callback(null, finalResponse);
                    }
                })
            },
            function (finalResponse, callback) { // Get facility app settings
                FacilityAppSettings.findOne({
                    facId: mongoose.Types.ObjectId(finalResponse.facilityData._id),
                    isDelete: false,
                    status: true
                }).exec(function (err, facilityAppSettings) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.facilityAppSettings = facilityAppSettings;
                        // console.log("finalResponse.facilityAppSettings", finalResponse.facilityAppSettings);
                        callback(null, finalResponse);
                    }
                })
            },
            function (finalResponse, callback) { //check sms limit of visitor exist
                if (finalResponse.facilityAppSettings.smsLimits.status == true) {
                    var checkSmsLimitObj = {
                        visitorId: finalResponse.visitorData._id,
                        userFacId: visitorObj.userFacilityId,
                        smsLimits: finalResponse.facilityAppSettings.smsLimits,
                        to: visitorObj.phoneNumber
                    }
                    utility.checkSmsLimitExist(checkSmsLimitObj, function (smsLimitExist) {
                        if (smsLimitExist == true) {
                            finalResponse.havingSmsLimit = true;
                            callback(null, finalResponse);
                        } else {
                            finalResponse.havingSmsLimit = false;
                            callback(null, finalResponse);
                        }
                    });
                } else {
                    finalResponse.havingSmsLimit = true;
                    callback(null, finalResponse);
                }
            },
            function (finalResponse, callback) { // send check in sms to the visitor 
                if (finalResponse.visitorData.visitor_type == 'family' || finalResponse.visitorData.visitor_type == 'poa' || finalResponse.visitorData.visitor_type == 'guardian') {

                    if (finalResponse.havingSmsLimit == true && finalResponse.visitorData.isSms == true && finalResponse.facilityAppSettings.checkInSms.status == true) {
                        var text; 
                        if(finalResponse.facilityAppSettings.checkInSms.visitorName == true){
                            text = finalResponse.visitorData.firstName+ ', ' +finalResponse.facilityAppSettings.checkInSms.message+', '+config.textMessageTwilio.STOP_MESSAGE_REPLY;                    
                        }else{
                            text = finalResponse.facilityAppSettings.checkInSms.message+', '+config.textMessageTwilio.STOP_MESSAGE_REPLY;                    
                        }
                        if (finalResponse.facilityAppSettings.checkInSmsInterval.status == true) {
                            finalResponse.checkInSmsInterval = true;
                            var dateObj = new Date();
                            var sendSmsObj = {
                                userFacId: visitorObj.userFacilityId,
                                visitorId: finalResponse.visitorData._id,
                                checkInOutId: finalResponse.checkInData._id,
                                message: text,
                                smsType: 'checkIn',
                                to: visitorObj.phoneNumber,
                                from: finalResponse.facilityData.twilioTollFreeNumber,
                                sendingTime: moment(dateObj).add(parseInt(finalResponse.facilityAppSettings.checkInSmsInterval.minutes), 'm').toDate()
                            }
                            var sendSmsInterval = new SendSmsInterval(sendSmsObj);
                            sendSmsInterval.save(function (err, SmsSavedData) {
                                if (err) {
                                    callback(err, false);
                                } else {
                                    callback(null, finalResponse);
                                }
                            });
                        } else {
                            var smsData = {
                                to: visitorObj.phoneNumber,
                                from: finalResponse.facilityData.twilioTollFreeNumber,
                                message: text
                            }
                            twilio.sendSMS(smsData, function (returnData) {
                                if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                                    finalResponse.twilioInfo = returnData;
                                    callback(null, finalResponse);
                                } else {
                                    finalResponse.twilioInfo = returnData;
                                    callback(null, finalResponse);
                                }
                            });
                        }
                    } else {
                        callback(null, finalResponse);
                    }
                } else {
                    callback(null, finalResponse);
                }
            },
            function (finalResponse, callback) { //Save sms history
                if (finalResponse.visitorData.visitor_type == 'family' || finalResponse.visitorData.visitor_type == 'poa' || finalResponse.visitorData.visitor_type == 'guardian') {
                    if (finalResponse.havingSmsLimit == true && finalResponse.visitorData.isSms == true && finalResponse.facilityAppSettings.checkInSms.status == true && finalResponse.checkInSmsInterval == false && finalResponse.twilioInfo.status == config.statusCode.success) {
                        var messageBody = finalResponse.twilioInfo.message.toJSON();
                        var smsInfo = {};
                        smsInfo.userFacilityId = visitorObj.userFacilityId;
                        smsInfo.visitorId = finalResponse.visitorData._id;
                        smsInfo.to = visitorObj.phoneNumber;
                        smsInfo.from = messageBody.from;
                        smsInfo.text = messageBody.body;
                        var smsHistory = new SMSHistory(smsInfo);
                        smsHistory.save(function (err, SmsSavedData) {
                            if (err) {
                                callback(err, false);
                            } else {
                                callback(null, finalResponse);
                            }
                        });
                    } else {
                        callback(null, finalResponse);
                    }
                } else {
                    callback(null, finalResponse);
                }
            },
        ],
        function (err, data) {     
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
            // console.log("comes@", err);                        
                res.json({
                    code: config.statusCode.success,
                    data: data,
                    message: i18n.__("CHECK_IN_SUCCESSFULLY")
                });
            }
        });
    }
}

/**
 * Function is add visitor Check Out
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 14-May-2018
 * Updated by Sunny
 * Updated Date 16 July 2018
 */
function visitorCheckOut(req, res) {
    var finalResponse = {};
    finalResponse.VisitorData = {};
    finalResponse.twilioInfo = {};
    finalResponse.facilityData = {};
    finalResponse.facilitySmsSettings = {};
    finalResponse.facilityAppSettings = {};
    finalResponse.textExist = true;
    finalResponse.checkOutSmsInterval = false;
    finalResponse.havingSmsLimit = false;

    var visitorObj = {
        userFacilityId: req.body.userFacilityId,
        checkOutDate: req.body.checkOutDate
    }
    if(req.body.byFacility){// This is for checkout visitor by facility
        visitorObj.phoneNumber = req.body.phoneNumber;
    }else{
        visitorObj.phoneNumber = config.phoneNumber.countryCode + req.body.phoneNumber;
    }
    if (!visitorObj.userFacilityId || !visitorObj.checkOutDate || !visitorObj.phoneNumber) {

        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else {
        waterfall([
            function (callback) { //Phone number verify
                Visitor.findOne({
                    phoneNumber: visitorObj.phoneNumber,
                    isDelete: false,
                    userFacilityId: mongoose.Types.ObjectId(req.user.userFacId)
                }).exec(function (err, VisitorData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (!VisitorData) {
                            res.json({
                                code: config.statusCode.invalid,
                                data: {},
                                message: i18n.__("UNAUTHORIZED")
                            });
                        } else {
                            finalResponse.VisitorData = VisitorData;
                            callback(null, finalResponse);
                        }
                    }
                })
            },
            function (finalResponse, callback) { //Check Visitor if already Checked out
                CheckInOut.findOne({
                    visitorId: finalResponse.VisitorData._id,
                    status: '1'
                }).exec(function (err, VisitorCheckedData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (!VisitorCheckedData) {
                            res.json({
                                code: config.statusCode.invalid,
                                data: {},
                                message: i18n.__("VISITOR_ALREADY_CHECKED_OUT")
                            });
                        } else {
                            callback(null, finalResponse);
                        }
                    }
                })
            },
            function (finalResponse, callback) { // visitor check out
                CheckInOut.findOneAndUpdate({
                    visitorId: finalResponse.VisitorData._id,
                    status: '1'
                }, {
                    $set: {
                        status: "0",
                        checkOutDate: visitorObj.checkOutDate,
                    }
                }, function (err, visitorSavedData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.visitorSavedData = visitorSavedData;
                        callback(null, finalResponse);
                    }
                });
            },
            function (finalResponse, callback) { // get facility name by facId
                Facility.findById(mongoose.Types.ObjectId(req.user.facId)).exec(function (err, facilityData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.facilityData = facilityData;
                        callback(null, finalResponse);
                    }
                })
            },
            function (finalResponse, callback) { // Get facility sms settings
                FacilitySmsSettings.findOne({
                    facId: mongoose.Types.ObjectId(req.user.facId),
                    isDelete: false,
                    status: true
                }).exec(function (err, facilitySmsSettings) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.facilitySmsSettings = facilitySmsSettings;
                        // console.log("finalResponse.facilitySmsSettings", finalResponse.facilitySmsSettings);
                        callback(null, finalResponse);
                    }
                })
            },
            function (finalResponse, callback) { // Get facility app settings
                FacilityAppSettings.findOne({
                    facId: mongoose.Types.ObjectId(req.user.facId),
                    isDelete: false,
                    status: true
                }).exec(function (err, facilityAppSettings) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.facilityAppSettings = facilityAppSettings;
                        callback(null, finalResponse);
                    }
                })
            },
            function (finalResponse, callback) { //check sms limit of visitor exist
                if (finalResponse.facilityAppSettings.smsLimits.status == true) {
                    var checkSmsLimitObj = {
                        visitorId: finalResponse.VisitorData._id,
                        userFacId: visitorObj.userFacilityId,
                        smsLimits: finalResponse.facilityAppSettings.smsLimits,
                        to: visitorObj.phoneNumber
                    }
                    utility.checkSmsLimitExist(checkSmsLimitObj, function (smsLimitExist) {
                        if (smsLimitExist == true) {
                            finalResponse.havingSmsLimit = true;
                            callback(null, finalResponse);
                        } else {
                            finalResponse.havingSmsLimit = false;
                            callback(null, finalResponse);
                        }
                    });
                } else {
                    finalResponse.havingSmsLimit = true;
                    callback(null, finalResponse);
                }
            },
            function (finalResponse, callback) { // send feedback form  to visitor by SMS
                if (finalResponse.VisitorData.visitor_type == 'family' || finalResponse.VisitorData.visitor_type == 'poa' || finalResponse.VisitorData.visitor_type == 'guardian') {

                    if (finalResponse.havingSmsLimit == true && finalResponse.VisitorData.isSms == true) {
                        var text;
                        var checkingDate = new Date(visitorObj.checkOutDate);
                        var dayOfWeek = checkingDate.getDay();
                        switch (dayOfWeek) {
                            case 0:
                                if (finalResponse.facilitySmsSettings.sunday.status == true) {
                                    text = finalResponse.facilitySmsSettings.sunday.message;
                                } else if (finalResponse.facilityAppSettings.checkOutSms.status == true) {
                                    if(finalResponse.facilityAppSettings.checkOutSms.visitorName == true){
                                        text = finalResponse.VisitorData.firstName+ ', ' +finalResponse.facilityAppSettings.checkOutSms.message;;                    
                                    }else{
                                        text = finalResponse.facilityAppSettings.checkOutSms.message;                    
                                    }
                                } else {
                                    finalResponse.textExist = false;
                                }
                                break;
                            case 1:
                                if (finalResponse.facilitySmsSettings.monday.status == true) {
                                    text = finalResponse.facilitySmsSettings.monday.message;
                                } else if (finalResponse.facilityAppSettings.checkOutSms.status == true) {
                                    if(finalResponse.facilityAppSettings.checkOutSms.visitorName == true){
                                        text = finalResponse.VisitorData.firstName+ ', ' +finalResponse.facilityAppSettings.checkOutSms.message;;                    
                                    }else{
                                        text = finalResponse.facilityAppSettings.checkOutSms.message;                    
                                    }
                                } else {
                                    finalResponse.textExist = false;
                                }
                                break;
                            case 2:
                                if (finalResponse.facilitySmsSettings.tuesday.status == true) {
                                    text = finalResponse.facilitySmsSettings.tuesday.message;
                                } else if (finalResponse.facilityAppSettings.checkOutSms.status == true) {
                                    if(finalResponse.facilityAppSettings.checkOutSms.visitorName == true){
                                        text = finalResponse.VisitorData.firstName+ ', ' +finalResponse.facilityAppSettings.checkOutSms.message;;                    
                                    }else{
                                        text = finalResponse.facilityAppSettings.checkOutSms.message;                    
                                    }
                                } else {
                                    finalResponse.textExist = false;
                                }
                                break;
                            case 3:
                                if (finalResponse.facilitySmsSettings.wednesday.status == true) {
                                    text = finalResponse.facilitySmsSettings.wednesday.message;
                                } else if (finalResponse.facilityAppSettings.checkOutSms.status == true) {
                                    if(finalResponse.facilityAppSettings.checkOutSms.visitorName == true){
                                        text = finalResponse.VisitorData.firstName+ ', ' +finalResponse.facilityAppSettings.checkOutSms.message;;                    
                                    }else{
                                        text = finalResponse.facilityAppSettings.checkOutSms.message;                    
                                    }
                                } else {
                                    finalResponse.textExist = false;
                                }
                                break;
                            case 4:
                                if (finalResponse.facilitySmsSettings.thursday.status == true) {
                                    text = finalResponse.facilitySmsSettings.thursday.message;
                                } else if (finalResponse.facilityAppSettings.checkOutSms.status == true) {
                                    if(finalResponse.facilityAppSettings.checkOutSms.visitorName == true){
                                        text = finalResponse.VisitorData.firstName+ ', ' +finalResponse.facilityAppSettings.checkOutSms.message;;                    
                                    }else{
                                        text = finalResponse.facilityAppSettings.checkOutSms.message;                    
                                    }
                                } else {
                                    finalResponse.textExist = false;
                                }
                                break;
                            case 5:
                                if (finalResponse.facilitySmsSettings.friday.status == true) {
                                    text = finalResponse.facilitySmsSettings.friday.message;
                                } else if (finalResponse.facilityAppSettings.checkOutSms.status == true) {
                                    if(finalResponse.facilityAppSettings.checkOutSms.visitorName == true){
                                        text = finalResponse.VisitorData.firstName+ ', ' +finalResponse.facilityAppSettings.checkOutSms.message;;                    
                                    }else{
                                        text = finalResponse.facilityAppSettings.checkOutSms.message;                    
                                    }
                                } else {
                                    finalResponse.textExist = false;
                                }
                                break;
                            case 6:
                                if (finalResponse.facilitySmsSettings.saturday.status == true) {
                                    text = finalResponse.facilitySmsSettings.saturday.message;
                                } else if (finalResponse.facilityAppSettings.checkOutSms.status == true) {
                                    if(finalResponse.facilityAppSettings.checkOutSms.visitorName == true){
                                        text = finalResponse.VisitorData.firstName+ ', ' +finalResponse.facilityAppSettings.checkOutSms.message;;                    
                                    }else{
                                        text = finalResponse.facilityAppSettings.checkOutSms.message;                    
                                    }
                                } else {
                                    finalResponse.textExist = false;
                                }
                        }
                        if (finalResponse.textExist == true) {

                            if (finalResponse.facilityAppSettings.checkOutSmsInterval.status == true) {
                                finalResponse.checkOutSmsInterval = true;
                                var dateObj = new Date();
                                if (finalResponse.facilityAppSettings.checkOutSmsInterval.period == 'hours') {
                                    var actualDate = moment(dateObj).add(parseInt(finalResponse.facilityAppSettings.checkOutSmsInterval.time), 'h').toDate();
                                } else {
                                    var actualDate = moment(dateObj).add(parseInt(finalResponse.facilityAppSettings.checkOutSmsInterval.time), 'm').toDate();
                                }
                                var sendSmsObj = {
                                    userFacId: visitorObj.userFacilityId,
                                    visitorId: finalResponse.VisitorData._id,
                                    checkInOutId: finalResponse.visitorSavedData._id,
                                    message: text,
                                    smsType: 'checkOut',
                                    to: visitorObj.phoneNumber,
                                    from: finalResponse.facilityData.twilioTollFreeNumber,
                                    sendingTime: actualDate
                                }
                                var sendSmsInterval = new SendSmsInterval(sendSmsObj);
                                sendSmsInterval.save(function (err, SmsSavedData) {
                                    if (err) {
                                        callback(err, false);
                                    } else {
                                        callback(null, finalResponse);
                                    }
                                });
                            } else {
                                var smsData = {
                                    to: visitorObj.phoneNumber,
                                    from: finalResponse.facilityData.twilioTollFreeNumber,
                                    message: text
                                }
                                twilio.sendSMS(smsData, function (returnData) {
                                    if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                                        finalResponse.twilioInfo = returnData;
                                        callback(null, finalResponse);
                                    } else {
                                        finalResponse.twilioInfo = returnData;
                                        callback(null, finalResponse);
                                    }
                                });
                            }
                        } else {
                            callback(null, finalResponse);
                        }
                    } else {
                        callback(null, finalResponse);
                    }
                } else {
                    callback(null, finalResponse);
                }
            },
            function (finalResponse, callback) { //Save sms history
                if (finalResponse.VisitorData.visitor_type == 'family' || finalResponse.VisitorData.visitor_type == 'poa' || finalResponse.VisitorData.visitor_type == 'guardian') {
                    if (finalResponse.havingSmsLimit == true && finalResponse.textExist == true && finalResponse.VisitorData.isSms == true && finalResponse.checkOutSmsInterval == false && finalResponse.twilioInfo.status == config.statusCode.success) {
                        CheckInOut.findOneAndUpdate({
                            _id: finalResponse.visitorSavedData
                        }, {
                            $set: {
                                checkOutSmsSent: true,
                                checkOutSmsSentDate: visitorObj.checkOutDate
                            }
                        }, function (err, againUpdateCheckInOut) {
                            if (err) {
                                callback(err, false);
                            } else {
                                callback(null, finalResponse);
                            }
                        });
                    } else {
                        callback(null, finalResponse);
                    }
                } else {
                    callback(null, finalResponse);
                }
            },
            function (finalResponse, callback) { //Save sms history
                if (finalResponse.VisitorData.visitor_type == 'family' || finalResponse.VisitorData.visitor_type == 'poa' || finalResponse.VisitorData.visitor_type == 'guardian') {
                    if (finalResponse.havingSmsLimit == true && finalResponse.textExist == true && finalResponse.VisitorData.isSms == true && finalResponse.checkOutSmsInterval == false && finalResponse.twilioInfo.status == config.statusCode.success) {
                        var messageBody = finalResponse.twilioInfo.message.toJSON();
                        var smsInfo = {};
                        smsInfo.userFacilityId = visitorObj.userFacilityId;
                        smsInfo.visitorId = finalResponse.VisitorData._id;
                        smsInfo.to = visitorObj.phoneNumber;
                        smsInfo.from = messageBody.from;
                        smsInfo.text = messageBody.body;
                        var smsHistory = new SMSHistory(smsInfo);
                        smsHistory.save(function (err, SmsSavedData) {
                            if (err) {
                                callback(err, false);
                            } else {
                                callback(null, finalResponse);
                            }
                        });
                    } else {
                        callback(null, finalResponse);
                    }
                } else {
                    callback(null, finalResponse);
                }
            }

        ],
        function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: data,
                    message: i18n.__("CHECK_OUT_SUCCESSFULLY")
                });
            }
        });
    }
}

/**
 * Function is receive sms response by twilio webhooks
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 18-May-2018
 */
function twilioSmsResponse(req, res) {
    console.log("it comes in twilio sms response", req.body, '\n');
    const twiml = new MessagingResponse();
    var finalResponse = {};
    finalResponse.visitorData = {};
    finalResponse.twiml = {};
    finalResponse.checkInOutData = {};
    finalResponse.userFacData = {};
    finalResponse.facCheckInfo = {};
    finalResponse.emptyResponse = false;
    finalResponse.trackingToken = '';
    finalResponse.trackingLink = '';
    finalResponse.checkInButNotCheckOut = false;
    finalResponse.receivedSmsAfterCheckIn = false;
    finalResponse.smsStatus = true;
    finalResponse.facilitySmsSettings = {};
    finalResponse.facilityRatingAndResponseSettings = {};
    finalResponse.facilityAppSettings = {};
    finalResponse.text = '';
    if (!req.body.Body || !req.body.From || !req.body.To) { // respond when body and to does not exist
        res.writeHead(200, {
            'Content-Type': 'text/xml'
        });
        res.end(twiml.toString());
    } else {
        waterfall([
                function (callback) { //Check facility exists or activate-deactivate
                    var condition = {};
                    condition.isDelete = false;
                    condition.status = '1';
                    condition['twilioTollFreeNumber'] = req.body.To;
                    condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;

                    var aggregate = [{
                            $lookup: {
                                from: 'userfacilities',
                                localField: "_id",
                                foreignField: "facilityId",
                                as: "userFacInfo"
                            }
                        },
                        {
                            $unwind: "$userFacInfo"
                        },
                        {
                            $lookup: {
                                from: 'users',
                                localField: "userFacInfo.userId",
                                foreignField: "_id",
                                as: "userInfo"
                            }
                        },
                        {
                            $unwind: "$userInfo"
                        },
                        {
                            $match: condition
                        },
                    ];
                    var project = {
                        $project: {
                            "facName": "$facName",
                            "userFacId": "$userFacInfo._id",
                            "googleLink": "$googleLink"
                        }
                    };

                    aggregate.push(project);
                    Facility.aggregate(aggregate).then(function (facData) {
                        console.log("facility exist", facData);
                        if (facData.length > 0) {
                            finalResponse.facCheckInfo = facData[0];
                            callback(null, finalResponse);
                        } else {
                            res.writeHead(200, {
                                'Content-Type': 'text/xml'
                            });
                            res.end(twiml.toString());
                        }
                    }).catch(function (err) {
                        res.writeHead(200, {
                            'Content-Type': 'text/xml'
                        });
                        res.end(twiml.toString());
                    });
                },
                function (finalResponse, callback) { //Check visitor check in log
                    var newObj = {
                        phoneNumber: req.body.From,
                        userFacilityId: finalResponse.facCheckInfo.userFacId,
                        isDelete: false,
                        $and:[{ 
                            $or:[
                                { visitor_type: config.visitorType.FAMILY }, 
                                { visitor_type: config.visitorType.POA },
                                { visitor_type: config.visitorType.GUARDIAN }
                            ]
                        }]
                    };
                    Visitor.findOne(newObj).lean().exec(function (err, visitorData) {
                        console.log("visitor check", err, visitorData)
                        if (err) {
                            callback(err, false);
                        } else if (visitorData) {
                            if (visitorData.isSms == false) {
                                finalResponse.smsStatus = false;
                            }
                            finalResponse.visitorData = visitorData;
                            callback(null, finalResponse);
                        } else { // respond when visitor does not exist
                            res.writeHead(200, {
                                'Content-Type': 'text/xml'
                            });
                            res.end(twiml.toString());
                        }
                    })
                },
                function (finalResponse, callback) { //Check visitor check in log
                    var checkInObj = {
                        visitorId: mongoose.Types.ObjectId(finalResponse.visitorData._id)
                    }
                    CheckInOut.findOne(checkInObj).sort({
                        createdAt: -1
                    }).exec(function (err, checkInOutData) {
                        // console.log("check in out", err, checkInOutData);
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.checkInOutData = checkInOutData;
                            callback(null, finalResponse);
                        }
                    })
                },
                function (finalResponse, callback) { //Get facility rating & response setting
                    FacilityRatingResponseSettings.findOne({
                        facId: mongoose.Types.ObjectId(finalResponse.facCheckInfo._id),
                        isDelete: false,
                        status: true
                    }).exec(function (err, facilityRatingAndResponseSettings) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.facilityRatingAndResponseSettings = facilityRatingAndResponseSettings;
                            //  console.log("finalResponse.facilityRatingAndResponseSettings", finalResponse.facilityRatingAndResponseSettings);
                            callback(null, finalResponse);
                        }
                    })
                },
                function (finalResponse, callback) { // Get facility app settings
                    FacilityAppSettings.findOne({
                        facId: mongoose.Types.ObjectId(finalResponse.facCheckInfo._id),
                        isDelete: false,
                        status: true
                    }).exec(function (err, facilityAppSettings) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.facilityAppSettings = facilityAppSettings;
                            // console.log("finalResponse.facilityAppSettings", finalResponse.facilityAppSettings);
                            callback(null, finalResponse);
                        }
                    })
                },
                function (finalResponse, callback) { //update rating or comments
                    // console.log("finalResponse.checkInOutData", finalResponse.checkInOutData);
                    if (finalResponse.checkInOutData.checkOutDate == undefined) { // when visitor checks in but not checked out
                        // console.log(" not checkout");
                        finalResponse.checkInButNotCheckOut = true;
                        if (finalResponse.checkInOutData.receivedSmsAfterCheckIn == false) {
                            CheckInOut.findOneAndUpdate({
                                _id: mongoose.Types.ObjectId(finalResponse.checkInOutData._id)
                            }, {
                                $set: {
                                    receivedSmsAfterCheckIn: true,
                                }
                            }, function (err, checkedInButNotCheckOutData) {
                                if (err) {
                                    callback(err, false);
                                } else {
                                    finalResponse.receivedSmsAfterCheckIn = true;
                                    if(new RegExp((req.body.Body).trim(), 'gi') == 'STOP'){
                                        Visitor.findOneAndUpdate({ 
                                            _id: mongoose.Types.ObjectId(finalResponse.visitorData._id)
                                        }, {
                                            $set: {
                                                isSms: false,
                                            }
                                        }, function (err, updateVisData) {
                                            if (err) {
                                                callback(err, false);
                                            } else {
                                                finalResponse.emptyResponse = true;
                                                callback(null, finalResponse);
                                            }
                                        });
                                    }else{
                                        if (finalResponse.facilityAppSettings.checkInMessageReceivedReplySms.status == true) {
                                            var text; 
                                            if(finalResponse.facilityAppSettings.checkInMessageReceivedReplySms.visitorName == true){
                                                text = finalResponse.visitorData.firstName+ ', ' +finalResponse.facilityAppSettings.checkInMessageReceivedReplySms.message;                    
                                            }else{
                                                text = finalResponse.facilityAppSettings.checkInMessageReceivedReplySms.message;
                                            }
                                            twiml.message(text);
                                            finalResponse.text = text;
                                            finalResponse.twiml = twiml;
                                            callback(null, finalResponse);
                                        } else {
                                            finalResponse.emptyResponse = true;
                                            callback(null, finalResponse);
                                        }
                                    }
                                }
                            });
                        } else {
                            callback(null, finalResponse);
                        }

                    } else if (finalResponse.checkInOutData.ratingDone == false) {
                        if (req.body.Body == '1' || req.body.Body == '2' || req.body.Body == '3' || req.body.Body == '4' || req.body.Body == '5') { //Rating 
                            var text;
                            if (req.body.Body <= finalResponse.facilityRatingAndResponseSettings.negative.from && req.body.Body >= finalResponse.facilityRatingAndResponseSettings.negative.to) {
                               
                                CheckInOut.findOneAndUpdate({
                                    _id: mongoose.Types.ObjectId(finalResponse.checkInOutData._id)
                                }, {
                                    $set: {
                                        ratingDone: true,
                                        ratingStatus: 'negative',
                                        rating: parseInt(req.body.Body),
                                        ratingDate: moment()
                                    }
                                }, function (err, updateNegativeRating) {
                                    if (err) {
                                        callback(err, false);
                                    } else {
                                        
                                        if (finalResponse.facilityRatingAndResponseSettings.negative.sendAlerts == true) {
                                            var text = finalResponse.facilityRatingAndResponseSettings.negative.autoResponse;
                                            twiml.message(text);
                                            finalResponse.text = text;
                                            finalResponse.twiml = twiml;
                                        } else {
                                            finalResponse.emptyResponse = true;
                                            callback(null, finalResponse);
                                        }

                                        var suggObj = {
                                            userFacId: finalResponse.checkInOutData.userFacilityId,
                                            name: finalResponse.visitorData.firstName + ' ' + finalResponse.visitorData.lastName,
                                            ratingStatus: 'negative',
                                            text: finalResponse.visitorData.firstName + ' ' + finalResponse.visitorData.lastName + ' rated your facility a ' + parseInt(req.body.Body) + ' out of 5, ' + config.textMessageTwilio.NEGATIVE_SUGGESTION,
                                            rating: parseInt(req.body.Body),
                                        }

                                        var suggestionsReport = new Suggestions(suggObj);
                                        suggestionsReport.save(function (err, suggestionData) {
                                            if (err) {
                                                callback(err, false);
                                            } else {
                                                callback(null, finalResponse);
                                            }
                                        })
                                    }
                                });
                            } else if (req.body.Body <= finalResponse.facilityRatingAndResponseSettings.positive.from && req.body.Body >= finalResponse.facilityRatingAndResponseSettings.positive.to) {
                                
                                CheckInOut.findOneAndUpdate({
                                    _id: mongoose.Types.ObjectId(finalResponse.checkInOutData._id)
                                }, {
                                    $set: {
                                        ratingDone: true,
                                        ratingStatus: 'positive',
                                        rating: parseInt(req.body.Body),
                                        ratingDate: moment()
                                    }
                                }, function (err, updatePositiveRating) {
                                    if (err) {
                                        callback(err, false);
                                    } else {
                                        var suggObj = {
                                            userFacId: finalResponse.checkInOutData.userFacilityId,
                                            name: finalResponse.visitorData.firstName + ' ' + finalResponse.visitorData.lastName,
                                            ratingStatus: 'positive',
                                            text: finalResponse.visitorData.firstName + ' ' + finalResponse.visitorData.lastName + ' rated your facility a ' + parseInt(req.body.Body) + ' out of 5, ' + config.textMessageTwilio.POSITIVE_SUGGESTION,
                                            rating: parseInt(req.body.Body),
                                        }
                                        var suggestionsReport = new Suggestions(suggObj);
                                        suggestionsReport.save(function (err, suggestionData) {
                                            if (err) {
                                                callback(err, false);
                                            } else {
                                                
                                                if (finalResponse.facilityRatingAndResponseSettings.positive.sendAlerts == true && finalResponse.facilityRatingAndResponseSettings.positive.addReviewLink == false) {
                                                    text = finalResponse.facilityRatingAndResponseSettings.positive.autoResponse;
                                                } else if (finalResponse.facilityRatingAndResponseSettings.positive.sendAlerts == true && finalResponse.facilityRatingAndResponseSettings.positive.addReviewLink == true) {
                                                    var date = new Date();
                                                    finalResponse.trackingToken = utility.getEncryptText(Math.random().toString(4).slice(2) + date.getTime());
                                                    finalResponse.trackingLink = config.email.base_url + '/visitGoogleRating/' + finalResponse.trackingToken;
                                                    text = finalResponse.facilityRatingAndResponseSettings.positive.autoResponse + ' ' + finalResponse.trackingLink;
                                                    
                                                    //Create tracking link and token to link tracking
                                                    CheckInOut.findOneAndUpdate({ 
                                                        _id: finalResponse.checkInOutData._id
                                                    }, {
                                                        $set: {
                                                            trackingToken: finalResponse.trackingToken,
                                                            trackingLink: finalResponse.trackingLink
                                                        }
                                                    }, function (err, updateCheckInOutData) {
                                                        if (err) {} else {}
                                                    });
                                                    //End

                                                } else { 
                                                    finalResponse.emptyResponse = true;
                                                    callback(null, finalResponse);
                                                }

                                                if (finalResponse.facilityAppSettings.googleRatingSmsInterval.status == true) {
                                                    var dateObj = moment();
                                                    if (finalResponse.facilityAppSettings.googleRatingSmsInterval.period == 'weeks') {
                                                        var actualDate = moment(dateObj).add(parseInt((finalResponse.facilityAppSettings.googleRatingSmsInterval.time) * 7), 'd').toDate();
                                                    } else if (finalResponse.facilityAppSettings.googleRatingSmsInterval.period == 'days') {
                                                        var actualDate = moment(dateObj).add(parseInt(finalResponse.facilityAppSettings.googleRatingSmsInterval.time), 'd').toDate();
                                                    } else if (finalResponse.facilityAppSettings.googleRatingSmsInterval.period == 'hours') {
                                                        var actualDate = moment(dateObj).add(parseInt(finalResponse.facilityAppSettings.googleRatingSmsInterval.time), 'h').toDate();
                                                    } else {
                                                        var actualDate = moment(dateObj).add(parseInt(finalResponse.facilityAppSettings.googleRatingSmsInterval.time), 'm').toDate();
                                                    }
                                                    var sendSmsObj = {
                                                        userFacId: finalResponse.checkInOutData.userFacilityId,
                                                        visitorId: finalResponse.visitorData._id,
                                                        checkInOutId: finalResponse.checkInOutData._id,
                                                        message: text,
                                                        smsType: 'googleLink',
                                                        to: req.body.From,
                                                        from: req.body.To,
                                                        sendingTime: actualDate,
                                                        addReviewLink: finalResponse.facilityRatingAndResponseSettings.positive.addReviewLink
                                                    }
                                                    
                                                    if(finalResponse.facilityRatingAndResponseSettings.positive.addReviewLink == true){
                                                        sendSmsObj.trackingLink = finalResponse.trackingLink;
                                                        sendSmsObj.routingLink = finalResponse.facCheckInfo.googleLink;
                                                    }
                                                    
                                                    var sendSmsInterval = new SendSmsInterval(sendSmsObj);
                                                    sendSmsInterval.save(function (err, SmsSavedData) {
                                                        if (err) {
                                                            callback(err, false);
                                                        } else {
                                                            console.log("sendsmsinterval");
                                                            finalResponse.emptyResponse = true;
                                                            callback(null, finalResponse);
                                                        }
                                                    });
                                                } else {
                                                    console.log("suggestions");
                                                    twiml.message(text);
                                                    finalResponse.text = text;
                                                    finalResponse.twiml = twiml;
                                                    
                                                    //Create tracking link and token to link tracking
                                                    CheckInOut.findOneAndUpdate({ 
                                                        _id: finalResponse.checkInOutData._id
                                                    }, {
                                                        $set: {
                                                            sentOnlineLinkInSms: finalResponse.facilityRatingAndResponseSettings.positive.addReviewLink,
                                                            sentOnlineLinkInSmsDate: moment()
                                                        }
                                                    }, function (err, updateCheckInOutData) {
                                                        if (err) {
                                                            callback(err, false);
                                                        } else {
                                                            callback(null, finalResponse);
                                                        }
                                                    });
                                                    //End
                                                }

                                            }
                                        })
                                    }
                                });
                            }
                        } else { //Responding while rating not done by visitor on last visit            
                            var text = config.textMessageTwilio.INVALID_RATING_RESPONSE;
                            twiml.message(text);
                            finalResponse.text = text;
                            finalResponse.twiml = twiml;
                            callback(null, finalResponse);
                        }
                    } else if (finalResponse.checkInOutData.rating <= finalResponse.facilityRatingAndResponseSettings.negative.from && finalResponse.checkInOutData.CommentDone == false) { // While negative rating but comment not done. Update comment status 
                        
                        CheckInOut.findOneAndUpdate({
                            _id: mongoose.Types.ObjectId(finalResponse.checkInOutData._id)
                        }, {
                            $set: {
                                CommentDone: true,
                                comments: req.body.Body,
                                CommentDate: moment()
                            }
                        }, function (err, updateComments) {
                            if (err) {
                                callback(err, false);
                            } else {
                                var incidentInfo = {};
                                incidentInfo.userFacId = finalResponse.facCheckInfo.userFacId,
                                incidentInfo.visitorId = mongoose.Types.ObjectId(finalResponse.visitorData._id),
                                incidentInfo.firstName = finalResponse.visitorData.firstName,
                                incidentInfo.lastName = finalResponse.visitorData.lastName,
                                incidentInfo.incidentTime = finalResponse.checkInOutData.checkInDate,
                                incidentInfo.concern = req.body.Body,
                                incidentInfo.incidentType = 'complaint'
                                incidentInfo.visitedTo = finalResponse.checkInOutData.visitedTo
                                var incidentReport = new IncidentReports(incidentInfo);
                                incidentReport.save(function (err, incidentReportData) {
                                    if (err) {
                                        callback(err, false);
                                    } else {
                                        var alertObj = {
                                            facId: finalResponse.facCheckInfo._id,
                                            visitorName: finalResponse.visitorData.firstName + ' ' + finalResponse.visitorData.lastName,
                                            visitedTo: finalResponse.checkInOutData.visitedTo,
                                            from: req.body.From,
                                            rating: finalResponse.checkInOutData.rating,
                                            concern: req.body.Body,
                                            createdAt: moment(finalResponse.checkInOutData.checkInDate).format('MM-DD-YYYY'),
                                            twilioTollFreeNumber: req.body.To,
                                            userFacId: finalResponse.checkInOutData.userFacilityId
                                        }
                                        sendLowRatingNotifications(alertObj);

                                        if (finalResponse.facilityRatingAndResponseSettings.negativeRatingFollowUpSms.status == true) {
                                            var text;
                                            if(finalResponse.facilityRatingAndResponseSettings.negativeRatingFollowUpSms.visitorName == true){
                                                text = finalResponse.visitorData.firstName+ ', ' +finalResponse.facilityRatingAndResponseSettings.negativeRatingFollowUpSms.message;                    
                                            }else{
                                                text = finalResponse.facilityRatingAndResponseSettings.negativeRatingFollowUpSms.message;
                                            }
                                            twiml.message(text);
                                            finalResponse.text = text;
                                            finalResponse.twiml = twiml;
                                            callback(null, finalResponse);
                                        } else {
                                            finalResponse.emptyResponse = true;
                                            callback(null, finalResponse);
                                        }

                                    }
                                })
                            }
                        });
                    } else {
                        // console.log("in else part");
                        finalResponse.emptyResponse = true;
                        callback(null, finalResponse);
                    }
                },
                function (finalResponse, callback) { //Save inbound twilio sms hisitory 
                    var receivedSmsObj = {
                        userFacilityId: finalResponse.facCheckInfo.userFacId,
                        visitorId: finalResponse.visitorData._id,
                        to: req.body.To,
                        from: req.body.From,
                        text: req.body.Body
                    }
                    if(finalResponse.checkInButNotCheckOut == true){
                        receivedSmsObj.isReplied = false;
                    }
                    var receivedSmsHistory = new SMSHistory(receivedSmsObj)
                    receivedSmsHistory.save(function (err, savedReceivedSms) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    })
                },
                function (finalResponse, callback) { // Get facility sms settings
                    FacilitySmsSettings.findOne({
                        facId: mongoose.Types.ObjectId(finalResponse.facCheckInfo._id),
                        isDelete: false,
                        status: true
                    }).exec(function (err, facilitySmsSettings) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.facilitySmsSettings = facilitySmsSettings;
                            callback(null, finalResponse);
                        }
                    })
                },
            ],
            function (err, data) {
                console.log("asasasDAtasatas@@@@@@", data.receivedSmsAfterCheckIn);
                if (err) { //responding empty xml format to twilio because it need while 2-way sms 
                    res.writeHead(200, {
                        'Content-Type': 'text/xml'
                    });
                    res.end(twiml.toString());
                } else { // responding on inbound sms
                    if (data.emptyResponse) {
                        // console.log("in empty response");
                        var twilioObj = {
                            to: req.body.To,
                            from: req.body.From,
                            visitorId: data.visitorData._id,
                            message: req.body.Body,
                            visitorName: data.visitorData.firstName + ' ' + data.visitorData.lastName,
                            visitedTo: data.visitorData.visitedTo
                        }
                        io.emit('twilioSms', twilioObj);
                        if(data.receivedSmsAfterCheckIn == true){
                            io.emit('twilioSmsPopUp', twilioObj);
                        }
                        res.writeHead(200, {
                            'Content-Type': 'text/xml'
                        });
                        res.end(twiml.toString());
                    } else {
                        if ((data.checkInButNotCheckOut == true && data.receivedSmsAfterCheckIn == false) || data.smsStatus == false) { //Not sending automated response while sms received again before checkout
                            // console.log("no response automated");
                            var twilioObj = {
                                to: req.body.To,
                                from: req.body.From,
                                visitorId: data.visitorData._id,
                                message: req.body.Body,
                                visitorName: data.visitorData.firstName + ' ' + data.visitorData.lastName,
                                visitedTo: data.visitorData.visitedTo
                            }
                            io.emit('twilioSms', twilioObj);
                            if(data.checkInButNotCheckOut == true && data.receivedSmsAfterCheckIn == false){
                                io.emit('twilioSmsPopUp', twilioObj);
                            }
                            res.writeHead(200, {
                                'Content-Type': 'text/xml'
                            });
                            res.end(twiml.toString());
                        } else {
                            // console.log("response automated");
                            if (data.facilitySmsSettings.disableAutoReply == false) {

                                if (data.facilityAppSettings.smsLimits.status == true) {
                                    var secFinalRes = {};
                                    secFinalRes.havingSmsLimit = false;
                                    waterfall([
                                        function (callback) { //Check for already exist phone number
                                            var checkSmsLimitObj = {
                                                visitorId: data.visitorData._id,
                                                userFacId: data.checkInOutData.userFacilityId,
                                                smsLimits: data.facilityAppSettings.smsLimits,
                                                to: req.body.From
                                            }
                                            utility.checkSmsLimitExist(checkSmsLimitObj, function (smsLimitExist) {
                                                if (smsLimitExist == true) {
                                                    secFinalRes.havingSmsLimit = true;
                                                    callback(null, finalResponse);
                                                } else {
                                                    secFinalRes.havingSmsLimit = false;
                                                    callback(null, finalResponse);
                                                }
                                            });
                                        }
                                    ],
                                    function (err, data1) {
                                        if (!err) {
                                            if(data1.havingSmsLimit == true){
                                                var smsObj = {
                                                    userFacilityId: data.facCheckInfo.userFacId,
                                                    visitorId: finalResponse.visitorData._id,
                                                    to: req.body.From,
                                                    from: req.body.To,
                                                    text: data.text
                                                }
                                                var smsHistory = new SMSHistory(smsObj)
                                                smsHistory.save(function (err, savedSmsHistory) { // save sending sms hisitory 
                                                    if (!err) {
                                                        var twilioObj = {
                                                            to: req.body.To,
                                                            from: req.body.From,
                                                            visitorId: data.visitorData._id,
                                                            message: req.body.Body,
                                                            visitorName: data.visitorData.firstName + ' ' + data.visitorData.lastName,
                                                            visitedTo: data.visitorData.visitedTo
                                                        }
            
                                                        io.emit('twilioSms', twilioObj);
            
                                                        if (data.receivedSmsAfterCheckIn == true && data.checkInOutData.status == '1') {
                                                            io.emit('twilioSmsPopUp', twilioObj);
                                                        }
                                                        res.writeHead(200, {
                                                            'Content-Type': 'text/xml'
                                                        });
                                                        res.end(data.twiml.toString());
                                                    }
                                                })
                                            }else{
                                                // console.log("comes in teeee");
                                                var twilioObj = {
                                                    to: req.body.To,
                                                    from: req.body.From,
                                                    visitorId: data.visitorData._id,
                                                    message: req.body.Body,
                                                    visitorName: data.visitorData.firstName + ' ' + data.visitorData.lastName,
                                                    visitedTo: data.visitorData.visitedTo
                                                }

                                                io.emit('twilioSms', twilioObj);

                                                if (data.receivedSmsAfterCheckIn == true && data.checkInOutData.status == '1') {
                                                    io.emit('twilioSmsPopUp', twilioObj);
                                                }
                                                const twiml1 = new MessagingResponse();
                                                res.writeHead(200, {
                                                    'Content-Type': 'text/xml'
                                                });
                                                res.end(twiml1.toString());
                                            }
                                        }
                                    });
                                } else {
                                    // console.log("false disable");
                                    var smsObj = {
                                        userFacilityId: data.facCheckInfo.userFacId,
                                        visitorId: finalResponse.visitorData._id,
                                        to: req.body.From,
                                        from: req.body.To,
                                        text: data.text
                                    }
                                    var smsHistory = new SMSHistory(smsObj)
                                    smsHistory.save(function (err, savedSmsHistory) { // save sending sms hisitory 
                                        if (!err) {
                                            var twilioObj = {
                                                to: req.body.To,
                                                from: req.body.From,
                                                visitorId: data.visitorData._id,
                                                message: req.body.Body,
                                                visitorName: data.visitorData.firstName + ' ' + data.visitorData.lastName,
                                                visitedTo: data.visitorData.visitedTo
                                            }

                                            io.emit('twilioSms', twilioObj);

                                            if (data.receivedSmsAfterCheckIn == true && data.checkInOutData.status == '1' ) {
                                                io.emit('twilioSmsPopUp', twilioObj);
                                            }
                                            res.writeHead(200, {
                                                'Content-Type': 'text/xml'
                                            });
                                            res.end(data.twiml.toString());
                                        }
                                    })
                                }
                            } else {
                                console.log("comes in teeee");
                                var twilioObj = {
                                    to: req.body.To,
                                    from: req.body.From,
                                    visitorId: data.visitorData._id,
                                    message: req.body.Body,
                                    visitorName: data.visitorData.firstName + ' ' + data.visitorData.lastName,
                                    visitedTo: data.visitorData.visitedTo
                                }

                                io.emit('twilioSms', twilioObj);

                                if (data.receivedSmsAfterCheckIn == true && data.checkInOutData.status == '1') {
                                    io.emit('twilioSmsPopUp', twilioObj);
                                }
                                const twiml1 = new MessagingResponse();
                                res.writeHead(200, {
                                    'Content-Type': 'text/xml'
                                });
                                res.end(twiml1.toString());
                            }
                        }
                    }
                }
            });
    }

}

/**
 * Function is use to send low rating alerts
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 4-07-2018
 */
function sendLowRatingNotifications(alertObj) {
    var createdAt = alertObj.createdAt;
    var visitorName = alertObj.visitorName;
    var cellPhone = alertObj.from;
    var visitedTo = alertObj.visitedTo;
    var rating = alertObj.rating;
    var twilioTollFreeNumber = alertObj.twilioTollFreeNumber;
    var concern = alertObj.concern;

    FacilityNotificationSettings.findOne({
        facId: mongoose.Types.ObjectId(alertObj.facId),
        isDelete: false,
        status: true
    }).exec(function (err, facilityNotificationSettings) {
        if (err) {} else if (facilityNotificationSettings != null) {
            console.log("facilityAppSettings", facilityNotificationSettings);
            if (facilityNotificationSettings.negative_rating_notification.status == true) {
                console.log("in incident to send emails");
                var headerTable = "<tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>" +
                    "<tr><td style='padding: 0 20px;'>" +
                    "<table width='100%' border='0' cellspacing='0' cellpadding='0'>" +
                    "<tbody><tr><td style='color: #C33333; padding-bottom: 10px;'><strong>Low Rating Details:</strong></td></tr></tbody></table>" +
                    "<table width='100%' border='1' bordercolor='#d9d9d9' cellspacing='0' cellpadding='10' style='border-collapse: collapse;'>" +
                    "<tbody>" +
                    "<tr>" +
                    "<td><span style='font-size: 12px; color: #777777;'>Name</span></td>" +
                    "<td><span style='font-size: 12px; color: #777777;'>Phone No</span></td>" +
                    "<td><span style='font-size: 12px; color: #777777;'>Visit At</span></td>" +
                    "<td><span style='font-size: 12px; color: #777777;'>Visited To</span></td>" +
                    "<td><span style='font-size: 12px; color: #777777;'>Rating</span></td>" +
                    "<td><span style='font-size: 12px; color: #777777;'>Concern</span></td>" +
                    "</tr>" +
                    "<tr>";
                var footerTable = "</tbody></table></td></tr>";
                var bodyContent = "<td><span><strong>" + visitorName + "</strong></span></td>" +
                    "<td><span><strong>" + cellPhone + "</strong></span></td>" +
                    "<td><span><strong>" + createdAt + "</strong></span></td>" +
                    "<td><span><strong>" + visitedTo + "</strong></span></td>" +
                    "<td><span><strong>" + rating + "</strong></span></td>" +
                    "<td><span><strong>" + concern + "</strong></span></td>" +
                    "</tr>";
                var finalBodyContent = headerTable + bodyContent + footerTable;
                async.eachSeries(facilityNotificationSettings.negative_rating_notification.emailsArray, function (notificationData, nextAgain) {
                    var baseUrl = config.email.base_url;
                    var options = {
                        template: 'notifyLowRating.html',
                        from: config.email.from,
                        repalcement: {
                            "{{content_notify}}": finalBodyContent,
                            "{{logo_url}}": baseUrl + config.email.logo_url,
                            "{{copyright}}": config.email.copyright,
                            "{{link.abuse_email}}": config.email.abuse_email
                        },
                        to: notificationData,
                        subject: 'Low Rating'
                    };
                    emailSend.smtp.sendMail(options, function (err, response) {
                        if (err) {
                            nextAgain();
                        } else {
                            nextAgain();
                        }
                    })
                }, function (err) {
                    if (err) {} else {
                        var text = "This is to notify you that a low rating is received. Please check the details of low rating. Visitor Name: " + visitorName + ", Cellphone No: " + cellPhone + ", Rating: " + rating + ", Concern: " + concern + ", Visited At: " + createdAt + ", Visted To: " + visitorName;
                        var smsData = {
                            to: facilityNotificationSettings.negative_rating_notification.phoneNumber,
                            from: twilioTollFreeNumber,
                            message: text
                        }
                        twilio.sendSMS(smsData, function (returnData) {
                            if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                            } else {
                                if (returnData.status == config.statusCode.success) {
                                    var messageBody = returnData.message.toJSON();
                                    var smsInfo = {};
                                    smsInfo.userFacId = alertObj.userFacId;
                                    smsInfo.to = messageBody.to;
                                    smsInfo.from = messageBody.from;
                                    smsInfo.text = messageBody.body;
                                    smsInfo.type = 'low_rating';
                                    var notificationSmsHistory = new NotificationSmsHistory(smsInfo);
                                    notificationSmsHistory.save(function (err, SmsSavedData) {
                                        if (err) {} else {}
                                    });
                                }
                            }
                        });
                    }
                })
            }
        }
    })
}

/** 
 * Function is used to validate the valid user while kiosk mode logout
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 18-May-2018
 */
function logoutKioskMode(req, res) {
    if (validator.isNull(req.body.password) || !req.body.password) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("PASSWORD_REQUIRED")
        });
    } else {
        var passEnc = utility.getEncryptText(req.body.password);
        var condition = {
            password: passEnc,
            email: req.user.email
        }
        User.findOne(condition, {
                password: 0,
                updatedAt: 0,
                createdAt: 0,
                verifyToken: 0
            })
            .lean()
            .exec(function (err, userData) { // check user credentials 
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                } else {
                    if (!userData) {
                        res.json({
                            code: config.statusCode.notFound,
                            data: {},
                            message: i18n.__("UNAUTHORIZED")
                        });
                    } else {
                        res.json({
                            code: config.statusCode.success,
                            data: userData,
                            message: i18n.__("USER_AUTHENTICATED")
                        });
                    }
                }
            });
    }
}

/** 
 * Function is used to get visitor trends of rating or feedback
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 1-June-2018
 */
function getVisitorTrends(req, res) {
    if (validator.isNull(req.body.todayDate) || !req.body.todayDate) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("TODAY_DATE_REQUIRED")
        });
    } else {
        var finalResponse = {};
        finalResponse.dateArray = [];
        finalResponse.avgRatingArray = [];
        finalResponse.dateFormatArray = [];
        var start_day_date = moment(req.body.todayDate).startOf('day').add(-60, 'days');
        var end_day_date = moment(req.body.todayDate).endOf('day');
        waterfall([
                function (callback) { //Set date array for last 61 days
                    while (start_day_date <= end_day_date) {
                        finalResponse.dateArray.push(moment(start_day_date))
                        start_day_date = moment(start_day_date).add(1, 'days');
                    }
                    callback(null, finalResponse);
                },
                function (finalResponse, callback) { //get average rating for a particular date and push in array with date

                    async.eachSeries(finalResponse.dateArray, function (singleDate, next) {

                        var day_start_of_date = singleDate;
                        var day_end_of_date = moment(singleDate).endOf('day');
                        var momentObjFrom = new Date(moment(day_start_of_date));
                        var momentObjTo = new Date(moment(day_end_of_date));
                        var condition = {
                            isDelete: false,
                            ratingDone: true,
                            userFacilityId: mongoose.Types.ObjectId(req.user.userFacId),
                            $and: [{
                                    ratingDate: {
                                        $gte: momentObjFrom
                                    }
                                },
                                {
                                    ratingDate: {
                                        $lte: momentObjTo
                                    }
                                }
                            ]
                        };

                        CheckInOut.aggregate([{
                            $match: condition
                        }, {
                            "$group": {
                                "_id": "$userFacilityId",
                                "avgRating": {
                                    "$avg": {
                                        "$ifNull": ["$rating", 0]
                                    }
                                }
                            }
                        }], function (err, rating) {
                            if (rating.length > 0) {
                                finalResponse.dateFormatArray.push(singleDate.format('MM-DD-YY'));
                                finalResponse.avgRatingArray.push(rating[0].avgRating.toFixed(1));
                                next();
                            } else {
                                finalResponse.dateFormatArray.push(singleDate.format('MM-DD-YY'));
                                finalResponse.avgRatingArray.push(null);
                                next();
                            }
                        })
                    }, function (err) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    })
                },
            ],
            function (err, data) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: data,
                        message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                    });
                }
            });
    }
}

/** 
 * Function is used to get current week visitor rating feedback
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 7-June-2018
 */
function getVisitorRatingGraph(req, res) {
    if (validator.isNull(req.body.todayDate) || !req.body.todayDate) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("TODAY_DATE_REQUIRED")
        });
    } else {
        var curr = new Date; // get current date
        var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
        var last = first + 6; // last day is the first day + 6
        var firstday = new Date(curr.setDate(first));
        var lastday = new Date(curr.setDate(last));

        var finalResponse = {};
        finalResponse.dateArray = [];
        finalResponse.avgVisitorRatingArray = [];
        finalResponse.dateFormatArray = [];
        var start_day_date = moment(firstday).startOf('day');
        var end_day_date = moment(lastday).endOf('day');
        waterfall([
                function (callback) { //Set date array for last 61 days
                    while (start_day_date <= end_day_date) {
                        finalResponse.dateArray.push(moment(start_day_date))
                        start_day_date = moment(start_day_date).add(1, 'days');
                    }
                    callback(null, finalResponse);
                },
                function (finalResponse, callback) { //get average rating for a particular date and push in array with date

                    async.eachSeries(finalResponse.dateArray, function (singleDate, next) {

                        var day_start_of_date = singleDate;
                        var day_end_of_date = moment(singleDate).endOf('day');
                        var momentObjFrom = new Date(moment(day_start_of_date));
                        var momentObjTo = new Date(moment(day_end_of_date));
                        var condition = {
                            isDelete: false,
                            ratingDone: true,
                            userFacilityId: mongoose.Types.ObjectId(req.user.userFacId),
                            $and: [{
                                    ratingDate: {
                                        $gte: momentObjFrom
                                    }
                                },
                                {
                                    ratingDate: {
                                        $lte: momentObjTo
                                    }
                                }
                            ]
                        };

                        CheckInOut.aggregate([{
                            $match: condition
                        }, {
                            "$group": {
                                "_id": "$userFacilityId",
                                "avgRating": {
                                    "$avg": {
                                        "$ifNull": ["$rating", 0]
                                    }
                                }
                            }
                        }], function (err, rating) {
                            if (rating.length > 0) {
                                finalResponse.avgVisitorRatingArray.push(rating[0].avgRating.toFixed(1));
                                next();
                            } else {
                                finalResponse.avgVisitorRatingArray.push(null);
                                next();
                            }
                        })
                    }, function (err) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    })
                },
            ],
            function (err, data) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: data.avgVisitorRatingArray,
                        message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                    });
                }
            });
    }
}

/** 
 * Function is used to get activity feed of facility
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 28-June-2018
 */
function getActivities(req, res) {
    var count = 20;
    var skip = 20 * (req.body.page - 1);

    SMSHistory.find({
            userFacilityId: mongoose.Types.ObjectId(req.user.userFacId),
            isDelete: false
        })
        .populate('visitorId').sort({
            createdAt: -1
        })
        .skip(skip)
        .limit(count).exec(function (err, smsHistory) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                SMSHistory.find({
                        userFacilityId: mongoose.Types.ObjectId(req.user.userFacId),
                        isDelete: false
                    })
                    .count().exec(function (err, totalLength) {
                        if (err) {
                            res.json({
                                code: config.statusCode.error,
                                data: {},
                                message: i18n.__("INTERNAL_ERROR")
                            });
                        } else {
                            var data = {
                                smsHistory: smsHistory,
                                totalLength: totalLength
                            }
                            res.json({
                                code: config.statusCode.success,
                                data: data,
                                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                            });
                        }
                    })

            }
        })

}


/**
 * Function is use to update Suggestion info by id
 * @access private
 * @return json
 * Created by VishakaR
 * @smartData Enterprises (I) Ltd
 * Created Date 10-July-2018
 */
function updateSuggestion(req, res) {
    var finalResponse = {};
    finalResponse.suggestionData = {};
    var sugObj = {
        _id: req.body._id,
        iDidThis: req.body.iDidThis,
        RemoveThis: req.body.RemoveThis
    }
    waterfall([
        function (callback) { // visitor check out
            Suggestions.findOneAndUpdate({
                _id: sugObj._id
            }, {
                $set: {
                    iDidThis: sugObj.iDidThis,
                    RemoveThis: sugObj.RemoveThis,
                }
            }, function (err, suggestionData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.suggestionData = suggestionData;
                    callback(null, finalResponse);
                }
            });
        },

    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("UPDATED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get Saved Notes by facility
 * @access private
 * @return json
 * Created by VishakaR
 * @smartData Enterprises (I) Ltd
 * Created Date 10-July-2018
 */
function getSuggestion(req, res) {
    var finalResponse = {};
    finalResponse.suggestionCount = 0;
    finalResponse.suggestionDetails = {};
    waterfall([
        function (callback) { //get Message Count
            var condition = {
                iDidThis: false,
                RemoveThis: false,
                userFacId: mongoose.Types.ObjectId(req.user.userFacId)
            };
            Suggestions.find(condition).count().exec(function (err, suggestionCount) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.suggestionCount = suggestionCount;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //get Message Details
            var condition = {};
            condition.iDidThis = false,
                condition.RemoveThis = false,
                condition.userFacId = mongoose.Types.ObjectId(req.user.userFacId);
            Suggestions.find(condition).sort({
                createdAt: -1
            }).exec(function (err, suggestionDetails) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.suggestionDetails = suggestionDetails;
                    callback(null, finalResponse);

                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to send sms to visitor using interval
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 11-July-2018
 */
function sendSmsUsingInterval(req, res) {
    var finalResponse = {};
    finalResponse.smsArray = [];
    finalResponse.twilioInfo = {};
    waterfall([
        function (callback) { //get sms array to send
            var condition = {
                status: false,
                isDelete: false,
                sendingTime: {
                    $lte: moment(new Date())
                }
            };
            SendSmsInterval.find(condition).sort({
                createdAt: 1
            }).exec(function (err, smsArray) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.smsArray = smsArray;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Looping for each sms obj and send sms to visitor 
            async.eachSeries(finalResponse.smsArray, function (smsObj, next) {
                switch (smsObj.smsType) {
                    case 'checkIn':
                        var smsData = {
                            to: smsObj.to,
                            from: smsObj.from,
                            message: smsObj.message
                        }
                        twilio.sendSMS(smsData, function (returnData) {
                            if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                                finalResponse.twilioInfo = returnData;
                                callback(null, finalResponse);
                            } else {
                                var messageBody = returnData.message.toJSON();
                                var smsInfo = {};
                                smsInfo.userFacilityId = smsObj.userFacId;
                                smsInfo.visitorId = smsObj.visitorId;
                                smsInfo.to = smsObj.to;
                                smsInfo.from = smsObj.from;
                                smsInfo.text = smsObj.message;
                                var smsHistory = new SMSHistory(smsInfo);
                                smsHistory.save(function (err, SmsSavedData) {
                                    if (err) {
                                        next();
                                    } else {
                                        SendSmsInterval.findOneAndUpdate({
                                            _id: smsObj._id
                                        }, {
                                            $set: {
                                                status: true
                                            }
                                        }, function (err, sendSmsIntervalUpdate) {
                                            if (err) {
                                                next();
                                            } else {
                                                next();
                                            }
                                        });
                                    }
                                });
                            }
                        });
                        break;
                    case 'checkOut':
                        var smsData = {
                            to: smsObj.to,
                            from: smsObj.from,
                            message: smsObj.message
                        }
                        twilio.sendSMS(smsData, function (returnData) {
                            if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                                finalResponse.twilioInfo = returnData;
                                callback(null, finalResponse);
                            } else {
                                var messageBody = returnData.message.toJSON();
                                var smsInfo = {};
                                smsInfo.userFacilityId = smsObj.userFacId;
                                smsInfo.visitorId = smsObj.visitorId;
                                smsInfo.to = smsObj.to;
                                smsInfo.from = smsObj.from;
                                smsInfo.text = smsObj.message;
                                var smsHistory = new SMSHistory(smsInfo);
                                smsHistory.save(function (err, SmsSavedData) {
                                    if (err) {
                                        next();
                                    } else {
                                        SendSmsInterval.findOneAndUpdate({
                                            _id: smsObj._id
                                        }, {
                                            $set: {
                                                status: true
                                            }
                                        }, function (err, sendSmsIntervalUpdate) {
                                            if (err) {
                                                next();
                                            } else {
                                                CheckInOut.findOneAndUpdate({
                                                    _id: smsObj.checkInOutId
                                                }, {
                                                    $set: {
                                                        checkOutSmsSent: true,
                                                        checkOutSmsSentDate: moment(sendingTime)
                                                    }
                                                }, function (err, againUpdateCheckInOut) {
                                                    if (err) {
                                                        next();
                                                    } else {
                                                        next();
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                        break;
                    case 'googleLink':
                        var smsData = {
                            to: smsObj.to,
                            from: smsObj.from,
                            message: smsObj.message
                        }
                        twilio.sendSMS(smsData, function (returnData) {
                            if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                                finalResponse.twilioInfo = returnData;
                                callback(null, finalResponse);
                            } else {
                                var messageBody = returnData.message.toJSON();
                                var smsInfo = {};
                                smsInfo.userFacilityId = smsObj.userFacId;
                                smsInfo.visitorId = smsObj.visitorId;
                                smsInfo.to = smsObj.to;
                                smsInfo.from = smsObj.from;
                                smsInfo.text = smsObj.message;
                                var smsHistory = new SMSHistory(smsInfo);
                                smsHistory.save(function (err, SmsSavedData) {
                                    if (err) {
                                        next();
                                    } else {
                                        SendSmsInterval.findOneAndUpdate({
                                            _id: smsObj._id
                                        }, {
                                            $set: {
                                                status: true
                                            }
                                        }, function (err, sendSmsIntervalUpdate) {
                                            if (err) {
                                                next();
                                            } else {
                                                //Create tracking link and token to link tracking
                                                if(smsObj.addReviewLink == true){
                                                    CheckInOut.findOneAndUpdate({ 
                                                        _id: smsObj.checkInOutId
                                                    }, {
                                                        $set: {
                                                            sentOnlineLinkInSms: smsObj.addReviewLink,
                                                            sentOnlineLinkInSmsDate: moment()
                                                        }
                                                    }, function (err, updateCheckInOutData) {
                                                        if (err) {
                                                            next();
                                                        } else {
                                                            next();
                                                        }
                                                    });
                                                }else{
                                                    next();
                                                }
                                                //End
                                            }
                                        });
                                    }
                                });
                            }
                        });
                        break;
                }
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })
        },
    ], function (err, data) {
        if (err) {} else {}
    });
}

/**
 * Function is checked in residents
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 16-July-2018
 * Updated By Sunny
 * Updated Date 31-July-2018
 */
function addResidentAndCheckedIn(req, res) {
    var finalResponse = {};
    finalResponse.checkInData = {};
    finalResponse.visitorData = {};

    var visitorObj = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        visitor_type: 'expressResident',
        room_no: req.body.room_no,
        bed_no: req.body.bed_no,
        checkInDate: req.body.checkInDate,
        userFacilityId: req.body.userFacilityId
    }

    if (!visitorObj.firstName || !visitorObj.lastName || !visitorObj.visitor_type || !visitorObj.userFacilityId || !visitorObj.room_no) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else {
        waterfall([
            function (callback) { //get visitor info
                var condition = {
                    firstName: new RegExp((visitorObj.firstName).trim(), 'gi'),
                    lastName: new RegExp(visitorObj.lastName.trim(), 'gi'),
                    userFacilityId: visitorObj.userFacilityId,
                    visitor_type: visitorObj.visitor_type,
                    room_no: visitorObj.room_no.trim(),
                    bed_no: visitorObj.bed_no,
                    isDelete: false
                };
                Visitor.findOne(condition).lean().exec(function (err, visitorData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (!visitorData) {
                            res.json({
                                code: config.statusCode.invalid,
                                data: {},
                                message: i18n.__("UNAUTHORIZED")
                            });
                        } else {
                            finalResponse.visitorData = visitorData;
                            callback(null, finalResponse);
                        }
                    }
                })
            },
            function (finalResponse, callback) { //Check Visitor if already Checked In
                CheckInOut.findOne({
                    visitorId: finalResponse.visitorData._id,
                    status: '0'
                }).exec(function (err, visitorCheckedData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (!visitorCheckedData) {
                            res.json({
                                code: config.statusCode.invalid,
                                data: {},
                                message: i18n.__("VISITOR_ALREADY_CHECKED_IN")
                            });
                        } else {
                            callback(null, finalResponse);
                        }
                    }
                })
            },
            function (finalResponse, callback) { // visitor check in update
                CheckInOut.findOneAndUpdate({
                    visitorId: finalResponse.visitorData._id,
                    status: '0'
                }, {
                    $set: {
                        status: "1",
                        checkInDate: visitorObj.checkInDate,
                    }
                }, function (err, checkOutSavedData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            }
        ],
        function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: data,
                    message: i18n.__("CHECK_IN_SUCCESSFULLY")
                });
            }
        });
    }
}

/**
 * Function is add resident Info and checked out
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 16-July-2018
 */
function addResidentAndCheckedOut(req, res) {
    var finalResponse = {};
    finalResponse.checkOutData = {};
    finalResponse.visitorData = {};

    var visitorObj = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        visitor_type: 'expressResident',
        room_no: req.body.room_no,
        bed_no: req.body.bed_no,
        checkOutDate: req.body.checkOutDate,
        userFacilityId: req.body.userFacilityId
    }

    if (!visitorObj.firstName || !visitorObj.lastName || !visitorObj.visitor_type || !visitorObj.userFacilityId || !visitorObj.room_no) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else {
        waterfall([
            function (callback) { //get visitor info
                var condition = {
                    firstName: new RegExp((visitorObj.firstName).trim(), 'gi'),
                    lastName: new RegExp((visitorObj.lastName).trim(), 'gi'),
                    userFacilityId: visitorObj.userFacilityId,
                    visitor_type: visitorObj.visitor_type,
                    room_no: (visitorObj.room_no).trim(),
                    bed_no: visitorObj.bed_no,
                    isDelete: false
                };

                Visitor.findOne(condition).lean().exec(function (err, visitorFoundData) {
                    if (err) {
                        callback(err, false);
                    } else if(visitorFoundData == null){
                        var obj1 = {
                            firstName: visitorObj.firstName.trim(),
                            lastName: visitorObj.lastName.trim(),
                            userFacilityId: visitorObj.userFacilityId,
                            visitor_type: visitorObj.visitor_type,
                            room_no: visitorObj.room_no.trim(),
                            bed_no: visitorObj.bed_no
                        };
                        var visitorRecord = new Visitor(obj1);
                        visitorRecord.save(function (err, visitorData) {
                            if (err) {
                                callback(err, false);
                            } else {
                                finalResponse.visitorData = visitorData;                                
                                callback(null, finalResponse);
                            }
                        })
                    }else{
                        var checkObj = {
                            visitorId: visitorFoundData._id,
                            userFacilityId: visitorObj.userFacilityId,
                            status: '0'
                        }
                        CheckInOut.findOne(checkObj)
                        .sort({ createdAt: -1 })
                        .exec(function(err, checkOutFoundData){
                            if(err){
                                callback(err, false);
                            }else if(checkOutFoundData == null){
                                finalResponse.visitorData = visitorFoundData;
                                callback(null, finalResponse);
                            }else{                                
                                res.json({
                                    code: config.statusCode.badRequest,
                                    data: {},
                                    message: i18n.__("VISITOR_ALREADY_CHECKED_OUT")
                                });
                            }
                        })
                    }
                })
            },
            function (finalResponse, callback) { //Save checkout data
                var newObj = {
                    visitorId: finalResponse.visitorData._id,
                    userFacilityId: visitorObj.userFacilityId,
                    checkOutDate: visitorObj.checkOutDate,
                    status: '0'
                };
                var checkOutRecord = new CheckInOut(newObj);
                checkOutRecord.save(function (err, checkOutData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.checkOutData = checkOutData;
                        callback(null, finalResponse);
                    }
                });
            }
        ],
        function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: data,
                    message: i18n.__("CHECK_OUT_SUCCESSFULLY")
                });
            }
        });
    }
}

/**
 * Function is use to send check in alerts or notifications via emails and text
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 19-07-2018
 */
function sendCheckInNotifications(sendCheckInObj) {
    var finalResponse = {};
    finalResponse.facilityNotificationsSettings = {};
    finalResponse.twilioInfo = {};
    finalResponse.roomNo = '';
    waterfall([
        function (callback) { //get facility notification info
            FacilityNotificationSettings.findOne({
                userFacId: mongoose.Types.ObjectId(sendCheckInObj.userFacId),
                isDelete: false,
                status: true
            }).exec(function (err, facilityNotificationsSettings) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.facilityNotificationsSettings = facilityNotificationsSettings;
                    callback(null, finalResponse);
                }
            })
        },
        function (finalResponse, callback) { //send email and sms notification
            if (finalResponse.facilityNotificationsSettings.checkInNotification.status == true) {
                async.eachSeries(finalResponse.facilityNotificationsSettings.checkInNotification.emailsArray, function (notificationData, next) {
                    var baseUrl = config.email.base_url;
                    if(sendCheckInObj.visitorData.bed_no || sendCheckInObj.visitorData.bed_no !='' || sendCheckInObj.visitorData.bed_no !=null || sendCheckInObj.visitorData.bed_no !=undefined){
                        finalResponse.roomNo = sendCheckInObj.visitorData.room_no+' '+sendCheckInObj.visitorData.bed_no;
                    }else{
                        finalResponse.roomNo = sendCheckInObj.visitorData.room_no;
                    } 
                    var options = {
                        template: 'notifyCheckInVisitor.html',
                        from: config.email.from,
                        repalcement: {
                            "{{date}}": moment(sendCheckInObj.checkInDate).format('MM-DD-YYYY'),
                            "{{visitor_name}}": sendCheckInObj.visitorData.firstName + ' ' + sendCheckInObj.visitorData.lastName,
                            "{{visited_to}}": sendCheckInObj.visitorData.visitedTo,
                            "{{room_no}}": finalResponse.roomNo,
                            "{{fac_name}}": sendCheckInObj.facName,
                            "{{user.url}}": baseUrl + "/facility/checkInLog",
                            "{{logo_url}}": baseUrl + config.email.logo_url,
                            "{{copyright}}": config.email.copyright,
                            "{{link.abuse_email}}": config.email.abuse_email
                        },
                        to: notificationData,
                        subject: 'Checking In'
                    };
                    emailSend.smtp.sendMail(options, function (err, response) {
                        if (err) {
                            next();
                        } else {                         
                            next();
                        }
                    })
                }, function (err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        var checkInDate = moment(sendCheckInObj.checkInDate).format('MM-DD-YYYY');
                        var text = "Hello, " + sendCheckInObj.visitorData.firstName + ' ' + sendCheckInObj.visitorData.lastName + " checked in at " + sendCheckInObj.facName + " and visiting to "  + sendCheckInObj.visitorData.visitedTo + " for room: " + finalResponse.roomNo + " on " + checkInDate;
                        var smsData = {
                            to: finalResponse.facilityNotificationsSettings.checkInNotification.phoneNumber,
                            from: sendCheckInObj.twilioTollFreeNumber,
                            message: text
                        }
                        twilio.sendSMS(smsData, function (returnData) {
                            if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                                finalResponse.twilioInfo = returnData;
                                callback(null, finalResponse);
                            } else {                    
                                finalResponse.twilioInfo = returnData;
                                callback(null, finalResponse);  
                            }
                        });
                    }
                })
            } else {
                callback(null, finalResponse);
            }
        },
        function (finalResponse, callback) { //Save notification sms history                                     
            if (finalResponse.facilityNotificationsSettings.checkInNotification.status == true && finalResponse.twilioInfo.status == config.statusCode.success) {
                var messageBody = finalResponse.twilioInfo.message.toJSON();
                var smsInfo = {};
                smsInfo.userFacId = sendCheckInObj.userFacId;
                smsInfo.to = messageBody.to;
                smsInfo.from = messageBody.from;
                smsInfo.text = messageBody.body;
                smsInfo.type = 'check_in';
                var notificationSmsHistory = new NotificationSmsHistory(smsInfo);
                notificationSmsHistory.save(function (err, SmsSavedData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            } else {                                                            
                callback(null, finalResponse);
            }
        } 
    ],
    function (err, data) {
        if (err) {} else {}
    });
}

/**
 * Function is use to get pop-up messages
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-07-2018
 */
function getPopupMessages(req, res) {
    var finalResponse = {};
    finalResponse.visitorsArray = [];
    finalResponse.visitorsIds = req.body.visitorsId;
    var count = 0;
    waterfall([
        function (callback) { //get facility notification info
            async.eachSeries(req.body.visitorsId, function (id, next) {
                // console.log("id!!!!!!!!!!!!!", id, req.body.visitorsId);
                // return;
                var condition = {};
                condition._id = mongoose.Types.ObjectId(id);
                condition['smsInfo.isReplied'] = false;
                condition['smsInfo.isDelete'] = false;
                
                var aggregate = [{
                        $lookup: {
                            from: 'smshistories',
                            localField: "_id",
                            foreignField: "visitorId",
                            as: "smsInfo"
                        }
                    },{
                        $unwind: {
                            path: "$smsInfo",
                            preserveNullAndEmptyArrays: true
                        }
                    },{
                        $lookup: {
                            from: 'userfacilities',
                            localField: "userFacilityId",
                            foreignField: "_id",
                            as: "userFacInfo"
                        }
                    },
                    {
                        $unwind: "$userFacInfo"
                    },{
                        $lookup: {
                            from: 'facilities',
                            localField: "userFacInfo.facilityId",
                            foreignField: "_id",
                            as: "facInfo"
                        }
                    },
                    {
                        $unwind: "$facInfo"
                    },
                    {
                        $match: condition
                    },{
                        "$group": {
                            "_id": "$_id",
                            "firstName":   { "$first": "$firstName" },
                            "lastName":    { "$first": "$lastName" },
                            "phoneNumber": { "$first": "$phoneNumber" },
                            "visitedTo": { "$first": "$visitedTo" },
                            "room_no": { "$first": "$room_no" },
                            "bed_no": { "$first": "$bed_no" },
                            "visitor_type": { "$first": "$visitor_type" },
                            "relation_type": { "$first": "$relation_type" },
                            "vendor_type": { "$first": "$vendor_type" },
                            "tollFreeNo": { "$first": "$facInfo.twilioTollFreeNumber" },
                            "smsInfo": { "$push": "$smsInfo" }
                        }
                    }
                ];
    
                var countQuery = [].concat(aggregate);
                aggregate.push({
                    $sort: { createdAt: 1 }
                });
                Visitor.aggregate(aggregate).then(function (visData) {
                    if(visData[0] == undefined){
                        count++;
                        // console.log("comes in undefined", count);
                        var index = (finalResponse.visitorsIds).indexOf(id);
                        if (index > -1) {
                            finalResponse.visitorsIds.splice(index, 1);
                            next();
                        }else{
                            next();
                        }
                    }else{
                        finalResponse.visitorsArray.push(visData[0]);
                        next();                        
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })    
        }
    ],
    function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            // console.log("dadtadstadsdastdatsdtasdfta", data);
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to send reply to visitor messages
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 27-07-2018
 */
function sendMessageOnChatPopup(req, res) {
    console.log("req.body", req.body);
    var finalResponse = {};
    waterfall([
        function (callback) { //get facility notification info
            async.eachSeries(req.body.smsInfo, function (sms, next) {
                SMSHistory.findOneAndUpdate({
                    _id: sms._id
                }, {
                    $set: {
                        isReplied: true
                    }
                }, function (err, visitorSavedData) {
                    if (err) {
                        next();
                    } else {
                        next();
                    }
                });                
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })    
        },
        function (finalResponse, callback) { //send sms
            var smsData = {
                to: req.body.phoneNumber,
                from: req.user.twilioTollFreeNumber,
                message: req.body.appMessage
            }
            twilio.sendSMS(smsData, function (returnData) {
                if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                    finalResponse.twilioInfo = returnData;
                    callback(null, finalResponse);
                } else {
                    finalResponse.twilioInfo = returnData;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Save sms history
            if (finalResponse.twilioInfo.status == config.statusCode.success) {
                var messageBody = finalResponse.twilioInfo.message.toJSON();
                var smsInfo = {};
                smsInfo.userFacilityId = req.user.userFacId;
                smsInfo.visitorId = req.body._id;
                smsInfo.to = messageBody.to;
                smsInfo.from = messageBody.from;
                smsInfo.text = messageBody.body;
                var smsHistory = new SMSHistory(smsInfo);
                smsHistory.save(function (err, SmsSavedData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            } else {
                callback(null, finalResponse);
            }
        }
    ],
    function (err, data) {
        console.log("err, data", err, data);
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("SMS_SENT_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to view to visitor messages
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 28-07-2018
 */
function viewMessageOnChatPopup(req, res) {
    console.log("req.body", req.body);
    var finalResponse = {};
    waterfall([
        function (callback) { //get facility notification info
            async.eachSeries(req.body.smsInfo, function (sms, next) {
                SMSHistory.findOneAndUpdate({
                    _id: sms._id
                }, {
                    $set: {
                        isReplied: true
                    }
                }, function (err, visitorSavedData) {
                    if (err) {
                        next();
                    } else {
                        next();
                    }
                });                
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })    
        }
    ],
    function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("UPDATED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to express resident check in
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 2-08-2018
 */
function getCheckInExpressResident(req, res) {
    CheckInOut.findOneAndUpdate({
        _id: mongoose.Types.ObjectId(req.body.checkInId)
    }, {
        $set: {
            status: "1",
            checkInDate: moment(req.body.checkInDate),
        }
    }, function (err, updatedData) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("UPDATED_SUCCESSFULLY")
            });
        }
    });
}
