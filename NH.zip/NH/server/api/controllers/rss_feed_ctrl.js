'use strict';

var mongoose = require('mongoose'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    i18n = require("i18n"),
    moment = require('moment'),
    request = require ("request"),
    FeedParser = require ("feedparser"),
    //require collections
    RssChannel = mongoose.model('rssChannel'),
    RssFeed = mongoose.model('rssFeed'),    
    FacilityRssChannel = mongoose.model('facilityRssChannel'),
    FacilitySavedRssFeed = mongoose.model('facilitySavedRssFeed'),    
    
    //require js files
    config = require('../../config/config.js');

module.exports = {
    addChannelTitle: addChannelTitle,
    getRssFeedFromChannels: getRssFeedFromChannels,
    getAllRssChannels: getAllRssChannels,
    getAllRssFeed: getAllRssFeed,
    selectionRssChannels: selectionRssChannels,
    saveFacilityFavouriteFeed: saveFacilityFavouriteFeed,
    getSavedRssFeeds: getSavedRssFeeds,
    removeSavedFeed: removeSavedFeed
}

/**
 * Function is use to add channel title 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 11-May-2018
 */
function addChannelTitle(req, res) {
    var finalResponse = {};
    if (!req.body.channelTitle || !req.body.channelName || !req.body.feedUrl ) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else {
        waterfall([
            function (callback) { //Check for title is already exist
                RssChannel.existCheck(req.body.channelTitle.trim(), req.body.channelName.trim(), function (err, exist) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (!exist) {
                            console.log("title exist")
                            res.json({
                                code: config.statusCode.badRequest,
                                data: {},
                                message: i18n.__("TITLE_ALREADY_EXIST")
                            });
                        } else {
                            callback(null, finalResponse);
                        }
                    }
                });
            },
            function (finalResponse, callback) { //Save channel 
                var rssChannel = new RssChannel(req.body);
                rssChannel.save(function (err, channelSavedData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            }  
        ],
        function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: data,
                    message: i18n.__("DATA_SAVED_SUCCESSFULLY")
                });
            }
        });
    }
}


/**
 * Function is use to get rss feeds from chhanels 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 12-May-2018
 */
function getRssFeedFromChannels() {
    var finalResponse = {};
    waterfall([
        function (callback) { //Find all the rss channels
            RssChannel.find({ isDelete: false, status: '0'}).exec(function (err, rssChannelsData) {
                if (err) {
                    callback(err, false);
                } else {
                    if(rssChannelsData.length > 0){
                        finalResponse.rssChannelsData = rssChannelsData;
                        callback(null, finalResponse);    
                    }
                }
            });
        },
        function (finalResponse, callback) { //Fetch rss feed on the basis of guid(global unique identifier) or link if guid is missing 

            async.eachSeries(finalResponse.rssChannelsData, function(rssChannel, next){
                getFeed (rssChannel.feedUrl, function (err, feedItems) {
                    if(err){
                        // console.log("err", err);
                        next();
                    }else {
                        async.eachSeries(feedItems, function(feedItem, feedItemsCallback){
                            var feedObj = {
                                rssChannelId: rssChannel._id,
                                guid: feedItem.guid ? feedItem.guid: '',
                                link: feedItem.link,
                                title: feedItem.title,
                                summary: feedItem.summary,
                                description: feedItem.description,
                                imageUrl: feedItem.image.url,
                                pubDate: feedItem.pubDate,
                                date: feedItem.date,
                                author: feedItem.author
                            }

                            var condition = {};
                            condition.isDelete = false;
                            condition.status = '0';
                            if(feedObj.guid != '' || feedObj.guid != null || feedObj.guid != undefined){
                                condition.guid = feedObj.guid;
                                condition.link = feedObj.link;
                            }else{
                                condition.link = feedObj.link;
                            }
                            RssFeed.update(condition,{ $set: feedObj }, { upsert: true }, function(err, updatedObj) { //save rss data into DB
                                if (err) {
                                    feedItemsCallback();
                                } else {
                                    feedItemsCallback();
                                }
                            });
                            //end save condition
                        },function(err){
                            if(err){
                                next();
                            }else{
                                next();
                            }
                        })
                    }
                });
            },function(err){
                if(err){
                    callback(err, false);
                }else{
                    callback(null, finalResponse); 
                }
            })
        }  
    ],
    function (err, data) {
        if (err) {} else {}
    });
}

/**
 * Function is use to get rss feed from a channel 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 12-May-2018
 */
function getFeed (urlfeed, callback) {
    var req = request (urlfeed);
    var feedparser = new FeedParser ();
    var feedItems = new Array ();
    req.on ("response", function (response) {
        var stream = this;
        if (response.statusCode == config.statusCode.success) {
            stream.pipe (feedparser);
        }
    });
    req.on ("error", function (err) {
        callback (err, false);
    });
    feedparser.on ("readable", function () {
        try {
            var item = this.read (), flnew;
            if (item !== null) { 
                feedItems.push (item);
            }
        }
        catch (err) {
            callback (err, false);
        }
    });
    feedparser.on ("end", function () {
        callback (null, feedItems);
    });
    feedparser.on ("error", function (err) {
        callback (err, false);
    });
}

/**
 * Function is use to get all rss channels  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 14-May-2018
 */
function getAllRssChannels(req, res) {

    var finalResponse = {};
    finalResponse.finalRssChannels = [];
    waterfall([
        function (callback) { //Find all the rss channels
            RssChannel.find({ isDelete: false, status: '0' }).exec(function(err, rssChannels){
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.rssChannels = rssChannels;
                    callback(null, finalResponse);
                }
            })
        },
        function (finalResponse, callback) { //update status of rss channel after checking that exist in facility preferred channels
            
            async.eachSeries(finalResponse.rssChannels, function(rssChannel, next){
                var condition = {
                    rssChannelId: mongoose.Types.ObjectId(rssChannel._id),
                    userFacId: mongoose.Types.ObjectId(req.user.userFacId),
                    isDelete: false,
                    status: true
                }
                var newRssChannel = rssChannel.toObject();
                FacilityRssChannel.findOne(condition).exec(function(err, facilityRssChannelData){
                    if(err){
                        callback(err, false);
                    }else if(facilityRssChannelData){
                        newRssChannel.status = true;
                        finalResponse.finalRssChannels.push(newRssChannel);
                        next();
                    }else {
                        newRssChannel.status = false;
                        finalResponse.finalRssChannels.push(newRssChannel);
                        next();
                    }
                })
            },function(err){
                if(err){
                    callback(err, false);
                }else{
                    callback(null, finalResponse);
                }
            })
        }  
    ],
    function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data.finalRssChannels,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });  
}

/**
 * Function is use to get all rss feeds to view  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 14-May-2018
 */
function getAllRssFeed(req, res) {
    var finalResponse = {};
    finalResponse.savedFeeds = [];
    finalResponse.rssChannelsIds = [];
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    
    waterfall([
        function (callback) { 
            
            async.each(req.body.rssChannelsList, function(rssChannel, callbackfirst) { //Get channles id having status true 
                if(rssChannel.status == true){
                    finalResponse.rssChannelsIds.push(rssChannel._id);
                    callbackfirst();
                }else if(rssChannel.status == false){
                    callbackfirst();
                }else{
                    callbackfirst(err, false);
                }
            },function(err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Get saved facility rss feed
            var condition = {
                userFacId: mongoose.Types.ObjectId(req.user.userFacId),
                isDelete: false,                
                status: true,
                rssChannelId: { $in: finalResponse.rssChannelsIds}
            }
            FacilitySavedRssFeed.find(condition).distinct('rssFeedId').exec(function(err, savedFeeds){
                if(err){
                    callback(err, false);
                }else{
                    finalResponse.savedFeeds = savedFeeds;
                    callback(null, finalResponse);
                }
            })
        },
        function (finalResponse, callback) { //Get rss feeds for facility upto ten days back only

            var today_date = moment().endOf('day');
            var tenth_day_back_date = moment().endOf('day').add(-10, 'days');
            var momentObjFrom = new Date(moment(tenth_day_back_date));
            var momentObjTo = new Date(moment(today_date));
            var condition = {
                isDelete: false,
                status: '0',
                rssChannelId: { $in: finalResponse.rssChannelsIds },
                _id: { $nin: finalResponse.savedFeeds },
                $and:[
                    { pubDate: {$lte: momentObjTo} }, 
                    { pubDate:  {$gte: momentObjFrom} },
                ],
            };

            RssFeed.find(condition)
            .sort({ pubDate: -1 })
            .skip(parseInt(skip))
            .limit(parseInt(count))
            .lean().exec(function(err, rssFeeds) {
                if (err) {
                    callback(err, false);
                } else {
                    var data = {};
                    data.data = rssFeeds;
                    RssFeed.find(condition)
                        .count()
                        .exec(function(err, total_count) {
                            if (err) {
                                callback(err, false);
                            } else {
                                data.total_count = total_count;
                                callback(null, data);
                            }
                        });
                }
            })
        } 
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to select facility favourite channel  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 14-May-2018
 */
function selectionRssChannels(req, res) {
    
    if(req.body.status == true){
        var selectObj = {
            rssChannelId: req.body.id,
            userFacId: req.user.userFacId,
            lastAddedBy: req.user.role,
            lastAddedById: req.user.uid,
            status: req.body.status
        }
    }else{
        var selectObj = {
            rssChannelId: req.body.id,
            userFacId: req.user.userFacId,
            lastRemovedBy: req.user.role,
            lastRemovedById: req.user.uid,
            status: req.body.status
        }
    }
    
    var condition = {
        rssChannelId: mongoose.Types.ObjectId(selectObj.rssChannelId),
        userFacId: mongoose.Types.ObjectId(selectObj.userFacId),
        isDelete: false
    }
    FacilityRssChannel.update(condition,{ $set: selectObj }, { upsert: true }, function(err, updatedObj) { //save favourite rss channels of facility into DB
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: updatedObj,
                message: i18n.__("DATA_SAVED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to save facility favourite rss feed  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 15-May-2018
 */
function saveFacilityFavouriteFeed(req, res) {
    var selectObj = {
        rssFeedId: req.body.id,
        rssChannelId: req.body.rssChannelId,
        userFacId: req.user.userFacId,
        savedBy: req.user.role,
        savedById: req.user.uid,
        status: true
    }
    
    var condition = {
        rssChannelId: mongoose.Types.ObjectId(selectObj.rssChannelId),
        rssFeedId: mongoose.Types.ObjectId(selectObj.rssFeedId),
        userFacId: mongoose.Types.ObjectId(selectObj.userFacId),
        isDelete: false
    }

    FacilitySavedRssFeed.update(condition,{ $set: selectObj }, { upsert: true }, function(err, updatedObj) { //save favourite rss feed of facility into DB
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: updatedObj,
                message: i18n.__("FEED_SAVED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get saved rss feeds of facility to view  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 15-May-2018
 */
function getSavedRssFeeds(req, res) {
    var finalResponse = {};
    finalResponse.savedFeeds = [];
    finalResponse.rssChannelsIds = [];
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    
    waterfall([
        function (callback) { 
            
            async.each(req.body.rssChannelsList, function(rssChannel, callbackfirst) { //Get channles id having status true 
                if(rssChannel.status == true){
                    finalResponse.rssChannelsIds.push(rssChannel._id);
                    callbackfirst();
                }else if(rssChannel.status == false){
                    callbackfirst();
                }else{
                    callbackfirst(err, false);
                }
            },function(err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Get saved facility rss feed
            var condition = {
                userFacId: mongoose.Types.ObjectId(req.user.userFacId),
                isDelete: false,                
                status: true,
                rssChannelId: { $in: finalResponse.rssChannelsIds}
            }
            FacilitySavedRssFeed.find(condition).distinct('rssFeedId').exec(function(err, savedFeeds){
                if(err){
                    callback(err, false);
                }else{
                    finalResponse.savedFeeds = savedFeeds;
                    callback(null, finalResponse);
                }
            })
        },
        function (finalResponse, callback) { //Get rss feeds for facility
            var condition = {
                isDelete: false,
                status: '0',
                _id: { $in: finalResponse.savedFeeds }
            };

            RssFeed.find(condition)
            .sort({ pubDate: -1 })
            .skip(parseInt(skip))
            .limit(parseInt(count))
            .lean().exec(function(err, rssFeeds) {
                if (err) {
                    callback(err, false);
                } else {
                    var data = {};
                    data.data = rssFeeds;
                    RssFeed.find(condition)
                        .count()
                        .exec(function(err, total_count) {
                            if (err) {
                                callback(err, false);
                            } else {
                                data.total_count = total_count;
                                callback(null, data);
                            }
                        });
                }
            })
        } 
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to remove feed from saved facility favourite feed  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 15-May-2018
 */
function removeSavedFeed(req, res) {
    var selectObj = {
        rssFeedId: req.body.id,
        rssChannelId: req.body.rssChannelId,
        userFacId: req.user.userFacId,
        isDeletedBy: req.user.role,
        isDeletedById: req.user.uid,
        isDelete: true
    }
    
    var condition = {
        rssChannelId: mongoose.Types.ObjectId(selectObj.rssChannelId),
        rssFeedId: mongoose.Types.ObjectId(selectObj.rssFeedId),
        userFacId: mongoose.Types.ObjectId(selectObj.userFacId),
        isDelete: false
    }

    FacilitySavedRssFeed.update(condition,{ $set: selectObj }, { upsert: true }, function(err, updatedObj) { //Remove feed from facility favourite feeds
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: updatedObj,
                message: i18n.__("FEED_REMOVED_SUCCESSFULLY")
            });
        }
    });
}
