'use strict';

var mongoose = require('mongoose'),
    generator = require('generate-password'),
    formidable = require('formidable'),
    fs = require('fs-extra'),
    path = require('path'),
    jwt = require('jsonwebtoken'),
    validator = require('validator'),
    utility = require('../lib/utility.js'),
    crypto = require('./../lib/crypto.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    Joi = require('joi'),
    i18n = require("i18n"),
    moment = require('moment'),
    // socket = require('socket.io'),
    //require models
    User = mongoose.model('user'),
    Visitor = mongoose.model('visitors'),
    CheckInOut = mongoose.model('checkInOut'),
    TrackingViewedLink = mongoose.model('trackingViewedLink'),
    UserFacility = mongoose.model('userFacility'),
    Facility = mongoose.model('facility'),
    SmsHistory = mongoose.model('smsHistory'),
    NotificationHistory = mongoose.model('notificationHistory'),
    SMSHistory = mongoose.model('smsHistory'),
    IncidentReports = mongoose.model('incidentReport'),
    IncidentNotes = mongoose.model('incidentNotes'),
    BroadcastMessages = mongoose.model('broadcastMessage'),
    ResponseMessages = mongoose.model('responseMessage'),
    FacilityNotificationSettings = mongoose.model('facilityNotificationSettings'),
    NotificationSmsHistory = mongoose.model('notificationSmsHistory'),

    //require js file
    emailSend = __rootRequire('api/core/email'),
    convert = require('xml-js'),
    twilio = require('./../lib/twilio.js'),
    config = require('../../config/config.js');

module.exports = {
    getAllVisitors: getAllVisitors,
    getCheckInLog: getCheckInLog,
    getAllVisitorsDashboard: getAllVisitorsDashboard,
    linkTracking: linkTracking,
    visitorCount: visitorCount,
    getAllRatingResponseCount: getAllRatingResponseCount,
    latestNegativeRatings: latestNegativeRatings,
    latestPositiveRatings: latestPositiveRatings,
    latestResponse: latestResponse,
    getVisitorById: getVisitorById,
    updateVisitorProfile: updateVisitorProfile,
    getVisitorMessages: getVisitorMessages,
    getCheckInLogByVisitorId: getCheckInLogByVisitorId,
    trackVisitorViewedLink: trackVisitorViewedLink,
    getClickTrackerCounts: getClickTrackerCounts,
    getAllMessageCount: getAllMessageCount,
    getAllResponseRate: getAllResponseRate,
    getListVistorsHeadersCount: getListVistorsHeadersCount,
    getCheckInLogHeaderCounts: getCheckInLogHeaderCounts,
    getVisitorMessageHeadersCount: getVisitorMessageHeadersCount,
    saveNotification: saveNotification,
    getNotificationDetails: getNotificationDetails,
    notificationViewed: notificationViewed,
    getVisitorTwilioChat: getVisitorTwilioChat,
    sendMessage: sendMessage,
    changeVisitorMenuStatus: changeVisitorMenuStatus,
    setVisitorAppMessage: setVisitorAppMessage,
    checkInAllNotiStatusViewed: checkInAllNotiStatusViewed,
    addIncidentReports: addIncidentReports,
    incidentReportsList: incidentReportsList,
    editIncidentReports: editIncidentReports,
    assignIncidentToEmployee: assignIncidentToEmployee,
    getIncidentByVisitorId: getIncidentByVisitorId,
    employeeIncidentReportsList: employeeIncidentReportsList,
    acceptIncidentByEmployee: acceptIncidentByEmployee,
    sendBroadCastAll: sendBroadCastAll,
    addBroadCastMessage: addBroadCastMessage,
    getBroadCastMessageDetails: getBroadCastMessageDetails,
    getReviewMessageDetails: getReviewMessageDetails,
    deleteSavedMessage: deleteSavedMessage,
    getOpenIncidentReportsList: getOpenIncidentReportsList,
    getResolvedIncidentReportsList: getResolvedIncidentReportsList,
    getEditIncidentRecord: getEditIncidentRecord,
    deleteVisitor: deleteVisitor,
    getIncidentNotes: getIncidentNotes,
    addIncidentNote: addIncidentNote,
    updateCustomIncidentSetting: updateCustomIncidentSetting,
    updateEveryDocument: updateEveryDocument,
    getSettingIncident: getSettingIncident,
    incidentAcceptVerify: incidentAcceptVerify,
    incidentRejectVerify: incidentRejectVerify
}

/**
 * Function is use to get Check In Log
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 17-May-2018
 */
function getCheckInLog(req, res) {
    var finalResponse = {};
    var start_day_date, end_day_date, momentObjFrom, momentObjTo;
    var orgData = {};
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);

    waterfall([
        function (callback) { //CheckInOut Data

            var condition = {};
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
            condition.isDelete = false;
            var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            if (searchText != undefined && searchText != 'undefined') {
                condition.$or = [{
                    'visitorInfo.firstName': new RegExp(searchText, 'gi')
                },
                {
                    'visitorInfo.lastName': new RegExp(searchText, 'gi')
                },
                {
                    'visitorInfo.phoneNumber': new RegExp(searchText, 'gi')
                },
                {
                    'visitorInfo.visitorName': new RegExp(searchText, 'gi')
                }
                ];
            }
            switch (req.body.selectType) {
                case '1':
                    start_day_date = moment(req.body.date).startOf('day');
                    end_day_date = moment(req.body.date).endOf('day');
                    momentObjFrom = new Date(moment(start_day_date));
                    momentObjTo = new Date(moment(end_day_date));
                    condition.$and = [{
                        createdAt: {
                            $gte: momentObjFrom
                        }
                    },
                    {
                        createdAt: {
                            $lte: momentObjTo
                        }
                    }
                    ];
                    break;
                case '2':
                    start_day_date = moment(req.body.date).endOf('day');
                    end_day_date = moment(req.body.date).endOf('day').add(-7, 'days');
                    momentObjFrom = new Date(moment(end_day_date));
                    momentObjTo = new Date(moment(start_day_date));
                    condition.$and = [{
                        createdAt: {
                            $gte: momentObjFrom
                        }
                    },
                    {
                        createdAt: {
                            $lte: momentObjTo
                        }
                    }
                    ];
                    break;
                case '3':
                    start_day_date = moment(req.body.date).endOf('day');
                    end_day_date = moment(req.body.date).endOf('day').add(-6, 'months');
                    momentObjFrom = new Date(moment(end_day_date));
                    momentObjTo = new Date(moment(start_day_date));
                    condition.$and = [{
                        createdAt: {
                            $gte: momentObjFrom
                        }
                    },
                    {
                        createdAt: {
                            $lte: momentObjTo
                        }
                    }
                    ];
                    break;
                case '4':
                    start_day_date = moment(req.body.date).endOf('day');
                    end_day_date = moment(req.body.date).endOf('day').add(-1, 'years');
                    momentObjFrom = new Date(moment(end_day_date));
                    momentObjTo = new Date(moment(start_day_date));
                    condition.$and = [{
                        createdAt: {
                            $gte: momentObjFrom
                        }
                    },
                    {
                        createdAt: {
                            $lte: momentObjTo
                        }
                    }
                    ];
                    break;
            }

            if (req.body.createdAt) {
                start_day_date = moment(req.body.createdAt).startOf('day');
                end_day_date = moment(req.body.createdAt).endOf('day');
                momentObjFrom = new Date(moment(start_day_date));
                momentObjTo = new Date(moment(end_day_date));
                condition.$and = [{
                    createdAt: {
                        $gte: momentObjFrom
                    }
                },
                {
                    createdAt: {
                        $lte: momentObjTo
                    }
                }
                ];
            }

            if (req.body.firstName) {
                condition['visitorInfo.firstName'] = new RegExp(req.body.firstName, 'gi');
            }
            if (req.body.lastName) {
                condition['visitorInfo.lastName'] = new RegExp(req.body.lastName, 'gi');
            }
            if (req.body.phoneNumber) {
                condition['visitorInfo.phoneNumber'] = new RegExp(req.body.phoneNumber, 'gi');
            }
            var aggregate = [{
                $lookup: {
                    from: 'visitors',
                    localField: "visitorId",
                    foreignField: "_id",
                    as: "visitorInfo"
                }
            },
            {
                $unwind: "$visitorInfo"
            },
            {
                $match: condition
            },
            ];
            var project = {
                $project: {
                    "firstName": "$visitorInfo.firstName",
                    "lastName": "$visitorInfo.lastName",
                    "phoneNumber": "$visitorInfo.phoneNumber",
                    "visitor_type": "$visitorInfo.visitor_type",
                    "relation_type": "$visitorInfo.relation_type",
                    "vendor_type": "$visitorInfo.vendor_type",
                    "checkInDate": "$checkInDate",
                    "checkOutDate": "$checkOutDate",
                    "visitedTo": "$visitedTo",
                    "status": "$status",
                    "rating": "$rating",
                    "createdAt": "$createdAt",
                    "room_no": "$visitorInfo.room_no",
                    "bed_no": "$visitorInfo.bed_no",
                    "visitorName": "$visitorInfo.visitorName"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            aggregate.push({
                $sort: sorting
            });
            aggregate.push({
                $skip: parseInt(skip)
            });
            aggregate.push({
                $limit: parseInt(count)
            });
            CheckInOut.aggregate(aggregate).then(function (visitorData) {
                var data = {};
                data.data = visitorData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                CheckInOut.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    data.total_count = cnt;
                    callback(null, data);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get All Visitors for dashboard
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 17-May-2018
 */
function getAllVisitorsDashboard(req, res) {
    var condition = {
        isDelete: false,
        userFacilityId: req.user.userFacId,
        visitor_type: {
            $ne: 'expressResident'
        }
    };
    Visitor.find(condition)
        .sort({
            createdAt: -1
        })
        .limit(parseInt(5))
        .lean().exec(function (err, visitorData) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("ERROR")
                })
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: visitorData,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }
        })
}

/**
 * Function is use to get All Visitors 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 17-May-2018
 */
function getAllVisitors(req, res) {
    var finalResponse = {};
    var orgData = {};
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);

    waterfall([
        function (callback) { //CheckInOut Data

            var condition = {
                visitor_type: {
                    $ne: 'expressResident'
                }
            };
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
            condition.isDelete = false;
            var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            if (searchText != undefined && searchText != 'undefined') {
                condition.$or = [{
                    'firstName': new RegExp(searchText, 'gi')
                },
                {
                    'lastName': new RegExp(searchText, 'gi')
                },
                {
                    'phoneNumber': new RegExp(searchText, 'gi')
                },
                {
                    'visitor_type': new RegExp(searchText, 'gi')
                },
                {
                    'room_no': new RegExp(searchText, 'gi')
                },
                {
                    'bed_no': new RegExp(searchText, 'gi')
                },
                {
                    'visitorName': new RegExp(searchText, 'gi')
                }
                ];
            }

            if (req.body.createdAt) {
                var start_day_date = moment(req.body.createdAt).startOf('day');
                var end_day_date = moment(req.body.createdAt).endOf('day');
                var momentObjFrom = new Date(moment(start_day_date));
                var momentObjTo = new Date(moment(end_day_date));
                condition.$and = [{
                    createdAt: {
                        $gte: momentObjFrom
                    }
                },
                {
                    createdAt: {
                        $lte: momentObjTo
                    }
                }
                ];

            }

            if (req.body.firstName) {
                condition['firstName'] = new RegExp(req.body.firstName, 'gi');
            }
            if (req.body.lastName) {
                condition['lastName'] = new RegExp(req.body.lastName, 'gi');
            }
            if (req.body.phoneNumber) {
                condition['phoneNumber'] = new RegExp(req.body.phoneNumber, 'gi');
            }

            if (req.body.visitor_type) {
                condition['visitor_type'] = new RegExp(req.body.visitor_type, 'gi');
            }
            if (req.body.room_no) {
                condition['room_no'] = new RegExp(req.body.room_no, 'gi');
            }
            if (req.body.bed_no) {
                condition['bed_no'] = new RegExp(req.body.bed_no, 'gi');
            }
            var aggregate = [{
                $match: condition
            },];
            var project = {
                $project: {
                    "firstName": "$firstName",
                    "lastName": "$lastName",
                    "phoneNumber": "$phoneNumber",
                    "flag": "$flag",
                    "createdAt": "$createdAt",
                    "visitor_type": "$visitor_type",
                    "relation_type": "$relation_type",
                    "vendor_type": "$vendor_type",
                    "room_no": "$room_no",
                    "bed_no": "$bed_no",
                    "visitorName": "$visitorName"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            aggregate.push({
                $sort: sorting
            });
            aggregate.push({
                $skip: parseInt(skip)
            });
            aggregate.push({
                $limit: parseInt(count)
            });
            Visitor.aggregate(aggregate).then(function (visitorData) {
                var data = {};
                data.data = visitorData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                Visitor.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    data.total_count = cnt;
                    callback(null, data);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to line Tracking
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 18-May-2018
 * Updated by Sunny
 * Updated Date 24-Jul-2018
 */
function linkTracking(req, res) {
    var finalResponse = {};
    waterfall([
        function (callback) { //CheckInOut Data
            var condition = {
                isDelete: false,
                status: '0',
                rating: {
                    $ne: 0
                },
                sentOnlineLinkInSms: true,
                userFacilityId: mongoose.Types.ObjectId(req.user.userFacId)
            };
            var aggregate = [{
                $lookup: {
                    from: 'visitors',
                    localField: "visitorId",
                    foreignField: "_id",
                    as: "visitorInfo"
                }
            },
            {
                $unwind: "$visitorInfo"
            },
            {
                $match: condition
            },
            ];

            var project = {
                $project: {
                    "firstName": "$visitorInfo.firstName",
                    "lastName": "$visitorInfo.lastName",
                    "phoneNumber": "$visitorInfo.phoneNumber",
                    "rating": "$rating",
                    "viewedLinkDate": "$viewedLinkDate",
                    "viewedLink": "$viewedLink",
                    "sentOnlineLinkInSmsDate": "$sentOnlineLinkInSmsDate"
                }
            };

            aggregate.push(project);
            aggregate.push({
                $sort: {
                    viewedLinkDate: -1
                }
            });

            aggregate.push({
                $limit: parseInt(5)
            });
            CheckInOut.aggregate(aggregate).then(function (visitorData) {
                var data = {};
                data.data = visitorData;
                callback(null, data);
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get Count
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 18-May-2018
 */

function visitorCount(req, res) {
    var finalResponse = {};
    finalResponse.visitorCount = {};
    finalResponse.negativeCount = 0;
    finalResponse.positiveCount = 0;
    finalResponse.neutralCount = 0;
    finalResponse.smsCount = 0;
    finalResponse.neutralRatingPercent = 0;
    finalResponse.positiveRatingPercent = 0;
    finalResponse.negativeRatingPercent = 0;
    finalResponse.foundFacilityData = {};
    waterfall([
        function (callback) { //get facility sms count
            Facility.findOne({
                _id: mongoose.Types.ObjectId(req.user.facId),
                isDelete: false,
                status: '1'
            }).exec(function (err, foundFacilityData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (!foundFacilityData) {
                        res.json({
                            code: config.statusCode.unauthorized,
                            data: {},
                            message: i18n.__("UNAUTHORIZED")
                        });
                    } else {
                        finalResponse.foundFacilityData = foundFacilityData;
                        callback(null, finalResponse);
                    }
                }
            })
        },
        function (finalResponse, callback) { //get visitor count 
            var condition = {
                isDelete: false,
                userFacilityId: mongoose.Types.ObjectId(req.user.userFacId)
            };
            Visitor.find(condition).count().exec(function (err, visitorCount) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.visitorCount = visitorCount;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //get positive ratings count
            var condition = {
                isDelete: false,
                ratingStatus: 'positive',
                userFacilityId: mongoose.Types.ObjectId(req.user.userFacId)
            };
            CheckInOut.find(condition).count().exec(function (err, positiveCount) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.positiveCount = positiveCount;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get  negative ratings count
            var condition = {
                isDelete: false,
                ratingStatus: 'negative',
                userFacilityId: mongoose.Types.ObjectId(req.user.userFacId)
            };
            CheckInOut.find(condition).count().exec(function (err, negativeCount) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.negativeCount = negativeCount;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get  neutral ratings count
            var condition = {
                isDelete: false,
                ratingStatus: 'neutral',
                userFacilityId: mongoose.Types.ObjectId(req.user.userFacId)
            };
            CheckInOut.find(condition).count().exec(function (err, neutralCount) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.neutralCount = neutralCount;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get facility sms count
            var condition = {
                isDelete: false,
                status: true,
                userFacilityId: mongoose.Types.ObjectId(req.user.userFacId),
                from: {
                    $ne: finalResponse.foundFacilityData.twilioTollFreeNumber
                }
            };
            SmsHistory.find(condition).count().exec(function (err, smsCount) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.smsCount = smsCount;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get visitors total list
            finalResponse.neutralRatingPercent = parseFloat(finalResponse.neutralCount / (finalResponse.neutralCount + finalResponse.negativeCount + finalResponse.positiveCount) * 100).toFixed(2);
            finalResponse.positiveRatingPercent = parseFloat(finalResponse.positiveCount / (finalResponse.neutralCount + finalResponse.negativeCount + finalResponse.positiveCount) * 100).toFixed(2);
            finalResponse.negativeRatingPercent = parseFloat(finalResponse.negativeCount / (finalResponse.neutralCount + finalResponse.negativeCount + finalResponse.positiveCount) * 100).toFixed(2);
            callback(null, finalResponse);
        },
        function (finalResponse, callback) { //get visitors today list
            var condition = {};
            condition.isDelete = false,
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId),
            condition.ratingDone = true
            if (req.body.ratingDate) {
                var start_day_date = moment(req.body.ratingDate).startOf('day');
                var end_day_date = moment(req.body.ratingDate).endOf('day');
                var momentObjFrom = new Date(moment(start_day_date));
                var momentObjTo = new Date(moment(end_day_date));
                condition.$and = [{
                    ratingDate: {
                        $gte: momentObjFrom
                    }
                },
                {
                    ratingDate: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            CheckInOut.find(condition).populate('visitorId').sort({
                createdAt: -1
            }).exec(function (err, todayVisitors) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.todayVisitors = todayVisitors;
                    callback(null, finalResponse);

                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}
/**
 * Function is use to get All Rating Response Count
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 18-May-2018
 */

function getAllRatingResponseCount(req, res) {
    var finalResponse = {};
    finalResponse.sevenDaysVisitors = {};
    finalResponse.thirtyDaysVisitors = {};
    finalResponse.today = {};
    finalResponse.yesterday = {};

    waterfall([
        function (callback) { //get visitors thirty days list
            var condition = {};
            condition.isDelete = false;
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
            condition.ratingDone = true;
            if (req.body.ratingDate) {
                var today_date = moment().endOf('day');
                var thirty_day_back_date = moment().endOf('day').add(-30, 'days');
                var momentObjFrom = new Date(moment(thirty_day_back_date));
                var momentObjTo = new Date(moment(today_date));
                condition.$and = [{
                    ratingDate: {
                        $gte: momentObjFrom
                    }
                },
                {
                    ratingDate: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            CheckInOut.find(condition).count().exec(function (err, thirtyDaysVisitors) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.thirtyDaysVisitors = thirtyDaysVisitors;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get visitors last 7 days list
            var condition = {};
            condition.isDelete = false;
            condition.ratingDone = true;
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
            if (req.body.ratingDate) {
                var today_date = moment().endOf('day');
                var seven_day_back_date = moment().endOf('day').add(-7, 'days');
                var momentObjFrom = new Date(moment(seven_day_back_date));
                var momentObjTo = new Date(moment(today_date));
                condition.$and = [{
                    ratingDate: {
                        $gte: momentObjFrom
                    }
                },
                {
                    ratingDate: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            CheckInOut.find(condition).count().exec(function (err, sevenDaysVisitors) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.sevenDaysVisitors = sevenDaysVisitors;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get visitors yesterday list
            var condition = {};
            condition.isDelete = false;
            condition.ratingDone = true;
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
            if (req.body.ratingDate) {
                var today_date = moment().endOf('day');
                var yesterday_day_back_date = moment().endOf('day').add(-1, 'days');
                var momentObjFrom = new Date(moment(yesterday_day_back_date));
                var momentObjTo = new Date(moment(today_date));
                condition.$and = [{
                    ratingDate: {
                        $gte: momentObjFrom
                    }
                },
                {
                    ratingDate: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            CheckInOut.find(condition).count().exec(function (err, yesterday) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.yesterday = yesterday;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get visitors today list
            var condition = {};
            condition.isDelete = false;
            condition.ratingDone = true;
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
            if (req.body.ratingDate) {
                var start_day_date = moment(req.body.ratingDate).startOf('day');
                var end_day_date = moment(req.body.ratingDate).endOf('day');
                var momentObjFrom = new Date(moment(start_day_date));
                var momentObjTo = new Date(moment(end_day_date));
                condition.$and = [{
                    ratingDate: {
                        $gte: momentObjFrom
                    }
                },
                {
                    ratingDate: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            CheckInOut.find(condition).count().exec(function (err, today) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.today = today;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get visitors total list
            var condition = {};
            condition.isDelete = false;
            condition.ratingDone = true;
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
            CheckInOut.find(condition).count().exec(function (err, totalVisitors) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.totalVisitors = totalVisitors;
                    callback(null, finalResponse);

                }
            });
        }

    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}
/**
 * Function is use to get All Rating Response 
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 24-May-2018
 */
function latestResponse(req, res) {
    var finalResponse = {};
    waterfall([
        function (callback) { //CheckInOut Data
            var condition = {
                isDelete: false,
                CommentDone: true,
                rating: {
                    $ne: 0
                },
                userFacilityId: mongoose.Types.ObjectId(req.user.userFacId)
            };
            var aggregate = [{
                $lookup: {
                    from: 'visitors',
                    localField: "visitorId",
                    foreignField: "_id",
                    as: "visitorInfo"
                }
            },
            {
                $unwind: "$visitorInfo"
            },
            {
                $match: condition
            },
            ];
            var project = {
                $project: {
                    "firstName": "$visitorInfo.firstName",
                    "lastName": "$visitorInfo.lastName",
                    "phoneNumber": "$visitorInfo.phoneNumber",
                    "status": "$status",
                    "rating": "$rating",
                    "reviewDate": "$reviewDate",
                    "comments": "$comments",
                    "CommentDate": "$CommentDate",
                    "ratingStatus": "$ratingStatus"
                }
            };

            aggregate.push(project);
            aggregate.push({
                $sort: {
                    CommentDate: -1
                }
            });
            aggregate.push({
                $limit: parseInt(5)
            });
            CheckInOut.aggregate(aggregate).then(function (latestResponseData) {
                var data = {};
                data.data = latestResponseData;
                callback(null, data);
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}
/**
 * Function is use to get All latest Positive Rating
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 24-May-2018
 */
function latestPositiveRatings(req, res) {
    var finalResponse = {};
    waterfall([
        function (callback) { //CheckInOut Data
            var condition = {
                isDelete: false,
                ratingStatus: 'positive',
                rating: {
                    $ne: 0
                },
                userFacilityId: mongoose.Types.ObjectId(req.user.userFacId)
            };
            var aggregate = [{
                $lookup: {
                    from: 'visitors',
                    localField: "visitorId",
                    foreignField: "_id",
                    as: "visitorInfo"
                }
            },
            {
                $unwind: "$visitorInfo"
            },
            {
                $match: condition
            },
            ];
            var project = {
                $project: {
                    "firstName": "$visitorInfo.firstName",
                    "lastName": "$visitorInfo.lastName",
                    "phoneNumber": "$visitorInfo.phoneNumber",
                    "status": "$status",
                    "rating": "$rating",
                    "reviewDate": "$reviewDate",
                    "comments": "$comments",
                    "ratingDate": "$ratingDate",
                    "ratingStatus": "$ratingStatus"
                }
            };

            aggregate.push(project);
            aggregate.push({
                $sort: {
                    ratingDate: -1
                }
            });
            aggregate.push({
                $limit: parseInt(5)
            });
            CheckInOut.aggregate(aggregate).then(function (latestResponseData) {
                var data = {};
                data.data = latestResponseData;
                callback(null, data);
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}
/**
 * Function is use to get All latest Negative Rating
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 24-May-2018
 */
function latestNegativeRatings(req, res) {
    var finalResponse = {};
    waterfall([
        function (callback) { //CheckInOut Data
            var condition = {
                isDelete: false,
                ratingStatus: 'negative',
                rating: {
                    $ne: 0
                },
                userFacilityId: mongoose.Types.ObjectId(req.user.userFacId)
            };
            var aggregate = [{
                $lookup: {
                    from: 'visitors',
                    localField: "visitorId",
                    foreignField: "_id",
                    as: "visitorInfo"
                }
            },
            {
                $unwind: "$visitorInfo"
            },
            {
                $match: condition
            },
            ];
            var project = {
                $project: {
                    "firstName": "$visitorInfo.firstName",
                    "lastName": "$visitorInfo.lastName",
                    "phoneNumber": "$visitorInfo.phoneNumber",
                    "status": "$status",
                    "rating": "$rating",
                    "reviewDate": "$reviewDate",
                    "comments": "$comments",
                    "ratingDate": "$ratingDate",
                    "ratingStatus": "$ratingStatus"
                }
            };

            aggregate.push(project);
            aggregate.push({
                $sort: {
                    ratingDate: -1
                }
            });
            aggregate.push({
                $limit: parseInt(5)
            });
            CheckInOut.aggregate(aggregate).then(function (latestResponseData) {
                var data = {};
                data.data = latestResponseData;
                callback(null, data);
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is get Visitor By Id
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 25-May-2018
 */
function getVisitorById(req, res) {
    var finalResponse = {};
    finalResponse.data = {};
    finalResponse.avgRatingResponse = 0;
    if (mongoose.Types.ObjectId.isValid(req.query.id)) {
        waterfall([
            function (callback) { //CheckInOut Data
                var condition = {};
                condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
                condition.isDelete = false;
                condition._id = mongoose.Types.ObjectId(req.query.id);
                var aggregate = [{
                    $match: condition
                },];
                var project = {
                    $project: {
                        "firstName": "$firstName",
                        "lastName": "$lastName",
                        "phoneNumber": "$phoneNumber",
                        "email": "$email",
                        "createdAt": "$createdAt",
                        "visitedTo": "$visitedTo",
                        "isCheckInAlert": "$isCheckInAlert",
                        "isAppMessagePopUp": "$isAppMessagePopUp",
                        "isSms": "$isSms",
                        "appMessage": "$appMessage",
                        "visitor_type": "$visitor_type",
                        "relation_type": "$relation_type",
                        "room_no": "$room_no",
                        "bed_no": "$bed_no",
                        "company_name": "$company_name",
                        "vendor_type": "$vendor_type"
                    }
                };
                aggregate.push(project);
                aggregate.push({
                    $sort: {
                        createdAt: -1
                    }
                });
                Visitor.aggregate(aggregate).then(function (result) {
                    finalResponse.data = result[0];
                    callback(null, finalResponse);
                }).catch(function (err) {
                    callback(err, false);
                });
            },
            function (finalResponse, callback) { //get visitors ratings to this facility
                var condition = {};
                condition.isDelete = false;
                condition.ratingDone = true;
                condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
                condition.visitorId = mongoose.Types.ObjectId(finalResponse.data._id);
                CheckInOut.aggregate([{
                    $match: condition
                }, {
                    "$group": {
                        "_id": "$userFacilityId",
                        "avgRating": {
                            "$avg": {
                                "$ifNull": ["$rating", 0]
                            }
                        }
                    }
                }], function (err, rating) {
                    if (rating[0]) {
                        if (rating[0].avgRating) {
                            var avgRating = rating[0].avgRating.toFixed(1);
                            if (avgRating > 3 && avgRating <= 5) {
                                finalResponse.avgRatingResponse = 'Positive'
                            } else if (avgRating > 0 && avgRating < 3) {
                                finalResponse.avgRatingResponse = 'Negative'
                            } else if (avgRating == 3) {
                                finalResponse.avgRatingResponse = 'Neutral'
                            }
                            callback(null, finalResponse);
                        }
                    } else {
                        callback(null, finalResponse);
                    }
                })
            }
        ], function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: data,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }
        });
    } else {
        res.json({
            code: config.statusCode.invalid,
            data: {},
            message: i18n.__("INVALID_URL")
        });
    }

}

/**
 * Function is use to update Visitor Profile
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function updateVisitorProfile(req, res) {
    var finalResponse = {};
    var visObj = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        phoneNumber: req.body.phoneNumber,
        visitor_type: req.body.visitor_type,
        relation_type: req.body.relation_type,
        vendor_type: req.body.vendor_type,
        visitedTo: req.body.visitedTo,
        company_name: req.body.company_name,
        room_no: req.body.room_no,
        bed_no: req.body.bed_no,
        _id: req.body._id,
        userFacilityId: req.user.userFacId
    }
    waterfall([
        function (callback) { //check phone Num is already exist
            Visitor.findOne({
                phoneNumber: visObj.phoneNumber,
                userFacilityId: visObj.userFacilityId,
                _id: {
                    $ne: mongoose.Types.ObjectId(visObj._id)
                },
                isDelete: false
            }).lean().exec(function (err, visitorPhoneCheck) {
                if (err) {
                    callback(err, false);
                } else {
                    if (visitorPhoneCheck) {
                        res.json({
                            code: config.statusCode.badRequest,
                            data: {},
                            message: i18n.__("PHONE_NUM_ALREADY_EXIST")
                        });
                    } else {
                        callback(null, finalResponse);
                    }
                }
            });
        },
        function (finalResponse, callback) { //Update user record
            Visitor.findById(visObj._id).exec(function (err, visitorInfo) {
                if (err) {
                    callback(err, false);
                } else {
                    visitorInfo.firstName = visObj.firstName;
                    visitorInfo.lastName = visObj.lastName;
                    visitorInfo.email = visObj.email;
                    visitorInfo.phoneNumber = visObj.phoneNumber;                    
                    visitorInfo.visitor_type = visObj.visitor_type;                    

                    switch (visObj.visitor_type) {
                        case 'family':
                            visitorInfo.vendor_type = undefined;
                            visitorInfo.company_name = undefined;
                            visitorInfo.relation_type = visObj.relation_type;                    
                            visitorInfo.room_no = visObj.room_no;                    
                            visitorInfo.bed_no = visObj.bed_no;
                            visitorInfo.visitedTo = visObj.visitedTo;
                            break;
                        case 'friend':
                            visitorInfo.vendor_type = undefined;
                            visitorInfo.company_name = undefined;
                            visitorInfo.relation_type = undefined;
                            visitorInfo.room_no = visObj.room_no;                    
                            visitorInfo.bed_no = visObj.bed_no;
                            visitorInfo.visitedTo = visObj.visitedTo;                            
                            break;
                        case 'poa':
                            visitorInfo.vendor_type = undefined;
                            visitorInfo.company_name = undefined;
                            visitorInfo.relation_type = undefined;                 
                            visitorInfo.room_no = visObj.room_no;                    
                            visitorInfo.bed_no = visObj.bed_no;
                            visitorInfo.visitedTo = visObj.visitedTo;                            
                            break;
                        case 'hcp':
                            visitorInfo.vendor_type = undefined;
                            visitorInfo.company_name = undefined;
                            visitorInfo.relation_type = undefined;                  
                            visitorInfo.room_no = visObj.room_no;                    
                            visitorInfo.bed_no = visObj.bed_no;
                            visitorInfo.visitedTo = visObj.visitedTo;                            
                            break;
                        case 'guardian':
                            visitorInfo.vendor_type = undefined;
                            visitorInfo.company_name = undefined;
                            visitorInfo.relation_type = undefined;          
                            visitorInfo.room_no = visObj.room_no;                    
                            visitorInfo.bed_no = visObj.bed_no;
                            visitorInfo.visitedTo = visObj.visitedTo;                            
                            break;
                        case 'attorney':
                            visitorInfo.vendor_type = undefined;
                            visitorInfo.company_name = undefined;
                            visitorInfo.relation_type = undefined;              
                            visitorInfo.room_no = visObj.room_no;                    
                            visitorInfo.bed_no = visObj.bed_no;
                            visitorInfo.visitedTo = visObj.visitedTo;                            
                            break;
                        case 'guest_tour':
                            visitorInfo.vendor_type = undefined;
                            visitorInfo.company_name = undefined;
                            visitorInfo.relation_type = undefined;
                            visitorInfo.room_no = undefined;
                            visitorInfo.bed_no = undefined;
                            visitorInfo.visitedTo = undefined;
                            break;
                        case 'vendor':
                            visitorInfo.relation_type = undefined;
                            visitorInfo.room_no = undefined;
                            visitorInfo.bed_no = undefined;
                            visitorInfo.visitedTo = undefined;
                            visitorInfo.vendor_type = visObj.vendor_type;                    
                            visitorInfo.company_name = visObj.company_name; 
                            break;
                    }
                                        
                    visitorInfo.modifiedBy = req.user.role;
                    visitorInfo.modifiedById = req.user.uid;

                    visitorInfo.save(function (err, updatedVisitorData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    })
                }
            })
        }

    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("VISITOR_INFO_UPDATE_SUCCESSFULLY")
            });
        }
    });
}
/**
 * Function is use to get Check In Log By VisitorId
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-May-2018
 */
function getCheckInLogByVisitorId(req, res) {
    var finalResponse = {};
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);

    waterfall([
        function (callback) { //CheckInOut Data

            var condition = {};
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
            condition.isDelete = false;
            if (mongoose.Types.ObjectId.isValid(req.body._id)) {
                condition.visitorId = mongoose.Types.ObjectId(req.body._id);
                var aggregate = [{
                    $lookup: {
                        from: 'visitors',
                        localField: "visitorId",
                        foreignField: "_id",
                        as: "visitorInfo"
                    }
                },
                {
                    $unwind: "$visitorInfo"
                },
                {
                    $match: condition
                },
                ];
                var project = {
                    $project: {
                        "checkInDate": "$checkInDate",
                        "checkOutDate": "$checkOutDate",
                        "visitedTo": "$visitedTo",
                        "status": "$status",
                        "rating": "$rating",
                        "createdAt": "$createdAt"
                    }
                };
                aggregate.push(project);
                var countQuery = [].concat(aggregate);
                aggregate.push({
                    $sort: { createdAt: -1 }
                });
                aggregate.push({
                    $skip: parseInt(skip)
                });
                aggregate.push({
                    $limit: parseInt(count)
                });
                CheckInOut.aggregate(aggregate).then(function (visitorData) {
                    var data = {};
                    data.data = visitorData;
                    countQuery.push({
                        $group: {
                            _id: null,
                            count: {
                                $sum: 1
                            }
                        }
                    });
                    CheckInOut.aggregate(countQuery).then(function (dataCount) {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        data.total_count = cnt;
                        callback(null, data);
                    });
                }).catch(function (err) {
                    callback(err, false);
                });
            }

        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get Visitor Messages
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-May-2018
 */
function getVisitorMessages(req, res) {
    var finalResponse = {};
    var start_day_date, end_day_date, momentObjFrom, momentObjTo;
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);

    waterfall([
        function (callback) { //CheckInOut Data
            var condition = {};
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
            condition.isDelete = false;
            condition.CommentDone = true;
            condition.rating = {
                $ne: 0
            };
            var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            if (searchText != undefined && searchText != 'undefined') {
                condition.$or = [{
                    'visitorInfo.firstName': new RegExp(searchText, 'gi')
                },
                {
                    'visitorInfo.lastName': new RegExp(searchText, 'gi')
                },
                {
                    'visitorInfo.phoneNumber': new RegExp(searchText, 'gi')
                },
                {
                    'rating': new RegExp(searchText, 'gi')
                },
                {
                    'visitorInfo.visitorName': new RegExp(searchText, 'gi')
                },
                ];
            }

            if (req.body.CommentDate) {
                start_day_date = moment(req.body.CommentDate).startOf('day');
                end_day_date = moment(req.body.CommentDate).endOf('day');
                momentObjFrom = new Date(moment(start_day_date));
                momentObjTo = new Date(moment(end_day_date));
                condition.$and = [{
                    CommentDate: {
                        $gte: momentObjFrom
                    }
                },
                {
                    CommentDate: {
                        $lte: momentObjTo
                    }
                }
                ];
            }

            if (req.body.firstName) {
                condition['visitorInfo.firstName'] = new RegExp(req.body.firstName, 'gi');
            }
            if (req.body.lastName) {
                condition['visitorInfo.lastName'] = new RegExp(req.body.lastName, 'gi');
            }
            if (req.body.phoneNumber) {
                condition['visitorInfo.phoneNumber'] = new RegExp(req.body.phoneNumber, 'gi');
            }
            if (req.body.rating) {
                condition['rating'] = new RegExp(req.body.rating, 'gi');
            }
            var aggregate = [{
                $lookup: {
                    from: 'visitors',
                    localField: "visitorId",
                    foreignField: "_id",
                    as: "visitorInfo"
                }
            },
            {
                $unwind: "$visitorInfo"
            },
            {
                $match: condition
            },
            ];
            var project = {
                $project: {
                    "firstName": "$visitorInfo.firstName",
                    "lastName": "$visitorInfo.lastName",
                    "phoneNumber": "$visitorInfo.phoneNumber",
                    "CommentDate": "$CommentDate",
                    "rating": "$rating",
                    "comments": "$comments",
                    "visitorName": "$visitorInfo.visitorName"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            aggregate.push({
                $sort: sorting
            });
            aggregate.push({
                $skip: parseInt(skip)
            });
            aggregate.push({
                $limit: parseInt(count)
            });
            CheckInOut.aggregate(aggregate).then(function (messageData) {
                var data = {};
                data.data = messageData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                CheckInOut.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    data.total_count = cnt;
                    callback(null, data);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to track the facility google link is viewed 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-May-2018
 */
function trackVisitorViewedLink(req, res) {
    var finalResponse = {};
    finalResponse.trackingData = {};
    finalResponse.updatedViewedLinkData = {};
    finalResponse.foundFacilityData = {};
    finalResponse.foundUserFacilityData = {};
    waterfall([
        function (callback) { //Verify token key is valid 
            CheckInOut.findOne({
                trackingToken: req.body.trackingToken
            }).exec(function (err, trackingData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (!trackingData) {
                        res.json({
                            code: config.statusCode.invalid,
                            data: {},
                            message: i18n.__("INVALID_URL")
                        });
                    } else {
                        finalResponse.trackingData = trackingData;
                        callback(null, finalResponse);
                    }
                }
            })
        },
        function (finalResponse, callback) { //Verify User  
            if (finalResponse.trackingData.isDelete == true || finalResponse.trackingData.status == '1') {
                res.json({
                    code: config.statusCode.serviceUnavailable,
                    data: {},
                    message: i18n.__("LINK_EXPIRED")
                });
            } else {
                callback(null, finalResponse);
            }
        },
        function (finalResponse, callback) { //Check facility is Active
            UserFacility.findOne({
                _id: mongoose.Types.ObjectId(finalResponse.trackingData.userFacilityId),
                isDelete: false,
                status: '1'
            }).exec(function (err, foundUserFacilityData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (!foundUserFacilityData) {
                        res.json({
                            code: config.statusCode.serviceUnavailable,
                            data: {},
                            message: i18n.__("LINK_EXPIRED")
                        });
                    } else {
                        finalResponse.foundUserFacilityData = foundUserFacilityData;
                        callback(null, finalResponse);
                    }
                }
            })
        },
        function (finalResponse, callback) { //Get routing facility Google link
            Facility.findOne({
                _id: mongoose.Types.ObjectId(finalResponse.foundUserFacilityData.facilityId),
                isDelete: false,
                status: '1'
            }).exec(function (err, foundFacilityData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (!foundFacilityData) {
                        res.json({
                            code: config.statusCode.serviceUnavailable,
                            data: {},
                            message: i18n.__("LINK_EXPIRED")
                        });
                    } else {
                        finalResponse.foundFacilityData = foundFacilityData;
                        callback(null, finalResponse);
                    }
                }
            })
        },
        function (finalResponse, callback) {
            CheckInOut.findOneAndUpdate({
                trackingToken: req.body.trackingToken
            }, {
                    $set: {
                        viewedLink: true,
                        viewedLinkDate: moment()
                    }
                }, function (err, updatedViewedLinkData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.updatedViewedLinkData = updatedViewedLinkData;
                        callback(null, finalResponse);
                    }
                });
        },
        function (finalResponse, callback) {
            var trackObj = {
                userFacId: finalResponse.foundUserFacilityData._id,
                visitorId: mongoose.Types.ObjectId(finalResponse.updatedViewedLinkData.visitorId),
                trackingLink: finalResponse.updatedViewedLinkData.trackingLink,
                routingLink: finalResponse.foundFacilityData.googleLink
            }
            var trackingViewedLink = new TrackingViewedLink(trackObj)
            trackingViewedLink.save(function (err, trackingLinkData) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data.foundFacilityData.googleLink,
                message: i18n.__("TRACKED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get click trackers counts
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-May-2018
 */
function getClickTrackerCounts(req, res) {
    var finalResponse = {};
    var todayDate = req.body.todayDate;
    finalResponse.googleLink = '';
    finalResponse.todayClicks = 0;
    finalResponse.lastSevenDaysClicks = 0;
    finalResponse.lastOneMonthClicks = 0;
    var condition = {
        userFacId: mongoose.Types.ObjectId(req.user.userFacId),
        status: true,
        isDelete: false
    }
    waterfall([
        function (callback) { //Get facility Google link 
            var facObj = {
                _id: mongoose.Types.ObjectId(req.user.facId),
                status: '1',
                isDelete: false
            }
            Facility.findOne(facObj).exec(function (err, facilityData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (!facilityData) {
                        res.json({
                            code: config.statusCode.notFound,
                            data: {},
                            message: i18n.__("UNAUTHORIZED")
                        });
                    } else {
                        finalResponse.googleLink = facilityData.googleLink;
                        callback(null, finalResponse);
                    }
                }
            })
        },
        function (finalResponse, callback) { //Get today Click counts  
            var start_day_date = moment(todayDate).startOf('day');
            var end_day_date = moment(todayDate).endOf('day');
            var momentObjFrom = new Date(moment(start_day_date));
            var momentObjTo = new Date(moment(end_day_date));
            condition.routingLink = finalResponse.googleLink;
            condition.$and = [{
                createdAt: {
                    $gte: momentObjFrom
                }
            },
            {
                createdAt: {
                    $lte: momentObjTo
                }
            }
            ];
            TrackingViewedLink.find(condition).count().exec(function (err, todayCount) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.todayClicks = todayCount;
                    callback(null, finalResponse);
                }
            })
        },
        function (finalResponse, callback) { //Get last 7 days click counts  
            var start_day_date = moment(req.body.todayDate).endOf('day').add(-7, 'days');
            var end_day_date = moment(req.body.todayDate).endOf('day');
            var momentObjFrom = new Date(moment(start_day_date));
            var momentObjTo = new Date(moment(end_day_date));
            condition.routingLink = finalResponse.googleLink;
            condition.$and = [{
                createdAt: {
                    $gte: momentObjFrom
                }
            },
            {
                createdAt: {
                    $lte: momentObjTo
                }
            }];
            TrackingViewedLink.find(condition).count().exec(function (err, lastSevenDaysCount) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.lastSevenDaysClicks = lastSevenDaysCount;
                    callback(null, finalResponse);
                }
            })
        },
        function (finalResponse, callback) { //Get last 30 days click counts  
            var start_day_date = moment(req.body.todayDate).endOf('day').add(-30, 'days');;
            var end_day_date = moment(req.body.todayDate).endOf('day');
            var momentObjFrom = new Date(moment(start_day_date));
            var momentObjTo = new Date(moment(end_day_date));
            condition.routingLink = finalResponse.googleLink;
            condition.$and = [{
                createdAt: {
                    $gte: momentObjFrom
                }
            },
            {
                createdAt: {
                    $lte: momentObjTo
                }
            }
            ];
            TrackingViewedLink.find(condition).count().exec(function (err, lastOneMonthCount) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.lastOneMonthClicks = lastOneMonthCount;
                    callback(null, finalResponse);
                }
            })
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            // console.log("data@@@click count", data);
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("TRACKED_SUCCESSFULLY")
            });
        }
    });

}


/**
 * Function is use to get All Message Count for dashboard
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 28-May-2018
 */


function getAllMessageCount(req, res) {
    var finalResponse = {};
    finalResponse.sevenDaysVisitors = {};
    finalResponse.thirtyDaysVisitors = {};
    finalResponse.today = {};
    finalResponse.yesterday = {};

    waterfall([
        function (callback) { //get facility 
            Facility.findOne({
                _id: mongoose.Types.ObjectId(req.user.facId),
                isDelete: false,
                status: '1'
            }).exec(function (err, foundFacilityData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (!foundFacilityData) {
                        res.json({
                            code: config.statusCode.unauthorized,
                            data: {},
                            message: i18n.__("UNAUTHORIZED")
                        });
                    } else {
                        finalResponse.foundFacilityData = foundFacilityData;
                        callback(null, finalResponse);
                    }
                }
            })
        },
        function (finalResponse, callback) { //get sms thirty days list
            var condition = {};
            condition.isDelete = false,
                condition.status = true,
                condition.from = {
                    $ne: finalResponse.foundFacilityData.twilioTollFreeNumber
                },
                condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId)
            if (req.body.createdAt) {
                var today_date = moment().endOf('day');
                var thirty_day_back_date = moment().endOf('day').add(-30, 'days');
                var momentObjFrom = new Date(moment(thirty_day_back_date));
                var momentObjTo = new Date(moment(today_date));
                condition.$and = [{
                    createdAt: {
                        $gte: momentObjFrom
                    }
                },
                {
                    createdAt: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            SmsHistory.find(condition).count().exec(function (err, thirtyDaysmsCount) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.thirtyDaysmsCount = thirtyDaysmsCount;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get sms 7 days list
            var condition = {};
            condition.isDelete = false,
                condition.status = true,
                condition.from = {
                    $ne: finalResponse.foundFacilityData.twilioTollFreeNumber
                },
                condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId)
            if (req.body.createdAt) {
                var today_date = moment().endOf('day');
                var seven_day_back_date = moment().endOf('day').add(-7, 'days');
                var momentObjFrom = new Date(moment(seven_day_back_date));
                var momentObjTo = new Date(moment(today_date));
                condition.$and = [{
                    createdAt: {
                        $gte: momentObjFrom
                    }
                },
                {
                    createdAt: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            SmsHistory.find(condition).count().exec(function (err, sevenDaysVisitors) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.sevenDaysVisitors = sevenDaysVisitors;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get sms yesterday list
            var condition = {};
            condition.isDelete = false,
                condition.status = true,
                condition.from = {
                    $ne: finalResponse.foundFacilityData.twilioTollFreeNumber
                },
                condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId)
            if (req.body.createdAt) {
                var today_date = moment().endOf('day');
                var yesterday_day_back_date = moment().endOf('day').add(-1, 'days');
                var momentObjFrom = new Date(moment(yesterday_day_back_date));
                var momentObjTo = new Date(moment(today_date));
                condition.$and = [{
                    createdAt: {
                        $gte: momentObjFrom
                    }
                },
                {
                    createdAt: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            SmsHistory.find(condition).count().exec(function (err, yesterday) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.yesterday = yesterday;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get sms today list
            var condition = {};
            condition.isDelete = false,
                condition.status = true,
                condition.from = {
                    $ne: finalResponse.foundFacilityData.twilioTollFreeNumber
                },
                condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId)
            if (req.body.createdAt) {
                var start_day_date = moment(req.body.createdAt).startOf('day');
                var end_day_date = moment(req.body.createdAt).endOf('day');
                var momentObjFrom = new Date(moment(start_day_date));
                var momentObjTo = new Date(moment(end_day_date));
                condition.$and = [{
                    createdAt: {
                        $gte: momentObjFrom
                    }
                },
                {
                    createdAt: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            SmsHistory.find(condition).count().exec(function (err, today) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.today = today;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get visitors total sms list
            var condition = {};
            condition.isDelete = false,
                condition.status = true,
                condition.from = {
                    $ne: finalResponse.foundFacilityData.twilioTollFreeNumber
                },
                condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId)
            SmsHistory.find(condition).count().exec(function (err, totalSms) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.totalSms = totalSms;
                    callback(null, finalResponse);

                }
            });
        }
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get All Rating Response Count
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 18-May-2018
 */
function getAllResponseRate(req, res) {
    var finalResponse = {};
    finalResponse.thirtyDaysResponseRate = 0;
    finalResponse.sevenDaysResponseRate = 0;
    finalResponse.yesterdayDaysResponseRate = 0;
    finalResponse.todaysResponseRate = 0;
    finalResponse.overAllResponseRate = 0;
    finalResponse.ratingDataOverAll = 0;
    finalResponse.checkOutdataOverAll = 0
    waterfall([
        function (callback) { //get response rate for thirtydays 
            var condition = {};
            condition.isDelete = false,
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId),
            condition.ratingDone = true
            if (req.body.ratingDate) {
                var today_date = moment().endOf('day');
                var thirty_day_back_date = moment().endOf('day').add(-30, 'days');
                var momentObjFrom = new Date(moment(thirty_day_back_date));
                var momentObjTo = new Date(moment(today_date));
                condition.$and = [{
                    ratingDate: {
                        $gte: momentObjFrom
                    }
                },
                {
                    ratingDate: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            CheckInOut.find(condition).count().exec(function (err, ratingDataThirtyDays) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.ratingDataThirtyDays = ratingDataThirtyDays;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get response rate for thirtydays 
            var condition = {};
            condition.isDelete = false,
            condition.status = '0',
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId)
            if (req.body.ratingDate) {
                var today_date = moment().endOf('day');
                var thirty_day_back_date = moment().endOf('day').add(-30, 'days');
                var momentObjFrom = new Date(moment(thirty_day_back_date));
                var momentObjTo = new Date(moment(today_date));
                condition.$and = [{
                    checkOutDate: {
                        $gte: momentObjFrom
                    }
                },
                {
                    checkOutDate: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            CheckInOut.find(condition).count().exec(function (err, checkOutdataThirtyDate) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.checkOutdataThirtyDate = checkOutdataThirtyDate;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get visitors yesterday list
            var condition = {};
            condition.isDelete = false,
                condition.ratingDone = true,
                condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId)
            if (req.body.ratingDate) {
                var today_date = moment().endOf('day');
                var yesterday_day_back_date = moment().endOf('day').add(-7, 'days');
                var momentObjFrom = new Date(moment(yesterday_day_back_date));
                var momentObjTo = new Date(moment(today_date));
                condition.$and = [{
                    ratingDate: {
                        $gte: momentObjFrom
                    }
                },
                {
                    ratingDate: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            CheckInOut.find(condition).count().exec(function (err, ratingDataSevenDays) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.ratingDataSevenDays = ratingDataSevenDays;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get visitors yesterday list
            var condition = {};
            condition.isDelete = false,
                condition.status = '0',
                condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId)
            if (req.body.ratingDate) {
                var today_date = moment().endOf('day');
                var yesterday_day_back_date = moment().endOf('day').add(-7, 'days');
                var momentObjFrom = new Date(moment(yesterday_day_back_date));
                var momentObjTo = new Date(moment(today_date));
                condition.$and = [{
                    checkOutDate: {
                        $gte: momentObjFrom
                    }
                },
                {
                    checkOutDate: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            CheckInOut.find(condition).count().exec(function (err, checkOutdataSevenDays) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.checkOutdataSevenDays = checkOutdataSevenDays;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get visitors yesterday list
            var condition = {};
            condition.isDelete = false,
                condition.ratingDone = true,
                condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId)
            if (req.body.ratingDate) {
                var today_date = moment().endOf('day');
                var yesterday_day_back_date = moment().endOf('day').add(-1, 'days');
                var momentObjFrom = new Date(moment(yesterday_day_back_date));
                var momentObjTo = new Date(moment(today_date));
                condition.$and = [{
                    ratingDate: {
                        $gte: momentObjFrom
                    }
                },
                {
                    ratingDate: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            CheckInOut.find(condition).count().exec(function (err, ratingDataYesterday) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.ratingDataYesterday = ratingDataYesterday;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get visitors yesterday list
            var condition = {};
            condition.isDelete = false,
                condition.status = '0',
                condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId)
            if (req.body.ratingDate) {
                var today_date = moment().endOf('day');
                var yesterday_day_back_date = moment().endOf('day').add(-1, 'days');
                var momentObjFrom = new Date(moment(yesterday_day_back_date));
                var momentObjTo = new Date(moment(today_date));
                condition.$and = [{
                    checkOutDate: {
                        $gte: momentObjFrom
                    }
                },
                {
                    checkOutDate: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            CheckInOut.find(condition).count().exec(function (err, checkOutdataYesterday) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.checkOutdataYesterday = checkOutdataYesterday;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get visitors today list
            var condition = {};
            condition.isDelete = false,
                condition.ratingDone = true,
                condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId)
            if (req.body.ratingDate) {
                var start_day_date = moment(req.body.ratingDate).startOf('day');
                var end_day_date = moment(req.body.ratingDate).endOf('day');
                var momentObjFrom = new Date(moment(start_day_date));
                var momentObjTo = new Date(moment(end_day_date));
                condition.$and = [{
                    ratingDate: {
                        $gte: momentObjFrom
                    }
                },
                {
                    ratingDate: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            CheckInOut.find(condition).count().exec(function (err, ratingDataToday) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.ratingDataToday = ratingDataToday;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get visitors today list
            var condition = {};
            condition.isDelete = false,
                condition.status = '0',
                condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId)
            if (req.body.ratingDate) {
                var start_day_date = moment(req.body.ratingDate).startOf('day');
                var end_day_date = moment(req.body.ratingDate).endOf('day');
                var momentObjFrom = new Date(moment(start_day_date));
                var momentObjTo = new Date(moment(end_day_date));
                condition.$and = [{
                    checkOutDate: {
                        $gte: momentObjFrom
                    }
                },
                {
                    checkOutDate: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            CheckInOut.find(condition).count().exec(function (err, checkOutdataToday) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.checkOutdataToday = checkOutdataToday;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get overall rate 
            var condition = {};
            condition.isDelete = false,
                condition.ratingDone = true,
                condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId)
            CheckInOut.find(condition).count().exec(function (err, ratingDataOverAll) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.ratingDataOverAll = ratingDataOverAll;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get overall  list
            var condition = {};
            condition.isDelete = false,
                condition.status = '0',
                condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId)
            CheckInOut.find(condition).count().exec(function (err, checkOutdataOverAll) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.checkOutdataOverAll = checkOutdataOverAll;
                    callback(null, finalResponse);

                }
            });
        },
        function (finalResponse, callback) { //get visitors total list
            finalResponse.thirtyDaysResponseRate = parseInt((finalResponse.ratingDataThirtyDays / finalResponse.checkOutdataThirtyDate) * 100);
            finalResponse.sevenDaysResponseRate = parseInt((finalResponse.ratingDataSevenDays / finalResponse.checkOutdataSevenDays) * 100);
            finalResponse.yesterdayDaysResponseRate = parseInt((finalResponse.ratingDataYesterday / finalResponse.checkOutdataYesterday) * 100);
            finalResponse.todaysResponseRate = parseInt((finalResponse.ratingDataToday / finalResponse.checkOutdataToday) * 100);
            finalResponse.overAllResponseRate = parseInt((finalResponse.ratingDataOverAll / finalResponse.checkOutdataOverAll) * 100);
            callback(null, finalResponse);
        }
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to Get visited/engaged/sent feedback count of list Visitors
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 29-May-2018
 */
function getListVistorsHeadersCount(req, res) {
    var finalResponse = {};
    var todayDate = req.body.todayDate;
    finalResponse.visitedInLastThirtyDays = 0;
    finalResponse.engagedPercentage = 0;
    finalResponse.sendFeedbackTotalCount = 0;

    var today_date = moment(todayDate).endOf('day');
    var thirty_day_back_date = moment().endOf('day').add(-30, 'days');
    var momentObjFrom = new Date(moment(thirty_day_back_date));
    var momentObjTo = new Date(moment(today_date));
    waterfall([
        function (callback) { //get visited count of visitors in last thirty days  
            var condition = {};
            condition.isDelete = false;
            condition['visitorsInfo.isDelete'] = false;
            condition['visitorsInfo.visitor_type'] = {
                $ne: 'expressResident'
            }


            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
            if (req.body.selectType != '0') {
                condition.$and = [{
                    createdAt: {
                        $gte: momentObjFrom
                    }
                },
                {
                    createdAt: {
                        $lte: momentObjTo
                    }
                }
                ];
            }
            var aggregate = [{
                $lookup: {
                    from: 'visitors',
                    localField: "visitorId",
                    foreignField: "_id",
                    as: "visitorsInfo"
                }
            },
            {
                $unwind: "$visitorsInfo"
            },
            {
                $match: condition
            },
            ];
            var group = {
                $group: {
                    _id: "$visitorsInfo._id"
                }
            };
            aggregate.push(group);
            var countQuery = [].concat(aggregate);
            countQuery.push({
                $group: {
                    _id: null,
                    count: {
                        $sum: 1
                    }
                }
            });
            CheckInOut.aggregate(countQuery).then(function (dataCount) {
                var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                finalResponse.visitedInLastThirtyDays = cnt;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //get engaged % of visitors in last thirty days 

            var condition = {
                isDelete: false,
                userFacilityId: mongoose.Types.ObjectId(req.user.userFacId),
                visitor_type: {
                    $ne: 'expressResident'
                }
            };

            Visitor.find(condition).distinct('phoneNumber').exec(function (err, visitorsPhoneArray) {
                if (err) {
                    callback(err, false);
                } else {
                    if (!visitorsPhoneArray) {
                        res.json({
                            code: config.statusCode.notFound,
                            data: {},
                            message: i18n.__("UNAUTHORIZED")
                        });
                    } else {
                        finalResponse.visitorsPhoneArray = visitorsPhoneArray
                        callback(null, finalResponse);
                    }
                }
            })
        },
        function (finalResponse, callback) {
            var condition = {};
            condition.isDelete = false;
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
            condition.from = {
                $in: finalResponse.visitorsPhoneArray
            };
            condition.$and = [{
                createdAt: {
                    $gte: momentObjFrom
                }
            },
            {
                createdAt: {
                    $lte: momentObjTo
                }
            }
            ];
            SmsHistory.find(condition).distinct('from').exec(function (err, smsHistoryData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.smsResponseLastThirtyDays = smsHistoryData;
                    finalResponse.engagedPercentage = parseInt(((finalResponse.smsResponseLastThirtyDays.length) / (finalResponse.visitorsPhoneArray.length)) * 100);
                    callback(null, finalResponse);
                }
            })
        },
        function (finalResponse, callback) { //get send feedback counts of visitors
            var condition = {};
            condition.isDelete = false;
            condition['visitorsInfo.isDelete'] = false;
            condition.ratingDone = true;
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
            condition.$and = [{
                createdAt: {
                    $gte: momentObjFrom
                }
            },
            {
                createdAt: {
                    $lte: momentObjTo
                }
            }
            ];
            var aggregate = [{
                $lookup: {
                    from: 'visitors',
                    localField: "visitorId",
                    foreignField: "_id",
                    as: "visitorsInfo"
                }
            },
            {
                $unwind: "$visitorsInfo"
            },
            {
                $match: condition
            },
            ];
            var group = {
                $group: {
                    _id: "$visitorsInfo._id"
                }
            };
            aggregate.push(group);
            var countQuery = [].concat(aggregate);
            countQuery.push({
                $group: {
                    _id: null,
                    count: {
                        $sum: 1
                    }
                }
            });
            CheckInOut.aggregate(countQuery).then(function (dataCount) {
                var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                finalResponse.sendFeedbackTotalCount = cnt;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {

            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to Get visited/engaged/sent feedback count of check in log Visitors
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 29-May-2018
 */
function getCheckInLogHeaderCounts(req, res) {
    var finalResponse = {};
    var start_day_date = {};
    var end_day_date = {};
    var momentObjFrom = {};
    var momentObjTo = {};
    var todayDate = req.body.todayDate;
    finalResponse.visitedInLastThirtyDays = 0;
    finalResponse.engagedPercentage = 0;
    finalResponse.sendFeedbackTotalCount = 0;
    switch (req.body.selectType) {
        case '1':
            start_day_date = moment(todayDate).startOf('day');
            end_day_date = moment(todayDate).endOf('day');
            momentObjFrom = new Date(moment(start_day_date));
            momentObjTo = new Date(moment(end_day_date));
            break;
        case '2':
            start_day_date = moment(todayDate).endOf('day');
            end_day_date = moment(todayDate).endOf('day').add(-7, 'days');
            momentObjFrom = new Date(moment(end_day_date));
            momentObjTo = new Date(moment(start_day_date));
            break;
        case '3':
            start_day_date = moment(todayDate).endOf('day');
            end_day_date = moment(todayDate).endOf('day').add(-6, 'months');
            momentObjFrom = new Date(moment(end_day_date));
            momentObjTo = new Date(moment(start_day_date));
            break;
        case '4':
            start_day_date = moment(todayDate).endOf('day');
            end_day_date = moment(todayDate).endOf('day').add(-1, 'years');
            momentObjFrom = new Date(moment(end_day_date));
            momentObjTo = new Date(moment(start_day_date));
            break;
    }

    waterfall([
        function (callback) { //get visited count of visitors in specific period  
            var condition = {};
            condition.isDelete = false;
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
            if (req.body.selectType != '0') {
                condition.$and = [{
                    createdAt: {
                        $gte: momentObjFrom
                    }
                },
                {
                    createdAt: {
                        $lte: momentObjTo
                    }
                }
                ];
            }
            var aggregate = [{
                $match: condition
            },];
            var countQuery = [].concat(aggregate);
            countQuery.push({
                $group: {
                    _id: null,
                    count: {
                        $sum: 1
                    }
                }
            });
            CheckInOut.aggregate(countQuery).then(function (dataCount) {
                var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                finalResponse.visitedInLastThirtyDays = cnt;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //get engaged % of visitors in specific period 
            var condition = {
                isDelete: false,
                userFacilityId: mongoose.Types.ObjectId(req.user.userFacId)
            };

            Visitor.find(condition).distinct('phoneNumber').exec(function (err, visitorsPhoneArray) {
                if (err) {
                    callback(err, false);
                } else {
                    if (!visitorsPhoneArray) {
                        res.json({
                            code: config.statusCode.notFound,
                            data: {},
                            message: i18n.__("UNAUTHORIZED")
                        });
                    } else {
                        finalResponse.visitorsPhoneArray = visitorsPhoneArray
                        callback(null, finalResponse);
                    }
                }
            })
        },
        function (finalResponse, callback) {
            var condition = {};
            condition.isDelete = false;
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
            condition.from = {
                $in: finalResponse.visitorsPhoneArray
            };
            if (req.body.selectType != '0') {
                condition.$and = [{
                    createdAt: {
                        $gte: momentObjFrom
                    }
                },
                {
                    createdAt: {
                        $lte: momentObjTo
                    }
                }
                ];
            }
            SmsHistory.find(condition).distinct('from').exec(function (err, smsHistoryData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.smsResponseLastThirtyDays = smsHistoryData;
                    finalResponse.engagedPercentage = parseInt(((finalResponse.smsResponseLastThirtyDays.length) / (finalResponse.visitorsPhoneArray.length)) * 100);
                    callback(null, finalResponse);
                }
            })
        },
        function (finalResponse, callback) { //get send feedback counts of visitors in specific period
            var condition = {};
            condition.isDelete = false;
            condition['visitorsInfo.isDelete'] = false;
            condition.ratingDone = true;
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
            if (req.body.selectType != '0') {
                condition.$and = [{
                    createdAt: {
                        $gte: momentObjFrom
                    }
                },
                {
                    createdAt: {
                        $lte: momentObjTo
                    }
                }
                ];
            }
            var aggregate = [{
                $lookup: {
                    from: 'visitors',
                    localField: "visitorId",
                    foreignField: "_id",
                    as: "visitorsInfo"
                }
            },
            {
                $unwind: "$visitorsInfo"
            },
            {
                $match: condition
            },
            ];
            var group = {
                $group: {
                    _id: "$visitorsInfo._id"
                }
            };
            aggregate.push(group);
            var countQuery = [].concat(aggregate);
            countQuery.push({
                $group: {
                    _id: null,
                    count: {
                        $sum: 1
                    }
                }
            });
            CheckInOut.aggregate(countQuery).then(function (dataCount) {
                var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                finalResponse.sendFeedbackTotalCount = cnt;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {

            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to Get rated visitors/average/negative ratings  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 29-May-2018
 */
function getVisitorMessageHeadersCount(req, res) {
    var finalResponse = {};
    finalResponse.avgPositiveRate = 0;
    finalResponse.avgNegativeRate = 0;
    finalResponse.visitorRatingCount = 0;

    waterfall([
        function (callback) { //get visited count of visitors in specific period  
            var condition = {};
            condition.isDelete = false;
            condition['visitorsInfo.isDelete'] = false;
            condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
            condition.ratingDone = true;
            var aggregate = [{
                $lookup: {
                    from: 'visitors',
                    localField: "visitorId",
                    foreignField: "_id",
                    as: "visitorsInfo"
                }
            },
            {
                $unwind: "$visitorsInfo"
            },
            {
                $match: condition
            },
            ];
            var group = {
                $group: {
                    _id: "$visitorsInfo._id"
                }
            };
            aggregate.push(group);
            var countQuery = [].concat(aggregate);
            countQuery.push({
                $group: {
                    _id: null,
                    count: {
                        $sum: 1
                    }
                }
            });
            CheckInOut.aggregate(countQuery).then(function (dataCount) {
                var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                finalResponse.visitorRatingCount = cnt;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //get average positive ratings 
            var condition = {
                isDelete: false,
                ratingStatus: 'positive',
                userFacilityId: mongoose.Types.ObjectId(req.user.userFacId)
            };

            CheckInOut.aggregate([{
                $match: condition
            }, {
                "$group": {
                    "_id": "$userFacilityId",
                    "avgRating": {
                        "$avg": {
                            "$ifNull": ["$rating", 0]
                        }
                    }
                }
            }], function (err, rating) {
                if (rating[0]) {
                    if (rating[0].avgRating) {
                        finalResponse.avgPositiveRate = rating[0].avgRating.toFixed(1);
                        callback(null, finalResponse);
                    }
                }
            })
        },
        function (finalResponse, callback) { //get average negative ratings
            var condition = {
                isDelete: false,
                ratingStatus: 'negative',
                userFacilityId: mongoose.Types.ObjectId(req.user.userFacId)
            };

            CheckInOut.aggregate([{
                $match: condition
            }, {
                "$group": {
                    "_id": '$userFacilityId',
                    "avgRating": {
                        "$avg": {
                            "$ifNull": ["$rating", 0]
                        }
                    }
                }
            }], function (err, rating) {
                if (rating[0]) {
                    if (rating[0].avgRating) {
                        finalResponse.avgNegativeRate = rating[0].avgRating.toFixed(1);
                        callback(null, finalResponse);
                    }
                }
            })
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {

            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to save Notification Details
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 30-May-2018
 */
function saveNotification(req, res) {
    var finalResponse = {};
    var notificationObj = {
        userFacId: req.body.checkInData.userFacilityId,
        visitorId: req.body.checkInData.visitorId
    }

    if (!notificationObj.userFacId || !notificationObj.visitorId) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } {
        waterfall([
            function (callback) { // save notification details
                var notificationInfo = {};
                notificationInfo.userFacId = notificationObj.userFacId,
                    notificationInfo.visitorId = notificationObj.visitorId,
                    notificationInfo.notificationType = 'checkIn';
                var notificationHistoryInfo = new NotificationHistory(notificationInfo);
                notificationHistoryInfo.save(function (err, notificationHistoryData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            }

        ], function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: data
                });
            }
        });
    }
}


/**
 * Function is use to get Notification Details
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 30-May-2018
 */


function getNotificationDetails(req, res) {
    var finalResponse = {};
    finalResponse.notificationCount = 0;
    finalResponse.notificationDetails = {};
    waterfall([
        function (callback) { //get notification Count
            var condition = {
                isDelete: false,
                isView: false,
                userFacId: mongoose.Types.ObjectId(req.user.userFacId)
            };
            NotificationHistory.find(condition).count().exec(function (err, notificationCount) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.notificationCount = notificationCount;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //get notification Details
            var condition = {};
            condition.isDelete = false,
                condition.isView = false,

                condition.userFacId = mongoose.Types.ObjectId(req.user.userFacId),
                NotificationHistory.find(condition).sort({
                    createdAt: -1
                }).populate('visitorId').exec(function (err, notificationDetails) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.notificationDetails = notificationDetails;
                        callback(null, finalResponse);

                    }
                });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}


/**
 * Function is use to notification Viewed
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 30-May-2018
 */
function notificationViewed(req, res) {
    var finalResponse = {};
    var notifyObj = {
        userFacId: mongoose.Types.ObjectId(req.user.userFacId),
        _id: req.body.notificationId,
        isDelete: false
    }
    waterfall([
        function (callback) { // update notification viewed
            NotificationHistory.findOneAndUpdate(notifyObj, {
                $set: {
                    isView: true,
                }
            }, function (err, updatedVisitorData) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        }

    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data
            });
        }
    });
}

/**
 * Function is get visitor twilio sms chat
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 2-June-2018
 */
function getVisitorTwilioChat(req, res) {
    var finalResponse = {};
    finalResponse.visitorData = {};
    finalResponse.smsHistoryData = {};
    if (mongoose.Types.ObjectId.isValid(req.query.id)) {
        waterfall([
            function (callback) { // get visitor info
                var condition = {};
                condition._id = mongoose.Types.ObjectId(req.query.id);
                condition.userFacilityId = mongoose.Types.ObjectId(req.user.userFacId);
                condition.isDelete = false;
                Visitor.findOne(condition).exec(function (err, visitorData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.visitorData = visitorData;

                        callback(null, finalResponse);
                    }
                });
            },
            function (finalResponse, callback) { //get visitor sms
                var condition = {
                    isDelete: false,
                    userFacilityId: mongoose.Types.ObjectId(req.user.userFacId),
                    $and: [{
                        $or: [{
                            to: finalResponse.visitorData.phoneNumber
                        },
                        {
                            from: finalResponse.visitorData.phoneNumber
                        }
                        ]
                    }]
                };
                SmsHistory.find(condition).sort({
                    createdAt: 1
                }).exec(function (err, smsHistoryData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.smsHistoryData = smsHistoryData;
                        callback(null, finalResponse);

                    }
                });
            },
        ], function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: data,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }
        });
    } else {
        res.json({
            code: config.statusCode.invalid,
            data: {},
            message: i18n.__("INVALID_URL")
        });
    }
}

/**
 * Function is send sms using twilio sms chat
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 5-June-2018
 */
function sendMessage(req, res) {
    var finalResponse = {};
    finalResponse.twilioInfo = {};
    finalResponse.visitorData = {};
    waterfall([
        function (callback) { //Phone number verify
            Visitor.findOne({
                phoneNumber: req.body.to,
                userFacilityId: mongoose.Types.ObjectId(req.user.userFacId),
                isDelete: false
            }).exec(function (err, visitorData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (visitorData.isSms == true) {
                        finalResponse.visitorData = visitorData;
                        callback(null, finalResponse);
                    } else {
                        res.json({
                            code: config.statusCode.error,
                            data: {},
                            message: i18n.__("SMS_STATUS_DISABLED")
                        });
                    }
                }
            })
        },
        function (finalResponse, callback) { //send sms
            var smsData = {
                to: req.body.to,
                from: req.body.from,
                message: req.body.text
            }
            twilio.sendSMS(smsData, function (returnData) {
                if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                    finalResponse.twilioInfo = returnData;
                    callback(null, finalResponse);
                } else {
                    finalResponse.twilioInfo = returnData;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Save sms history
            if (finalResponse.twilioInfo.status == config.statusCode.success) {
                var messageBody = finalResponse.twilioInfo.message.toJSON();
                var smsInfo = {};
                smsInfo.userFacilityId = req.user.userFacId;
                smsInfo.visitorId = finalResponse.visitorData._id;
                smsInfo.to = messageBody.to;
                smsInfo.from = messageBody.from;
                smsInfo.text = messageBody.body;
                var smsHistory = new SMSHistory(smsInfo);
                smsHistory.save(function (err, SmsSavedData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            } else {
                callback(null, finalResponse);
            }
        }
    ],
        function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: {},
                    message: i18n.__("SMS_SENT_SUCCESSFULLY")
                });
            }
        });
}


/**
 * Function is used change status of the visitor menu
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 6-June-2018
 */
function changeVisitorMenuStatus(req, res) {
    Visitor.findOneAndUpdate({
        _id: mongoose.Types.ObjectId(req.body.visitorId),
        userFacilityId: mongoose.Types.ObjectId(req.user.userFacId),
        isDelete: false
    }, {
            $set: {
                isCheckInAlert: req.body.isCheckInAlert,
                isAppMessagePopUp: req.body.isAppMessagePopUp,
                isSms: req.body.isSms
            }
        }, function (err, updatedVisitor) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                if (!updatedVisitor) {
                    res.json({
                        code: config.statusCode.unauthorized,
                        data: {},
                        message: i18n.__("UNAUTHORIZED")
                    });
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: {},
                        message: i18n.__("UPDATED_SUCCESSFULLY")
                    });
                }
            }
        });
}

/**
 * Function is used set visitor custom app message
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 7-June-2018
 */
function setVisitorAppMessage(req, res) {
    Visitor.findOneAndUpdate({
        _id: mongoose.Types.ObjectId(req.body.visitorId),
        userFacilityId: mongoose.Types.ObjectId(req.user.userFacId),
        isDelete: false
    }, {
            $set: {
                isAppMessagePopUp: req.body.isAppMessagePopUp,
                appMessage: req.body.appMessage
            }
        }, function (err, updatedVisitor) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                if (!updatedVisitor) {
                    res.json({
                        code: config.statusCode.unauthorized,
                        data: {},
                        message: i18n.__("UNAUTHORIZED")
                    });
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: {},
                        message: i18n.__("UPDATED_SUCCESSFULLY")
                    });
                }
            }
        });
}

/**
 * Function is use to change all check-in notifications status to true
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 9-June-2018
 */
function checkInAllNotiStatusViewed(req, res) {
    async.eachSeries(req.body.notificationDetails, function (singleCheckIn, next) {
        var notifyObj = {
            userFacId: mongoose.Types.ObjectId(req.user.userFacId),
            _id: singleCheckIn._id,
            isDelete: false
        }
        NotificationHistory.findOneAndUpdate(notifyObj, {
            $set: {
                isView: true,
            }
        }, function (err, updatedVisitorData) {
            if (err) {
                next();
            } else {
                next();
            }
        });
    }, function (err) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("UPDATED_SUCCESSFULLY")
            });
        }
    })
}


/**
 * Function is use to add incident reports
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 12-July-2018
 */
function addIncidentReports(req, res) {
    var finalResponse = {};
    finalResponse.checkInOutData = {};
    var incidentObj = {
        visitorId: req.body.visitorId,
        firstName: req.body.firstName,
        incidentType: req.body.incidentType,
        incidentTime: req.body.incidentTime,
        lastName: req.body.lastName,
        concern: req.body.concern,
        department: req.body.department,
        resolved: req.body.resolved,
        visitedTo: req.body.visitedTo,
        subject: req.body.subject,
        notes: req.body.notes,
        resolutionNotes: req.body.resolutionNotes
    }

    if (!incidentObj.visitorId) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } {
        waterfall([
            function (callback) { //Check visitor check in log
                var checkInObj = {
                    userFacilityId: mongoose.Types.ObjectId(req.user.userFacId),
                    visitorId: mongoose.Types.ObjectId(req.body.visitorId)
                }
                CheckInOut.findOne(checkInObj).sort({
                    createdAt: -1
                }).exec(function (err, checkInOutData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.checkInOutData = checkInOutData;
                        callback(null, finalResponse);
                    }
                })
            },
            function (finalResponse, callback) { // save notification details
                var incidentInfo = {};
                incidentInfo.userFacId = mongoose.Types.ObjectId(req.user.userFacId),
                    incidentInfo.visitorId = incidentObj.visitorId,
                    incidentInfo.checkInlogId = finalResponse.checkInOutData._id,
                    incidentInfo.incidentType = incidentObj.incidentType,
                    incidentInfo.firstName = incidentObj.firstName,
                    incidentInfo.lastName = incidentObj.lastName,
                    incidentInfo.concern = incidentObj.concern,
                    incidentInfo.department = incidentObj.department,
                    incidentInfo.incidentTime = incidentObj.incidentTime,
                    incidentInfo.resolved = incidentObj.resolved,
                    incidentInfo.visitedTo = incidentObj.visitedTo,
                    incidentInfo.subject = incidentObj.subject,
                    incidentInfo.notes = incidentObj.notes,
                    incidentInfo.resolutionNotes = incidentObj.resolutionNotes
                var incidentReport = new IncidentReports(incidentInfo);
                incidentReport.save(function (err, incidentReportData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            }

        ], function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: data,
                    message: i18n.__("INCIDENT_REPORT_SAVE_SUCCUSSFULLY")
                });
            }
        });
    }
}

/**
 * Function is use to get incident Reports List
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 13-June-2018
 */
function incidentReportsList(req, res) {
    var finalResponse = {};
    var orgData = {};
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);

    waterfall([
        function (callback) {
            var condition = {};
            condition.userFacId = mongoose.Types.ObjectId(req.user.userFacId);
            condition.isDelete = false;
            var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            if (searchText != undefined && searchText != 'undefined') {
                condition.$or = [{
                    'firstName': new RegExp(searchText, 'gi')
                },
                {
                    'lastName': new RegExp(searchText, 'gi')
                },
                ];
            }
            if (req.body.createdAt) {
                var start_day_date = moment(req.body.createdAt).startOf('day');
                var end_day_date = moment(req.body.createdAt).endOf('day');
                var momentObjFrom = new Date(moment(start_day_date));
                var momentObjTo = new Date(moment(end_day_date));
                condition.$and = [{
                    createdAt: {
                        $gte: momentObjFrom
                    }
                },
                {
                    createdAt: {
                        $lte: momentObjTo
                    }
                }
                ];
            }

            if (req.body.firstName) {
                condition['firstName'] = new RegExp(req.body.firstName, 'gi');
            }
            if (req.body.lastName) {
                condition['lastName'] = new RegExp(req.body.lastName, 'gi');
            }
            var aggregate = [{
                $lookup: {
                    from: 'visitors',
                    localField: "visitorId",
                    foreignField: "_id",
                    as: "visitorInfo"
                }
            },
            {
                $unwind: "$visitorInfo"
            },
            { //upadte by divya 16/7/2018
                $lookup: {
                    from: 'users',
                    localField: "employeeId",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: { path: "$userInfo", preserveNullAndEmptyArrays: true }
            },// -----------------------
            {
                $match: condition
            },
            ];
            var project = {
                $project: {
                    "visitorId": "$visitorId",
                    "firstName": "$firstName",
                    "lastName": "$lastName",
                    "email": "$visitorInfo.email",
                    "createdAt": "$createdAt",
                    "concern": "$concern",
                    "incidentTime": "$incidentTime",
                    "visitedTo": "$visitedTo",
                    "department": "$department",
                    "incidentType": "$incidentType",
                    "assignStatus": "$assignStatus",
                    "resolved": "$resolved",
                    "subject": "$subject",
                    "empAccept": "$empAccept",
                    "notes": "$notes",
                    "adminNotes": "$adminNotes", //upadte by divya 16/7/2018
                    "employeeNotes": "$employeeNotes", //upadte by divya 16/7/2018
                    "resolutionNotes": "$resolutionNotes",
                    "employeeId": "$employeeId", //upadte by divya 16/7/2018
                    "userName": "$userInfo.userName" //upadte by divya 16/7/2018

                }
            };
            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            aggregate.push({
                $sort: sorting
            });
            aggregate.push({
                $skip: parseInt(skip)
            });
            aggregate.push({
                $limit: parseInt(count)
            });
            IncidentReports.aggregate(aggregate).then(function (IncidentReportsData) {
                var data = {};
                data.data = IncidentReportsData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                IncidentReports.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    data.total_count = cnt;
                    callback(null, data);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to edit Incident Reports
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 14-June-2018
 */
function editIncidentReports(req, res) {
    var finalResponse = {};
    finalResponse.incidentInfo = {};
    finalResponse.twilioInfo = {};
    var incidentObj = {
        _id: req.body._id,
        incidentType: req.body.incidentType,
        firstName: req.body.firstName,
        incidentTime: req.body.incidentTime,
        lastName: req.body.lastName,
        concern: req.body.concern,
        department: req.body.department,
        resolved: req.body.resolved,
        visitedTo: req.body.visitedTo,
        subject: req.body.subject,
        notes: req.body.notes,
        resolutionNotes: req.body.resolutionNotes
    }
    waterfall([
        function (callback) { //Update user record
            IncidentReports.findById(incidentObj._id).exec(function (err, incidentInfo) {
                if (err) {
                    callback(err, false);
                } else {
                    incidentInfo.firstName = req.body.firstName,
                    incidentInfo.incidentTime = req.body.incidentTime,
                    incidentInfo.incidentType = req.body.incidentType,
                    incidentInfo.lastName = req.body.lastName,
                    incidentInfo.concern = req.body.concern,
                    incidentInfo.department = req.body.department,
                    incidentInfo.resolved = req.body.resolved,
                    incidentInfo.visitedTo = req.body.visitedTo,
                    incidentInfo.subject = req.body.subject,
                    incidentInfo.notes = req.body.notes,
                    incidentInfo.resolutionNotes = req.body.resolutionNotes
                    if(req.body.resolved == true){
                        incidentInfo.resolvedDate = moment(req.body.resolvedDate);
                    }
                    incidentInfo.save(function (err, updatedIncidentData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.incidentInfo = incidentInfo;
                            
                            /* Send Custom and universal notification on incident update */
                            var obj = {
                                incidentInfo: incidentInfo,
                                twilioTollFreeNumber: req.user.twilioTollFreeNumber
                            }
                            sendCustomNotificationOnUpdate(obj); //Custom
                            sendNotificationOnUpdate(obj);  //Universal w.r.t facility
                            /* End */

                            callback(null, finalResponse);
                        }
                    })
                }
            })
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("INCIDENT_REPORT_UPDATE_SUCCESSFULLY")
            });
        }
    });
}


/**
 * Function is use to assign Incident To Employee
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 14-June-2018
 */
function assignIncidentToEmployee(req, res) {
    var finalResponse = {};
    finalResponse.verifyIncidentAcceptRejectToken = '';
    finalResponse.verifyIncidentAcceptLink = '';
    finalResponse.verifyIncidentRejectLink = '';
    var incidentNote = req.body.incidentNote;
    waterfall([
        function (callback) {
            
            var date = new Date();
            finalResponse.verifyIncidentAcceptRejectToken = utility.getEncryptText(Math.random().toString(4).slice(2) + date.getTime());
            finalResponse.verifyIncidentAcceptLink = config.email.base_url + '/verify_incident_accept_request/' + finalResponse.verifyIncidentAcceptRejectToken;
            finalResponse.verifyIncidentRejectLink = config.email.base_url + '/verify_incident_reject_request/' + finalResponse.verifyIncidentAcceptRejectToken;

            IncidentReports.findOneAndUpdate({
                _id: mongoose.Types.ObjectId(req.body.incidentId),
                isDelete: false,
                userFacId: mongoose.Types.ObjectId(req.user.userFacId),
            }, {
                    $set: {
                        employeeId: mongoose.Types.ObjectId(req.body.employeeId),
                        assignStatus: true,
                        empAccept: '',
                        verifyIncidentAcceptRejectToken: finalResponse.verifyIncidentAcceptRejectToken
                    }
                }, function (err, data) {
                    if (err) {
                        callback(err, false);
                    } else {
                        console.log("in assignIncidentToEmployee to send emails");
                        var headerTable = "<tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>" +
                            "<tr><td style='padding: 0 20px;'>" +
                            "<table width='100%' border='0' cellspacing='0' cellpadding='0'>" +
                            "<tbody><tr><td style='color: #C33333; padding-bottom: 10px;'><strong>Assign Incident Detail:</strong></td></tr></tbody></table>" +
                            "<table width='100%' border='1' bordercolor='#d9d9d9' cellspacing='0' cellpadding='10' style='border-collapse: collapse;'>" +
                            "<tbody>" +
                            "<tr>" +
                            "<td><span style='font-size: 12px; color: #777777;'>Created At</span></td>" +
                            "<td><span style='font-size: 12px; color: #777777;'>Regarding</span></td>" +
                            "<td><span style='font-size: 12px; color: #777777;'>Type</span></td>" +
                            "<td><span style='font-size: 12px; color: #777777;'>Visited To</span></td>" +
                            "<td><span style='font-size: 12px; color: #777777;'>Concern</span></td>" +
                            "</tr>" +
                            "<tr>";
                        if(req.body.incidentNote != null || req.body.incidentNote != undefined || req.body.incidentNote != ''){
                            var footerTable = "</tbody></table>"+
                                              "<table width='100%' border='0' cellspacing='0' cellpadding='0'>" +
                                              "<tbody><tr><td style='padding-bottom: 10px;'><strong>Note: "+ incidentNote +"</strong></td></tr></tbody></table>" +  
                                              "</td></tr>";
                        }else{
                            var footerTable = "</tbody></table></td></tr>";
                        }    
                        var bodyContent = "";
                        var createdAt = moment(data.createdAt).format('MM-DD-YYYY');
                        var regarding = data.firstName + ' ' + data.lastName;
                        var type = data.incidentType;
                        var visitedTo = data.visitedTo;
                        var concern = data.concern ? data.concern : '-';

                        bodyContent += "<td><span><strong>" + createdAt + "</strong></span></td>" +
                            "<td><span><strong>" + regarding + "</strong></span></td>" +
                            "<td><span><strong>" + type + "</strong></span></td>" +
                            "<td><span><strong>" + visitedTo + "</strong></span></td>" +
                            "<td><span><strong>" + concern + "</strong></span></td>" +
                            "</tr>";

                        var finalBodyContent = headerTable + bodyContent + footerTable;
                        User.findOne({
                            _id: mongoose.Types.ObjectId(req.body.employeeId),
                            isDelete: false
                        }).exec(function (err, employeeData) {
                            if (err) {
                                next();
                            } else {
                                var baseUrl = config.email.base_url;
                                var options = {
                                    template: 'assignIncident.html',
                                    from: config.email.from,
                                    repalcement: {
                                        "{{user.name}}": employeeData.firstName.charAt(0).toUpperCase() + employeeData.firstName.slice(1).toLowerCase() + ' ' + employeeData.lastName.charAt(0).toUpperCase() + employeeData.lastName.slice(1).toLowerCase(),
                                        "{{content_notify}}": finalBodyContent,
                                        "{{user.url}}": baseUrl + "/facility/incidentReports",
                                        "{{logo_url}}": baseUrl + config.email.logo_url,
                                        "{{copyright}}": config.email.copyright,
                                        "{{link.abuse_email}}": config.email.abuse_email,
                                        "{{accept_url}}": finalResponse.verifyIncidentAcceptLink,
                                        "{{reject_url}}": finalResponse.verifyIncidentRejectLink
                                    },
                                    to: employeeData.email,
                                    subject: 'Incident/Complaint Assignment'
                                };
                                emailSend.smtp.sendMail(options, function (err, response) {
                                    if (err) {
                                        callback(err, false);
                                    } else {
                                        callback(null, finalResponse);
                                    }
                                })
                            }
                        })
                    }
                })
        },
        function (finalResponse, callback) { //Save note to the incident note
            if (req.body.incidentNote != null || req.body.incidentNote != undefined || req.body.incidentNote != '') {
                var obj = {
                    incidentId: req.body.incidentId,
                    userFacId: req.user.userFacId,
                    userId: req.body.noteAddedById,
                    message: req.body.incidentNote
                }
                var incidentNotes = new IncidentNotes(obj);
                incidentNotes.save(function (err, incidentNotes) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            } else {
                callback(null, finalResponse);
            }
        }
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("INCIDENT_ASSIGNED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get Check In Log By VisitorId
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-May-2018
 */
function getIncidentByVisitorId(req, res) {
    var finalResponse = {};
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    waterfall([
        function (callback) { //CheckInOut Data
            var condition = {};
            condition.userFacId = mongoose.Types.ObjectId(req.user.userFacId);
            condition.isDelete = false;
            if (mongoose.Types.ObjectId.isValid(req.body._id)) {
                condition.visitorId = mongoose.Types.ObjectId(req.body._id);
                var aggregate = [{
                    $lookup: {
                        from: 'visitors',
                        localField: "visitorId",
                        foreignField: "_id",
                        as: "visitorInfo"
                    }
                },
                {
                    $unwind: "$visitorInfo"
                },
                {
                    $match: condition
                },
                ];
                var project = {
                    $project: {
                        "createdAt": "$createdAt",
                        "subject": "$subject",
                        "concern": "$concern",
                        "notes": "$notes",
                        "resolutionNotes": "$resolutionNotes",
                        "resolved": "$resolved"
                    }
                };
                aggregate.push(project);
                var countQuery = [].concat(aggregate);
                aggregate.push({
                    $sort: {
                        createdAt: -1
                    }
                });
                aggregate.push({
                    $skip: parseInt(skip)
                });
                aggregate.push({
                    $limit: parseInt(count)
                });
                IncidentReports.aggregate(aggregate).then(function (visitorData) {
                    var data = {};
                    data.data = visitorData;
                    countQuery.push({
                        $group: {
                            _id: null,
                            count: {
                                $sum: 1
                            }
                        }
                    });
                    IncidentReports.aggregate(countQuery).then(function (dataCount) {
                        var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                        data.total_count = cnt;
                        callback(null, data);
                    });
                }).catch(function (err) {
                    callback(err, false);
                });
            }

        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}


/**
 * Function is use to get incident Reports List for Employee
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 13-June-2018
 */
function employeeIncidentReportsList(req, res) {
    var finalResponse = {};
    var orgData = {};
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);

    waterfall([
        function (callback) {
            var condition = {};
            condition.userFacId = mongoose.Types.ObjectId(req.user.userFacId);
            condition.employeeId = mongoose.Types.ObjectId(req.user.uid);
            condition.isDelete = false;
            var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            if (searchText != undefined && searchText != 'undefined') {
                condition.$or = [{
                    'firstName': new RegExp(searchText, 'gi')
                },
                {
                    'lastName': new RegExp(searchText, 'gi')
                },
                ];
            }
            if (req.body.createdAt) {
                var start_day_date = moment(req.body.createdAt).startOf('day');
                var end_day_date = moment(req.body.createdAt).endOf('day');
                var momentObjFrom = new Date(moment(start_day_date));
                var momentObjTo = new Date(moment(end_day_date));
                condition.$and = [{
                    createdAt: {
                        $gte: momentObjFrom
                    }
                },
                {
                    createdAt: {
                        $lte: momentObjTo
                    }
                }
                ];

            }

            if (req.body.firstName) {
                condition['firstName'] = new RegExp(req.body.firstName, 'gi');
            }
            if (req.body.lastName) {
                condition['lastName'] = new RegExp(req.body.lastName, 'gi');
            }
            var aggregate = [{
                $lookup: {
                    from: 'visitors',
                    localField: "visitorId",
                    foreignField: "_id",
                    as: "visitorInfo"
                }
            },
            {
                $unwind: "$visitorInfo"
            },
            {
                $match: condition
            },
            ];
            var project = {
                $project: {
                    "visitorId": "$visitorId",
                    "firstName": "$firstName",
                    "lastName": "$lastName",
                    "email": "$visitorInfo.email",
                    "createdAt": "$createdAt",
                    "concern": "$concern",
                    "incidentTime": "$incidentTime",
                    "visitedTo": "$visitedTo",
                    "department": "$department",
                    "incidentType": "$incidentType",
                    "assignStatus": "$assignStatus",
                    "resolved": "$resolved",
                    "subject": "$subject",
                    "empAccept": "$empAccept",
                    "notes": "$notes",
                    "resolutionNotes": "$resolutionNotes"
                }
            };
            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            aggregate.push({
                $sort: sorting
            });
            aggregate.push({
                $skip: parseInt(skip)
            });
            aggregate.push({
                $limit: parseInt(count)
            });
            IncidentReports.aggregate(aggregate).then(function (IncidentReportsData) {
                var data = {};
                data.data = IncidentReportsData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                IncidentReports.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    data.total_count = cnt;
                    callback(null, data);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        console.log("..data", data)
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}


/**
 * Function is use to accept Incident By Employee
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 15-June-2018
 */

function acceptIncidentByEmployee(req, res) {
    var finalResponse = {};
    finalResponse.acceptIncidentData = {};
    waterfall([
        function (callback) {
            IncidentReports.findOneAndUpdate({
                _id: mongoose.Types.ObjectId(req.body.incidentId),
                isDelete: false,
                employeeId: mongoose.Types.ObjectId(req.user.uid),
                userFacId: mongoose.Types.ObjectId(req.user.userFacId),
            }, {
                    $set: {
                        empAccept: req.body.acceptIncident
                    },

                }, {
                    new: true
                }, function (err, data) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.acceptIncidentData = data;
                        callback(null, finalResponse);
                    }
                });
        }
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("INCIDENT_ACCEPTED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is send sms to all selected visitors using twilio sms chat
 * @access private
 * @return json
 * Created by VishakaR
 * @smartData Enterprises (I) Ltd
 * Created Date 2-July-2018
 */
function sendBroadCastAll(req, res) {
    var finalResponse = {};
    finalResponse.twilioInfo = {};
    finalResponse.visitorData = {};
    var ids = req.body.ids_array;
    ids.map(id => {
        waterfall([
            function (callback) { //Phone number verify
                Visitor.findOne({
                    userFacilityId: mongoose.Types.ObjectId(req.user.userFacId),
                    _id: mongoose.Types.ObjectId(id),
                    isDelete: false
                }).exec(function (err, visitorData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (visitorData.isSms == true) {
                            finalResponse.visitorData = visitorData;
                            callback(null, finalResponse);
                        } else {
                            res.json({
                                code: config.statusCode.error,
                                data: {},
                                message: i18n.__("SMS_STATUS_DISABLED")
                            });
                        }
                    }
                })
            },
            function (finalResponse, callback) { //Save sms history
                var smsData = {
                    to: finalResponse.visitorData.phoneNumber,
                    from: req.user.twilioTollFreeNumber,
                    message: req.body.message
                }
                twilio.sendSMS(smsData, function (returnData) {
                    if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                        finalResponse.twilioInfo = returnData;
                        callback(null, finalResponse);
                    } else {
                        finalResponse.twilioInfo = returnData;
                        callback(null, finalResponse);
                    }
                });
            },
            function (finalResponse, callback) { //Save sms history
                if (finalResponse.twilioInfo.status == config.statusCode.success) {
                    var messageBody = finalResponse.twilioInfo.message.toJSON();
                    var smsInfo = {};
                    smsInfo.userFacilityId = req.user.userFacId,
                        smsInfo.visitorId = finalResponse.visitorData._id,
                        smsInfo.to = messageBody.to,
                        smsInfo.from = messageBody.from,
                        smsInfo.text = messageBody.body
                    var smsHistory = new SMSHistory(smsInfo);
                    smsHistory.save(function (err, SmsSavedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                } else if (finalResponse.twilioInfo.status == config.statusCode.badRequest) {
                    var smsInfo = {};
                    smsInfo.userFacilityId = req.user.userFacId,
                        smsInfo.visitorId = finalResponse.visitorData._id,
                        smsInfo.to = finalResponse.visitorData.phoneNumber,
                        smsInfo.from = req.user.twilioTollFreeNumber,
                        smsInfo.text = req.body.message,
                        smsInfo.status = false
                    var smsHistory = new SMSHistory(smsInfo);
                    smsHistory.save(function (err, SmsSavedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                } else {
                    callback(null, finalResponse);
                }
            }
        ],
            function (err, data) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: {},
                        message: i18n.__("SMS_SENT_SUCCESSFULLY")
                    });
                }
            });
    });
}

/**
 * Function is use to add BroadCast Message by facility
 * @access private
 * @return json
 * Created by VishakR
 * @smartData Enterprises (I) Ltd
 * Created Date 3-July-2018
 */
function addBroadCastMessage(req, res) {
    var finalResponse = {};
    var broadcastObj = {
        userFacId: req.user.userFacId,
        message: req.body.message
    }
    console.log("broadcastObj", broadcastObj);
    if (!broadcastObj.userFacId || !broadcastObj.message) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } {
        waterfall([
            function (callback) { // save notification details
                var broadcastMessagesInfo = {};
                broadcastMessagesInfo.userFacId = req.user.userFacId;
                broadcastMessagesInfo.message = req.body.message;
                var broadcastMessagesSave = new BroadcastMessages(broadcastMessagesInfo);
                broadcastMessagesSave.save(function (err, broadcastMessagesData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            }

        ], function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: data,
                    message: i18n.__("Your message has been saved!")
                });
            }
        });
    }
}



/**
 * Function is use to get added BroadCast Message by facility
 * @access private
 * @return json
 * Created by VishakaR
 * @smartData Enterprises (I) Ltd
 * Created Date 3-July-2018
 */


function getBroadCastMessageDetails(req, res) {
    var finalResponse = {};
    finalResponse.messageCount = 0;
    finalResponse.messageDetails = {};
    waterfall([
        function (callback) { //get Message Count
            var condition = {
                isDelete: false,
                userFacId: mongoose.Types.ObjectId(req.user.userFacId)
            };
            BroadcastMessages.find(condition).count().exec(function (err, messageCount) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.messageCount = messageCount;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //get Message Details
            var condition = {};
            condition.isDelete = false;
            condition.userFacId = mongoose.Types.ObjectId(req.user.userFacId);

            BroadcastMessages.find(condition).sort({
                createdAt: -1
            }).exec(function (err, messageDetails) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.messageDetails = messageDetails;
                    callback(null, finalResponse);

                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}



/**
 * Function is use to get Review Message Details
 * @access private
 * @return json
 * Created by VishakaR
 * @smartData Enterprises (I) Ltd
 * Created Date 3-July-2018
 */


function getReviewMessageDetails(req, res) {
    var finalResponse = {};
    finalResponse.messageCount = 0;
    finalResponse.positivemessage = [];
    finalResponse.negativemessage = [];
    finalResponse.requestreviewmessage = [];
    waterfall([
        function (callback) { //get review Count
            ResponseMessages.find().count().exec(function (err, messageCount) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.messageCount = messageCount;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //get review Details

            ResponseMessages.find().sort({
                createdAt: -1
            }).exec(function (err, messageDetails) {
                if (err) {
                    callback(err, false);
                } else {
                    for (var i = 0; i < messageDetails.length; i++) {
                        if (messageDetails[i].title == 'positive') {
                            finalResponse.positivemessage.push(messageDetails[i]);
                        } else if (messageDetails[i].title == 'negative') {
                            finalResponse.negativemessage.push(messageDetails[i]);
                        } else if (messageDetails[i].title == 'requestReview') {
                            finalResponse.requestreviewmessage.push(messageDetails[i]);
                        } else {

                        }
                    }
                    callback(null, finalResponse);
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to delete saved Message
 * @access private
 * @return json
 * Created by VishakaR
 * @smartData Enterprises (I) Ltd
 * Created Date 3-July-2018
 */
function deleteSavedMessage(req, res) {
    var finalResponse = {};
    waterfall([
        function (callback) { //Delete company
            BroadcastMessages.findOneAndUpdate({
                _id: req.body._id
            }, {
                    $set: {
                        isDelete: true,
                    }
                }, function (err, data) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
        }
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("FACILITY_ACCOUNT_DELETED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get open incident Reports List
 * @access private
 * @return json
 * Created by Divya
 * @smartData Enterprises (I) Ltd
 * Created Date 17-July-2018
*/
function getOpenIncidentReportsList(req, res) {
    var finalResponse = {};
    var orgData = {};
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);

    waterfall([
        function (callback) {
            var condition = {};
            condition.userFacId = mongoose.Types.ObjectId(req.user.userFacId);
            condition.isDelete = false;
            condition.resolved = false;
            var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            if (searchText != undefined && searchText != 'undefined') {
                condition.$or = [{
                    'firstName': new RegExp(searchText, 'gi')
                },
                {
                    'lastName': new RegExp(searchText, 'gi')
                },
                ];
            }
            if (req.body.createdAt) {
                var start_day_date = moment(req.body.createdAt).startOf('day');
                var end_day_date = moment(req.body.createdAt).endOf('day');
                var momentObjFrom = new Date(moment(start_day_date));
                var momentObjTo = new Date(moment(end_day_date));
                condition.$and = [{
                    createdAt: {
                        $gte: momentObjFrom
                    }
                },
                {
                    createdAt: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            if (req.body.firstName) {
                condition['firstName'] = new RegExp(req.body.firstName, 'gi');
            }
            if (req.body.lastName) {
                condition['lastName'] = new RegExp(req.body.lastName, 'gi');
            }
            var aggregate = [{
                $lookup: {
                    from: 'visitors',
                    localField: "visitorId",
                    foreignField: "_id",
                    as: "visitorInfo"
                }
            },
            {
                $unwind: "$visitorInfo"
            },
            {
                $lookup: {
                    from: 'users',
                    localField: "employeeId",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: { path: "$userInfo", preserveNullAndEmptyArrays: true }
            },
            {
                $match: condition
            },
            ];
            var project = {
                $project: {
                    "visitorId": "$visitorId",
                    "firstName": "$firstName",
                    "lastName": "$lastName",
                    "email": "$visitorInfo.email",
                    "createdAt": "$createdAt",
                    "concern": "$concern",
                    "incidentTime": "$incidentTime",
                    "visitedTo": "$visitedTo",
                    "department": "$department",
                    "incidentType": "$incidentType",
                    "assignStatus": "$assignStatus",
                    "resolved": "$resolved",
                    "subject": "$subject",
                    "empAccept": "$empAccept",
                    "notes": "$notes",
                    "adminNotes": "$adminNotes",
                    "employeeNotes": "$employeeNotes",
                    "resolutionNotes": "$resolutionNotes",
                    "employeeId": "$employeeId",
                    "userName": "$userInfo.userName"
                }
            };
            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            aggregate.push({
                $sort: sorting
            });
            aggregate.push({
                $skip: parseInt(skip)
            });
            aggregate.push({
                $limit: parseInt(count)
            });
            IncidentReports.aggregate(aggregate).then(function (IncidentReportsData) {
                var data = {};
                data.data = IncidentReportsData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                IncidentReports.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    data.total_count = cnt;
                    callback(null, data);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get resolved incident Reports List
 * @access private
 * @return json
 * Created by Divya
 * @smartData Enterprises (I) Ltd
 * Created Date 17-July-2018
*/
function getResolvedIncidentReportsList(req, res) {
    var finalResponse = {};
    var orgData = {};
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);

    waterfall([
        function (callback) {
            var condition = {};
            condition.userFacId = mongoose.Types.ObjectId(req.user.userFacId);
            condition.isDelete = false;
            condition.resolved = true;
            var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            if (searchText != undefined && searchText != 'undefined') {
                condition.$or = [{
                    'firstName': new RegExp(searchText, 'gi')
                },
                {
                    'lastName': new RegExp(searchText, 'gi')
                },
                ];
            }
            if (req.body.createdAt) {
                var start_day_date = moment(req.body.createdAt).startOf('day');
                var end_day_date = moment(req.body.createdAt).endOf('day');
                var momentObjFrom = new Date(moment(start_day_date));
                var momentObjTo = new Date(moment(end_day_date));
                condition.$and = [{
                    createdAt: {
                        $gte: momentObjFrom
                    }
                },
                {
                    createdAt: {
                        $lte: momentObjTo
                    }
                }
                ];

            }
            if (req.body.firstName) {
                condition['firstName'] = new RegExp(req.body.firstName, 'gi');
            }
            if (req.body.lastName) {
                condition['lastName'] = new RegExp(req.body.lastName, 'gi');
            }
            var aggregate = [{
                $lookup: {
                    from: 'visitors',
                    localField: "visitorId",
                    foreignField: "_id",
                    as: "visitorInfo"
                }
            },
            {
                $unwind: "$visitorInfo"
            },
            {
                $lookup: {
                    from: 'users',
                    localField: "employeeId",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: { path: "$userInfo", preserveNullAndEmptyArrays: true }
            },
            {
                $match: condition
            },
            ];
            var project = {
                $project: {
                    "visitorId": "$visitorId",
                    "firstName": "$firstName",
                    "lastName": "$lastName",
                    "email": "$visitorInfo.email",
                    "createdAt": "$createdAt",
                    "concern": "$concern",
                    "incidentTime": "$incidentTime",
                    "visitedTo": "$visitedTo",
                    "department": "$department",
                    "incidentType": "$incidentType",
                    "assignStatus": "$assignStatus",
                    "resolved": "$resolved",
                    "subject": "$subject",
                    "empAccept": "$empAccept",
                    "notes": "$notes",
                    "adminNotes": "$adminNotes",
                    "employeeNotes": "$employeeNotes",
                    "resolutionNotes": "$resolutionNotes",
                    "employeeId": "$employeeId",
                    "userName": "$userInfo.userName"
                }
            };
            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            aggregate.push({
                $sort: sorting
            });
            aggregate.push({
                $skip: parseInt(skip)
            });
            aggregate.push({
                $limit: parseInt(count)
            });
            IncidentReports.aggregate(aggregate).then(function (IncidentReportsData) {
                var data = {};
                data.data = IncidentReportsData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                IncidentReports.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    data.total_count = cnt;
                    callback(null, data);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get incident record by id
 * @access private
 * @return json
 * Created by Divya
 * @smartData Enterprises (I) Ltd
 * Created Date 17-July-2018
*/
function getEditIncidentRecord(req, res) {
    waterfall([
        function (callback) {
            var condition = {};
            condition.userFacId = mongoose.Types.ObjectId(req.user.userFacId);
            condition.isDelete = false;
            condition._id = mongoose.Types.ObjectId(req.body._id);
            var aggregate = [{
                $lookup: {
                    from: 'visitors',
                    localField: "visitorId",
                    foreignField: "_id",
                    as: "visitorInfo"
                }
            },
            {
                $unwind: "$visitorInfo"
            },
            {
                $lookup: {
                    from: 'users',
                    localField: "employeeId",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: { path: "$userInfo", preserveNullAndEmptyArrays: true }
            },
            {
                $match: condition
            },
            ];
            var project = {
                $project: {
                    "visitorId": "$visitorId",
                    "firstName": "$firstName",
                    "lastName": "$lastName",
                    "email": "$visitorInfo.email",
                    "createdAt": "$createdAt",
                    "concern": "$concern",
                    "incidentTime": "$incidentTime",
                    "visitedTo": "$visitedTo",
                    "department": "$department",
                    "incidentType": "$incidentType",
                    "assignStatus": "$assignStatus",
                    "resolved": "$resolved",
                    "subject": "$subject",
                    "empAccept": "$empAccept",
                    "notes": "$notes",
                    "adminNotes": "$adminNotes",
                    "employeeNotes": "$employeeNotes",
                    "resolutionNotes": "$resolutionNotes",
                    "employeeId": "$employeeId",
                    "userName": "$userInfo.userName"
                }
            };
            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            IncidentReports.aggregate(aggregate).then(function (IncidentReportsData) {
                var data = {};
                data.data = IncidentReportsData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                IncidentReports.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    data.total_count = cnt;
                    callback(null, data);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to delete visitor 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 20-Aug-2018
 */
function deleteVisitor(req, res) {
    Visitor.findOneAndUpdate({
        _id: mongoose.Types.ObjectId(req.body._id)
    }, {
        $set: {
            isDelete: true,
        }
    }, function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("VISITOR_REMOVED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get incident notes 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 21-Aug-2018
 */
function getIncidentNotes(req, res) {
    IncidentNotes.find({
        incidentId: mongoose.Types.ObjectId(req.body.incidentId),
        isDelete:  false,
        userFacId: req.user.userFacId
    }).populate('userId', 'userName image' ).exec(function (err, incidentNotes) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: incidentNotes,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to add incident notes 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 21-Aug-2018
 */
function addIncidentNote(req, res) {
    var obj = {
        incidentId: req.body.incidentId,
        userFacId: req.body.userFacId,
        userId: req.body.userId._id,
        message: req.body.message
    }
    var incidentNotes = new IncidentNotes(obj);
    incidentNotes.save(function (err, incidentNotes) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: incidentNotes,
                message: i18n.__("DATA_SAVED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to update every collection to add extra field  
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 6-Sep-2018
 */
function updateEveryDocument(req, res) {
    console.log("ready to update");

    var count = 0;
    Visitor.find().exec(function (err, visitorData) {
        if (err) {
            console.log(err);
        } else {
            async.eachSeries(visitorData, function (singleVisitor, next) {
                count++;
                Visitor.findOneAndUpdate({ _id: mongoose.Types.ObjectId(singleVisitor._id) }, {
                    $set: {
                        visitorName: singleVisitor.firstName+ ' '+singleVisitor.lastName,
                    }
                }, function (err, updatedVisitorData) {
                    if (err) {
                        next();
                    } else {
                        console.log('count@@',count);
                        next();
                    }
                });
            }, function (err) {
                if (err) {
                    console.log(err);
                } else {
                    console.log("successfully update", count);
                }
            })
        }
    });
}

/**
 * Function is use to get setting incident record 
 * @access private
 * @return json
 * Created by Divya
 * @smartData Enterprises (I) Ltd
 * Created Date 7-Sep-2018
 */
function getSettingIncident(req, res){
    IncidentReports.findOne({
        _id: mongoose.Types.ObjectId(req.body.obj._id),
        isDelete: false
    }).exec(function (err, getSettingIncidentResponse) {
        if(err){
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        }else{
            res.json({
                code: config.statusCode.success,
                data: getSettingIncidentResponse,
                message: i18n.__("DATA_SAVED_SUCCESSFULLY")
            });
        }
    })
}

/**
 * Function is use to update custom setting of incident
 * @access private
 * @return json
 * Created by Divya
 * @smartData Enterprises (I) Ltd
 * Created Date 7-Sep-2018
 */
function updateCustomIncidentSetting(req, res){
    IncidentReports.findOneAndUpdate({ _id: req.body._id }, {
        $set: {
            openIncident: req.body.openIncident,
            updateResolvedIncident: req.body.updateResolvedIncident
        }
    }, function (err, updatedCustomSettingResult) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("SETTING_UPDATED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to send custom notification for incident update
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 8-Sep-2018
 */
function sendCustomNotificationOnUpdate(incidentData){
    var finalResponse = {};
    finalResponse.twilioInfo = {};
    var createdAt = moment(incidentData.incidentInfo.createdAt).format('MM-DD-YYYY');

    waterfall([
        function (callback) { //Send email/text notifcation 
            if (incidentData.incidentInfo.updateResolvedIncident.status == true) {
                async.eachSeries(incidentData.incidentInfo.updateResolvedIncident.emailsArray, function (notificationData, next) {
                    var baseUrl = config.email.base_url;
                    var options = {
                        template: 'notifyUpdateIncident.html',
                        from: config.email.from,
                        repalcement: {
                            "{{created_date}}": createdAt,
                            "{{regarding}}": incidentData.incidentInfo.firstName + ' ' + incidentData.incidentInfo.lastName,
                            "{{concern}}": incidentData.incidentInfo.concern,
                            "{{user.url}}": baseUrl + "/facility/incidentReports",
                            "{{logo_url}}": baseUrl + config.email.logo_url,
                            "{{copyright}}": config.email.copyright,
                            "{{user.login_url}}": baseUrl,
                            "{{link.abuse_email}}": config.email.abuse_email
                        },
                        to: notificationData,
                        subject: 'Update/Resolved Incident'
                    };
                    emailSend.smtp.sendMail(options, function (err, response) {
                        if (err) {
                            next();
                        } else {
                            next();
                        }
                    })
                }, function (err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        var text = "Incident report created At " + createdAt + " regarding " + incidentData.incidentInfo.firstName + ' ' + incidentData.incidentInfo.lastName + " whose concern is " + incidentData.incidentInfo.concern + " is updated. To check please visit to the provided link: " + config.email.base_url + "/facility/incidentReports";
                        var smsData = {
                            to: incidentData.incidentInfo.updateResolvedIncident.phoneNumber,
                            from: incidentData.twilioTollFreeNumber,
                            message: text
                        }
                        twilio.sendSMS(smsData, function (returnData) {
                            if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                                finalResponse.twilioInfo = returnData;
                                callback(null, finalResponse);
                            } else {
                                finalResponse.twilioInfo = returnData;
                                callback(null, finalResponse);
                            }
                        });
                    }
                })
            } else {
                callback(null, finalResponse);
            }
        },
        function (finalResponse, callback) { //saved notificationSmsHistory
            if (incidentData.incidentInfo.updateResolvedIncident.status == true && finalResponse.twilioInfo.status == config.statusCode.success) {
                var messageBody = finalResponse.twilioInfo.message.toJSON();
                var smsInfo = {};
                smsInfo.userFacId = incidentData.incidentInfo.userFacId;
                smsInfo.to = messageBody.to;
                smsInfo.from = messageBody.from;
                smsInfo.text = messageBody.body;
                smsInfo.type = 'custom_update_incident';
                var notificationSmsHistory = new NotificationSmsHistory(smsInfo);
                notificationSmsHistory.save(function (err, SmsSavedData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            } else {
                callback(null, finalResponse);
            }
        },
    ], function (err, data) {
        if (err) {} else {}
    });
}

/**
 * Function is use to send universal notification for incident update w.r.t facility
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 8-Sep-2018
 */
function sendNotificationOnUpdate(incidentData){
    var finalResponse = {};
    finalResponse.facilityNotificationsSettings = {};
    finalResponse.twilioInfo = {};
    var createdAt = moment(incidentData.incidentInfo.createdAt).format('MM-DD-YYYY');

    waterfall([
        function (callback) {// get facility notification setting
            FacilityNotificationSettings.findOne({
                userFacId: mongoose.Types.ObjectId(incidentData.incidentInfo.userFacId),
                isDelete: false,
                status: true
            }).exec(function (err, facilityNotificationsSettings) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.facilityNotificationsSettings = facilityNotificationsSettings;
                    callback(null, finalResponse);
                }
            })
        },
        function (finalResponse, callback) { // send email and sms notifications to all mentioned emails
            if (finalResponse.facilityNotificationsSettings.updateResolvedIncident.status == true) {
                async.eachSeries(finalResponse.facilityNotificationsSettings.updateResolvedIncident.emailsArray, function (notificationData, next) {
                    var baseUrl = config.email.base_url;
                    var options = {
                        template: 'notifyUpdateIncident.html',
                        from: config.email.from,
                        repalcement: {
                            "{{created_date}}": moment(incidentData.incidentInfo.createdAt).format('MM-DD-YYYY'),
                            "{{regarding}}": incidentData.incidentInfo.firstName + ' ' + incidentData.incidentInfo.lastName,
                            "{{concern}}": incidentData.incidentInfo.concern,
                            "{{user.url}}": baseUrl + "/facility/incidentReports",
                            "{{logo_url}}": baseUrl + config.email.logo_url,
                            "{{copyright}}": config.email.copyright,
                            "{{user.login_url}}": baseUrl,
                            "{{link.abuse_email}}": config.email.abuse_email
                        },
                        to: notificationData,
                        subject: 'Update/Resolved Incident'
                    };
                    emailSend.smtp.sendMail(options, function (err, response) {
                        if (err) {
                            next();
                        } else {
                            next();
                        }
                    })
                }, function (err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        var text = "Incident report created At " + moment(incidentData.incidentInfo.createdAt).format('MM-DD-YYYY') + " regarding " + incidentData.incidentInfo.firstName + ' ' + incidentData.incidentInfo.lastName + " whose concern is " + incidentData.incidentInfo.concern + " is updated. To check please visit to the provided link: " + config.email.base_url + "/facility/incidentReports";
                        var smsData = {
                            to: finalResponse.facilityNotificationsSettings.updateResolvedIncident.phoneNumber,
                            from: incidentData.twilioTollFreeNumber,
                            message: text
                        }
                        twilio.sendSMS(smsData, function (returnData) {
                            if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                                finalResponse.twilioInfo = returnData;
                                callback(null, finalResponse);
                            } else {
                                finalResponse.twilioInfo = returnData;
                                callback(null, finalResponse);
                            }
                        });
                    }
                })
            } else {
                callback(null, finalResponse);
            }
        },
        function (finalResponse, callback) { //Save notification sms history
            if (finalResponse.facilityNotificationsSettings.updateResolvedIncident.status == true && finalResponse.twilioInfo.status == config.statusCode.success) {
                var messageBody = finalResponse.twilioInfo.message.toJSON();
                var smsInfo = {};
                smsInfo.userFacId = incidentData.incidentInfo.userFacId;
                smsInfo.to = messageBody.to;
                smsInfo.from = messageBody.from;
                smsInfo.text = messageBody.body;
                smsInfo.type = 'update_incident';
                var notificationSmsHistory = new NotificationSmsHistory(smsInfo);
                notificationSmsHistory.save(function (err, SmsSavedData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            } else {
                callback(null, finalResponse);
            }
        }
    ], function (err, data) {
        if (err) {} else {}
    });
}


/**
 * Function is use to verify incident accept token and accept request
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 8-Sep-2018
 */
function incidentAcceptVerify(req, res){
    var finalResponse = {};
    finalResponse.incidentReportData = {};
    finalResponse.updatedIncidentData = {};

    waterfall([
        function (callback) {// Verify token key is valid
            IncidentReports.findOne({
                verifyIncidentAcceptRejectToken: req.body.verifyIncidentAcceptRejectToken,
                isDelete: false,
                status: true
            }).populate('employeeId').exec(function (err, incidentReportData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (!incidentReportData) {
                        console.log("comes in incident not found token");
                        res.json({
                            code: config.statusCode.invalid,
                            data: {},
                            message: i18n.__("INVALID_URL")
                        });
                    } else {
                        finalResponse.incidentReportData = incidentReportData;
                        callback(null, finalResponse);
                    }
                }
            })
        },
        function (finalResponse, callback) { //Verify employee
            if (finalResponse.incidentReportData.employeeId.isDelete == true || finalResponse.incidentReportData.empAccept == '1' || finalResponse.incidentReportData.empAccept == '2') {
                console.log("another");               
                res.json({
                    code: config.statusCode.serviceUnavailable,
                    data: {},
                    message: i18n.__("LINK_EXPIRED")
                });
            } else {
                IncidentReports.findOneAndUpdate({
                    verifyIncidentAcceptRejectToken: req.body.verifyIncidentAcceptRejectToken
                }, {
                    $set: {
                        empAccept: req.body.acceptIncident,
                    }
                }, function (err, data) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.updatedIncidentData = data;
                        callback(null, finalResponse);
                    }
                });
            }
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("INCIDENT_ACCEPTED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to verify incident reject token and accept request
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 8-Sep-2018
 */
function incidentRejectVerify(req, res){
    var finalResponse = {};
    finalResponse.incidentReportData = {};
    finalResponse.updatedIncidentData = {};

    waterfall([
        function (callback) {// Verify token key is valid
            IncidentReports.findOne({
                verifyIncidentAcceptRejectToken: req.body.verifyIncidentAcceptRejectToken,
                isDelete: false,
                status: true
            }).populate('employeeId').exec(function (err, incidentReportData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (!incidentReportData) {
                        res.json({
                            code: config.statusCode.invalid,
                            data: {},
                            message: i18n.__("INVALID_URL")
                        });
                    } else {
                        finalResponse.incidentReportData = incidentReportData;
                        callback(null, finalResponse);
                    }
                }
            })
        },
        function (finalResponse, callback) { //Verify employee
            if (finalResponse.incidentReportData.employeeId.isDelete == true || finalResponse.incidentReportData.empAccept == '1' || finalResponse.incidentReportData.empAccept == '2') {
                res.json({
                    code: config.statusCode.serviceUnavailable,
                    data: {},
                    message: i18n.__("LINK_EXPIRED")
                });
            } else {
                IncidentReports.findOneAndUpdate({
                    verifyIncidentAcceptRejectToken: req.body.verifyIncidentAcceptRejectToken
                }, {
                    $set: {
                        empAccept: req.body.acceptIncident,
                    }
                }, function (err, data) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.updatedIncidentData = data;
                        callback(null, finalResponse);
                    }
                });
            }
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("INCIDENT_REJECTED_SUCCESSFULLY")
            });
        }
    });
}