'use strict';

var mongoose = require('mongoose'),
    generator = require('generate-password'),
    User = mongoose.model('user'),
    Company = mongoose.model('company'),
    UserCompany = mongoose.model('userCompany'),
    formidable = require('formidable'),
    fs = require('fs-extra'),
    path = require('path'),
    jwt = require('jsonwebtoken'),
    validator = require('validator'),
    utility = require('../lib/utility.js'),
    crypto = require('./../lib/crypto.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    Joi = require('joi'),
    i18n = require("i18n"),
    moment = require('moment'),
    emailSend = __rootRequire('api/core/email'),
    convert = require('xml-js'),
    zipcodes = require('zipcodes'),
    Facility = mongoose.model('facility'),
    CheckInOut = mongoose.model('checkInOut'),
    IncidentReports = mongoose.model('incidentReport'),
    config = require('../../config/config.js');

module.exports = {
    getAllCompanyUsersList: getAllCompanyUsersList,
    addCompanyUser: addCompanyUser,
    getCompanyUserById: getCompanyUserById,
    updateCompanyUser: updateCompanyUser,
    deleteCompanyUser: deleteCompanyUser,
    activateDeactivateCompanyUser: activateDeactivateCompanyUser
}

/**
 * Function is use to get all users of company
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 8-Aug-2018
 */
function getAllCompanyUsersList(req, res) {
    var finalResponse = {};
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);

    waterfall([
        function (callback) { //Company User Data

            var condition = {};
            condition.isDelete = false;
            condition['userCmpInfo.isDelete'] = false;
            condition['userCmpInfo.companyId'] = mongoose.Types.ObjectId(req.user.cmpId);
            condition['isDelete'] = false;
            condition['role'] = config.role_type.COMPANY_USER.name;
                
            var searchText = decodeURIComponent(req.body.searchText.trim()).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            if (searchText != undefined && searchText != 'undefined') { 
                console.log("searchText searchText", searchText);
                condition.$or = [{
                        'firstName': new RegExp(searchText, 'gi')
                    },
                    {
                        'lastName': new RegExp(searchText, 'gi')
                    },
                    {
                        'userName': new RegExp(searchText, 'gi')
                    },
                    {
                        'phoneNumber': new RegExp(searchText, 'gi')
                    },
                    {
                        'email': new RegExp(searchText, 'gi')
                    }
                ];
            }

            if (req.body.createdAt) {
                var start_day_date = moment(req.body.createdAt).startOf('day');
                var end_day_date = moment(req.body.createdAt).endOf('day');
                var momentObjFrom = new Date(moment(start_day_date));
                var momentObjTo = new Date(moment(end_day_date));
                condition.$and = [{
                        createdAt: {
                            $gte: momentObjFrom
                        }
                    },
                    {
                        createdAt: {
                            $lte: momentObjTo
                        }
                    }
                ];

            }

            if (req.body.userName) {
                condition['userName'] = new RegExp(req.body.userName.trim(), 'gi');
            }
            if (req.body.phoneNumber) {
                condition['phoneNumber'] = new RegExp((req.body.phoneNumber).trim(), 'gi');
            }

            if (req.body.email) {
                condition['email'] = new RegExp(req.body.email.trim(), 'gi');
            }
            var aggregate = [{
                    $lookup: {
                        from: 'usercompanies',
                        localField: "_id",
                        foreignField: "userId",
                        as: "userCmpInfo"
                    }
                },
                {
                    $unwind: "$userCmpInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "createdAt": "$createdAt",
                    "userName": "$userName",
                    "phoneNumber": "$phoneNumber",
                    "status": "$status",
                    "userCmpId": "$userCmpInfo._id",
                    "image": "$image",
                    "email": "$email",
                    "password": "$password"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            aggregate.push({
                $sort: sorting
            });
            aggregate.push({
                $skip: parseInt(skip)
            });
            aggregate.push({
                $limit: parseInt(count)
            });
            User.aggregate(aggregate).then(function (userData) {
                for (var i = 0; i < userData.length; i++) {
                    userData[i].password = utility.getDecryptText(userData[i].password)
                }
                var data = {};
                data.data = userData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                User.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    data.total_count = cnt;
                    callback(null, data);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        // console.log("err, data", err, data);
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to add company user 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 8-Aug-2018
 */
function addCompanyUser(req, res) {
    
    var finalResponse = {};
    finalResponse.userData = {};
    finalResponse.verifyToken = '';
    finalResponse.verifingLink = '';
    var userObj = {
        firstName: req.swagger.params.firstName.value,
        lastName: req.swagger.params.lastName.value,
        email: req.swagger.params.email.value,
        phoneNumber: req.swagger.params.phoneNumber.value,
        file: req.swagger.params.file.value
    }

    console.log("addCompanyUser", userObj);
    if (!userObj.firstName || !userObj.lastName || !userObj.email || !userObj.phoneNumber) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else if (userObj.email && !config.isEmail(userObj.email)) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("INVALID_EMAIL")
        });
    } else {
        waterfall([
            function (callback) { //Check for already exist email of user
                User.existCheck(userObj.email.trim().toLowerCase(), '', function (err, emailExist) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (!emailExist) {
                            res.json({
                                code: config.statusCode.badRequest,
                                data: {},
                                message: i18n.__("EMAIL_ALREADY_EXIST")
                            });
                        } else {
                            callback(null, finalResponse);
                        }
                    }
                });
            },
            function (finalResponse, callback) { //Save User data
                var randomPassword = generator.generate({
                    length: 10,
                    numbers: true
                });
                var passEnc = utility.getEncryptText(randomPassword.toString()); //crypto need string in parameter

                var obj = {
                    firstName: userObj.firstName,
                    lastName: userObj.lastName,
                    userName: userObj.firstName + ' ' + userObj.lastName,
                    role: config.role_type.COMPANY_USER.name,
                    createdBy: req.user.role,
                    createdById: req.user.uid,
                    phoneNumber: userObj.phoneNumber,
                    email: userObj.email.toLowerCase(),
                    password: passEnc
                };

                var userRecord = new User(obj);
                userRecord.save(function (err, userSavedData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.userSavedData = userSavedData;
                        if (userObj.file) { //Save company user profile if file exist
                            var timestamp = Number(new Date()); // current time as number
                            var file = userObj.file;
                            var userId = req.user.uid;
                            var splitFileName = file.originalname.split('.');
                            var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                            var filename = userId + '_' + timestamp + '.' + ext;
                            var imagePath = "./../client/src/assets/upload/profiles/" + filename; //Used for write file on this path
                            var base_url = config.server_url;

                            utility.fileUpload(path.resolve(imagePath), file.buffer).then(function () {
                                userSavedData.image = filename;
                                userSavedData.save(function (err, updateUserImage) {
                                    if (err) {
                                        callback(err, false);
                                    } else {
                                        callback(null, finalResponse);
                                    }
                                })
                            })
                        } else {
                            callback(null, finalResponse);
                        }
                    }
                });
            },
            function (finalResponse, callback) { //Save User company data
                var userCmpData = {
                    userId: finalResponse.userSavedData._id,
                    companyId: req.user.cmpId
                };
                var userCompanyRecord = new UserCompany(userCmpData);
                userCompanyRecord.save(function (err, userCompanySavedData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.userCompanySavedData = userCompanySavedData;
                        callback(null, finalResponse);
                    }
                });
            },
            function (finalResponse, callback) { //Create verify link and token to verify the company user
                var date = new Date();
                finalResponse.verifyToken = utility.getEncryptText(Math.random().toString(4).slice(2) + date.getTime());
                finalResponse.verifingLink = config.email.base_url + '/verify_account/' + finalResponse.verifyToken;

                User.findOneAndUpdate({
                    _id: finalResponse.userSavedData._id
                }, {
                    $set: {
                        verifyToken: finalResponse.verifyToken
                    }
                }, function (err, updatedUserdata) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            },
            function (finalResponse, callback) { //Send Email to User for verify Account
                var baseUrl = config.email.base_url;
                var options = {
                    template: 'verifyAccount.html',
                    from: config.email.from,
                    repalcement: {
                        "{{user.name}}": finalResponse.userSavedData.firstName.charAt(0).toUpperCase() + finalResponse.userSavedData.firstName.slice(1).toLowerCase() + ' ' + finalResponse.userSavedData.lastName.charAt(0).toUpperCase() + finalResponse.userSavedData.lastName.slice(1).toLowerCase(),
                        "{{user.email}}": finalResponse.userSavedData.email,
                        "{{user.password}}": utility.getDecryptText(finalResponse.userSavedData.password),
                        "{{user.url}}": finalResponse.verifingLink,
                        "{{logo_url}}": baseUrl + config.email.logo_url,
                        "{{copyright}}": config.email.copyright,
                        "{{user.login_url}}": baseUrl,
                        "{{link.abuse_email}}": config.email.abuse_email
                    },
                    to: finalResponse.userSavedData.email,
                    subject: 'Verify Account'
                };
                emailSend.smtp.sendMail(options, function (err, response) {
                    if (err) {
                        callback(null, finalResponse);
                    } else {
                        callback(null, finalResponse);
                    }
                })
            }
        ],
        function (err, data) {
            // console.log("err, data", err, data);
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: data,
                    message: i18n.__("COMPANY_USER_CREATED_SUCCESSFULLY")
                });
            }
        });
    }
}

/**
 * Function is get company user by id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 08-Aug-2018
 */
function getCompanyUserById(req, res) {
    var finalResponse = {};
    var condition = {};
    if (mongoose.Types.ObjectId.isValid(req.query.id)) {
        User.findById(mongoose.Types.ObjectId(req.query.id), {
            firstName: 1,
            lastName: 1,
            phoneNumber: 1,
            email: 1,
            image: 1
        }).exec(function (err, userData) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {                
                res.json({
                    code: config.statusCode.success,
                    data: userData,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }
        })
    } else {
        res.json({
            code: config.statusCode.invalid,
            data: {},
            message: i18n.__("INVALID_URL")
        });
    }
}

/**
 * Function is use to update company user info by id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 08-Aug-2018
 */
function updateCompanyUser(req, res) {
    var email = req.body.email.trim().toLowerCase();
    var finalResponse = {};
    finalResponse.userData = {};
    finalResponse.userFacilityData = {};
    var userObj = {
        firstName: req.swagger.params.firstName.value,
        lastName: req.swagger.params.lastName.value,
        email: req.swagger.params.email.value,
        phoneNumber: req.swagger.params.phoneNumber.value,
        file: req.swagger.params.file.value,
        _id: req.swagger.params._id.value
    }
    waterfall([
        function (callback) { //check email and facility name is already exist
            User.findOne({
                email: userObj.email.trim().toLowerCase(),
                _id: {
                    $ne: userObj._id
                },
                isDelete: false
            }).lean().exec(function (err, userData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (userData) {
                        res.json({
                            code: config.statusCode.badRequest,
                            data: {},
                            message: i18n.__("EMAIL_ALREADY_EXIST")
                        });
                    } else {
                        callback(null, finalResponse);
                    }
                }
            });
        },
        function (finalResponse, callback) { //Update user record

            User.findById(userObj._id).exec(function (err, data) {
                if (err) {
                    callback(err, false);
                } else {
                    console.log("userObj=---data---", data);
                    data.firstName = userObj.firstName;
                    data.lastName = userObj.lastName;
                    data.userName = userObj.firstName + ' ' + userObj.lastName,
                    data.email = userObj.email;
                    data.phoneNumber = userObj.phoneNumber;
                    data.modifiedBy = req.user.role;
                    data.modifiedById = req.user.uid;
                    data.save(function (err, updatedUserData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.userData = data;
                            if (userObj.file) { //Update logo if exist
                                var timestamp = Number(new Date()); // current time as number
                                var file = userObj.file;
                                var userId = req.user.uid;
                                var splitFileName = file.originalname.split('.');
                                var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                                var filename = userId + '_' + timestamp + '.' + ext;
                                var imagePath = "./../client/src/assets/upload/profiles/" + filename;
                                var base_url = config.server_url;

                                utility.fileUpload(path.resolve(imagePath), file.buffer).then(function () {
                                    updatedUserData.image = filename;
                                    updatedUserData.save(function (err, updateUserImage) {
                                        if (err) {
                                            callback(err, false);
                                        } else {
                                            callback(null, finalResponse);
                                        }
                                    })
                                })
                            } else {
                                callback(null, finalResponse);
                            }
                        }
                    })
                }
            });
        },
    ], function (err, data) {
        // console.log("data=------", err, data);
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("UPDATED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to delete company user account 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 08-Aug-2018
 */
function deleteCompanyUser(req, res) {
    var finalResponse = {};
    waterfall([
        function (callback) { //delete user record
            User.findOneAndUpdate({
                _id: req.body.userId
            }, {
                $set: {
                    isDelete: true,
                    isDeletedBy: req.user.role,
                    isDeletedById: req.user.uid
                }
            }, function (err, userfacdata) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //delete user facility
            UserCompany.findOneAndUpdate({
                _id: req.body.userCmpId
            }, {
                $set: {
                    isDelete: true,
                }
            }, function (err, userCmpdata) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },

    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("COMPANY_USER_ACCOUNT_DELETED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to activate-deactivate company user account 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 08-Aug-2018
 */
function activateDeactivateCompanyUser(req, res) {
    var finalResponse = {};
    waterfall([
        function (callback) { //Activate deactivate user facility
            UserCompany.findOneAndUpdate({
                _id: req.body.userCmpId
            }, {
                $set: {
                    status: req.body.status,
                }
            }, function (err, userCmpdata) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Activate deactivate user record
            if (req.body.status == '1') {
                if (req.body.by == 'company_admin') {
                    var userObj = {
                        isActivatedBy: config.role_type.COMPANY_ADMIN.name,
                        isActivatedById: req.user.uid,
                        status: '1'
                    }
                } else {
                    var userObj = {
                        isActivatedBy: config.role_type.COMPANY_ADMIN.name,
                        isActivatedById: req.user.uid,
                        status: '1'
                    }

                }
            } else {
                var userObj = {
                    isDeactivatedBy: req.user.role,
                    isDeactivatedById: req.user.uid,
                    status: '2'
                }
            }
            User.findOneAndUpdate({
                _id: req.body.userId
            }, {
                $set: userObj
            }, function (err, userfacdata) {
                if (err) {
                    callback(err, false);
                } else {
                    if (req.body.by == 'company_admin') {
                        UserCompany.findById(req.body.userCmpId).populate('userId').exec(function (err, data) {
                            if (err) {
                                callback(err, false);
                            } else {
                                var baseUrl = config.email.base_url;
                                var options = {
                                    template: 'verifiedAccountBySuperAdmin.html',
                                    from: config.email.from,
                                    repalcement: {
                                        "{{user.name}}": data.userId.firstName.charAt(0).toUpperCase() + data.userId.firstName.slice(1).toLowerCase() + ' ' + data.userId.lastName.charAt(0).toUpperCase() + data.userId.lastName.slice(1).toLowerCase(),
                                        "{{user.email}}": data.userId.email,
                                        "{{user.password}}": utility.getDecryptText(data.userId.password),
                                        "{{user.url}}": finalResponse.verifingLink,
                                        "{{logo_url}}": baseUrl + config.email.logo_url,
                                        "{{copyright}}": config.email.copyright,
                                        "{{user.login_url}}": baseUrl,
                                        "{{link.abuse_email}}": config.email.abuse_email
                                    },
                                    to: data.userId.email,
                                    subject: 'Verified Account By Repute'
                                };
                                emailSend.smtp.sendMail(options, function (err, response) {
                                    if (err) {
                                        callback(null, finalResponse);
                                    } else {
                                        callback(null, finalResponse);
                                    }
                                })
                            }
                        })

                    } else {
                        callback(null, finalResponse);
                    }
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__('User ' + ((req.body.status == 1) ? 'activated' : 'deactivated') + ' successfully')
            });
        }
    });
}