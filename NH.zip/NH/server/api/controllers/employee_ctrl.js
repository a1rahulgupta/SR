'use strict';

var mongoose = require('mongoose'),
    generator = require('generate-password'),
    formidable = require('formidable'),
    fs = require('fs-extra'),
    path = require('path'),
    jwt = require('jsonwebtoken'),
    validator = require('validator'),
    utility = require('../lib/utility.js'),
    crypto = require('./../lib/crypto.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    i18n = require("i18n"),
    moment = require('moment'),

    //require collections
    User = mongoose.model('user'),
    Facility = mongoose.model('facility'),
    UserFacility = mongoose.model('userFacility'),
    DefaultEmployeePermission = mongoose.model('defaultEmployeePermission'),
    Permission = mongoose.model('permission'),

    //require files
    emailSend = __rootRequire('api/core/email'),
    convert = require('xml-js'),
    config = require('../../config/config.js');

module.exports = {
    getAllEmployeeList: getAllEmployeeList,
    addEmployee: addEmployee,
    getEmployeeById: getEmployeeById,
    updateEmployee: updateEmployee,
    deleteEmployee: deleteEmployee,
    activateDeactivateEmployee: activateDeactivateEmployee,
    getEmployeePermissions: getEmployeePermissions,
    updateEmployeePermission: updateEmployeePermission
}

/**
 * Function is use to add employee 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 7-May-2018
 */
function addEmployee(req, res) {

    var finalResponse = {};
    finalResponse.userData = {};
    finalResponse.userSavedData = {};
    finalResponse.userFacilityData = {};
    finalResponse.userFacilitySavedData = {};
    finalResponse.defaultEmpPerData = {};
    finalResponse.verifyToken = '';
    finalResponse.verifingLink = '';
    var empObj = {
        firstName: req.swagger.params.firstName.value,
        lastName: req.swagger.params.lastName.value,
        email: req.swagger.params.email.value,
        phoneNumber: req.swagger.params.phoneNumber.value,
        file: req.swagger.params.file.value
    }

    if (!empObj.firstName || !empObj.lastName || !empObj.email || !empObj.phoneNumber) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else if (empObj.email && !config.isEmail(empObj.email)) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("INVALID_EMAIL")
        });
    } else {
        waterfall([
                function (callback) { //Check for already exist email of user
                    User.existCheck(empObj.email.trim().toLowerCase(), '', function (err, emailExist) {
                        if (err) {
                            callback(err, false);
                        } else {
                            if (!emailExist) {
                                res.json({
                                    code: config.statusCode.badRequest,
                                    data: {},
                                    message: i18n.__("EMAIL_ALREADY_EXIST")
                                });
                            } else {
                                callback(null, finalResponse);
                            }
                        }
                    });
                },
                function (finalResponse, callback) { //Save User data
                    var randomPassword = generator.generate({
                        length: 10,
                        numbers: true
                    });
                    var passEnc = utility.getEncryptText(randomPassword.toString()); //crypto need string in parameter

                    var obj = {
                        firstName: empObj.firstName,
                        lastName: empObj.lastName,
                        userName: empObj.firstName + ' ' + empObj.lastName,
                        role: config.role_type.EMPLOYEE.name,
                        createdBy: req.user.role,
                        createdById: req.user.uid,
                        phoneNumber: empObj.phoneNumber,
                        email: empObj.email.toLowerCase(),
                        password: passEnc
                    };

                    var userRecord = new User(obj);
                    userRecord.save(function (err, userSavedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.userSavedData = userSavedData;
                            if (empObj.file) { //Save facility logo if file exist
                                var timestamp = Number(new Date()); // current time as number
                                var file = empObj.file;
                                var userId = req.user.uid;
                                var splitFileName = file.originalname.split('.');
                                var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                                var filename = userId + '_' + timestamp + '.' + ext;
                                var imagePath = "./../client/src/assets/upload/profiles/" + filename; //Used for write file on this path
                                var base_url = config.server_url;

                                utility.fileUpload(path.resolve(imagePath), file.buffer).then(function () {
                                    userSavedData.image = filename;
                                    userSavedData.save(function (err, updateUserImage) {
                                        if (err) {
                                            callback(err, false);
                                        } else {
                                            callback(null, finalResponse);
                                        }
                                    })
                                })
                            } else {
                                callback(null, finalResponse);
                            }
                        }
                    });
                },
                function (finalResponse, callback) { //Save User facility data
                    var userFacilityData = {
                        userId: finalResponse.userSavedData._id,
                        facilityId: req.user.facId
                    };
                    var userFacilityRecord = new UserFacility(userFacilityData);
                    userFacilityRecord.save(function (err, userFacilitySavedData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.userFacilitySavedData = userFacilitySavedData;
                            callback(null, finalResponse);
                        }
                    });
                },
                function (finalResponse, callback) { //get default employee permission
                    DefaultEmployeePermission.findOne({
                        name: config.role_type.EMPLOYEE.name,
                        status: true
                    }).lean().exec(function (err, defaultEmpPerData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.defaultEmpPerData = defaultEmpPerData;
                            callback(null, finalResponse);
                        }
                    });
                },
                function (finalResponse, callback) { //save default employee permission
                    var permissionData = {
                        userId: finalResponse.userFacilitySavedData.userId,
                        facId: finalResponse.userFacilitySavedData.facilityId,
                        userFacId: finalResponse.userFacilitySavedData._id,
                        visitors: finalResponse.defaultEmpPerData.visitors,
                        newsFeed: finalResponse.defaultEmpPerData.newsFeed,
                        kiosk: finalResponse.defaultEmpPerData.kiosk,
                        employee: finalResponse.defaultEmpPerData.employee,
                        dashboard: finalResponse.defaultEmpPerData.dashboard,
                        incidentClaimReports: finalResponse.defaultEmpPerData.incidentClaimReports,
                        googleLink: finalResponse.defaultEmpPerData.googleLink,
                        settings: finalResponse.defaultEmpPerData.settings
                    };
                    var permissionRecord = new Permission(permissionData);
                    permissionRecord.save(function (err, permissionData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                },
                function (finalResponse, callback) { //Create verify link and token to verify the facility
                    var date = new Date();
                    finalResponse.verifyToken = utility.getEncryptText(Math.random().toString(4).slice(2) + date.getTime());
                    finalResponse.verifingLink = config.email.base_url + '/verify_account/' + finalResponse.verifyToken;

                    User.findOneAndUpdate({
                        _id: finalResponse.userSavedData._id
                    }, {
                        $set: {
                            verifyToken: finalResponse.verifyToken
                        }
                    }, function (err, updatedUserdata) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                },
                function (finalResponse, callback) { //Send Email to User for verify Account
                    var baseUrl = config.email.base_url;
                    var options = {
                        template: 'verifyAccount.html',
                        from: config.email.from,
                        repalcement: {
                            "{{user.name}}": finalResponse.userSavedData.firstName.charAt(0).toUpperCase() + finalResponse.userSavedData.firstName.slice(1).toLowerCase() + ' ' + finalResponse.userSavedData.lastName.charAt(0).toUpperCase() + finalResponse.userSavedData.lastName.slice(1).toLowerCase(),
                            "{{user.email}}": finalResponse.userSavedData.email,
                            "{{user.password}}": utility.getDecryptText(finalResponse.userSavedData.password),
                            "{{user.url}}": finalResponse.verifingLink,
                            "{{logo_url}}": baseUrl + config.email.logo_url,
                            "{{copyright}}": config.email.copyright,
                            "{{user.login_url}}": baseUrl,
                            "{{link.abuse_email}}": config.email.abuse_email
                        },
                        to: finalResponse.userSavedData.email,
                        subject: 'Verify Account'
                    };
                    emailSend.smtp.sendMail(options, function (err, response) {
                        if (err) {
                            callback(null, finalResponse);
                        } else {
                            callback(null, finalResponse);
                        }
                    })
                }
            ],
            function (err, data) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: data,
                        message: i18n.__("EMPLOYEE_CREATED_SUCCESSFULLY")
                    });
                }
            });
    }
}

/**
 * Function is use to fetch facility list for admin
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 3-May-2018
 */
function getAllEmployeeList(req, res) {
    var finalResponse = {};
    var orgData = {};
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);

    waterfall([
        function (callback) { //Company Data

            var condition = {};
            condition.isDelete = false;
            condition['userFacInfo.isDelete'] = false;
            condition['userFacInfo.facilityId'] = mongoose.Types.ObjectId(req.user.facId);
            condition['isDelete'] = false;
            condition['role'] = config.role_type.EMPLOYEE.name;

            var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            if (searchText != undefined && searchText != 'undefined') {
                condition.$or = [{
                        'firstName': new RegExp(searchText, 'gi')
                    },
                    {
                        'lastName': new RegExp(searchText, 'gi')
                    },
                    {
                        'userName': new RegExp(searchText, 'gi')
                    },
                    {
                        'phoneNumber': new RegExp(searchText, 'gi')
                    }
                ];
            }

            if (req.body.createdAt) {
                var start_day_date = moment(req.body.createdAt).startOf('day');
                var end_day_date = moment(req.body.createdAt).endOf('day');
                var momentObjFrom = new Date(moment(start_day_date));
                var momentObjTo = new Date(moment(end_day_date));
                condition.$and = [{
                        createdAt: {
                            $gte: momentObjFrom
                        }
                    },
                    {
                        createdAt: {
                            $lte: momentObjTo
                        }
                    }
                ];

            }

            if (req.body.userName) {
                condition['userName'] = new RegExp(req.body.userName, 'gi');
            }
            if (req.body.phoneNumber) {
                condition['phoneNumber'] = new RegExp(req.body.phoneNumber, 'gi');
            }
            var aggregate = [{
                    $lookup: {
                        from: 'userfacilities',
                        localField: "_id",
                        foreignField: "userId",
                        as: "userFacInfo"
                    }
                },
                {
                    $unwind: "$userFacInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "createdAt": "$createdAt",
                    "userName": "$userName",
                    "phoneNumber": "$phoneNumber",
                    "status": "$status",
                    "userFacId": "$userFacInfo._id",
                    "image": "$image",
                    "email": "$email",
                    "password": "$password"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            aggregate.push({
                $sort: sorting
            });
            aggregate.push({
                $skip: parseInt(skip)
            });
            aggregate.push({
                $limit: parseInt(count)
            });
            User.aggregate(aggregate).then(function (userData) {
                for (var i = 0; i < userData.length; i++) {
                    userData[i].password = utility.getDecryptText(userData[i].password)

                }
                var data = {};
                data.data = userData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                User.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    data.total_count = cnt;
                    callback(null, data);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to Export Xml
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 3-May-2018
 */

function exportXml(req, res) {
    var xmlData = req.body;
    var options = {
        compact: true,
        spaces: 4
    };
    var result = convert.json2xml(xmlData, options);
    if (result) {
        res.json({
            code: config.statusCode.success,
            data: result
        });
    }
}

/**
 * Function is get employee by id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 07-May-2018
 */
function getEmployeeById(req, res) {
    var finalResponse = {};
    var condition = {};
    if (mongoose.Types.ObjectId.isValid(req.query.id)) {
        User.findById(mongoose.Types.ObjectId(req.query.id), {
            firstName: 1,
            lastName: 1,
            phoneNumber: 1,
            email: 1,
            image: 1
        }).exec(function (err, userData) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: userData,
                    message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                });
            }
        }).catch(function (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        });
    } else {
        res.json({
            code: config.statusCode.invalid,
            data: {},
            message: i18n.__("INVALID_URL")
        });
    }
}

/**
 * Function is use to update employee info by id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 07-May-2018
 */
function updateEmployee(req, res) {
    var email = req.body.email.trim().toLowerCase();
    var finalResponse = {};
    finalResponse.userData = {};
    finalResponse.userFacilityData = {};
    var empObj = {
        firstName: req.swagger.params.firstName.value,
        lastName: req.swagger.params.lastName.value,
        email: req.swagger.params.email.value,
        phoneNumber: req.swagger.params.phoneNumber.value,
        file: req.swagger.params.file.value,
        _id: req.swagger.params._id.value
    }
    console.log("empObj=------", empObj);
    waterfall([
        function (callback) { //check email and facility name is already exist
            User.findOne({
                email: empObj.email.trim().toLowerCase(),
                _id: {
                    $ne: empObj._id
                },
                isDelete: false
            }).lean().exec(function (err, userData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (userData) {
                        res.json({
                            code: config.statusCode.badRequest,
                            data: {},
                            message: i18n.__("EMAIL_ALREADY_EXIST")
                        });
                    } else {
                        callback(null, finalResponse);
                    }
                }
            });
        },
        function (finalResponse, callback) { //Update user record

            User.findById(empObj._id).exec(function (err, data) {
                if (err) {
                    callback(err, false);
                } else {
                    console.log("empObj=---data---", data);
                    data.firstName = empObj.firstName;
                    data.lastName = empObj.lastName;
                    data.userName = empObj.firstName + ' ' + empObj.lastName,
                        data.email = empObj.email;
                    data.phoneNumber = empObj.phoneNumber;
                    data.modifiedBy = req.user.role;
                    data.modifiedById = req.user.uid;
                    data.save(function (err, updatedUserData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.userData = data;
                            if (empObj.file) { //Update logo if exist
                                var timestamp = Number(new Date()); // current time as number
                                var file = empObj.file;
                                var userId = req.user.uid;
                                var splitFileName = file.originalname.split('.');
                                var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                                var filename = userId + '_' + timestamp + '.' + ext;
                                var imagePath = "./../client/src/assets/upload/profiles/" + filename;
                                var base_url = config.server_url;

                                utility.fileUpload(path.resolve(imagePath), file.buffer).then(function () {
                                    updatedUserData.image = filename;
                                    updatedUserData.save(function (err, updateUserImage) {
                                        if (err) {
                                            callback(err, false);
                                        } else {
                                            callback(null, finalResponse);
                                        }
                                    })
                                })
                            } else {
                                callback(null, finalResponse);
                            }
                        }
                    })
                }
            });
        },
        function (finalResponse, callback) { //Update user facility record
            UserFacility.findOne({
                userId: finalResponse.userData._id
            }).exec(function (err, foundUserFacilityData) {
                if (err) {
                    callback(err, false);
                } else {
                    foundUserFacilityData.userId = finalResponse.userData._id;
                    foundUserFacilityData.save(function (err, updateUserfacData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    })
                }
            })
        },
    ], function (err, data) {
        console.log("data=------", data);
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("UPDATED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to delete employee account 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 07-May-2018
 */
function deleteEmployee(req, res) {
    var finalResponse = {};
    waterfall([
        function (callback) { //delete user record
            User.findOneAndUpdate({
                _id: req.body.userId
            }, {
                $set: {
                    isDelete: true,
                    isDeletedBy: req.user.role,
                    isDeletedById: req.user.uid
                }
            }, function (err, userfacdata) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //delete user facility
            UserFacility.findOneAndUpdate({
                _id: req.body.userFacId
            }, {
                $set: {
                    isDelete: true,
                }
            }, function (err, userfacdata) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },

    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("EMPLOYEE_ACCOUNT_DELETED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to activate-deactivate employee account 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 07-May-2018
 */
function activateDeactivateEmployee(req, res) {
    var finalResponse = {};
    waterfall([
        function (callback) { //Activate deactivate user facility
            UserFacility.findOneAndUpdate({
                _id: req.body.userFacId
            }, {
                $set: {
                    status: req.body.status,
                }
            }, function (err, userfacdata) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Activate deactivate user record
            if (req.body.status == '1') {
                if (req.body.by == 'super_admin') {
                    var userObj = {
                        isActivatedBy: config.role_type.SUPER_ADMIN.name,
                        isActivatedById: req.user.uid,
                        status: '1'
                    }
                } else {
                    var userObj = {
                        isActivatedBy: config.role_type.SUPER_ADMIN.name,
                        isActivatedById: req.user.uid,
                        status: '1'
                    }

                }
            } else {
                var userObj = {
                    isDeactivatedBy: req.user.role,
                    isDeactivatedById: req.user.uid,
                    status: '2'
                }
            }
            User.findOneAndUpdate({
                _id: req.body.userId
            }, {
                $set: userObj
            }, function (err, userfacdata) {
                if (err) {
                    callback(err, false);
                } else {
                    if (req.body.by == 'super_admin') {
                        UserFacility.findById(req.body.userFacId).populate('userId').exec(function (err, data) {
                            if (err) {
                                callback(err, false);
                            } else {
                                var baseUrl = config.email.base_url;
                                var options = {
                                    template: 'verifiedAccountBySuperAdmin.html',
                                    from: config.email.from,
                                    repalcement: {
                                        "{{user.name}}": data.userId.firstName.charAt(0).toUpperCase() + data.userId.firstName.slice(1).toLowerCase() + ' ' + data.userId.lastName.charAt(0).toUpperCase() + data.userId.lastName.slice(1).toLowerCase(),
                                        "{{user.email}}": data.userId.email,
                                        "{{user.password}}": utility.getDecryptText(data.userId.password),
                                        "{{user.url}}": finalResponse.verifingLink,
                                        "{{logo_url}}": baseUrl + config.email.logo_url,
                                        "{{copyright}}": config.email.copyright,
                                        "{{user.login_url}}": baseUrl,
                                        "{{link.abuse_email}}": config.email.abuse_email
                                    },
                                    to: data.userId.email,
                                    subject: 'Verified Account By Repute'
                                };
                                emailSend.smtp.sendMail(options, function (err, response) {
                                    if (err) {
                                        callback(null, finalResponse);
                                    } else {
                                        callback(null, finalResponse);
                                    }
                                })
                            }
                        })

                    } else {
                        callback(null, finalResponse);
                    }
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__('Employee ' + ((req.body.status == 1) ? 'activated' : 'deactivated') + ' successfully')
            });
        }
    });
}

/**
 * Function is used to get employee permission
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 9-June-2018
 */
function getEmployeePermissions(req, res) {
    console.log("getEmployeePermissions", req.body);
    if (!req.body.employeeId) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else {
        var condition = {
            userId: mongoose.Types.ObjectId(req.body.employeeId),
            facId: mongoose.Types.ObjectId(req.user.facId),
            isDelete: false
        }
        Permission.findOne(condition, {
            updatedAt: 0,
            createdAt: 0,
            __v: 0,
            isDelete: 0,
            status: 0,
            userId: 0,
            facId: 0,
            userFacId: 0
        }).exec(function (err, permissionData) {
            console.log("permissionData", permissionData);
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                if (!permissionData) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: permissionData,
                        message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                    });
                }
            }
        });
    }

}

/**
 * Function is used to update employee permission
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 9-June-2018
 */
function updateEmployeePermission(req, res) {
    Permission.findOneAndUpdate({
        _id: req.body._id
    }, {
        $set: {
            employee: req.body.employee,
            kiosk: req.body.kiosk,
            newsFeed: req.body.newsFeed,
            visitors: req.body.visitors,
            dashboard: req.body.dashboard,
            incidentClaimReports: req.body.incidentClaimReports,
            googleLink: req.body.googleLink,
            settings: req.body.settings
        }
    }, function (err, updatedEmployeePermissions) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("EMPLOYEE_PERMISSION_UPDATED")
            });
        }
    });

}