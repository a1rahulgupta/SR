'use strict';

var mongoose = require('mongoose'),
    generator = require('generate-password'),
    formidable = require('formidable'),
    fs = require('fs-extra'),
    path = require('path'),
    jwt = require('jsonwebtoken'),
    validator = require('validator'),
    utility = require('../lib/utility.js'),
    crypto = require('./../lib/crypto.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    i18n = require("i18n"),
    moment = require('moment'),
    twilio = require('./../lib/twilio.js'),

    //require collections
    User = mongoose.model('user'),
    Facility = mongoose.model('facility'),
    UserFacility = mongoose.model('userFacility'),
    SubLogin = mongoose.model('subLogin'),
    AppSettings = mongoose.model('appSettings'),        
    FacilityAppSettings = mongoose.model('facilityAppSettings'),    
    RatingResponseSettings = mongoose.model('ratingResponseSettings'),    
    FacilityRatingResponseSettings = mongoose.model('facilityRatingResponseSettings'),    
    SmsSettings = mongoose.model('smsSettings'),    
    FacilitySmsSettings = mongoose.model('facilitySmsSettings'), 
    NotificationSettings = mongoose.model('notificationSettings'),        
    FacilityNotificationSettings = mongoose.model('facilityNotificationSettings'),   
    IncidentReports = mongoose.model('incidentReport'),
    NotificationSmsHistory = mongoose.model('notificationSmsHistory'),     

    //require files
    emailSend = __rootRequire('api/core/email'),
    convert = require('xml-js'),
    config = require('../../config/config.js');

module.exports = {
    getSettingsStatus: getSettingsStatus,
    updateAppSetting: updateAppSetting,
    updateSMSSetting: updateSMSSetting,
    updateRatingResponseSetting: updateRatingResponseSetting,
    updateNotificationSetting: updateNotificationSetting,
    sendOpenIncidentsNotification: sendOpenIncidentsNotification,
    sendCustomOpenIncidentsNotification: sendCustomOpenIncidentsNotification
}

/**
 * Function is use to get setting status
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 15-June-2018
 */
function getSettingsStatus(req, res) {
    if (!req.body.selectType || req.body.selectType == null || req.body.selectType == undefined || req.body.selectType =='' ) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else {
        var finalResponse = {};
        switch (req.body.selectType) {
            case config.settingModuleSelectType.APP_STATUS:
                break;
            case config.settingModuleSelectType.APP_SETTINGS:
                FacilityAppSettings.findOne({
                    userFacId: mongoose.Types.ObjectId(req.user.userFacId),
                    facId: mongoose.Types.ObjectId(req.user.facId),
                    isDelete: false,
                    status: true
                }).lean().exec(function(err, appSettingsData){
                    if(err){
                        res.json({
                            code: config.statusCode.error,
                            data: {},
                            message: i18n.__("INTERNAL_ERROR")
                        });
                    }else{
                        // console.log("appSettingsData", appSettingsData);
                        res.json({
                            code: config.statusCode.success,
                            data: appSettingsData,
                            message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                        });
                    }
                })
                break;
            case config.settingModuleSelectType.SMS_SETTINGS:   
                FacilitySmsSettings.findOne({
                    userFacId: mongoose.Types.ObjectId(req.user.userFacId),
                    facId: mongoose.Types.ObjectId(req.user.facId),
                    isDelete: false,
                    status: true
                }).lean().exec(function(err, smsSettingsData){
                    if(err){
                        res.json({
                            code: config.statusCode.error,
                            data: {},
                            message: i18n.__("INTERNAL_ERROR")
                        });
                    }else{
                        res.json({
                            code: config.statusCode.success,
                            data: smsSettingsData,
                            message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                        });
                    }
                })
                break;
            case config.settingModuleSelectType.RATING_RESPONSE_SETTINGS:       
                FacilityRatingResponseSettings.findOne({
                    userFacId: mongoose.Types.ObjectId(req.user.userFacId),
                    facId: mongoose.Types.ObjectId(req.user.facId),
                    isDelete: false,
                    status: true
                }).lean().exec(function(err, ratingResSettingsData){
                    if(err){
                        res.json({
                            code: config.statusCode.error,
                            data: {},
                            message: i18n.__("INTERNAL_ERROR")
                        });
                    }else{
                        res.json({
                            code: config.statusCode.success,
                            data: ratingResSettingsData,
                            message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                        });
                    }
                })
                break;
            default:       
                FacilityNotificationSettings.findOne({
                    userFacId: mongoose.Types.ObjectId(req.user.userFacId),
                    facId: mongoose.Types.ObjectId(req.user.facId),
                    isDelete: false,
                    status: true
                }).lean().exec(function(err, notificationSettingsData){
                    if(err){
                        res.json({
                            code: config.statusCode.error,
                            data: {},
                            message: i18n.__("INTERNAL_ERROR")
                        });
                    }else{
                        res.json({
                            code: config.statusCode.success,
                            data: notificationSettingsData,
                            message: i18n.__("DATA_FOUND_SUCCESSFULLY")
                        });
                    }
                })
        }
        
    }       
}


/**
 * Function is used to update app setting
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 27-June-2018
 */
function updateAppSetting(req, res) {
    FacilityAppSettings.findOneAndUpdate({ _id: req.body._id }, {
        $set: {
            checkInSms: req.body.checkInSms,
            checkInMessageReceivedReplySms: req.body.checkInMessageReceivedReplySms,
            checkOutSms: req.body.checkOutSms,
            checkInSmsInterval: req.body.checkInSmsInterval,
            checkOutSmsInterval: req.body.checkOutSmsInterval,
            googleRatingSmsInterval: req.body.googleRatingSmsInterval,
            smsLimits: req.body.smsLimits,
            welcomeMessage: req.body.welcomeMessage,
            goodbyeMessage: req.body.goodbyeMessage,
            footerMessage: req.body.footerMessage,
            expressResident: req.body.expressResident
        }
    }, function (err, updatedAppSetting) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("SETTING_UPDATED_SUCCESSFULLY")
            });
        }
    });
    
}

/**
 * Function is used to update sms setting
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 27-June-2018
 */
function updateSMSSetting(req, res) {
    FacilitySmsSettings.findOneAndUpdate({ _id: req.body._id }, {
        $set: {
            sunday: req.body.sunday,
            monday: req.body.monday,
            tuesday: req.body.tuesday,
            wednesday: req.body.wednesday,
            thursday: req.body.thursday,
            friday: req.body.friday,
            saturday: req.body.saturday,
            disableAutoReply: req.body.disableAutoReply
        }
    }, function (err, updatedSMSSetting) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("SETTING_UPDATED_SUCCESSFULLY")
            });
        }
    });
    
}



/**
 * Function is used to update rating response setting
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 27-June-2018
 * Updated by Sunny
 * Updated Date 18-July-2018
 */
function updateRatingResponseSetting(req, res) {
    FacilityRatingResponseSettings.findOneAndUpdate({ _id: req.body._id }, {
        $set: {
            positive: req.body.positive,
            negative: req.body.negative,
            negativeRatingFollowUpSms: req.body.negativeRatingFollowUpSms
        }
    }, function (err, updatedRatingResponseSetting) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            Facility.findOneAndUpdate({ _id: req.body.facId }, {
                $set: {
                    googleLink: req.body.positive.googleLink
                }
            }, function (err, updatedFacility) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: {},
                        message: i18n.__("SETTING_UPDATED_SUCCESSFULLY")
                    });
                }
            });    
        }
    });
    
}

/**
 * Function is used to update notification setting
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 29-June-2018
 */
function updateNotificationSetting(req, res) {
    FacilityNotificationSettings.findOneAndUpdate({ _id: req.body._id }, {
        $set: {
            openIncident: req.body.openIncident,
            updateResolvedIncident: req.body.updateResolvedIncident,
            negative_rating_notification: req.body.negative_rating_notification,
            checkInNotification: req.body.checkInNotification            
        }
    }, function (err, updatedNotificationSetting) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("SETTING_UPDATED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to send open incident notifications
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 03-July-2018
 */
function sendOpenIncidentsNotification(req, res) {
    console.log("comes in send open incident notifications");
    var finalResponse = {};
    finalResponse.facArray = [];
    waterfall([
        function (callback) { //find all the facilities

            var condition = {};
            condition.isDelete = false;
            condition['userFacInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;

            var aggregate = [{
                    $lookup: {
                        from: 'userfacilities',
                        localField: "_id",
                        foreignField: "facilityId",
                        as: "userFacInfo"
                    }
                },
                {
                    $unwind: "$userFacInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userFacInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                }, {
                    $lookup: {
                        from: 'usercompanies',
                        localField: "userCmpId",
                        foreignField: "_id",
                        as: "userCmpInfo"
                    }
                },
                {
                    $unwind: "$userCmpInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "facName": "$facName",
                    "userId": "$userInfo._id",
                    "userFacId": "$userFacInfo._id",
                    "twilioTollFreeNumber": "$twilioTollFreeNumber"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Facility.aggregate(aggregate).then(function (facArray) {
                finalResponse.facArray = facArray;
                console.log("faccccc",facArray.length)
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Create facilities todays checklist 
            async.eachSeries(finalResponse.facArray, function (facData, next) {
                FacilityNotificationSettings.findOne({ facId: mongoose.Types.ObjectId(facData._id), isDelete: false, status: true}).exec(function(err, facilityNotificationsSettings){
                    if(err){
                         next();
                    }else if(facilityNotificationsSettings != null){
                        console.log("facilityNotificationsSettings", facilityNotificationsSettings);
                        if(facilityNotificationsSettings.openIncident.status == true){
                            var todayDate = new Date();
                            switch (facilityNotificationsSettings.openIncident.period) {
                                case config.openIncidentPeriod.ON_SECOND_DAY:
                                    var start_day_date = moment(todayDate).startOf('day').add(-1, 'days');
                                    var end_day_date = moment(todayDate).endOf('day').add(-1, 'days');
                                    break;
                                case config.openIncidentPeriod.ON_SEVENTH_DAY:
                                    console.log("sdsdsdsdsdsdsdsdsdsdsd on seven day")
                                    var start_day_date = moment(todayDate).startOf('day').add(-6, 'days');
                                    var end_day_date = moment(todayDate).endOf('day').add(-6, 'days');
                                    break;
                                case config.openIncidentPeriod.ON_FIFTEENTH_DAY:
                                    var start_day_date = moment(todayDate).startOf('day').add(-14, 'days');
                                    var end_day_date = moment(todayDate).endOf('day').add(-14, 'days');
                                    break;
                                case config.openIncidentPeriod.ON_THIRTHEETH_DAY:
                                    var start_day_date = moment(todayDate).startOf('day').add(-29, 'days');
                                    var end_day_date = moment(todayDate).endOf('day').add(-29, 'days');
                                    break;
                            }
                            var momentObjFrom = new Date(moment(start_day_date));
                            var momentObjTo = new Date(moment(end_day_date));
                            console.log("momentObjFrom", momentObjFrom, momentObjTo);
                            var condition = {
                                isDelete: false,
                                status: true,
                                userFacId: mongoose.Types.ObjectId(facData.userFacId),
                                resolved: false,
                                $and: [{
                                        createdAt: {
                                            $gte: momentObjFrom
                                        }
                                    },
                                    {
                                        createdAt: {
                                            $lte: momentObjTo
                                        }
                                    }
                                ]
                            };
                            IncidentReports.find(condition).exec(function(err, incidentsArray){
                                if(err){
                                    console.log("in incident find error");
                                    next();
                                }else if(incidentsArray.length > 0){
                                    console.log("in incident to send emails");
                                    var headerTable = "<tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>"+
                                                        "<tr><td style='padding: 0 20px;'>"+
                                                            "<table width='100%' border='0' cellspacing='0' cellpadding='0'>"+
                                                                "<tbody><tr><td style='color: #C33333; padding-bottom: 10px;'><strong>Open Incident Detail:</strong></td></tr></tbody></table>"+
                                                                    "<table width='100%' border='1' bordercolor='#d9d9d9' cellspacing='0' cellpadding='10' style='border-collapse: collapse;'>"+
                                                                "<tbody>"+
                                                            "<tr>"+
                                                            "<td><span style='font-size: 12px; color: #777777;'>Created At</span></td>"+
                                                            "<td><span style='font-size: 12px; color: #777777;'>Regarding</span></td>"+
                                                            "<td><span style='font-size: 12px; color: #777777;'>Type</span></td>"+
                                                            "<td><span style='font-size: 12px; color: #777777;'>Visited To</span></td>"+
                                                            "<td><span style='font-size: 12px; color: #777777;'>Concern</span></td>"+
                                                            "</tr>"+
                                                            "<tr>";
                                    var footerTable = "</tbody></table></td></tr>";
                                    var bodyContent = "";
                                    async.eachSeries(incidentsArray, function(incidentData, nextIncidents){
                                            var createdAt = moment(incidentData.createdAt).format('MM-DD-YYYY');
                                            var regarding = incidentData.firstName+ ' '+ incidentData.lastName;
                                            var type = incidentData.incidentType;
                                            var visitedTo = incidentData.visitedTo;
                                            var concern = incidentData.concern ? incidentData.concern: '-';

                                            bodyContent += "<td><span><strong>"+ createdAt +"</strong></span></td>"+
                                                        "<td><span><strong>"+ regarding +"</strong></span></td>"+
                                                        "<td><span><strong>"+ type +"</strong></span></td>"+
                                                        "<td><span><strong>"+ visitedTo +"</strong></span></td>"+
                                                        "<td><span><strong>"+ concern +"</strong></span></td>"+
                                                        "</tr>";
                                            nextIncidents();
                                    },function(err){
                                        if(err){
                                            next();
                                        }else{
                                            var finalBodyContent = headerTable+bodyContent+footerTable;
                                            console.log("finalBodyContent@@@@@@@@@@@@@@@@", finalBodyContent)
                                            async.eachSeries(facilityNotificationsSettings.openIncident.emailsArray, function (notificationData, nextAgain) {
                                                var baseUrl = config.email.base_url;
                                                var options = {
                                                    template: 'notifyOpenIncident.html',
                                                    from: config.email.from,
                                                    repalcement: {
                                                        // "{{finalBodyContent}}": finalBodyContent,
                                                        "{{content_notify}}": finalBodyContent,
                                                        "{{user.url}}": baseUrl + "/facility/incidentReports",
                                                        "{{logo_url}}": baseUrl + config.email.logo_url,
                                                        "{{copyright}}": config.email.copyright,                        
                                                        "{{link.abuse_email}}": config.email.abuse_email
                                                    },
                                                    to: notificationData,
                                                    subject: 'Open Incident'
                                                };
                                                emailSend.smtp.sendMail(options, function (err, response) {
                                                    if (err) {
                                                        console.log("in email error", err);
                                                        nextAgain();
                                                    } else {
                                                        console.log("in succees email");
                                                        nextAgain();
                                                    }
                                                })
                                            }, function (err) {
                                                if (err) {
                                                    next();
                                                } else {
                                                    var text = "This is to notify you that there are some incidents are open. To check please visit to the provided link: "+ config.email.base_url+ "/facility/incidentReports";
                                                    var smsData = {
                                                        to: facilityNotificationsSettings.openIncident.phoneNumber,
                                                        from: facData.twilioTollFreeNumber,
                                                        message: text
                                                    }
                                                    twilio.sendSMS(smsData, function (returnData) {
                                                        if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                                                            finalResponse.twilioInfo = returnData;
                                                            next();
                                                        } else {
                                                            finalResponse.twilioInfo = returnData;
                                                            if (finalResponse.twilioInfo.status == config.statusCode.success) {
                                                                var messageBody = finalResponse.twilioInfo.message.toJSON();
                                                                var smsInfo = {};
                                                                smsInfo.userFacId = facData.userFacId;
                                                                smsInfo.to = messageBody.to;
                                                                smsInfo.from = messageBody.from;
                                                                smsInfo.text = messageBody.body;
                                                                smsInfo.type = 'open_incident';
                                                                var notificationSmsHistory = new NotificationSmsHistory(smsInfo);
                                                                notificationSmsHistory.save(function (err, SmsSavedData) {
                                                                    if (err) {
                                                                        next();
                                                                    } else {
                                                                        next();
                                                                    }
                                                                });
                                                            } else {
                                                                next();
                                                            }
                                                        }
                                                    });
                                                }
                                            })     
                                        }
                                    })
                                }else{
                                    console.log("not found@@@@@@@@@@@@@@@@@@");
                                    next();
                                }
                            }) 
                        } else{
                            console.log("vashdsdhsdasd@@@@######");
                            next();
                        }
                    }else{
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })
        },
    ], function (err, data) {
        if (err) {} else {}
    });
}

/**
 * Function is use to send open incident notifications
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 03-July-2018
 */
function sendOpenIncidentsNotification(req, res) {
    console.log("comes in send open incident notifications");
    var finalResponse = {};
    finalResponse.facArray = [];
    waterfall([
        function (callback) { //find all the facilities

            var condition = {};
            condition.isDelete = false;
            condition['userFacInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;

            var aggregate = [{
                    $lookup: {
                        from: 'userfacilities',
                        localField: "_id",
                        foreignField: "facilityId",
                        as: "userFacInfo"
                    }
                },
                {
                    $unwind: "$userFacInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userFacInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                }, {
                    $lookup: {
                        from: 'usercompanies',
                        localField: "userCmpId",
                        foreignField: "_id",
                        as: "userCmpInfo"
                    }
                },
                {
                    $unwind: "$userCmpInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "facName": "$facName",
                    "userId": "$userInfo._id",
                    "userFacId": "$userFacInfo._id",
                    "twilioTollFreeNumber": "$twilioTollFreeNumber"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Facility.aggregate(aggregate).then(function (facArray) {
                finalResponse.facArray = facArray;
                console.log("faccccc",facArray.length)
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Create facilities todays checklist 
            async.eachSeries(finalResponse.facArray, function (facData, next) {
                FacilityNotificationSettings.findOne({ facId: mongoose.Types.ObjectId(facData._id), isDelete: false, status: true}).exec(function(err, facilityNotificationsSettings){
                    if(err){
                         next();
                    }else if(facilityNotificationsSettings != null){
                        console.log("facilityNotificationsSettings", facilityNotificationsSettings);
                        if(facilityNotificationsSettings.openIncident.status == true){
                            var todayDate = new Date();
                            switch (facilityNotificationsSettings.openIncident.period) {
                                case config.openIncidentPeriod.ON_SECOND_DAY:
                                    var start_day_date = moment(todayDate).startOf('day').add(-1, 'days');
                                    var end_day_date = moment(todayDate).endOf('day').add(-1, 'days');
                                    break;
                                case config.openIncidentPeriod.ON_SEVENTH_DAY:
                                    console.log("sdsdsdsdsdsdsdsdsdsdsd on seven day")
                                    var start_day_date = moment(todayDate).startOf('day').add(-6, 'days');
                                    var end_day_date = moment(todayDate).endOf('day').add(-6, 'days');
                                    break;
                                case config.openIncidentPeriod.ON_FIFTEENTH_DAY:
                                    var start_day_date = moment(todayDate).startOf('day').add(-14, 'days');
                                    var end_day_date = moment(todayDate).endOf('day').add(-14, 'days');
                                    break;
                                case config.openIncidentPeriod.ON_THIRTHEETH_DAY:
                                    var start_day_date = moment(todayDate).startOf('day').add(-29, 'days');
                                    var end_day_date = moment(todayDate).endOf('day').add(-29, 'days');
                                    break;
                            }
                            var momentObjFrom = new Date(moment(start_day_date));
                            var momentObjTo = new Date(moment(end_day_date));
                            console.log("momentObjFrom", momentObjFrom, momentObjTo);
                            var condition = {
                                isDelete: false,
                                status: true,
                                userFacId: mongoose.Types.ObjectId(facData.userFacId),
                                resolved: false,
                                $and: [{
                                        createdAt: {
                                            $gte: momentObjFrom
                                        }
                                    },
                                    {
                                        createdAt: {
                                            $lte: momentObjTo
                                        }
                                    }
                                ]
                            };
                            IncidentReports.find(condition).exec(function(err, incidentsArray){
                                if(err){
                                    console.log("in incident find error");
                                    next();
                                }else if(incidentsArray.length > 0){
                                    console.log("in incident to send emails");
                                    var headerTable = "<tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>"+
                                                        "<tr><td style='padding: 0 20px;'>"+
                                                            "<table width='100%' border='0' cellspacing='0' cellpadding='0'>"+
                                                                "<tbody><tr><td style='color: #C33333; padding-bottom: 10px;'><strong>Open Incident Detail:</strong></td></tr></tbody></table>"+
                                                                    "<table width='100%' border='1' bordercolor='#d9d9d9' cellspacing='0' cellpadding='10' style='border-collapse: collapse;'>"+
                                                                "<tbody>"+
                                                            "<tr>"+
                                                            "<td><span style='font-size: 12px; color: #777777;'>Created At</span></td>"+
                                                            "<td><span style='font-size: 12px; color: #777777;'>Regarding</span></td>"+
                                                            "<td><span style='font-size: 12px; color: #777777;'>Type</span></td>"+
                                                            "<td><span style='font-size: 12px; color: #777777;'>Visited To</span></td>"+
                                                            "<td><span style='font-size: 12px; color: #777777;'>Concern</span></td>"+
                                                            "</tr>"+
                                                            "<tr>";
                                    var footerTable = "</tbody></table></td></tr>";
                                    var bodyContent = "";
                                    async.eachSeries(incidentsArray, function(incidentData, nextIncidents){
                                            var createdAt = moment(incidentData.createdAt).format('MM-DD-YYYY');
                                            var regarding = incidentData.firstName+ ' '+ incidentData.lastName;
                                            var type = incidentData.incidentType;
                                            var visitedTo = incidentData.visitedTo;
                                            var concern = incidentData.concern ? incidentData.concern: '-';

                                            bodyContent += "<td><span><strong>"+ createdAt +"</strong></span></td>"+
                                                        "<td><span><strong>"+ regarding +"</strong></span></td>"+
                                                        "<td><span><strong>"+ type +"</strong></span></td>"+
                                                        "<td><span><strong>"+ visitedTo +"</strong></span></td>"+
                                                        "<td><span><strong>"+ concern +"</strong></span></td>"+
                                                        "</tr>";
                                            nextIncidents();
                                    },function(err){
                                        if(err){
                                            next();
                                        }else{
                                            var finalBodyContent = headerTable+bodyContent+footerTable;
                                            console.log("finalBodyContent@@@@@@@@@@@@@@@@", finalBodyContent)
                                            async.eachSeries(facilityNotificationsSettings.openIncident.emailsArray, function (notificationData, nextAgain) {
                                                var baseUrl = config.email.base_url;
                                                var options = {
                                                    template: 'notifyOpenIncident.html',
                                                    from: config.email.from,
                                                    repalcement: {
                                                        // "{{finalBodyContent}}": finalBodyContent,
                                                        "{{content_notify}}": finalBodyContent,
                                                        "{{user.url}}": baseUrl + "/facility/incidentReports",
                                                        "{{logo_url}}": baseUrl + config.email.logo_url,
                                                        "{{copyright}}": config.email.copyright,                        
                                                        "{{link.abuse_email}}": config.email.abuse_email
                                                    },
                                                    to: notificationData,
                                                    subject: 'Open Incident'
                                                };
                                                emailSend.smtp.sendMail(options, function (err, response) {
                                                    if (err) {
                                                        console.log("in email error", err);
                                                        nextAgain();
                                                    } else {
                                                        console.log("in succees email");
                                                        nextAgain();
                                                    }
                                                })
                                            }, function (err) {
                                                if (err) {
                                                    next();
                                                } else {
                                                    var text = "This is to notify you that there are some incidents are open. To check please visit to the provided link: "+ config.email.base_url+ "/facility/incidentReports";
                                                    var smsData = {
                                                        to: facilityNotificationsSettings.openIncident.phoneNumber,
                                                        from: facData.twilioTollFreeNumber,
                                                        message: text
                                                    }
                                                    twilio.sendSMS(smsData, function (returnData) {
                                                        if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                                                            finalResponse.twilioInfo = returnData;
                                                            next();
                                                        } else {
                                                            finalResponse.twilioInfo = returnData;
                                                            if (finalResponse.twilioInfo.status == config.statusCode.success) {
                                                                var messageBody = finalResponse.twilioInfo.message.toJSON();
                                                                var smsInfo = {};
                                                                smsInfo.userFacId = facData.userFacId;
                                                                smsInfo.to = messageBody.to;
                                                                smsInfo.from = messageBody.from;
                                                                smsInfo.text = messageBody.body;
                                                                smsInfo.type = 'open_incident';
                                                                var notificationSmsHistory = new NotificationSmsHistory(smsInfo);
                                                                notificationSmsHistory.save(function (err, SmsSavedData) {
                                                                    if (err) {
                                                                        next();
                                                                    } else {
                                                                        next();
                                                                    }
                                                                });
                                                            } else {
                                                                next();
                                                            }
                                                        }
                                                    });
                                                }
                                            })     
                                        }
                                    })
                                }else{
                                    next();
                                }
                            }) 
                        } else{
                            next();
                        }
                    }else{
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })
        },
    ], function (err, data) {
        if (err) {} else {}
    });
}

/**
 * Function is use to send open incident notifications
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 03-July-2018
 */
function sendOpenIncidentsNotification(req, res) {
    var finalResponse = {};
    finalResponse.facArray = [];
    waterfall([
        function (callback) { //find all the facilities

            var condition = {};
            condition.isDelete = false;
            condition['userFacInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;

            var aggregate = [{
                    $lookup: {
                        from: 'userfacilities',
                        localField: "_id",
                        foreignField: "facilityId",
                        as: "userFacInfo"
                    }
                },
                {
                    $unwind: "$userFacInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userFacInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                }, {
                    $lookup: {
                        from: 'usercompanies',
                        localField: "userCmpId",
                        foreignField: "_id",
                        as: "userCmpInfo"
                    }
                },
                {
                    $unwind: "$userCmpInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "facName": "$facName",
                    "userId": "$userInfo._id",
                    "userFacId": "$userFacInfo._id",
                    "twilioTollFreeNumber": "$twilioTollFreeNumber"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Facility.aggregate(aggregate).then(function (facArray) {
                finalResponse.facArray = facArray;
                console.log("faccccc",facArray.length)
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Create facilities todays checklist 
            async.eachSeries(finalResponse.facArray, function (facData, next) {
                FacilityNotificationSettings.findOne({ facId: mongoose.Types.ObjectId(facData._id), isDelete: false, status: true}).exec(function(err, facilityNotificationsSettings){
                    if(err){
                         next();
                    }else if(facilityNotificationsSettings != null){
                        console.log("facilityNotificationsSettings", facilityNotificationsSettings);
                        if(facilityNotificationsSettings.openIncident.status == true){
                            var todayDate = new Date();
                            switch (facilityNotificationsSettings.openIncident.period) {
                                case config.openIncidentPeriod.ON_SECOND_DAY:
                                    var start_day_date = moment(todayDate).startOf('day').add(-1, 'days');
                                    var end_day_date = moment(todayDate).endOf('day').add(-1, 'days');
                                    break;
                                case config.openIncidentPeriod.ON_SEVENTH_DAY:
                                    console.log("sdsdsdsdsdsdsdsdsdsdsd on seven day")
                                    var start_day_date = moment(todayDate).startOf('day').add(-6, 'days');
                                    var end_day_date = moment(todayDate).endOf('day').add(-6, 'days');
                                    break;
                                case config.openIncidentPeriod.ON_FIFTEENTH_DAY:
                                    var start_day_date = moment(todayDate).startOf('day').add(-14, 'days');
                                    var end_day_date = moment(todayDate).endOf('day').add(-14, 'days');
                                    break;
                                case config.openIncidentPeriod.ON_THIRTHEETH_DAY:
                                    var start_day_date = moment(todayDate).startOf('day').add(-29, 'days');
                                    var end_day_date = moment(todayDate).endOf('day').add(-29, 'days');
                                    break;
                            }
                            var momentObjFrom = new Date(moment(start_day_date));
                            var momentObjTo = new Date(moment(end_day_date));
                            console.log("momentObjFrom", momentObjFrom, momentObjTo);
                            var condition = {
                                isDelete: false,
                                status: true,
                                userFacId: mongoose.Types.ObjectId(facData.userFacId),
                                resolved: false,
                                $and: [{
                                        createdAt: {
                                            $gte: momentObjFrom
                                        }
                                    },
                                    {
                                        createdAt: {
                                            $lte: momentObjTo
                                        }
                                    }
                                ]
                            };
                            IncidentReports.find(condition).exec(function(err, incidentsArray){
                                if(err){
                                    console.log("in incident find error");
                                    next();
                                }else if(incidentsArray.length > 0){
                                    console.log("in incident to send emails");
                                    var headerTable = "<tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>"+
                                                        "<tr><td style='padding: 0 20px;'>"+
                                                            "<table width='100%' border='0' cellspacing='0' cellpadding='0'>"+
                                                                "<tbody><tr><td style='color: #C33333; padding-bottom: 10px;'><strong>Open Incident Detail:</strong></td></tr></tbody></table>"+
                                                                    "<table width='100%' border='1' bordercolor='#d9d9d9' cellspacing='0' cellpadding='10' style='border-collapse: collapse;'>"+
                                                                "<tbody>"+
                                                            "<tr>"+
                                                            "<td><span style='font-size: 12px; color: #777777;'>Created At</span></td>"+
                                                            "<td><span style='font-size: 12px; color: #777777;'>Regarding</span></td>"+
                                                            "<td><span style='font-size: 12px; color: #777777;'>Type</span></td>"+
                                                            "<td><span style='font-size: 12px; color: #777777;'>Visited To</span></td>"+
                                                            "<td><span style='font-size: 12px; color: #777777;'>Concern</span></td>"+
                                                            "</tr>"+
                                                            "<tr>";
                                    var footerTable = "</tbody></table></td></tr>";
                                    var bodyContent = "";
                                    async.eachSeries(incidentsArray, function(incidentData, nextIncidents){
                                            var createdAt = moment(incidentData.createdAt).format('MM-DD-YYYY');
                                            var regarding = incidentData.firstName+ ' '+ incidentData.lastName;
                                            var type = incidentData.incidentType;
                                            var visitedTo = incidentData.visitedTo;
                                            var concern = incidentData.concern ? incidentData.concern: '-';

                                            bodyContent += "<td><span><strong>"+ createdAt +"</strong></span></td>"+
                                                        "<td><span><strong>"+ regarding +"</strong></span></td>"+
                                                        "<td><span><strong>"+ type +"</strong></span></td>"+
                                                        "<td><span><strong>"+ visitedTo +"</strong></span></td>"+
                                                        "<td><span><strong>"+ concern +"</strong></span></td>"+
                                                        "</tr>";
                                            nextIncidents();
                                    },function(err){
                                        if(err){
                                            next();
                                        }else{
                                            var finalBodyContent = headerTable+bodyContent+footerTable;
                                            console.log("finalBodyContent@@@@@@@@@@@@@@@@", finalBodyContent)
                                            async.eachSeries(facilityNotificationsSettings.openIncident.emailsArray, function (notificationData, nextAgain) {
                                                var baseUrl = config.email.base_url;
                                                var options = {
                                                    template: 'notifyOpenIncident.html',
                                                    from: config.email.from,
                                                    repalcement: {
                                                        // "{{finalBodyContent}}": finalBodyContent,
                                                        "{{content_notify}}": finalBodyContent,
                                                        "{{user.url}}": baseUrl + "/facility/incidentReports",
                                                        "{{logo_url}}": baseUrl + config.email.logo_url,
                                                        "{{copyright}}": config.email.copyright,                        
                                                        "{{link.abuse_email}}": config.email.abuse_email
                                                    },
                                                    to: notificationData,
                                                    subject: 'Open Incident'
                                                };
                                                emailSend.smtp.sendMail(options, function (err, response) {
                                                    if (err) {
                                                        console.log("in email error", err);
                                                        nextAgain();
                                                    } else {
                                                        console.log("in succees email");
                                                        nextAgain();
                                                    }
                                                })
                                            }, function (err) {
                                                if (err) {
                                                    next();
                                                } else {
                                                    var text = "This is to notify you that there are some incidents are open. To check please visit to the provided link: "+ config.email.base_url+ "/facility/incidentReports";
                                                    var smsData = {
                                                        to: facilityNotificationsSettings.openIncident.phoneNumber,
                                                        from: facData.twilioTollFreeNumber,
                                                        message: text
                                                    }
                                                    twilio.sendSMS(smsData, function (returnData) {
                                                        if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                                                            finalResponse.twilioInfo = returnData;
                                                            next();
                                                        } else {
                                                            finalResponse.twilioInfo = returnData;
                                                            if (finalResponse.twilioInfo.status == config.statusCode.success) {
                                                                var messageBody = finalResponse.twilioInfo.message.toJSON();
                                                                var smsInfo = {};
                                                                smsInfo.userFacId = facData.userFacId;
                                                                smsInfo.to = messageBody.to;
                                                                smsInfo.from = messageBody.from;
                                                                smsInfo.text = messageBody.body;
                                                                smsInfo.type = 'open_incident';
                                                                var notificationSmsHistory = new NotificationSmsHistory(smsInfo);
                                                                notificationSmsHistory.save(function (err, SmsSavedData) {
                                                                    if (err) {
                                                                        next();
                                                                    } else {
                                                                        next();
                                                                    }
                                                                });
                                                            } else {
                                                                next();
                                                            }
                                                        }
                                                    });
                                                }
                                            })     
                                        }
                                    })
                                }else{
                                    console.log("not found@@@@@@@@@@@@@@@@@@");
                                    next();
                                }
                            }) 
                        } else{
                            console.log("vashdsdhsdasd@@@@######");
                            next();
                        }
                    }else{
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })
        },
    ], function (err, data) {
        if (err) {} else {}
    });
}

/**
 * Function is use to send custom open incident notifications
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 08-Sep-2018
 */
function sendCustomOpenIncidentsNotification(req, res) {
    var finalResponse = {};
    finalResponse.facArray = [];
    waterfall([
        function (callback) { //find all the facilities
            var condition = {};
            condition.isDelete = false;
            condition['userFacInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;

            var aggregate = [{
                    $lookup: {
                        from: 'userfacilities',
                        localField: "_id",
                        foreignField: "facilityId",
                        as: "userFacInfo"
                    }
                },
                {
                    $unwind: "$userFacInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userFacInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                }, {
                    $lookup: {
                        from: 'usercompanies',
                        localField: "userCmpId",
                        foreignField: "_id",
                        as: "userCmpInfo"
                    }
                },
                {
                    $unwind: "$userCmpInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "facName": "$facName",
                    "userId": "$userInfo._id",
                    "userFacId": "$userFacInfo._id",
                    "twilioTollFreeNumber": "$twilioTollFreeNumber"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Facility.aggregate(aggregate).then(function (facArray) {
                finalResponse.facArray = facArray;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Create facilities todays checklist 
            async.eachSeries(finalResponse.facArray, function (facData, next) {
                if(facData.openIncident){
                    var todayDate = new Date();
                    switch (facData.openIncident.period) {
                        case config.openIncidentPeriod.ON_SECOND_DAY:
                            var start_day_date = moment(todayDate).startOf('day').add(-1, 'days');
                            var end_day_date = moment(todayDate).endOf('day').add(-1, 'days');
                            break;
                        case config.openIncidentPeriod.ON_SEVENTH_DAY:
                            var start_day_date = moment(todayDate).startOf('day').add(-6, 'days');
                            var end_day_date = moment(todayDate).endOf('day').add(-6, 'days');
                            break;
                        case config.openIncidentPeriod.ON_FIFTEENTH_DAY:
                            var start_day_date = moment(todayDate).startOf('day').add(-14, 'days');
                            var end_day_date = moment(todayDate).endOf('day').add(-14, 'days');
                            break;
                        case config.openIncidentPeriod.ON_THIRTHEETH_DAY:
                            var start_day_date = moment(todayDate).startOf('day').add(-29, 'days');
                            var end_day_date = moment(todayDate).endOf('day').add(-29, 'days');
                            break;
                    }
                    var momentObjFrom = new Date(moment(start_day_date));
                    var momentObjTo = new Date(moment(end_day_date));
                    var condition = {
                        isDelete: false,
                        status: true,
                        userFacId: mongoose.Types.ObjectId(facData.userFacId),
                        resolved: false,
                        $and: [{
                                createdAt: {
                                    $gte: momentObjFrom
                                }
                            },
                            {
                                createdAt: {
                                    $lte: momentObjTo
                                }
                            }
                        ]
                    };
                    IncidentReports.find(condition).exec(function(err, incidentsArray){
                        if(err){
                            next();
                        }else if(incidentsArray.length > 0){
                            var headerTable = "<tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>"+
                                                "<tr><td style='padding: 0 20px;'>"+
                                                    "<table width='100%' border='0' cellspacing='0' cellpadding='0'>"+
                                                        "<tbody><tr><td style='color: #C33333; padding-bottom: 10px;'><strong>Open Incident Detail:</strong></td></tr></tbody></table>"+
                                                            "<table width='100%' border='1' bordercolor='#d9d9d9' cellspacing='0' cellpadding='10' style='border-collapse: collapse;'>"+
                                                        "<tbody>"+
                                                "<tr>"+
                                                "<td><span style='font-size: 12px; color: #777777;'>Created At</span></td>"+
                                                "<td><span style='font-size: 12px; color: #777777;'>Regarding</span></td>"+
                                                "<td><span style='font-size: 12px; color: #777777;'>Type</span></td>"+
                                                "<td><span style='font-size: 12px; color: #777777;'>Visited To</span></td>"+
                                                "<td><span style='font-size: 12px; color: #777777;'>Concern</span></td>"+
                                                "</tr>"+
                                                "<tr>";
                            var footerTable = "</tbody></table></td></tr>";
                            var bodyContent = "";
                            async.eachSeries(incidentsArray, function (incData, incidentCallback) {
                                if(incData.openIncident && incData.openIncident.status==true){
                                    var createdAt = moment(incData.createdAt).format('MM-DD-YYYY');
                                    var regarding = incData.firstName+ ' '+ incData.lastName;
                                    var type = incData.incidentType;
                                    var visitedTo = incData.visitedTo;
                                    var concern = incData.concern ? incData.concern: '-';
    
                                    bodyContent += "<td><span><strong>"+ createdAt +"</strong></span></td>"+
                                                "<td><span><strong>"+ regarding +"</strong></span></td>"+
                                                "<td><span><strong>"+ type +"</strong></span></td>"+
                                                "<td><span><strong>"+ visitedTo +"</strong></span></td>"+
                                                "<td><span><strong>"+ concern +"</strong></span></td>"+
                                                "</tr>";
                                    var finalBodyContent = headerTable+bodyContent+footerTable;            
                                    async.eachSeries(incData.openIncident.emailsArray, function (notificationData, nextAgain) {
                                        var baseUrl = config.email.base_url;
                                        var options = {
                                            template: 'notifyOpenIncident.html',
                                            from: config.email.from,
                                            repalcement: {
                                                // "{{finalBodyContent}}": finalBodyContent,
                                                "{{content_notify}}": finalBodyContent,
                                                "{{user.url}}": baseUrl + "/facility/incidentReports",
                                                "{{logo_url}}": baseUrl + config.email.logo_url,
                                                "{{copyright}}": config.email.copyright,                        
                                                "{{link.abuse_email}}": config.email.abuse_email
                                            },
                                            to: notificationData,
                                            subject: 'Open Incident'
                                        };
                                        emailSend.smtp.sendMail(options, function (err, response) {
                                            if (err) {
                                                nextAgain();
                                            } else {
                                                nextAgain();
                                            }
                                        })
                                    }, function (err) {
                                        if (err) {
                                            incidentCallback();
                                        } else {
                                            var text = "This is to notify you that there are some incidents are open. To check please visit to the provided link: "+ config.email.base_url+ "/facility/incidentReports";
                                            var smsData = {
                                                to: incData.openIncident.phoneNumber,
                                                from: facData.twilioTollFreeNumber,
                                                message: text
                                            }
                                            twilio.sendSMS(smsData, function (returnData) {
                                                if (returnData.status == config.statusCode.error) { //twilio give an error to sending sms to this number
                                                    finalResponse.twilioInfo = returnData;
                                                    incidentCallback();
                                                } else {
                                                    finalResponse.twilioInfo = returnData;
                                                    if (finalResponse.twilioInfo.status == config.statusCode.success) {
                                                        var messageBody = finalResponse.twilioInfo.message.toJSON();
                                                        var smsInfo = {};
                                                        smsInfo.userFacId = facData.userFacId;
                                                        smsInfo.to = messageBody.to;
                                                        smsInfo.from = messageBody.from;
                                                        smsInfo.text = messageBody.body;
                                                        smsInfo.type = 'custom_open_incident';
                                                        var notificationSmsHistory = new NotificationSmsHistory(smsInfo);
                                                        notificationSmsHistory.save(function (err, SmsSavedData) {
                                                            if (err) {
                                                                incidentCallback();
                                                            } else {
                                                                incidentCallback();
                                                            }
                                                        });
                                                    } else {
                                                        incidentCallback();
                                                    }
                                                }
                                            });
                                        }
                                    })  
                                }else{
                                    incidentCallback();
                                }
                            }, function (err) {
                                if (err) {
                                    next();
                                } else {
                                    next();
                                }
                            })
                        }else{
                            next();
                        }
                    }) 
                }else{
                    next();
                }
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })
        },
    ], function (err, data) {
        if (err) {} else {}
    });
}