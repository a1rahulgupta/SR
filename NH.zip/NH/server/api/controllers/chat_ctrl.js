'use strict';

var mongoose = require('mongoose'),
    generator = require('generate-password'),
    User = mongoose.model('user'),
    Company = mongoose.model('company'),
    UserCompany = mongoose.model('userCompany'),
    UserFacility = mongoose.model('userFacility'),
    formidable = require('formidable'),
    fs = require('fs-extra'),
    path = require('path'),
    jwt = require('jsonwebtoken'),
    validator = require('validator'),
    utility = require('../lib/utility.js'),
    crypto = require('./../lib/crypto.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    Joi = require('joi'),
    i18n = require("i18n"),
    moment = require('moment'),
    emailSend = __rootRequire('api/core/email'),
    convert = require('xml-js'),
    zipcodes = require('zipcodes'),
    Facility = mongoose.model('facility'),
    CheckInOut = mongoose.model('checkInOut'),
    IncidentReports = mongoose.model('incidentReport'),
    Chat = mongoose.model('chat'),    
    config = require('../../config/config.js');

module.exports = {
    getUsersList: getUsersList,
    getChatHistory: getChatHistory,
    sendChatMessage: sendChatMessage
}

/**
 * Function is use to get users list of facility
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 10-Aug-2018
 */
function getUsersList(req, res) {
    console.log("coming in to get users list", req.user.uid);
    var finalResponse = {};

    waterfall([
        function (callback) { //Users Data

            var condition = {
                _id: { $ne: mongoose.Types.ObjectId(req.user.uid)}
            };
            condition.isDelete = false;
            condition['userFacInfo.isDelete'] = false;
            condition['userFacInfo.facilityId'] = mongoose.Types.ObjectId(req.user.facId);
            condition['isDelete'] = false;

            var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            if (searchText != undefined && searchText != 'undefined') {
                condition.$or = [{
                        'firstName': new RegExp(searchText, 'gi')
                    },
                    {
                        'lastName': new RegExp(searchText, 'gi')
                    },
                    {
                        'userName': new RegExp(searchText, 'gi')
                    },
                    {
                        'phoneNumber': new RegExp(searchText, 'gi')
                    }
                ];
            }

            var aggregate = [{
                    $lookup: {
                        from: 'userfacilities',
                        localField: "_id",
                        foreignField: "userId",
                        as: "userFacInfo"
                    }
                },
                {
                    $unwind: "$userFacInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "createdAt": "$createdAt",
                    "userName": "$userName",
                    "phoneNumber": "$phoneNumber",
                    "status": "$status",
                    "userFacId": "$userFacInfo._id",
                    "image": "$image",
                    "email": "$email"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            User.aggregate(aggregate).then(function (userData) {
                var data = {};
                data.data = userData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                User.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    data.total_count = cnt;
                    callback(null, data);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            // console.log("data", data);
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get chat history
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 13-Aug-2018
 */
function getChatHistory(req, res) {
    var finalResponse = {};
    var condition = {
        isDelete: false,
        $and:[{ 
            $or:[
                { sentBy: req.body.receiverId, receivedBy: req.user.uid },
                { sentBy: req.user.uid, receivedBy: req.body.receiverId }
            ]
        }]
    };
    
    Chat.find(condition).exec(function(err, chatHistory){
        if(err){
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        }else{
            res.json({
                code: config.statusCode.success,
                data: chatHistory,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    })
   
}

/**
 * Function is use to send chat message
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 14-Aug-2018
 */
function sendChatMessage(req, res) {
    console.log("send chat message", req.body);
    var finalResponse = {};
    finalResponse.twilioInfo = {};
    finalResponse.visitorData = {};
    waterfall([
        function (callback) { //notify real time communication to employee
            io.emit('newChatMessage', req.body);
            callback(null, finalResponse);
        },
        function (finalResponse, callback) { //save chat history
            var obj = {
                userFacId: mongoose.Types.ObjectId(req.body.userFacId),
                sentBy: mongoose.Types.ObjectId(req.body.sentBy),
                receivedBy: mongoose.Types.ObjectId(req.body.receivedBy),
                message: req.body.message
            }
            var chatRecord = new Chat(obj);
            chatRecord.save(function (err, chatData) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })
        },
    ],
    function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("SMS_SENT_SUCCESSFULLY")
            });
        }
    });
   
}
