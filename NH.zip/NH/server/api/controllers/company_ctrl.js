'use strict';

var mongoose = require('mongoose'),
    generator = require('generate-password'),
    User = mongoose.model('user'),
    Company = mongoose.model('company'),
    UserCompany = mongoose.model('userCompany'),
    formidable = require('formidable'),
    fs = require('fs-extra'),
    path = require('path'),
    jwt = require('jsonwebtoken'),
    validator = require('validator'),
    utility = require('../lib/utility.js'),
    crypto = require('./../lib/crypto.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    Joi = require('joi'),
    i18n = require("i18n"),
    moment = require('moment'),
    emailSend = __rootRequire('api/core/email'),
    convert = require('xml-js'),
    zipcodes = require('zipcodes'),
    Facility = mongoose.model('facility'),
    CheckInOut = mongoose.model('checkInOut'),
    IncidentReports = mongoose.model('incidentReport'),
    config = require('../../config/config.js');

module.exports = {
    addCompany: addCompany,
    getAllCompanyList: getAllCompanyList,
    getCompanyById: getCompanyById,
    updateCompany: updateCompany,
    deleteCompany: deleteCompany,
    activateDeactivateCompany: activateDeactivateCompany,
    exportXml: exportXml,
    getCompanyListForFacilityAdmin: getCompanyListForFacilityAdmin,
    getZipCode: getZipCode,
    updateCompanyProfile: updateCompanyProfile,
    getCompanyDashboardCount: getCompanyDashboardCount,
    getResolvedComplaintPercentage: getResolvedComplaintPercentage,
    getCompanyResponseRate: getCompanyResponseRate,
    getOverAllRatingOfCompany: getOverAllRatingOfCompany,
    companyLinkTracking: companyLinkTracking,
    companyRating: companyRating
}

/**
 * Function is use to add company by admin 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 24-Apr-2018
 */
function addCompany(req, res) {
    var finalResponse = {};
    finalResponse.userData = {};
    finalResponse.cmpData = {};
    finalResponse.userCompanyData = {};
    finalResponse.verifyToken = '';
    finalResponse.verifingLink = '';
    var cmpObj = {
        firstName: req.swagger.params.firstName.value,
        lastName: req.swagger.params.lastName.value,
        cmpName: req.swagger.params.cmpName.value,
        email: req.swagger.params.email.value,
        address: req.swagger.params.address.value,
        city: req.swagger.params.city.value,
        state: req.swagger.params.state.value,
        country: req.swagger.params.country.value,
        zipCode: req.swagger.params.zipCode.value,
        expiryDate: req.swagger.params.expiryDate.value,
        phoneNumber: req.swagger.params.phoneNumber.value,
        stateCode: req.swagger.params.stateCode.value,
        file: req.swagger.params.file.value
    }

    console.log("cmpObj", cmpObj);
    // return;

    if (!cmpObj.firstName || !cmpObj.lastName || !cmpObj.email || !cmpObj.cmpName || !cmpObj.address || !cmpObj.city || !cmpObj.state || !cmpObj.zipCode || !cmpObj.country || !cmpObj.phoneNumber || !cmpObj.expiryDate) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else if (cmpObj.email && !config.isEmail(cmpObj.email)) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("INVALID_EMAIL")
        });
    } else {
        waterfall([
                function (callback) { //Check for already exist Company
                    Company.existCheck(cmpObj.cmpName.trim(), function (err, exist) {
                        if (err) {
                            callback(err, false);
                        } else {
                            if (!exist) {
                                res.json({
                                    code: config.statusCode.badRequest,
                                    data: {},
                                    message: i18n.__("COMPANY_ALREADY_EXIST")
                                });
                            } else {
                                callback(null, finalResponse);
                            }
                        }
                    });
                },
                function (finalResponse, callback) { //Check for already exist Email of user
                    User.existCheck(cmpObj.email.trim(), '', function (err, emailExist) {
                        if (err) {
                            callback(err, false);
                        } else {
                            if (!emailExist) {
                                res.json({
                                    code: config.statusCode.badRequest,
                                    data: {},
                                    message: i18n.__("EMAIL_ALREADY_EXIST")
                                });
                            } else {
                                callback(null, finalResponse);
                            }
                        }
                    });
                },
                function (finalResponse, callback) { //Save User data
                    var randomPassword = generator.generate({
                        length: 10,
                        numbers: true
                    });
                    var passEnc = utility.getEncryptText(randomPassword.toString()); //crypto need string in parameter

                    var obj = {
                        firstName: cmpObj.firstName,
                        lastName: cmpObj.lastName,
                        userName: cmpObj.firstName + ' ' + cmpObj.lastName,
                        role: config.role_type.COMPANY_ADMIN.name,
                        createdBy: config.role_type.SUPER_ADMIN.name,
                        createdById: req.user.uid,
                        phoneNumber: cmpObj.phoneNumber,
                        email: cmpObj.email.toLowerCase(),
                        password: passEnc
                    };

                    var userRecord = new User(obj);
                    userRecord.save(function (err, userData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.userData = userData;
                            callback(null, finalResponse);
                        }
                    });
                },
                function (finalResponse, callback) { //Save company data
                    var newObj = {
                        cmpName: cmpObj.cmpName,
                        address: cmpObj.address,
                        city: cmpObj.city,
                        state: cmpObj.state,
                        country: cmpObj.country,
                        zipCode: cmpObj.zipCode,
                        expiryDate: cmpObj.expiryDate,
                        stateCode: cmpObj.stateCode

                    };
                    var cmpRecord = new Company(newObj);
                    cmpRecord.save(function (err, cmpData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.cmpData = cmpData;
                            if (cmpObj.file) { //Save company logo if file exist
                                var timestamp = Number(new Date()); // current time as number
                                var file = cmpObj.file;
                                var companyId = cmpData._id;
                                var splitFileName = file.originalname.split('.');
                                var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                                var filename = companyId + '_' + timestamp + '.' + ext;
                                var imagePath = "./../client/src/assets/upload/profiles/" + filename; //Used for write file on this path
                                var base_url = config.server_url;

                                utility.fileUpload(path.resolve(imagePath), file.buffer).then(function () {
                                    cmpData.cmpLogo = filename;
                                    cmpData.save(function (err, updateCmpLogo) {
                                        if (err) {
                                            callback(err, false);
                                        } else {
                                            callback(null, finalResponse);
                                        }
                                    })
                                })
                            } else {
                                callback(null, finalResponse);
                            }
                        }
                    });
                },
                function (finalResponse, callback) { //Save User company data
                    var userCompanyData = {
                        userId: finalResponse.userData._id,
                        companyId: finalResponse.cmpData._id
                    };
                    var userCompanyRecord = new UserCompany(userCompanyData);
                    userCompanyRecord.save(function (err, userCompanyData) {
                        console.log("userCompanyData", err, userCompanyData);
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.userCompanyData = userCompanyData;
                            callback(null, finalResponse);
                        }
                    });
                },
                function (finalResponse, callback) { //Create verify link and token to verify the company
                    var date = new Date();
                    finalResponse.verifyToken = utility.getEncryptText(Math.random().toString(4).slice(2) + date.getTime());
                    finalResponse.verifingLink = config.email.base_url + '/verify_account/' + finalResponse.verifyToken;

                    User.findOneAndUpdate({
                        _id: finalResponse.userData._id
                    }, {
                        $set: {
                            verifyToken: finalResponse.verifyToken
                        }
                    }, function (err, updatedUserdata) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    });
                },
                function (finalResponse, callback) { //Send Email to User for verify Account
                    var baseUrl = config.email.base_url;
                    var options = {
                        template: 'verifyAccount.html',
                        from: config.email.from,
                        repalcement: {
                            "{{user.name}}": finalResponse.userData.firstName.charAt(0).toUpperCase() + finalResponse.userData.firstName.slice(1).toLowerCase() + ' ' + finalResponse.userData.lastName.charAt(0).toUpperCase() + finalResponse.userData.lastName.slice(1).toLowerCase(),
                            "{{user.email}}": finalResponse.userData.email,
                            "{{user.password}}": utility.getDecryptText(finalResponse.userData.password),
                            "{{user.url}}": finalResponse.verifingLink,
                            "{{logo_url}}": baseUrl + config.email.logo_url,
                            "{{copyright}}": config.email.copyright,
                            "{{user.login_url}}": baseUrl,
                            "{{link.abuse_email}}": config.email.abuse_email
                        },
                        to: finalResponse.userData.email,
                        subject: 'Verify Account'
                    };
                    emailSend.smtp.sendMail(options, function (err, response) {
                        if (err) {
                            callback(null, finalResponse);
                        } else {
                            callback(null, finalResponse);
                        }
                    })
                }
            ],
            function (err, data) {
                if (err) {
                    res.json({
                        code: config.statusCode.error,
                        data: {},
                        message: i18n.__("INTERNAL_ERROR")
                    });
                } else {
                    res.json({
                        code: config.statusCode.success,
                        data: data,
                        message: i18n.__("COMPANY_CREATED_SUCCESSFULLY")
                    });
                }
            });

    }
}

/**
 * Function is use to fetch company list for admin
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function getAllCompanyList(req, res) {
    var finalResponse = {};
    var orgData = {};
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);

    waterfall([
        function (callback) { //Company Data

            var condition = {};
            condition.isDelete = false;
            condition['userCmpInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.COMPANY_ADMIN.name;

            var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            if (req.body.searchText) {
                condition.$or = [{
                        'userInfo.userName': new RegExp(searchText, 'gi')
                    },
                    {
                        'cmpName': new RegExp(searchText, 'gi')
                    }
                ];
            }
            if (req.body.createdAt) {
                var start_day_date = moment(req.body.createdAt).startOf('day');
                var end_day_date = moment(req.body.createdAt).endOf('day');
                var momentObjFrom = new Date(moment(start_day_date));
                var momentObjTo = new Date(moment(end_day_date));
                condition.$and = [{
                        createdAt: {
                            $gte: momentObjFrom
                        }
                    },
                    {
                        createdAt: {
                            $lte: momentObjTo
                        }
                    }
                ];

            }

            if (req.body.cmpName) {
                condition['cmpName'] = new RegExp(req.body.cmpName, 'gi');
            }
            if (req.body.userName) {
                condition['userInfo.userName'] = new RegExp(req.body.userName, 'gi');
            }

            var aggregate = [{
                    $lookup: {
                        from: 'usercompanies',
                        localField: "_id",
                        foreignField: "companyId",
                        as: "userCmpInfo"
                    }
                },
                {
                    $unwind: "$userCmpInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userCmpInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                },
                {
                    $match: condition
                },
            ];
            // var decpassword = utility.getDecryptText(userInfo.password)
            var project = {

                $project: {
                    "cmpName": "$cmpName",
                    "cmpLogo": "$cmpLogo",
                    "createdAt": "$userInfo.createdAt",
                    "firstName": "$userInfo.firstName",
                    "lastName": "$userInfo.lastName",
                    "userName": "$userInfo.userName",
                    "phoneNumber": "$userInfo.phoneNumber",
                    "email": "$userInfo.email",
                    "status": "$userInfo.status",
                    "userId": "$userInfo._id",
                    "userCmpId": "$userCmpInfo._id",
                    "password": "$userInfo.password"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            aggregate.push({
                $sort: sorting
            });
            aggregate.push({
                $skip: parseInt(skip)
            });
            aggregate.push({
                $limit: parseInt(count)
            });
            Company.aggregate(aggregate).then(function (cmpData) {
                for (var i = 0; i < cmpData.length; i++) {
                    cmpData[i].password = utility.getDecryptText(cmpData[i].password)

                }
                var data = {};
                data.data = cmpData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                Company.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    data.total_count = cnt;
                    callback(null, data);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            console.log("error", err);
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is get company by id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 27-Apr-2018
 */
function getCompanyById(req, res) {
    console.log("req.query.id", req.query.id);
    var finalResponse = {};
    var condition = {};
    if (mongoose.Types.ObjectId.isValid(req.query.id)) {
        condition._id = mongoose.Types.ObjectId(req.query.id);
        condition['userInfo.role'] = config.role_type.COMPANY_ADMIN.name;
        var aggregate = [{
                $lookup: {
                    from: 'usercompanies',
                    localField: "_id",
                    foreignField: "companyId",
                    as: "userCmpInfo"
                }
            },
            {
                $unwind: "$userCmpInfo"
            },
            {
                $lookup: {
                    from: 'users',
                    localField: "userCmpInfo.userId",
                    foreignField: "_id",
                    as: "userInfo"
                }
            },
            {
                $unwind: "$userInfo"
            },
            {
                $match: condition
            },
        ];
        var project = {
            $project: {
                userId: "$userInfo._id",
                userCmpId: "$userCmpInfo._id",
                firstName: "$userInfo.firstName",
                lastName: "$userInfo.lastName",
                phoneNumber: "$userInfo.phoneNumber",
                email: "$userInfo.email",
                cmpName: "$cmpName",
                cmpLogo: "$cmpLogo",
                address: "$address",
                city: "$city",
                state: "$state",
                country: "$country",
                zipCode: "$zipCode",
                expiryDate: "$expiryDate",
                stateCode: "$stateCode",
            }
        };

        var countQuery = [].concat(aggregate);
        aggregate.push(project);

        Company.aggregate(aggregate).then(function (result) {
            finalResponse.data = result[0];
            res.json({
                code: config.statusCode.success,
                data: finalResponse.data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }).catch(function (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        });
    } else {
        res.json({
            code: config.statusCode.invalid,
            data: {},
            message: i18n.__("INVALID_URL")
        });
    }
}

/**
 * Function is use to update company info by id
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function updateCompany(req, res) {
    var email = req.body.email.toLowerCase();
    var finalResponse = {};
    finalResponse.userData = {};
    finalResponse.userCompanyData = {};
    var cmpObj = {
        firstName: req.swagger.params.firstName.value,
        lastName: req.swagger.params.lastName.value,
        cmpName: req.swagger.params.cmpName.value,
        email: req.swagger.params.email.value,
        address: req.swagger.params.address.value,
        city: req.swagger.params.city.value,
        state: req.swagger.params.state.value,
        country: req.swagger.params.country.value,
        zipCode: req.swagger.params.zipCode.value,
        phoneNumber: req.swagger.params.phoneNumber.value,
        file: req.swagger.params.file.value,
        _id: req.swagger.params._id.value,
        userId: req.swagger.params.userId.value,
        userCmpId: req.swagger.params.userCmpId.value,
        stateCode: req.swagger.params.stateCode.value,
        expiryDate: req.swagger.params.expiryDate.value
    }
    if (cmpObj.zipCode != undefined || cmpObj.zipCode != null || cmpobj.zipCode != '') {
        waterfall([
            function (callback) { //check email and company name is already exist
                User.findOne({
                    email: cmpObj.email.trim().toLowerCase(),
                    _id: {
                        $ne: cmpObj.userId
                    },
                    isDelete: false
                }).lean().exec(function (err, userData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (userData) {
                            res.json({
                                code: config.statusCode.badRequest,
                                data: {},
                                message: i18n.__("EMAIL_ALREADY_EXIST")
                            });
                        } else {
                            Company.findOne({
                                cmpName: cmpObj.cmpName,
                                _id: {
                                    $ne: mongoose.Types.ObjectId(cmpObj._id)
                                },
                                isDelete: false
                            }).lean().exec(function (err, cmpData) {
                                if (err) {
                                    callback(err, false);
                                } else {
                                    if (cmpData) {
                                        res.json({
                                            code: config.statusCode.badRequest,
                                            data: {},
                                            message: i18n.__("COMPANY_ALREADY_EXIST")
                                        });
                                    } else {
                                        callback(null, finalResponse);
                                    }
                                }
                            });
                        }
                    }
                });
            },
            function (finalResponse, callback) { //Update user record
                User.findById(cmpObj.userId).exec(function (err, data) {
                    if (err) {
                        callback(err, false);
                    } else {
                        data.firstName = cmpObj.firstName;
                        data.lastName = cmpObj.lastName;
                        data.userName = cmpObj.firstName + ' ' + cmpObj.lastName,
                            data.email = cmpObj.email;
                        data.phoneNumber = cmpObj.phoneNumber;
                        data.modifiedBy = config.role_type.SUPER_ADMIN.name;
                        data.modifiedById = req.user.uid;
                        data.save(function (err, updatedUserData) {
                            if (err) {
                                callback(err, false);
                            } else {
                                finalResponse.userData = data;
                                callback(null, finalResponse);
                            }
                        })
                    }
                });
            },
            function (finalResponse, callback) { //Update company record
                Company.findById(cmpObj._id).exec(function (err, cmpData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        cmpData.cmpName = cmpObj.cmpName;
                        cmpData.address = cmpObj.address;
                        cmpData.city = cmpObj.city;
                        cmpData.state = cmpObj.state;
                        cmpData.country = cmpObj.country;
                        cmpData.zipCode = cmpObj.zipCode;
                        cmpData.expiryDate = cmpObj.expiryDate;
                        cmpData.stateCode = cmpObj.stateCode;
                        cmpData.save(function (err, updateCmpData) {
                            if (err) {
                                callback(err, false);
                            } else {
                                if (cmpObj.file) { //Update logo if exist
                                    var timestamp = Number(new Date()); // current time as number
                                    var file = cmpObj.file;
                                    var companyId = cmpData._id;
                                    var splitFileName = file.originalname.split('.');
                                    var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                                    var filename = companyId + '_' + timestamp + '.' + ext;
                                    var imagePath = "./../client/src/assets/upload/profiles/" + filename;
                                    var base_url = config.server_url;

                                    utility.fileUpload(path.resolve(imagePath), file.buffer).then(function () {
                                        cmpData.cmpLogo = filename;
                                        cmpData.save(function (err, updateCmpLogo) {
                                            if (err) {
                                                callback(err, false);
                                            } else {
                                                callback(null, finalResponse);
                                            }
                                        })
                                    })
                                } else {
                                    callback(null, finalResponse);
                                }
                            }
                        })
                    }
                });
            },
            function (finalResponse, callback) { //Update user company record
                UserCompany.findOne({
                    _id: cmpObj.userCmpId
                }).exec(function (err, foundUserCompanyData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        foundUserCompanyData.userId = finalResponse.userData._id;
                        foundUserCompanyData.companyId = cmpObj._id;
                        foundUserCompanyData.save(function (err, updateUserCmpData) {
                            if (err) {
                                callback(err, false);
                            } else {
                                callback(null, finalResponse);
                            }
                        })
                    }
                })
            },
        ], function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: {},
                    message: i18n.__("UPDATED_SUCCESSFULLY")
                });
            }
        });
    } else {
        res.json({
            code: config.statusCode.error,
            data: {},
            message: i18n.__("Zip code is missing")
        });
    }

}

/**
 * Function is use to delete company account 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function deleteCompany(req, res) {
    var finalResponse = {};

    waterfall([
        function (callback) { //Delete company
            Company.findOneAndUpdate({
                _id: req.body._id
            }, {
                $set: {
                    isDelete: true,
                }
            }, function (err, data) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //delete user company
            UserCompany.findOneAndUpdate({
                _id: req.body.userCmpId
            }, {
                $set: {
                    isDelete: true,
                }
            }, function (err, userCmpdata) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //delete user record
            User.findOneAndUpdate({
                _id: req.body.userId
            }, {
                $set: {
                    isDelete: true,
                    isDeletedBy: config.role_type.SUPER_ADMIN.name,
                    isDeletedById: req.user.uid
                }
            }, function (err, userCmpdata) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("COMPANY_ACCOUNT_DELETED_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to activate-deactivate account 
 * @access private
 * @return json
 * Created by Sunny
 * Updated by VishakaR
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018 ,9-july-2018
 */
function activateDeactivateCompany(req, res) {
    var finalResponse = {};
    waterfall([
            function (callback) { //Activate deactivate company
                Company.findOneAndUpdate({
                    _id: req.body._id
                }, {
                    $set: {
                        status: req.body.status,
                    }
                }, function (err, data) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            },
            function (finalResponse, callback) { //Activate deactivate user company
                UserCompany.findOneAndUpdate({
                    _id: req.body.userCmpId
                }, {
                    $set: {
                        status: req.body.status,
                    }
                }, function (err, userCmpdata) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            },
            function (finalResponse, callback) { //Activate deactivate user record
                if (req.body.status == '1') {
                    if (req.body.by == 'super_admin') {
                        var userObj = {
                            isActivatedBy: config.role_type.SUPER_ADMIN.name,
                            isActivatedById: req.user.uid,
                            status: '1'
                        }
                    } else {
                        var userObj = {
                            isActivatedBy: config.role_type.SUPER_ADMIN.name,
                            isActivatedById: req.user.uid,
                            status: '1'
                        }

                    }

                } else {
                    var userObj = {
                        isDeactivatedBy: config.role_type.SUPER_ADMIN.name,
                        isDeactivatedById: req.user.uid,
                        status: '2'
                    }

                }
                User.findOneAndUpdate({
                    _id: req.body.userId
                }, {
                    $set: userObj
                }, function (err, userCmpdata) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (req.body.status == '1') {
                            UserCompany.findById(req.body.userCmpId).populate('userId').exec(function (err, data) {
                                if (err) {
                                    callback(err, false);
                                } else {
                                    var baseUrl = config.email.base_url;
                                    var options = {
                                        template: 'verifiedAccountBySuperAdmin.html',
                                        from: config.email.from,
                                        repalcement: {
                                            "{{user.name}}": data.userId.firstName.charAt(0).toUpperCase() + data.userId.firstName.slice(1).toLowerCase() + ' ' + data.userId.lastName.charAt(0).toUpperCase() + data.userId.lastName.slice(1).toLowerCase(),
                                            "{{user.email}}": data.userId.email,
                                            "{{user.password}}": utility.getDecryptText(data.userId.password),
                                            "{{user.url}}": finalResponse.verifingLink,
                                            "{{logo_url}}": baseUrl + config.email.logo_url,
                                            "{{copyright}}": config.email.copyright,
                                            "{{user.login_url}}": baseUrl,
                                            "{{link.abuse_email}}": config.email.abuse_email
                                        },
                                        to: data.userId.email,
                                        subject: 'Verified Account By Repute'
                                    };
                                    emailSend.smtp.sendMail(options, function (err, response) {
                                        if (err) {
                                            callback(null, finalResponse);
                                        } else {
                                            callback(null, finalResponse);
                                        }
                                    })
                                }
                            })
                        } else {
                            callback(null, finalResponse);
                        }

                    }
                });
            },
        ],
        function (err, data) {
            if (err) {
                res.json({
                    code: config.statusCode.error,
                    data: {},
                    message: i18n.__("INTERNAL_ERROR")
                });
            } else {
                res.json({
                    code: config.statusCode.success,
                    data: {},
                    message: i18n.__('Company ' + ((req.body.status == 1) ? 'activated' : 'deactivated') + ' successfully')
                });
            }
        });
}

/**
 * Function is use to Export Xml
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 3-May-2018
 */

function exportXml(req, res) {
    var xmlData = req.body;
    var options = {
        compact: true,
        spaces: 4
    };
    var result = convert.json2xml(xmlData, options);
    if (result) {
        res.json({
            code: config.statusCode.success,
            data: result
        });
    }
}

/**
 * Function is use to get Company List For Facility Admin
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 3-May-2018
 */
function getCompanyListForFacilityAdmin(req, res) {

    waterfall([
        function (callback) { //Company Data

            var condition = {};
            condition.isDelete = false;
            condition['userCmpInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.COMPANY_ADMIN.name;

            var aggregate = [{
                    $lookup: {
                        from: 'usercompanies',
                        localField: "_id",
                        foreignField: "companyId",
                        as: "userCmpInfo"
                    }
                },
                {
                    $unwind: "$userCmpInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userCmpInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "cmpName": "$cmpName",
                    "userCmpId": "$userCmpInfo._id"
                }
            };

            aggregate.push(project);
            Company.aggregate(aggregate).then(function (facData) {
                var data = {};
                data = facData;
                console.log("data", data);
                callback(null, data);
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to Get Zip Code On the basis of City and state of the USA 
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 21-May-2018
 */
function getZipCode(req, res) {
    if (!req.body.cityName || !req.body.stateCode) {
        res.json({
            code: config.statusCode.badRequest,
            data: {},
            message: i18n.__("REQUIRED_FIELD_IS_MISSING")
        });
    } else {
        var getZipCodes = zipcodes.lookupByName(req.body.cityName, req.body.stateCode);
        if (getZipCodes.length > 0) {
            res.json({
                code: config.statusCode.success,
                data: getZipCodes,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        } else {
            res.json({
                code: config.statusCode.notFound,
                data: {},
                message: i18n.__("ENTERED_CITY_NOT_FOUND_ZIP_CODE")
            });
        }
    }
}

/**
 * Function is use to update company profile
 * @access private
 * @return json
 * Created by Rahul
 * @smartData Enterprises (I) Ltd
 * Created Date 02-June-2018
 */
function updateCompanyProfile(req, res) {
    var email = req.body.email.toLowerCase();
    var finalResponse = {};
    finalResponse.userData = {};
    finalResponse.userCompanyData = {};
    var cmpObj = {
        firstName: req.swagger.params.firstName.value,
        lastName: req.swagger.params.lastName.value,
        cmpName: req.swagger.params.cmpName.value,
        email: req.swagger.params.email.value,
        address: req.swagger.params.address.value,
        city: req.swagger.params.city.value,
        state: req.swagger.params.state.value,
        country: req.swagger.params.country.value,
        zipCode: req.swagger.params.zipCode.value,
        phoneNumber: req.swagger.params.phoneNumber.value,
        ownerfile: req.swagger.params.ownerfile.value,
        cmpfile: req.swagger.params.cmpfile.value,
        _id: mongoose.Types.ObjectId(req.user.cmpId),
        userId: req.swagger.params.userId.value,
        userCmpId: req.swagger.params.userCmpId.value,
        stateCode: req.swagger.params.stateCode.value
    }
    waterfall([
        function (callback) { //check email and company name is already exist
            User.findOne({
                email: cmpObj.email.trim().toLowerCase(),
                _id: {
                    $ne: cmpObj.userId
                },
                isDelete: false
            }).lean().exec(function (err, userData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (userData) {
                        res.json({
                            code: config.statusCode.badRequest,
                            data: {},
                            message: i18n.__("EMAIL_ALREADY_EXIST")
                        });
                    } else {
                        Company.findOne({
                            cmpName: cmpObj.cmpName,
                            _id: {
                                $ne: mongoose.Types.ObjectId(cmpObj._id)
                            },
                            isDelete: false
                        }).lean().exec(function (err, cmpData) {
                            if (err) {
                                callback(err, false);
                            } else {
                                if (cmpData) {
                                    res.json({
                                        code: config.statusCode.badRequest,
                                        data: {},
                                        message: i18n.__("COMPANY_ALREADY_EXIST")
                                    });
                                } else {
                                    callback(null, finalResponse);
                                }
                            }
                        });
                    }
                }
            });
        },
        function (finalResponse, callback) { //Update user record
            User.findById(cmpObj.userId).exec(function (err, data) {
                if (err) {
                    callback(err, false);
                } else {
                    data.firstName = cmpObj.firstName;
                    data.lastName = cmpObj.lastName;
                    data.userName = cmpObj.firstName + ' ' + cmpObj.lastName,
                        data.email = cmpObj.email;
                    data.phoneNumber = cmpObj.phoneNumber;
                    data.modifiedBy = config.role_type.COMPANY_ADMIN.name;
                    data.modifiedById = req.user.uid;
                    data.save(function (err, updatedUserData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            finalResponse.userData = updatedUserData;
                            if (cmpObj.ownerfile) { //Update logo if exist
                                var timestamp = Number(new Date()); // current time as number
                                var file = cmpObj.ownerfile;
                                var userId = data._id;
                                var splitFileName = file.originalname.split('.');
                                var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                                var filename = userId + '_' + timestamp + '.' + ext;
                                var imagePath = "./../client/src/assets/upload/profiles/" + filename;
                                var base_url = config.server_url;

                                utility.fileUpload(path.resolve(imagePath), file.buffer).then(function () {
                                    data.image = filename;
                                    data.save(function (err, updateProfileImage) {
                                        if (err) {
                                            callback(err, false);
                                        } else {
                                            callback(null, finalResponse);
                                        }
                                    })
                                })
                            } else {
                                callback(null, finalResponse);
                            }
                        }
                    })
                }
            });
        },
        function (finalResponse, callback) { //Update company record
            Company.findById(cmpObj._id).exec(function (err, cmpData) {
                if (err) {
                    callback(err, false);
                } else {
                    cmpData.cmpName = cmpObj.cmpName;
                    cmpData.address = cmpObj.address;
                    cmpData.city = cmpObj.city;
                    cmpData.state = cmpObj.state;
                    cmpData.country = cmpObj.country;
                    cmpData.zipCode = cmpObj.zipCode;
                    cmpData.stateCode = cmpObj.stateCode;
                    cmpData.save(function (err, updateCmpData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            if (cmpObj.cmpfile) { //Update logo if exist
                                var timestamp = Number(new Date()); // current time as number
                                var file = cmpObj.cmpfile;
                                var companyId = cmpData._id;
                                var splitFileName = file.originalname.split('.');
                                var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                                var filename = companyId + '_' + timestamp + '.' + ext;
                                var imagePath = "./../client/src/assets/upload/profiles/" + filename;
                                var base_url = config.server_url;

                                utility.fileUpload(path.resolve(imagePath), file.buffer).then(function () {
                                    cmpData.cmpLogo = filename;
                                    cmpData.save(function (err, updateCmpLogo) {
                                        if (err) {
                                            callback(err, false);
                                        } else {
                                            callback(null, finalResponse);
                                        }
                                    })
                                })
                            } else {
                                callback(null, finalResponse);
                            }
                        }
                    })
                }
            });
        },
        function (finalResponse, callback) { //Update user company record
            UserCompany.findOne({
                _id: cmpObj.userCmpId
            }).exec(function (err, foundUserCompanyData) {
                if (err) {
                    callback(err, false);
                } else {
                    foundUserCompanyData.userId = finalResponse.userData._id;
                    foundUserCompanyData.companyId = cmpObj._id;
                    foundUserCompanyData.save(function (err, updateUserCmpData) {
                        if (err) {
                            callback(err, false);
                        } else {
                            callback(null, finalResponse);
                        }
                    })
                }
            })
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {},
                message: i18n.__("UPDATED_SUCCESSFULLY")
            });
        }
    });

}

/**
 * Function is use to get count for company dashboard
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 1-Aug-2018
 */
function getCompanyDashboardCount(req, res) {
    var finalResponse = {};
    finalResponse.todayDate = req.body.todayDate;
    finalResponse.facilityCount = 0;
    finalResponse.overAll = false;
    finalResponse.momentObjFrom = '';
    finalResponse.momentObjTo = '';
    finalResponse.ratingReceivedCount = 0;
    finalResponse.complaintCount = 0;
    finalResponse.incidentCount = 0;
    finalResponse.companyRatingReceivedArray = [];
    finalResponse.companyIncidentComplaintArray = [];
    waterfall([
        function (callback) { //start and end Data
            var start_day_date = '';
            var end_day_date = '';
            switch (req.body.selectPeriod) {
                case config.selectPeriod.LAST_THIRTY_DAYS:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(29, 'days');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.LAST_SIX_MONTH:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(6, 'months');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    console.log("start_day_date", start_day_date, end_day_date);

                    break;
                case config.selectPeriod.LAST_YEAR:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(1, 'years');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.OVER_ALL:
                    finalResponse.overAll = true;
                    break;
            }
            if(finalResponse.overAll == false){
                finalResponse.momentObjFrom = new Date(moment(start_day_date));
                finalResponse.momentObjTo = new Date(moment(end_day_date));
            }
            callback(null, finalResponse);
        },
        function (finalResponse, callback) { //Get facilities count in particular time period under company 
            var condition = {
                userCmpId: req.user.userCmpId,
                isDelete: false
            }
            if(finalResponse.overAll == false){
                condition.$and = [{
                    createdAt: {
                        $gte: finalResponse.momentObjFrom
                    }
                },
                {
                    createdAt: {
                        $lte: finalResponse.momentObjTo
                    }
                }];
            }
            Facility.find(condition)
            .lean()
            .count()
            .exec(function(err, facilityCount){
                if(err){
                    callback(err, false);
                }else{
                    finalResponse.facilityCount = facilityCount;
                    callback(null, finalResponse);
                }
            })
        },
        function (finalResponse, callback) { //Get facilities under company
            var condition = {};
            condition.isDelete = false;
            condition.userCmpId = mongoose.Types.ObjectId(req.user.userCmpId);
            condition['userFacInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;
            var aggregate = [{
                    $lookup: {
                        from: 'userfacilities',
                        localField: "_id",
                        foreignField: "facilityId",
                        as: "userFacInfo"
                    }
                },
                {
                    $unwind: "$userFacInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userFacInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "userId": "$userInfo._id",
                    "userFacId": "$userFacInfo._id",
                    "facName": "$facName"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Facility.aggregate(aggregate).then(function (facData) {
                finalResponse.facArray = facData;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Get rating received under companies
            async.eachSeries(finalResponse.facArray, function (facilityData, next) {
                var condition = {};
                condition.isDelete = false;
                condition.userFacilityId = mongoose.Types.ObjectId(facilityData.userFacId);
                condition.ratingDone = true;
                if(finalResponse.overAll == false){
                    condition.$and = [{
                        ratingDate: {
                            $gte: finalResponse.momentObjFrom
                        }
                    },
                    {
                        ratingDate: {
                            $lte: finalResponse.momentObjTo
                        }
                    }];
                }
                CheckInOut.find(condition).count().exec(function(err, receivedRatingCount){
                    if(err){
                        callback(err, false);
                    }else{
                        finalResponse.ratingReceivedCount = finalResponse.ratingReceivedCount +  receivedRatingCount;
                        var ratingInfo = {
                            facName: facilityData.facName,
                            ratingReceivedCount: receivedRatingCount
                        }
                        finalResponse.companyRatingReceivedArray.push(ratingInfo);
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })  
        },
        function (finalResponse, callback) { //Get open complaint/Incident Count
            async.eachSeries(finalResponse.facArray, function (facilityData, next) {
                var condition = {};
                condition.isDelete = false;
                condition.userFacId = mongoose.Types.ObjectId(facilityData.userFacId);
                condition.resolved = false;
                condition.incidentType = 'complaint';
                if(finalResponse.overAll == false){
                    condition.$and = [{
                        createdAt: {
                            $gte: finalResponse.momentObjFrom
                        }
                    }, 
                    {
                        createdAt: {
                            $lte: finalResponse.momentObjTo
                        }
                    }];
                }
                IncidentReports.find(condition).count().exec(function(err, complaintCount){
                    if(err){
                        callback(err, false);
                    }else{
                        finalResponse.complaintCount = finalResponse.complaintCount +  complaintCount;
                        condition.incidentType = 'incident'; 
                        IncidentReports.find(condition).count().exec(function(err, incidentCount){
                            if(err){
                                callback(err, false);
                            }else{
                                finalResponse.incidentCount = finalResponse.incidentCount +  incidentCount;
                                var incidentComplaintInfo = {
                                    facName: facilityData.facName,
                                    incidentCount: incidentCount,
                                    complaintCount: complaintCount
                                }
                                finalResponse.companyIncidentComplaintArray.push(incidentComplaintInfo);
                                next();
                            }
                        })
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })  
        },
    ], function (err, data) {
        // console.log("errrer@@@", err, data);
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get percentage of resolved complaints
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 4-Aug-2018
 */
function getResolvedComplaintPercentage(req, res) {
    var finalResponse = {};
    finalResponse.todayDate = req.body.todayDate;
    finalResponse.overAll = false;
    finalResponse.momentObjFrom = '';
    finalResponse.momentObjTo = '';
    finalResponse.complaintCount = 0;
    finalResponse.resolvedComplaintCount = 0;    
    finalResponse.incidentCount = 0;
    finalResponse.resolvedIncidentCount = 0;
    finalResponse.resolvedComplaintPercentage = 0;
    finalResponse.resolvedIncidentPercentage = 0;
    finalResponse.companyResolvedComplaintIncidentArray = [];
    waterfall([
        function (callback) { //start and end date
            var start_day_date = '';
            var end_day_date = '';
            switch (req.body.selectPeriod) {
                case config.selectPeriod.LAST_THIRTY_DAYS:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(29, 'days');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.LAST_SIX_MONTH:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(6, 'months');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    console.log("start_day_date", start_day_date, end_day_date);

                    break;
                case config.selectPeriod.LAST_YEAR:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(1, 'years');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.OVER_ALL:
                    finalResponse.overAll = true;
                    break;
            }
            if(finalResponse.overAll == false){
                finalResponse.momentObjFrom = new Date(moment(start_day_date));
                finalResponse.momentObjTo = new Date(moment(end_day_date));
            }
            callback(null, finalResponse);
        },
        function (finalResponse, callback) { //Get facilities under company
            var condition = {};
            condition.isDelete = false;
            condition.userCmpId = mongoose.Types.ObjectId(req.user.userCmpId);
            condition['userFacInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;
            var aggregate = [{
                    $lookup: {
                        from: 'userfacilities',
                        localField: "_id",
                        foreignField: "facilityId",
                        as: "userFacInfo"
                    }
                },
                {
                    $unwind: "$userFacInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userFacInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "userId": "$userInfo._id",
                    "userFacId": "$userFacInfo._id",
                    "facName": "$facName"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Facility.aggregate(aggregate).then(function (facData) {
                finalResponse.facArray = facData;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Get resolved percentage of facility complaint/Incident under company
            async.eachSeries(finalResponse.facArray, function (facilityData, next) {
                var condition = {};
                condition.isDelete = false;
                condition.userFacId = mongoose.Types.ObjectId(facilityData.userFacId);
                condition.incidentType = 'complaint';
                condition.$or = [
                    {$and:[
                        { resolved: true }, 
                        { resolvedDate: { $gte: finalResponse.momentObjFrom }}, 
                        { resolvedDate: { $lte: finalResponse.momentObjTo}}
                    ]},
                    { resolved: false }
                ]
                IncidentReports.find(condition).count().exec(function(err, complaintCount){
                    if(err){
                        callback(err, false);
                    }else{
                        finalResponse.complaintCount = finalResponse.complaintCount +  complaintCount;
                        condition.incidentType = 'incident'; 
                        IncidentReports.find(condition).count().exec(function(err, incidentCount){
                            if(err){
                                callback(err, false);
                            }else{
                                finalResponse.incidentCount = finalResponse.incidentCount +  incidentCount;
                                delete condition["$or"];
                                condition.resolved = true;
                                if(finalResponse.overAll == false){
                                    condition.$and = [{
                                        resolvedDate: {
                                            $gte: finalResponse.momentObjFrom
                                        }
                                    }, 
                                    {
                                        resolvedDate: {
                                            $lte: finalResponse.momentObjTo
                                        }
                                    }];
                                }
                                IncidentReports.find(condition).count().exec(function(err, resolvedIncidentCount){
                                    if(err){
                                        callback(err, false);
                                    }else{
                                        finalResponse.resolvedIncidentCount = finalResponse.resolvedIncidentCount + resolvedIncidentCount;
                                        condition.incidentType = 'complaint';
                                        IncidentReports.find(condition).count().exec(function(err, resolvedComplaintCount){
                                            if(err){
                                                callback(err, false);
                                            }else{
                                                finalResponse.resolvedComplaintCount = finalResponse.resolvedComplaintCount + resolvedComplaintCount;
                                                var resolvedComplaintPercentage = parseInt((resolvedComplaintCount / complaintCount) * 100);
                                                var resolvedIncidentPercentage = parseInt((resolvedIncidentCount / incidentCount) * 100);
                                                var companyInfo = {
                                                    facName: facilityData.facName,
                                                    resolvedComplaintPercentage: resolvedComplaintPercentage,
                                                    resolvedIncidentPercentage: resolvedIncidentPercentage
                                                }
                                                finalResponse.companyResolvedComplaintIncidentArray.push(companyInfo);
                                                next();
                                            }
                                        })     
                                    }
                                })
                            }
                        })
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })  
        },
        function (finalResponse, callback) { //Get resolved percentage of complaint/Incident under company
            finalResponse.resolvedComplaintPercentage = parseInt((finalResponse.resolvedComplaintCount / finalResponse.complaintCount) * 100);
            finalResponse.resolvedIncidentPercentage = parseInt((finalResponse.resolvedIncidentCount / finalResponse.incidentCount) * 100);
            callback(null, finalResponse);
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get company response rate
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 4-Aug-2018
 */
function getCompanyResponseRate(req, res) {
    var finalResponse = {};
    finalResponse.todayDate = req.body.todayDate;
    finalResponse.overAll = false;
    finalResponse.momentObjFrom = '';
    finalResponse.momentObjTo = '';
    finalResponse.ratingReceivedCount = 0; 
    finalResponse.checkOutSmsSentCount = 0;
    finalResponse.companyResponseRate = 0;
    finalResponse.companyResponseRateArray = [];
    waterfall([
        function (callback) { //start and end date 
            var start_day_date = '';
            var end_day_date = '';
            switch (req.body.selectPeriod) {
                case config.selectPeriod.LAST_THIRTY_DAYS:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(29, 'days');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.LAST_SIX_MONTH:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(6, 'months');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    console.log("start_day_date", start_day_date, end_day_date);
                    break;
                case config.selectPeriod.LAST_YEAR:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(1, 'years');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.OVER_ALL:
                    finalResponse.overAll = true;
                    break;
            }
            if(finalResponse.overAll == false){
                finalResponse.momentObjFrom = new Date(moment(start_day_date));
                finalResponse.momentObjTo = new Date(moment(end_day_date));
            }
            callback(null, finalResponse);
        },
        function (finalResponse, callback) { //Get facilities under company
            var condition = {};
            condition.isDelete = false;
            condition.userCmpId = mongoose.Types.ObjectId(req.user.userCmpId);
            condition['userFacInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;
            var aggregate = [{
                    $lookup: {
                        from: 'userfacilities',
                        localField: "_id",
                        foreignField: "facilityId",
                        as: "userFacInfo"
                    }
                },
                {
                    $unwind: "$userFacInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userFacInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "userId": "$userInfo._id",
                    "userFacId": "$userFacInfo._id",
                    "facName": "$facName"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Facility.aggregate(aggregate).then(function (facData) {
                finalResponse.facArray = facData;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Get response rate under company
            async.eachSeries(finalResponse.facArray, function (facilityData, next) {
                var condition = {};
                condition.isDelete = false,
                condition.userFacilityId = mongoose.Types.ObjectId(facilityData.userFacId),
                condition.checkOutSmsSent = true;
                condition.ratingDone = true;
                if(finalResponse.overAll == false){
                    condition.$and = [{
                        ratingDate: {
                            $gte: finalResponse.momentObjFrom
                        }
                    }, 
                    {
                        ratingDate: {
                            $lte: finalResponse.momentObjTo
                        }
                    },
                    {
                        checkOutSmsSentDate: {
                            $gte: finalResponse.momentObjFrom
                        }
                    }, 
                    {
                        checkOutSmsSentDate: {
                            $lte: finalResponse.momentObjTo
                        }
                    }];
                }
                CheckInOut.find(condition).count().exec(function (err, ratingReceivedCount) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.ratingReceivedCount = finalResponse.ratingReceivedCount + ratingReceivedCount;
                        delete condition["ratingDone"];                        
                        if(finalResponse.overAll == false){
                            delete condition["$and"];
                            condition.$and = [{
                                checkOutSmsSentDate: {
                                    $gte: finalResponse.momentObjFrom
                                }
                            }, 
                            {
                                checkOutSmsSentDate: {
                                    $lte: finalResponse.momentObjTo
                                }
                            }];     
                        }
                        CheckInOut.find(condition).count().exec(function (err, checkOutSmsSentCount) {
                            if (err) {
                                callback(err, false);
                            } else {
                                finalResponse.checkOutSmsSentCount = finalResponse.checkOutSmsSentCount + checkOutSmsSentCount;
                                var companyResponseRate = parseInt((ratingReceivedCount / checkOutSmsSentCount) * 100);
                                var companyInfo = {
                                    facName: facilityData.facName,
                                    companyResponseRate: companyResponseRate
                                }
                                finalResponse.companyResponseRateArray.push(companyInfo);
                                next();
                            }
                        });
                    }
                });
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })  
        },
        function (finalResponse, callback) { //Get percentage of response rate under company
            finalResponse.companyResponseRate = parseInt((finalResponse.ratingReceivedCount / finalResponse.checkOutSmsSentCount) * 100);
            callback(null, finalResponse);
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            // console.log("finalResponse", data);
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get company overall ratig
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 4-Aug-2018
 */
function getOverAllRatingOfCompany(req, res) {
    var finalResponse = {};
    finalResponse.overAll = false;
    finalResponse.momentObjFrom = '';
    finalResponse.momentObjTo = '';
    finalResponse.negativeRatingCount = 0; 
    finalResponse.positiveRatingCount = 0;
    finalResponse.positiveRatingPercent = 0;
    finalResponse.negativeRatingPercent = 0;
    waterfall([
        function (callback) { //get facilities under company 
            var condition = {};
            condition.isDelete = false;
            condition.userCmpId = mongoose.Types.ObjectId(req.user.userCmpId);
            condition['userFacInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;
            var aggregate = [{
                    $lookup: {
                        from: 'userfacilities',
                        localField: "_id",
                        foreignField: "facilityId",
                        as: "userFacInfo"
                    }
                },
                {
                    $unwind: "$userFacInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userFacInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "userId": "$userInfo._id",
                    "userFacId": "$userFacInfo._id"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Facility.aggregate(aggregate).then(function (facData) {
                finalResponse.facArray = facData;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Get positive and negative ratings under company
            async.eachSeries(finalResponse.facArray, function (facilityData, next) {
                var condition = {
                    isDelete: false,
                    ratingStatus: 'negative',
                    userFacilityId: mongoose.Types.ObjectId(facilityData.userFacId)
                };
                CheckInOut.find(condition).count().exec(function (err, negativeRatingCount) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.negativeRatingCount = finalResponse.negativeRatingCount + negativeRatingCount;
                        condition.ratingStatus = 'positive';
                        CheckInOut.find(condition).count().exec(function (err, positiveRatingCount) {
                            if (err) {
                                callback(err, false);
                            } else {
                                finalResponse.positiveRatingCount = finalResponse.positiveRatingCount + positiveRatingCount;
                                next();
                            }
                        });     
                    }
                });
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })  
        },
        function (finalResponse, callback) { //calculate percentage of negative and positive ratings under company
            finalResponse.positiveRatingPercent = parseInt(finalResponse.positiveRatingCount / (finalResponse.positiveRatingCount + finalResponse.negativeRatingCount) * 100);
            finalResponse.negativeRatingPercent = parseInt(finalResponse.negativeRatingCount / (finalResponse.positiveRatingCount + finalResponse.negativeRatingCount) * 100);
            callback(null, finalResponse);            
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get company link Tracking
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 6-Aug-2018
 */
function companyLinkTracking(req, res) {
    var finalResponse = {};
    finalResponse.overAll = false;
    finalResponse.todayDate = req.body.todayDate;
    finalResponse.overAllLinkTrackingArray = [];
    finalResponse.momentObjFrom = '';
    finalResponse.momentObjTo = '';
    finalResponse.overAllLinkTrackingCount = 0;
    waterfall([
        function (callback) { //start and end date 
            var start_day_date = '';
            var end_day_date = '';
            switch (req.body.selectPeriod) {
                case config.selectPeriod.LAST_THIRTY_DAYS:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(29, 'days');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.LAST_SIX_MONTH:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(6, 'months');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    console.log("start_day_date", start_day_date, end_day_date);
                    break;
                case config.selectPeriod.LAST_YEAR:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(1, 'years');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.OVER_ALL:
                    finalResponse.overAll = true;
                    break;
            }
            if(finalResponse.overAll == false){
                finalResponse.momentObjFrom = new Date(moment(start_day_date));
                finalResponse.momentObjTo = new Date(moment(end_day_date));
            }
            callback(null, finalResponse);
        },
        function (finalResponse, callback) { //get facilities under company 
            var condition = {};
            condition.isDelete = false;
            condition.userCmpId = mongoose.Types.ObjectId(req.user.userCmpId);
            condition['userFacInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;
            var aggregate = [{
                    $lookup: {
                        from: 'userfacilities',
                        localField: "_id",
                        foreignField: "facilityId",
                        as: "userFacInfo"
                    }
                },
                {
                    $unwind: "$userFacInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userFacInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "userId": "$userInfo._id",
                    "userFacId": "$userFacInfo._id",
                    "facName": "$facName"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Facility.aggregate(aggregate).then(function (facData) {
                finalResponse.facArray = facData;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Get over all link tracking under company
            async.eachSeries(finalResponse.facArray, function (facilityData, next) {
                var condition = {
                    isDelete: false,
                    status: '0',
                    ratingDone: true,
                    sentOnlineLinkInSms: true,
                    viewedLink: true,
                    userFacilityId: mongoose.Types.ObjectId(facilityData.userFacId)
                }; 

                if(finalResponse.overAll == false){
                    condition.$and = [{
                        viewedLinkDate: {
                            $gte: finalResponse.momentObjFrom
                        }
                    },
                    {
                        viewedLinkDate: {
                            $lte: finalResponse.momentObjTo
                        }
                    }];
                } 

                CheckInOut.find(condition).count().exec(function(err, linkTrackingCount){
                    if(err){
                        callback(err, false);
                    }else{
                        finalResponse.overAllLinkTrackingCount = finalResponse.overAllLinkTrackingCount + linkTrackingCount;
                        var linkInfo = {
                            facName: facilityData.facName,
                            linkTrackingCount: linkTrackingCount
                        }
                        finalResponse.overAllLinkTrackingArray.push(linkInfo);
                        next();
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })  
        }
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get company positive rating counts
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 7-Aug-2018
 */
function companyRating(req, res) {
    var finalResponse = {};
    finalResponse.overAll = false;
    finalResponse.todayDate = req.body.todayDate;
    finalResponse.companyRatingArray = [];
    finalResponse.momentObjFrom = '';
    finalResponse.momentObjTo = '';
    finalResponse.positiveRatingCount = 0;
    finalResponse.negativeRatingCount = 0;
    waterfall([
        function (callback) { //start and end date 
            var start_day_date = '';
            var end_day_date = '';
            switch (req.body.selectPeriod) {
                case config.selectPeriod.LAST_THIRTY_DAYS:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(29, 'days');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.LAST_SIX_MONTH:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(6, 'months');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    console.log("start_day_date", start_day_date, end_day_date);
                    break;
                case config.selectPeriod.LAST_YEAR:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(1, 'years');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.OVER_ALL:
                    finalResponse.overAll = true;
                    break;
            }
            if(finalResponse.overAll == false){
                finalResponse.momentObjFrom = new Date(moment(start_day_date));
                finalResponse.momentObjTo = new Date(moment(end_day_date));
            }
            callback(null, finalResponse);
        },
        function (finalResponse, callback) { //get facilities under company 
            var condition = {};
            condition.isDelete = false;
            condition.userCmpId = mongoose.Types.ObjectId(req.user.userCmpId);
            condition['userFacInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;
            var aggregate = [{
                    $lookup: {
                        from: 'userfacilities',
                        localField: "_id",
                        foreignField: "facilityId",
                        as: "userFacInfo"
                    }
                },
                {
                    $unwind: "$userFacInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userFacInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "userId": "$userInfo._id",
                    "userFacId": "$userFacInfo._id",
                    "facName": "$facName"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Facility.aggregate(aggregate).then(function (facData) {
                finalResponse.facArray = facData;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Get positive and negative ratings under company
            async.eachSeries(finalResponse.facArray, function (facilityData, next) {
                var condition = {
                    isDelete: false,
                    status: '0',
                    ratingDone: true,
                    ratingStatus: 'positive',
                    userFacilityId: mongoose.Types.ObjectId(facilityData.userFacId)
                };
                if(finalResponse.overAll == false){
                    condition.$and = [{
                        ratingDate: {
                            $gte: finalResponse.momentObjFrom
                        }
                    },
                    {
                        ratingDate: {
                            $lte: finalResponse.momentObjTo
                        }
                    }];
                } 

                CheckInOut.find(condition).count().exec(function(err, positiveRatingCount){
                    if(err){
                        callback(err, false);
                    }else{
                        finalResponse.positiveRatingCount = finalResponse.positiveRatingCount + positiveRatingCount;
                        var linkInfo = {
                            facName: facilityData.facName,
                            positiveRatingCount: positiveRatingCount
                        }
                        condition.ratingStatus = 'negative';
                        CheckInOut.find(condition).count().exec(function(err, negativeRatingCount){
                            if(err){
                                callback(err, false);
                            }else{
                                finalResponse.negativeRatingCount = finalResponse.negativeRatingCount + negativeRatingCount;
                                linkInfo.negativeRatingCount = negativeRatingCount;
                                finalResponse.companyRatingArray.push(linkInfo);
                                next();
                            }
                        })
                    }
                })
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })  
        }
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}