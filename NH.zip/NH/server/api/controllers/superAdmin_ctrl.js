'use strict';

var mongoose = require('mongoose'),
    generator = require('generate-password'),
    User = mongoose.model('user'),
    Company = mongoose.model('company'),
    UserCompany = mongoose.model('userCompany'),
    formidable = require('formidable'),
    fs = require('fs-extra'),
    path = require('path'),
    jwt = require('jsonwebtoken'),
    validator = require('validator'),
    utility = require('../lib/utility.js'),
    crypto = require('./../lib/crypto.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    Joi = require('joi'),
    i18n = require("i18n"),
    moment = require('moment'),
    emailSend = __rootRequire('api/core/email'),
    convert = require('xml-js'),
    zipcodes = require('zipcodes'),
    Facility = mongoose.model('facility'),
    CheckInOut = mongoose.model('checkInOut'),
    IncidentReports = mongoose.model('incidentReport'),
    config = require('../../config/config.js');

module.exports = {
    getOverAllRatingByAdmin: getOverAllRatingByAdmin,
    getSuperAdminDashboardCount: getSuperAdminDashboardCount,
    getResolvedComplaintPercentageBySuperAdmin: getResolvedComplaintPercentageBySuperAdmin,
    getResponseRateBySuperAdmin: getResponseRateBySuperAdmin,
    ratingBySuperAdmin: ratingBySuperAdmin,
    linkTrackingBySuperAdmin: linkTrackingBySuperAdmin
}

/**
 * Function is use to get organization overall rating
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 23-Aug-2018
 */
function getOverAllRatingByAdmin(req, res) {
    var finalResponse = {};
    finalResponse.overAll = false;
    finalResponse.momentObjFrom = '';
    finalResponse.momentObjTo = '';
    finalResponse.negativeRatingCount = 0; 
    finalResponse.positiveRatingCount = 0;
    finalResponse.positiveRatingPercent = 0;
    finalResponse.negativeRatingPercent = 0;
    waterfall([
        function (callback) { //get all facilities under organization 
            var condition = {};
            condition.isDelete = false;
            condition['userFacInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;
            var aggregate = [{
                    $lookup: {
                        from: 'userfacilities',
                        localField: "_id",
                        foreignField: "facilityId",
                        as: "userFacInfo"
                    }
                },
                {
                    $unwind: "$userFacInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userFacInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "userId": "$userInfo._id",
                    "userFacId": "$userFacInfo._id"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Facility.aggregate(aggregate).then(function (facData) {
                finalResponse.facArray = facData;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Get positive and negative ratings under organization
            async.eachSeries(finalResponse.facArray, function (facilityData, next) {
                var condition = {
                    isDelete: false,
                    ratingStatus: 'negative',
                    userFacilityId: mongoose.Types.ObjectId(facilityData.userFacId)
                };
                CheckInOut.find(condition).count().exec(function (err, negativeRatingCount) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.negativeRatingCount = finalResponse.negativeRatingCount + negativeRatingCount;
                        condition.ratingStatus = 'positive';
                        CheckInOut.find(condition).count().exec(function (err, positiveRatingCount) {
                            if (err) {
                                callback(err, false);
                            } else {
                                finalResponse.positiveRatingCount = finalResponse.positiveRatingCount + positiveRatingCount;
                                next();
                            }
                        });     
                    }
                });
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })  
        },
        function (finalResponse, callback) { //calculate percentage of negative and positive ratings under organization
            finalResponse.positiveRatingPercent = parseInt(finalResponse.positiveRatingCount / (finalResponse.positiveRatingCount + finalResponse.negativeRatingCount) * 100);
            finalResponse.negativeRatingPercent = parseInt(finalResponse.negativeRatingCount / (finalResponse.positiveRatingCount + finalResponse.negativeRatingCount) * 100);
            callback(null, finalResponse);            
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: data,
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get count for super admin dashboard
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 23-Aug-2018
 */
function getSuperAdminDashboardCount(req, res) {
    var finalResponse = {};
    finalResponse.todayDate = req.body.todayDate;
    finalResponse.cmpCount = 0;
    finalResponse.facCount = 0;
    finalResponse.totalCmpCount = 0;
    finalResponse.totalFacCount = 0;
    finalResponse.overAll = false;
    finalResponse.momentObjFrom = '';
    finalResponse.momentObjTo = '';
    finalResponse.cmpArray = [];
    finalResponse.cmpRecord = [];
    finalResponse.ratingReceivedCount = 0;
    finalResponse.complaintCount = 0;
    finalResponse.incidentCount = 0;
    finalResponse.companyRecordRatingReceivedArray = [];
    waterfall([
        function (callback) { //start and end Data
            var start_day_date = '';
            var end_day_date = '';
            switch (req.body.selectPeriod) {
                case config.selectPeriod.LAST_THIRTY_DAYS:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(29, 'days');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.LAST_SIX_MONTH:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(6, 'months');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    console.log("start_day_date", start_day_date, end_day_date);

                    break;
                case config.selectPeriod.LAST_YEAR:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(1, 'years');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.OVER_ALL:
                    finalResponse.overAll = true;
                    break;
            }
            if(finalResponse.overAll == false){
                finalResponse.momentObjFrom = new Date(moment(start_day_date));
                finalResponse.momentObjTo = new Date(moment(end_day_date));
            }
            callback(null, finalResponse);
        },
        function (finalResponse, callback) { //Get companies count in particular time period under organization 
            var condition = {
                isDelete: false
            }
            if(finalResponse.overAll == false){
                condition.$and = [{
                    createdAt: {
                        $gte: finalResponse.momentObjFrom
                    }
                },
                {
                    createdAt: {
                        $lte: finalResponse.momentObjTo
                    }
                }];
            }
            Company.find(condition)
            .lean()
            .count()
            .exec(function(err, cmpCount){
                if(err){
                    callback(err, false);
                }else{
                    finalResponse.cmpCount = cmpCount;
                    callback(null, finalResponse);
                }
            })
        },
        function (finalResponse, callback) { //Get facilities count in particular time period under organization 
            var condition = {
                isDelete: false,
                userCmpId: { $exists: true }
            }
            Facility.find(condition)
            .lean()
            .count()
            .exec(function(err, totalFacCount){
                if(err){
                    callback(err, false);
                }else{
                    finalResponse.totalFacCount = totalFacCount;
                    if(finalResponse.overAll == false){
                        condition.$and = [{
                            createdAt: {
                                $gte: finalResponse.momentObjFrom
                            }
                        },
                        {
                            createdAt: {
                                $lte: finalResponse.momentObjTo
                            }
                        }];
                    }
                    Facility.find(condition)
                    .lean()
                    .count()
                    .exec(function(err, facCount){
                        if(err){
                            callback(err, false);
                        }else{
                            finalResponse.facCount = facCount;
                            callback(null, finalResponse);
                        }
                    })
                }
            })
        },
        function (finalResponse, callback) { //Get companies under organization
            var condition = {};
            condition.isDelete = false;
            condition['userCmpInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.COMPANY_ADMIN.name;
            var aggregate = [{
                    $lookup: {
                        from: 'usercompanies',
                        localField: "_id",
                        foreignField: "companyId",
                        as: "userCmpInfo"
                    }
                },
                {
                    $unwind: "$userCmpInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userCmpInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "userId": "$userInfo._id",
                    "userCmpId": "$userCmpInfo._id",
                    "cmpName": "$cmpName"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Company.aggregate(aggregate).then(function (cmpData) {
                finalResponse.cmpArray = cmpData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                Company.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    finalResponse.totalCmpCount = cnt;
                    callback(null, finalResponse);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Get facilities under company
            async.eachSeries(finalResponse.cmpArray, function (cmpData, next) {
                var condition = {};
                condition.isDelete = false;
                condition.userCmpId = mongoose.Types.ObjectId(cmpData.userCmpId);
                condition['userFacInfo.isDelete'] = false;
                condition['userInfo.isDelete'] = false;
                condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;
                var aggregate = [{
                        $lookup: {
                            from: 'userfacilities',
                            localField: "_id",
                            foreignField: "facilityId",
                            as: "userFacInfo"
                        }
                    },
                    {
                        $unwind: "$userFacInfo"
                    },
                    {
                        $lookup: {
                            from: 'users',
                            localField: "userFacInfo.userId",
                            foreignField: "_id",
                            as: "userInfo"
                        }
                    },
                    {
                        $unwind: "$userInfo"
                    },
                    {
                        $match: condition
                    },
                ];
                var project = {
                    $project: {
                        "userId": "$userInfo._id",
                        "userFacId": "$userFacInfo._id",
                        "facName": "$facName"
                    }
                };
    
                aggregate.push(project);
                var countQuery = [].concat(aggregate);
                Facility.aggregate(aggregate).then(function (facData) {
                    finalResponse.facArray = facData;
                    var obj = {
                        userCmpId: cmpData.userCmpId,
                        cmpName: cmpData.cmpName,
                        cmpUserId: cmpData.userId,
                        facArray: finalResponse.facArray
                    }
                    finalResponse.cmpRecord.push(obj)
                    next();
                }).catch(function (err) {
                    next();
                });
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })  
        },
        function (finalResponse, callback) { //Get rating received and open complaint/Incident Count under organization
            async.eachSeries(finalResponse.cmpRecord, function (cmpData, nextCmp) {
                var cmpObj = {};
                cmpObj.ratingReceivedCount = 0;
                cmpObj.complaintCount = 0;
                cmpObj.incidentCount = 0;                
                cmpObj.companyRatingReceivedArray = [];
                async.eachSeries(cmpData.facArray, function (facilityData, next) {
                    var condition = {};
                    condition.isDelete = false;
                    condition.userFacilityId = mongoose.Types.ObjectId(facilityData.userFacId);
                    condition.ratingDone = true;
                    if(finalResponse.overAll == false){
                        condition.$and = [{
                            ratingDate: {
                                $gte: finalResponse.momentObjFrom
                            }
                        },
                        {
                            ratingDate: {
                                $lte: finalResponse.momentObjTo
                            }
                        }];
                    }
                    CheckInOut.find(condition).count().exec(function(err, receivedRatingCount){
                        if(err){
                            callback(err, false);
                        }else{
                            cmpObj.ratingReceivedCount = cmpObj.ratingReceivedCount +  receivedRatingCount;
                            finalResponse.ratingReceivedCount = finalResponse.ratingReceivedCount + receivedRatingCount;
                            var condition = {};
                            condition.isDelete = false;
                            condition.userFacId = mongoose.Types.ObjectId(facilityData.userFacId);
                            condition.resolved = false;
                            condition.incidentType = 'complaint';
                            if(finalResponse.overAll == false){
                                condition.$and = [{
                                    createdAt: {
                                        $gte: finalResponse.momentObjFrom
                                    }
                                }, 
                                {
                                    createdAt: {
                                        $lte: finalResponse.momentObjTo
                                    }
                                }];
                            }
                            IncidentReports.find(condition).count().exec(function(err, complaintCount){
                                if(err){
                                    callback(err, false);
                                }else{
                                    cmpObj.complaintCount = cmpObj.complaintCount +  complaintCount;
                                    finalResponse.complaintCount = finalResponse.complaintCount + complaintCount;
                                    condition.incidentType = 'incident'; 
                                    IncidentReports.find(condition).count().exec(function(err, incidentCount){
                                        if(err){
                                            callback(err, false);
                                        }else{
                                            cmpObj.incidentCount = cmpObj.incidentCount +  incidentCount;
                                            finalResponse.incidentCount = finalResponse.incidentCount + incidentCount;                            
                                            var ratingInfo = {
                                                facName: facilityData.facName,
                                                incidentCount: incidentCount,
                                                complaintCount: complaintCount,
                                                ratingReceivedCount: receivedRatingCount
                                            }
                                            cmpObj.companyRatingReceivedArray.push(ratingInfo);
                                            next();
                                        }
                                    })
                                }
                            })
                        }
                    })
                }, function (err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        cmpObj.cmpName = cmpData.cmpName;
                        finalResponse.companyRecordRatingReceivedArray.push(cmpObj);
                        nextCmp();
                    }
                })  
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            }) 
        }
    ], function (err, data) {
        // console.log("errrer@@@", err, data.totalFacCount);
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: { 
                    companyRecordRatingReceivedArray: data.companyRecordRatingReceivedArray, 
                    cmpCount: data.cmpCount,
                    ratingReceivedCount: data.ratingReceivedCount,
                    incidentCount: data.incidentCount,
                    complaintCount: data.complaintCount,
                    totalCmpCount: data.totalCmpCount,
                    totalFacCount: data.totalFacCount,
                    facCount: data.facCount  
                },
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get percentage of resolved complaints by super admin
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 23-Aug-2018
 */
function getResolvedComplaintPercentageBySuperAdmin(req, res) {
    var finalResponse = {};
    finalResponse.todayDate = req.body.todayDate;
    finalResponse.overAll = false;
    finalResponse.momentObjFrom = '';
    finalResponse.momentObjTo = '';
    finalResponse.cmpArray = [];
    finalResponse.cmpRecord = [];
    finalResponse.complaintCount = 0;
    finalResponse.resolvedComplaintCount = 0;    
    finalResponse.incidentCount = 0;
    finalResponse.resolvedIncidentCount = 0;
    finalResponse.resolvedComplaintPercentage = 0;
    finalResponse.resolvedIncidentPercentage = 0;
    finalResponse.companyResolvedComplaintIncidentArray = [];

    waterfall([
        function (callback) { //start and end date
            var start_day_date = '';
            var end_day_date = '';
            switch (req.body.selectPeriod) {
                case config.selectPeriod.LAST_THIRTY_DAYS:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(29, 'days');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.LAST_SIX_MONTH:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(6, 'months');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    console.log("start_day_date", start_day_date, end_day_date);

                    break;
                case config.selectPeriod.LAST_YEAR:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(1, 'years');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.OVER_ALL:
                    finalResponse.overAll = true;
                    break;
            }
            if(finalResponse.overAll == false){
                finalResponse.momentObjFrom = new Date(moment(start_day_date));
                finalResponse.momentObjTo = new Date(moment(end_day_date));
            }
            callback(null, finalResponse);
        },
        function (finalResponse, callback) { //Get companies under organization
            var condition = {};
            condition.isDelete = false;
            condition['userCmpInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.COMPANY_ADMIN.name;
            var aggregate = [{
                    $lookup: {
                        from: 'usercompanies',
                        localField: "_id",
                        foreignField: "companyId",
                        as: "userCmpInfo"
                    }
                },
                {
                    $unwind: "$userCmpInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userCmpInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "userId": "$userInfo._id",
                    "userCmpId": "$userCmpInfo._id",
                    "cmpName": "$cmpName"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Company.aggregate(aggregate).then(function (cmpData) {
                finalResponse.cmpArray = cmpData;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Get facilities under company
            async.eachSeries(finalResponse.cmpArray, function (cmpData, next) {
                var condition = {};
                condition.isDelete = false;
                condition.userCmpId = mongoose.Types.ObjectId(cmpData.userCmpId);
                condition['userFacInfo.isDelete'] = false;
                condition['userInfo.isDelete'] = false;
                condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;
                var aggregate = [{
                        $lookup: {
                            from: 'userfacilities',
                            localField: "_id",
                            foreignField: "facilityId",
                            as: "userFacInfo"
                        }
                    },
                    {
                        $unwind: "$userFacInfo"
                    },
                    {
                        $lookup: {
                            from: 'users',
                            localField: "userFacInfo.userId",
                            foreignField: "_id",
                            as: "userInfo"
                        }
                    },
                    {
                        $unwind: "$userInfo"
                    },
                    {
                        $match: condition
                    },
                ];
                var project = {
                    $project: {
                        "userId": "$userInfo._id",
                        "userFacId": "$userFacInfo._id",
                        "facName": "$facName"
                    }
                };
    
                aggregate.push(project);
                var countQuery = [].concat(aggregate);
                Facility.aggregate(aggregate).then(function (facData) {
                    var obj = {
                        userCmpId: cmpData.userCmpId,
                        cmpName: cmpData.cmpName,
                        cmpUserId: cmpData.userId,
                        facArray: facData
                    }
                    finalResponse.cmpRecord.push(obj)
                    next();
                }).catch(function (err) {
                    next();
                });
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })  
        },
        function (finalResponse, callback) { //Get resolved percentage of facility complaint/Incident under organization
            async.eachSeries(finalResponse.cmpRecord, function (cmpData, nextCmp) {
                var cmpObj = {};
                cmpObj.complaintCount = 0;
                cmpObj.incidentCount = 0; 
                cmpObj.resolvedIncidentCount = 0;                
                cmpObj.resolvedComplaintCount = 0;   
                cmpObj.resolvedComplaintPercentage = 0;                             
                cmpObj.resolvedIncidentPercentage = 0;                             
                cmpObj.companyResolvedComplaintIncidentArray = [];
                async.eachSeries(cmpData.facArray, function (facilityData, next) {
                    var condition = {};
                    condition.isDelete = false;
                    condition.userFacId = mongoose.Types.ObjectId(facilityData.userFacId);
                    condition.incidentType = 'complaint';
                    condition.$or = [
                        {$and:[
                            { resolved: true }, 
                            { resolvedDate: { $gte: finalResponse.momentObjFrom }}, 
                            { resolvedDate: { $lte: finalResponse.momentObjTo}}
                        ]},
                        { resolved: false }
                    ]
                    IncidentReports.find(condition).count().exec(function(err, complaintCount){
                        if(err){
                            callback(err, false);
                        }else{
                            cmpObj.complaintCount = cmpObj.complaintCount + complaintCount;
                            finalResponse.complaintCount = finalResponse.complaintCount +  complaintCount;
                            condition.incidentType = 'incident'; 
                            IncidentReports.find(condition).count().exec(function(err, incidentCount){
                                if(err){
                                    callback(err, false);
                                }else{
                                    cmpObj.incidentCount = cmpObj.incidentCount + incidentCount;
                                    finalResponse.incidentCount = finalResponse.incidentCount +  incidentCount;
                                    delete condition["$or"];
                                    condition.resolved = true;
                                    if(finalResponse.overAll == false){
                                        condition.$and = [{
                                            resolvedDate: {
                                                $gte: finalResponse.momentObjFrom
                                            }
                                        }, 
                                        {
                                            resolvedDate: {
                                                $lte: finalResponse.momentObjTo
                                            }
                                        }];
                                    }
                                    IncidentReports.find(condition).count().exec(function(err, resolvedIncidentCount){
                                        if(err){
                                            callback(err, false);
                                        }else{
                                            cmpObj.resolvedIncidentCount = cmpObj.resolvedIncidentCount + resolvedIncidentCount;
                                            finalResponse.resolvedIncidentCount = finalResponse.resolvedIncidentCount + resolvedIncidentCount;
                                            condition.incidentType = 'complaint';
                                            IncidentReports.find(condition).count().exec(function(err, resolvedComplaintCount){
                                                if(err){
                                                    callback(err, false);
                                                }else{
                                                    cmpObj.resolvedComplaintCount = cmpObj.resolvedComplaintCount + resolvedComplaintCount;
                                                    finalResponse.resolvedComplaintCount = finalResponse.resolvedComplaintCount + resolvedComplaintCount;
                                                    var resolvedComplaintPercentage = parseInt((resolvedComplaintCount / complaintCount) * 100);
                                                    var resolvedIncidentPercentage = parseInt((resolvedIncidentCount / incidentCount) * 100);
                                                    var facInfo = {
                                                        facName: facilityData.facName,
                                                        resolvedComplaintPercentage: resolvedComplaintPercentage,
                                                        resolvedIncidentPercentage: resolvedIncidentPercentage
                                                    }
                                                    cmpObj.companyResolvedComplaintIncidentArray.push(facInfo);
                                                    next();
                                                }
                                            })     
                                        }
                                    })
                                }
                            })
                        }
                    })
                }, function (err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        cmpObj.cmpName = cmpData.cmpName;
                        cmpObj.resolvedComplaintPercentage = parseInt((cmpObj.resolvedComplaintCount / cmpObj.complaintCount) * 100);
                        cmpObj.resolvedIncidentPercentage = parseInt((cmpObj.resolvedIncidentCount / cmpObj.incidentCount) * 100);
                        finalResponse.companyResolvedComplaintIncidentArray.push(cmpObj);
                        nextCmp();
                    }
                })   
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            }) 
        },
        function (finalResponse, callback) { //Get resolved percentage of complaint/Incident under organization
            finalResponse.resolvedComplaintPercentage = parseInt((finalResponse.resolvedComplaintCount / finalResponse.complaintCount) * 100);
            finalResponse.resolvedIncidentPercentage = parseInt((finalResponse.resolvedIncidentCount / finalResponse.incidentCount) * 100);
            callback(null, finalResponse);
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: { 
                    resolvedComplaintPercentage: data.resolvedComplaintPercentage,
                    resolvedIncidentPercentage: data.resolvedIncidentPercentage,
                    companyResolvedComplaintIncidentArray: data.companyResolvedComplaintIncidentArray
                },
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get response rate by super admin
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 23-Aug-2018
 */
function getResponseRateBySuperAdmin(req, res) {
    var finalResponse = {};
    finalResponse.todayDate = req.body.todayDate;
    finalResponse.overAll = false;
    finalResponse.momentObjFrom = '';
    finalResponse.momentObjTo = '';
    finalResponse.cmpRecord = [];
    finalResponse.cmpArray = [];
    finalResponse.ratingReceivedCount = 0; 
    finalResponse.checkOutSmsSentCount = 0;
    finalResponse.companyResponseRate = 0;
    finalResponse.companyResponseRateArray = [];
    waterfall([
        function (callback) { //start and end date 
            var start_day_date = '';
            var end_day_date = '';
            switch (req.body.selectPeriod) {
                case config.selectPeriod.LAST_THIRTY_DAYS:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(29, 'days');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.LAST_SIX_MONTH:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(6, 'months');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    console.log("start_day_date", start_day_date, end_day_date);
                    break;
                case config.selectPeriod.LAST_YEAR:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(1, 'years');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.OVER_ALL:
                    finalResponse.overAll = true;
                    break;
            }
            if(finalResponse.overAll == false){
                finalResponse.momentObjFrom = new Date(moment(start_day_date));
                finalResponse.momentObjTo = new Date(moment(end_day_date));
            }
            callback(null, finalResponse);
        },
        function (finalResponse, callback) { //Get companies under organization
            var condition = {};
            condition.isDelete = false;
            condition['userCmpInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.COMPANY_ADMIN.name;
            var aggregate = [{
                    $lookup: {
                        from: 'usercompanies',
                        localField: "_id",
                        foreignField: "companyId",
                        as: "userCmpInfo"
                    }
                },
                {
                    $unwind: "$userCmpInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userCmpInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "userId": "$userInfo._id",
                    "userCmpId": "$userCmpInfo._id",
                    "cmpName": "$cmpName"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Company.aggregate(aggregate).then(function (cmpData) {
                finalResponse.cmpArray = cmpData;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Get facilities under company
            async.eachSeries(finalResponse.cmpArray, function (cmpData, next) {
                var condition = {};
                condition.isDelete = false;
                condition.userCmpId = mongoose.Types.ObjectId(cmpData.userCmpId);
                condition['userFacInfo.isDelete'] = false;
                condition['userInfo.isDelete'] = false;
                condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;
                var aggregate = [{
                        $lookup: {
                            from: 'userfacilities',
                            localField: "_id",
                            foreignField: "facilityId",
                            as: "userFacInfo"
                        }
                    },
                    {
                        $unwind: "$userFacInfo"
                    },
                    {
                        $lookup: {
                            from: 'users',
                            localField: "userFacInfo.userId",
                            foreignField: "_id",
                            as: "userInfo"
                        }
                    },
                    {
                        $unwind: "$userInfo"
                    },
                    {
                        $match: condition
                    },
                ];
                var project = {
                    $project: {
                        "userId": "$userInfo._id",
                        "userFacId": "$userFacInfo._id",
                        "facName": "$facName"
                    }
                };
    
                aggregate.push(project);
                var countQuery = [].concat(aggregate);
                Facility.aggregate(aggregate).then(function (facData) {
                    var obj = {
                        userCmpId: cmpData.userCmpId,
                        cmpName: cmpData.cmpName,
                        cmpUserId: cmpData.userId,
                        facArray: facData
                    }
                    finalResponse.cmpRecord.push(obj)
                    next();
                }).catch(function (err) {
                    next();
                });
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })  
        },
        function (finalResponse, callback) { //Get response rate under organization
            async.eachSeries(finalResponse.cmpRecord, function (cmpData, nextCmp) {
                var cmpObj = {};
                cmpObj.ratingReceivedCount = 0;
                cmpObj.checkOutSmsSentCount = 0;  
                cmpObj.companyResponseRateArray = [];              
                async.eachSeries(cmpData.facArray, function (facilityData, next) {
                    var condition = {};
                    condition.isDelete = false,
                    condition.userFacilityId = mongoose.Types.ObjectId(facilityData.userFacId),
                    condition.checkOutSmsSent = true;
                    condition.ratingDone = true;
                    if(finalResponse.overAll == false){
                        condition.$and = [{
                            ratingDate: {
                                $gte: finalResponse.momentObjFrom
                            }
                        }, 
                        {
                            ratingDate: {
                                $lte: finalResponse.momentObjTo
                            }
                        },
                        {
                            checkOutSmsSentDate: {
                                $gte: finalResponse.momentObjFrom
                            }
                        }, 
                        {
                            checkOutSmsSentDate: {
                                $lte: finalResponse.momentObjTo
                            }
                        }];
                    }
                    CheckInOut.find(condition).count().exec(function (err, ratingReceivedCount) {
                        if (err) {
                            callback(err, false);
                        } else {
                            cmpObj.ratingReceivedCount = cmpObj.ratingReceivedCount + ratingReceivedCount;
                            finalResponse.ratingReceivedCount = finalResponse.ratingReceivedCount + ratingReceivedCount;
                            delete condition["ratingDone"];                        
                            if(finalResponse.overAll == false){
                                delete condition["$and"];
                                condition.$and = [{
                                    checkOutSmsSentDate: {
                                        $gte: finalResponse.momentObjFrom
                                    }
                                }, 
                                {
                                    checkOutSmsSentDate: {
                                        $lte: finalResponse.momentObjTo
                                    }
                                }];     
                            }
                            CheckInOut.find(condition).count().exec(function (err, checkOutSmsSentCount) {
                                if (err) {
                                    callback(err, false);
                                } else {
                                    cmpObj.checkOutSmsSentCount = cmpObj.checkOutSmsSentCount + checkOutSmsSentCount;
                                    finalResponse.checkOutSmsSentCount = finalResponse.checkOutSmsSentCount + checkOutSmsSentCount;
                                    var companyResponseRate = parseInt((ratingReceivedCount / checkOutSmsSentCount) * 100);
                                    var facInfo = {
                                        facName: facilityData.facName,
                                        companyResponseRate: companyResponseRate
                                    }
                                    cmpObj.companyResponseRateArray.push(facInfo);
                                    next();
                                }
                            });
                        }
                    });
                }, function (err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        cmpObj.cmpName = cmpData.cmpName;
                        cmpObj.companyResponseRate = parseInt((cmpObj.ratingReceivedCount / cmpObj.checkOutSmsSentCount) * 100);
                        finalResponse.companyResponseRateArray.push(cmpObj);
                        nextCmp();
                    }
                })   
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            }) 
        },
        function (finalResponse, callback) { //Get percentage of response rate under organization
            finalResponse.companyResponseRate = parseInt((finalResponse.ratingReceivedCount / finalResponse.checkOutSmsSentCount) * 100);
            callback(null, finalResponse);
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: {
                    companyResponseRate: data.companyResponseRate,
                    companyResponseRateArray: data.companyResponseRateArray
                },
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get rating by super admin
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 24-Aug-2018
 */
function ratingBySuperAdmin(req, res) {
    var finalResponse = {};
    finalResponse.overAll = false;
    finalResponse.todayDate = req.body.todayDate;
    finalResponse.companyRatingArray = [];
    finalResponse.momentObjFrom = '';
    finalResponse.momentObjTo = '';
    finalResponse.cmpRecord = [];
    finalResponse.cmpArray = [];
    finalResponse.positiveRatingCount = 0;
    finalResponse.negativeRatingCount = 0;
    waterfall([
        function (callback) { //start and end date 
            var start_day_date = '';
            var end_day_date = '';
            switch (req.body.selectPeriod) {
                case config.selectPeriod.LAST_THIRTY_DAYS:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(29, 'days');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.LAST_SIX_MONTH:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(6, 'months');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    console.log("start_day_date", start_day_date, end_day_date);
                    break;
                case config.selectPeriod.LAST_YEAR:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(1, 'years');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.OVER_ALL:
                    finalResponse.overAll = true;
                    break;
            }
            if(finalResponse.overAll == false){
                finalResponse.momentObjFrom = new Date(moment(start_day_date));
                finalResponse.momentObjTo = new Date(moment(end_day_date));
            }
            callback(null, finalResponse);
        },
        function (finalResponse, callback) { //Get companies under organization
            var condition = {};
            condition.isDelete = false;
            condition['userCmpInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.COMPANY_ADMIN.name;
            var aggregate = [{
                    $lookup: {
                        from: 'usercompanies',
                        localField: "_id",
                        foreignField: "companyId",
                        as: "userCmpInfo"
                    }
                },
                {
                    $unwind: "$userCmpInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userCmpInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "userId": "$userInfo._id",
                    "userCmpId": "$userCmpInfo._id",
                    "cmpName": "$cmpName"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Company.aggregate(aggregate).then(function (cmpData) {
                finalResponse.cmpArray = cmpData;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Get facilities under company
            async.eachSeries(finalResponse.cmpArray, function (cmpData, next) {
                var condition = {};
                condition.isDelete = false;
                condition.userCmpId = mongoose.Types.ObjectId(cmpData.userCmpId);
                condition['userFacInfo.isDelete'] = false;
                condition['userInfo.isDelete'] = false;
                condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;
                var aggregate = [{
                        $lookup: {
                            from: 'userfacilities',
                            localField: "_id",
                            foreignField: "facilityId",
                            as: "userFacInfo"
                        }
                    },
                    {
                        $unwind: "$userFacInfo"
                    },
                    {
                        $lookup: {
                            from: 'users',
                            localField: "userFacInfo.userId",
                            foreignField: "_id",
                            as: "userInfo"
                        }
                    },
                    {
                        $unwind: "$userInfo"
                    },
                    {
                        $match: condition
                    },
                ];
                var project = {
                    $project: {
                        "userId": "$userInfo._id",
                        "userFacId": "$userFacInfo._id",
                        "facName": "$facName"
                    }
                };
    
                aggregate.push(project);
                var countQuery = [].concat(aggregate);
                Facility.aggregate(aggregate).then(function (facData) {
                    var obj = {
                        userCmpId: cmpData.userCmpId,
                        cmpName: cmpData.cmpName,
                        cmpUserId: cmpData.userId,
                        facArray: facData
                    }
                    finalResponse.cmpRecord.push(obj)
                    next();
                }).catch(function (err) {
                    next();
                });
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })  
        },
        function (finalResponse, callback) { //Get positive/negative under organization
            async.eachSeries(finalResponse.cmpRecord, function (cmpData, nextCmp) {
                var cmpObj = {};
                cmpObj.positiveRatingCount = 0;
                cmpObj.negativeRatingCount = 0;  
                cmpObj.companyRatingArray = [];              
                async.eachSeries(cmpData.facArray, function (facilityData, next) {
                    var condition = {
                        isDelete: false,
                        status: '0',
                        ratingDone: true,
                        ratingStatus: 'positive',
                        userFacilityId: mongoose.Types.ObjectId(facilityData.userFacId)
                    };
                    if(finalResponse.overAll == false){
                        condition.$and = [{
                            ratingDate: {
                                $gte: finalResponse.momentObjFrom
                            }
                        },
                        {
                            ratingDate: {
                                $lte: finalResponse.momentObjTo
                            }
                        }];
                    } 
    
                    CheckInOut.find(condition).count().exec(function(err, positiveRatingCount){
                        if(err){
                            callback(err, false);
                        }else{
                            cmpObj.positiveRatingCount = cmpObj.positiveRatingCount + positiveRatingCount;
                            finalResponse.positiveRatingCount = finalResponse.positiveRatingCount + positiveRatingCount;
                            var linkInfo = {
                                facName: facilityData.facName,
                                positiveRatingCount: positiveRatingCount
                            }
                            condition.ratingStatus = 'negative';
                            CheckInOut.find(condition).count().exec(function(err, negativeRatingCount){
                                if(err){
                                    callback(err, false);
                                }else{
                                    cmpObj.negativeRatingCount = cmpObj.negativeRatingCount + negativeRatingCount;
                                    finalResponse.negativeRatingCount = finalResponse.negativeRatingCount + negativeRatingCount;
                                    linkInfo.negativeRatingCount = negativeRatingCount;
                                    cmpObj.companyRatingArray.push(linkInfo);
                                    next();
                                }
                            })
                        }
                    })
                }, function (err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        cmpObj.cmpName = cmpData.cmpName;
                        finalResponse.companyRatingArray.push(cmpObj);
                        nextCmp();
                    }
                })   
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            }) 
        }
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: { 
                    companyRatingArray: data.companyRatingArray,
                    negativeRatingCount: data.negativeRatingCount,
                    positiveRatingCount: data.positiveRatingCount
                },
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}

/**
 * Function is use to get link Tracking by super admin
 * @access private
 * @return json
 * Created by Sunny
 * @smartData Enterprises (I) Ltd
 * Created Date 23-Aug-2018
 */
function linkTrackingBySuperAdmin(req, res) {
    var finalResponse = {};
    finalResponse.overAll = false;
    finalResponse.todayDate = req.body.todayDate;
    finalResponse.overAllLinkTrackingArray = [];
    finalResponse.momentObjFrom = '';
    finalResponse.momentObjTo = '';
    finalResponse.cmpRecord = [];
    finalResponse.cmpArray = [];
    finalResponse.overAllLinkTrackingCount = 0;
    waterfall([
        function (callback) { //start and end date 
            var start_day_date = '';
            var end_day_date = '';
            switch (req.body.selectPeriod) {
                case config.selectPeriod.LAST_THIRTY_DAYS:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(29, 'days');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.LAST_SIX_MONTH:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(6, 'months');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    console.log("start_day_date", start_day_date, end_day_date);
                    break;
                case config.selectPeriod.LAST_YEAR:
                    start_day_date = moment(finalResponse.todayDate).startOf('day').subtract(1, 'years');
                    end_day_date = moment(finalResponse.todayDate).endOf('day');
                    break;
                case config.selectPeriod.OVER_ALL:
                    finalResponse.overAll = true;
                    break;
            }
            if(finalResponse.overAll == false){
                finalResponse.momentObjFrom = new Date(moment(start_day_date));
                finalResponse.momentObjTo = new Date(moment(end_day_date));
            }
            callback(null, finalResponse);
        },
        function (finalResponse, callback) { //Get companies under organization
            var condition = {};
            condition.isDelete = false;
            condition['userCmpInfo.isDelete'] = false;
            condition['userInfo.isDelete'] = false;
            condition['userInfo.role'] = config.role_type.COMPANY_ADMIN.name;
            var aggregate = [{
                    $lookup: {
                        from: 'usercompanies',
                        localField: "_id",
                        foreignField: "companyId",
                        as: "userCmpInfo"
                    }
                },
                {
                    $unwind: "$userCmpInfo"
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: "userCmpInfo.userId",
                        foreignField: "_id",
                        as: "userInfo"
                    }
                },
                {
                    $unwind: "$userInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "userId": "$userInfo._id",
                    "userCmpId": "$userCmpInfo._id",
                    "cmpName": "$cmpName"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            Company.aggregate(aggregate).then(function (cmpData) {
                finalResponse.cmpArray = cmpData;
                callback(null, finalResponse);
            }).catch(function (err) {
                callback(err, false);
            });
        },
        function (finalResponse, callback) { //Get facilities under company
            async.eachSeries(finalResponse.cmpArray, function (cmpData, next) {
                var condition = {};
                condition.isDelete = false;
                condition.userCmpId = mongoose.Types.ObjectId(cmpData.userCmpId);
                condition['userFacInfo.isDelete'] = false;
                condition['userInfo.isDelete'] = false;
                condition['userInfo.role'] = config.role_type.FACILITY_ADMIN.name;
                var aggregate = [{
                        $lookup: {
                            from: 'userfacilities',
                            localField: "_id",
                            foreignField: "facilityId",
                            as: "userFacInfo"
                        }
                    },
                    {
                        $unwind: "$userFacInfo"
                    },
                    {
                        $lookup: {
                            from: 'users',
                            localField: "userFacInfo.userId",
                            foreignField: "_id",
                            as: "userInfo"
                        }
                    },
                    {
                        $unwind: "$userInfo"
                    },
                    {
                        $match: condition
                    },
                ];
                var project = {
                    $project: {
                        "userId": "$userInfo._id",
                        "userFacId": "$userFacInfo._id",
                        "facName": "$facName"
                    }
                };
    
                aggregate.push(project);
                var countQuery = [].concat(aggregate);
                Facility.aggregate(aggregate).then(function (facData) {
                    var obj = {
                        userCmpId: cmpData.userCmpId,
                        cmpName: cmpData.cmpName,
                        cmpUserId: cmpData.userId,
                        facArray: facData
                    }
                    finalResponse.cmpRecord.push(obj)
                    next();
                }).catch(function (err) {
                    next();
                });
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            })  
        },
        function (finalResponse, callback) { //Get over all link tracking under organization
            async.eachSeries(finalResponse.cmpRecord, function (cmpData, nextCmp) {
                var cmpObj = {};
                cmpObj.overAllLinkTrackingCount = 0;
                cmpObj.overAllLinkTrackingArray = [];              
                async.eachSeries(cmpData.facArray, function (facilityData, next) {
                    var condition = {
                        isDelete: false,
                        status: '0',
                        ratingDone: true,
                        sentOnlineLinkInSms: true,
                        viewedLink: true,
                        userFacilityId: mongoose.Types.ObjectId(facilityData.userFacId)
                    }; 
    
                    if(finalResponse.overAll == false){
                        condition.$and = [{
                            viewedLinkDate: {
                                $gte: finalResponse.momentObjFrom
                            }
                        },
                        {
                            viewedLinkDate: {
                                $lte: finalResponse.momentObjTo
                            }
                        }];
                    } 
    
                    CheckInOut.find(condition).count().exec(function(err, linkTrackingCount){
                        if(err){
                            callback(err, false);
                        }else{
                            cmpObj.overAllLinkTrackingCount = cmpObj.overAllLinkTrackingCount + linkTrackingCount;
                            finalResponse.overAllLinkTrackingCount = finalResponse.overAllLinkTrackingCount + linkTrackingCount;
                            var linkInfo = {
                                facName: facilityData.facName,
                                linkTrackingCount: linkTrackingCount
                            }
                            cmpObj.overAllLinkTrackingArray.push(linkInfo);
                            next();
                        }
                    })
                }, function (err) {
                    if (err) {
                        callback(err, false);
                    } else {
                        cmpObj.cmpName = cmpData.cmpName,
                        finalResponse.overAllLinkTrackingArray.push(cmpObj);
                        nextCmp();
                    }
                }) 
            }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            }) 
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: config.statusCode.error,
                data: {},
                message: i18n.__("INTERNAL_ERROR")
            });
        } else {
            res.json({
                code: config.statusCode.success,
                data: { 
                    overAllLinkTrackingArray: data.overAllLinkTrackingArray, 
                    overAllLinkTrackingCount: data.overAllLinkTrackingCount
                },
                message: i18n.__("DATA_FOUND_SUCCESSFULLY")
            });
        }
    });
}