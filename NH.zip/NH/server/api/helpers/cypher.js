var crypto = require('../../config/keys.js');
var bcrypt = require('bcrypt-nodejs');
var Hashids = require("hashids"),
        _ = require("underscore"),
        hashids = new Hashids(crypto.saltKey);

exports.comparePassword = function(plainPassword, hashPassword, callback) {
    bcrypt.compare(plainPassword, hashPassword, function(err, res) {
        //__debug(hashPassword);
        //__debug(plainPassword);
        //__debug(res);
        if (err)
            callback(null,err);
        else
            callback(res);
    });
};

exports.cryptPassword = function(plainPassword, callback) {
    //var salt = bcrypt.genSaltSync(10);
    bcrypt.hash(plainPassword, crypto.saltKey, null, function(err, hash) {
        if (err) {
            throw err;
        }
        callback(hash);
    });
};


exports.encode = function(plain) {
    return  hashids.encode(parseInt(plain));
};

exports.decode = function(encoded) {
    var original = hashids.decode(encoded);
    if (typeof (original) === 'object') {
        return original[0];
    }
    return original;
};

exports.encryptIds = function(obj) { 
     var arg   = arguments;
     if(!obj || typeof(obj)!=='object'){
         return obj;
     }
     if(typeof obj.toJSON === 'function') { 
      obj = obj.toJSON();
    }    
    var field  = (typeof(arg[1])==='string') ? arg[1]:'id';    
    for (var i in obj) 
    {
        obj[i][field] = this.encode(obj[i][field]);
    }
    return obj;
};
exports.encryptId = function(obj, options) {
    if(typeof obj.toJSON === 'function') { 
     obj = obj.toJSON();
    }   
    obj['id'] = this.encode(obj['id']);
    return obj;
};
exports.encryptIdR = function(obj, options) {
    obj = obj.toJSON();
    obj['id'] = this.encode(obj['id']);
    obj['patient_id'] = this.encode(obj['patient_id']);
    return obj;
};

exports.formatDate = function(date) {
    var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

    if (month.length < 2)
        month = '0' + month;
    if (day.length < 2)
        day = '0' + day;

    return [year, month, day].join('-');
};
exports.parseConvert = function(number) {
    return parseFloat(Math.round(number * 100) / 100).toFixed(2);    
};

exports.uuid = {
    uuid:require('node-uuid'),
    v1: function() {      
      return this.uuid.apply(this,arguments);  //.v1()
   }    
};
