'use strict';

var mongoose = require('mongoose');

var notificationSmsHistorySchema = new mongoose.Schema({
    userFacId:          { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },
    to:                 { type: String }, //visitor or facility twilio phone no.
    from:               { type: String }, //visitor or facility twilio phone no.
    text:               { type: String }, 
    update_incident:    { type: String },          
    status:             { type: Boolean, default: true },
    isDelete:           { type: Boolean, default: false },
}, {
    timestamps: true
});

var notificationSmsHistory = mongoose.model('notificationSmsHistory', notificationSmsHistorySchema);
module.exports = notificationSmsHistory;
