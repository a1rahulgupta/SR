'use strict';

var mongoose = require('mongoose');

var facebookSRMetricsSchema = new mongoose.Schema({
	facebookTokenId:    {type: mongoose.Schema.Types.ObjectId, ref: 'facebookToken' }, //Reference from facebookToken table
    facebookPagesId :   {type: mongoose.Schema.Types.ObjectId, ref: 'facebookPages' }, //Reference from facebookPages table
	ACCOUNT:          	{type: String, default: '' },    
    ACCOUNT_NAME:     	{type: String, default: '' },
    ACCOUNT_NICK:     	{type: String, default: '' },
    ACCOUNT_OWNER:    	{type: String, default: '' },
    DATE:          	  	{type: String, default: '' },
    ISODATE: 		  	{type:Date},
    POSTS: 			  	{type:Number, default:0},
    STATUSES: 		  	{type:Number, default:0},
    LINKS: 			  	{type:Number, default:0},
    PHOTOS: 		  	{type:Number, default:0},
    VIDEOS: 		  	{type:Number, default:0},
    FRIENDS_POSTS: 	  	{type:Number, default:0},
    QUESTIONS: 			{type:Number, default:0},
    COUPONS: 			{type:Number, default:0},
    COMMENTS: 			{type:Number, default:0},
    LIKES: 				{type:Number, default:0},
    SHARES: 			{type:Number, default:0},
    REVIEWS: 			{type:Number, default:0},
    CONVERSATIONS: 		{type:Number, default:0},
    CLICKS: 			{type:Number, default:0},
    GENDER_MALE: 		{type:Number, default:0},
    GENDER_FEMALE: 		{type:Number, default:0},
    GENDER_UNKNOWN: 	{type:Number, default:0},
    AGE_LESS_THEN_13: 	{type:Number, default:0},
    AGE_13_TO_17: 		{type:Number, default:0},
    AGE_18_TO_24: 		{type:Number, default:0},
    AGE_25_TO_34: 		{type:Number, default:0},
    AGE_35_TO_44: 		{type:Number, default:0},
    AGE_45_TO_54: 		{type:Number, default:0},
    AGE_55_TO_64: 		{type:Number, default:0},
    AGE_65_PLUS: 		{type:Number, default:0},
    AGE_UNKNOWN: 		{type:Number, default:0},
    PAGE_VIEWS: 		{type:Number, default:0},
    PAGE_IMPRESSIONS: 	{type:Number, default:0},
    PAGE_IMPRESSIONS_ORGANIC: 	{type:Number, default:0},
    POSTS_IMPRESSIONS: 			{type:Number, default:0},
    POSTS_IMPRESSIONS_ORGANIC: 	{type:Number, default:0},
    POSTS_IMPRESSIONS_UNIQUE: 	{type:Number, default:0},
    STORYTELLERS: 		{type:Number, default:0},
    CHECKINS: 			{type:Number, default:0},
    PHOTO_VIEW: 		{type:Number, default:0},
    VIDEO_PLAY: 		{type:Number, default:0},
    ENGAGED_USERS: 		{type:Number, default:0},
    PAGE_LIKES: 		{type:Number, default:0},
    NEW_PAGE_LIKES: 	{type:Number, default:0},
    REMOVED_PAGE_LIKES:	{type:Number, default:0},
    TOTAL_REACH: 		{type:Number, default:0},
    UNLIKES: 			{type:Number, default:0},
    CONSUMPTIONS_UNIQUE: {type:Number, default:0},
    POSTS_TO_PAGE: 		{type:Number, default:0},
    ORGANIC_REACH: 		{type:Number, default:0},
    PAID_REACH: 		{type:Number, default:0},
    VIRAL_REACH: 		{type:Number, default:0}
}, {
    timestamps: true
});

module.exports = mongoose.model('facebookSRMetrics', facebookSRMetricsSchema);