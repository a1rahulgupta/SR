'use strict';

var mongoose = require('mongoose');

var smsHistorySchema = new mongoose.Schema({
    userFacilityId:     { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },
    visitorId:          { type: mongoose.Schema.Types.ObjectId, ref: 'visitors' }, //visitorId
    to:                 { type: String }, //visitor or facility twilio phone no.
    from:               { type: String }, //visitor or facility twilio phone no.
    text:               { type: String },   
    isReplied:          { type: Boolean }, 
    status:             { type: Boolean, default: true },
    isDelete:           { type: Boolean, default: false },
}, {
    timestamps: true
});

var smsHistory = mongoose.model('smsHistory', smsHistorySchema);
module.exports = smsHistory;
