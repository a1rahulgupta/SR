'use strict';

var mongoose = require('mongoose');

var patientComplaintSchema = new mongoose.Schema({
    userFacilityId: { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },
    category_id:    { type: mongoose.Schema.Types.ObjectId, ref: 'category' },
    firstName:      { type: String, default: '' },
    lastName:       { type: String, default: '' },
    email:          { type: String },
    phoneNumber:    { type: String, default: '' },
    complaint:      { type: String, default: '' },
    isDelete:       { type: Boolean, default: false }
}, {
        timestamps: true
    });    

var patientComplaint = mongoose.model('patientComplaint', patientComplaintSchema);
module.exports = patientComplaint;