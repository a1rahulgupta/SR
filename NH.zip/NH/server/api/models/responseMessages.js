'use strict';

var mongoose = require('mongoose');

var responseMessageSchema = new mongoose.Schema({
    message: {
        type: String
    },
    title: {
        type: String
    }
}, {
    timestamps: true
});

var responseMessage = mongoose.model('responseMessage', responseMessageSchema);
module.exports = responseMessage;