'use strict';

var mongoose = require('mongoose');

var trackingViewedLinkSchema = new mongoose.Schema({
    userFacId:          { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },
    visitorId:          { type: mongoose.Schema.Types.ObjectId, ref: 'visitors' },
    trackingLink:       { type: String },
    routingLink:        { type: String },
    status:             { type: Boolean, default: true },
    isDelete:           { type: Boolean, default: false }
}, {
    timestamps: true
});

var trackingViewedLink = mongoose.model('trackingViewedLink', trackingViewedLinkSchema);
module.exports = trackingViewedLink;
