'use strict';
var mongoose = require('mongoose');

var notificationSettingsSchema = new mongoose.Schema({
    openIncident:                   {
                                        status:              { type: Boolean, default: false },
                                        period:              { type: String, default: '' },
                                        emailsArray:         [{ }],
                                        phoneNumber:         { type: String, default: '' } 
                                    },
    updateResolvedIncident:         {
                                        status:              { type: Boolean, default: false },
                                        emailsArray:         [{ }],
                                        phoneNumber:         { type: String, default: '' }
                                    },                                    
    negative_rating_notification:   {
                                        status:              { type: Boolean, default: false },
                                        phoneNumber:         { type: String, default: '' }, 
                                        emailsArray:         [{ }]
                                    },
    checkInNotification:            {
                                        status:              { type: Boolean, default: false },
                                        phoneNumber:         { type: String, default: '' }, 
                                        emailsArray:         [{ }]
                                    },                                                                       
    status:                         {   type: Boolean, default: true },                    
    isDelete:                       {   type: Boolean, default: false }            
}, {
        timestamps: true
});

module.exports = mongoose.model('notificationSettings', notificationSettingsSchema);
