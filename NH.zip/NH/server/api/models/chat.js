'use strict';

var mongoose = require('mongoose');

var chatSchema = new mongoose.Schema({
    userFacId:      { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },
    sentBy:         { type: mongoose.Schema.Types.ObjectId, ref: 'users' },
    receivedBy:     { type: mongoose.Schema.Types.ObjectId, ref: 'users' },
    message:        { type: String },
    status:         { type: Boolean, default: true }, //true: sms sent, false: sms not sent
    isDelete:       { type: Boolean, default: false },
}, {
    timestamps: true
});

var Chat = mongoose.model('chat', chatSchema);
module.exports = Chat;
