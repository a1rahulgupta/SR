'use strict';

var mongoose = require('mongoose');

var facilityReviewPlatformSchema = new mongoose.Schema({
    platformName:        {type: String, required: true}, //It refers to the name of the review platform
    scrapeUrl:           {type: String}, //Platform Url 
    userFacId:           {
                            type: mongoose.Schema.Types.ObjectId,
                            ref: 'userFacility'
                         },
    userCmpId:           {
                            type: mongoose.Schema.Types.ObjectId,
                            ref: 'userCompany'
                         },
    overAllRating:       {type: Number, default: 0},                                          
    outOfRating:         {type: Number, default: 0},                                          
    totalReviews:        {type: Number, default: 0},                                          
    status:              {type: Boolean, default: true}, //true-Active, false-Deactive
    isDelete:            {type: Boolean, default: false} 
}, {
    timestamps: true
});

facilityReviewPlatformSchema.statics.existCheck = function (platformName, callback) {
    var where = {};
    where.platformName = platformName;
    where.isDelete = false;
    facilityReviewPlatform.findOne(where, function (err, facilityPlatfomrData) {
        if (err) {
            callback(err)
        } else {
            if (facilityPlatfomrData) {
                callback(null, false);
            } else {
                callback(null, true);
            }
        }
    });
};

var facilityReviewPlatform = mongoose.model('facilityReviewPlatform', facilityReviewPlatformSchema);
module.exports = facilityReviewPlatform;