'use strict';

var mongoose = require('mongoose');

var checkInOutSchema = new mongoose.Schema({
    userFacilityId:          { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },
    visitorId:               { type: mongoose.Schema.Types.ObjectId, ref: 'visitors' },
    checkInDate:             { type: Date },
    checkInSmsSent:          { type: Boolean, default: false },
    checkOutSmsSent:         { type: Boolean, default: false },
    checkOutSmsSentDate:     { type: Date },
    checkOutDate:            { type: Date },
    visitedTo:               { type: String },
    rating:                  { type: Number, default: 0},
    comments:                { type: String },
    duration:                { type: String },
    reviewToken:             { type: String },
    isDelete:                { type: Boolean, default: false },
    reviewDate:              { type: Date },
    smsStatus:               { type: Boolean, default: true },    
    status:                  { type: String, default: '1'}, //0-out, 1-In,    
    ratingStatus:            { type: String, enum: ['negative', 'positive', 'neutral'] }, //1-2 : negative, 3: neutral, 4-5: positive 
    ratingDone:              { type: Boolean, default: false },
    ratingDate:              { type: Date }, 
    CommentDone:             { type: Boolean, default: false },
    CommentDate:             { type: Date },
    trackingToken:           { type: String, default: '' },
    trackingLink:            { type: String, default: '' },
    viewedLink:              { type: Boolean, default: false },
    sentOnlineLinkInSms:     { type: Boolean, default: false },
    sentOnlineLinkInSmsDate: { type: Date },        
    viewedLinkDate:          { type: Date },    
    receivedSmsAfterCheckIn: { type: Boolean, default: false },
    reviewStatus:            { type: String } //0-Not submitted, 1-Submit review 
}, {
    timestamps: true
});

var checkInOut = mongoose.model('checkInOut', checkInOutSchema);
module.exports = checkInOut;
