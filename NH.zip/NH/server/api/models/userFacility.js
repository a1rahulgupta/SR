'use strict';

var mongoose = require('mongoose');

var userFacilitySchema = new mongoose.Schema({
    userId:         {type: mongoose.Schema.Types.ObjectId, ref: 'user'},    //It refers to the user
    facilityId:     {type: mongoose.Schema.Types.ObjectId, ref: 'facility'}, //It refers to the facility
    status:         {type: String, default: 0}, //0-InActive, 1-Active, 2- Deactive
    isDelete:       {type: Boolean, default: false}
}, {
    timestamps: true
});

var UserFacility = mongoose.model('userFacility', userFacilitySchema);
module.exports = UserFacility;
