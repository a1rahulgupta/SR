
'use strict';

var mongoose = require('mongoose');

var todaysCheckListSchema = new mongoose.Schema({
    userFacId:                      { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },
    checkNewNotifications:          { type: Boolean, default:false }, 
    revisitAndRespond:              { type: Boolean, default:false },
    reviewYesterdaysRatings:        { type: Boolean, default:false },
    thankPositiveRaters:            { type: Boolean, default:false },
    checkTheLatestReviews:          { type: Boolean, default:false },
    postToSocialMedia:              { type: Boolean, default:false },
    status:                         { type: Boolean, default:true },
    isDelete:                       { type: Boolean, default: false }
}, {
    timestamps: true
});    

var todaysCheckList = mongoose.model('todaysCheckList', todaysCheckListSchema);
module.exports = todaysCheckList;
