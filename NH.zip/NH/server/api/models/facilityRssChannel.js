'use strict';

var mongoose = require('mongoose');

var facilityRssChannelSchema = new mongoose.Schema({
    rssChannelId:       { type: mongoose.Schema.Types.ObjectId, ref: 'rssChannel' }, //It refers to the rss channel
    userFacId:          { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' }, //It refers to the facility
    lastAddedBy:        { type: String, enum: ['super_admin', 'company_admin', 'facility_admin', 'employee', 'company_user'] }, //Who latestly added this rssChannel to the facility 
    lastAddedById:      { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    lastRemovedBy:      { type: String, enum: ['super_admin', 'company_admin', 'facility_admin', 'employee', 'company_user'] }, //Who latestly removed this rssChannel to the facility
    lastRemovedById:    { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    status:             {type: Boolean, default: true}, 
    isDelete:           {type: Boolean, default: false} 
}, {
    timestamps: true
});

var FacilityRssChannel = mongoose.model('facilityRssChannel', facilityRssChannelSchema);
module.exports = FacilityRssChannel;