'use strict';

var mongoose = require('mongoose');

var facilitySavedRssFeedSchema = new mongoose.Schema({
    rssFeedId:         { type: mongoose.Schema.Types.ObjectId, ref: 'rssChannel' }, //It refers to the rss feed
    rssChannelId:      { type: mongoose.Schema.Types.ObjectId, ref: 'rssChannel' }, //It refers to the rss channel
    userFacId:         { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' }, //It refers to the facility
    savedBy:           { type: String, enum: ['super_admin', 'company_admin', 'facility_admin', 'employee', 'company_user'] }, //Who saved this rss feed to the facility 
    savedById:         { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    isDeletedBy:       { type: String, enum: ['super_admin', 'company_admin', 'facility_admin', 'employee', 'company_user'] }, //Who deleted this rss feed to the facility  
    isDeletedById:     { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    status:            { type: Boolean, default: true }, 
    isDelete:          { type: Boolean, default: false } 
}, {
    timestamps: true
});

var facilitySavedRssFeed = mongoose.model('facilitySavedRssFeed', facilitySavedRssFeedSchema);
module.exports = facilitySavedRssFeed;