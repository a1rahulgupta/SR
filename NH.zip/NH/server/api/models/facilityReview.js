'use strict';

var mongoose = require('mongoose');

var facilityReviewSchema = new mongoose.Schema({
    facRevPlatId:        {
                            type: mongoose.Schema.Types.ObjectId,
                            ref: 'facilityReviewPlatform' 
                         },
    reviewId:            {type: String, required: true}, //It refers to the review id
    platformName:        {type: String, required: true}, //It refers to the name of the review platform
    scrapeUrl:           {type: String}, //scrape Url 
    reviewUrl:           {type: String}, //review Url 
    userFacId:           {
                            type: mongoose.Schema.Types.ObjectId,
                            ref: 'userFacility'
                         },
    userCmpId:           {
                            type: mongoose.Schema.Types.ObjectId,
                            ref: 'userCompany'
                         },
    rating:              {type: Number, default: 0},                                          
    outOfRating:         {type: Number, default: 0},                                          
    review:              {type: String, default: ''},
    caringPlatSub:       {type: String},
    title:               {type: String},                                            
    expSeniorAdvisor:    {type: String},                                          
    author:              {type: String, default: ''},
    reviewDate:          {type: Date},                                           
    updateDate:          {type: Date},
    authorProfile:       {type: String}, 
    authorRelToFac:      {type: String},
    reviewer:            {type: Object}, //It refers to google review platform
    review_name:         {type: String}, //It refers to google review platform                                           
    status:              {type: Boolean, default: true}, //true-Active, false-Deactive
    isDelete:            {type: Boolean, default: false} 
}, {
    timestamps: true
});

var facilityReview = mongoose.model('facilityReview', facilityReviewSchema);
module.exports = facilityReview;