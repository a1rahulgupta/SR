'use strict';

var mongoose = require('mongoose');

var suggestionSchema = new mongoose.Schema({
    userFacId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'userFacility'
    },
    ratingStatus: {
        type: String,
        enum: ['negative', 'positive', 'neutral']
    },
    text: {
        type: String
    },
    name: {
        type: String
    },
    rating: {
        type: Number,
        default: 0
    },
    iDidThis: {
        type: Boolean,
        default: false
    },
    RemoveThis: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var suggestion = mongoose.model('suggestion', suggestionSchema);
module.exports = suggestion;