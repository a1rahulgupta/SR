'use strict';

var mongoose = require('mongoose');

var employeeReviewSchema = new mongoose.Schema({
    userFacilityId: { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },
    category_id:    { type: mongoose.Schema.Types.ObjectId, ref: 'category' },
    firstName:      { type: String, default: '' },
    lastName:       { type: String, default: '' },
    email:          { type: String },
    phoneNumber:    { type: String, default: '' },
    rating:         { type: Number, default: 0 },
    comments:       { type: String, default: '' },
    isDelete:       { type: Boolean, default: false }
}, {
    timestamps: true
});    

var employeeReview = mongoose.model('employeeReview', employeeReviewSchema);
module.exports = employeeReview;