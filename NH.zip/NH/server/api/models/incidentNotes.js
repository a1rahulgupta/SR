'use strict';

var mongoose = require('mongoose');

var incidentNotesSchema = new mongoose.Schema({
    userFacId:               { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },
    incidentId:              { type: mongoose.Schema.Types.ObjectId, ref: 'incidentReport' },
    userId:                  { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    message:                 { type: String },
    status:                  { type: Boolean, default: true },
    isDelete:       		 { type: Boolean, default: false }
}, {
    timestamps: true
});

var incidentNotes = mongoose.model('incidentNotes', incidentNotesSchema);
module.exports = incidentNotes;
