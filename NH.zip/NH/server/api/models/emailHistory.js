'use strict';

var mongoose = require('mongoose');

var emailHistorySchema = new mongoose.Schema({
    to:          	{type: String, default: ''}, 
    from:           {type: String, default: ''},
    subject:        {type: String, default: ''},
    html:           {type: String, default: ''},
    status:         {type: String, default: 0}, //0-send, 1-Failed    
}, {
    timestamps: true
});

module.exports = mongoose.model('emailHistory', emailHistorySchema);


