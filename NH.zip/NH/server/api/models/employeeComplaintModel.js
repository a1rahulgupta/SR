'use strict';

var mongoose = require('mongoose');

var employeeComplaintSchema = new mongoose.Schema({
    userFacilityId: { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },
    category_id:    { type: mongoose.Schema.Types.ObjectId, ref: 'category' },
    firstName:      { type: String, default: '' },
    lastName:       { type: String, default: '' },
    email:          { type: String },
    phoneNumber:    { type: String, default: '' },
    complaint:      { type: String, default: '' },
    isDelete:       { type: Boolean, default: false }
}, {
    timestamps: true
});    

var employeeComplaint = mongoose.model('employeeComplaint', employeeComplaintSchema);
module.exports = employeeComplaint;