'use strict';

var mongoose = require('mongoose');

var visitorsSchema = new mongoose.Schema({
    userFacilityId:     { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },
    firstName:          { type: String, default: '' },
    lastName:           { type: String, default: '' },
    visitorName:        { type: String },
    email:              { type: String },
    phoneNumber:        { type: String, default: '' },
    flag:               { type: String, default: 'clear' },
    visitedTo:          { type: String },
    isCheckInAlert:     { type: Boolean, default: true },
    isAppMessagePopUp:  {
                          type: Boolean,
                          default: false
                        },
    appMessage:         {
                          type: String,
                          default: ''
                        },
    isSms:              { type: Boolean, default: true },
    visitor_type:       {
                          type: String
                        },
    relation_type:      {
                          type: String
                        },
    vendor_type:        {
                          type: String
                        },
    company_name:       {
                          type: String
                        },
    room_no:            {
                          type: String
                        },
    bed_no:             {
                          type: String
                        },
    isDelete:           { type: Boolean, default: false },
    modifiedById:       { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    modifiedBy:         { type: String, enum: ['super_admin', 'company_admin', 'facility_admin', 'employee', 'company_user'] }, 
}, {
    timestamps: true
});

visitorsSchema.statics.existPhoneCheck = function (phoneNumber,userFacId, callback) {
    var where = {};
    where.phoneNumber = phoneNumber;
    where.userFacilityId = mongoose.Types.ObjectId(userFacId);
    where.isDelete = false;
    visitors.findOne(where, function (err, cmpData) {
        if (err) {
            console.log("err", err);
            callback(err, false)
        } else {
            if (cmpData) {
                callback(null, false);
            } else {
                callback(null, true);
            }
        }
    });
};  

visitorsSchema.statics.existEmailCheck = function(email,userFacilityId, id, callback) {
    var where = {};
     where.userFacilityId = userFacilityId;
    if (id) {
        where = {
            $or: [{ email: new RegExp('^' + email + '$', "i") }],
            isDelete: { $ne: true },
            _id: { $ne: id }
        };
    } else {
        where = { $or: [{ email: new RegExp('^' + email + '$', "i") }], isDelete: { $ne: true } };
    }
    visitors.findOne(where, function(err, userdata) {
        if (err) {
            callback(err, false)
        } else {
            if (userdata) {
                callback(null, false);
            } else {
                callback(null, true);
            }
        }
    });
};  

var visitors = mongoose.model('visitors', visitorsSchema);
module.exports = visitors;
