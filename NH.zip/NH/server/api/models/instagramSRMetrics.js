'use strict';

var mongoose = require('mongoose');

var instagramSRMetricsSchema = new mongoose.Schema({
	instagramTokenId:   {type: mongoose.Schema.Types.ObjectId, ref: 'instagramToken' }, //Reference from instagramToken table
	ACCOUNT:          	{type: String, default: '' },    
    ACCOUNT_NAME:     	{type: String, default: '' },
    ACCOUNT_NICK:     	{type: String, default: '' },
    ACCOUNT_OWNER:    	{type: String, default: '' },
    DATE:          	  	{type: String, default: '' },
    ISODATE: 		  	{type:Date},
    TOTAL_MEDIA: 		{type:Number, default:0},
    NEW_MEDIA: 		  	{type:Number, default:0},
    NEW_PHOTOS: 		{type:Number, default:0},
    NEW_VIDEOS: 	    {type:Number, default:0},
    COMMENTS: 		  	{type:Number, default:0},
    LIKES: 	  	        {type:Number, default:0},
    FOLLOWED_BY: 		{type:Number, default:0},
    NEW_FOLLOWED_BY: 	{type:Number, default:0},
    LOST_FOLLOWED_BY: 	{type:Number, default:0},
    FOLLOWS: 			{type:Number, default:0},
    NEW_FOLLOWS: 		{type:Number, default:0},
    LOST_FOLLOWS: 		{type:Number, default:0},
    GENDER_MALE: 		{type:Number, default:0},
    GENDER_FEMALE: 		{type:Number, default:0},
    GENDER_UNKNOWN: 	{type:Number, default:0}
}, {
    timestamps: true
});
module.exports = mongoose.model('instagramSRMetrics', instagramSRMetricsSchema);