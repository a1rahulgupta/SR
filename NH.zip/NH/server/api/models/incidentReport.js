'use strict';

var mongoose = require('mongoose');

var incidentReportSchema = new mongoose.Schema({
    userFacId:                        { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },
    visitorId:                        { type: mongoose.Schema.Types.ObjectId, ref: 'visitors' },
    employeeId:                       { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    checkInlogId:                     { type: mongoose.Schema.Types.ObjectId, ref: 'checkInOut' },
    assignStatus:                     { type: Boolean ,default: false },
    incidentType:                     { type: String, enum: ['complaint', 'incident'], required: true }, 
    firstName:                        { type: String },
    lastName:                         { type: String },
    concern:                          { type: String },
    incidentTime:                     { type: Date },
    visitedTo:                        { type: String },
    department:                       { type: String },
    resolved:                         { type: Boolean , default: false }, // true- resolved false-unresolved
    resolvedDate:                     { type: Date }, 
    subject:                          { type: String },
    notes:                            { type: String },
    resolutionNotes:                  { type: String },
    isDelete:       		          { type: Boolean, default: false },
    empAccept:                        { type: String ,default: '' }, //1 -accept 0- reject
    verifyIncidentAcceptRejectToken:  { type: String ,default: '' },
    status:                           { type: Boolean, default: true },
    openIncident:                     {
                                        status:              { type: Boolean, default: false },
                                        period:              { type: String, default: '' },
                                        emailsArray:         [{  }],
                                        phoneNumber:         { type: String, default: '' } 
                                      },
    updateResolvedIncident:           {
                                        status:              { type: Boolean, default: false },
                                        emailsArray:         [{  }],
                                        phoneNumber:         { type: String, default: '' }
                                      }, 
}, {
    timestamps: true
});

var incidentReport = mongoose.model('incidentReport', incidentReportSchema);
module.exports = incidentReport;
