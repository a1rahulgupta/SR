'use strict';

var mongoose = require('mongoose');

var rssFeedSchema = new mongoose.Schema({
    rssChannelId:      { type: mongoose.Schema.Types.ObjectId, ref: 'rssChannel' }, //It refers to the rss channel
    guid:              { type: String }, //It refers to the unique identifier for the article
    link:              { type: String }, //Source Url of the article content
    title:             { type: String }, //It refers to the title of the article
    summary:           { type: String }, //An excerpt of the article content
    description:       { type: String }, //Description of the article content
    imageUrl:          { type: String }, //Image Url of the article content 
    pubDate:           { type: Date, default: Date.now }, //Original published date of the article content 
    date:              { type: Date, default: Date.now }, //Most recent update date of the article content 
    author:            { type: String }, //Author of the article content
    status:            { type: String, default: 0 }, //0-Active, 1-Deactive
    isDelete:          { type: Boolean, default: false } 
}, {
    timestamps: true
});

var RssFeed = mongoose.model('rssFeed', rssFeedSchema);
module.exports = RssFeed;