'use strict';

var mongoose = require('mongoose');

var rssChannelSchema = new mongoose.Schema({
    channelName:         {type: String, required: true}, //It refers to the name of the channel
    channelTitle:        {type: String, required: true}, //It refers to the title of the channel
    feedUrl:             {type: String}, //feed Url of the channel 
    status:              {type: String, default: 0}, //0-Active, 1-Deactive
    isDelete:            {type: Boolean, default: false} 
}, {
    timestamps: true
});

rssChannelSchema.statics.existCheck = function (channelTitle, channelName, callback) {
    var where = {};
    where.channelTitle = channelTitle;
    where.channelName = channelName;
    where.isDelete = false;
    rssChannel.findOne(where, function (err, channelData) {
        if (err) {
            callback(err)
        } else {
            if (channelData) {
                callback(null, false);
            } else {
                callback(null, true);
            }
        }
    });
};

var rssChannel = mongoose.model('rssChannel', rssChannelSchema);
module.exports = rssChannel;