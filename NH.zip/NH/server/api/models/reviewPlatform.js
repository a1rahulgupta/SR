'use strict';

var mongoose = require('mongoose');

var reviewPlatformSchema = new mongoose.Schema({
    platformName:        {type: String, required: true}, //It refers to the name of the review platform
    platformUrl:         {type: String}, //Platform Url 
    status:              {type: Boolean, default: true}, //true-Active, false-Deactive
    isDelete:            {type: Boolean, default: false} 
}, {
    timestamps: true
});

reviewPlatformSchema.statics.existCheck = function (platformName, callback) {
    var where = {};
    where.platformName = platformName;
    where.isDelete = false;
    reviewPlatform.findOne(where, function (err, platfomrData) {
        if (err) {
            callback(err)
        } else {
            if (platfomrData) {
                callback(null, false);
            } else {
                callback(null, true);
            }
        }
    });
};

var reviewPlatform = mongoose.model('reviewPlatform', reviewPlatformSchema);
module.exports = reviewPlatform;