'use strict';

var mongoose = require('mongoose');

var companySchema = new mongoose.Schema({
    cmpName: {type: String, default: ''},
    cmpLogo: {type: String, default: 'noLogoAvailable.png'},
    address: {type: String },
    city: { type: String },
    state: { type: String },
    stateCode: {type: String},
    country: { type: String },
    zipCode: { type: String },
    expiryDate: { type: Date },
    status:  { type: String, default: 0 }, //0-InActive, 1-Active, 2- Deactive
    isDelete: {type: Boolean, default: false},
}, {
    timestamps: true
});

companySchema.statics.existCheck = function (cmpName, callback) {
    var where = {};
    where.cmpName = cmpName;
    where.isDelete = false;
    Company.findOne(where, function (err, cmpData) {
        if (err) {
            callback(err)
        } else {
            if (cmpData) {
                callback(null, false);
            } else {
                callback(null, true);
            }
        }
    });
};

var Company = mongoose.model('company', companySchema);
module.exports = Company;
