'use strict';

var mongoose = require('mongoose');
var SettingSchema = mongoose.Schema({
    accountSid: {
        type: String
    },
    authToken: {
        type: String
    },
    application_sid:{
        type: String
    },
    account_title:{
        type: String
    },
    is_deleted: {
        type: Boolean,
        default:false
    },
    status: {
        type: Boolean,
        default:true
    }
}, {
    timestamps: true
});

mongoose.model('setting', SettingSchema);