'use strict';
var mongoose = require('mongoose');

var ratingResponseSettingsSchema = new mongoose.Schema({
    positive:                          {
                                            from:         { type: Number, default: 5 },
                                            to:           { type: Number, default: 4 },
                                            autoResponse: { type: String, default: "Thank you very much! We would appreciate if you can take a min and leave us a review online aswell." },
                                            sendAlerts:   { type: Boolean, default: true },
                                            addReviewLink:{ type: Boolean, default: true },
                                            googleLink:   { type: String },                                            
                                       },
    negative:                          {
                                            from:         { type: Number, default: 3 },
                                            to:           { type: Number, default: 1 },
                                            autoResponse: { type: String, default: "We are sorry if your experience wasn't the best. In a few words, please reply with details of your  experience." },
                                            sendAlerts:   { type: Boolean, default: true },
                                       },
    negativeRatingFollowUpSms:         {
                                            status:              { type: Boolean, default: true },
                                            visitorName:         { type: Boolean, default: false },
                                            message:             { type: String, default: 'Thank you for your response. We will contact you as soon as possible to discuss your concerns.' },
                                       },                      
    status:                            {    type: Boolean, default: true },                                         
    isDelete:                          {    type: Boolean, default: false }             
}, {
        timestamps: true
});

module.exports = mongoose.model('ratingResponseSettings', ratingResponseSettingsSchema);
