'use strict';

var mongoose = require('mongoose');

var broadcastMessageSchema = new mongoose.Schema({
    userFacId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'userFacility'
    },
    message: {
        type: String
    },
    isDelete: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var broadcastMessage = mongoose.model('broadcastMessage', broadcastMessageSchema);
module.exports = broadcastMessage;