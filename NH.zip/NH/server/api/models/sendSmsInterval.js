'use strict';

var mongoose = require('mongoose');

var sendSmsIntervalSchema = new mongoose.Schema({
    userFacId:               { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },
    visitorId:               { type: mongoose.Schema.Types.ObjectId, ref: 'visitors' },
    checkInOutId:            { type: mongoose.Schema.Types.ObjectId, ref: 'checkInOut' },    
    sendingTime:             { type: Date },
    message:                 { type: String },
    smsType:                 { type: String },
    to:                      { type: String },
    from:                    { type: String },   
    trackingLink:            { type: String },
    routingLink:             { type: String },
    checkOutSmsSent:         { type: Boolean, default: false },
    status:                  { type: Boolean, default: false }, 
    addReviewLink:           { type: Boolean },         
    isDelete:                { type: Boolean, default: false },
}, {
    timestamps: true
});

var sendSmsInterval = mongoose.model('sendSmsInterval', sendSmsIntervalSchema);
module.exports = sendSmsInterval;
