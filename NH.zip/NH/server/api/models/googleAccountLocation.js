'use strict';

var mongoose = require('mongoose');
var GoogleAccountLocationSchema = mongoose.Schema({
    googleCredentialId:  { type: mongoose.Schema.Types.ObjectId, ref: 'googleCredential' },
    locationName: {
        type: String,
        required: true
    },
    location_name: {
        type: String,
        required: true
    },
    websiteUrl: {
        type: String
    },
    regularHours: {
        type: Object
    },
    serviceArea: {
        type: Object
    },
    locationKey: {
        type: Object
    },
    latlng: {
        type: Object
    },
    openInfo: {
        type: Object
    },
    locationState: {
        type: Object
    },
    metadata: {
        type: Object
    },
    languageCode: {
        type: String
    },
    address: {
        type: Object
    },
    isActivate: {
        type: Boolean,
        default: false
    },
    is_deleted: {
        type: Boolean,
        default:false
    },
    status: {
        type: Boolean,
        default:true
    }
}, {
    timestamps: true
});

mongoose.model('googleAccountLocation', GoogleAccountLocationSchema);