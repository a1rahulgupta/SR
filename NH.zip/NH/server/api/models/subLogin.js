'use strict';

var mongoose = require('mongoose');

var subLoginSchema = new mongoose.Schema({
    name: { type: String },
    loginId: { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    date: { type: Date },
    isDelete: { type: Boolean, default: false },
}, {
        timestamps: true
    });

module.exports = mongoose.model('subLogin', subLoginSchema);
