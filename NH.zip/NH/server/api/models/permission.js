'use strict';

var mongoose = require('mongoose');

var permissionSchema = new mongoose.Schema({
    userId:             {type: mongoose.Schema.Types.ObjectId, ref: 'user'},
    facId:              {type: mongoose.Schema.Types.ObjectId, ref: 'facility' },    
    userFacId:          {type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },    
    visitors:           {
                            status:                     {type: Boolean, default: false},
                            edit:                       {type: Boolean, default: false},
                            visitorsList:               {type: Boolean, default: false},
                            checkInLogList:             {type: Boolean, default: false},
                            latestNegativeResponseList: {type: Boolean, default: false},
                            isCheckInAlert:             {type: Boolean, default: false},
                            isAppMessagePopUp:          {type: Boolean, default: false},
                            isSms:                      {type: Boolean, default: false},
                            twilioChat:                 {type: Boolean, default: false},
                            documentIncident:           {type: Boolean, default: false},  
                            stickyNote:                 {type: Boolean, default: false}
                        },                        
    newsFeed:           {   
                            status:             {type: Boolean, default: false},                       
                            save:               {type: Boolean, default: false},
                            list:               {type: Boolean, default: false },
                            remove:             {type: Boolean, default: false}
                        },
    kiosk: 			    {   
                            status:             {type: Boolean, default: false}, 						
    						visitorKiosk:       {type: Boolean, default: false},
    						patientKiosk:       {type: Boolean, default: false},
    					},
    employee: 			{ 
                            status:             {type: Boolean, default: false},   						
                            add:                {type: Boolean, default: false},
                            list:               {type: Boolean, default: false },
    						edit:  	            {type: Boolean, default: false},
    						delete:             {type: Boolean, default: false},
                            activateDeactivate: {type: Boolean, default: false},
                            managePermission:   {type: Boolean, default: false}, 
                        },
    dashboard:          {   
                            status:                 {type: Boolean, default: false},
                            dashboardStatus:        {type: Boolean, default: false},
                            totalVisitorsCount:     {type: Boolean, default: false},
                            positiveRatingsCount:   {type: Boolean, default: false},
                            negativeRatingsCount:   {type: Boolean, default: false},
                            smsMessageCount:        {type: Boolean, default: false},
                            clickTrackerSection:    {type: Boolean, default: false},
                            todayChackList:         {type: Boolean, default: false},
                            latestNegativeResponse: {type: Boolean, default: false},
                            latestPositiveRatings:  {type: Boolean, default: false},
                            latestNegativeRatings:  {type: Boolean, default: false},
                            visitorTrendsGraph:     {type: Boolean, default: false},
                            visitorRatingGraph:     {type: Boolean, default: false},
                            message:                {type: Boolean, default: false},
                            responseRate:           {type: Boolean, default: false},
                            linkTracking:           {type: Boolean, default: false},
                            latestVisitorsList:     {type: Boolean, default: false},
                            overallRatingGraph:     {type: Boolean, default: false},
                        },
    incidentClaimReports: {
                            
                            status:                       {type: Boolean, default: false},
                            allReports:                   {type: Boolean, default: false},
                            myReports:                    {type: Boolean, default: false},
                        },  
    googleLink:             {
                            status:                      {type: Boolean, default: false},
                            viewGoogleLink:              {type: Boolean, default: false},
                        },    
    settings:            {
                            status:                      {type: Boolean, default: false},
                            serviceStatus:               {type: Boolean, default: false},
                            appSettings:                 {type: Boolean, default: false},
                            smsSettings:                 {type: Boolean, default: false},
                            ratingAndResponseSettings:   {type: Boolean, default: false},
    
                         },                                           
    status:             { type: Boolean, default: true},
    isDelete:           { type: Boolean, default: false}                      
}, {
    timestamps: true
});

module.exports = mongoose.model('permission', permissionSchema);
