'use strict';

var mongoose = require('mongoose');

var userCompanySchema = new mongoose.Schema({
    userId:         {type: mongoose.Schema.Types.ObjectId, ref: 'user'},    //It refers to the user
    companyId:      {type: mongoose.Schema.Types.ObjectId, ref: 'company'}, //It refers to the company
    status:         {type: String, default: 0 }, //0-InActive, 1-Active, 2- Deactive
    isDelete:       {type: Boolean, default: false}
}, {
    timestamps: true
});

var UserCompany = mongoose.model('userCompany', userCompanySchema);
module.exports = UserCompany;