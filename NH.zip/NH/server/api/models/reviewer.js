'use strict';

var mongoose = require('mongoose');

var reviewerSchema = new mongoose.Schema({
    reviewername:    { type: String, lowercase: true },
    firstName:       { type: String, default: '' },
    lastName:        { type: String, default: '' },
    email:           { type: String, lowercase: true }, 
    phoneNumber:     { type: String, required: true }, //unique: true
    image:           { type: String, default: 'noImageAvailable.png' },
    reviewerType:    { type: String, enum: ['visitor', 'patient', 'employee'] },
    status:          { type: String, default: 0 }, //0-Active, 1-Deactive
    isDelete:        { type: Boolean, default: false }
}, {
    timestamps: true
});

reviewerSchema.statics.existCheck = function(email, id, callback) {
    var where = {};
    if (id) {
        where = {
            $or: [{ email: new RegExp('^' + email + '$', "i") }],
            isDelete: { $ne: true },
            _id: { $ne: id }
        };  
    } else {
        where = { $or: [{ email: new RegExp('^' + email + '$', "i") }], isDelete: { $ne: true } };
    }
    Reviewer.findOne(where, function(err, reviewerdata) {
        if (err) {
            callback(err)
        } else {
            if (reviewerdata) {
                callback(null, false);
            } else {
                callback(null, true);
            }
        }
    });
};

var Reviewer = mongoose.model('reviewer', reviewerSchema);
module.exports = Reviewer;
