'use strict';
var mongoose = require('mongoose');

var facilityAppSettingsSchema = new mongoose.Schema({
    userId:                            { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    userFacId:                         { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },
    facId:                             { type: mongoose.Schema.Types.ObjectId, ref: 'facility' },    
    checkInSms:                        {
                                            status:              { type: Boolean, default: false },
                                            visitorName:         { type: Boolean, default: false },
                                            message:             { type: String, default: '' },
                                       },
    checkInMessageReceivedReplySms:    {
                                            status:              { type: Boolean, default: true },
                                            visitorName:         { type: Boolean, default: false },
                                            message:             { type: String, default: 'We got your message! Someone will get back to you as soon as possible!' },
                                       },  
    checkOutSms:                       {
                                            status:              { type: Boolean, default: false },    
                                            visitorName:         { type: Boolean, default: false },
                                            message:             { type: String, default: '' },
                                       },   
    welcomeMessage:                    {
                                            status:              { type: Boolean, default: false },
                                            greeting:            { type: String, default: '' },
                                            message:             { type: String, default: '' },
                                       },
    goodbyeMessage:                    {
                                            status:              { type: Boolean, default: false },
                                            greeting:             { type: String, default: '' },
                                            message:             { type: String, default: '' },
                                       },
    footerMessage:                     {
                                            status:              { type: Boolean, default: false },
                                            message:             { type: String, default: '' },
                                       },                     
    checkInSmsInterval:                {
                                            status:              { type: Boolean, default: false },
                                            minutes:             { type: String, default: '5' },
                                            period:              { type: String, default: 'minutes' },
                                       },                        
    checkOutSmsInterval:               {
                                            status:              { type: Boolean, default: false },
                                            time:                { type: String, default: '5' },
                                            period:              { type: String, default: 'minutes' },
                                       },
    googleRatingSmsInterval:           {
                                            status:              { type: Boolean, default: false },
                                            time:                { type: String, default: '5' },
                                            period:              { type: String, default: 'minutes' },
                                       },                                                                
    smsLimits:                         {
                                            status:              { type: Boolean, default: false },
                                            globalLimit:         { type: String, default: '0' }, 
                                            dailyLimit:          { type: String, default: '0' },
                                            weeklyLimit:         { type: String, default: '0' },
                                            monthlyLimit:        { type: String, default: '0' },
                                       },   
    expressResident:                   {   type: Boolean, default: false },                                                                                                
    status:                            {   type: Boolean, default: true },                    
    isDelete:                          {   type: Boolean, default: false }            
}, {
        timestamps: true
});

module.exports = mongoose.model('facilityAppSettings', facilityAppSettingsSchema);
