'use strict';

var mongoose = require('mongoose');
var GoogleCredentialSchema = mongoose.Schema({
    client_id: {
        type: String
    },
    client_secret: {
        type: String
    },
    account_title:{
        type: String
    },
    code: {
        type: String
    },
    access_token: {
        type: String
    },
    refresh_token: {
        type: String
    },
    expiry_date: {
        type: Date
    },
    account_name: {
        type: String
    },
    accountName: {
        type: String
    },
    totalSize:{
        type: Number
    },
    isActivate: {
        type: Boolean,
        default:false
    },
    is_deleted: {
        type: Boolean,
        default:false
    },
    status: {
        type: Boolean,
        default:true
    }
}, {
    timestamps: true
});

mongoose.model('googleCredential', GoogleCredentialSchema);