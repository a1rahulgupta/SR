'use strict';
var mongoose = require('mongoose');

var facilitySmsSettingsSchema = new mongoose.Schema({
    userId:             { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    userFacId:          { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },
    facId:              { type: mongoose.Schema.Types.ObjectId, ref: 'facility' }, 
    sunday:              {
                                status:       { type: Boolean, default: false },
                                message:      { type: String, default: '' },
                         },
    monday:              {
                                status:       { type: Boolean, default: false },
                                message:      { type: String, default: '' },
                         },
    tuesday:             {
                                status:       { type: Boolean, default: false },
                                message:      { type: String, default: '' },
                         },
    wednesday:           {
                                status:       { type: Boolean, default: false },
                                message:      { type: String, default: '' },
                         },
    thursday:            {
                                status:       { type: Boolean, default: false },
                                message:      { type: String, default: '' },
                         },
    friday:              {
                                status:       { type: Boolean, default: false },
                                message:      { type: String, default: '' },
                         },
    saturday:            {
                                status:       { type: Boolean, default: false },
                                message:      { type: String, default: '' },
                         },
    disableAutoReply:    {      type: Boolean, default: false },
    status:              {      type: Boolean, default: true },                                         
    isDelete:            {      type: Boolean, default: false }            
}, {
        timestamps: true
});

module.exports = mongoose.model('facilitySmsSettings', facilitySmsSettingsSchema);
