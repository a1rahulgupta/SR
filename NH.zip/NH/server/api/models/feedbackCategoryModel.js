
'use strict';

var mongoose = require('mongoose');

var feedbackCategorySchema = new mongoose.Schema({
    category_name:  { type: String, default: '' },
    status:         { type: Boolean, default:false},
    isDelete:       { type: Boolean, default: false }
}, {
        timestamps: true
    });    

var feedbackCategory = mongoose.model('feedbackCategory', feedbackCategorySchema);
module.exports = feedbackCategory;
