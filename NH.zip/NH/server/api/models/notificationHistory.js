'use strict';

var mongoose = require('mongoose');

var notificationHistorySchema = new mongoose.Schema({
    userFacId:          { type: mongoose.Schema.Types.ObjectId, ref: 'userFacility' },
    visitorId:          { type: mongoose.Schema.Types.ObjectId, ref: 'visitors' }, //visitorId
    notificationType:   { type: String, enum: ['checkIn','incident'] },
    title:              { type: String ,default :''},
    isView:             { type: Boolean ,default: false },
    isDelete:           { type: Boolean, default: false },
}, {
        timestamps: true
    });

var notificationHistory = mongoose.model('notificationHistory', notificationHistorySchema);
module.exports = notificationHistory;
