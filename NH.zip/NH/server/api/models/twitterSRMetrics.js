'use strict';

var mongoose = require('mongoose');

var twitterSRMetricsSchema = new mongoose.Schema({
	twitterTokenId:     {type: mongoose.Schema.Types.ObjectId, ref: 'twitterToken' }, //Reference from twitterToken table
	ACCOUNT:          	{type: String, default: '' },    
    ACCOUNT_NAME:     	{type: String, default: '' },
    ACCOUNT_NICK:     	{type: String, default: '' },
    ACCOUNT_OWNER:    	{type: String, default: '' },
    DATE:          	  	{type: String, default: '' },
    ISODATE: 		  	{type:Date},
    STATUSES: 			{type:Number, default:0},
    QUOTES: 		  	{type:Number, default:0},
    MENTIONS: 			{type:Number, default:0},
    DIRECT_MESSAGES: 	{type:Number, default:0},
    RT_OF_ME: 		  	{type:Number, default:0},
    RT_BY_ME: 	  	    {type:Number, default:0},
    REPLIES: 			{type:Number, default:0},
    FAVORITES: 			{type:Number, default:0},
    NEW_LISTS: 			{type:Number, default:0},
    REACH: 				{type:Number, default:0},
    CLICKS: 			{type:Number, default:0},
    LINKS: 			    {type:Number, default:0},
    REFERENCES: 		{type:Number, default:0},
    FOLLOWERS: 			{type:Number, default:0},
    NEW_FOLLOWERS: 		{type:Number, default:0},
    LOST_FOLLOWERS: 	{type:Number, default:0},
    FOLLOWINGS: 	    {type:Number, default:0},
    NEW_FOLLOWINGS: 	{type:Number, default:0},
    LOST_FOLLOWINGS: 	{type:Number, default:0},
    GENDER_MALE: 		{type:Number, default:0},
    GENDER_FEMALE: 		{type:Number, default:0},
    GENDER_UNKNOWN: 	{type:Number, default:0}
}, {
    timestamps: true
});

module.exports = mongoose.model('twitterSRMetrics', twitterSRMetricsSchema);