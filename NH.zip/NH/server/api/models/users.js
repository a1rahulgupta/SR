'use strict';

var mongoose = require('mongoose');

var userSchema = new mongoose.Schema({
    userName:        { type: String, lowercase: true },
    password:        { type: String, default: '' },
    firstName:       { type: String, default: '' },
    lastName:        { type: String, default: '' },
    email:           { type: String, lowercase: true, required: true }, //unique: true,
    phoneNumber:     { type: String, default: '' },
    image:           { type: String, default: 'noImageAvailable.png' },

    role:            { type: String, enum: ['super_admin', 'company_admin', 'facility_admin', 'employee', 'company_user'], required: true }, //role for every user
    lastLoginDate:   { type: Date },
    
    createdBy:       { type: String, enum: ['super_admin', 'company_admin', 'facility_admin', 'employee', 'company_user'] },
    createdById:     { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    modifiedBy:      { type: String, enum: ['super_admin', 'company_admin', 'facility_admin', 'employee', 'company_user'] },
    modifiedById:    { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    isDeletedBy:     { type: String, enum: ['super_admin', 'company_admin', 'facility_admin', 'employee', 'company_user'] },
    isDeletedById:   { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    isActivatedBy:   { type: String, enum: ['super_admin', 'company_admin', 'facility_admin', 'employee', 'company_user'] },
    isActivatedId:   { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    isDeactivatedBy: { type: String, enum: ['super_admin', 'company_admin', 'facility_admin', 'employee', 'company_user'] },
    isDeactivatedId: { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    forgotPwdToken:  { type: String, default: '' },
    verifyToken:     { type: String, default: '' },
    reset_key:       { type: String, default: '' },
    token:           { type: String, default: '' },    
    status:          { type: String, default: 0 }, //0-InActive, 1-Active, 2- Deactive
    isDelete:        { type: Boolean, default: false }
}, {
    timestamps: true
});

userSchema.statics.existCheck = function(email, id, callback) {
    var where = {};
    if (id) {
        where = {
            $and: [{ email: new RegExp('^' + email + '$', "i") }],
            isDelete: { $ne: true },
            _id: { $ne: id }
        };
    } else {
        where = { $and: [{ email: new RegExp('^' + email + '$', "i") }], isDelete: { $ne: true } };
    }
    User.findOne(where, function(err, userdata) {
        if (err) {
            callback(err)
        } else {
            if (userdata) {
                callback(null, false);
            } else {
                callback(null, true);
            }
        }
    });
};

var User = mongoose.model('user', userSchema);
module.exports = User;
