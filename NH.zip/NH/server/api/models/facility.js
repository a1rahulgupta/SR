'use strict';

var mongoose = require('mongoose');

var facilitySchema = new mongoose.Schema({
    facName: { type: String, default: '' },
    facLogo: { type: String, default: 'noLogoAvailable.png' },
    userCmpId: { type: mongoose.Schema.Types.ObjectId, ref: 'company' },
    address: { type: String },
    city: { type: String },
    state: { type: String },
    stateCode: {type: String},
    country: { type: String },
    zipCode: { type: String },
    googleLink: { type: String },
    twilioTollFreeNumber: { type: String },
    status: { type: String, default: 0 }, //0-InActive, 1-Active, 2- Deactive
    isDelete: { type: Boolean, default: false }
}, {
    timestamps: true
});

facilitySchema.statics.existCheck = function (facName, callback) {
    var where = {};
    where.facName = facName;
    where.isDelete = false;
    Facility.findOne(where, function (err, facData) {
        if (err) {
            callback(err)
        } else {
            if (facData) {
                callback(null, false);
            } else {
                callback(null, true);
            }
        }
    });
};

var Facility = mongoose.model('facility', facilitySchema);
module.exports = Facility;
