'use strict';

var mongoose = require('mongoose');

var notesSchema = new mongoose.Schema({
    userFacId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'userFacility'
    },
    notes: {
        type: String
    },
    isDelete: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

var notesMessage = mongoose.model('notesMessage', notesSchema);
module.exports = notesMessage;