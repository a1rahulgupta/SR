import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";
import { CmpDashboardComponent } from "./components/cmp_dashboard.component";
import { CmpProfileComponent } from "./components/cmp_profile.component";
import { CmpUpdatePasswordComponent } from "./components/cmp_updatepassword.component";
import { CmpComponent } from "./cmp.component";

const routes: Routes = [
    {
        path: '', 
        component: CmpComponent,
        children: [
            {
                path: 'dashboard',
                component: CmpDashboardComponent,
            },
            {
                path: 'profile',
                component: CmpProfileComponent,
            },
            {
                path: 'changePassword',
                component: CmpUpdatePasswordComponent,
            },

            {
                path: 'company',
                component: CmpDashboardComponent,
            },
            {
                path: '',
                redirectTo:'dashboard',
                pathMatch:'full '
            }             
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class CmpRoutingModule {

}