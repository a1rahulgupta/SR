import { Component } from "@angular/core";
import { WebStorage } from "../../../core/utility/web.storage";
import { AppConfig } from "../../../core/config/app.config";
import { CmpDashboardService } from "../services/cmpDashboard.services";
import { ToastrService } from 'ngx-toastr';
import * as Chart from 'chart.js';

@Component({
    selector: 'dashboard-component',
    preserveWhitespaces: false,
    templateUrl: './view/cmp_dashboard.component.html',
    styleUrls: ['./css/dashboard.css'],
    providers: [
        CmpDashboardService
    ]
})
export class CmpDashboardComponent {
    a : any;
    b: any;
    c: any;
    d: any;
    e: any;
    f: any;
    g: any;
    h: any;
    i: any;
    j: any;
    negativeRatingCount: any = 0;
    positiveRatingCount: any = 0;
    overAllLinkTrackingCount: any = 0;
    overAllData: {
        labels: string[];
        datasets: {
            data: string[];
            backgroundColor: string[];
            hoverBackgroundColor: string[];
        }[];
    };
    positiveRatingPercent: number = 0;
    negativeRatingPercent: number = 0;
    overAllRatingGraph: boolean = false;
    overAllRatingData: any[];
    overAllRatingLabelDate: any[];
    companyResponseRate: any = 0;
    resolvedIncidentPercentage: any = 0;
    resolvedComplaintPercentage: any = 0;
    complaintCount: any = 0;
    incidentCount: any = 0;
    ratingReceivedCount: any = 0;
    facilityCount: any = 0;
    user: any;
    time: Date;
    prevNowPlaying: any;
    selectPeriod: string = 'overAll';
    body: object = {};
    constructor(
        private storage: WebStorage,
        private config: AppConfig,
        private CmpDashboardService: CmpDashboardService,
        private toaster: ToastrService
    ) { }

    public asc: string = 'asc';
    public exportfile: string = '';
    public loading: boolean = true;
    public listOverAllLinkTracking: any = [];
    public companyRatingArray: any = [];
    public companyIncidentComplaintArray: any = [];
    public companyRatingReceivedArray: any = [];
    public companyResolvedComplaintIncidentArray: any = [];
    public companyResponseRateArray: any = [];
    public totalItems: number = 0;
    public body1: any = {
        'page': 1,
        'count': this.config.perPageDefault,
        'searchText': '',
        'firstName': '',
        'phoneNumber': '',
        'createdAt': '',
        'selectType': '1',
        'sorting': 'createdAt',
        'order': 'asc',
    };

    // public setRecordPerPage(records: number): void {
    //     this.body1.page = 1;
    //     this.body1.count = records;
    //     this.companyLinkTracking();
    //   }

    //   public sort(field: string, order: any): void {
    //     if (order == 'asc') {
    //       this.asc = 'asc';
    //     } else {
    //       this.asc = 'desc';
    //     }
    //     this.body1.sorting = field;
    //     this.body1.order = order;
    //     this.companyLinkTracking();
    //   }

    //   public pageChanged(event: any): void {
    //     this.body1.page = event.page;
    //     this.companyLinkTracking();
    //   }

    //   public resetSearch(): void {
    //     this.body1.searchText = '';
    //     this.body1.phoneNumber = '';
    //     this.body1.createdAt = '';
    //     this.body1.firstName = '';
    //     this.body1.lastName = '';
    //     this.companyLinkTracking();
    //   }

    public getCompanyDashboardCount(selectPeriod) {
        this.loading = true;
        this.body = {
            selectPeriod: selectPeriod,
            todayDate: new Date()
        }
        this.CmpDashboardService.getCompanyDashboardCount(this.body).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.facilityCount = rs.data.facilityCount;
                this.ratingReceivedCount = rs.data.ratingReceivedCount;
                this.complaintCount = rs.data.complaintCount;
                this.incidentCount = rs.data.incidentCount;
                this.companyRatingReceivedArray = rs.data.companyRatingReceivedArray;
                this.companyIncidentComplaintArray = rs.data.companyIncidentComplaintArray;
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
    }

    public getResolvedComplaintPercentage(selectPeriod) {
        this.loading = true;
        this.body = {
            selectPeriod: selectPeriod,
            todayDate: new Date()
        }
        this.CmpDashboardService.getResolvedComplaintPercentage(this.body).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.resolvedComplaintPercentage = rs.data.resolvedComplaintPercentage;
                this.resolvedIncidentPercentage = rs.data.resolvedIncidentPercentage;
                this.companyResolvedComplaintIncidentArray = rs.data.companyResolvedComplaintIncidentArray;
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
    }

    public getCompanyResponseRate(selectPeriod) {
        this.loading = true;
        this.body = {
            selectPeriod: selectPeriod,
            todayDate: new Date()
        }
        this.CmpDashboardService.getCompanyResponseRate(this.body).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.companyResponseRate = rs.data.companyResponseRate;
                this.companyResponseRateArray = rs.data.companyResponseRateArray;
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
    }

    public overAllRating(overAllRatingData, overAllRatingLabel) {
        if (overAllRatingData[0] != null) {
            this.overAllRatingGraph = true;
            this.overAllData = {
                labels: overAllRatingLabel,
                datasets: [
                    {
                        data: overAllRatingData,
                        backgroundColor: [
                            "#009688",
                            "#ff7043"
                        ],
                        hoverBackgroundColor: [
                            "#009688",
                            "#ff7043"
                        ]
                    }]
            };
        } else {
            this.overAllRatingGraph = false;
        }

    }

    public getOverAllRatingOfCompany() {
        this.loading = true;
        let overAllRatingArray = [];
        let overAllRatingLabel = [];
        this.CmpDashboardService.getOverAllRatingOfCompany(this.body).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                overAllRatingLabel.push(rs.data.positiveRatingPercent + '%' + ' ' + 'Positive', rs.data.negativeRatingPercent + '%' + ' ' + 'Negative');
                overAllRatingArray.push(rs.data.positiveRatingPercent, rs.data.negativeRatingPercent);
                this.overAllRatingData = overAllRatingArray;
                this.overAllRatingLabelDate = overAllRatingLabel;
                this.overAllRating(this.overAllRatingData, this.overAllRatingLabelDate);
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
    }

    public filterByPeriod(selectPeriod) {
        this.getCompanyDashboardCount(selectPeriod);
        this.getResolvedComplaintPercentage(selectPeriod);
        this.getCompanyResponseRate(selectPeriod);
        this.companyLinkTracking(selectPeriod);
        this.companyRating(selectPeriod);
    }

    public companyLinkTracking(selectPeriod) {
        this.loading = false;
        this.body = {
            selectPeriod: selectPeriod,
            todayDate: new Date()
        }
        this.CmpDashboardService.companyLinkTracking(this.body).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.listOverAllLinkTracking = rs.data.overAllLinkTrackingArray;
                this.overAllLinkTrackingCount = rs.data.overAllLinkTrackingCount;
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
    }

    public companyRating(selectPeriod) {
        this.loading = true;
        this.body = {
            selectPeriod: selectPeriod,
            todayDate: new Date()
        }
        this.CmpDashboardService.companyRating(this.body).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.companyRatingArray = rs.data.companyRatingArray;
                this.positiveRatingCount = rs.data.positiveRatingCount;
                this.negativeRatingCount = rs.data.negativeRatingCount;
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
    }

    public ngOnInit(): void {
        this.user = this.storage.get(this.config.token.userKey);
        var stationdate = new Date();
        if (this.prevNowPlaying) {
            clearInterval(this.prevNowPlaying);
        }
        this.prevNowPlaying = setInterval(() => {
            stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
            this.time = stationdate;
        }, 1000);

        this.filterByPeriod('overAll');
        this.getOverAllRatingOfCompany();
    }
}