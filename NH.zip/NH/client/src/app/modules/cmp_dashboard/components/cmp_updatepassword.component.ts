import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

import { requiredTrim, matchingPasswords } from './../../../core/validators/validators';

import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { UserService } from "./../../../core/services/user.services";

@Component({
  selector: 'app-changePwd-company',
  preserveWhitespaces: false,
  templateUrl: './view/cmp_updatepassword.view.html',
  styleUrls: ['./css/setpassword.css'],
  providers: [
    UserService
  ]
})
export class CmpUpdatePasswordComponent {
  time: Date;
  prevNowPlaying: any;

  public changePwdFrm: FormGroup;
  public httpCall: any = false;

  constructor(
    private toaster: ToastrService,
    private user: UserService,
    private router: Router,
    private formBuilder: FormBuilder,
    private utills: Utills,
    private config: AppConfig
  ) {
    this.changePwdFrm = formBuilder.group({
      currentPassword: ['', [requiredTrim]],
      password: ['', [requiredTrim, Validators.pattern(this.config.pattern.PASSWORD)]],
      conf_password: ['', [requiredTrim]]
    }, { validator: matchingPasswords('password', 'conf_password') });
  }

  save() {
    this.httpCall = true;
    let data = this.changePwdFrm.value;
    this.user.changePassword(data).subscribe((result: any) => {
      this.httpCall = false;
      var rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.toaster.success(rs.message);
        this.changePwdFrm.reset();
        this.router.navigate(['/company']);
      } else {
        this.toaster.error(rs.message);
        this.changePwdFrm.reset();
      }
    });
  }

  public ngOnInit() {
        var stationdate = new Date();
    if (this.prevNowPlaying) {
        clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
        stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
        this.time = stationdate;
    }, 1000);
  }

}