import { Component, NgZone,ViewChild,EventEmitter, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';
import { WebStorage } from './../../../core/utility/web.storage';
import { requiredTrim } from "./../../../core/validators/validators";
import { UserService } from '../../../core/services/user.services';
import { CompanyService } from "../../company/services/company.services";
import { AgmCoreModule, MapsAPILoader } from '@agm/core';
import {} from '@types/googlemaps';
declare var jQuery: any;
declare var $: any;
declare var google: any;
import {
  ConfirmDialogModule,
  ConfirmationService,
  SelectItem,
  DialogModule,
  CalendarModule
} from 'primeng/primeng';
import { AuthService } from "../../../core/services/auth.service";

@Component({
  selector: 'app-company-profile',
  preserveWhitespaces: false,
  templateUrl: './view/cmp_profile.component.html',
  providers: [
    UserService,
    CompanyService
  ]
})
export class CmpProfileComponent { 
  userName: string;
  file1: any;
  file2: any;
  ownerCroppedImage: any;
  ownerDisplay: boolean = false;
  ownerBaseImage: Blob;
  ownerfileNameData: any;
  ownerImageChangedEvent: any = '';
  ownerCropperReady = false;
  cmpCroppedImage: any;
  cmpDisplay: boolean = false;
  cmpBaseImage: Blob;
  cmpfileNameData: any;
  cmpImageChangedEvent: any = '';
  cmpCropperReady = false;
  zipCodeData: any;
  addressData: string;
  role: any;
  showCmpFileName: boolean = false;
  showOwnerFileName: boolean = false;
  zipCode: any;
  zipCodes: any;
  cityName: any;
  finalState: any;
  stateCode: any;
  countryName: any;
  citytemp: any;
  time: Date;
  prevNowPlaying: any;
  maxDate: Date;
  minDate: Date;
  userCmpId: any;
  userId: any;
  phoneNumber: any;
  public httpCall: any = false;
  public cmpImagePath: any = '';
  public ownerImagePath: any = '';
  public profileFrm: FormGroup;
  public searchControl: FormControl;
  @ViewChild("search")
  public searchElementRef: ElementRef;
  

  constructor(
    private toaster: ToastrService,
    private UserService: UserService,
    private auth: AuthService,
    private company : CompanyService,
    private router: Router,
    private mapsAPILoader: MapsAPILoader,
    private ngZone: NgZone,
    private activatedRoute: ActivatedRoute,
    public config: AppConfig,
    private formBuilder: FormBuilder,
    public utills: Utills,
    private tmpStorage: TmpStorage,
    private storage: WebStorage
  ) {
    this.searchControl = new FormControl();
    this.profileFrm = formBuilder.group({
      cmpName: ['', [requiredTrim]],
      email: ['', [requiredTrim, Validators.pattern(this.config.pattern.EMAIL)]],
      firstName: ['', [requiredTrim]],
      lastName: ['', [requiredTrim]],
      country_code: ['+1', [requiredTrim]],
      status: ['1', [requiredTrim]],
      phoneNumber: ['', [requiredTrim, Validators.minLength(10), Validators.maxLength(10)]],
      ownerfilename: [{ value: '', disabled: true }],
      cmpfilename: [{ value: '', disabled: true }],
      address: ['', [requiredTrim]],
      city: ['', [requiredTrim]],
      state: ['', [requiredTrim]],
      zipCode: ['',  [requiredTrim, Validators.minLength(3), Validators.maxLength(5)]],
      country: ['', [requiredTrim]]

    });
  }

          ownerfileChangeEvent(event: any): void {
          this.ownerDisplay = true;
            this.ownerImageChangedEvent = event;
            let fileName = event.target.files[0];
            this.ownerfileNameData = fileName.name;
        }
        ownerImageLoaded() {
          this.ownerCropperReady = true;
        }
        ownerloadImageFailed(){
          this.ownerDisplay = false;
          this.toaster.error("You can upload only .jpg, .jpeg, .png file");
        }
        ownerSelectImage(action:any){
         if(action == true){
           this.ownerImageLoaded();
            this.ownerDisplay = false;
         }else{
           this.ownerDisplay = false;
         }
   }

 public ownerImageCropped(fileData: any) {
     this.ownerCroppedImage = fileData;
     let ownerfileName = this.ownerfileNameData;
      this.ownerBaseImage = this.utills.dataURItoBlob(fileData);
      let file = this.ownerBaseImage;
      let alowedSize = 1024 * 1024 * this.config.MaxUploadSixe;
      if (this.config.alowedFiletypes.indexOf(file.type) >= 0) {
        if (file.size <= alowedSize) {
          this.showOwnerFileName = true;
          this.profileFrm.controls['ownerfilename'].patchValue(ownerfileName);
        } else {
          this.toaster.error("Please select a file within " + this.config.MaxUploadSixe + "MB");
        }
      } else {
        this.toaster.error("You can upload only .jpg, .jpeg, .png, .gif file");
      }
    } 
  
       cmpfileChangeEvent(event: any): void {
          this.cmpDisplay = true;
            this.cmpImageChangedEvent = event;
            let fileName = event.target.files[0];
            this.cmpfileNameData = fileName.name;
        }
        cmpImageLoaded() {
          this.cmpCropperReady = true;
        }
        cmploadImageFailed(){
          this.cmpDisplay = false;
          this.toaster.error("You can upload only .jpg, .jpeg, .png file");
        }
       
        cmpSelectImage(action:any){
         if(action == true){
           this.cmpImageLoaded();
            this.cmpDisplay = false;
         }else{
           this.cmpDisplay = false;
         }
   }

 public cmpImageCropped(fileData: any) {
     this.cmpCroppedImage = fileData;
     let cmpfileName = this.cmpfileNameData;
      this.cmpBaseImage = this.utills.dataURItoBlob(fileData);
      let file = this.cmpBaseImage;
      let alowedSize = 1024 * 1024 * this.config.MaxUploadSixe;
      if (this.config.alowedFiletypes.indexOf(file.type) >= 0) {
        if (file.size <= alowedSize) {
          this.showCmpFileName = true;
          this.profileFrm.controls['cmpfilename'].patchValue(cmpfileName);
        } else {
          this.toaster.error("Please select a file within " + this.config.MaxUploadSixe + "MB");
        }
      } else {
        this.toaster.error("You can upload only .jpg, .jpeg, .png, .gif file");
      }
    }

  public update(ownerfileData,cmpfileData) {
        ownerfileData = this.ownerCroppedImage;
        cmpfileData = this.cmpCroppedImage;
        let formData = new FormData();
      let cmpfileName = this.cmpfileNameData;
      let ownerfileName = this.ownerfileNameData;
      let url = this.config.apiUrl + "/company/updateCompanyProfile";
      if(ownerfileData){
        this.ownerBaseImage = this.utills.dataURItoBlob(ownerfileData);
        let ownerfile = this.ownerBaseImage;
        formData.append("ownerfile", ownerfile, ownerfileName);
      }
      if(cmpfileData){
        this.cmpBaseImage = this.utills.dataURItoBlob(cmpfileData);
          let cmpfile = this.cmpBaseImage;
          formData.append("cmpfile", cmpfile, cmpfileName);
      }    
            this.httpCall = true;
            this.phoneNumber = this.profileFrm.value.country_code + this.profileFrm.value.phoneNumber;
            formData.append("cmpName", this.profileFrm.value.cmpName);
            formData.append("userId", this.userId);
            formData.append("userCmpId", this.userCmpId);
            formData.append("email", this.profileFrm.value.email);
            formData.append("firstName", this.profileFrm.value.firstName);
            formData.append("lastName", this.profileFrm.value.lastName);
            formData.append("phoneNumber", this.phoneNumber);
            formData.append("address", this.profileFrm.value.address);
            formData.append("city", this.profileFrm.value.city);
            formData.append("state", this.profileFrm.value.state);
            formData.append("stateCode", this.stateCode);
            formData.append("zipCode", this.profileFrm.value.zipCode);
            formData.append("country", this.profileFrm.value.country);
            this.xhrRequest(url, formData);
          
      }
  

  private xhrRequest(url, formData) {
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          this.httpCall = false;
          let rs = JSON.parse(xhr.response);
          if (rs.code == this.config.statusCode.success) {
            this.auth.refreshCompanyProfileData.emit();
            this.toaster.success(rs.message);
            this.router.navigate(['/company']);
            // location.reload();

          } else {
            this.toaster.error(rs.message);
          }
        } else {
          this.httpCall = false;
          let rs = JSON.parse(xhr.response);
          if (rs.code == this.config.statusCode.success) {
            this.auth.refreshCompanyProfileData.emit();
            this.toaster.success(rs.message);
            this.router.navigate(['/company']);
            // location.reload();
          } else {
            this.toaster.error(rs.message);
          }
        }
      }
    }
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Authorization", "Bearer " + this.storage.get(this.config.token.keyID));
    xhr.send(formData);
  }

  public setZipValueEmpty(){
    this.profileFrm.controls['zipCode'].patchValue(''); 
  }
 

  public ngOnInit() {
    // console.log("this.zipCodesasas", this.zipCode)
      let user = this.storage.get(this.config.token.userKey);
      this.UserService.getCompanyProfileById({ id: user.uid }).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          var phoneNumber = rs.data.phoneNumber;
          rs.data.phoneNumber = phoneNumber.slice(-10);
          rs.data.country_code = phoneNumber.slice(0, -10);
            this.ownerImagePath = 'assets/upload/profiles/'+rs.data.image;
          this.cmpImagePath = 'assets/upload/profiles/'+rs.data.cmpLogo;
          this.userName = rs.data.firstName + ' ' + rs.data.lastName;
          this.userId = rs.data.userId;
          this.userCmpId = rs.data.userCmpId;
          var parentObj = rs.data;
          this.stateCode = rs.data.stateCode;
          this.profileFrm.patchValue(parentObj);
        } else {
          this.toaster.error(rs.message);
          this.router.navigate(['']);
        }
      });
      this.role = user.role;
    var stationdate = new Date();
        if (this.prevNowPlaying) {
            clearInterval(this.prevNowPlaying);
        }
        this.prevNowPlaying = setInterval(() => {
            stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
            this.time = stationdate;
        }, 1000);
        
            //load Places Autocomplete
            this.searchControl = new FormControl();
            console.log("this.searchElementRef",this.searchElementRef);
            this.mapsAPILoader.load().then(() => {
              let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
                // types: ['(cities)'],
                componentRestrictions: { country: "us" }
              });
              autocomplete.addListener("place_changed", () => {
                this.ngZone.run(() => {
                  //get the place result
                  let place: google.maps.places.PlaceResult = autocomplete.getPlace();
                  console.log("place", place);
                  //verify result
                  if (place.geometry === undefined || place.geometry === null) {
                    return;
                  }
                  const components = place.address_components;
                  // console.log(components);
                  const street = null;
                  var data = [];
                  for (let i = 0, component; component = components[i]; i++) {
                    var temp = component.long_name;
                    data.push({
                      city: component.long_name
                    })
                    this.addressData = place.formatted_address;
                    if (component.types[0] === 'country') {
                      const country = component.long_name;
                      this.countryName = country; 
                    } else if (component.types[0] === 'administrative_area_level_1') {
                      const state = component.long_name;
                      this.stateCode = component.short_name;
                      this.finalState = state;
                      console.log("state", this.finalState);
                    } else if ((component.types[0] === 'locality') || (component.types[0] === 'sublocality_level_1')) {
                      const city = component.long_name;  
                      this.cityName = city;
                    }else if(component.types[0] === 'postal_code'){
                      const zip = component.long_name;
                      this.zipCodeData = zip;
                    }
                  }
                  this.profileFrm.controls['zipCode'].patchValue('');                  
                  this.profileFrm.controls['state'].patchValue(this.finalState);
                  this.profileFrm.controls['country'].patchValue(this.countryName);
                  this.profileFrm.controls['city'].patchValue(this.cityName);
                  this.profileFrm.controls['zipCode'].patchValue(this.zipCodeData);
                  this.profileFrm.controls['address'].patchValue(this.addressData);
                });
              });
            });
        
  }

}
