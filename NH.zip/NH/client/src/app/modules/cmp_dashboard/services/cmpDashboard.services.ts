
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '../../../core/utility/http.client';


@Injectable()
export class CmpDashboardService {
  constructor(
    private http: HttpClient
  ) { }

  getCompanyDashboardCount(data: any): Observable<any> {
    return this.http.post('/company/getCompanyDashboardCount', data);
  }

  getResolvedComplaintPercentage(data: any): Observable<any> {
    return this.http.post('/company/getResolvedComplaintPercentage', data);
  }

  getCompanyResponseRate(data: any): Observable<any> {
    return this.http.post('/company/getCompanyResponseRate', data);
  }

  getOverAllRatingOfCompany(data: any): Observable<any> {
    return this.http.post('/company/getOverAllRatingOfCompany', data);
  }

  companyLinkTracking(data: any): Observable<any> {
    return this.http.post('/company/companyLinkTracking', data);
  }

  companyRating(data: any): Observable<any> {
    return this.http.post('/company/companyRating', data);
  }

}

