import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CmpProfileComponent } from './components/cmp_profile.component';
import { CmpUpdatePasswordComponent } from './components/cmp_updatepassword.component';
import { CmpDashboardComponent } from './components/cmp_dashboard.component';
import { CmpComponent } from './cmp.component';
import { CmpRoutingModule } from './cmp-routing.module';
import { ImageCropperModule } from 'ngx-image-cropper';
import { DialogModule, ChartModule, AccordionModule } from 'primeng/primeng';
import { CountoModule }  from 'angular2-counto';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ChartModule,
        ReactiveFormsModule,
        CmpRoutingModule,
        DialogModule,
        ImageCropperModule,
        AccordionModule,
        CountoModule
    ],
    declarations: [
        CmpComponent,
        CmpDashboardComponent,
        CmpUpdatePasswordComponent,
        CmpProfileComponent
    ],
    providers: []
})
export class CmpDashboardModule { }