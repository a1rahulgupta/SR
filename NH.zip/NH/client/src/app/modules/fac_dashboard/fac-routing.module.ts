import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";
import { FacComponent } from "./fac.component";
import { FacDashboardComponent } from "./components/fac_dashboard.component";
import { FacProfileComponent } from "./components/fac_profile.component";
import { EmployeeProfileComponent } from "./components/emp_profile.component";
import { FacUpdatePasswordComponent } from "./components/fac_updatepassword.component";
import { EmpUpdatePasswordComponent } from "./components/emp_updatepassword.component";


const routes: Routes = [
    {
        path: '', 
        component: FacComponent,
        children: [
            {
                path: 'dashboard',
                component: FacDashboardComponent,
            },
            {
                path: 'facility',
                component: FacDashboardComponent,
            },
            {
                path: 'profile',
                component: FacProfileComponent,
            },
            {
                path: 'changePassword',
                component: FacUpdatePasswordComponent,
            },
            {
                path: 'employeeChangePassword',
                component: EmpUpdatePasswordComponent,
            },
            {
                path: 'employeeProfile',
                component: EmployeeProfileComponent,
            },
            {
                path: '',
                redirectTo:'dashboard',
                pathMatch:'full '
            }            
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class FacRoutingModule {

}