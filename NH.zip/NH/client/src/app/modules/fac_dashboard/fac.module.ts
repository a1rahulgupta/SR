import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FacDashboardComponent } from './components/fac_dashboard.component';
import { FacComponent } from './fac.component';
import { FacRoutingModule } from './fac-routing.module';
import { SettingModule } from "./../../layout/common/setting.module";
import { ChartModule } from 'primeng/primeng';
import { ImageCropperModule } from 'ngx-image-cropper';
import { FacProfileComponent } from "./components/fac_profile.component";
import { EmployeeProfileComponent } from "./components/emp_profile.component";
import { FacUpdatePasswordComponent } from "./components/fac_updatepassword.component";
import { EmpUpdatePasswordComponent } from "./components/emp_updatepassword.component";
import { AutosizeModule } from 'ngx-autosize';
import { AngularDraggableModule } from 'angular2-draggable';

import {
    ConfirmDialogModule,
    ConfirmationService,
    SelectItem,
    DialogModule,
    CalendarModule,
    ProgressSpinnerModule,
} from 'primeng/primeng';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { CountoModule }  from 'angular2-counto';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        FacRoutingModule,
        ChartModule,
        ImageCropperModule,
        ConfirmDialogModule,
        DialogModule,
        AutosizeModule,
        ProgressSpinnerModule,
        InfiniteScrollModule,
        SettingModule.forChild(),
        AngularDraggableModule,
        CountoModule
    ],
    declarations: [
        FacComponent,
        FacDashboardComponent,
        FacProfileComponent,
        EmployeeProfileComponent,
        FacUpdatePasswordComponent,
        EmpUpdatePasswordComponent
    ],
    providers: []
})
export class FacDashboardModule { }