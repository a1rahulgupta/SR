import { Component, NgZone,ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';
import { WebStorage } from './../../../core/utility/web.storage';
import { requiredTrim } from "./../../../core/validators/validators";
import { UserService } from '../../../core/services/user.services';
import { AgmCoreModule, MapsAPILoader } from '@agm/core';
import {} from '@types/googlemaps';
import { AuthService } from "../../../core/services/auth.service";
// import {ImageCropperComponent, CropperSettings} from 'ng2-img-cropper';

declare var jQuery: any;
declare var $: any;
declare var google: any;

@Component({
  selector: 'app-facility-profile',
  preserveWhitespaces: false,
  templateUrl: './view/fac_profile.component.html',
  providers: [
    UserService,
  ]
})
export class FacProfileComponent { 
  // data: any;
  // cropperSettings: CropperSettings
  cmpName: any;
  file1: any;
  file2: any;
  ownerCroppedImage: any;
  ownerDisplay: boolean = false;
  ownerBaseImage: Blob;
  ownerfileNameData: any;
  ownerImageChangedEvent: any = '';
  ownerCropperReady = false;
  facCroppedImage: any;
  facDisplay: boolean = false;
  facBaseImage: Blob;
  facfileNameData: any;
  facImageChangedEvent: any = '';
  facCropperReady = false;
  addressData: any;
  zipCodeData: any;
  role: any;
  username: string;
  showFacFileName: boolean = false;
  showOwnerFileName: boolean = false;
  zipCode: any;
  zipCodes: any;
  cityName: any;
  finalState: any;
  stateCode: any;
  countryName: any;
  citytemp: any;
  time: Date;
  prevNowPlaying: any;
  maxDate: Date;
  minDate: Date;
  userFacId: any;
  userId: any;
  phoneNumber: any;
  public httpCall: any = false;
  public facImagePath: any = '';
  public ownerImagePath: any = '';
  public profileFrm: FormGroup;
  public searchControl: FormControl;
  @ViewChild("search")
  public searchElementRef: ElementRef;
  

  constructor(
    private toaster: ToastrService,
    private UserService: UserService,
    private router: Router,
    private mapsAPILoader: MapsAPILoader,
    private auth: AuthService,
    private ngZone: NgZone,
    private activatedRoute: ActivatedRoute,
    public config: AppConfig,
    private formBuilder: FormBuilder,
    public utills: Utills,
    private tmpStorage: TmpStorage,
    private storage: WebStorage
  ) {
      // this.cropperSettings = new CropperSettings();
      // this.cropperSettings.width = 100;
      // this.cropperSettings.height = 100;
      // this.cropperSettings.croppedWidth = 100;
      // this.cropperSettings.croppedHeight = 100;
      // this.cropperSettings.canvasWidth = 400;
      // this.cropperSettings.canvasHeight = 300;
      // this.data = {};
        
    this.searchControl = new FormControl();
    this.profileFrm = formBuilder.group({
      facName: ['', [requiredTrim]],
      email: ['', [requiredTrim, Validators.pattern(this.config.pattern.EMAIL)]],
      firstName: ['', [requiredTrim]],
      lastName: ['', [requiredTrim]],
      country_code: ['+1', [requiredTrim]],
      status: ['1', [requiredTrim]],
      phoneNumber: ['', [requiredTrim, Validators.minLength(10), Validators.maxLength(10)]],
      ownerfilename: [{ value: '', disabled: true }],
      facfilename: [{ value: '', disabled: true }],
      address: ['', [requiredTrim]],
      city: ['', [requiredTrim]],
      state: ['', [requiredTrim]],
      zipCode: ['',  [requiredTrim, Validators.minLength(3), Validators.maxLength(5)]],
      country: ['', [requiredTrim]],
      googleLink: ['', [requiredTrim]],
      twilioTollFreeNumber: ['',[requiredTrim]]

    });
  }



        ownerfileChangeEvent(event: any): void {
          this.ownerDisplay = true;
            this.ownerImageChangedEvent = event;
            let fileName = event.target.files[0];
            this.ownerfileNameData = fileName.name;
        }
        ownerImageLoaded() {
          this.ownerCropperReady = true;
        }
        ownerloadImageFailed(){
          this.ownerDisplay = false;
          this.toaster.error("You can upload only .jpg, .jpeg, .png file");
        }
        ownerSelectImage(action:any){
         if(action == true){
           this.ownerImageLoaded();
            this.ownerDisplay = false;
         }else{
           this.ownerDisplay = false;
         }
   }

 public ownerImageCropped(fileData: any) {
     this.ownerCroppedImage = fileData;
     let ownerfileName = this.ownerfileNameData;
      this.ownerBaseImage = this.utills.dataURItoBlob(fileData);
      let file = this.ownerBaseImage;
      let alowedSize = 1024 * 1024 * this.config.MaxUploadSixe;
      if (this.config.alowedFiletypes.indexOf(file.type) >= 0) {
        if (file.size <= alowedSize) {
          this.showOwnerFileName = true;
          this.profileFrm.controls['ownerfilename'].patchValue(ownerfileName);
        } else {
          this.toaster.error("Please select a file within " + this.config.MaxUploadSixe + "MB");
        }
      } else {
        this.toaster.error("You can upload only .jpg, .jpeg, .png, .gif file");
      }
    } 
  
       facfileChangeEvent(event: any): void {
          this.facDisplay = true;
            this.facImageChangedEvent = event;
            let fileName = event.target.files[0];
            this.facfileNameData = fileName.name;
        }
        facImageLoaded() {
          this.facCropperReady = true;
        }
        facloadImageFailed(){
          this.facDisplay = false;
          this.toaster.error("You can upload only .jpg, .jpeg, .png file");
        }
       
        facSelectImage(action:any){
         if(action == true){
           this.facImageLoaded();
            this.facDisplay = false;
         }else{
           this.facDisplay = false;
         }
   }

 public facImageCropped(fileData: any) {
    this.facCroppedImage = fileData;
     let facfileName = this.facfileNameData;
      this.facBaseImage = this.utills.dataURItoBlob(fileData);
      let file = this.facBaseImage;
      let alowedSize = 1024 * 1024 * this.config.MaxUploadSixe;
      if (this.config.alowedFiletypes.indexOf(file.type) >= 0) {
        if (file.size <= alowedSize) {
          this.showFacFileName = true;
          this.profileFrm.controls['facfilename'].patchValue(facfileName);
        } else {
          this.toaster.error("Please select a file within " + this.config.MaxUploadSixe + "MB");
        }
      } else {
        this.toaster.error("You can upload only .jpg, .jpeg, .png, .gif file");
      }
    } 

  public update(ownerfileData,facfileData) {
    ownerfileData = this.ownerCroppedImage;
    facfileData = this.facCroppedImage;
    let formData = new FormData();
      let facfileName = this.facfileNameData;
      let ownerfileName = this.ownerfileNameData;
      let url = this.config.apiUrl + "/facility/updateFacilityProfile";
      if(ownerfileData){
        this.ownerBaseImage = this.utills.dataURItoBlob(ownerfileData);
        let ownerfile = this.ownerBaseImage;
        formData.append("ownerfile", ownerfile, ownerfileName);
      }
      if(facfileData){
        this.facBaseImage = this.utills.dataURItoBlob(facfileData);
          let facfile = this.facBaseImage;
          formData.append("facfile", facfile, facfileName);
      }    
            this.httpCall = true;
            this.phoneNumber = this.profileFrm.value.country_code + this.profileFrm.value.phoneNumber;
            formData.append("facName", this.profileFrm.value.facName);
            formData.append("userId", this.userId);
            formData.append("userFacId", this.userFacId);
            formData.append("email", this.profileFrm.value.email);
            formData.append("firstName", this.profileFrm.value.firstName);
            formData.append("lastName", this.profileFrm.value.lastName);
            formData.append("phoneNumber", this.phoneNumber);
            formData.append("address", this.profileFrm.value.address);
            formData.append("city", this.profileFrm.value.city);
            formData.append("state", this.profileFrm.value.state);
            formData.append("stateCode", this.stateCode);
            formData.append("zipCode", this.profileFrm.value.zipCode);
            formData.append("country", this.profileFrm.value.country);
            formData.append("googleLink", this.profileFrm.value.googleLink);
            formData.append("twilioTollFreeNumber", this.profileFrm.value.twilioTollFreeNumber);
            this.xhrRequest(url, formData);
          
      }
  

  private xhrRequest(url, formData) {
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          this.httpCall = false;
          let rs = JSON.parse(xhr.response);
          if (rs.code == this.config.statusCode.success) {
            this.auth.refreshFacilityProfileData.emit();
            this.toaster.success(rs.message);
            this.router.navigate(['/facility']);

          } else {
            this.toaster.error(rs.message);
          }
        } else {
          this.httpCall = false;
          let rs = JSON.parse(xhr.response);
          if (rs.code == this.config.statusCode.success) {
            this.auth.refreshFacilityProfileData.emit();
            this.toaster.success(rs.message);
            this.router.navigate(['/facility']);
          } else {
            this.toaster.error(rs.message);
          }
        }
      }
    }
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Authorization", "Bearer " + this.storage.get(this.config.token.keyID));
    xhr.send(formData);
  }

  public setZipValueEmpty(){
    this.profileFrm.controls['zipCode'].patchValue(''); 
  }
 

  public ngOnInit() {
    // console.log("this.zipCodesasas", this.zipCode)
      let user = this.storage.get(this.config.token.userKey);
      this.role = user.role;
      this.UserService.getFacilityProfileById({ id: user.uid }).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          console.log("rs-------------",rs)
          var phoneNumber = rs.data.phoneNumber;
          rs.data.phoneNumber = phoneNumber.slice(-10);
          rs.data.country_code = phoneNumber.slice(0, -10);
          this.facImagePath = 'assets/upload/profiles/'+rs.data.facLogo;
          this.ownerImagePath = 'assets/upload/profiles/'+rs.data.image;
          this.userId = rs.data.userId;
          this.cmpName = rs.data.cmpName;
          this.userFacId = rs.data.userFacId;
          this.username =  rs.data.firstName + ' ' + rs.data.lastName;
          var parentObj = rs.data;
          this.stateCode = rs.data.stateCode;
          this.profileFrm.patchValue(parentObj);
        } else {
          this.toaster.error(rs.message);
          this.router.navigate(['']);
        }
      });

    var stationdate = new Date();
        if (this.prevNowPlaying) {
            clearInterval(this.prevNowPlaying);
        }
        this.prevNowPlaying = setInterval(() => {
            stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
            this.time = stationdate;
        }, 1000);
        
            //load Places Autocomplete
            this.searchControl = new FormControl();
            console.log("this.searchElementRef",this.searchElementRef);
            this.mapsAPILoader.load().then(() => {
              let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
                // types: ['(cities)'],
                componentRestrictions: { country: "us" }
              });
              autocomplete.addListener("place_changed", () => {
                this.ngZone.run(() => {
                  //get the place result
                  let place: google.maps.places.PlaceResult = autocomplete.getPlace();
                  console.log("place", place);
                  //verify result
                  if (place.geometry === undefined || place.geometry === null) {
                    return;
                  }
                  const components = place.address_components;
                  // console.log(components);
                  const street = null;
                  var data = [];
                  for (let i = 0, component; component = components[i]; i++) {
                    var temp = component.long_name;
                    data.push({
                      city: component.long_name
                    })
                    this.addressData = place.formatted_address;
                    if (component.types[0] === 'country') {
                      const country = component.long_name;
                      this.countryName = country; 
                    } else if (component.types[0] === 'administrative_area_level_1') {
                      const state = component.long_name;
                      this.stateCode = component.short_name;
                      this.finalState = state;
                      console.log("state", this.finalState);
                     } else if ((component.types[0] === 'locality') || (component.types[0] === 'sublocality_level_1')) {
                      const city = component.long_name;  
                      this.cityName = city;
                    }else if(component.types[0] === 'postal_code'){
                      const zip = component.long_name;
                      this.zipCodeData = zip;
                    }
                  }
                  this.profileFrm.controls['state'].patchValue(this.finalState);
                  this.profileFrm.controls['country'].patchValue(this.countryName);
                  this.profileFrm.controls['city'].patchValue(this.cityName);
                  this.profileFrm.controls['zipCode'].patchValue(this.zipCodeData);
                  this.profileFrm.controls['address'].patchValue(this.addressData);
                });
              });
            });
        
  }

}
