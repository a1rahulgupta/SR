import { Component, EventEmitter, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

import { UserService } from "./../../../core/services/user.services";
import { AppConfig } from "./../../../core/config/app.config";
import { Utills } from './../../../core/utility/utills';
import { requiredTrim } from "./../../../core/validators/validators";
import { WebStorage } from "./../../../core/utility/web.storage";
import { AuthService } from "../../../core/services/auth.service";
import { EmployeeService } from '../../employee/services/employee.services';

@Component({
  selector: 'profile-component',
  templateUrl: './view/emp_profile.component.html',
  styleUrls: ['./css/profile.css'],
  providers: [
    UserService,
    EmployeeService
  ]
})
export class EmployeeProfileComponent {
  permissionData: any;
  time: Date;
  prevNowPlaying: any;
  display: boolean = false;
  file: any;
  showFileName: boolean = false;
  baseImage: Blob;
  fileNameData: any;
  imageChangedEvent: any = '';
  croppedImage: any = '';
  cropperReady = false;
  role: any;
  userName: any;
  phone: any;
  public imagePath: any = '';

  public profileFrm: FormGroup;
  public httpCall: any = false;

  constructor(
    private toaster: ToastrService,
    private auth: AuthService,
    private user: UserService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public config: AppConfig,
    public utills: Utills,
    private storage: WebStorage,
    private employee: EmployeeService,
    private formBuilder: FormBuilder
  ) {
    this.profileFrm = formBuilder.group({
      firstName: ['', [requiredTrim]],
      lastName: ['', [requiredTrim]],
      filename: [{ value: '', disabled: true }],
      email: ['', [requiredTrim, Validators.pattern(this.config.pattern.EMAIL)]],
      country_code: ['+1', [requiredTrim]],
      phoneNumber: ['', [requiredTrim, Validators.minLength(10), Validators.maxLength(10)]]
    });
  }

  fileChangeEvent(event: any): void {
    this.display = true;
    this.imageChangedEvent = event;
    let fileName = event.target.files[0];
    this.fileNameData = fileName.name;
  }
  imageLoaded() {
    this.cropperReady = true;
  }
  loadImageFailed() {
    this.display = false;
    this.toaster.error("You can upload only .jpg, .jpeg, .png file");
  }

  selectImage(action: any) {
    if (action == true) {
      this.imageLoaded();
      this.display = false;
    } else {
      this.display = false;
    }
  }

  public imageCropped(fileData: any) {
    this.croppedImage = fileData;
    let fileName = this.fileNameData;
    this.baseImage = this.utills.dataURItoBlob(fileData);
    let file = this.baseImage;
    let alowedSize = 1024 * 1024 * this.config.MaxUploadSixe;
    if (this.config.alowedFiletypes.indexOf(file.type) >= 0) {
      if (file.size <= alowedSize) {
        this.showFileName = true;
        this.profileFrm.controls['filename'].patchValue(fileName);
      } else {
        this.toaster.error("Please select a file within " + this.config.MaxUploadSixe + "MB");
      }
    } else {
      this.toaster.error("You can upload only .jpg, .jpeg, .png, .gif file");
    }
  }

  public save(fileData) {
    fileData = this.croppedImage;
    let fileName = this.fileNameData;
    let user = this.storage.get(this.config.token.userKey);
    let url = this.config.apiUrl + "/employee/updateEmployee";
    console.log("fileData---url---", url);
    if (fileData != '') {
      this.baseImage = this.utills.dataURItoBlob(fileData);
      let file = this.baseImage;
      let alowedSize = 1024 * 1024 * this.config.MaxUploadSixe;
      if (this.config.alowedFiletypes.indexOf(file.type) >= 0) {
        if (file.size <= alowedSize) {
          this.httpCall = true;
          this.phone = this.profileFrm.value.country_code + this.profileFrm.value.phoneNumber;
          let formData = new FormData();
          formData.append("file", file, fileName);
          formData.append("_id", user.uid);
          formData.append("email", this.profileFrm.value.email);
          formData.append("firstName", this.profileFrm.value.firstName);
          formData.append("lastName", this.profileFrm.value.lastName);
          formData.append("phoneNumber", this.phone);
          this.xhrRequest(url, formData);
        } else {
          this.toaster.error("Please select a file within " + this.config.MaxUploadSixe + "MB");
        }
      } else {
        this.toaster.error("You can upload only .jpg, .jpeg, .png, .gif file");
      }
    } else {
      this.httpCall = true;
      this.phone = this.profileFrm.value.country_code + this.profileFrm.value.phoneNumber;
      let formData = new FormData();
      formData.append("_id", user.uid);
      formData.append("email", this.profileFrm.value.email);
      formData.append("lastName", this.profileFrm.value.lastName);
      formData.append("firstName", this.profileFrm.value.firstName);
      formData.append("phoneNumber", this.phone);
      this.xhrRequest(url, formData);
    }
    // });
  }

  private xhrRequest(url, formData) {
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          this.httpCall = false;
          let rs = JSON.parse(xhr.response);
          if (rs.code == this.config.statusCode.success) {
            this.toaster.success(rs.message);
            this.auth.refreshEmployeeProfileData.emit();
            this.router.navigate(['/facility']);
          } else {
            this.toaster.error(rs.message);
          }
        } else {
          this.httpCall = false;
          let rs = JSON.parse(xhr.response);
          if (rs.code == this.config.statusCode.success) {
            this.toaster.success(rs.message);
            this.auth.refreshEmployeeProfileData.emit();
            this.router.navigate(['/facility']);
          } else {
            this.toaster.error(rs.message);
          }
        }
      }
    }
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Authorization", "Bearer " + this.storage.get(this.config.token.keyID));
    xhr.send(formData);
  }

  public ngOnInit() {
    let user = this.storage.get(this.config.token.userKey);
    if (user.role == 'employee') {
      var obj = {
        employeeId: user.uid,
      }
      this.employee.getEmployeePermissions(obj).subscribe((result) => {
        let rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.permissionData = rs.data;
        }
      })

    }
    this.user.getEmployeeProfile({ id: user.uid }).subscribe((result: any) => {
      var rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.userName = rs.data.userData.userName;
        this.role = rs.data.userData.role;
        var phoneNumber = rs.data.userData.phoneNumber;
        rs.data.userData.phoneNumber = phoneNumber.slice(-10);
        rs.data.userData.country_code = phoneNumber.slice(0, -10);
        this.imagePath = 'assets/upload/profiles/' + rs.data.userData.image;
        console.log(this.imagePath)
        this.profileFrm.patchValue(rs.data.userData);
      } else {
        this.toaster.error(rs.message);
      }
    });
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);

  }
}


