
import { Component, ElementRef, ViewChild, OnInit, AfterViewInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from './../../../core/config/app.config';
import { FacService } from "../service/fac.service";
import { Router } from "@angular/router";
import { WebStorage } from "../../../core/utility/web.storage";
import { Message } from 'primeng/primeng';
import * as Chart from 'chart.js';
import { EmployeeService } from '../../employee/services/employee.services';
import { ProgressSpinnerModule } from 'primeng/primeng';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/switchMap';

declare var $: any;

@Component({
  selector: 'app-fac-dashboard',
  templateUrl: './view/fac_dashboard.component.html',
  providers: [
    FacService,
    EmployeeService
  ]
})
export class FacDashboardComponent implements AfterViewInit, OnInit {
  bottomTab4: boolean = false;
  bottomTab3: boolean = false;
  bottomTab2: boolean = false;
  bottomTab1: boolean = false;
  todaysCheckListExist: boolean;
  todaysCheckList: any;
  totalLengthActivities: any;
  a : any;
  b: any;
  c: any;
  d: any;
  e: any;
  f: any;
  permissionData: any = {
    dashboard: {
      "status": false,
      "totalVisitorsCount": false,
      "positiveRatingsCount": false,
      "negativeRatingsCount": false,
      "smsMessageCount": false,
      "clickTrackerSection": false,
      "todayChackList": false,
      "latestNegativeResponse": false,
      "latestPositiveRatings": false,
      "latestNegativeRatings": false,
      "visitorTrendsGraph": false,
      "visitorRatingGraph": false,
      "message": false,
      "responseRate": false,
      "linkTracking": false,
      "latestVisitorsList": false,
      "overallRatingGraph": false
    }
  };
  user: any;
  @ViewChild('myChart') myChart: ElementRef;
  @ViewChild('parent') parent: ElementRef;
  overAllRatingLabelDate: any[];
  negativeRatingPercent: number = 0;
  positiveRatingPercent: number = 0;
  neutralRatingPercent: number = 0;
  overAllRatingGraph: boolean = false;
  commingsoon: boolean = false;
  loader: boolean = false;
  neutralCount: any;
  overAllRatingData: any[];
  mm: any[];
  lb: string[];
  data: {
    labels: string[];
    datasets: {
      data: string[];
      backgroundColor: string[];
      hoverBackgroundColor: string[];
    }[];
  };
  totalVisitors: any;
  overAllResponseRate: any;
  todaysResponseRate: any;
  yesterdayDaysResponseRate: any;
  sevenDaysResponseRate: any;
  thirtyDaysResponseRate: any;
  totalSms: any;
  sevenDaysVisitorsMessage: any;
  thirtyDaysVisitorsMessage: any;
  todayMessage: any;
  yesterdayMessage: any;
  chartColor: string[];
  doughnutChartLabels: string[];
  doughnutChartData: number[];
  smsCount: any;
  googleLink: any;
  todayClicks: any;
  lastSevenDaysClicks: any;
  lastOneMonthClicks: any;
  yesterday: any;
  today: any;
  thirtyDaysVisitors: any;
  sevenDaysVisitors: any;
  listVisitorslength: boolean;
  linkTrackinglength: boolean;
  todayVisitorslength: boolean;
  length: boolean;
  negativeRatingData: any;
  latestResponseData: any;
  postiveRatingData: any;
  noteCount: any;
  suggestionList: any;
  count: any;
  todayVisitors: any;
  saved: boolean = false;
  saving: boolean = false;
  public body: any = {
    'ratingDate': new Date()
  };
  public messageDate: any = {
    'createdAt': new Date()
  }
  positiveCount: any;
  negativeCount: any;
  linkTrackingData: any;
  listVisitors: any;
  kioskMode: boolean;
  prevNowPlaying: any;
  listData: any;
  visCount: any;
  display: boolean;
  time: Date;
  nn: any[];
  visitorTrendData: any;
  visitorTrendOptions: any;
  visitorRatingData: any;
  saveNote: string;
  visitorRatingOptions: any;


  constructor(
    private toaster: ToastrService,
    private fac: FacService,
    private employee: EmployeeService,
    private storage: WebStorage,
    private config: AppConfig,
    private router: Router
  ) {

  }

  /*------------------ Listing Elements --------------------*/
  // events
  public loading: boolean = true;
  public body1: any = {
    'page': 1
  };

  public selectBottomTab(bottomTab){
    if(bottomTab == '1'){
      this.bottomTab1 = true;
      this.bottomTab2 = false;
      this.bottomTab3 = false;
      this.bottomTab4 = false;
    }else if(bottomTab == '2'){
      this.bottomTab1 = false;
      this.bottomTab2 = true;
      this.bottomTab3 = false;
      this.bottomTab4 = false;
    }else if(bottomTab == '3'){
      this.bottomTab1 = false;
      this.bottomTab2 = false;
      this.bottomTab3 = true;
      this.bottomTab4 = false;
    }else{
      this.bottomTab1 = false;
      this.bottomTab2 = false;
      this.bottomTab3 = false;
      this.bottomTab4 = true;
    }
  }
  public visitorCount() {
    this.loading = true;
    let overAllRatingArray = [];
    let overAllRatingLabel = [];
    this.fac.visitorCount(this.body).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.visitorCount = rs.data.visitorCount;
        this.negativeCount = rs.data.negativeCount;
        this.positiveCount = rs.data.positiveCount;
        this.neutralRatingPercent = rs.data.neutralRatingPercent;
        this.positiveRatingPercent = rs.data.positiveRatingPercent;
        this.negativeRatingPercent = rs.data.negativeRatingPercent;
        this.smsCount = rs.data.smsCount;
        this.todayVisitors = rs.data.todayVisitors;
        overAllRatingLabel.push(this.neutralRatingPercent + '%' + ' ' + 'Neutral', this.positiveRatingPercent + '%' + ' ' + 'Positive', this.negativeRatingPercent + '%' + ' ' + 'Negative');
        overAllRatingArray.push(this.neutralRatingPercent, this.positiveRatingPercent, this.negativeRatingPercent);
        this.overAllRatingData = overAllRatingArray;
        this.overAllRatingLabelDate = overAllRatingLabel;
        this.overAllRating(this.overAllRatingData, this.overAllRatingLabelDate);
        if (rs.data.todayVisitors.length == 0) {
          this.todayVisitorslength = false;
        }
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  public overAllRating(overAllRatingData, overAllRatingLabel) {
    if (overAllRatingData[0] != null) {
      this.overAllRatingGraph = true;
      this.data = {
        labels: overAllRatingLabel,
        datasets: [
          {
            data: overAllRatingData,
            backgroundColor: [
              "#5c6bc0",
              "#009688",
              "#ff7043"
            ],
            hoverBackgroundColor: [
              "#5c6bc0",
              "#009688",
              "#ff7043"
            ]
          }]
      };
    } else {
      this.overAllRatingGraph = false;
    }

  }

  public getAllRatingResponseCount() {
    this.loading = true;
    this.fac.getAllRatingResponseCount(this.body).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.loader = false;
        this.sevenDaysVisitors = rs.data.sevenDaysVisitors,
          this.thirtyDaysVisitors = rs.data.thirtyDaysVisitors,
          this.today = rs.data.today,
          this.yesterday = rs.data.yesterday,
          this.totalVisitors = rs.data.totalVisitors
      } else {
        this.loader = false;
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  public getAllMessageCount() {
    this.loading = true;
    this.fac.getAllMessageCount(this.messageDate).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.sevenDaysVisitorsMessage = rs.data.sevenDaysVisitors,
          this.thirtyDaysVisitorsMessage = rs.data.thirtyDaysmsCount,
          this.todayMessage = rs.data.today,
          this.yesterdayMessage = rs.data.yesterday,
          this.totalSms = rs.data.totalSms
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }
  public getAllResponseRate() {
    this.loading = true;
    this.fac.getAllResponseRate(this.body).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.thirtyDaysResponseRate = rs.data.thirtyDaysResponseRate;
        this.sevenDaysResponseRate = rs.data.sevenDaysResponseRate;
        this.yesterdayDaysResponseRate = rs.data.yesterdayDaysResponseRate;
        this.todaysResponseRate = rs.data.todaysResponseRate;
        this.overAllResponseRate = rs.data.overAllResponseRate
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }
  public linkTracking() {
    this.loading = true;
    this.fac.linkTracking({ data: this.body }).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.linkTrackingData = rs.data.data;
        if (rs.data.data.length == 0) {
          this.linkTrackinglength = false;
        }
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }
  public latestResponse() {
    this.loading = true;
    this.fac.latestResponse({ data: this.body }).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.latestResponseData = rs.data.data;
        if (rs.data.data.length == 0) {
          this.latestResponseData = false;
        }
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }
  public latestNegativeRatings() {
    this.loading = true;
    this.fac.latestNegativeRatings({ data: this.body }).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.negativeRatingData = rs.data.data;
        if (rs.data.data.length == 0) {
          this.negativeRatingData = false;
        }
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }
  public latestPositiveRatings() {
    this.loading = true;
    this.fac.latestPositiveRatings({ data: this.body }).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.postiveRatingData = rs.data.data;
        if (rs.data.data.length == 0) {
          this.postiveRatingData = false;
        }
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  public getAllVisitors() {
    this.loading = true;
    this.fac.getAllVisitorsDashboard(this.body).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.listVisitors = rs.data;
        if (rs.data.length == 0) {
          this.listVisitorslength = false;
        }
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  public getClickTrackerCounts() {
    this.loading = true;
    this.fac.getClickTrackerCounts({ todayDate: new Date() }).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.googleLink = rs.data.googleLink
        this.todayClicks = rs.data.todayClicks
        this.lastSevenDaysClicks = rs.data.lastSevenDaysClicks
        this.lastOneMonthClicks = rs.data.lastOneMonthClicks
      } else {
        this.googleLink = 'NA';
        this.todayClicks = this.lastSevenDaysClicks = this.lastOneMonthClicks = 0;
      }
      this.loading = false;
    });
  }

  public getVisitorTrends() {
    this.loading = true;

    let myChart = this.myChart.nativeElement;
    var parent = this.parent.nativeElement;
    myChart.width = parent.offsetWidth;
    myChart.height = parent.offsetHeight;
    var ctx = myChart.getContext('2d');

    this.fac.getVisitorTrends({ todayDate: new Date() }).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {

        this.visitorTrendData = {
          labels: rs.data.dateFormatArray,
          datasets: [
            {
              label: 'Rating',
              data: rs.data.avgRatingArray,
              fill: false,
              lineTension: 0,
              pointHoverBackgroundColor: '#4bc0c1',
              pointHoverBorderColor: '#4bc0c1',
              pointHoverBorderWidth: 4,
              borderWidth: '2',
              borderColor: '#4bc0c0',
              pointBorderWidth: 2,
              pointRadius: 3,
            }
          ]
        }


        this.visitorTrendOptions = {
          scales: {
            yAxes: [{
              ticks: {
                min: 0,
                max: 5,
                stepSize: 1,
                fontColor: '#000000',
                callback: function (label, index, labels) {
                  switch (label) {
                    case 0:
                      return '0';
                    case 1:
                      return '1';
                    case 2:
                      return '2';
                    case 3:
                      return '3';
                    case 4:
                      return '4';
                    case 5:
                      return '5';
                  }
                }
              },
              scaleLabel: {
                display: true,
                labelString: 'Rating',
                fontColor: '#000000'
              }
            }],
            xAxes: [{
              ticks: {
                fontColor: '#000000'
              }
            }]
          },
          spanGaps: true,
          legend: {
            display: false,
          },
          responsive: false,
          maintainAspectRatio: false,
          // animation: {
          //     onProgress: function(animation) {
          //         progress.value = animation.animationObject.currentStep / animation.animationObject.numSteps;
          //     }
          // }
        }

        var chart = new Chart(ctx, {
          type: 'line',
          options: this.visitorTrendOptions,
          data: this.visitorTrendData
        });

      } else {
        var chart = new Chart(ctx, {
          type: 'line',
          options: {},
          data: {}
        });
      }
      this.loading = false;
    });
  }

  public getVisitorRatingGraph() {
    this.loading = true;
    this.fac.getVisitorRatingGraph({ todayDate: new Date() }).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.visitorRatingData = {
          labels: ['Sun', 'Mon', 'Tue', 'Wed', 'Thr', 'Fri', 'Sat'],
          datasets: [
            {
              label: 'Rating',
              data: rs.data,
              fill: false,
              borderColor: '#fc6180',
              pointBackgroundColor: '#fc6180',
              showLine: false,
              pointBorderWidth: 2,
              pointRadius: 3,
              pointHoverBackgroundColor: '#fc6180',
              pointHoverBorderColor: '#fc6180',
              pointHoverBorderWidth: 4,
              pointHoverRadius: 4
            },
          ]
        }

        this.visitorRatingOptions = {
          scales: {
            yAxes: [{
              ticks: {
                min: 0,
                max: 5,
                stepSize: 1,
                fontColor: '#000000',
                callback: function (label, index, labels) {
                  switch (label) {
                    case 0:
                      return '0';
                    case 1:
                      return '1';
                    case 2:
                      return '2';
                    case 3:
                      return '3';
                    case 4:
                      return '4';
                    case 5:
                      return '5';
                  }
                }
              }
            }],
            xAxes: [{
              ticks: {
                fontColor: '#000000'
              }
            }],
            responsive: true,
            maintainAspectRatio: false,
          },
          legend: {
            display: false,
          }
        }
      } else {
        this.visitorRatingData = {};
        this.visitorRatingOptions = {};
      }
      this.loading = false;
    });

  }

  // List that is going to be actually displayed to user
  public activities = [];
  // No need to call onScroll if full list has already been displayed
  public isFullListDisplayed: boolean = false;

  onScroll() {
    this.body1.page = this.body1.page + 1;
    this.fac.getActivities(this.body1).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        if (this.activities.length <= rs.data.totalLength) {
          this.activities = this.activities.concat(rs.data.smsHistory);
        } else {
          this.isFullListDisplayed = true;
        }
      }
    });
  }

  public getActivities() {
    this.fac.getActivities(this.body1).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        if (this.activities.length <= rs.data.totalLength) {
          this.activities = rs.data.smsHistory;
          this.totalLengthActivities = rs.data.totalLength;
        } else {
          this.isFullListDisplayed = true;
        }
      }
    });
  }

  public getFacilityTodaysChecklist() {
    this.loading = true;
    this.fac.getFacilityTodaysChecklist({ todayDate: new Date() }).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.todaysCheckListExist = true;
        this.todaysCheckList = rs.data;
      } else if (rs.code == this.config.statusCode.notFound) {
        this.todaysCheckListExist = false;
        this.todaysCheckList = {};
      } else {
        this.todaysCheckList = {};
      }
      this.loading = false;
    });
  }

  public updateTodaysCheckList(todaysCheckList) {

    this.fac.updateTodaysCheckList(this.todaysCheckList).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) { } else { }
    });
  }

  support() {
    this.commingsoon = true;
  }

  /*------------------ Listing Elements --------------------*/

  public ngOnInit(): void {
    this.getSuggestion();
    this.selectBottomTab('1');
    this.loader = true;
    this.user = this.storage.get(this.config.token.userKey);
    if (this.user.role == 'employee') {
      var obj = {
        employeeId: this.user.uid,
        userFacId: this.user.userFacId
      }
      this.employee.getEmployeePermissions(obj).subscribe((result) => {
        let rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.permissionData = rs.data;
        }
      })

    }


    if (this.storage.get(this.config.storage.KIOSK_MODE) == true) {
      this.kioskMode = true;
      // this.toaster.success("Visitor Kiosk Mode On.");
      this.router.navigate(['/facility/visitorKiosk']);
    } else {
      this.kioskMode = false;
    }
    this.visitorTrendData = {};
    this.visitorTrendOptions = {};
    this.body1 = {
      'page': 1
    }
    this.visitorCount();
    this.getAllVisitors();
    this.getActivities();
    this.linkTracking();
    this.latestResponse();
    this.latestNegativeRatings();
    this.latestPositiveRatings();
    this.getAllRatingResponseCount();
    this.getAllMessageCount();
    this.getClickTrackerCounts();
    this.getAllResponseRate();
    this.getVisitorRatingGraph();
    this.getFacilityTodaysChecklist();
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);

    this.getSaveNotes();
  }

  ngAfterViewInit() {
    const _self = this;
    setTimeout(() => {
      if (_self.user.role == 'employee' && _self.permissionData.dashboard.visitorTrendsGraph == true && _self.kioskMode == false || _self.user.role == 'facility_admin') {
        _self.getVisitorTrends();
      }
    }, 1000);

    // $.getMultiScripts = function (arr, path) {
    //   var _arr = $.map(arr, function (scr) {
    //       return $.getScript((path || "") + scr);
    //   });

    //   _arr.push($.Deferred(function (deferred) {
    //       $(deferred.resolve);
    //   }));

    //     return $.when.apply($, _arr);
    // }

    // var script_arr = [
    //     'custom.js'
    // ];

    // $.getMultiScripts(script_arr, 'assets/js/').done(function () {
    //     // all scripts loaded
    // });
  }



  //follwing function is used to save notes

  inputChangedPromise;
  public onChangeSaveNotes() {
    console.log("babsabsas!!!!");
    this.saved = false;
    this.saving = true;
    this.loading = true;

    if (this.inputChangedPromise) {
      console.log("clear out")
      clearTimeout(this.inputChangedPromise);
    }


    this.inputChangedPromise = setTimeout(
      ((saveNote) => {
        if (this.saveNote != undefined && this.saveNote != null) {
          var data = {
            notes: this.saveNote
          }
          this.fac.saveNotes(data).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
              this.saving = false;
              this.saved = true;
              this.getSaveNotes();
            } else {
              this.toaster.error(rs.message);
            }
            this.loading = false;
          });
        } else {
          //console.log("Chief complaint is blank");
        }
      }
      ), 2000)

  }

  //follwing function is used to save notes

  public getSaveNotes() {
    this.loading = true;
    this.fac.getNotesDetails().subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        if(rs.data.notesDetails[0] !=undefined || rs.data.notesDetails[0] !=null || rs.data.notesDetails[0] !=''){
          this.saveNote = rs.data.notesDetails[0].notes;
        }else{
          this.saveNote  = '';
        }
        if (this.saveNote != '') {
          this.noteCount = "1"
        } else {
          this.noteCount = "0"
        }
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  //follwing function is used to get Suggestion

  public getSuggestion() {
    this.loading = true;
    this.fac.getSuggestionDetails().subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.suggestionList = rs.data.suggestionDetails;
        this.count = rs.data.suggestionCount;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }
  //follwing function is used to change Suggestion status

  public selectSuggestion(id, data) {

    this.loading = true;
    if (data == 1) {
      var postData = {
        "_id": id,
        "iDidThis": false,
        "RemoveThis": true,
      };
    } else {
      var postData = {
        "_id": id,
        "iDidThis": true,
        "RemoveThis": false,
      };
    }
    this.fac.changeSuggestionStatus(postData).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.getSuggestion();
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

}





