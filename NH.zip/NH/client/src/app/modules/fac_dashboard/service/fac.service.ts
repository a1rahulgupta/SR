import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from "../../../core/utility/http.client";


@Injectable()
export class FacService {
  constructor(
    private http: HttpClient
  ) { }

  getAllVisitorsDashboard(data: any): Observable<any> {
    return this.http.post('/visitor/getAllVisitorsDashboard', data);
  }
  visitorCount(data: any): Observable<any> {
    return this.http.post('/visitor/visitorCount', data);
  }
  latestResponse(data: any): Observable<any> {
    return this.http.get('/visitor/latestResponse', data);
  }
  latestNegativeRatings(data: any): Observable<any> {
    return this.http.get('/visitor/latestNegativeRatings', data);
  }
  latestPositiveRatings(data: any): Observable<any> {
    return this.http.get('/visitor/latestPositiveRatings', data);
  }
  linkTracking(data: any): Observable<any> {
    return this.http.get('/visitor/linkTracking', data);
  }
  getAllRatingResponseCount(data: any): Observable<any> {
    return this.http.post('/visitor/getAllRatingResponseCount', data);
  }
  getClickTrackerCounts(data: any): Observable<any> {
    return this.http.post('/visitor/getClickTrackerCounts', data);
  }
  getAllMessageCount(data: any): Observable<any> {
    return this.http.post('/visitor/getAllMessageCount', data);
  }
  getAllResponseRate(data: any): Observable<any> {
    return this.http.post('/visitor/getAllResponseRate', data);
  }
  getVisitorTrends(data: any): Observable<any> {
    return this.http.post('/feedback/getVisitorTrends', data);
  }
  getVisitorRatingGraph(data: any): Observable<any> {
    return this.http.post('/feedback/getVisitorRatingGraph', data);
  }
  getActivities(data: any): Observable<any> {
    return this.http.post('/feedback/getActivities', data);
  }
  getFacilityTodaysChecklist(data: any): Observable<any> {
    return this.http.post('/facility/getFacilityTodaysChecklist', data);
  }
  updateTodaysCheckList(data: any): Observable<any> {
    return this.http.post('/facility/updateTodaysCheckList', data);
  }
  saveNotes(data: any): Observable<any> {

    return this.http.post('/facility/saveFacilityNotes', data);
  }

  getNotesDetails(): Observable<any> {
    return this.http.get('/facility/getNotesDetails', '');
  }

  getSuggestionDetails(): Observable<any> {
    return this.http.get('/feedback/getSuggestion', '');
  }

  changeSuggestionStatus(data): Observable<any> {
    return this.http.post('/feedback/updateSuggestion', data);
  }
}
