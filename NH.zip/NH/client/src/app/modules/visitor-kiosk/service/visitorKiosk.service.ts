import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from "../../../core/utility/http.client";


@Injectable()
export class VisitorKioskService {
  constructor(
    private http: HttpClient
  ) { }

  getFacilityLogo(data: any): Observable<any> {
    return this.http.get('/feedback/getFacilityLogo', data);
  }
  getVisitorData(data: any): Observable<any> {
    return this.http.get('/feedback/getVisitorData', data);
  }
  visitorCheckIn(data: any): Observable<any> {
    return this.http.post('/feedback/visitorCheckIn', data);
  }
  visitorCheckOut(data: any): Observable<any> {
    return this.http.post('/feedback/visitorCheckOut', data);
  }
  addVisitedInfo(data: any): Observable<any> {
    return this.http.post('/feedback/addVisitedInfo', data);
  }
  addVisitedInfoById(data: any): Observable<any> {
    return this.http.post('/feedback/addVisitedInfoById', data);
  }
  logoutKioskMode(data: any): Observable<any> {
    return this.http.post('/feedback/logoutKioskMode', data);
  }
  addVisitorDetail(data: any): Observable<any> {
    return this.http.post('/feedback/addVisitedInfo', data);
  }
  addResidentAndCheckedIn(data: any): Observable<any> {
    return this.http.post('/feedback/addResidentAndCheckedIn', data);
  }
  addResidentAndCheckedOut(data: any): Observable<any> {
    return this.http.post('/feedback/addResidentAndCheckedOut', data);
  }
}
