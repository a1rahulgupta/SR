import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
    PaginationModule
} from 'ngx-bootstrap';
import {
    ConfirmDialogModule,
    ConfirmationService,
    DialogModule
} from 'primeng/primeng';

import { AddVisitorInfoComponent } from "./components/addVisitorInfo.component";
import { VisitorCheckInComponent } from "./components/visitorCheckIn.component";
import { VisitorCheckOutComponent } from "./components/visitorCheckOut.component";
import { VisitorKoiskComponent } from "./visitorKiosk.component";
import { VisitorKioskDashboardComponent } from "./components/visitorKioskDashboard.component";
import { VisitorKioskRoutingModule } from "./visitorKiosk-routing.module";
import { GoodByeAndAppMessageComponent } from "./components/goodByeAndAppMessage.component";
import { ExpressResidentDashboardComponent } from "./components/expressResidentDashboard.component";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PaginationModule.forRoot(),
        ConfirmDialogModule,
        VisitorKioskRoutingModule,
        DialogModule,
    ],
    declarations: [
        VisitorKoiskComponent,
        AddVisitorInfoComponent,
        VisitorKioskDashboardComponent,
        VisitorCheckOutComponent,
        VisitorCheckInComponent,
        GoodByeAndAppMessageComponent,
        ExpressResidentDashboardComponent
    ],
    providers: [
        ConfirmationService
    ]
    
})
export class VisitorKioskModule { }