import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";
import { VisitorCheckInComponent } from "./components/visitorCheckIn.component";
import { AddVisitorInfoComponent } from "./components/addVisitorInfo.component";
import { VisitorCheckOutComponent } from "./components/visitorCheckOut.component";
import { VisitorKoiskComponent } from "./visitorKiosk.component";
import { VisitorKioskDashboardComponent } from "./components/visitorKioskDashboard.component";
import { GoodByeAndAppMessageComponent } from "./components/goodByeAndAppMessage.component";
import { ExpressResidentDashboardComponent } from "./components/expressResidentDashboard.component";

const routes: Routes = [
    {
        path: '', 
        component: VisitorKoiskComponent,
        children: [
            {
                path: '',
                component: VisitorKioskDashboardComponent,
            },
            {
                path: 'visitor-checkIn',
                component: VisitorCheckInComponent,
            },
            {
               path: 'visitor-checkOut',
               component: VisitorCheckOutComponent,
            },
            {
                path: 'addVisitorInfo',
                component: AddVisitorInfoComponent,
            },
            {
                path: 'goodByeAndAppMessage',
                component: GoodByeAndAppMessageComponent,
            },
            {
                path: 'expressResidentDashboard',
                component: ExpressResidentDashboardComponent,
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class VisitorKioskRoutingModule {

}