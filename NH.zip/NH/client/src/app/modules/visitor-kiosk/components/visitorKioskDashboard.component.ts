
import { Component,ViewChild ,Input, AfterViewInit} from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { requiredTrim } from "../../../core/validators/validators";
import { WebStorage } from "../../../core/utility/web.storage";
import { VisitorKioskService } from "../service/visitorKiosk.service";
import { Observable } from 'rxjs/Observable';
import { UserService } from "../../../core/services/user.services";
declare var $: any;


@Component({
  selector: 'app-visitor-dashboard',
  preserveWhitespaces: false,
  templateUrl: './view/visitorKioskDashboard.component.html',
  providers: [
    VisitorKioskService,
    UserService
  ]
})
export class VisitorKioskDashboardComponent implements AfterViewInit {
  appSettingObj: any = {
      checkInSms: {
          "status": false,
          "message": ''
      },
      checkInMessageReceivedReplySms: {
          "status": false,
          "message": ''
      },
      checkOutSms: {
          "status": false,
          "message": ''
      },
      positiveRatingSms: {
          "status": false,
          "message": ''
      },
      negativeRatingSms: {
          "status": false,

          "message": ''
      },
      negativeRatingFollowUpSms: {
          "status": false,
          "message": ''
      },
      footerMessage: {
          "status": false,
          "message": ''
      },
      welcomeMessage: {
          "status": false,
          "greeting": '',
          "message": ''
      },
      goodbyeMessage: {
          "status": false,
          "greeting": '',
          "message": ''
      },
      checkInSmsInterval: {
          "status": false,
          "minutes": '',
          "period": ''
      },
      checkOutSmsInterval: {
          "status": false,
          "minutes": '',
          "period": ''
      },
      googleRatingSmsInterval: {
          "status": false,
          "minutes": '',
          "period": ''
      },
      smsLimits: {
          "status": false,
          "globalLimit": '',
          "dailyLimit": '',
          "weeklyLimit": '',
          "monthlyLimit": '',
      },
      alerts: {
          "status": false,
          "phoneNumber": '',
          "emailsArray": []
      },
      api: false

  };
  notificationSettingObj: any = {
      openIncident: {
          "status": false,
          "period": '',
          "phoneNumber": '',
          "emailsArray": []
      },
      updateResolvedIncident: {
          "status": false,
          "phoneNumber": '',
          "emailsArray": []
      },

  };

  smsSettingObj: any = {
      "disableAutoReply": false,
      saturday: {
          "message": "",
          "status": false
      },
      friday: {
          "message": "",
          "status": false
      },
      thursday: {
          "message": "",
          "status": false
      },
      wednesday: {
          "message": "",
          "status": false
      },
      tuesday: {
          "message": "",
          "status": false
      },
      monday: {
          "message": "",
          "status": false
      },
      sunday: {
          "message": "",
          "status": false
      },
  };
  ratingResponseObj: any = {
      positive: {
          "from": 4,
          "to": 5,
          "autoResponse": '',
          "sendAlerts": true,
          "addReviewLink": true,
      },
      neutral: {
          "from": 3,
          "to": 3,
          "autoResponse": '',
          "sendAlerts": true,
          "addReviewLink": true,
      },
      negative: {
          "from": 1,
          "to": 2,
          "autoResponse": '',
          "sendAlerts": true
      },
  }
  iconurl: any;
  weatherName: any;
  facTemp: any;
  facName: any;
  commingsoon: boolean;
  appMessageData: any;
  message: any;
  MessageViewDialoge: boolean;
  kioskModeFile: boolean;
  kioskMode: boolean;
  time: Date;
  prevNowPlaying: any;
  currentdate: Date;
  imagePath: string;
  getLogo: any;
  user: any;
  loading: boolean;
  public httpCall: any = false;

  range = [];
  marked = -1;
  constructor(
    private toaster: ToastrService,
    private visitorKioskService: VisitorKioskService,
    private UserService: UserService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private utills: Utills,
    private config: AppConfig,
    private storage: WebStorage
  ) {

    
  }

  public support() {
    this.commingsoon = true;
  }
  
  public getSettingsStatus(selectType) {
    this.UserService.getSettingsStatus({ selectType: selectType }).subscribe((result) => {
        let rs = result.json();
        if (rs.code == this.config.statusCode.success) {
            if (rs.data.checkInSms) {
                this.appSettingObj = rs.data;
            } else if (rs.data.sunday) {
                this.smsSettingObj = rs.data;
            } else if (rs.data.positive != null) {
                this.ratingResponseObj = rs.data;
            } else if (rs.data.openIncident != null) {
                this.notificationSettingObj = rs.data;
            }
        } else {
            this.toaster.error(rs.message);
        }
    });
  }

  ngOnInit() {  
    if(this.storage.get(this.config.storage.KIOSK_MODE)==false){
      this.kioskMode = false;
      this.toaster.success("Visitor Kiosk Mode Off.");
      this.router.navigate(['/facility/dashboard']);
    }
    else{
      this.kioskMode = true;
    }
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
    this.user = this.storage.get(this.config.token.userKey);
    var facId = this.user.facId;
    this.visitorKioskService.getFacilityLogo({ id: facId }).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.imagePath = 'assets/upload/profiles/' + rs.data.data.facLogo;
        this.facName = rs.data.data.facName;
        this.facTemp = rs.data.temp;
        this.weatherName = rs.data.weatherName;
        this.iconurl = rs.data.iconurl;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
    this.getMessageData();
    this.getSettingsStatus('appSettings');  
  }



        getMessageData(){
          let getData = JSON.parse(localStorage.getItem("getDataItem"));
        if(getData != null && getData != undefined && getData != ''){
            var messagePop = getData.isAppMessagePopUp;
        if(messagePop == true){
          this.MessageViewDialoge = true;
          this.appMessageData = getData.appMessage;
          this.message = getData.message;
          this.removeModel();
        }else{
            this.MessageViewDialoge = false;
          } 
    }
  }
  removeModel(){
     setTimeout(()=>{    
         this.MessageViewDialoge = false;
         let getData = localStorage.removeItem("getDataItem");
      }, 10000);
  }
  public logoutKioskMode(password: string) {
    var body = {
      password: password
    }
    this.visitorKioskService.logoutKioskMode(body).subscribe((result: any) => {
      this.httpCall = false;
      var rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.toaster.success(rs.message);
        this.kioskMode = false;
        this.kioskModeFile = true;
        this.storage.localStore(this.config.storage.KIOSK_MODE, this.kioskMode);
        this.storage.localStore(this.config.storage.KIOSK_MODE_FILE, this.kioskModeFile);
        location.reload();
        // this.router.navigate(['/facility/visitorKiosk']);
      } else {
        this.toaster.error(rs.message);
      }
    });

  }
     ngAfterViewInit() {
        $.getMultiScripts = function(arr, path) {
            var _arr = $.map(arr, function(scr) {
                return $.getScript( (path||"") + scr );
            });

            _arr.push($.Deferred(function( deferred ){
                $( deferred.resolve );
            }));

            return $.when.apply($, _arr);
        }

        var script_arr = [
            'materialize.min.js', 
            'core/libraries/bootstrap.min.js',
            'plugins/visualization/d3/d3.min.js',
            'plugins/visualization/d3/d3_tooltip.js',
            'plugins/forms/styling/switchery.min.js',
            'plugins/forms/styling/uniform.min.js',
            'plugins/forms/selects/bootstrap_multiselect.js',
            'plugins/ui/moment/moment.min.js',
            'plugins/pickers/daterangepicker.js',
            'core/app.js',
            'plugins/ui/ripple.min.js',
            'custom.js'
        ];
        
        $.getMultiScripts(script_arr, 'assets/js/').done(function() {
            // all scripts loaded
        });
    }


}

// 