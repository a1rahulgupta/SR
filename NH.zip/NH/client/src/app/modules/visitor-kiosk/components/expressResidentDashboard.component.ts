
import { Component,ViewChild ,Input } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { requiredTrim } from "../../../core/validators/validators";
import { WebStorage } from "../../../core/utility/web.storage";
import { VisitorKioskService } from "../service/visitorKiosk.service";
import { Observable } from 'rxjs/Observable';
import { UserService } from "../../../core/services/user.services";
declare var $: any;


@Component({
  selector: 'express-resident-dashboard',
  preserveWhitespaces: false,
  templateUrl: './view/expressResidentDashboard.component.html',
  providers: [
    VisitorKioskService,
    UserService
  ]
})
export class ExpressResidentDashboardComponent {
    showExpressCheckOutModal: boolean = false;
    showExpressCheckInModal: boolean = false;
    appSettingObj: any = {
      checkInSms: {
          "status": false,
          "message": ''
      },
      checkInMessageReceivedReplySms: {
          "status": false,
          "message": ''
      },
      checkOutSms: {
          "status": false,
          "message": ''
      },
      positiveRatingSms: {
          "status": false,
          "message": ''
      },
      negativeRatingSms: {
          "status": false,

          "message": ''
      },
      negativeRatingFollowUpSms: {
          "status": false,
          "message": ''
      },
      footerMessage: {
          "status": false,
          "message": ''
      },
      welcomeMessage: {
          "status": false,
          "greeting": '',
          "message": ''
      },
      goodbyeMessage: {
          "status": false,
          "greeting": '',
          "message": ''
      },
      checkInSmsInterval: {
          "status": false,
          "minutes": '',
          "period": ''
      },
      checkOutSmsInterval: {
          "status": false,
          "minutes": '',
          "period": ''
      },
      googleRatingSmsInterval: {
          "status": false,
          "minutes": '',
          "period": ''
      },
      smsLimits: {
          "status": false,
          "globalLimit": '',
          "dailyLimit": '',
          "weeklyLimit": '',
          "monthlyLimit": '',
      },
      alerts: {
          "status": false,
          "phoneNumber": '',
          "emailsArray": []
      },
      api: false

  };
  notificationSettingObj: any = {
      openIncident: {
          "status": false,
          "period": '',
          "phoneNumber": '',
          "emailsArray": []
      },
      updateResolvedIncident: {
          "status": false,
          "phoneNumber": '',
          "emailsArray": []
      },

  };

  smsSettingObj: any = {
      "disableAutoReply": false,
      saturday: {
          "message": "",
          "status": false
      },
      friday: {
          "message": "",
          "status": false
      },
      thursday: {
          "message": "",
          "status": false
      },
      wednesday: {
          "message": "",
          "status": false
      },
      tuesday: {
          "message": "",
          "status": false
      },
      monday: {
          "message": "",
          "status": false
      },
      sunday: {
          "message": "",
          "status": false
      },
  };
  ratingResponseObj: any = {
      positive: {
          "from": 4,
          "to": 5,
          "autoResponse": '',
          "sendAlerts": true,
          "addReviewLink": true,
      },
      neutral: {
          "from": 3,
          "to": 3,
          "autoResponse": '',
          "sendAlerts": true,
          "addReviewLink": true,
      },
      negative: {
          "from": 1,
          "to": 2,
          "autoResponse": '',
          "sendAlerts": true
      },
  }
  iconurl: any;
  weatherName: any;
  facTemp: any;
  facName: any;
  commingsoon: boolean;
  appMessageData: any;
  message: any;
  MessageViewDialoge: boolean;
  time: Date;
  prevNowPlaying: any;
  imagePath: string;
  user: any;
  loading: boolean;
  public addResidentForm: FormGroup;
  public httpCall: any = false;
  
  constructor(
    private toaster: ToastrService,
    private visitorKioskService: VisitorKioskService,
    private UserService: UserService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private utills: Utills,
    private config: AppConfig,
    private storage: WebStorage
  ) {

  }

  public support() {
    this.commingsoon = true;
  }
  
  modalResidentBack() {
    this.showExpressCheckInModal = false;
    this.showExpressCheckOutModal = false;
    this.addResidentForm.reset();
    this.addResidentForm.controls['bed_no'].setValue('');
    this.addResidentForm.controls['first_name'].setValue('');
    this.addResidentForm.controls['last_name'].setValue('');
    this.addResidentForm.controls['room_no'].setValue('');
  }

  public getSettingsStatus(selectType) {
    this.UserService.getSettingsStatus({ selectType: selectType }).subscribe((result) => {
        let rs = result.json();
        if (rs.code == this.config.statusCode.success) {
            if (rs.data.checkInSms) {
                this.appSettingObj = rs.data;
            } else if (rs.data.sunday) {
                this.smsSettingObj = rs.data;
            } else if (rs.data.positive != null) {
                this.ratingResponseObj = rs.data;
            } else if (rs.data.openIncident != null) {
                this.notificationSettingObj = rs.data;
            }
        } else {
            this.toaster.error(rs.message);
        }
    });
  }

  public openExpressCheckIn() {
    this.showExpressCheckInModal = true;
  }

  public openExpressCheckOut(){
    this.showExpressCheckOutModal = true;
  }

  //Function is used to checkin for residential
  expressResidentCheckOut(data) {
    this.httpCall = true;
    var requestdata: any = {};
    requestdata.firstName = data.first_name;
    requestdata.lastName = data.last_name;
    requestdata.room_no = data.room_no;
    requestdata.bed_no = data.bed_no;
    requestdata.userFacilityId = this.user.userFacId;
    requestdata.checkOutDate = new Date();

    if (this.addResidentForm.valid) {
        this.visitorKioskService.addResidentAndCheckedOut(requestdata).subscribe((result) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.toaster.success(rs.message);
                this.showExpressCheckOutModal = false;
                this.addResidentForm.reset();
                this.addResidentForm.controls['bed_no'].setValue('');
                this.addResidentForm.controls['first_name'].setValue('');
                this.addResidentForm.controls['last_name'].setValue('');
                this.addResidentForm.controls['room_no'].setValue('');
                this.router.navigate(['/facility/visitorKiosk']);
            } else {
                this.toaster.error(rs.message);
            }
        });
    } else {
        this.validateAllResidentFields(this.addResidentForm);
    }
  }

  validateAllResidentFields(formGroup: FormGroup) {
    Object.keys(this.addResidentForm.controls).forEach(field => {
        const control = this.addResidentForm.get(field);
        control.markAsTouched({ onlySelf: true });
        control.markAsDirty({ onlySelf: true });
    });
  }

  //Function is used to checkOut for residential
  onSubmitResident(data){
    this.httpCall = true;        
    var requestdata: any = {};
    requestdata.firstName = data.first_name;
    requestdata.lastName = data.last_name;             
    requestdata.room_no = data.room_no;
    requestdata.bed_no = data.bed_no;                
    requestdata.userFacilityId = this.user.userFacId;
    requestdata.checkInDate = new Date();

    if (this.addResidentForm.valid) {
        this.visitorKioskService.addResidentAndCheckedIn(requestdata).subscribe((result) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.toaster.success(rs.message);
                this.showExpressCheckInModal = false;
                this.addResidentForm.reset();
                this.addResidentForm.controls['bed_no'].setValue('');
                this.addResidentForm.controls['first_name'].setValue('');
                this.addResidentForm.controls['last_name'].setValue('');
                this.addResidentForm.controls['room_no'].setValue('');
                this.router.navigate(['/facility/visitorKiosk']);
            } else {
                this.toaster.error(rs.message);
            }
        });
    } else {
        this.validateAllResidentFields(this.addResidentForm);
    }
  }

  ngOnInit() { 
      
    this.addResidentForm = this.formBuilder.group({
        first_name: new FormControl('', [Validators.required]),
        last_name: new FormControl('', [Validators.required]),
        room_no: new FormControl('', [Validators.required]),
        bed_no: new FormControl('', )
    });
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);

    this.user = this.storage.get(this.config.token.userKey);
    var facId = this.user.facId;
    this.visitorKioskService.getFacilityLogo({ id: facId }).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.imagePath = 'assets/upload/profiles/' + rs.data.data.facLogo;
        this.facName = rs.data.data.facName;
        this.facTemp = rs.data.temp;
        this.weatherName = rs.data.weatherName;
        this.iconurl = rs.data.iconurl;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
   
    this.getSettingsStatus('appSettings');  
  }

}
