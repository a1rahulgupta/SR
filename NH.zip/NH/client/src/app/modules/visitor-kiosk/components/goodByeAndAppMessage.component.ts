import { Component, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { requiredTrim } from "../../../core/validators/validators";
import { WebStorage } from "../../../core/utility/web.storage";
import { Observable } from 'rxjs/Observable';
import { VisitorKioskService } from "../service/visitorKiosk.service";
import { Socket } from 'ngx-socket-io';
import { VisitorKioskDashboardComponent } from "./visitorKioskDashboard.component";


@Component({
    selector: 'goodbye-app-message',
    preserveWhitespaces: false,
    templateUrl: './view/goodByeAndAppMessage.component.html',
    providers: [
        VisitorKioskService
    ]
})
export class GoodByeAndAppMessageComponent {
    visitorAppObj: any;
    appSettingObj: any;
    greeting: any;
    getData: void;
    iconurl: any;
    weatherName: any;
    facTemp: any;
    facName: any;
    welcomeMessage: any;

    time: Date;
    prevNowPlaying: any;
    currentdate: Date;
    visitorPhoneNumber: any;
    imagePath: string;
    getCategoryList: any;
    loading: any;
    phoneNumber: any;
    public checkInForm: FormGroup;
    public httpCall: any = false;

    constructor(
        private toaster: ToastrService,
        private VisitorKioskService: VisitorKioskService,
        private router: Router,
        private socket: Socket,
        private activatedRoute: ActivatedRoute,
        private formBuilder: FormBuilder,
        private utills: Utills,
        private storage: WebStorage,
        private config: AppConfig
    ) {
        this.checkInForm = formBuilder.group({
            email: ['', [Validators.pattern(this.config.pattern.EMAIL)]],
            firstName: ['', [requiredTrim]],
            lastName: ['', [requiredTrim]],
            visitedTo: ['', [requiredTrim]],
            phoneNumber: ['', [requiredTrim]],
        });
    }

    changeRoute(){
        setTimeout(()=>{    
            localStorage.removeItem("getDataItem");
            localStorage.removeItem("getVisitorItem");
            this.router.navigate(['/facility/visitorKiosk']);
         }, 10000);
    }

    getMessageData(){
        let getData = JSON.parse(localStorage.getItem("getDataItem"));
        console.log("getData@@@@@@", getData);
        let visitorData = JSON.parse(localStorage.getItem("getVisitorItem"));
        console.log("visitorData@@@@@@", visitorData);        
        if(getData != null && getData != undefined && getData != '' && visitorData != null && getData != undefined && getData != ''){
           this.appSettingObj = getData;  
           this.visitorAppObj = visitorData;
           this.changeRoute() 
        }else{
            this.router.navigate(['/facility/visitorKiosk']);
        }
    }


    ngOnInit() {
        var stationdate = new Date();
        if (this.prevNowPlaying) {
            clearInterval(this.prevNowPlaying);
        }
        this.prevNowPlaying = setInterval(() => {
            stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
            this.time = stationdate;
        }, 1000);
        this.checkInForm.patchValue({
            phoneNumber: this.storage.get(this.config.storage.VISITOR_PHONE),
            visitedTo: this.storage.get(this.config.storage.PATIENT_NAME)
        })
        let user = this.storage.get(this.config.token.userKey);
        var facId = user.facId;
        this.VisitorKioskService.getFacilityLogo({ id: facId }).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
              this.imagePath = 'assets/upload/profiles/' + rs.data.data.facLogo;
              this.facName = rs.data.data.facName;
              this.facTemp = rs.data.temp;
              this.weatherName = rs.data.weatherName;
              this.iconurl = rs.data.iconurl;
            } else {
              this.toaster.error(rs.message);
            }
            this.loading = false;
        });
        this.getMessageData();
    }
    send() {
        let user = this.storage.get(this.config.token.userKey);
        let visitorPhoneNumber = this.storage.get(this.config.storage.VISITOR_PHONE);
        this.httpCall = true;
        var data = this.checkInForm.value;
        data.userFacilityId = user.userFacId;
        data.phoneNumber = visitorPhoneNumber;
        data.checkInDate = new Date();
        this.VisitorKioskService.addVisitedInfo(data).subscribe((result: any) => {
            this.httpCall = false;
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.socket.emit('visitorCheckIn', rs.data);
                var getData = rs.data.visitorData;
                if(getData.isAppMessagePopUp == false){
                    this.toaster.success(rs.message);
                }
                getData.message = rs.message;
                localStorage.setItem("getDataItem",JSON.stringify (getData));
                this.router.navigate(['/facility/visitorKiosk']);
            } else {
                this.toaster.error(rs.message);
            }
        });
    }

}