import { Component, ViewChild, Input } from '@angular/core';
import { Router, ActivatedRoute, Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { requiredTrim } from "../../../core/validators/validators";
import { WebStorage } from "../../../core/utility/web.storage";
import { Observable } from 'rxjs/Observable';
import { VisitorKioskService } from "../service/visitorKiosk.service";
import { Socket } from 'ngx-socket-io';
import { VisitorKioskDashboardComponent } from "./visitorKioskDashboard.component";
import { UserService } from '../../../core/services/user.services';

@Component({
    selector: 'app-visitor-checkIn',
    preserveWhitespaces: false,
    templateUrl: './view/visitorCheckIn.component.html',
    providers: [
        VisitorKioskService,
        UserService
    ]
})
export class VisitorCheckInComponent {
    showExpressCheckInModal: boolean = false;
    appSettingObj: any = {
        checkInSms: {
            "status": false,
            "message": ''
        },
        checkInMessageReceivedReplySms: {
            "status": false,
            "message": ''
        },
        checkOutSms: {
            "status": false,
            "message": ''
        },
        positiveRatingSms: {
            "status": false,
            "message": ''
        },
        negativeRatingSms: {
            "status": false,

            "message": ''
        },
        negativeRatingFollowUpSms: {
            "status": false,
            "message": ''
        },
        footerMessage: {
            "status": false,
            "message": ''
        },
        welcomeMessage: {
            "status": false,
            "greeting": '',
            "message": ''
        },
        goodbyeMessage: {
            "status": false,
            "greeting": '',
            "message": ''
        },
        checkInSmsInterval: {
            "status": false,
            "minutes": '',
            "period": ''
        },
        checkOutSmsInterval: {
            "status": false,
            "minutes": '',
            "period": ''
        },
        googleRatingSmsInterval: {
            "status": false,
            "minutes": '',
            "period": ''
        },
        smsLimits: {
            "status": false,
            "globalLimit": '',
            "dailyLimit": '',
            "weeklyLimit": '',
            "monthlyLimit": '',
        },
        alerts: {
            "status": false,
            "phoneNumber": '',
            "emailsArray": []
        },
        api: false

    };
    notificationSettingObj: any = {
        openIncident: {
            "status": false,
            "period": '',
            "phoneNumber": '',
            "emailsArray": []
        },
        updateResolvedIncident: {
            "status": false,
            "phoneNumber": '',
            "emailsArray": []
        },

    };

    smsSettingObj: any = {
        "disableAutoReply": false,
        saturday: {
            "message": "",
            "status": false
        },
        friday: {
            "message": "",
            "status": false
        },
        thursday: {
            "message": "",
            "status": false
        },
        wednesday: {
            "message": "",
            "status": false
        },
        tuesday: {
            "message": "",
            "status": false
        },
        monday: {
            "message": "",
            "status": false
        },
        sunday: {
            "message": "",
            "status": false
        },
    };
    ratingResponseObj: any = {
        positive: {
            "from": 4,
            "to": 5,
            "autoResponse": '',
            "sendAlerts": true,
            "addReviewLink": true,
        },
        neutral: {
            "from": 3,
            "to": 3,
            "autoResponse": '',
            "sendAlerts": true,
            "addReviewLink": true,
        },
        negative: {
            "from": 1,
            "to": 2,
            "autoResponse": '',
            "sendAlerts": true
        },
    }
    iconurl: any;
    weatherName: any;
    facTemp: any;
    facName: any;
    numberButton1: string = '';
    time: Date;
    prevNowPlaying: any;
    visitedId: any;
    visitorData: any;
    currentdate: Date;
    phoneNumber: any;
    imagePath: string;
    facilityName: string;
    showPatientField: boolean = false;
    showVendorType: boolean = false;
    showFamilyType: boolean = false;
    user: any;
    showAddVisitorModal: boolean = false;
    numberButton: string = '';
    getCategoryList: any;
    loading: any;
    phoneNo: any;
    public addvisitorForm: FormGroup;
    public addResidentForm: FormGroup;
    public httpCall: any = false;

    constructor(
        private toaster: ToastrService,
        private VisitorKioskService: VisitorKioskService,
        private UserService: UserService,
        private router: Router,
        private socket: Socket,
        private activatedRoute: ActivatedRoute,
        private formBuilder: FormBuilder,
        public utills: Utills,
        private storage: WebStorage,
        public config: AppConfig,
        private fb: FormBuilder
    ) {

    }

    validateInput(formgroup: FormGroup) {
        if (formgroup.controls["visitor_type"].value == 'family') {
            formgroup.controls["patient_name"].setValidators([Validators.required]),
            formgroup.controls["relation_type"].setValidators([Validators.required]),
            formgroup.controls["room_no"].setValidators([Validators.required]),
            formgroup.controls["vendor_type"].setValidators([]),
            formgroup.controls["company_name"].setValidators([])

        } else if (formgroup.controls["visitor_type"].value == 'friend' ||
            formgroup.controls["visitor_type"].value == 'poa' ||
            formgroup.controls["visitor_type"].value == 'hcp' ||
            formgroup.controls["visitor_type"].value == 'guardian' ||
            formgroup.controls["visitor_type"].value == 'attorney') {

                formgroup.controls["patient_name"].setValidators([Validators.required]),
                formgroup.controls["relation_type"].setValidators([]),
                formgroup.controls["room_no"].setValidators([Validators.required]),
                formgroup.controls["vendor_type"].setValidators([]),
                formgroup.controls["company_name"].setValidators([])

        } else if (formgroup.controls["visitor_type"].value == 'vendor') {

            formgroup.controls["patient_name"].setValidators([]),
            formgroup.controls["relation_type"].setValidators([]),
            formgroup.controls["room_no"].setValidators([]),
            formgroup.controls["vendor_type"].setValidators([Validators.required]),
            formgroup.controls["company_name"].setValidators([Validators.required])

        }else if (formgroup.controls["visitor_type"].value == 'guest_tour'){
            formgroup.controls["patient_name"].setValidators([]),
            formgroup.controls["relation_type"].setValidators([]),
            formgroup.controls["room_no"].setValidators([]),
            formgroup.controls["vendor_type"].setValidators([]),
            formgroup.controls["company_name"].setValidators([])
        }

    }
    public getSettingsStatus(selectType) {
        this.UserService.getSettingsStatus({ selectType: selectType }).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                if (rs.data.checkInSms) {
                    this.appSettingObj = rs.data;
                } else if (rs.data.sunday) {
                    this.smsSettingObj = rs.data;
                } else if (rs.data.positive != null) {
                    this.ratingResponseObj = rs.data;
                } else if (rs.data.openIncident != null) {
                    this.notificationSettingObj = rs.data;
                }
            } else {
                this.toaster.error(rs.message);
            }
        });
    }

    public openExpressCheckIn() {
        this.showExpressCheckInModal = true;
    }

    ngOnInit() {
        this.addvisitorForm = this.fb.group({
            first_name: new FormControl('', [Validators.required]),
            last_name: new FormControl('', [Validators.required]),
            visitor_type: new FormControl("", [Validators.required]),
            email: new FormControl('', [Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
            patient_name: new FormControl('', ),
            relation_type: new FormControl('', ),
            vendor_type: new FormControl('', ),
            company_name: new FormControl('', ),
            room_no: new FormControl('', ),
            bed_no: new FormControl('', )
        }, {
                validator: (formgroup: FormGroup) => {
                    return this.validateInput(formgroup);
                }
            }
        );

        this.addResidentForm = this.fb.group({
            first_name: new FormControl('', [Validators.required]),
            last_name: new FormControl('', [Validators.required]),
            room_no: new FormControl('', [Validators.required]),
            bed_no: new FormControl('', )
        });

        var stationdate = new Date();
        if (this.prevNowPlaying) {
            clearInterval(this.prevNowPlaying);
        }
        this.prevNowPlaying = setInterval(() => {
            stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
            this.time = stationdate;
        }, 1000);
        this.user = this.storage.get(this.config.token.userKey);
        var facId = this.user.facId;
        this.VisitorKioskService.getFacilityLogo({ id: facId }).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.imagePath = 'assets/upload/profiles/' + rs.data.data.facLogo;
                this.facName = rs.data.data.facName;
                this.facTemp = rs.data.temp;
                this.weatherName = rs.data.weatherName;
                this.iconurl = rs.data.iconurl;
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
        this.getSettingsStatus('appSettings');

    }

    // Function is use to show input fields depend on selected Value from visitor Type dropdown
    onChangeType(data) {
        switch (data) {
            case 'family':
                this.showPatientField = true;
                this.showVendorType = false;
                this.showFamilyType = true;
                this.addvisitorForm.controls['vendor_type'].setValue('');
                this.addvisitorForm.controls['company_name'].setValue('');
                break;
            case 'friend':
                this.showPatientField = true;
                this.showVendorType = false;
                this.showFamilyType = false;
                this.addvisitorForm.controls['vendor_type'].setValue('');
                this.addvisitorForm.controls['relation_type'].setValue('');
                this.addvisitorForm.controls['company_name'].setValue('');
                break;
            case 'poa':
                this.showPatientField = true;
                this.showVendorType = false;
                this.showFamilyType = false;
                this.addvisitorForm.controls['vendor_type'].setValue('');
                this.addvisitorForm.controls['relation_type'].setValue('');
                this.addvisitorForm.controls['company_name'].setValue('');
                break;
            case 'hcp':
                this.showPatientField = true;
                this.showVendorType = false;
                this.showFamilyType = false;
                this.addvisitorForm.controls['vendor_type'].setValue('');
                this.addvisitorForm.controls['relation_type'].setValue('');
                this.addvisitorForm.controls['company_name'].setValue('');
                break;
            case 'guardian':
                this.showPatientField = true;
                this.showVendorType = false;
                this.showFamilyType = false;
                this.addvisitorForm.controls['vendor_type'].setValue('');
                this.addvisitorForm.controls['relation_type'].setValue('');
                this.addvisitorForm.controls['company_name'].setValue('');
                break;
            case 'attorney':
                this.showPatientField = true;
                this.showVendorType = false;
                this.showFamilyType = false;
                this.addvisitorForm.controls['vendor_type'].setValue('');
                this.addvisitorForm.controls['relation_type'].setValue('');
                this.addvisitorForm.controls['company_name'].setValue('');
                break;
            case 'guest_tour':
                this.showPatientField = false;
                this.showVendorType = false;
                this.showFamilyType = false;
                this.addvisitorForm.controls['vendor_type'].setValue('');
                this.addvisitorForm.controls['relation_type'].setValue('');
                this.addvisitorForm.controls['company_name'].setValue('');
                this.addvisitorForm.controls['room_no'].setValue('');
                this.addvisitorForm.controls['bed_no'].setValue('');
                this.addvisitorForm.controls['patient_name'].setValue('');
                break;
            case 'vendor':
                this.showPatientField = false;
                this.showVendorType = true;
                this.showFamilyType = false;
                this.addvisitorForm.controls['relation_type'].setValue('');
                this.addvisitorForm.controls['room_no'].setValue('');
                this.addvisitorForm.controls['bed_no'].setValue('');
                this.addvisitorForm.controls['patient_name'].setValue('');
                break;
        }
    }

    onSubmit(data) {
        this.httpCall = true;
        let user = this.storage.get(this.config.token.userKey);
        let visitorPhoneNumber = this.storage.get(this.config.storage.VISITOR_PHONE);
        data.userFacilityId = user.userFacId;
        var requestdata: any = {};
        requestdata.firstName = data.first_name;
        requestdata.lastName = data.last_name;
        requestdata.visitor_type = data.visitor_type;
        requestdata.email = data.email;
        requestdata.visitedTo = data.patient_name;
        requestdata.phoneNumber = visitorPhoneNumber;
        requestdata.relation_type = data.relation_type;
        requestdata.vendor_type = data.vendor_type;
        requestdata.company_name = data.company_name;
        requestdata.room_no = data.room_no;
        requestdata.bed_no = data.bed_no;
        requestdata.userFacilityId = user.userFacId;
        requestdata.checkInDate = new Date();
        if (this.addvisitorForm.valid) {
            console.log("data on select guest tour", this.addvisitorForm.valid); 
            this.VisitorKioskService.addVisitorDetail(requestdata).subscribe((result) => {
                var rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.socket.emit('visitorCheckIn', rs.data);
                    this.toaster.success(rs.message);
                    var getData = this.appSettingObj;
                    var visitorData = rs.data.visitorData
                    if (this.appSettingObj.welcomeMessage.status == true || visitorData.isAppMessagePopUp == true) {
                        localStorage.setItem("getVisitorItem", JSON.stringify(visitorData));
                        localStorage.setItem("getDataItem", JSON.stringify(getData));
                        this.router.navigate(['/facility/visitorKiosk/addVisitorInfo']);
                    } else {
                        this.router.navigate(['/facility/visitorKiosk']);
                    }
                } else {
                    this.toaster.error(rs.message);
                }
            });
        } else {
            console.log("else tour", this.addvisitorForm);             
            this.validateAllFormFields(this.addvisitorForm);
        }
    }

    validateAllFormFields(formGroup: FormGroup) {
        Object.keys(this.addvisitorForm.controls).forEach(field => {
            const control = this.addvisitorForm.get(field);
            control.markAsTouched({ onlySelf: true });
            control.markAsDirty({ onlySelf: true });
        });
    }

    getVisitorData() {
        this.VisitorKioskService.getVisitorData({ id: this.visitedId }).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.visitorData = rs.data;
                this.addVisitedInfoById();
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
    }

    addVisitedInfoById() {
        let user = this.storage.get(this.config.token.userKey);
        this.httpCall = true;
        var data = {
            userFacilityId: user.userFacId,
            visitedTo: this.visitorData.visitedTo,
            visitorId: this.visitedId,
            phoneNumber: this.phoneNumber,
            checkInDate: new Date()
        }

        this.VisitorKioskService.addVisitedInfoById(data).subscribe((result: any) => {
            this.httpCall = false;
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.socket.emit('visitorCheckIn', rs.data);
                this.toaster.success(rs.message);
                var getData = this.appSettingObj;
                var visitorData = rs.data.visitorData
                if (this.appSettingObj.welcomeMessage.status == true || visitorData.isAppMessagePopUp == true) {
                    localStorage.setItem("getVisitorItem", JSON.stringify(visitorData));
                    localStorage.setItem("getDataItem", JSON.stringify(getData));
                    this.router.navigate(['/facility/visitorKiosk/addVisitorInfo']);
                } else {
                    this.router.navigate(['/facility/visitorKiosk']);
                }
            } else {
                this.toaster.error(rs.message);
            }
        });
    }

    //function is to get values from key press
    selectNumber(keyPress) {
        this.loading = true;
        this.numberButton1 = this.numberButton1 + keyPress
        if (this.numberButton1.length <= 10) {
            this.numberButton = this.numberButton1
        }
        if (this.numberButton1.length == 10) {
            this.httpCall = true;
            var data = {
                phoneNumber: this.numberButton
            };
            this.VisitorKioskService.visitorCheckIn(data).subscribe((result: any) => {
                this.httpCall = false;
                var rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.loading = false;
                    this.showAddVisitorModal = true;
                    this.storage.localStore(this.config.storage.VISITOR_PHONE, rs.data.phoneNumber);
                } else if (rs.code == this.config.statusCode.continue) {
                    this.visitedId = rs.data._id;
                    this.phoneNumber = rs.data.phoneNumber;
                    this.getVisitorData();
                } else {
                    this.toaster.error(rs.message);
                }
            });
        }
    }

    //function is used used to cancel input 
    cancel() {
        this.numberButton = '';
        this.numberButton1 = '';
    }
    //function is used  to cancel Visitor Modal
    modalBack() {
        this.showAddVisitorModal = false;
        this.numberButton = '';
        this.numberButton1 = '';
        this.addvisitorForm.reset('');
        this.addvisitorForm.controls['bed_no'].setValue('');
        this.addvisitorForm.controls['company_name'].setValue('');
        this.addvisitorForm.controls['email'].setValue('');
        this.addvisitorForm.controls['first_name'].setValue('');
        this.addvisitorForm.controls['last_name'].setValue('');
        this.addvisitorForm.controls['patient_name'].setValue('');
        this.addvisitorForm.controls['relation_type'].setValue('');
        this.addvisitorForm.controls['room_no'].setValue('');
        this.addvisitorForm.controls['vendor_type'].setValue('');
        this.addvisitorForm.controls['visitor_type'].setValue('');

    }

    //function is used to cancel Resident Modal
    modalResidentBack() {
        this.showExpressCheckInModal = false;
        this.numberButton = '';
        this.numberButton1 = '';
        this.addResidentForm.reset();
        this.addResidentForm.controls['bed_no'].setValue('');
        this.addResidentForm.controls['first_name'].setValue('');
        this.addResidentForm.controls['last_name'].setValue('');
        this.addResidentForm.controls['room_no'].setValue('');
    }


    //function is used used to cancel one input 
    cancleOne() {
        this.numberButton = this.numberButton.slice(0, -1);
        this.numberButton1 = this.numberButton1.slice(0, -1);
    }

    //Function is used to checkin for residential
    onSubmitResident(data) {
        this.httpCall = true;
        var requestdata: any = {};
        requestdata.firstName = data.first_name;
        requestdata.lastName = data.last_name;
        requestdata.room_no = data.room_no;
        requestdata.bed_no = data.bed_no;
        requestdata.userFacilityId = this.user.userFacId;
        requestdata.checkInDate = new Date();

        if (this.addResidentForm.valid) {
            this.VisitorKioskService.addResidentAndCheckedIn(requestdata).subscribe((result) => {
                var rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.toaster.success(rs.message);
                    this.router.navigate(['/facility/visitorKiosk']);
                } else {
                    this.toaster.error(rs.message);
                }
            });
        } else {
            this.validateAllResidentFields(this.addResidentForm);
        }
    }


    validateAllResidentFields(formGroup: FormGroup) {
        Object.keys(this.addResidentForm.controls).forEach(field => {
            const control = this.addResidentForm.get(field);
            control.markAsTouched({ onlySelf: true });
            control.markAsDirty({ onlySelf: true });
        });
    }

}