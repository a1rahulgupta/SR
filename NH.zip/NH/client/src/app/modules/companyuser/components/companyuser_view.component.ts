import { Component, OnInit, ViewChild, Output, EventEmitter, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms'
import { Router, ActivatedRoute, Params } from '@angular/router';
import { MessageService } from 'primeng/components/common/messageservice';
import { AppConfig } from './../../../core/config/app.config';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import { CompanyUserService } from '../services/companyuser.services';


@Component({
  selector: 'app-companyuser-view',
  preserveWhitespaces: false,
  templateUrl: './view/companyuser_view.view.html',
  providers: [
    CompanyUserService
  ]
})
export class CompanyUserViewComponent implements OnInit {
  imagePath: any;
  employeeInfo: any;
  type = "password";

  show = false;

  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private companyUser: CompanyUserService,
    private router: Router,
    private confirmationService: ConfirmationService
  ) {

  }

  ngOnInit() {
  }

  getCompanyUserData(getData) {
    this.employeeInfo = getData;
    console.log("this.employeeInfo", this.employeeInfo);
    this.imagePath = 'assets/upload/profiles/' + getData.image;
  }
  toggleShow() {
    this.show = !this.show;
    if (this.show) {
      this.type = "text";
    }
    else {
      this.type = "password";
    }
  }
}




