import { Component, Inject, Output, ViewChild, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import { CompanyUserViewComponent } from './companyuser_view.component';
import { WebStorage } from '../../../core/utility/web.storage';
import { CompanyUserService } from '../services/companyuser.services';
type AOA = Array<Array<any>>;

@Component({
  selector: 'app-companyuser-list',
  preserveWhitespaces: false,
  templateUrl: './view/companyuser_list.view.html',
  styles: [`
  :host >>> .popover {
    color: #FFFFFF;
    background: #000000;
  }
 
`],
  providers: [
    CompanyUserService
  ]
})
export class CompanyUserListComponent {
  companyUserViewDialoge: boolean = false;
  kioskMode: boolean;
  user: any;
  permissionArray: any = {
    employee: {
      "status": false,
      "add": false,
      "edit": false,
      "delete": false,
      "activateDeactivate": false,
      "managePermission": false
    }
  };
  permission: any = {
    visitors: {
      "status": false,
      "edit": false,
      "visitorsList": false,
      "isCheckInAlert": false,
      "isAppMessagePopUp": false,
      "checkInLogList": false,
      "latestNegativeResponseList": false,
      "isSms": false,
      "twilioChat": false,
      "documentIncident": false,
      "stickyNote": false
    },
    employee: {
      "status": false,
      "list": false,
      "add": false,
      "edit": false,
      "delete": false,
      "activateDeactivate": false,
      "managePermission": false
    },
    kiosk: {
      "status": false,
      "visitorKiosk": false,
      "patientKiosk": false
    },
    newsFeed: {
      "status": false,
      "list": false,
      "save": false,
      "remove": false
    },
    dashboard: {
      "status": false,
      "totalVisitorsCount": false,
      "positiveRatingsCount": false,
      "negativeRatingsCount": false,
      "smsMessageCount": false,
      "clickTrackerSection": false,
      "todayChackList": false,
      "latestNegativeResponse": false,
      "latestPositiveRatings": false,
      "latestNegativeRatings": false,
      "visitorTrendsGraph": false,
      "visitorRatingGraph": false,
      "message": false,
      "responseRate": false,
      "linkTracking": false,
      "latestVisitorsList": false,
      "overallRatingGraph": false
    },
    incidentClaimReports: {
      "status": false,
      "allReports": false,
      "myReports": false

    },
    settings: {
      "status": false,
      "serviceStatus": false,
      "appSettings": false,
      "smsSettings": false,
      "ratingAndResponseSettings": false
    },
    googleLink: {
      "status": false,
      "viewGoogleLink": false
    }
  };
  permissionDialog: boolean;
  commingsoon: boolean;
  time: Date;
  prevNowPlaying: any;
  display: boolean;
  facilityViewDialoge: boolean;
  @ViewChild('CompanyUserViewComponent')
  private CompanyUserViewComponent: CompanyUserViewComponent;


  public listData: any = [];
  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private companyUser: CompanyUserService,
    private storage: WebStorage,
    private router: Router,
    private utills: Utills,
    private tmpStorage: TmpStorage,
    private confirmationService: ConfirmationService,

  ) {
  }

  /*------------------ Listing Elements --------------------*/
  public asc: string = 'asc';
  public loading: boolean = true;
  public exportfile: string = '';
  public totalItems: number = 0;
  public body: any = {
    'page': 1,
    'count': this.config.perPageDefault,
    'searchText': '',
    'phoneNumber': '',
    'userName': '',
    'createdAt': '',
    'sorting': 'createdAt',
    'order': 'asc',
  };

  public setRecordPerPage(records: number): void {
    this.body.page = 1;
    this.body.limit = records;
    this.getAllCompanyUsersList();
  }


  public sort(field: string, order: any): void {
    if (order == 'asc') {
      this.asc = 'asc';
    } else {
      this.asc = 'desc';
    }
    this.body.sorting = field;
    this.body.order = order;
    this.getAllCompanyUsersList();
  }

  public pageChanged(event: any): void {
    this.body.page = event.page;
    this.getAllCompanyUsersList();
  }

  public resetSearch(): void {
    this.body.userName = '';
    this.body.phoneNumber = '';
    this.body.createdAt = '';
    this.body.email = '';
    this.getAllCompanyUsersList()
  }

  public changePageLimit(pageLimit: any) {
    this.body.limit = pageLimit;
    this.getAllCompanyUsersList()
  }


  public getAllCompanyUsersList() {
    this.loading = true;
    console.log("this.body", this.body);
    this.companyUser.getAllCompanyUsersList(this.body).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.listData = rs.data.data;
        this.totalItems = rs.data.total_count;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }
  /*------------------ Listing Elements --------------------*/

  public remove(_id: string, userCmpId: string) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to delete?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        this.companyUser.deleteCompanyUser({ userId: _id, userCmpId: userCmpId }).subscribe((result) => {
          let rs = result.json();
          if (rs.code == this.config.statusCode.success) {
            this.getAllCompanyUsersList();
            this.toaster.success(rs.message);
          } else {
            this.toaster.error(rs.message);
          }
          this.loading = false;
        });
      },
      reject: () => {
      }
    });
  }
  public enable(userId: string, userCmpId: string, status: string, by: string) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to change status?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var userObj = {
          userId: userId,
          userCmpId: userCmpId,
          status: status,
          by: by
        };
        this.companyUser.activateDeactivateCompanyUser(userObj).subscribe((result) => {
          let rs = result.json();
          if (rs.code == this.config.statusCode.success) {
            this.getAllCompanyUsersList();
            this.toaster.success(rs.message);
          } else {
            this.toaster.error(rs.message);
          }
          this.loading = false;
        });
      },
      reject: () => {
      }
    });
  }

  public exportAll(exportfile) {
    if (exportfile == 'xls') {
      this.exportXls();
    } else if (exportfile == 'json') {
      this.exportJson();
    } else if (exportfile == 'csv') {
      this.createCsvFile();
    } else if (exportfile == 'txt') {
      this.exportTxt();
    } else if (exportfile == 'xml') {
      this.exportXml();
    }
  }
  public showDialog() {
    this.display = true;
  }

  public getEmployeePermissions(employeeData: any) {
    var obj = {
      employeeId: employeeData._id,
      userFacId: employeeData.userFacId
    }
    this.companyUser.getEmployeePermissions(obj).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.permission = rs.data;
        console.log("getEmployeePermissions", rs.data);
        this.permissionDialog = true;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  public updateEmployeePermission(permission) {
    console.log("updateEmployeePermission", permission);
    this.permissionDialog = false;
    this.companyUser.updateEmployeePermission(permission).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.toaster.success(rs.message);
        this.getAllCompanyUsersList();
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }


  public createCsvFile() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to csv file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        var options = {
          fieldSeparator: ',',
          quoteStrings: '"',
          decimalseparator: '.',
          showLabels: true,
          showTitle: true,
          useBom: true
        };
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'User Name': this.listData[i].userName,
            'Phone': this.listData[i].phoneNumber,
            'Created At': this.listData[i].createdAt
          });
        }
        new Angular2Csv(data, 'listData', { headers: Object.keys(data[0]) });
      },
      reject: () => {
      }
    });
  }

  public exportTxt() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to text file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'User Name': this.listData[i].userName,
            'Phone': this.listData[i].phoneNumber,
            'CreatedAt': this.listData[i].createdAt
          });
        }
        var obj = objectToString(data);
        console.log(obj);
        function objectToString(obj) {
          var str = '';
          var i = 0;
          for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
              if (typeof obj[key] == 'object') {
                {
                  str += key + ' : { ' + objectToString(obj[key]) + '} ' + (i > 0 ? ',' : '');
                }
              }
              else {
                str += key + ':\'' + obj[key] + '\'' + (i > 0 ? ',' : '');
              }
              i++;
            }
          }
          return str;
        }
        var textToSave = obj,
          filename = 'file.txt',
          blob = new Blob([textToSave], { type: "text/plain;charset=utf-8" });
        saveAs(blob, filename);
      },
      reject: () => {
      }
    });
  }


  public exportXml() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to Xml file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'id': this.listData[i]._id,
            'column-1': this.listData[i].userName,
            'column-2': this.listData[i].phoneNumber,
            'column-3': this.listData[i].createdAt
          });

        }
        var obj = JSON.stringify(
          {
            "_declaration": {
              "_attributes": {
                "version": "1.0",
                "encoding": "utf-8"
              }
            },
            "tabledata": {
              "field": [
                [],
                "User Name",
                "Phone",
                "Created At"
              ],
              "data": {
                "row": data
              }
            }
          }
        )
        this.companyUser.exportXml(obj).subscribe((result) => {
          let rs = result.json();
          var textToSave = rs.data,
            filename = 'file.xml',
            blob = new Blob([textToSave], { type: "'application/xml charset=utf-8'" });
          saveAs(blob, filename);
        })
      },
      reject: () => {
      }
    });

  }


  public exportJson() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to json file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'User Name': this.listData[i].userName,
            'Phone': this.listData[i].phoneNumber,
            'Created At': this.listData[i].createdAt
          });
        }
        var textToSave = JSON.stringify({ "header": [["User Name", "Phone", "Created At"]], "data": data }),
          filename = 'file.json',
          blob = new Blob([textToSave], { type: "'application/json; charset=utf-8'" });

        saveAs(blob, filename);
      },
      reject: () => {
      }
    });
  }

  public exportXls(): void {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to excel?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        let wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
        let fileName: string = 'User_' + new Date().getTime() + '.xlsx';
        let data: AOA = [
          [
            "User Name",
            "Phone",
            "Created At"
          ]
        ];

        this.listData.map((item: any) => {
          data.push([
            item.userName,
            item.phoneNumber,
            item.createdAt
          ]);
        });

        const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(data);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
        const wbout: ArrayBuffer = XLSX.write(wb, wopts);
        saveAs(new Blob([wbout], { type: 'application/octet-stream' }), fileName);
      },
      reject: () => {
      }
    });
  }

  public viewCompanyUser(companyUserData: any) {
    var getData = companyUserData;
    this.CompanyUserViewComponent.getCompanyUserData(getData);
    this.companyUserViewDialoge = true;
  }

  public support() {
    this.commingsoon = true;
  }

  public ngOnInit(): void {
    this.user = this.storage.get(this.config.token.userKey);
    this.getAllCompanyUsersList();

    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
  }
  
}
