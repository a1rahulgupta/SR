import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '../../../core/utility/http.client';


@Injectable()
export class CompanyUserService {
  constructor(
    private http: HttpClient
  ) { }

  getAllCompanyUsersList(data: any): Observable<any> {
    return this.http.post('/companyUser/getAllCompanyUsersList', data);
  }

  getCompanyUserById(data: any): Observable<any> {
    return this.http.get('/companyUser/getCompanyUserById', data);
  }

  deleteCompanyUser(data: any): Observable<any> {
    return this.http.post('/companyUser/deleteCompanyUser', data);
  }

  activateDeactivateCompanyUser(data: any): Observable<any> {
    return this.http.post('/companyUser/activateDeactivateCompanyUser', data);
  }

  exportXml(data: any): Observable<any> {
    return this.http.post('/company/exportXml', data);
  }
  getEmployeePermissions(data: any): Observable<any> {
    return this.http.post('/employee/getEmployeePermissions', data);
  }
  updateEmployeePermission(data: any): Observable<any> {
    return this.http.post('/employee/updateEmployeePermission', data);
  }

}
