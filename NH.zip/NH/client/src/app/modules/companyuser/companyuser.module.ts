import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
    PaginationModule
} from 'ngx-bootstrap';
import {
    ConfirmDialogModule,
    ConfirmationService,
    DialogModule,
    CalendarModule,
    ProgressSpinnerModule
} from 'primeng/primeng';

import { CompanyUserRoutingModule } from "./../../modules/companyuser/companyuser-routing.module";
import { ImageCropperModule } from 'ngx-image-cropper';
import { DataTableModule } from 'primeng/primeng';
import { MultiSelectModule } from 'primeng/primeng';
import { PopoverModule } from "ngx-popover";
import { CompanyUserViewComponent } from "./components/companyuser_view.component";
import { CompanyUserEditComponent } from "./components/companyuser_edit.component";
import { CompanyUserAddComponent } from "./components/companyuser_add.component";
import { CompanyUserListComponent } from "./components/companyuser_list.component";
import { CompanyUserComponent } from "./companyuser.component";



@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PaginationModule.forRoot(),
        ConfirmDialogModule,
        CompanyUserRoutingModule,
        ImageCropperModule,
        DataTableModule,
        MultiSelectModule,
        ProgressSpinnerModule,
        DialogModule,
        CalendarModule,
        PopoverModule
    ],
    declarations: [
        CompanyUserComponent,
        CompanyUserListComponent,
        CompanyUserAddComponent,
        CompanyUserEditComponent,
        CompanyUserViewComponent
    ],
    providers: [
        ConfirmationService
    ]
})
export class CompanyUserModule { }