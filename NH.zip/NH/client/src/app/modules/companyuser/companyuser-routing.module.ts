import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";

import { CompanyUserComponent } from "./companyuser.component";
import { CompanyUserListComponent } from "./components/companyuser_list.component";
import { CompanyUserAddComponent } from "./components/companyuser_add.component";
import { CompanyUserEditComponent } from "./components/companyuser_edit.component";

const routes: Routes = [
    {
        path: '', 
        component: CompanyUserComponent,
        children: [
            {
                path: '',
                component: CompanyUserListComponent,
            },
            {
                path: 'add',
                component: CompanyUserAddComponent,
            },
            {
                path: 'edit/:id',
                component: CompanyUserEditComponent,
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class CompanyUserRoutingModule {

}