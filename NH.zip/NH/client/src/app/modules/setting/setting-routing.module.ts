import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";
import { SettingEditComponent } from "./components/setting_edit.component";
import { SettingAddComponent } from "./components/setting_add.component";
import { SettingListComponent } from "./components/setting_list.component";
import { SettingComponent } from "./setting.component";
import { GoogleSettingListComponent } from "./components/googleSetting_list.component";
import { GoogleSettingAddComponent } from "./components/googleSetting_add.component";
import { GoogleSettingEditComponent } from "./components/googleSetting_edit.component";



const routes: Routes = [
    {
        path: '', 
        component: SettingComponent,
        children: [
            {
                path: '',
                component: SettingListComponent,
            },
            {
                path: 'add',
                component: SettingAddComponent,
            },
            {
                path: 'edit/:id',
                component: SettingEditComponent,
            },
            {
                path: 'googleList',
                component: GoogleSettingListComponent,
            },
            {
                path: 'googleAdd',
                component: GoogleSettingAddComponent,
            },
            {
                path: 'googleEdit/:id',
                component: GoogleSettingEditComponent,
            },
    
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SettingRoutingModule {

}