import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
    PaginationModule
} from 'ngx-bootstrap';
import {
    ConfirmDialogModule,
    ConfirmationService,
    DialogModule
} from 'primeng/primeng';
import { SettingEditComponent } from "./components/setting_edit.component";
import { SettingListComponent } from "./components/setting_list.component";
import { SettingComponent } from "./setting.component";
import { SettingRoutingModule } from "./setting-routing.module";
import { SettingAddComponent } from "./components/setting_add.component";
import { SettingViewComponent } from "./components/setting_view.component";
import { GoogleSettingViewComponent } from "./components/googleSetting_view.component";
import { GoogleSettingAddComponent } from "./components/googleSetting_add.component";
import { GoogleSettingEditComponent } from "./components/googleSetting_edit.component";
import { GoogleSettingListComponent } from "./components/googleSetting_list.component";
import { PopoverModule } from "ngx-popover";



@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PaginationModule.forRoot(),
        ConfirmDialogModule,
        SettingRoutingModule,
        DialogModule,
        PopoverModule
    ],
    declarations: [
        SettingComponent,
        SettingListComponent,
        SettingAddComponent,
        SettingEditComponent,
        SettingViewComponent,
        GoogleSettingAddComponent,
        GoogleSettingEditComponent,
        GoogleSettingListComponent,
        GoogleSettingViewComponent
    ],
    providers: [
        ConfirmationService
    ]
})
export class SettingModule { }