import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { SettingService } from "../service/setting.service";
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { TmpStorage } from "../../../core/utility/temp.storage";
import { requiredTrim } from "../../../core/validators/validators";



@Component({
  selector: 'app-googleSetting-edit',
  preserveWhitespaces: false,
  templateUrl: './view/googleSetting_edit.view.html',
  providers: [
    SettingService
  ]
})
export class GoogleSettingEditComponent {
  prevNowPlaying: any;
  time: Date;

  public httpCall: any = false;
  public settingFrm: FormGroup;

  constructor(
    private toaster: ToastrService,
    private setting: SettingService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public config: AppConfig,
    private formBuilder: FormBuilder,
    private utills: Utills,
    private tmpStorage: TmpStorage
  ) {
    this.settingFrm = formBuilder.group({
      client_id: ['', [requiredTrim]],
      client_secret: ['', [requiredTrim]],
      account_title:['', [requiredTrim]]
    });
  }

  public save() {
    this.httpCall = true;
    this.activatedRoute.params.subscribe((param: any) => {
      let data = this.settingFrm.value;
      data._id = param['id'];
      this.setting.updateGoogleCredentials(data).subscribe((result: any) => {
        this.httpCall = false;
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.toaster.success(rs.message);
          this.router.navigate(['admin/setting/googleList']);
        } else {
          this.toaster.error(rs.message);
        }
      });
    });
  }

  public ngOnInit() {
    var stationdate = new Date();
    if (this.prevNowPlaying) {
        clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
        stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
        this.time = stationdate;
    }, 1000);
    this.activatedRoute.params.subscribe((param: any) => {
      this.setting.getGoogleCredentialsById({ id: param['id'] }).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.settingFrm.patchValue(rs.data);
        } else {
          this.toaster.error(rs.message);
          this.router.navigate(['admin/setting/googleList']);
        }
      });
    });
  }

}
