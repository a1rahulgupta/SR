import { Component, Inject, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import { SettingService } from "../service/setting.service";
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { TmpStorage } from "../../../core/utility/temp.storage";
import { requiredTrim } from "../../../core/validators/validators";
import { SettingViewComponent } from "./setting_view.component";

@Component({
  selector: 'app-setting-list',
  preserveWhitespaces: false,
  templateUrl: './view/setting_list.view.html',
  styles: [`
  :host >>> .popover {
    color: #FFFFFF;
    background: #000000;
  
  }
 
`],
  providers: [
    SettingService
  ]
})
export class SettingListComponent {
  prevNowPlaying: any;
  time: Date;
  settingViewDialoge: boolean;
  @ViewChild('SettingViewComponent')
  private SettingViewComponent: SettingViewComponent;

  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private setting: SettingService,
    private router: Router,
    private utills: Utills,
    private tmpStorage: TmpStorage,
    private confirmationService: ConfirmationService
  ) { }

  /*------------------ Listing Elements --------------------*/
  public loading: boolean = true;
  public listData: any = [];
  public totalItems: number = 0;
  public params: any = {
  };

  public getAll() {
    this.loading = true;
    this.setting.getAllSetting(this.params).subscribe((result) => {
      let rs = result.json();
      console.log("data", rs);
      if (rs.code == this.config.statusCode.success) {
        console.log("data", rs.data);
        this.listData = rs.data;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  public viewSetting(settingData: any) {
    var getData = settingData;
    this.SettingViewComponent.getSettingData(getData);
    this.settingViewDialoge = true;
  }
  /*------------------ Listing Elements --------------------*/



  public ngOnInit(): void {
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
    this.getAll();
  }

}
