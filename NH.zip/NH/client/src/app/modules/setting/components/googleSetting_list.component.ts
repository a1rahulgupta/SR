import { Component, Inject, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import { SettingService } from "../service/setting.service";
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { TmpStorage } from "../../../core/utility/temp.storage";
import { requiredTrim } from "../../../core/validators/validators";
import { GoogleSettingViewComponent } from './googleSetting_view.component';

@Component({
  selector: 'app-googleSetting-list',
  preserveWhitespaces: false,
  templateUrl: './view/googleSetting_list.view.html',
  styles: [`
  :host >>> .popover {
    color: #FFFFFF;
    background: #000000;
  
  }
 
`],
  providers: [
    SettingService
  ]
})
export class GoogleSettingListComponent {
    [x: string]: any;
    prevNowPlaying: any;
  time: Date;
  settingViewDialoge: boolean;
  @ViewChild('GoogleSettingViewComponent')
  private GoogleSettingViewComponent: GoogleSettingViewComponent;

  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private setting: SettingService,
    private router: Router,
    private utills: Utills,
    private tmpStorage: TmpStorage,
    private confirmationService: ConfirmationService,
    private activatedRoute: ActivatedRoute,
  ) { }

  /*------------------ Listing Elements --------------------*/
  public loading: boolean = true;
  public listData: any = [];
  public totalItems: number = 0;
  public params: any = {
  };

  public getGoogleCredentials() {
    this.loading = true;
    this.activatedRoute.queryParams.subscribe((queryParams: any) => {
        if(queryParams.code == '' || queryParams.code == null || queryParams.code == undefined){
            this.setting.getGoogleCredentials(this.params).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                  this.listData = rs.data;
                } else {
                  this.toaster.error(rs.message);
                }
                this.loading = false;
            });
        }else{
            this.setting.checkGoogleAuthorizeOAuth({ code: queryParams.code}).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.toaster.success(rs.message);
                } else {
                    this.toaster.error(rs.message);
                }
                this.loading = false;
            });
        }
     
     });
  }

  public viewGoogleCredentials(settingData: any) {
    var getData = settingData;
    this.GoogleSettingViewComponent.getSettingData(getData);
    this.settingViewDialoge = true;
  }
  /*------------------ Listing Elements --------------------*/

  public activateGoogleCredentials(id: any){
    this.loading = true;
    this.setting.activateGoogleCredentials({id: id}).subscribe((result) => {
        let rs = result.json();
        if (rs.code == this.config.statusCode.success) {} else {}
        this.loading = false;
    });
  }

  public ngOnInit(): void {
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
    this.getGoogleCredentials();
  }

}
