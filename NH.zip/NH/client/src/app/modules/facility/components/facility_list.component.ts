import { Component, Inject, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
type AOA = Array<Array<any>>;
import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';
import { FacilityViewComponent } from "./facility_view.component";
import { FacilityService } from '../services/facility.services';
import { WebStorage } from "../../../core/utility/web.storage";
import { AuthService } from "../../../core/services/auth.service";
import { Socket } from 'ngx-socket-io';

@Component({
  selector: 'app-facility-list',
  preserveWhitespaces: false,
  templateUrl: './view/facility_list.view.html',
  styles: [`
  :host >>> .popover {
    color: #FFFFFF;
    background: #000000;
  
  }
 
`],
  providers: [
    FacilityService
  ]
})
export class FacilityListComponent {
  kioskModeFile: boolean;
  kioskMode: boolean;
  isLoggedIn: boolean;
  maxDate: Date;
  minDate: Date;
  time: Date;
  prevNowPlaying: any;
  public user: any;
  display: boolean;
  facilityViewDialoge: boolean;
  closebtn: any;

  @ViewChild('FacilityViewComponent')
  private FacilityViewComponent: FacilityViewComponent;


  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private facility: FacilityService,
    private auth: AuthService,
    private router: Router,
    private utills: Utills,
    private socket: Socket,
    private tmpStorage: TmpStorage,
    private confirmationService: ConfirmationService,
    private storage: WebStorage
  ) { }

  /*------------------ Listing Elements --------------------*/
  public asc: string = 'asc';
  public exportfile: string = '';
  public loading: boolean = true;
  public listData: any = [];
  public totalItems: number = 0;

  public body: any = {
    'page': 1,
    'count': this.config.perPageDefault,
    'searchText': '',
    'facName': '',
    'phoneNumber': '',
    'email': '',
    'userName': '',
    'cmpName': '',
    'createdAt': '',
    'sorting': 'createdAt',
    'order': 'asc',
  };

  public setRecordPerPage(records: number): void {
    this.body.page = 1;
    this.body.count = records;
    this.getAllFacilityList();
  }

  public sort(field: string, order: any): void {
    if (order == 'asc') {
      this.asc = 'asc';
    } else {
      this.asc = 'desc';
    }
    this.body.sorting = field;
    this.body.order = order;
    this.getAllFacilityList();
  }

  public pageChanged(event: any): void {

    this.body.page = event.page;

    this.getAllFacilityList();
  }

  public resetSearch(): void {
    this.body.searchText = '';
    this.body.phoneNumber = '';
    this.body.createdAt = '';
    this.body.userName = '';
    this.body.facName = '';
    this.body.email = '';
    this.getAllFacilityList();
  }

  public changePageLimit(pageLimit: any) {

    this.body.count = parseInt(pageLimit);
    console.log("this.body.count", this.body.count)
    this.getAllFacilityList()
  }

  public getAllFacilityList() {
    this.loading = true;
    console.log("rs.datathis.body", this.body);
    this.facility.getAllFacilityList(this.body).subscribe((result) => {
      let rs = result.json();
      console.log("rs.data****************", rs);
      if (rs.code == this.config.statusCode.success) {
        this.listData = rs.data.data;
        this.totalItems = rs.data.total_count;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }
  /*------------------ Listing Elements --------------------*/

  public remove(id: string, userId: string, userFacId: string) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to delete?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        this.facility.deleteFacility({
          _id: id,
          userId: userId,
          userFacId: userFacId
        }).subscribe((result) => {
          let rs = result.json();
          if (rs.code == this.config.statusCode.success) {
            this.getAllFacilityList();
            this.toaster.success(rs.message);
          } else {
            this.toaster.error(rs.message);
          }
          this.loading = false;
        });
      },
      reject: () => { }
    });
  }

  public enable(id: string, userId: string, userFacId: string, status: string, by: string) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to change status?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var facObj = {
          _id: id,
          userId: userId,
          userFacId: userFacId,
          status: status,
          by: by
        };
        this.facility.activateDeactivateFacility(facObj).subscribe((result) => {
          let rs = result.json();
          if (rs.code == this.config.statusCode.success) {
            this.getAllFacilityList();
            this.toaster.success(rs.message);
          } else {
            this.toaster.error(rs.message);
          }
          this.loading = false;
        });
      },
      reject: () => { }
    });
  }

  public exportAll(exportfile) {
    if (exportfile == 'xls') {
      this.exportXls();
    } else if (exportfile == 'json') {
      this.exportJson();
    } else if (exportfile == 'csv') {
      this.createCsvFile();
    } else if (exportfile == 'txt') {
      this.exportTxt();
    } else if (exportfile == 'xml') {
      this.exportXml();
    }
  }


  public createCsvFile() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to csv file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        var options = {
          fieldSeparator: ',',
          quoteStrings: '"',
          decimalseparator: '.',
          showLabels: true,
          showTitle: true,
          useBom: true
        };
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'Facility Name': this.listData[i].facName,
            'Company Name': this.listData[i].cmpName,
            'User Name': this.listData[i].userName,
            'Phone Number': this.listData[i].phoneNumber,
            'CreatedAt': this.listData[i].createdAt
          });
        }
        new Angular2Csv(data, 'listData', {
          headers: Object.keys(data[0])
        });
      },
      reject: () => { }
    });
  }

  public exportTxt() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to text file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'Facility Name': this.listData[i].facName,
            'Company Name': this.listData[i].cmpName,
            'User Name': this.listData[i].userName,
            'Phone Number': this.listData[i].phoneNumber,
            'CreatedAt': this.listData[i].createdAt
          });
        }
        var obj = objectToString(data);
        console.log(obj);

        function objectToString(obj) {
          var str = '';
          var i = 0;
          for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
              if (typeof obj[key] == 'object') {
                {
                  str += key + ' : { ' + objectToString(obj[key]) + '} ' + (i > 0 ? ',' : '');
                }
              } else {
                str += key + ':\'' + obj[key] + '\'' + (i > 0 ? ',' : '');
              }
              i++;
            }
          }
          return str;
        }
        var textToSave = obj,
          filename = 'file.txt',
          blob = new Blob([textToSave], {
            type: "text/plain;charset=utf-8"
          });
        saveAs(blob, filename);
      },
      reject: () => { }
    });
  }


  public exportXml() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to Xml file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'id': this.listData[i]._id,
            'column-1': this.listData[i].facName,
            'column-2': this.listData[i].cmpName,
            'column-3': this.listData[i].userName,
            'column-4': this.listData[i].phoneNumber,
            'column-5': this.listData[i].createdAt
          });

        }
        var obj = JSON.stringify({
          "_declaration": {
            "_attributes": {
              "version": "1.0",
              "encoding": "utf-8"
            }
          },
          "tabledata": {
            "field": [
              [],
              "Facility Name",
              "Company Name",
              "User Name",
              "Phone Number",
              "Created At"
            ],
            "data": {
              "row": data
            }
          }
        })
        this.facility.exportXml(obj).subscribe((result) => {
          let rs = result.json();
          var textToSave = rs.data,
            filename = 'file.xml',
            blob = new Blob([textToSave], {
              type: "'application/xml charset=utf-8'"
            });
          saveAs(blob, filename);
        })
      },
      reject: () => { }
    });

  }


  public exportJson() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to json file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'Facility Name': this.listData[i].facName,
            'Company Name': this.listData[i].cmpName,
            'User Name': this.listData[i].userName,
            'Phone Number': this.listData[i].phoneNumber,
            'CreatedAt': this.listData[i].createdAt
          });
        }
        var textToSave = JSON.stringify({
          "header": [
            ["Facility Name", "Company Name", "User Name", "Phone Number", "Created At"]
          ],
          "data": data
        }),
          filename = 'file.json',
          blob = new Blob([textToSave], {
            type: "'application/json; charset=utf-8'"
          });

        saveAs(blob, filename);
      },
      reject: () => { }
    });
  }

  public exportXls(): void {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to excel?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        let wopts: XLSX.WritingOptions = {
          bookType: 'xlsx',
          type: 'array'
        };
        let fileName: string = 'facility_' + new Date().getTime() + '.xlsx';
        let data: AOA = [
          [
            "Facility Name",
            "Company Name",
            "User Name",
            "Phone Number",
            "Created At"
          ]
        ];

        this.listData.map((item: any) => {
          data.push([
            item.facName,
            item.cmpName,
            item.userName,
            item.phoneNumber,
            item.createdAt
          ]);
        });

        const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(data);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
        const wbout: ArrayBuffer = XLSX.write(wb, wopts);
        saveAs(new Blob([wbout], {
          type: 'application/octet-stream'
        }), fileName);
      },
      reject: () => { }
    });
  }


  public viewFacility(facilityData: any) {
    var getData = facilityData;
    this.FacilityViewComponent.getFacilityData(getData);
    this.facilityViewDialoge = true;
  }
  showDialog() {
    this.display = true;
  }

  public ngOnInit(): void {
    this.user = this.storage.get(this.config.token.userKey);
    this.getAllFacilityList();
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
    let today = new Date();
    let month = today.getMonth();
    let year = today.getFullYear();
    let prevMonth = (month === 0) ? 11 : month - 1;
    let prevYear = (prevMonth === 11) ? year - 1 : year;
    let nextMonth = (month === 11) ? 0 : month + 1;
    let nextYear = (nextMonth === 0) ? year + 1 : year;
    this.minDate = new Date();
    this.minDate.setMonth(nextMonth);
    this.minDate.setFullYear(year);
    this.maxDate = new Date();
    this.maxDate.setMonth(nextMonth);
    this.maxDate.setFullYear(nextYear);
  }

  onCellClick(id) {
    this.facility.getLoginDetails({
      id: id
    }).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.badRequest || rs.code == this.config.statusCode.notFound || rs.code == this.config.statusCode.error || rs.code == this.config.statusCode.unauthorized) {
        this.isLoggedIn = false;
        this.kioskMode = false;
        this.kioskModeFile = false;
      } else {
        this.storage.clear(this.config.token.keyID);
        this.storage.clear(this.config.token.userKey);
        this.storage.clear(this.config.token.subLoginKey);
        this.storage.clear(this.config.storage.VISITOR_PHONE);
        this.storage.clear(this.config.storage.VISITOR_ID);
        this.storage.clear(this.config.storage.KIOSK_MODE);
        this.storage.clear(this.config.storage.KIOSK_MODE_FILE);
        this.storage.clear(this.config.storage.EMAIL);
        this.storage.clear(this.config.storage.PASSWORD);
        this.storage.clear(this.config.storage.SWITCH);
        this.isLoggedIn = true;
        this.kioskMode = false;
        this.kioskModeFile = false;
        this.storage.localStore(this.config.storage.KIOSK_MODE, this.kioskMode);
        this.storage.localStore(this.config.storage.KIOSK_MODE_FILE, this.kioskModeFile);
        this.storage.sessionStore(this.config.token.keyID, rs.data.token);
        this.storage.localStore(this.config.token.userKey, rs.data.user);
        this.storage.localStore(this.config.token.subLoginKey, rs.data.sublogin);
        this.socket.emit('adduser', rs.data, function () {
          // alert("here")
        });
        this.router.navigate(['facility']);
        this.toaster.success(rs.message);
      }
    });
  }

}
