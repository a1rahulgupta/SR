
import { Component, ViewChild, NgZone, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';
import { WebStorage } from './../../../core/utility/web.storage';
import { requiredTrim } from "./../../../core/validators/validators";
import { FacilityService } from '../services/facility.services';
import { CompanyService } from '../../company/services/company.services';
import { AgmCoreModule, MapsAPILoader } from '@agm/core';
import { } from '@types/googlemaps';
declare var jQuery: any;
declare var $: any;
declare var google: any;



@Component({
  selector: 'app-facility-add',
  preserveWhitespaces: false,
  templateUrl: './view/facility_add.view.html',
  providers: [
    FacilityService,
    CompanyService
  ]
})
export class FacilityAddComponent {
  display: boolean = false;
  showFileName: boolean = false;
  baseImage: Blob;
  fileNameData: any;
  imageChangedEvent: any = '';
  croppedImage: any = '';
  cropperReady = false;
  addressData: any;
  zipCodeData: any;
  listNumber: any;
  listTwilioNumber: any;
  body: any;
  twilioDialoge: boolean;
  zipCodes: any;
  citytemp: any;
  countryName: any;
  stateCode: any;
  finalState: any;
  cityName: any;
  maxDate: Date;
  minDate: Date;
  time: Date;
  prevNowPlaying: any;
  loading: boolean = false;
  public user: any;
  getCompanyList: any;
  phoneNumber: any;
  public searchControl: FormControl;
  public httpCall: any = false;
  public logoSelected: any = true;
  public facilityFrm: FormGroup;
  @ViewChild("search")
  public searchElementRef: ElementRef;

  constructor(
    private toaster: ToastrService,
    private Facility: FacilityService,
    private Company: CompanyService,
    private mapsAPILoader: MapsAPILoader,
    private ngZone: NgZone,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public config: AppConfig,
    private formBuilder: FormBuilder,
    public utills: Utills,
    private tmpStorage: TmpStorage,
    private storage: WebStorage
  ) {
    this.facilityFrm = formBuilder.group({
      facName: ['', [requiredTrim]],
      userCmpId: [''],
      firstName: ['', [requiredTrim]],
      lastName: ['', [requiredTrim]],
      email: ['', [requiredTrim, Validators.pattern(this.config.pattern.EMAIL)]],
      country_code: ['+1', [requiredTrim]],
      filename: [{ value: '', disabled: true }],
      phoneNumber: ['', [requiredTrim, Validators.minLength(10), Validators.maxLength(10)]],
      address: ['', [requiredTrim]],
      city: ['', [requiredTrim]],
      state: ['', [requiredTrim]],
      zipCode: ['', [requiredTrim, Validators.minLength(3), Validators.maxLength(5)]],
      country: ['', [requiredTrim]],
      twilioTollFreeNumber: ['', [requiredTrim]],
      // twilioTollFreeNumber: [''],
      googleLink: ['', [requiredTrim]]
    });
  }
  fileChangeEvent(event: any): void {
    this.display = true;
    this.imageChangedEvent = event;
    let fileName = event.target.files[0];
    this.fileNameData = fileName.name;
  }
  imageLoaded() {
    this.cropperReady = true;
  }
  loadImageFailed() {
    this.display = false;
    this.toaster.error("You can upload only .jpg, .jpeg, .png file");
  }

  selectImage(action: any) {
    if (action == true) {
      this.imageLoaded();
      this.display = false;
    } else {
      this.display = false;
    }
  }

  public imageCropped(fileData: any) {
    this.croppedImage = fileData;
    let fileName = this.fileNameData;
    this.baseImage = this.utills.dataURItoBlob(fileData);
    let file = this.baseImage;
    let alowedSize = 1024 * 1024 * this.config.MaxUploadSixe;
    if (this.config.alowedFiletypes.indexOf(file.type) >= 0) {
      if (file.size <= alowedSize) {
        this.showFileName = true;
        this.facilityFrm.controls['filename'].patchValue(fileName);
      } else {
        this.toaster.error("Please select a file within " + this.config.MaxUploadSixe + "MB");
      }
    } else {
      this.toaster.error("You can upload only .jpg, .jpeg, .png, .gif file");
    }
  }

  public save(fileData) {
    this.loading = true;
    fileData = this.croppedImage;
    let fileName = this.fileNameData;

    let url = this.config.apiUrl + "/facility/addFacility";
    if (fileData != '') {
      this.baseImage = this.utills.dataURItoBlob(fileData);
      let file = this.baseImage;
      let alowedSize = 1024 * 1024 * this.config.MaxUploadSixe;
      if (this.config.alowedFiletypes.indexOf(file.type) >= 0) {
        if (file.size <= alowedSize) {
          this.httpCall = true;
          this.phoneNumber = this.facilityFrm.value.country_code + this.facilityFrm.value.phoneNumber;
          let formData = new FormData();
          formData.append("file", file, fileName);
          formData.append("facName", this.facilityFrm.value.facName);
          formData.append("userCmpId", this.facilityFrm.value.userCmpId ? this.facilityFrm.value.userCmpId : this.user.userCmpId);
          formData.append("email", this.facilityFrm.value.email);
          formData.append("firstName", this.facilityFrm.value.firstName);
          formData.append("lastName", this.facilityFrm.value.lastName);
          formData.append("phoneNumber", this.phoneNumber);
          formData.append("address", this.facilityFrm.value.address);
          formData.append("city", this.facilityFrm.value.city);
          formData.append("state", this.facilityFrm.value.state);
          formData.append("stateCode", this.stateCode);
          formData.append("googleLink", this.facilityFrm.value.googleLink);
          formData.append("zipCode", this.facilityFrm.value.zipCode);
          formData.append("country", this.facilityFrm.value.country);
          formData.append("twilioTollFreeNumber", this.facilityFrm.value.twilioTollFreeNumber);

          this.xhrRequest(url, formData);
        } else {
          this.toaster.error("Please select a file within " + this.config.MaxUploadSixe + "MB");
        }
      } else {
        this.toaster.error("You can upload only .jpg, .jpeg, .png file");
      }
    } else {
      console.log("fileData----else-----", fileData);

      this.httpCall = true;
      this.phoneNumber = this.facilityFrm.value.country_code + this.facilityFrm.value.phoneNumber;
      let formData = new FormData();
      formData.append("userCmpId", this.facilityFrm.value.userCmpId ? this.facilityFrm.value.userCmpId : this.user.userCmpId);
      formData.append("facName", this.facilityFrm.value.facName);
      formData.append("email", this.facilityFrm.value.email);
      formData.append("firstName", this.facilityFrm.value.firstName);
      formData.append("lastName", this.facilityFrm.value.lastName);
      formData.append("phoneNumber", this.phoneNumber);
      formData.append("address", this.facilityFrm.value.address);
      formData.append("city", this.facilityFrm.value.city);
      formData.append("state", this.facilityFrm.value.state);
      formData.append("googleLink", this.facilityFrm.value.googleLink);
      formData.append("stateCode", this.stateCode);
      formData.append("zipCode", this.facilityFrm.value.zipCode);
      formData.append("country", this.facilityFrm.value.country);
      formData.append("twilioTollFreeNumber", this.facilityFrm.value.twilioTollFreeNumber);

      this.xhrRequest(url, formData);
    }
  }

  private xhrRequest(url, formData) {
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          this.loading = false;
          this.httpCall = false;
          let rs = JSON.parse(xhr.response);
          if (rs.code == this.config.statusCode.success) {
            this.toaster.success(rs.message);
            if (this.user.role == 'super_admin') {
              this.router.navigate(['/admin/facility']);
            } else {
              this.router.navigate(['/company/facility']);
            }
          } else {
            this.toaster.error(rs.message);
          }
        } else {
          this.loading = false;
          this.httpCall = false;
          let rs = JSON.parse(xhr.response);
          if (rs.code == this.config.statusCode.success) {
            this.toaster.success(rs.message);
            if (this.user.role == 'super_admin') {
              this.router.navigate(['/admin/facility']);
            } else {
              this.router.navigate(['/company/facility']);
            }
          } else {
            this.toaster.error(rs.message);
          }
        }
      }
    }
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Authorization", "Bearer " + this.storage.get(this.config.token.keyID));
    xhr.send(formData);
  }

  public ngOnInit() {

    this.user = this.storage.get(this.config.token.userKey);
    this.Facility.getCompanyList({}).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.getCompanyList = rs.data;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
    let today = new Date();
    let month = today.getMonth();
    let year = today.getFullYear();
    let prevMonth = (month === 0) ? 11 : month - 1;
    let prevYear = (prevMonth === 11) ? year - 1 : year;
    let nextMonth = (month === 11) ? 0 : month + 1;
    let nextYear = (nextMonth === 0) ? year + 1 : year;
    this.minDate = new Date();
    this.minDate.setMonth(nextMonth);
    this.minDate.setFullYear(year);
    this.maxDate = new Date();
    this.maxDate.setMonth(nextMonth);
    this.maxDate.setFullYear(nextYear);

    this.searchControl = new FormControl();

    console.log("this.searchElementRef", this.searchElementRef);
    //load Places Autocomplete
    this.mapsAPILoader.load().then(() => {
      let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
        // types: ['(cities)'],
        componentRestrictions: { country: "us" }
      });
      autocomplete.addListener("place_changed", () => {
        this.ngZone.run(() => {
          //get the place result
          let place: google.maps.places.PlaceResult = autocomplete.getPlace();
          console.log("place", place);
          //verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }
          const components = place.address_components;
          // console.log(components);
          const street = null;
          var data = [];
          for (let i = 0, component; component = components[i]; i++) {
            var temp = component.long_name;
            data.push({
              city: component.long_name
            })
            this.addressData = place.formatted_address;
            if (component.types[0] === 'country') {
              const country = component.long_name;
              this.countryName = country;
            } else if (component.types[0] === 'administrative_area_level_1') {
              const state = component.long_name;
              this.stateCode = component.short_name;
              this.finalState = state;
              console.log("state", this.finalState);
            } else if ((component.types[0] === 'locality') || (component.types[0] === 'sublocality_level_1')) {
              const city = component.long_name;
              this.cityName = city;
            } else if (component.types[0] === 'postal_code') {
              const zip = component.long_name;
              this.zipCodeData = zip;
            }
          }
          this.facilityFrm.controls['state'].patchValue(this.finalState);
          this.facilityFrm.controls['country'].patchValue(this.countryName);
          this.facilityFrm.controls['city'].patchValue(this.cityName);
          this.facilityFrm.controls['zipCode'].patchValue(this.zipCodeData);
          this.facilityFrm.controls['address'].patchValue(this.addressData);
        });
      });
    });


  }
  public getZipCode(cityName, stateCode) {
    var obj = {
      cityName: this.cityName,
      stateCode: this.stateCode
    }
    this.Company.getZipCode(obj).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.zipCodes = rs.data;
      } else {
        this.toaster.error(rs.message);
        this.zipCodes = [];
      }
    })
  }

  buyNumber(number) {
    console.log("number", number);
    this.facilityFrm.controls['twilioTollFreeNumber'].patchValue(number);
    this.twilioDialoge = false;
  }

  public openTwilioModel() {
    this.Facility.getNumberList({ data: this.body }).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.listTwilioNumber = rs.data;
        this.twilioDialoge = true;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }
}