import { Component, OnInit, ViewChild, Output, EventEmitter, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms'
import { Router, ActivatedRoute, Params } from '@angular/router';
import { MessageService } from 'primeng/components/common/messageservice';
import { AppConfig } from './../../../core/config/app.config';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import { FacilityService } from '../services/facility.services';


@Component({
  selector: 'app-facility-view',
  preserveWhitespaces: false,
  templateUrl: './view/facilityView.view.html',
  providers: [
    FacilityService
  ]
})
export class FacilityViewComponent implements OnInit {
  imagePath: any;
  facilityInfo: any;

  type = "password";

  show = false;

  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private facilityService: FacilityService,
    private router: Router,
    private confirmationService: ConfirmationService
  ) {

  }

  ngOnInit() {
  }

  getFacilityData(getData) {
    this.facilityInfo = getData;
    this.imagePath = 'assets/upload/profiles/' + getData.facLogo;
  }
  toggleShow() {
    this.show = !this.show;
    if (this.show) {
      this.type = "text";
    }
    else {
      this.type = "password";
    }
  }
}




