
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '../../../core/utility/http.client';


@Injectable()
export class FacilityService {
  constructor(
    private http: HttpClient
  ) { }

  //facility start
  getFacilityById(data: any): Observable<any> {
    return this.http.get('/facility/getfacilityById', data);
  }

  getAllFacilityList(data: any): Observable<any> {
    return this.http.post('/facility/getAllfacilityList', data);
  }

  deleteFacility(data: any): Observable<any> {
    return this.http.post('/facility/deletefacility', data);
  }

  activateDeactivateFacility(data: any): Observable<any> {
    return this.http.post('/facility/activateDeactivatefacility', data);
  }
  getCompanyList(data: any): Observable<any> {
    return this.http.get('/company/getCompanyListForFacilityAdmin', data);
  }
  exportXml(data: any): Observable<any> {
    return this.http.post('/company/exportXml', data);
  }
  getNumberList(data: any): Observable<any> {
    return this.http.get('/facility/getNumberList', data);
  }
  getLoginDetails(data: any): Observable<any> {
    return this.http.get('/facility/getLoginDetails', data);
  }

  //facility end

}

