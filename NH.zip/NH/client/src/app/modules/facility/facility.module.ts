import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
    PaginationModule
} from 'ngx-bootstrap';
import {
    ConfirmDialogModule,
    ConfirmationService,
    DialogModule,
    CalendarModule,
    ProgressSpinnerModule
} from 'primeng/primeng';
import { AgmCoreModule } from '@agm/core';
import { FacilityRoutingModule } from "./../../modules/facility/facility-routing.module";
import { FacilityComponent } from "./../../modules/facility/facility.component";
import { FacilityListComponent } from "./../../modules/facility/components/facility_list.component";
import { FacilityAddComponent } from "./../../modules/facility/components/facility_add.component";
import { FacilityEditComponent } from "./../../modules/facility/components/facility_edit.component";
import { FacilityViewComponent } from "./components/facility_view.component";
import { ImageCropperModule } from 'ngx-image-cropper';
import { PopoverModule } from "ngx-popover";
import { SettingModule } from "./../../layout/common/setting.module"


@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PaginationModule.forRoot(),
        AgmCoreModule.forRoot({
            apiKey: 'AIzaSyBF34eGmus7PbNf4Ie-bXnedpvYOENwx1w',
            libraries: ['places']
        }),
        ConfirmDialogModule,
        FacilityRoutingModule,
        ImageCropperModule,
        DialogModule,
        CalendarModule,
        PopoverModule,
        ProgressSpinnerModule,
        SettingModule.forChild()
    ],
    declarations: [
        FacilityComponent,
        FacilityListComponent,
        FacilityAddComponent,
        FacilityEditComponent,
        FacilityViewComponent
    ],
    providers: [
        ConfirmationService
    ]
})
export class FacilityModule { }