import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";

import { FacilityComponent } from "./../../modules/facility/facility.component";
import { FacilityListComponent } from "./../../modules/facility/components/facility_list.component";
import { FacilityAddComponent } from "./../../modules/facility/components/facility_add.component";
import { FacilityEditComponent } from "./../../modules/facility/components/facility_edit.component";

const routes: Routes = [
    {
        path: '', 
        component: FacilityComponent,
        children: [
            {
                path: '',
                component: FacilityListComponent,
            },
            {
                path: 'add',
                component: FacilityAddComponent,
            },
            {
                path: 'edit/:id',
                component: FacilityEditComponent,
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class FacilityRoutingModule {

}