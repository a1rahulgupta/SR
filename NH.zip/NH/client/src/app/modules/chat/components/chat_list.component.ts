import { Input, Output, EventEmitter, Component, ViewChild, AfterViewInit, ElementRef } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { requiredTrim } from "../../../core/validators/validators";
import { WebStorage } from "../../../core/utility/web.storage";
import { ChatService } from "../services/chat.services";
import { Socket } from "ngx-socket-io";
declare var $: any;

@Component({
  selector: 'app-employee_review',
  preserveWhitespaces: false,
  templateUrl: './view/chat_list.view.html',
  providers: [
    ChatService
  ]
})
export class ChatListComponent {
  userListChat: boolean = false;
  chatHistory: boolean = false;
  userSelected: boolean = false;
  user: any;
  message: string = '';
  chatLength: boolean;
  selectedUser: any = {
    user: { _id: null },
    history: []
  };
  kioskMode: boolean;
  time: Date;
  prevNowPlaying: any;
  viewTabIndex: any;
  savedRssFeedlist: any;
  index: any;
  totalItems: any;
  params: any;
  firstTab: number = 0;
  secTab: number = 1;
  rssFeedlist: any;
  rssChannelsList: any;
  public body: any = {
    'page': 1,
    'count': 10
  };
  @ViewChild('messgBx') txtArea: any;
  constructor(
    private chatService: ChatService,
    private router: Router,
    private storage: WebStorage,
    public config: AppConfig,
    private toaster: ToastrService,
    private socket: Socket,
  ) {
    this.socket.on('newChatMessage', (data: any) => {
      console.log('New Message !', data);
      this.getChatHistory(this.selectedUser.user)
    });
  }

  /*------------------ Listing Elements --------------------*/
  public loading: boolean = true;
  public userList: any = [];
  // public changePageLimit(pageLimit: any) {
  //   this.body.count = parseInt(pageLimit);
  //   if (this.viewTabIndex == 1) {
  //     this.getSavedRssFeeds();
  //   } else {
  //     this.getAllRssFeed();
  //   }
  // }

  // public pageChanged(event: any): void {
  //   this.body.page = event.page;
  //   if (this.viewTabIndex == 1) {
  //     this.getSavedRssFeeds();
  //   } else {
  //     this.getAllRssFeed();
  //   }
  // }

  // public getTabViewId(tabIndex) {
  //   this.viewTabIndex = tabIndex;
  //   this.body.page = 1;
  //   this.body.count = 10;
  //   if (this.viewTabIndex == 1) {
  //     this.getSavedRssFeeds();
  //   } else {
  //     this.getAllRssFeed();
  //   }
  // }

  // public getAllRssChannels() {
  //   this.loading = true;
  //   this.rssFeed.getAllRssChannels(this.body).subscribe((result) => {
  //     let rs = result.json();
  //     if (rs.code == this.config.statusCode.success) {
  //       this.rssChannelsList = rs.data;
  //       this.getAllRssFeed();
  //     } else {
  //       this.toaster.error(rs.message);
  //     }
  //     this.loading = false;
  //   });
  // }

  // public getAllRssFeed() {
  //   this.loading = true;
  //   this.body.rssChannelsList = this.rssChannelsList;
  //   this.rssFeed.getAllRssFeed(this.body).subscribe((result) => {
  //     let rs = result.json();
  //     if (rs.code == this.config.statusCode.success) {
  //       this.rssFeedlist = rs.data.data;
  //       this.totalItems = rs.data.total_count;
  //     } else {
  //       this.toaster.error(rs.message);
  //     }
  //     this.loading = false;
  //   });
  // }

  // public selectionRssChannels(id, status) {
  //   this.rssFeed.selectionRssChannels({ id: id, status: status }).subscribe((result) => {
  //     let rs = result.json();
  //     if (rs.code == this.config.statusCode.success) {
  //       if (this.viewTabIndex == 0) {
  //         this.getAllRssFeed();
  //       } else {
  //         this.getSavedRssFeeds();
  //       }
  //     } else {
  //       this.toaster.error(rs.message);
  //     }
  //     this.loading = false;
  //   });
  // }

  // public saveFacilityFavouriteFeed(id, rssChannelId: any) {
  //   this.rssFeed.saveFacilityFavouriteFeed({ id: id, rssChannelId: rssChannelId }).subscribe((result) => {
  //     let rs = result.json();
  //     if (rs.code == this.config.statusCode.success) {
  //       this.toaster.success(rs.message);
  //       this.getAllRssFeed();
  //     } else {
  //       this.toaster.error(rs.message);
  //     }
  //     this.loading = false;
  //   });
  // }

  // public removeSavedFeed(id, rssChannelId: any) {
  //   this.rssFeed.removeSavedFeed({ id: id, rssChannelId: rssChannelId }).subscribe((result) => {
  //     let rs = result.json();
  //     if (rs.code == this.config.statusCode.success) {
  //       this.toaster.success(rs.message);
  //       this.getSavedRssFeeds();
  //     } else {
  //       this.toaster.error(rs.message);
  //     }
  //     this.loading = false;
  //   });
  // }

  public getUsersList() {
    this.loading = true;
    this.chatService.getUsersList(this.body).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.userList = rs.data.data;
        console.log("this.userList", this.userList);
        this.totalItems = rs.data.total_count;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  scrollDown() {
    setTimeout(() => {
      this.txtArea.nativeElement.scrollTop = this.txtArea.nativeElement.scrollHeight;
    }, 500)
  }

  public getChatHistory(user) {
    // console.log("user======>", user);
    if ($(window).width() < 768) {
      this.chatHistory = true;
      this.userListChat = false;
    } else {
      this.chatHistory = true;
      this.userListChat = true;
    }


    this.userSelected = true;
    console.log("this.userSelected", this.userSelected);
    this.loading = true;
    this.selectedUser.user = user;
    this.body.receiverId = user._id;
    this.chatService.getChatHistory(this.body).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.selectedUser.history = rs.data;
        console.log("this.selectedUser", this.selectedUser);
        if (rs.data.length == 0) {
          this.chatLength = false;
        }
        this.scrollDown();

      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  public sendMessage() {
    let data = {
      message: this.message,
      userFacId: this.user.userFacId,
      sentBy: this.user.uid,
      image: this.user.image,
      userName: this.user.userName,
      receivedBy: this.selectedUser.user._id,
      createdAt: new Date()
    }
    console.log("data in send message", data);
    this.selectedUser.history.push(data)
    this.message = '';
    this.scrollDown();
    this.chatService.sendChatMessage(data).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) { } else { }
    })
  }

  eventHandler(event: any, type: string) {
    if (type == 'Enter') {
      this.sendMessage();
    }
  }

  public ngOnInit(): void {
    if ($(window).width() < 768) {
      this.chatHistory = false;
      this.userListChat = true;
    } else {
      this.chatHistory = true;
      this.userListChat = true;
    }

    this.user = this.storage.get(this.config.token.userKey);
    if (this.storage.get(this.config.storage.KIOSK_MODE) == true) {
      this.kioskMode = true;
      this.toaster.success("Visitor Kiosk Mode On.");
      this.router.navigate(['/facility/visitorKiosk']);
    } else {
      this.kioskMode = false;
    }
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);

    this.getUsersList();

  }



}