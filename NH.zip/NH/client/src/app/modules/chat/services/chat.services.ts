import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '../../../core/utility/http.client';


@Injectable()
export class ChatService {
  constructor(
    private http: HttpClient
  ) { }

  //chat start
  getUsersList(data: any): Observable<any> {
    return this.http.post('/chat/getUsersList', data);
  }

  getChatHistory(data: any): Observable<any> {
    return this.http.post('/chat/getChatHistory', data);
  }

  sendChatMessage(data: any): Observable<any> {
    return this.http.post('/chat/sendChatMessage', data);
  }
  
  getAllRssChannels(data: any): Observable<any> {
    return this.http.get('/chat/getAllRssChannels', data);
  }


  selectionRssChannels(data: any): Observable<any> {
    return this.http.post('/chat/selectionRssChannels', data);
  }

  saveFacilityFavouriteFeed(data: any): Observable<any> {
    return this.http.post('/chat/saveFacilityFavouriteFeed', data);
  }

  getSavedRssFeeds(data: any): Observable<any> {
    return this.http.post('/chat/getSavedRssFeeds', data);
  }

  removeSavedFeed(data: any): Observable<any> {
    return this.http.post('/chat/removeSavedFeed', data);
  }
//   exportXml(data: any): Observable<any> {
//     return this.http.post('/company/exportXml', data);
//   }
//   activateDeactivateEmployee(data: any): Observable<any> {
//     return this.http.post('/employee/activateDeactivateEmployee', data);
//   }
  //employee end
 
}

