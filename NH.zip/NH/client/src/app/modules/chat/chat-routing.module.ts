import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";
import { ChatComponent } from "./chat.component";
import { ChatListComponent } from "./../../modules/chat/components/chat_list.component";



const routes: Routes = [
    {
        path: '', 
        component: ChatComponent,
        children: [
            {
                path: '',
                component: ChatListComponent,
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ChatRoutingModule {

}