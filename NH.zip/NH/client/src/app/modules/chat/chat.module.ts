import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
    PaginationModule
} from 'ngx-bootstrap';
import {
    ConfirmDialogModule,
    ConfirmationService,
    DialogModule,
    CalendarModule,
    TabViewModule
} from 'primeng/primeng';

import { ChatRoutingModule } from "./chat-routing.module";
import { ChatListComponent } from "./../../modules/chat/components/chat_list.component";
import { ChatComponent } from "./chat.component";



@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PaginationModule.forRoot(),
        ConfirmDialogModule,
        ChatRoutingModule,
        DialogModule,
        CalendarModule,
        TabViewModule
    ],
    declarations: [
        ChatComponent,
        ChatListComponent
    ],
    providers: [
        ConfirmationService
    ]
})
export class ChatModule { }