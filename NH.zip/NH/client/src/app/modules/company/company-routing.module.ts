import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";

import { CompanyComponent } from "./../../modules/company/company.component";
import { CompanyListComponent } from "./components/company_list.component";
import { CompanyAddComponent } from "./components/company_add.component";
import { CompanyEditComponent } from "./components/company_edit.component";
// import { CompanyImportComponent } from "./components/gene_import.component";

const routes: Routes = [
    {
        path: '', 
        component: CompanyComponent,
        children: [
            {
                path: '',
                component: CompanyListComponent,
            },
            {
                path: 'add',
                component: CompanyAddComponent,
            },
            {
                path: 'edit/:id',
                component: CompanyEditComponent,
            },
            //  {
            //     path: 'import',
            //     component: CompanyImportComponent,
            // }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class CompanyRoutingModule {

}