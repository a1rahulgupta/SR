import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
    PaginationModule
} from 'ngx-bootstrap';
import {
    ConfirmDialogModule,
    ConfirmationService,
    SelectItem,
    DialogModule,
    CalendarModule,
    ProgressSpinnerModule
} from 'primeng/primeng';
import { CompanyRoutingModule } from "./../../modules/company/company-routing.module";
import { CompanyComponent } from "./../../modules/company/company.component";
import { CompanyListComponent } from "./../../modules/company/components/company_list.component";
import { CompanyAddComponent } from "./../../modules/company/components/company_add.component";
import { CompanyEditComponent } from "./../../modules/company/components/company_edit.component";
import { CompanyViewComponent } from "./components/company_view.component";
import { ImageCropperModule } from 'ngx-image-cropper';
import { PopoverModule } from "ngx-popover";


@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PaginationModule.forRoot(),
        ConfirmDialogModule,
        CompanyRoutingModule,
        ImageCropperModule,
        DialogModule,
        CalendarModule,
        PopoverModule,
        ProgressSpinnerModule

    ],
    declarations: [
        CompanyComponent,
        CompanyListComponent,
        CompanyAddComponent,
        CompanyEditComponent,
        CompanyViewComponent
    ],
    providers: [
        ConfirmationService
    ]
})
export class CompanyModule { }