
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '../../../core/utility/http.client';


@Injectable()
export class CompanyService {
  constructor(
    private http: HttpClient
  ) { }

  //company start
  getCompanyById(data: any): Observable<any> {
    return this.http.get('/company/getCompanyById', data);
  }

  getAllCompanyList(data: any): Observable<any> {
    return this.http.post('/company/getAllCompanyList', data);
  }

  deleteCompany(data: any): Observable<any> {
    return this.http.post('/company/deleteCompany', data);
  }

  activateDeactivateCompany(data: any): Observable<any> {
    return this.http.post('/company/activateDeactivateCompany', data);
  }
  exportXml(data: any): Observable<any> {
    return this.http.post('/company/exportXml', data);
  }
  getZipCode(data: any): Observable<any> {
    return this.http.post('/company/getZipCode', data);
  }
  //company end

}

