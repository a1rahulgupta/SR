import { Component, ViewChild, ElementRef, NgZone } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from './../../../core/config/app.config';
import { AgmCoreModule, MapsAPILoader } from '@agm/core';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';
import { WebStorage } from './../../../core/utility/web.storage';
import { requiredTrim } from "./../../../core/validators/validators";
import { CompanyService } from '../services/company.services';
import { } from '@types/googlemaps';
declare var jQuery: any;
declare var $: any;
declare var google: any;


@Component({
  selector: 'app-company-add',
  preserveWhitespaces: false,
  templateUrl: './view/company_add.view.html',
  providers: [
    CompanyService
  ]
})
export class CompanyAddComponent {
  display: boolean = false;
  showFileName: boolean = false;
  baseImage: Blob;
  fileNameData: any;
  addressData: string;
  zipCodeData: any;
  cityName: any;
  finalState: any;
  stateCode: any;
  countryName: any;
  loading: boolean = false;
  citytemp: any;
  time: Date;
  prevNowPlaying: any;
  maxDate: Date;
  minDate: Date;
  phoneNumber: any;
  imageChangedEvent: any = '';
  croppedImage: any = '';
  cropperReady = false;
  public searchControl: FormControl;
  public httpCall: any = false;
  public logoSelected: any = true;
  public companyFrm: FormGroup;
  @ViewChild("search")
  public searchElementRef: ElementRef;

  constructor(
    private toaster: ToastrService,
    private Company: CompanyService,
    private router: Router,
    private mapsAPILoader: MapsAPILoader,
    private ngZone: NgZone,
    private activatedRoute: ActivatedRoute,
    public config: AppConfig,
    private formBuilder: FormBuilder,
    public utills: Utills,
    private tmpStorage: TmpStorage,
    private storage: WebStorage
  ) {
    this.formBuilder = formBuilder;
    this.searchControl = new FormControl();
    this.companyFrm = formBuilder.group({
      cmpName: ['', [requiredTrim]],
      firstName: ['', [requiredTrim]],
      lastName: ['', [requiredTrim]],
      email: ['', [requiredTrim, Validators.pattern(this.config.pattern.EMAIL)]],
      country_code: ['+1', [requiredTrim]],
      filename: [{ value: '', disabled: true }],
      phoneNumber: ['', [requiredTrim, Validators.minLength(10), Validators.maxLength(10)]],
      address: ['', [requiredTrim]],
      city: ['', [requiredTrim]],
      state: ['', [requiredTrim]],
      zipCode: ['', [requiredTrim, Validators.minLength(3), Validators.maxLength(5)]],
      expiryDate: ['', [requiredTrim]],
      country: ['', [requiredTrim]]
    });
  }

  fileChangeEvent(event: any): void {
    this.display = true;
    this.imageChangedEvent = event;
    let fileName = event.target.files[0];
    this.fileNameData = fileName.name;
  }
  imageLoaded() {
    this.cropperReady = true;
  }
  loadImageFailed() {
    this.display = false;
    this.toaster.error("You can upload only .jpg, .jpeg, .png file");
  }

  selectImage(action: any) {
    if (action == true) {
      this.imageLoaded();
      this.display = false;
    } else {
      this.display = false;
    }
  }

  public imageCropped(fileData: any) {
    this.croppedImage = fileData;
    let fileName = this.fileNameData;
    this.baseImage = this.utills.dataURItoBlob(fileData);
    let file = this.baseImage;
    let alowedSize = 1024 * 1024 * this.config.MaxUploadSixe;
    if (this.config.alowedFiletypes.indexOf(file.type) >= 0) {
      if (file.size <= alowedSize) {
        this.showFileName = true;
        this.companyFrm.controls['filename'].patchValue(fileName);
      } else {
        this.toaster.error("Please select a file within " + this.config.MaxUploadSixe + "MB");
      }
    } else {
      this.toaster.error("You can upload only .jpg, .jpeg, .png, .gif file");
    }
  }

  public save(fileData) {
    this.loading = true;
    fileData = this.croppedImage;
    let fileName = this.fileNameData;
    let url = this.config.apiUrl + "/company/addCompany";
    if (fileData != '') {
      this.baseImage = this.utills.dataURItoBlob(fileData);
      let file = this.baseImage;
      let alowedSize = 1024 * 1024 * this.config.MaxUploadSixe;
      if (this.config.alowedFiletypes.indexOf(file.type) >= 0) {
        if (file.size <= alowedSize) {
          this.httpCall = true;
          this.phoneNumber = this.companyFrm.value.country_code + this.companyFrm.value.phoneNumber;
          let formData = new FormData();
          formData.append("file", file, fileName);
          formData.append("cmpName", this.companyFrm.value.cmpName);
          formData.append("email", this.companyFrm.value.email);
          formData.append("firstName", this.companyFrm.value.firstName);
          formData.append("lastName", this.companyFrm.value.lastName);
          formData.append("phoneNumber", this.phoneNumber);
          formData.append("address", this.companyFrm.value.address);
          formData.append("city", this.companyFrm.value.city);
          formData.append("state", this.companyFrm.value.state);
          formData.append("zipCode", this.companyFrm.value.zipCode);
          formData.append("country", this.companyFrm.value.country);
          formData.append("expiryDate", this.companyFrm.value.expiryDate);
          formData.append("stateCode", this.stateCode);

          this.xhrRequest(url, formData);
        } else {
          this.toaster.error("Please select a file within " + this.config.MaxUploadSixe + "MB");
        }
      } else {
        this.toaster.error("You can upload only .jpg, .jpeg, .png file");
      }
    } else {

      this.httpCall = true;
      this.phoneNumber = this.companyFrm.value.country_code + this.companyFrm.value.phoneNumber;
      let formData = new FormData();
      formData.append("cmpName", this.companyFrm.value.cmpName);
      formData.append("email", this.companyFrm.value.email);
      formData.append("firstName", this.companyFrm.value.firstName);
      formData.append("lastName", this.companyFrm.value.lastName);
      formData.append("phoneNumber", this.phoneNumber);
      formData.append("address", this.companyFrm.value.address);
      formData.append("city", this.companyFrm.value.city);
      formData.append("state", this.companyFrm.value.state);
      formData.append("zipCode", this.companyFrm.value.zipCode);
      formData.append("country", this.companyFrm.value.country);
      formData.append("expiryDate", this.companyFrm.value.expiryDate);
      formData.append("stateCode", this.stateCode);

      this.xhrRequest(url, formData);
    }
  }

  private xhrRequest(url, formData) {
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          this.loading = false;
          this.httpCall = false;
          let rs = JSON.parse(xhr.response);
          if (rs.code == this.config.statusCode.success) {
            this.toaster.success(rs.message);
            this.router.navigate(['/admin/company']);
          } else {
            this.toaster.error(rs.message);
          }
        } else {
          this.loading = false;
          this.httpCall = false;
          let rs = JSON.parse(xhr.response);
          if (rs.code == this.config.statusCode.success) {
            this.toaster.success(rs.message);
            this.router.navigate(['/admin/company']);
          } else {
            this.toaster.error(rs.message);
          }
        }
      }
    }
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Authorization", "Bearer " + this.storage.get(this.config.token.keyID));
    xhr.send(formData);
  }


  public ngOnInit() {
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
    let today = new Date();
    let month = today.getMonth();
    let year = today.getFullYear();
    let prevMonth = (month === 0) ? 11 : month - 1;
    let prevYear = (prevMonth === 11) ? year - 1 : year;
    let nextMonth = (month === 11) ? 0 : month + 1;
    let nextYear = (nextMonth === 0) ? year + 1 : year;
    this.minDate = new Date();
    this.minDate.setMonth(nextMonth);
    this.minDate.setFullYear(year);
    this.maxDate = new Date();
    this.maxDate.setMonth(nextMonth);
    this.maxDate.setFullYear(nextYear);


    //create search FormControl
    this.searchControl = new FormControl();

    console.log("this.searchElementRef", this.searchElementRef);
    //load Places Autocomplete
    this.mapsAPILoader.load().then(() => {
      let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
        // types: ['(cities)'],
        componentRestrictions: { country: "us" }
      });
      autocomplete.addListener("place_changed", () => {
        this.ngZone.run(() => {
          //get the place result
          let place: google.maps.places.PlaceResult = autocomplete.getPlace();
          console.log("place------", place);
          //verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }
          const components = place.address_components;
          const street = null;
          var data = [];
          for (let i = 0, component; component = components[i]; i++) {
            var temp = component.long_name;
            data.push({
              address: component.long_name
            })
            this.addressData = place.formatted_address;
            if (component.types[0] === 'country') {
              const country = component.long_name;
              this.countryName = country;
            } else if (component.types[0] === 'administrative_area_level_1') {
              const state = component.long_name;
              this.stateCode = component.short_name;
              this.finalState = state;
              console.log("state", this.finalState);
            } else if ((component.types[0] === 'locality') || (component.types[0] === 'sublocality_level_1')) {
              const city = component.long_name;
              this.cityName = city;
            } else if (component.types[0] === 'postal_code') {
              const zip = component.long_name;
              this.zipCodeData = zip;
            }
          }
          this.companyFrm.controls['state'].patchValue(this.finalState);
          this.companyFrm.controls['country'].patchValue(this.countryName);
          this.companyFrm.controls['city'].patchValue(this.cityName);
          this.companyFrm.controls['zipCode'].patchValue(this.zipCodeData);
          this.companyFrm.controls['address'].patchValue(this.addressData);
        });
      });
    });


  }

}
