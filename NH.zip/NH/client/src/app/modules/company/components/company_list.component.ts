
import { Component, Inject, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
type AOA = Array<Array<any>>;

import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';
import { CompanyViewComponent } from "./company_view.component";
import { CompanyService } from '../services/company.services';

@Component({
  selector: 'app-company-list',
  preserveWhitespaces: false,
  templateUrl: './view/company_list.view.html',
  styles: [`
  :host >>> .popover {
    color: #FFFFFF;
    background: #000000;
  
  }

`],
  providers: [
    CompanyService
  ]
})
export class CompanyListComponent {
  closebtn: any;
  maxDate: Date;
  minDate: Date;
  time: Date;
  prevNowPlaying: any;
  display: boolean;
  companyViewDialoge: boolean;
  @ViewChild('CompanyViewComponent')
  private CompanyViewComponent: CompanyViewComponent;


  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private company: CompanyService,
    private router: Router,
    private utills: Utills,
    private tmpStorage: TmpStorage,
    private confirmationService: ConfirmationService
  ) { }

  /*------------------ Listing Elements --------------------*/
  public asc: string = 'asc';
  public exportfile: string = '';
  public loading: boolean = true;
  public listData: any = [];
  public totalItems: number = 0;

  public body: any = {
    'page': 1,
    'count': this.config.perPageDefault,
    'searchText': '',
    'cmpName': '',
    'userName': '',
    'createdAt': '',
    'sorting': 'createdAt',
    'order': 'asc',
  };

  public setRecordPerPage(records: number): void {
    this.body.page = 1;
    this.body.count = records;
    this.getAllCompanyList();
  }

  public sort(field: string, order: any): void {
    if (order == 'asc') {
      this.asc = 'asc';
    } else {
      this.asc = 'desc';
    }
    this.body.sorting = field;
    this.body.order = order;
    this.getAllCompanyList();
  }

  public pageChanged(event: any): void {

    this.body.page = event.page;
    this.getAllCompanyList();
  }

  public resetSearch(): void {
    this.body.searchText = '';
    this.body.createdAt = '';
    this.body.userName = '';
    this.body.cmpName = '';
    this.getAllCompanyList();
  }

  public changePageLimit(pageLimit: any) {
    this.body.count = parseInt(pageLimit);
    this.getAllCompanyList()
  }

  public getAllCompanyList() {
    this.loading = true;
    console.log("rs.datathis.body", this.body);
    this.company.getAllCompanyList(this.body).subscribe((result) => {
      let rs = result.json();
      console.log("rs.data****************", rs);
      if (rs.code == this.config.statusCode.success) {
        this.listData = rs.data.data;
        this.totalItems = rs.data.total_count;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }
  /*------------------ Listing Elements --------------------*/

  public remove(id: string, userId: string, userCmpId: string) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to delete?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        this.company.deleteCompany({ _id: id, userId: userId, userCmpId: userCmpId }).subscribe((result) => {
          let rs = result.json();
          if (rs.code == this.config.statusCode.success) {
            this.getAllCompanyList();
            this.toaster.success(rs.message);
          } else {
            this.toaster.error(rs.message);
          }
          this.loading = false;
        });
      },
      reject: () => {
      }
    });
  }

  public enable(id: string, userId: string, userCmpId: string, status: string, by: string) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to change status?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var cmpObj = {
          _id: id,
          userId: userId,
          userCmpId: userCmpId,
          status: status,
          by: by
        };
        this.company.activateDeactivateCompany(cmpObj).subscribe((result) => {
          let rs = result.json();
          if (rs.code == this.config.statusCode.success) {
            this.getAllCompanyList();
            this.toaster.success(rs.message);
          } else {
            this.toaster.error(rs.message);
          }
          this.loading = false;
        });
      },
      reject: () => {
      }
    });
  }

  public exportAll(exportfile) {
    if (exportfile == 'xls') {
      this.exportXls();
    } else if (exportfile == 'json') {
      this.exportJson();
    } else if (exportfile == 'csv') {
      this.createCsvFile();
    } else if (exportfile == 'txt') {
      this.exportTxt();
    } else if (exportfile == 'xml') {
      this.exportXml();
    }
  }


  public createCsvFile() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to csv file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        var options = {
          fieldSeparator: ',',
          quoteStrings: '"',
          decimalseparator: '.',
          showLabels: true,
          showTitle: true,
          useBom: true
        };
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'Company Name': this.listData[i].cmpName,
            'User Name': this.listData[i].userName,

            'CreatedAt': this.listData[i].createdAt
          });
        }
        new Angular2Csv(data, 'listData', { headers: Object.keys(data[0]) });
      },
      reject: () => {
      }
    });
  }

  public exportTxt() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to text file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'Company Name': this.listData[i].cmpName,
            'User Name': this.listData[i].userName,

            'CreatedAt': this.listData[i].createdAt
          });
        }
        var obj = objectToString(data);
        console.log(obj);
        function objectToString(obj) {
          var str = '';
          var i = 0;
          for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
              if (typeof obj[key] == 'object') {
                {
                  str += key + ' : { ' + objectToString(obj[key]) + '} ' + (i > 0 ? ',' : '');
                }
              }
              else {
                str += key + ':\'' + obj[key] + '\'' + (i > 0 ? ',' : '');
              }
              i++;
            }
          }
          return str;
        }
        var textToSave = obj,
          filename = 'file.txt',
          blob = new Blob([textToSave], { type: "text/plain;charset=utf-8" });
        saveAs(blob, filename);
      },
      reject: () => {
      }
    });
  }


  public exportXml() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to Xml file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'id': this.listData[i]._id,
            'column-1': this.listData[i].cmpName,
            'column-2': this.listData[i].userName,
            'column-3': this.listData[i].createdAt
          });

        }
        var obj = JSON.stringify(
          {
            "_declaration": {
              "_attributes": {
                "version": "1.0",
                "encoding": "utf-8"
              }
            },
            "tabledata": {
              "field": [
                [],
                "Company Name",
                "User Name",

                "Created At"
              ],
              "data": {
                "row": data
              }
            }
          }
        )
        this.company.exportXml(obj).subscribe((result) => {
          let rs = result.json();
          var textToSave = rs.data,
            filename = 'file.xml',
            blob = new Blob([textToSave], { type: "'application/xml charset=utf-8'" });
          saveAs(blob, filename);
        })
      },
      reject: () => {
      }
    });

  }


  public exportJson() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to json file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'Company Name': this.listData[i].cmpName,
            'User Name': this.listData[i].userName,

            'CreatedAt': this.listData[i].createdAt
          });
        }
        var textToSave = JSON.stringify({ "header": [["Company Name", "User Name", "Created At"]], "data": data }),
          filename = 'file.json',
          blob = new Blob([textToSave], { type: "'application/json; charset=utf-8'" });

        saveAs(blob, filename);
      },
      reject: () => {
      }
    });
  }

  public exportXls(): void {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to excel?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        let wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
        let fileName: string = 'company_' + new Date().getTime() + '.xlsx';
        let data: AOA = [
          [
            "Company Name",
            "User Name",

            "Created At"
          ]
        ];

        this.listData.map((item: any) => {
          data.push([
            item.cmpName,
            item.userName,
            item.createdAt
          ]);
        });

        const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(data);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
        const wbout: ArrayBuffer = XLSX.write(wb, wopts);
        saveAs(new Blob([wbout], { type: 'application/octet-stream' }), fileName);
      },
      reject: () => {
      }
    });
  }


  public viewCompany(companyData: any) {
    console.log("data---", companyData);
    var getData = companyData;
    this.CompanyViewComponent.getCompanyData(getData);
    this.companyViewDialoge = true;
  }
  showDialog() {
    this.display = true;
  }


  public ngOnInit(): void {
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
    this.getAllCompanyList();
    let today = new Date();
    let month = today.getMonth();
    let year = today.getFullYear();
    let prevMonth = (month === 0) ? 11 : month - 1;
    let prevYear = (prevMonth === 11) ? year - 1 : year;
    let nextMonth = (month === 11) ? 0 : month + 1;
    let nextYear = (nextMonth === 0) ? year + 1 : year;
    this.minDate = new Date();
    this.minDate.setMonth(nextMonth);
    this.minDate.setFullYear(year);
    this.maxDate = new Date();
    this.maxDate.setMonth(nextMonth);
    this.maxDate.setFullYear(nextYear);
  }

}

