import { Component, OnInit, ViewChild, Output, EventEmitter, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms'
import { Router, ActivatedRoute, Params } from '@angular/router';
import { MessageService } from 'primeng/components/common/messageservice';
import { AppConfig } from './../../../core/config/app.config';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import { CompanyService } from '../services/company.services';

@Component({
  selector: 'app-company-view',
  preserveWhitespaces: false,
  templateUrl: './view/companyView.view.html',
  providers: [
    CompanyService
  ]
})
export class CompanyViewComponent implements OnInit {
  imagePath: any;
  companyInfo: any;

  type = "password";

  show = false;

  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private companyService: CompanyService,
    private router: Router,
    private confirmationService: ConfirmationService
  ) {

  }

  ngOnInit() {
  }

  getCompanyData(getData) {
    this.companyInfo = getData;
    console.log("this.companyInfo", this.companyInfo);
    this.imagePath = 'assets/upload/profiles/' + getData.cmpLogo;
  }

  toggleShow() {
    this.show = !this.show;
    if (this.show) {
      this.type = "text";
    }
    else {
      this.type = "password";
    }
  }
}




