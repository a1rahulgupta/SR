import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
  PaginationModule
} from 'ngx-bootstrap';
import {
  ConfirmDialogModule,
  ConfirmationService
} from 'primeng/primeng';

import { PatientDashboardComponent } from "./components/patientDashboard.component";
import { PatientFeedbackComponent } from "./patient_feedback.component";
import { PatientFeedbackRoutingModule } from "./patient_feedback-routing.module";
import { AddPatientComplaintComponent } from "./components/addPatientComplaint.component";
import { AddPatientReviewComponent } from "./components/addPatientReview.component";

@NgModule({
    imports: [
        CommonModule, 
        FormsModule,
        ReactiveFormsModule,
        PaginationModule.forRoot(),
        ConfirmDialogModule,
        PatientFeedbackRoutingModule
    ],
    declarations: [
        PatientFeedbackComponent,
        AddPatientReviewComponent,
        PatientDashboardComponent,
        AddPatientComplaintComponent
    ],
    providers: [
        ConfirmationService
    ]
})
export class PatientFeedbackModule { }