import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from "../../../core/utility/http.client";



@Injectable()
export class PatientFeedbackService {
  constructor(
    private http: HttpClient
  ) { }

  addPatientReview(data: any): Observable<any> {
    return this.http.post('/feedback/addPatientReview', data);
  }
  addPatientComplaint(data: any): Observable<any> {
    return this.http.post('/feedback/addPatientComplaint', data);
  }
  getCategory(data:any): Observable<any>{
    return this.http.post('/feedback/getCategoryList', data);
  }

}
