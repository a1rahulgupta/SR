import { Input, Output, EventEmitter, Component,ViewChild,AfterViewInit, ElementRef } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { UserService } from "../../../core/services/user.services";
import { requiredTrim } from "../../../core/validators/validators";


@Component({
  selector: 'app-employee_review',
  preserveWhitespaces: false,
  templateUrl: './view/patientDashboard.component.html',
  providers: [
    UserService
  ]
})
export class PatientDashboardComponent {
  constructor(
    
  ) {
    
  }

	ngOnInit() {
   
  }
  




}