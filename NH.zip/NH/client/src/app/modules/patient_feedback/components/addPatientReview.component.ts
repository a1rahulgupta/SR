import { Input, Output, EventEmitter, Component, ViewChild, AfterViewInit, ElementRef } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { requiredTrim } from "../../../core/validators/validators";
import { PatientFeedbackService } from "../service/patient_feedback.service";
import { WebStorage } from "../../../core/utility/web.storage";


@Component({
  selector: 'app-patient_review',
  preserveWhitespaces: false,
  templateUrl: './view/addPatientReview.component.html',
  providers: [
    PatientFeedbackService
  ]
})
export class AddPatientReviewComponent {
  user: any;
  loading: boolean;
  getCategoryList: any;

  public verifyStatus: number = 0;
  public patientReviewFrm: FormGroup;
  public httpCall: any = false;
  @Input() score;
  @Input() maxScore = 5;
  @Input() forDisplay = false;
  @Output() rateChanged = new EventEmitter();

  range = [];
  marked = -1;
  constructor(
    private toaster: ToastrService,
    private patientFeedbackService: PatientFeedbackService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private utills: Utills,
    private config: AppConfig,
    private storage: WebStorage
  ) {
    this.patientReviewFrm = formBuilder.group({
      email: ['', [Validators.pattern(this.config.pattern.EMAIL)]],
      firstName: ['', [requiredTrim]],
      lastName: ['', [requiredTrim]],
      comments: ['', [requiredTrim]],
      rating: [''],
      phoneNumber: ['', [Validators.minLength(10), Validators.maxLength(10)]],
      category_id: ['', [requiredTrim]]
    });
  }

  ngOnInit() {
    this.patientFeedbackService.getCategory({}).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.getCategoryList = rs.data;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
    for (var i = 0; i < this.maxScore; i++) {
      this.range.push(i);
    }
  }

  public mark = (index) => {
    this.marked = this.marked == index ? index - 1 : index;
    this.score = this.marked + 1;
    this.rateChanged.next(this.score);
  }

  public isMarked = (index) => {
    if (!this.forDisplay) {
      if (index <= this.marked) {
        return 'fa-star';
      }
      else {
        return 'fa-star-o';
      }
    }
    else {
      if (this.score >= index + 1) {
        return 'fa-star';
      }
      else if (this.score > index && this.score < index + 1) {
        return 'fa-star-half-o';
      }
      else {
        return 'fa-star-o';
      }
    }
  }


  send() {
    this.httpCall = true;
    this.user = this.storage.get(this.config.token.userKey);
    var patientReview = this.patientReviewFrm.value;
    patientReview.userFacilityId = this.user.userFacId;
    patientReview.rating = this.score;
    console.log("patientReview", patientReview);
    this.patientFeedbackService.addPatientReview(patientReview).subscribe((result: any) => {
      this.httpCall = false;
      var rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.toaster.success(rs.message);
        this.router.navigate(['/facility/patient_feedback/']);
      } else {
        this.toaster.error(rs.message);
      }
    });
  }

}