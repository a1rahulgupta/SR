import { Component } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { UserService } from "../../../core/services/user.services";
import { requiredTrim } from "../../../core/validators/validators";
import { PatientFeedbackService } from "../service/patient_feedback.service";
import { WebStorage } from "../../../core/utility/web.storage";


@Component({
  selector: 'app-patient_complaint',
  preserveWhitespaces: false,
  templateUrl: './view/addPatientComplaint.component.html',
  providers: [
    PatientFeedbackService
  ]
})
export class AddPatientComplaintComponent {
  loading: boolean;
  getCategoryList: any;
  user: any;
  public patientComplaintFrm: FormGroup;
  public httpCall: any = false;
  constructor(
    private toaster: ToastrService,
    private patientFeedbackService: PatientFeedbackService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private utills: Utills,
    private config: AppConfig,
    private storage: WebStorage,
  ) {
    this.patientComplaintFrm = formBuilder.group({
      email: ['', [ Validators.pattern(this.config.pattern.EMAIL)]],
      firstName:['',[requiredTrim]],
      lastName:['',[requiredTrim]],
      complaint:['',[requiredTrim]],
      phoneNumber: ['', [Validators.minLength(10), Validators.maxLength(10)]],
      category_id:['',[requiredTrim]]
    });
  }

	ngOnInit() {
      this.patientFeedbackService.getCategory({}).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.getCategoryList = rs.data;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }


  send() {
    this.httpCall = true;
    this.user = this.storage.get(this.config.token.userKey);
    var patientComplaint = this.patientComplaintFrm.value;
        patientComplaint.userFacilityId = this.user.userFacId;
        console.log("patientComplaint",patientComplaint);
    this.patientFeedbackService.addPatientComplaint(patientComplaint).subscribe((result: any) => {
      this.httpCall = false;
      var rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.toaster.success(rs.message);
        this.router.navigate(['/facility/patient_feedback/']);
      } else {
        this.toaster.error(rs.message);
      }
    });
  }

}