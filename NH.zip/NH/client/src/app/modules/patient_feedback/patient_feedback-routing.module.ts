import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";
import { PatientDashboardComponent } from "./components/patientDashboard.component";
import { PatientFeedbackComponent } from "./patient_feedback.component";
import { AddPatientComplaintComponent } from "./components/addPatientComplaint.component";
import { AddPatientReviewComponent } from "./components/addPatientReview.component";

const routes: Routes = [
    {
        path: '', 
        component: PatientFeedbackComponent,
        children: [

             {
                path: '',
                component: PatientDashboardComponent,
            },
             {
                path: 'review',
                component: AddPatientReviewComponent,
            },
             {
                path: 'complaint',
                component: AddPatientComplaintComponent,
            },
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class PatientFeedbackRoutingModule {

}