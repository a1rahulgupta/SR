import { Input, Output, EventEmitter, Component, ViewChild, AfterViewInit, ElementRef } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { requiredTrim } from "../../../core/validators/validators";
import { WebStorage } from "../../../core/utility/web.storage";
import { ReviewsService } from "../services/reviews.services";
declare var $: any;

@Component({
  selector: 'app-employee_review',
  preserveWhitespaces: false,
  templateUrl: './view/reviews_list.view.html',
  providers: [
    ReviewsService
  ]
})
export class ReviewsListComponent {
  googleShow: boolean = false;  
  citeHealthShow: boolean = false;
  public citeHealthArray: any = [];
  public googleArray: any = [];
  citeHealthPage: any;
  citeHealthPageFound: boolean = false; 
  googlePage: any;  
  googlePageFound: boolean = false; 
  citeHealth = {
    status: false,
  };
  google = {
    status: false
  };
  public caringArray: any = [];
  caringShow: boolean = false;
  caringPage: any;    
  caringPageFound: boolean = false; 
  caring = {
    status: false
  };
  public seniorAdvisorArray: any = [];
  seniorAdvisorShow: boolean = false;
  seniorAdvisorPage: any;    
  seniorAdvisorPageFound: boolean = false; 
  seniorAdvisor = {
    status: false
  };
  public localNursingHomesArray: any = [];
  localNursingHomesShow: boolean = false;
  localNursingHomesPage: any;    
  localNursingHomesPageFound: boolean = false; 
  localNursingHomes = {
    status: false
  };
  nursingHomeSitePage: any;    
  nursingHomeSitePageFound: boolean = false; 
  nursingHomeSite = {
    status: false
  };
  familyAssetsPage: any;    
  familyAssetsPageFound: boolean = false; 
  familyAssets = {
    status: false
  };
  public yelpArray: any = [];
  yelpShow: boolean = false;
  yelpPage: any;    
  yelpPageFound: boolean = false; 
  yelp = {
    status: false
  };
  public superPagesArray: any = [];
  superPagesShow: boolean = false;
  superPagesPage: any;    
  superPagesPageFound: boolean = false; 
  superPages = {
    status: false
  };
  public yellowPagesArray: any = [];
  yellowPagesShow: boolean = false;
  yellowPagesPage: any;    
  yellowPagesPageFound: boolean = false; 
  yellowPages = {
    status: false
  };
  public agingCareArray: any = [];
  agingCareShow: boolean = false;
  agingCarePage: any;    
  agingCarePageFound: boolean = false; 
  agingCare = {
    status: false
  };
  public indeedArray: any = [];
  indeedShow: boolean = false;
  indeedPage: any;    
  indeedPageFound: boolean = false; 
  indeed = {
    status: false
  };
  public wellnessArray: any = [];
  wellnessShow: boolean = false;
  wellnessPage: any;    
  wellnessPageFound: boolean = false; 
  wellness = {
    status: false
  };
  kioskMode: boolean;
  time: Date;
  prevNowPlaying: any;
  viewTabIndex: any;
  savedRssFeedlist: any;
  index: any;
  totalItems: any;
  params: any;
  firstTab: number = 0;
  secTab: number = 1;
  rssFeedlist: any;
  rssChannelsList: any;
  public body: any = {
    'page': 1,
    'count': 10
  };
  constructor(
    private reviewsService: ReviewsService,
    private router: Router,
    private storage: WebStorage,
    public config: AppConfig,
    private toaster: ToastrService,
    private activatedRoute: ActivatedRoute,
  ) { }

  /*------------------ Listing Elements --------------------*/
  public loading: boolean = true;

  public seachPage(platform: any){
    if(platform == 'chealth'){
      this.citeHealthPageFound = true;
    }else if(platform == 'google'){
      this.googlePageFound = true;
    }else if(platform == 'caring'){
      this.caringPageFound = true;
    }else if(platform == 'seniorAdvisor'){
      this.seniorAdvisorPageFound = true;
    }else if(platform == 'localNursingHomes'){
      this.localNursingHomesPageFound = true;
    }else if(platform == 'nursingHomeSite'){
      this.nursingHomeSitePageFound = true;
    }else if(platform == 'familyAssets'){
      this.familyAssetsPageFound = true;
    }else if(platform == 'yelp'){
      this.yelpPageFound = true;
    }else if(platform == 'superPages'){
      this.superPagesPageFound = true;
    }else if(platform == 'yellowPages'){
      this.yellowPagesPageFound = true;
    }else if(platform == 'agingCare'){
      this.agingCarePageFound = true;
    }else if(platform == 'indeed'){
      this.indeedPageFound = true;
    }else if(platform == 'wellness'){
      this.wellnessPageFound = true;
    }
  }

  public getFacilityReviewPlatforms(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.getFacilityReviewPlatforms({}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.citeHealth = rs.data.citeHealth;
          this.google = rs.data.google;
          this.caring = rs.data.caring;
          this.seniorAdvisor = rs.data.seniorAdvisor;
          this.localNursingHomes = rs.data.localNursingHomes;
          this.nursingHomeSite = rs.data.nursingHomeSite;
          this.familyAssets = rs.data.familyAssets;
          this.yelp = rs.data.yelp;
          this.superPages = rs.data.superPages;
          this.yellowPages = rs.data.yellowPages;
          this.agingCare = rs.data.agingCare;
          this.indeed = rs.data.indeed;
          this.wellness = rs.data.wellness;
        }else{
          this.toaster.error(rs.message);
        } 
      })
    })
  }

  public searchReviewPlatformPage(pageUrl: any, platform: any){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.searchReviewPlatformPage({pageUrl: pageUrl, platform: platform}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.toaster.success(rs.message);
          this.getFacilityReviewPlatforms();
          this.getFacilityCitehealthReviews();
        }else{
          this.citeHealthPage = '';
          this.citeHealth.status = false;
          this.toaster.error(rs.message);
        } 
      })
    })
  }

  public searchGoogleReviewPlatformBusiness(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.searchGoogleReviewPlatformBusiness({businessName: this.googlePage}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.toaster.success(rs.message);
          this.getFacilityReviewPlatforms();
          this.getFacilityGoogleReviews();
        }else{
          this.googlePage = '';
          this.google.status = false;
          this.toaster.error(rs.message);
        } 
      })
    })
  }

  public getFacilityCitehealthReviews(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.getFacilityCitehealthReviews({}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.citeHealthArray = rs.data;
          if(this.citeHealthArray.length>0){
            this.citeHealthShow = true;
          }else{
            this.citeHealthShow = false;
          }
        } else{
          this.toaster.error(rs.message);
        }
      })
    })
  }

  public getFacilityGoogleReviews(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.getFacilityGoogleReviews({}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.googleArray = rs.data;
          if(this.googleArray.length>0){
            this.googleShow = true;
          }else{
            this.googleShow = false;
          }
        } else{
          this.toaster.error(rs.message);
        }
      })
    })
  }

  public getFacilityCaringReviews(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.getFacilityCaringReviews({}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.caringArray = rs.data;
          if(this.caringArray.length>0){
            this.caringShow = true;
          }else{
            this.caringShow = false;
          }
        } else{
          this.toaster.error(rs.message);
        }
      })
    })
  }

  public searchCaringReviewPlatformPage(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.searchCaringReviewPlatformPage({pageUrl: this.caringPage}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.toaster.success(rs.message);
          this.getFacilityReviewPlatforms();
          this.getFacilityCaringReviews();
        }else{
          this.caringPage = '';
          this.caring.status = false;
          this.toaster.error(rs.message);
        } 
      })
    })
  }

  public getFacilitySeniorAdvisorReviews(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.getFacilitySeniorAdvisorReviews({}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.seniorAdvisorArray = rs.data;
          if(this.seniorAdvisorArray.length>0){
            this.seniorAdvisorShow = true;
          }else{
            this.seniorAdvisorShow = false;
          }
        } else{
          this.toaster.error(rs.message);
        }
      })
    })
  }

  public searchSeniorAdvisorReviewPlatformPage(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.searchSeniorAdvisorReviewPlatformPage({pageUrl: this.seniorAdvisorPage}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.toaster.success(rs.message);
          this.getFacilityReviewPlatforms();
          this.getFacilitySeniorAdvisorReviews();
        }else{
          this.seniorAdvisorPage = '';
          this.seniorAdvisor.status = false;
          this.toaster.error(rs.message);
        } 
      })
    })
  }

  public getFacilityLocalNursingHomeReviews(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.getFacilityLocalNursingHomeReviews({}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.localNursingHomesArray = rs.data;
          if(this.localNursingHomesArray.length>0){
            this.localNursingHomesShow = true;
          }else{
            this.localNursingHomesShow = false;
          }
        } else{
          this.toaster.error(rs.message);
        }
      })
    })
  }

  public searchLocalNursingHomeReviewPlatformPage(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.searchLocalNursingHomeReviewPlatformPage({pageUrl: this.localNursingHomesPage}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.toaster.success(rs.message);
          this.getFacilityReviewPlatforms();
          this.getFacilityLocalNursingHomeReviews();
        }else{
          this.localNursingHomesPage = '';
          this.localNursingHomes.status = false;
          this.toaster.error(rs.message);
        } 
      })
    })
  }

  public searchNursingHomeSiteReviewPlatformPage(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.searchNursingHomeSiteReviewPlatformPage({pageUrl: this.nursingHomeSitePage}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.toaster.success(rs.message);
          this.getFacilityReviewPlatforms();
        }else{
          this.nursingHomeSitePage = '';
          this.nursingHomeSite.status = false;
          this.toaster.error(rs.message);
        } 
      })
    })
  }

  public searchFamilyAssetsReviewPlatformPage(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.searchFamilyAssetsReviewPlatformPage({pageUrl: this.familyAssetsPage}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.toaster.success(rs.message);
          this.getFacilityReviewPlatforms();
        }else{
          this.familyAssetsPage = '';
          this.familyAssets.status = false;
          this.toaster.error(rs.message);
        } 
      })
    })
  }


  public testFunc = function(rating){
    var displatRating=[];
    for(var i=0;i<5;i++){
      if(rating-i>=1){
        displatRating.push({starType:'fa-star'}); 
      }else if(rating-i<1 && rating-i>0){
        displatRating.push({starType:'fa-star-half-o'}); 
      }else{
        displatRating.push({starType:'fa-star-o'}); 
      }
    }
    return displatRating;
  }

  public getFacilityYelpReviews(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.getFacilityYelpReviews({}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.yelpArray = rs.data;
          if(this.yelpArray.length>0){
            this.yelpShow = true;
          }else{
            this.yelpShow = false;
          }
        } else{
          this.toaster.error(rs.message);
        }
      })
    })
  }

  public searchYelpReviewPlatformPage(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.searchYelpReviewPlatformPage({pageUrl: this.yelpPage}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.toaster.success(rs.message);
          this.getFacilityReviewPlatforms();
          this.getFacilityYelpReviews();
        }else{
          this.yelpPage = '';
          this.yelp.status = false;
          this.toaster.error(rs.message);
        } 
      })
    })
  }

  public getFacilitySuperPagesReviews(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.getFacilitySuperPagesReviews({}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.superPagesArray = rs.data;
          if(this.superPagesArray.length>0){
            this.superPagesShow = true;
          }else{
            this.superPagesShow = false;
          }
        } else{
          this.toaster.error(rs.message);
        }
      })
    })
  }

  public searchSuperPagesReviewPlatformPage(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.searchSuperPagesReviewPlatformPage({pageUrl: this.superPagesPage}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.toaster.success(rs.message);
          this.getFacilityReviewPlatforms();
          this.getFacilitySuperPagesReviews();
        }else{
          this.superPagesPage = '';
          this.superPages.status = false;
          this.toaster.error(rs.message);
        } 
      })
    })
  }

  public getFacilityYellowPagesReviews(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.getFacilityYellowPagesReviews({}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.yellowPagesArray = rs.data;
          if(this.yellowPagesArray.length>0){
            this.yellowPagesShow = true;
          }else{
            this.yellowPagesShow = false;
          }
        } else{
          this.toaster.error(rs.message);
        }
      })
    })
  }

  public searchYellowPagesReviewPlatformPage(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.searchYellowPagesReviewPlatformPage({pageUrl: this.yellowPagesPage}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.toaster.success(rs.message);
          this.getFacilityReviewPlatforms();
          this.getFacilityYellowPagesReviews();
        }else{
          this.yellowPagesPage = '';
          this.yellowPages.status = false;
          this.toaster.error(rs.message);
        } 
      })
    })
  }

  public getFacilityAgingCareReviews(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.getFacilityAgingCareReviews({}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.agingCareArray = rs.data;
          if(this.agingCareArray.length>0){
            this.agingCareShow = true;
          }else{
            this.agingCareShow = false;
          }
        } else{
          this.toaster.error(rs.message);
        }
      })
    })
  }

  public searchAgingCareReviewPlatformPage(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.searchAgingCareReviewPlatformPage({pageUrl: this.agingCarePage}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.toaster.success(rs.message);
          this.getFacilityReviewPlatforms();
          this.getFacilityAgingCareReviews();
        }else{
          this.agingCarePage = '';
          this.agingCare.status = false;
          this.toaster.error(rs.message);
        } 
      })
    })
  }

  public getFacilityIndeedReviews(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.getFacilityIndeedReviews({}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.indeedArray = rs.data;
          if(this.indeedArray.length>0){
            this.indeedShow = true;
          }else{
            this.indeedShow = false;
          }
        } else{
          this.toaster.error(rs.message);
        }
      })
    })
  }

  public searchIndeedReviewPlatformPage(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.searchIndeedReviewPlatformPage({pageUrl: this.indeedPage}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.toaster.success(rs.message);
          this.getFacilityReviewPlatforms();
          this.getFacilityIndeedReviews();
        }else{
          this.indeedPage = '';
          this.indeed.status = false;
          this.toaster.error(rs.message);
        } 
      })
    })
  }

  public getFacilityWellnessReviews(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.getFacilityWellnessReviews({}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.wellnessArray = rs.data;
          if(this.wellnessArray.length>0){
            this.wellnessShow = true;
          }else{
            this.wellnessShow = false;
          }
        } else{
          this.toaster.error(rs.message);
        }
      })
    })
  }

  public searchWellnessReviewPlatformPage(){
    this.activatedRoute.params.subscribe((param: any) => {
      this.reviewsService.searchWellnessReviewPlatformPage({pageUrl: this.wellnessPage}).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.toaster.success(rs.message);
          this.getFacilityReviewPlatforms();
          this.getFacilityWellnessReviews();
        }else{
          this.wellnessPage = '';
          this.wellness.status = false;
          this.toaster.error(rs.message);
        } 
      })
    })
  }

  public ngOnInit(): void {
    if (this.storage.get(this.config.storage.KIOSK_MODE) == true) {
      this.kioskMode = true;
      this.toaster.success("Visitor Kiosk Mode On.");
      this.router.navigate(['/facility/visitorKiosk']);
    } else {
      this.kioskMode = false;
    }
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
    
    this.getFacilityReviewPlatforms();
    this.getFacilityCitehealthReviews();
    this.getFacilityGoogleReviews();
    this.getFacilityCaringReviews();
    this.getFacilitySeniorAdvisorReviews();
    this.getFacilityLocalNursingHomeReviews(); 
    this.getFacilityYelpReviews();
    this.getFacilitySuperPagesReviews();  
    this.getFacilityYellowPagesReviews();     
    this.getFacilityAgingCareReviews(); 
    this.getFacilityIndeedReviews();
    this.getFacilityWellnessReviews();
  }
  
}