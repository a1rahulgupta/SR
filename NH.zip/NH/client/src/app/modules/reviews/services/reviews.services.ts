import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '../../../core/utility/http.client';


@Injectable()
export class ReviewsService {
  constructor(
    private http: HttpClient
  ) { }

  //review start
  getFacilityReviewPlatforms(data: any): Observable<any> {
    return this.http.get('/reviews/getFacilityReviewPlatforms', data);
  }

  searchReviewPlatformPage(data: any): Observable<any> {
    return this.http.post('/reviews/searchReviewPlatformPage', data);
  }

  getFacilityCitehealthReviews(data: any): Observable<any> {
    return this.http.get('/reviews/getFacilityCitehealthReviews', data);
  }

  searchGoogleReviewPlatformBusiness(data: any): Observable<any> {
    return this.http.post('/reviews/searchGoogleReviewPlatformBusiness', data);
  }

  getFacilityGoogleReviews(data: any): Observable<any> {
    return this.http.get('/reviews/getFacilityGoogleReviews', data);
  }

  getFacilityCaringReviews(data: any): Observable<any> {
    return this.http.get('/reviews/getFacilityCaringReviews', data);
  }

  searchCaringReviewPlatformPage(data: any): Observable<any> {
    return this.http.post('/reviews/searchCaringReviewPlatformPage', data);
  }

  getFacilitySeniorAdvisorReviews(data: any): Observable<any> {
    return this.http.get('/reviews/getFacilitySeniorAdvisorReviews', data);
  }

  searchSeniorAdvisorReviewPlatformPage(data: any): Observable<any> {
    return this.http.post('/reviews/searchSeniorAdvisorReviewPlatformPage', data);
  }

  getFacilityLocalNursingHomeReviews(data: any): Observable<any> {
    return this.http.get('/reviews/getFacilityLocalNursingHomeReviews', data);
  }

  searchLocalNursingHomeReviewPlatformPage(data: any): Observable<any> {
    return this.http.post('/reviews/searchLocalNursingHomeReviewPlatformPage', data);
  }

  searchNursingHomeSiteReviewPlatformPage(data: any): Observable<any> {
    return this.http.post('/reviews/searchNursingHomeSiteReviewPlatformPage', data);
  }

  searchFamilyAssetsReviewPlatformPage(data: any): Observable<any> {
    return this.http.post('/reviews/searchFamilyAssetsReviewPlatformPage', data);
  }

  getFacilityYelpReviews(data: any): Observable<any> {
    return this.http.get('/reviews/getFacilityYelpReviews', data);
  }

  searchYelpReviewPlatformPage(data: any): Observable<any> {
    return this.http.post('/reviews/searchYelpReviewPlatformPage', data);
  }

  getFacilitySuperPagesReviews(data: any): Observable<any> {
    return this.http.get('/reviews/getFacilitySuperPagesReviews', data);
  }

  searchSuperPagesReviewPlatformPage(data: any): Observable<any> {
    return this.http.post('/reviews/searchSuperPagesReviewPlatformPage', data);
  }

  getFacilityYellowPagesReviews(data: any): Observable<any> {
    return this.http.get('/reviews/getFacilityYellowPagesReviews', data);
  }

  searchYellowPagesReviewPlatformPage(data: any): Observable<any> {
    return this.http.post('/reviews/searchYellowPagesReviewPlatformPage', data);
  }

  getFacilityAgingCareReviews(data: any): Observable<any> {
    return this.http.get('/reviews/getFacilityAgingCareReviews', data);
  }

  searchAgingCareReviewPlatformPage(data: any): Observable<any> {
    return this.http.post('/reviews/searchAgingCareReviewPlatformPage', data);
  }

  getFacilityIndeedReviews(data: any): Observable<any> {
    return this.http.get('/reviews/getFacilityIndeedReviews', data);
  }

  searchIndeedReviewPlatformPage(data: any): Observable<any> {
    return this.http.post('/reviews/searchIndeedReviewPlatformPage', data);
  }

  getFacilityWellnessReviews(data: any): Observable<any> {
    return this.http.get('/reviews/getFacilityWellnessReviews', data);
  }

  searchWellnessReviewPlatformPage(data: any): Observable<any> {
    return this.http.post('/reviews/searchWellnessReviewPlatformPage', data);
  }

}
