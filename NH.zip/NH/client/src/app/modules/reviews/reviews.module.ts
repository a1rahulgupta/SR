import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
    PaginationModule
} from 'ngx-bootstrap';
import {
    ConfirmDialogModule,
    ConfirmationService,
    DialogModule,
    CalendarModule,
    TabViewModule
} from 'primeng/primeng';

import { ReviewsRoutingModule } from "./reviews-routing.module";
import { ReviewsListComponent } from "./../../modules/reviews/components/reviews_list.component";
import { ReviewsComponent } from "./reviews.component";



@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PaginationModule.forRoot(),
        ConfirmDialogModule,
        ReviewsRoutingModule,
        DialogModule,
        CalendarModule,
        TabViewModule
    ],
    declarations: [
        ReviewsComponent,
        ReviewsListComponent
    ],
    providers: [
        ConfirmationService
    ]
})
export class ReviewsModule { }