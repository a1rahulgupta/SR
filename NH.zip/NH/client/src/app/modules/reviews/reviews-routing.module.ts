import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";
import { ReviewsComponent } from "./reviews.component";
import { ReviewsListComponent } from "./../../modules/reviews/components/reviews_list.component";



const routes: Routes = [
    {
        path: '', 
        component: ReviewsComponent,
        children: [
            {
                path: '',
                component: ReviewsListComponent,
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ReviewsRoutingModule {

}