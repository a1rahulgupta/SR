import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";
import { AdmDashboardComponent } from "./components/adm_dashboard.component";
import { AdmProfileComponent } from "./components/adm_profile.component";
import { AdmUpdatePasswordComponent } from "./components/adm_updatepassword.component";
import { AdmComponent } from "./adm.component";


const routes: Routes = [
    {
        path: '', 
        component: AdmComponent,
        children: [
            {
                path: 'updatepassword',
                component: AdmUpdatePasswordComponent,
            },
            {
                path: 'dashboard',
                component: AdmDashboardComponent,
            },
            {
                path: 'profile',
                component: AdmProfileComponent,
            },
            {
                path: 'changePassword',
                component: AdmUpdatePasswordComponent,
            },
            {
                path: '',
                redirectTo:'dashboard',
                pathMatch:'full '
            }   

        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AdmRoutingModule {

}