import { Component } from "@angular/core";
import {
    Router, NavigationStart, NavigationCancel, NavigationEnd
} from '@angular/router';
import { AppConfig } from "../../../core/config/app.config";
import { WebStorage } from "../../../core/utility/web.storage";
import { AdminDashboardService } from "../services/adminDashboard.services";
import { ToastrService } from 'ngx-toastr';

@Component({
    selector: 'dashboard-component',
    preserveWhitespaces: false,
    templateUrl: './view/adm_dashboard.component.html',
    styleUrls: ['./css/dashboard.css'],
    providers: [
        AdminDashboardService
    ]
})
export class AdmDashboardComponent {
    totalCmpCount: any = 0;
    totalFacCount: any = 0;
    facCount: any = 0;    
    a: any;
    b: any;
    c: any;
    d: any;
    e: any;
    f: any;
    g: any;
    h: any;
    i: any;
    j: any;
    k: any;
    l: any;
    m: any;
    user: any;
    time: Date;
    prevNowPlaying: any;
    loading: any;
    body: object = {};
    selectPeriod: string = 'overAll';
    overAllRatingData: any[];
    overAllRatingLabelDate: any[];
    overAllRatingGraph: boolean = false;
    overAllData: {
        labels: string[];
        datasets: {
            data: string[];
            backgroundColor: string[];
            hoverBackgroundColor: string[];
        }[];
    };
    companyCount: any = 0;
    ratingReceivedCount: any = 0;
    complaintCount: any = 0;
    incidentCount: any = 0;
    resolvedIncidentPercentage: any = 0;
    resolvedComplaintPercentage: any = 0;
    public companyRecordRatingReceivedArray: any = [];
    public companyResolvedComplaintIncidentArray: any = [];
    public listOverAllLinkTracking: any = [];
    overAllLinkTrackingCount: any = 0;
    companyResponseRate: any = 0;
    public companyResponseRateArray: any = [];
    public companyRatingArray: any = [];
    negativeRatingCount: any = 0;
    positiveRatingCount: any = 0;
    constructor(
        private router: Router,
        private config: AppConfig,
        private storage: WebStorage,
        private adminDashboardService: AdminDashboardService,
        private toaster: ToastrService
    ) {
        this.loading = true;
    }

    public getSuperAdminDashboardCount(selectPeriod) {
        this.loading = true;
        this.body = {
            selectPeriod: selectPeriod,
            todayDate: new Date()
        }
        this.adminDashboardService.getSuperAdminDashboardCount(this.body).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.totalCmpCount = rs.data.totalCmpCount;
                this.totalFacCount = rs.data.totalFacCount;
                this.facCount = rs.data.facCount;
                this.companyCount = rs.data.cmpCount;
                this.ratingReceivedCount = rs.data.ratingReceivedCount;
                this.complaintCount = rs.data.complaintCount;
                this.incidentCount = rs.data.incidentCount;
                this.companyRecordRatingReceivedArray = rs.data.companyRecordRatingReceivedArray;
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
    }

    public getResolvedComplaintPercentageBySuperAdmin(selectPeriod) {
        this.loading = true;
        this.body = {
            selectPeriod: selectPeriod,
            todayDate: new Date()
        }
        this.adminDashboardService.getResolvedComplaintPercentageBySuperAdmin(this.body).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.resolvedComplaintPercentage = rs.data.resolvedComplaintPercentage;
                this.resolvedIncidentPercentage = rs.data.resolvedIncidentPercentage;
                this.companyResolvedComplaintIncidentArray = rs.data.companyResolvedComplaintIncidentArray;
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
    }

    public getResponseRateBySuperAdmin(selectPeriod) {
        this.loading = true;
        this.body = {
            selectPeriod: selectPeriod,
            todayDate: new Date()
        }
        this.adminDashboardService.getResponseRateBySuperAdmin(this.body).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.companyResponseRate = rs.data.companyResponseRate;
                this.companyResponseRateArray = rs.data.companyResponseRateArray;
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
    }

    public ratingBySuperAdmin(selectPeriod) {
        this.loading = true;
        this.body = {
            selectPeriod: selectPeriod,
            todayDate: new Date()
        }
        this.adminDashboardService.ratingBySuperAdmin(this.body).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.companyRatingArray = rs.data.companyRatingArray;
                this.positiveRatingCount = rs.data.positiveRatingCount;
                this.negativeRatingCount = rs.data.negativeRatingCount;
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
    }

    public linkTrackingBySuperAdmin(selectPeriod) {
        this.loading = false;
        this.body = {
            selectPeriod: selectPeriod,
            todayDate: new Date()
        }
        this.adminDashboardService.linkTrackingBySuperAdmin(this.body).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.listOverAllLinkTracking = rs.data.overAllLinkTrackingArray;
                this.overAllLinkTrackingCount = rs.data.overAllLinkTrackingCount;
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
    }

    public filterByPeriod(selectPeriod){
        this.getSuperAdminDashboardCount(selectPeriod);
        this.getResolvedComplaintPercentageBySuperAdmin(selectPeriod);
        this.getResponseRateBySuperAdmin(selectPeriod);
        this.ratingBySuperAdmin(selectPeriod);
        this.linkTrackingBySuperAdmin(selectPeriod);
    }
    
    public overAllRating(overAllRatingData, overAllRatingLabel) {
        if (overAllRatingData[0] != null) {
            this.overAllRatingGraph = true;
            this.overAllData = {
                labels: overAllRatingLabel,
                datasets: [
                    {
                        data: overAllRatingData,
                        backgroundColor: [
                            "#009688",
                            "#ff7043"
                        ],
                        hoverBackgroundColor: [
                            "#009688",
                            "#ff7043"
                        ]
                    }]
            };
        } else {
            this.overAllRatingGraph = false;
        }
    }

    public getOverAllRatingByAdmin() {
        this.loading = true;
        let overAllRatingArray = [];
        let overAllRatingLabel = [];
        this.adminDashboardService.getOverAllRatingByAdmin(this.body).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                overAllRatingLabel.push(rs.data.positiveRatingPercent + '%' + ' ' + 'Positive', rs.data.negativeRatingPercent + '%' + ' ' + 'Negative');
                overAllRatingArray.push(rs.data.positiveRatingPercent, rs.data.negativeRatingPercent);
                this.overAllRatingData = overAllRatingArray;
                this.overAllRatingLabelDate = overAllRatingLabel;
                this.overAllRating(this.overAllRatingData, this.overAllRatingLabelDate);
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
    }

    public ngOnInit(): void {
        this.user = this.storage.get(this.config.token.userKey);
        var stationdate = new Date();
        if (this.prevNowPlaying) {
            clearInterval(this.prevNowPlaying);
        }
        this.prevNowPlaying = setInterval(() => {
            stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
            this.time = stationdate;
        }, 1000);
        this.filterByPeriod('overAll');
        this.getOverAllRatingByAdmin();
    }

    ngAfterViewInit() {
        this.router.events
            .subscribe((event) => {
                if (event instanceof NavigationStart) {
                    this.loading = true;
                }
                else if (
                    event instanceof NavigationEnd ||
                    event instanceof NavigationCancel
                ) {
                    this.loading = false;
                }
            });
    }

}