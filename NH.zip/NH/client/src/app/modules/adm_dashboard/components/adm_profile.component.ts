import { Component, EventEmitter, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { UserService } from "./../../../core/services/user.services";
import { AppConfig } from "./../../../core/config/app.config";
import { Utills } from './../../../core/utility/utills';
import { requiredTrim } from "./../../../core/validators/validators";
import { WebStorage } from "./../../../core/utility/web.storage";
import { AuthService } from "../../../core/services/auth.service";
import { Socket } from 'ngx-socket-io';

@Component({
  selector: 'profile-component',
  templateUrl: './view/adm_profile.component.html',
  styleUrls: ['./css/profile.css'],
  providers: [
    UserService
  ]
})
export class AdmProfileComponent {
  display: boolean = false;
  showFileName: boolean = false;
  baseImage: Blob;
  fileNameData: any;
  file: any;
  role: any;
  userName: any;
  phone: any;
  time: Date;
  prevNowPlaying: any;
  public imagePath: any = '';
  imageChangedEvent: any = '';
  croppedImage: any = '';
  cropperReady = false;
  public profileFrm: FormGroup;
  public httpCall: any = false;

  constructor(
    private toaster: ToastrService,
    private user: UserService,
    private auth: AuthService,
    private router: Router,
    private socket: Socket,

    private activatedRoute: ActivatedRoute,
    public config: AppConfig,
    public utills: Utills,
    private storage: WebStorage,
    private formBuilder: FormBuilder
  ) {
    this.profileFrm = formBuilder.group({
      firstName: ['', [requiredTrim]],
      lastName: ['', [requiredTrim]],
      filename: [{ value: '', disabled: true }],
      email: ['', [requiredTrim, Validators.pattern(this.config.pattern.EMAIL)]],
      country_code: ['+1', [requiredTrim]],
      phoneNumber: ['', [requiredTrim, Validators.minLength(10), Validators.maxLength(10)]]
    });
  }
  fileChangeEvent(event: any): void {
    this.display = true;
    this.imageChangedEvent = event;
    let fileName = event.target.files[0];
    this.fileNameData = fileName.name;
  }
  imageLoaded() {
    this.cropperReady = true;
  }
  loadImageFailed() {
    this.display = false;
    this.toaster.error("You can upload only .jpg, .jpeg, .png file");
  }

  selectImage(action: any) {
    if (action == true) {
      this.imageLoaded();
      this.display = false;
    } else {
      this.display = false;
    }
  }

  public imageCropped(fileData: any) {
    this.croppedImage = fileData;
    let fileName = this.fileNameData;
    this.baseImage = this.utills.dataURItoBlob(fileData);
    let file = this.baseImage;
    let alowedSize = 1024 * 1024 * this.config.MaxUploadSixe;
    if (this.config.alowedFiletypes.indexOf(file.type) >= 0) {
      if (file.size <= alowedSize) {
        this.showFileName = true;
        this.profileFrm.controls['filename'].patchValue(fileName);
      } else {
        this.toaster.error("Please select a file within " + this.config.MaxUploadSixe + "MB");
      }
    } else {
      this.toaster.error("You can upload only .jpg, .jpeg, .png, .gif file");
    }
  }


  public save(fileData) {
    fileData = this.croppedImage;
    let fileName = this.fileNameData;
    let user = this.storage.get(this.config.token.userKey);
    let url = this.config.apiUrl + "/user/updateProfile";
    if (fileData != '') {
      this.baseImage = this.utills.dataURItoBlob(fileData);
      let file = this.baseImage;
      let alowedSize = 1024 * 1024 * this.config.MaxUploadSixe;
      if (this.config.alowedFiletypes.indexOf(file.type) >= 0) {
        if (file.size <= alowedSize) {
          this.httpCall = true;
          this.phone = this.profileFrm.value.country_code + this.profileFrm.value.phoneNumber;
          let formData = new FormData();
          formData.append("file", file, fileName);
          formData.append("_id", user.uid);
          formData.append("email", this.profileFrm.value.email);
          formData.append("firstName", this.profileFrm.value.firstName);
          formData.append("lastName", this.profileFrm.value.lastName);
          formData.append("phoneNumber", this.phone);
          this.xhrRequest(url, formData);
        } else {
          this.toaster.error("Please select a file within " + this.config.MaxUploadSixe + "MB");
        }
      } else {
        this.toaster.error("You can upload only .jpg, .jpeg, .png, .gif file");
      }
    } else {
      this.httpCall = true;
      this.phone = this.profileFrm.value.country_code + this.profileFrm.value.phoneNumber;
      let formData = new FormData();
      formData.append("_id", user.uid);
      formData.append("email", this.profileFrm.value.email);
      formData.append("lastName", this.profileFrm.value.lastName);
      formData.append("firstName", this.profileFrm.value.firstName);
      formData.append("phoneNumber", this.phone);
      this.xhrRequest(url, formData);
    }
  }

  public xhrRequest(url, formData) {
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          this.httpCall = false;
          let rs = JSON.parse(xhr.response);
          if (rs.code == this.config.statusCode.success) {
            this.toaster.success(rs.message);
            this.auth.refreshAdminProfileData.emit();
            this.router.navigate(['/admin']);
          } else {
            this.toaster.error(rs.message);
          }
        } else {
          this.httpCall = false;
          let rs = JSON.parse(xhr.response);
          if (rs.code == this.config.statusCode.success) {
            this.toaster.success(rs.message);
            this.auth.refreshAdminProfileData.emit();
            this.socket.emit('profile', rs.data);
            this.router.navigate(['/admin']);
          } else {
            this.toaster.error(rs.message);
          }
        }
      }
    }
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Authorization", "Bearer " + this.storage.get(this.config.token.keyID));
    xhr.send(formData);
  }

  public ngOnInit() {
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
    let user = this.storage.get(this.config.token.userKey);
    this.user.getProfile({ id: user.uid }).subscribe((result: any) => {
      var rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.userName = rs.data.userName;
        this.role = rs.data.role;
        var phoneNumber = rs.data.phoneNumber;
        rs.data.phoneNumber = phoneNumber.slice(-10);
        rs.data.country_code = phoneNumber.slice(0, -10);
        this.imagePath = 'assets/upload/profiles/' + rs.data.image;
        this.profileFrm.patchValue(rs.data);
      } else {
        this.toaster.error(rs.message);
      }
    });

  }
}


