
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '../../../core/utility/http.client';


@Injectable()
export class AdminDashboardService {
  constructor(
    private http: HttpClient
  ) { }

  /* Dashboard start */
  getOverAllRatingByAdmin(data: any): Observable<any> {
    return this.http.get('/superAdmin/getOverAllRatingByAdmin', data);
  }

  getSuperAdminDashboardCount(data: any): Observable<any> {
    return this.http.post('/superAdmin/getSuperAdminDashboardCount', data);
  }

  getResolvedComplaintPercentageBySuperAdmin(data: any): Observable<any> {
    return this.http.post('/superAdmin/getResolvedComplaintPercentageBySuperAdmin', data);
  }

  getResponseRateBySuperAdmin(data: any): Observable<any> {
    return this.http.post('/superAdmin/getResponseRateBySuperAdmin', data);
  }

  ratingBySuperAdmin(data: any): Observable<any> {
    return this.http.post('/superAdmin/ratingBySuperAdmin', data);
  }

  linkTrackingBySuperAdmin(data: any): Observable<any> {
    return this.http.post('/superAdmin/linkTrackingBySuperAdmin', data);
  }
  
  /* Dashboard end */

}

