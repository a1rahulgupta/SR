
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdmProfileComponent } from './components/adm_profile.component';
import { AdmUpdatePasswordComponent } from './components/adm_updatepassword.component';
import { AdmDashboardComponent } from './components/adm_dashboard.component';
import { AdmComponent } from './adm.component';
import { AdmRoutingModule } from './adm-routing.module';
import { ImageCropperModule } from 'ngx-image-cropper';
import { DialogModule, AccordionModule, ChartModule } from 'primeng/primeng';
import { CountoModule }  from 'angular2-counto';

@NgModule({
    imports: [
        CommonModule, 
        FormsModule, 
        ReactiveFormsModule,
        AdmRoutingModule,
        ImageCropperModule,
        DialogModule,
        AccordionModule,
        ChartModule,
        CountoModule
    ],
    declarations: [
        AdmComponent,
        AdmDashboardComponent,
        AdmUpdatePasswordComponent,
        AdmProfileComponent
    ],
    providers: []
})
export class AdmDashboardModule { }