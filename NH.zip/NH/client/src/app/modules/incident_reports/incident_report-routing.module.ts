import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";
import { IncidentReportsComponent } from "./incident_reports.component";
import { IncidentReportsEditComponent } from "./components/edit_incident_reports.component";
import { IncidentReportsListComponent } from "./components/incedent_reports_list.component";
import { EmployeeIncidentReportsListComponent } from "./components/employee_incident_reports_list.component";
import { OpenIncidentListComponent } from "./components/open_incedent_list.component";
import { ResolvedIncidentListComponent } from "./components/resolved_incedent_list.component";
import { SettingIncidentComponent } from "./components/setting_incedent.component";

const routes: Routes = [
    {
        path: '', 
        component: IncidentReportsComponent,
        children: [
            {
                path: '',
                component: IncidentReportsListComponent,
            },
            {
                path: 'employeeIncidentList',
                component: EmployeeIncidentReportsListComponent,
            },
            {
                path: 'edit/:id',
                component: IncidentReportsEditComponent,
            },
            {
                path: 'openIncident',
                component: OpenIncidentListComponent,
            },
            {
                path: 'resolvedIncident',
                component: ResolvedIncidentListComponent,
            },
            {
                path: 'settingIncident',
                component: SettingIncidentComponent,
            },

        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class IncidentReportsRoutingModule {

}