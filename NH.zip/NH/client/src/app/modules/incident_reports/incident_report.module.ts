import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
    PaginationModule
} from 'ngx-bootstrap';
import {
    ConfirmDialogModule,
    ConfirmationService,
    DialogModule,
    CalendarModule,
    CheckboxModule,
    ChipsModule
} from 'primeng/primeng';

import { MultiSelectModule } from 'primeng/primeng';
import { IncidentReportsComponent } from "./incident_reports.component";
import { IncidentReportsListComponent } from "./components/incedent_reports_list.component";
import { IncidentReportsEditComponent } from "./components/edit_incident_reports.component";
import { IncidentReportsRoutingModule } from "./incident_report-routing.module";
import { AssignIncidentEmployeeComponent } from "./components/assignIncidentEmployee.component";
import { EmployeeIncidentReportsListComponent } from "./components/employee_incident_reports_list.component";
import { PopoverModule } from "ngx-popover";
import { OpenIncidentListComponent } from "./components/open_incedent_list.component";
import { ResolvedIncidentListComponent } from "./components/resolved_incedent_list.component";
import { SettingIncidentComponent } from "./components/setting_incedent.component";
import { AngularDraggableModule } from "angular2-draggable";


@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PaginationModule.forRoot(),
        ConfirmDialogModule,
        IncidentReportsRoutingModule,
        MultiSelectModule,
        DialogModule,
        CalendarModule,
        CheckboxModule,
        PopoverModule,
        ChipsModule,
        AngularDraggableModule
    ],
    declarations: [
        IncidentReportsComponent,
        IncidentReportsListComponent,
        IncidentReportsEditComponent,
        AssignIncidentEmployeeComponent,
        EmployeeIncidentReportsListComponent,
        OpenIncidentListComponent,
        ResolvedIncidentListComponent,
        SettingIncidentComponent
    ],
    providers: [
        ConfirmationService
    ]
})
export class IncidentReportModule { }