import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '../../../core/utility/http.client';


@Injectable()
export class IncidentReportsService {
  constructor(
    private http: HttpClient
  ) { }

  incidentReportsList(data: any): Observable<any> {
    return this.http.post('/visitor/incidentReportsList', data);
  }
  getOpenIncidentReportsList(data: any): Observable<any> {
    return this.http.post('/visitor/getOpenIncidentReportsList', data);
  }
  getResolvedIncidentReportsList(data: any): Observable<any> {
    return this.http.post('/visitor/getResolvedIncidentReportsList', data);
  }
  getEditIncidentRecord(data: any): Observable<any> {
    return this.http.post('/visitor/getEditIncidentRecord', data);
  }
  employeeIncidentReportsList(data: any): Observable<any> {
    return this.http.post('/visitor/employeeIncidentReportsList', data);
  }
  editIncidentReports(data: any): Observable<any> {
    return this.http.post('/visitor/editIncidentReports', data);
  }
  exportXml(data: any): Observable<any> {
    return this.http.post('/company/exportXml', data);
  }
  assignIncidentToEmployee(data: any): Observable<any> {
    return this.http.post('/visitor/assignIncidentToEmployee', data);
  }
  acceptIncidentByEmployee(data: any): Observable<any> {
    return this.http.post('/visitor/acceptIncidentByEmployee', data);
  }
  getIncidentNotes(data: any): Observable<any> {
    return this.http.post('/visitor/getIncidentNotes', data);
  }

  addIncidentNote(data: any): Observable<any> {
    return this.http.post('/visitor/addIncidentNote', data);
  }

  updateCustomIncidentSetting(data: any): Observable<any> {
    return this.http.post('/visitor/updateCustomIncidentSetting', data);
  }

  getSettingIncident(data: any): Observable<any> {
    return this.http.post('/visitor/getSettingIncident', data);
  }
  

}
