import { Component, Inject, Output, ViewChild, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import { IncidentReportsService } from "../services/incident_reports.services";
import { EmployeeService } from "../../employee/services/employee.services";
import { WebStorage } from '../../../core/utility/web.storage';
import { IncidentReportsEditComponent } from "./edit_incident_reports.component";
import { AssignIncidentEmployeeComponent } from "./assignIncidentEmployee.component";

type AOA = Array<Array<any>>;

@Component({
  selector: 'app-open-incident_list',
  preserveWhitespaces: false,
  templateUrl: './view/open_incident_list.view.html',
  styles: [`
  :host >>> .popover {
    color: #FFFFFF;
    background: #000000;
  
  }
 
`],
  providers: [
    IncidentReportsService,
    EmployeeService
  ]
})
export class OpenIncidentListComponent {
  kioskMode: boolean;
  assignIncidentDialoge: boolean;
  @ViewChild('IncidentReportsEditComponent')
  private IncidentReportsEditComponent: IncidentReportsEditComponent;
  @ViewChild('AssignIncidentEmployeeComponent')
  private AssignIncidentEmployeeComponent: AssignIncidentEmployeeComponent;
  incidentEditViewDialoge: boolean;
  commingsoon: boolean;
  time: Date;
  prevNowPlaying: any;
  employeeViewDialoge: boolean;
  display: boolean;
  public openIncidentData: any = [];
  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private IncidentService: IncidentReportsService,
    private employee: EmployeeService,
    private router: Router,
    private utills: Utills,
    private storage: WebStorage,
    private tmpStorage: TmpStorage,
    private confirmationService: ConfirmationService,

  ) {
  }

  public asc: string = 'asc';
  public loading: boolean = true;
  public exportfile: string = '';
  public totalItems: number = 0;
  public body: any = {
    'page': 1,
    'count': this.config.perPageDefault,
    'searchText': '',
    'createdAt': '',
    'firstName': '',
    'lastName': '',
    'sorting': 'createdAt',
    'order': 'asc',
  };

  public sort(field: string, order: any): void {
    if (order == 'asc') {
      this.asc = 'asc';
    } else {
      this.asc = 'desc';
    }
    this.body.sorting = field;
    this.body.order = order;
    this.getOpenIncidentReportsList();
  }

    public exportAll(exportfile) {
    if (exportfile == 'xls') {
      this.exportXls();
    } else if (exportfile == 'json') {
      this.exportJson();
    } else if (exportfile == 'csv') {
      this.createCsvFile();
    } else if (exportfile == 'txt') {
      this.exportTxt();
    } else if (exportfile == 'xml') {
      this.exportXml();
    }
  }
  public exportXls(): void {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to excel?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        let wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
        let fileName: string = 'Incident_Reports_' + new Date().getTime() + '.xlsx';
        let data: AOA = [
          [
            "Incident Type",
            "Created",
            "Regarding",
            "Concern",
            "Department",
            "Resolved"
          ]
        ];

        this.openIncidentData.map((item: any) => {
          data.push([
            item.incidentType,
            item.createdAt,
            item.firstName + item.lastName,
            item.Concern,
            item.department,
            item.resolved
          ]);
        });

        const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(data);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
        const wbout: ArrayBuffer = XLSX.write(wb, wopts);
        saveAs(new Blob([wbout], { type: 'application/octet-stream' }), fileName);
      },
      reject: () => {
      }
    });
  }

  public exportJson() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to json file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.openIncidentData.length; i++) {
          data.push({
            'Incident Type': this.openIncidentData[i].incidentType,
            'Created': this.openIncidentData[i].createdAt,
            'Regarding': this.openIncidentData[i].firstName + this.openIncidentData[i].lastName,
            'Concern': this.openIncidentData[i].concern,
            'Department': this.openIncidentData[i].department,
            'Resolved': this.openIncidentData[i].resolved,
          });
        }
        var textToSave = JSON.stringify({ "header": [["Incident Type", "Created", "Created ", "Regarding", "Concern", "Department", "Resolved"]], "data": data }),
          filename = 'file.json',
          blob = new Blob([textToSave], { type: "'application/json; charset=utf-8'" });

        saveAs(blob, filename);
      },
      reject: () => {
      }
    });
  }

  public createCsvFile() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to csv file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        var options = {
          fieldSeparator: ',',
          quoteStrings: '"',
          decimalseparator: '.',
          showLabels: true,
          showTitle: true,
          useBom: true
        };
        for (let i = 0; i < this.openIncidentData.length; i++) {
          data.push({
            'Incident Type': this.openIncidentData[i].incidentType,
            'Created': this.openIncidentData[i].createdAt,
            'Regarding': this.openIncidentData[i].firstName + this.openIncidentData[i].lastName,
            'Concern': this.openIncidentData[i].concern,
            'Department': this.openIncidentData[i].department,
            'Resolved': this.openIncidentData[i].resolved,
          });
        }
        new Angular2Csv(data, 'openIncidentData', { headers: Object.keys(data[0]) });
      },
      reject: () => {
      }
    });
  }
  
   public editOpenIncidentReport(incidentData) {
    this.IncidentService.getEditIncidentRecord(incidentData).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
          var getData = rs.data.data[0];
          this.IncidentReportsEditComponent.getProfileData(getData);
          this.incidentEditViewDialoge = true;
      } else {
        this.toaster.error(rs.message);
      }
    });

  }

  closeIncidentDialoge() {
    this.incidentEditViewDialoge = false;
  }
  
  public exportTxt() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to text file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.openIncidentData.length; i++) {
          data.push({
            'Incident Type': this.openIncidentData[i].incidentType,
            'Created': this.openIncidentData[i].createdAt,
            'Regarding': this.openIncidentData[i].firstName + this.openIncidentData[i].lastName,
            'Concern': this.openIncidentData[i].concern,
            'Department': this.openIncidentData[i].department,
            'Resolved': this.openIncidentData[i].resolved,
          });
        }
        var obj = objectToString(data);
        function objectToString(obj) {
          var str = '';
          var i = 0;
          for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
              if (typeof obj[key] == 'object') {
                {
                  str += key + ' : { ' + objectToString(obj[key]) + '} ' + (i > 0 ? ',' : '');
                }
              }
              else {
                str += key + ':\'' + obj[key] + '\'' + (i > 0 ? ',' : '');
              }
              i++;
            }
          }
          return str;
        }
        var textToSave = obj,
          filename = 'file.txt',
          blob = new Blob([textToSave], { type: "text/plain;charset=utf-8" });
        saveAs(blob, filename);
      },
      reject: () => {
      }
    });
  }

   public exportXml() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to Xml file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.openIncidentData.length; i++) {
          data.push({
            'id': this.openIncidentData[i]._id,
            'column-1': this.openIncidentData[i].incidentType,
            'column-2': this.openIncidentData[i].createdAt,
            'column-3': this.openIncidentData[i].firstName + this.openIncidentData[i].lastName,
            'column-4': this.openIncidentData[i].concern,
            'column-5': this.openIncidentData[i].department,
            'column-6': this.openIncidentData[i].resolved
          });

        }
        var obj = JSON.stringify(
          {
            "_declaration": {
              "_attributes": {
                "version": "1.0",
                "encoding": "utf-8"
              }
            },
            "tabledata": {
              "field": [
                [],
                "Incident Type",
                "Created",
                "Regarding",
                "Concern",
                "Department",
                "Resolved"
              ],
              "data": {
                "row": data
              }
            }
          }
        )
        this.IncidentService.exportXml(obj).subscribe((result) => {
          let rs = result.json();
          var textToSave = rs.data,
            filename = 'file.xml',
            blob = new Blob([textToSave], { type: "'application/xml charset=utf-8'" });
          saveAs(blob, filename);
        })
      },
      reject: () => {
      }
    });

  }

  public resetSearch(): void {
    this.body.userName = '';
    this.body.phoneNumber = '';
    this.body.createdAt = '';
    this.getOpenIncidentReportsList()
  }

  public showDialog() {
    this.display = true;
  }

  public pageChanged(event: any): void {
    this.body.page = event.page;
    this.getOpenIncidentReportsList();
  }

  public changePageLimit(pageLimit: any) {
    this.body.limit = pageLimit;
    this.getOpenIncidentReportsList();
  }

  public getOpenIncidentReportsList() {
    this.loading = true;
    this.IncidentService.getOpenIncidentReportsList(this.body).subscribe((result) => {
      let rs = result.json();
      console.log("Open Incident Reports List Response", rs);
      if (rs.code == this.config.statusCode.success) {
        this.openIncidentData = rs.data.data;
        this.totalItems = rs.data.total_count;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  public assignIncidentReport(id, assignStatus, empAccept) {
    console.log(".id, assignStatus, empAccept..................",id, assignStatus, empAccept)
    if (assignStatus == true && empAccept == '') {
      this.toaster.error("This Incident is Already Assigned. ");
    } else if (assignStatus == true && empAccept == '1') {
      this.toaster.error("This Incident is Already Assigned. ");
    } else {
      console.log("assignIncidentReport---");
      var getData = id;
      console.log("assignIncidentReport---", id);
      this.AssignIncidentEmployeeComponent.getIncidentId(id);
      this.assignIncidentDialoge = true;
    }
  }

  closeAssignDialoge() {
    this.assignIncidentDialoge = false;
    this.getOpenIncidentReportsList();
  }

  public ngOnInit(): void {

    this.getOpenIncidentReportsList();
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);

  }

}
