import { Component,Inject, Output,ViewChild, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { TmpStorage } from "../../../core/utility/temp.storage";
import { requiredTrim } from "../../../core/validators/validators";
import { IncidentReportsService } from "../services/incident_reports.services";


@Component({
  selector: 'app-incident-report-edit',
  preserveWhitespaces: false,
  templateUrl: './view/incident_reports_edit.view.html',
  providers: [
    IncidentReportsService
  ]
})
export class IncidentReportsEditComponent {
  resolved: true;
  profileInfo: any;
  @Output('onClose') onClose = new EventEmitter<any>();
  time: Date;
  prevNowPlaying: any;
  public httpCall: any = false;
  public incidentFrm: FormGroup;

  constructor(
    private toaster: ToastrService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private IncidentService: IncidentReportsService,
    public config: AppConfig,
    private formBuilder: FormBuilder,
    private utills: Utills,
    private tmpStorage: TmpStorage
  ) {
    this.incidentFrm = formBuilder.group({
      firstName: ['', [requiredTrim]],
      lastName: ['', [requiredTrim]],
      concern:['', [requiredTrim]],
      department:['', [requiredTrim]],
      resolved: [''],
      incidentType: ['',[requiredTrim]],
      subject : ['', [requiredTrim]],
      notes : [''], 
      employeeNotes : [''], 
      adminNotes : [''],       
      visitedTo: ['',[requiredTrim]],
      incidentTime : ['',[requiredTrim]],
      resolutionNotes : [''],
      resolvedDate: ['']
    });
  }

incidentResolved(value){
  this.incidentFrm.value.resolved = value;
}

  public save() {
    this.httpCall = true;
    let data = this.incidentFrm.value;
     data.visitorId = this.profileInfo.visitorId;
     data.incidentTime = this.profileInfo.incidentTime;
     data._id = this.profileInfo._id;
     if(this.incidentFrm.value.resolved == true){
       data.resolved = true;
       data.resolvedDate = new Date(); 
     } else{
       data.resolved = false
     }
    this.IncidentService.editIncidentReports(data).subscribe((result: any) => {
      this.httpCall = false;
      var rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.toaster.success(rs.message);
        this.onClose.emit();
        this.incidentFrm.reset();
      } else {
        this.toaster.error(rs.message);
      }
    });
  }
  
resetForm(){
  this.onClose.emit();
  this.incidentFrm.reset();
}

getProfileData(getData) {
    this.profileInfo = getData;
    var incidentTime = getData.incidentTime;
    getData.incidentTime = new Date(getData.incidentTime);
    this.incidentFrm.patchValue(this.profileInfo);
    this.resolved = getData.resolved;
}

public ngOnInit(): void {
}

}
