import { Component, Inject, Output, ViewChild, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';
import { EmployeeService } from "../../employee/services/employee.services";
import { IncidentReportsService } from "../services/incident_reports.services";
import { WebStorage } from '../../../core/utility/web.storage';

@Component({
  selector: 'app-assign-incident',
  preserveWhitespaces: false,
  templateUrl: './view/assignIncidentEmployee.view.html',
  providers: [
    EmployeeService
  ]
})
export class AssignIncidentEmployeeComponent {
  user: any;
  employeeId: string;
  incidentNote: string = '';
  employeeAssignmentDialoge: boolean = false;
  IncidentId: any;
@Output('onClose') onClose = new EventEmitter<any>();
  public listData: any = [];
  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private employee: EmployeeService,
    private IncidentService: IncidentReportsService,
    private router: Router,
    private utills: Utills,
    private tmpStorage: TmpStorage,
    private confirmationService: ConfirmationService,
    private storage: WebStorage,
    
  ) {
   }

  /*------------------ Listing Elements --------------------*/
  public asc: string = 'asc';
  public loading: boolean = true;
  public exportfile: string = '';
  // public columnOptions: SelectItem = [];
  public totalItems: number = 0;
  public body: any = {
    'page': 1,
    'count': this.config.perPageDefault,
    'searchText': '',
    'phoneNumber':'',
    'userName':'',
    'createdAt':'',
    'sorting': 'createdAt',
    'order': 'asc',
  };

  getIncidentId(getId) {
    this.IncidentId = getId;
    console.log("getIncidentId-----",getId);
  }


  public setRecordPerPage(records: number): void {
    this.body.page = 1;
    this.body.limit = records;
    this.getAll();
  }


  public sort(field: string, order: any): void {
    if (order == 'asc') {
      this.asc = 'asc';
    } else {
      this.asc = 'desc';
    }
    this.body.sorting = field;
    this.body.order = order;
    this.getAll();
  }

  public pageChanged(event: any): void {
    this.body.page = event.page;
    this.getAll();
  }

  public resetSearch(): void {
    this.body.userName = '';
    this.body.phoneNumber = '';
    this.body.createdAt = '';
    this.getAll()
  }

  public changePageLimit(pageLimit: any) {
    this.body.limit = pageLimit;
    this.getAll()
  }


  public getAll() {
    this.loading = true;
    this.employee.getAllEmployeeList(this.body).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.listData = rs.data.data;
        this.totalItems = rs.data.total_count;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }
  /*------------------ Listing Elements --------------------*/

  // public assignIncidentToEmployee(_id: string) {
  //   this.confirmationService.confirm({
  //     message: 'Are you sure that you want to assign?',
  //     header: 'Confirmation',
  //     icon: 'fa fa-question-circle',
  //     accept: () => {
  //       this.IncidentService.assignIncidentToEmployee({ employeeId: _id, incidentId: this.IncidentId  }).subscribe((result) => {
  //         let rs = result.json();
  //         if (rs.code == this.config.statusCode.success) {
  //           this.onClose.emit();
  //           this.toaster.success(rs.message);
  //         } else {
  //           this.toaster.error(rs.message);
  //         }
  //         this.loading = false;
  //       });
  //     },
  //     reject: () => {
  //     }
  //   });
  // }

  public assignIncidentToEmployee(id: string) {
    this.loading = true;
    let assignObj = {
      employeeId: id, 
      incidentId: this.IncidentId, 
      incidentNote: this.incidentNote,
      noteAddedById: this.user.uid
    }
    this.IncidentService.assignIncidentToEmployee(assignObj).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.employeeAssignmentDialoge = false;
        this.onClose.emit();
        this.toaster.success(rs.message);
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }
  
  public assignIncidentToEmployeeDialogue(id: string){
    this.employeeId = id;
    this.employeeAssignmentDialoge = true;
  }

  
  public ngOnInit(): void {
    let user = this.storage.get(this.config.token.userKey);
    this.user = user;
    this.getAll();
  }

}
