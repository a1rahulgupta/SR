import { Component, Inject, Output, ViewChild, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import { IncidentReportsService } from "../services/incident_reports.services";
import { EmployeeService } from "../../employee/services/employee.services";
import { WebStorage } from '../../../core/utility/web.storage';
type AOA = Array<Array<any>>;

@Component({
  selector: 'app-setting-incident',
  preserveWhitespaces: false,
  templateUrl: './view/setting_incident.view.html',
  styles: [`
  :host >>> .popover {
    color: #FFFFFF;
    background: #000000;
  
  }
 
`],
  providers: [
    IncidentReportsService,
    EmployeeService
  ]
})
export class SettingIncidentComponent {
  kioskMode: boolean;
  assignIncidentDialoge: boolean;
  incidentEditViewDialoge: boolean;
  commingsoon: boolean;
  time: Date;
  prevNowPlaying: any;
  employeeViewDialoge: boolean;
  display: boolean;
  public resolvedIncidentData: any = [];
  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private IncidentService: IncidentReportsService,
    private employee: EmployeeService,
    private router: Router,
    private utills: Utills,
    private storage: WebStorage,
    private tmpStorage: TmpStorage,
    private confirmationService: ConfirmationService,

  ) {
  }

  public asc: string = 'asc';
  public loading: boolean = true;
  public exportfile: string = '';
  public totalItems: number = 0;
  public body: any = {
    'page': 1,
    'count': this.config.perPageDefault,
    'searchText': '',
    'createdAt': '',
    'firstName': '',
    'lastName': '',
    'sorting': 'createdAt',
    'order': 'asc',
  };

  public ngOnInit(): void {
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
  
  }



}
