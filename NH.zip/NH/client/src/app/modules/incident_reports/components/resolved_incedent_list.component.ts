import { Component, Inject, Output, ViewChild, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import { IncidentReportsService } from "../services/incident_reports.services";
import { EmployeeService } from "../../employee/services/employee.services";
import { WebStorage } from '../../../core/utility/web.storage';
type AOA = Array<Array<any>>;

@Component({
  selector: 'app-resolved-incident_list',
  preserveWhitespaces: false,
  templateUrl: './view/resolved_incident_list.view.html',
  styles: [`
  :host >>> .popover {
    color: #FFFFFF;
    background: #000000;
  
  }
 
`],
  providers: [
    IncidentReportsService,
    EmployeeService
  ]
})
export class ResolvedIncidentListComponent {
  kioskMode: boolean;
  assignIncidentDialoge: boolean;
  incidentEditViewDialoge: boolean;
  commingsoon: boolean;
  time: Date;
  prevNowPlaying: any;
  employeeViewDialoge: boolean;
  display: boolean;
  public resolvedIncidentData: any = [];
  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private IncidentService: IncidentReportsService,
    private employee: EmployeeService,
    private router: Router,
    private utills: Utills,
    private storage: WebStorage,
    private tmpStorage: TmpStorage,
    private confirmationService: ConfirmationService,

  ) {
  }

  public asc: string = 'asc';
  public loading: boolean = true;
  public exportfile: string = '';
  public totalItems: number = 0;
  public body: any = {
    'page': 1,
    'count': this.config.perPageDefault,
    'searchText': '',
    'createdAt': '',
    'firstName': '',
    'lastName': '',
    'sorting': 'createdAt',
    'order': 'asc',
  };

  public sort(field: string, order: any): void {
    if (order == 'asc') {
      this.asc = 'asc';
    } else {
      this.asc = 'desc';
    }
    this.body.sorting = field;
    this.body.order = order;
    this.getResolvedIncidentReportsList();
  }

  public exportAll(exportfile) {
    if (exportfile == 'xls') {
      this.exportXls();
    } else if (exportfile == 'json') {
      this.exportJson();
    } else if (exportfile == 'csv') {
      this.createCsvFile();
    } else if (exportfile == 'txt') {
      this.exportTxt();
    } else if (exportfile == 'xml') {
      this.exportXml();
    }
  }
  public exportXls(): void {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to excel?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        let wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
        let fileName: string = 'Incident_Reports_' + new Date().getTime() + '.xlsx';
        let data: AOA = [
          [
            "Incident Type",
            "Created",
            "Regarding",
            "Concern",
            "Department",
            "Resolved"
          ]
        ];

        this.resolvedIncidentData.map((item: any) => {
          data.push([
            item.incidentType,
            item.createdAt,
            item.firstName + item.lastName,
            item.Concern,
            item.department,
            item.resolved
          ]);
        });

        const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(data);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
        const wbout: ArrayBuffer = XLSX.write(wb, wopts);
        saveAs(new Blob([wbout], { type: 'application/octet-stream' }), fileName);
      },
      reject: () => {
      }
    });
  }

  public exportJson() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to json file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.resolvedIncidentData.length; i++) {
          data.push({
            'Incident Type': this.resolvedIncidentData[i].incidentType,
            'Created': this.resolvedIncidentData[i].createdAt,
            'Regarding': this.resolvedIncidentData[i].firstName + this.resolvedIncidentData[i].lastName,
            'Concern': this.resolvedIncidentData[i].concern,
            'Department': this.resolvedIncidentData[i].department,
            'Resolved': this.resolvedIncidentData[i].resolved,
          });
        }
        var textToSave = JSON.stringify({ "header": [["Incident Type", "Created", "Created ", "Regarding", "Concern", "Department", "Resolved"]], "data": data }),
          filename = 'file.json',
          blob = new Blob([textToSave], { type: "'application/json; charset=utf-8'" });

        saveAs(blob, filename);
      },
      reject: () => {
      }
    });
  }

  public createCsvFile() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to csv file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        var options = {
          fieldSeparator: ',',
          quoteStrings: '"',
          decimalseparator: '.',
          showLabels: true,
          showTitle: true,
          useBom: true
        };
        for (let i = 0; i < this.resolvedIncidentData.length; i++) {
          data.push({
            'Incident Type': this.resolvedIncidentData[i].incidentType,
            'Created': this.resolvedIncidentData[i].createdAt,
            'Regarding': this.resolvedIncidentData[i].firstName + this.resolvedIncidentData[i].lastName,
            'Concern': this.resolvedIncidentData[i].concern,
            'Department': this.resolvedIncidentData[i].department,
            'Resolved': this.resolvedIncidentData[i].resolved,
          });
        }
        new Angular2Csv(data, 'resolvedIncidentData', { headers: Object.keys(data[0]) });
      },
      reject: () => {
      }
    });
  }

  public exportTxt() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to text file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.resolvedIncidentData.length; i++) {
          data.push({
            'Incident Type': this.resolvedIncidentData[i].incidentType,
            'Created': this.resolvedIncidentData[i].createdAt,
            'Regarding': this.resolvedIncidentData[i].firstName + this.resolvedIncidentData[i].lastName,
            'Concern': this.resolvedIncidentData[i].concern,
            'Department': this.resolvedIncidentData[i].department,
            'Resolved': this.resolvedIncidentData[i].resolved,
          });
        }
        var obj = objectToString(data);
        function objectToString(obj) {
          var str = '';
          var i = 0;
          for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
              if (typeof obj[key] == 'object') {
                {
                  str += key + ' : { ' + objectToString(obj[key]) + '} ' + (i > 0 ? ',' : '');
                }
              }
              else {
                str += key + ':\'' + obj[key] + '\'' + (i > 0 ? ',' : '');
              }
              i++;
            }
          }
          return str;
        }
        var textToSave = obj,
          filename = 'file.txt',
          blob = new Blob([textToSave], { type: "text/plain;charset=utf-8" });
        saveAs(blob, filename);
      },
      reject: () => {
      }
    });
  }

   public exportXml() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to Xml file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.resolvedIncidentData.length; i++) {
          data.push({
            'id': this.resolvedIncidentData[i]._id,
            'column-1': this.resolvedIncidentData[i].incidentType,
            'column-2': this.resolvedIncidentData[i].createdAt,
            'column-3': this.resolvedIncidentData[i].firstName + this.resolvedIncidentData[i].lastName,
            'column-4': this.resolvedIncidentData[i].concern,
            'column-5': this.resolvedIncidentData[i].department,
            'column-6': this.resolvedIncidentData[i].resolved
          });

        }
        var obj = JSON.stringify(
          {
            "_declaration": {
              "_attributes": {
                "version": "1.0",
                "encoding": "utf-8"
              }
            },
            "tabledata": {
              "field": [
                [],
                "Incident Type",
                "Created",
                "Regarding",
                "Concern",
                "Department",
                "Resolved"
              ],
              "data": {
                "row": data
              }
            }
          }
        )
        this.IncidentService.exportXml(obj).subscribe((result) => {
          let rs = result.json();
          var textToSave = rs.data,
            filename = 'file.xml',
            blob = new Blob([textToSave], { type: "'application/xml charset=utf-8'" });
          saveAs(blob, filename);
        })
      },
      reject: () => {
      }
    });

  }

  public showDialog() {
    this.display = true;
  }

  public resetSearch(): void {
    this.body.userName = '';
    this.body.phoneNumber = '';
    this.body.createdAt = '';
    this.getResolvedIncidentReportsList()
  }
  public pageChanged(event: any): void {
    this.body.page = event.page;
    this.getResolvedIncidentReportsList();
  }

  public changePageLimit(pageLimit: any) {
    this.body.limit = pageLimit;
    this.getResolvedIncidentReportsList();
  }

  public getResolvedIncidentReportsList() {
    this.loading = true;
    this.IncidentService.getResolvedIncidentReportsList(this.body).subscribe((result) => {
      let rs = result.json();
      console.log("Resolved Incident Reports List Response", rs);
      if (rs.code == this.config.statusCode.success) {
        this.resolvedIncidentData = rs.data.data;
        this.totalItems = rs.data.total_count;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }


  public ngOnInit(): void {

    this.getResolvedIncidentReportsList();
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);

  }



}
