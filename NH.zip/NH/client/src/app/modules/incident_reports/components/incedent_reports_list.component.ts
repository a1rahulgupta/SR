import { Component, Inject, Output, ViewChild, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import { IncidentReportsService } from "../services/incident_reports.services";
import { IncidentReportsEditComponent } from "./edit_incident_reports.component";
import { EmployeeService } from "../../employee/services/employee.services";
import { AssignIncidentEmployeeComponent } from "./assignIncidentEmployee.component";
import { WebStorage } from '../../../core/utility/web.storage';
type AOA = Array<Array<any>>;

@Component({
  selector: 'app-incident_reports_list',
  preserveWhitespaces: false,
  templateUrl: './view/incident_reports_list.view.html',
  styles: [`
  :host >>> .popover {
    color: #FFFFFF;
    background: #000000;
  }
 
`],
  providers: [
    IncidentReportsService,
    EmployeeService
  ]
})
export class IncidentReportsListComponent {
  @ViewChild('messgBx') txtArea: any;
  appMessage: any;
  user: any;
  incidentNotes: any = [];
  incident: object;
  chatBoxShow: boolean = false;
  kioskMode: boolean;
  assignIncidentDialoge: boolean;
  incidentEditViewDialoge: boolean;
  @ViewChild('IncidentReportsEditComponent')
  private IncidentReportsEditComponent: IncidentReportsEditComponent;
  @ViewChild('AssignIncidentEmployeeComponent')
  private AssignIncidentEmployeeComponent: AssignIncidentEmployeeComponent;
  commingsoon: boolean;
  settingDialog: boolean;
  time: Date;
  prevNowPlaying: any;
  employeeViewDialoge: boolean;
  display: boolean;
  public listData: any = [];

  incidentSettingObj: any = {
        openIncident: {
            "status": false,
            "period": '',
            "phoneNumber": '',
            "emailsArray": []
        },
        updateResolvedIncident: {
            "status": false,
            "phoneNumber": '',
            "emailsArray": []
        }
    };

  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private IncidentService: IncidentReportsService,
    private employee: EmployeeService,
    private router: Router,
    private utills: Utills,
    private storage: WebStorage,
    private tmpStorage: TmpStorage,
    private confirmationService: ConfirmationService,
  ) {
  }

  /*------------------ Listing Elements --------------------*/
  public asc: string = 'asc';
  public loading: boolean = true;
  public exportfile: string = '';
  // public columnOptions: SelectItem = [];
  public totalItems: number = 0;
  public body: any = {
    'page': 1,
    'count': this.config.perPageDefault,
    'searchText': '',
    'createdAt': '',
    'firstName': '',
    'lastName': '',
    'sorting': 'createdAt',
    'order': 'asc',
  };

  public setRecordPerPage(records: number): void {
    this.body.page = 1;
    this.body.limit = records;
    this.getAllIncidentReports();
  }

  public sort(field: string, order: any): void {
    if (order == 'asc') {
      this.asc = 'asc';
    } else {
      this.asc = 'desc';
    }
    this.body.sorting = field;
    this.body.order = order;
    this.getAllIncidentReports();
  }

  public pageChanged(event: any): void {
    this.body.page = event.page;
    this.getAllIncidentReports();
  }

  public resetSearch(): void {
    this.body.userName = '';
    this.body.phoneNumber = '';
    this.body.createdAt = '';
    this.getAllIncidentReports()
  }

  public changePageLimit(pageLimit: any) {
    this.body.limit = pageLimit;
    this.getAllIncidentReports();
  }


  public getAllIncidentReports() {
    this.loading = true;
    this.IncidentService.incidentReportsList(this.body).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.listData = rs.data.data;
        this.totalItems = rs.data.total_count;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  public editincidentReport(incidentData) {
    this.IncidentService.getEditIncidentRecord(incidentData).subscribe((result) => { //updated by divya gurnani 17/7/2018
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
          var getData = rs.data.data[0];
          this.IncidentReportsEditComponent.getProfileData(getData);
          this.getAllIncidentReports();
          this.incidentEditViewDialoge = true;
      } else {
        this.toaster.error(rs.message);
      }
    });
  }

  closeIncidentDialoge() {
    this.incidentEditViewDialoge = false;
  }

  public assignIncidentReport(id, assignStatus, empAccept) {
    if (assignStatus == true && empAccept == '') {
      this.toaster.error("This Incident is Already Assigned. ");
    } else if (assignStatus == true && empAccept == '1') {
      this.toaster.error("This Incident is Already Assigned. ");
    } else {
      var getData = id;
      this.AssignIncidentEmployeeComponent.getIncidentId(id);
      this.assignIncidentDialoge = true;
    }
  }

  closeAssignDialoge() {
    this.assignIncidentDialoge = false;
    this.getAllIncidentReports();
  }

  public exportAll(exportfile) {
    if (exportfile == 'xls') {
      this.exportXls();
    } else if (exportfile == 'json') {
      this.exportJson();
    } else if (exportfile == 'csv') {
      this.createCsvFile();
    } else if (exportfile == 'txt') {
      this.exportTxt();
    } else if (exportfile == 'xml') {
      this.exportXml();
    }
  }
  public showDialog() {
    this.display = true;
  }

  formatDate(date) {
    var monthNames = [
        "Jan", "Feb", "Mar",
        "Apr", "May", "June", "July",
        "Aug", "Sep", "Oct",
        "Nov", "Dec"
    ];
    date = new Date(date);

    var day = date.getDate();
    var monthIndex = date.getMonth();
    var year = date.getFullYear();

    return day + ' ' + monthNames[monthIndex] + ' ' + year;
  }


  orderByDate(data: Array<any>) {
    var lastDate = '', date;
    for (let i = 0; i < data.length; i++) {

      date = this.formatDate(data[i]['createdAt']);
      if (date !== lastDate) {
        data[i]['date_changed'] = true;
      } else {
        data[i]['date_changed'] = false;
      }
      data[i]['time_created'] = data[i]['createdAt'];
      data[i]['created'] = date;
      lastDate = date;
    }
    return data;
  }

  public createCsvFile() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to csv file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        var options = {
          fieldSeparator: ',',
          quoteStrings: '"',
          decimalseparator: '.',
          showLabels: true,
          showTitle: true,
          useBom: true
        };
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'Incident Type': this.listData[i].incidentType,
            'Created': this.listData[i].createdAt,
            'Regarding': this.listData[i].firstName + this.listData[i].lastName,
            'Concern': this.listData[i].concern,
            'Department': this.listData[i].department,
            'Resolved': this.listData[i].resolved,
          });
        }
        new Angular2Csv(data, 'listData', { headers: Object.keys(data[0]) });
      },
      reject: () => {
      }
    });
  }

  public exportTxt() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to text file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'Incident Type': this.listData[i].incidentType,
            'Created': this.listData[i].createdAt,
            'Regarding': this.listData[i].firstName + this.listData[i].lastName,
            'Concern': this.listData[i].concern,
            'Department': this.listData[i].department,
            'Resolved': this.listData[i].resolved,
          });
        }
        var obj = objectToString(data);
        function objectToString(obj) {
          var str = '';
          var i = 0;
          for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
              if (typeof obj[key] == 'object') {
                {
                  str += key + ' : { ' + objectToString(obj[key]) + '} ' + (i > 0 ? ',' : '');
                }
              }
              else {
                str += key + ':\'' + obj[key] + '\'' + (i > 0 ? ',' : '');
              }
              i++;
            }
          }
          return str;
        }
        var textToSave = obj,
          filename = 'file.txt',
          blob = new Blob([textToSave], { type: "text/plain;charset=utf-8" });
        saveAs(blob, filename);
      },
      reject: () => {
      }
    });
  }


  public exportXml() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to Xml file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'id': this.listData[i]._id,
            'column-1': this.listData[i].incidentType,
            'column-2': this.listData[i].createdAt,
            'column-3': this.listData[i].firstName + this.listData[i].lastName,
            'column-4': this.listData[i].concern,
            'column-5': this.listData[i].department,
            'column-6': this.listData[i].resolved
          });

        }
        var obj = JSON.stringify(
          {
            "_declaration": {
              "_attributes": {
                "version": "1.0",
                "encoding": "utf-8"
              }
            },
            "tabledata": {
              "field": [
                [],
                "Incident Type",
                "Created",
                "Regarding",
                "Concern",
                "Department",
                "Resolved"
              ],
              "data": {
                "row": data
              }
            }
          }
        )
        this.IncidentService.exportXml(obj).subscribe((result) => {
          let rs = result.json();
          var textToSave = rs.data,
            filename = 'file.xml',
            blob = new Blob([textToSave], { type: "'application/xml charset=utf-8'" });
          saveAs(blob, filename);
        })
      },
      reject: () => {
      }
    });

  }


  public exportJson() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to json file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'Incident Type': this.listData[i].incidentType,
            'Created': this.listData[i].createdAt,
            'Regarding': this.listData[i].firstName + this.listData[i].lastName,
            'Concern': this.listData[i].concern,
            'Department': this.listData[i].department,
            'Resolved': this.listData[i].resolved,
          });
        }
        var textToSave = JSON.stringify({ "header": [["Incident Type", "Created", "Created ", "Regarding", "Concern", "Department", "Resolved"]], "data": data }),
          filename = 'file.json',
          blob = new Blob([textToSave], { type: "'application/json; charset=utf-8'" });

        saveAs(blob, filename);
      },
      reject: () => {
      }
    });
  }

  public exportXls(): void {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to excel?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        let wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
        let fileName: string = 'Incident_Reports_' + new Date().getTime() + '.xlsx';
        let data: AOA = [
          [
            "Incident Type",
            "Created",
            "Regarding",
            "Concern",
            "Department",
            "Resolved"
          ]
        ];

        this.listData.map((item: any) => {
          data.push([
            item.incidentType,
            item.createdAt,
            item.firstName + item.lastName,
            item.Concern,
            item.department,
            item.resolved
          ]);
        });

        const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(data);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
        const wbout: ArrayBuffer = XLSX.write(wb, wopts);
        saveAs(new Blob([wbout], { type: 'application/octet-stream' }), fileName);
      },
      reject: () => {
      }
    });
  }
  public showMessageInactive(id: string, status: string) {
    this.toaster.info("Employee is not verified yet.");
  }

  public getSettingIncident(settingData) {
    this.IncidentService.getSettingIncident({ obj : settingData }).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.incidentSettingObj = rs.data;
            }else{
                this.toaster.error(rs.message);
            }
        });
    this.settingDialog = true; 
  }

  public updateCustomIncidentSetting(incidentSettingObj) {
      console.log("incidentSettingObj",incidentSettingObj);
      incidentSettingObj._id = this.incidentSettingObj._id;
      this.IncidentService.updateCustomIncidentSetting(incidentSettingObj).subscribe((result) => {
          let rs = result.json();
          if (rs.code == this.config.statusCode.success) {
              this.toaster.success(rs.message);
          } else {
              this.toaster.error(rs.message);
          }
      });
  }

  public getIncidentNotes(incident){
    this.incident = incident;
    this.loading = true;
    var obj = {
      incidentId: incident._id
    }
    this.IncidentService.getIncidentNotes(obj).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.chatBoxShow = true;
        let _response = rs.data; 
        _response = this.orderByDate(_response);
        this.incidentNotes = _response;
        this.totalItems = this.incidentNotes.length;
        this.scrollDown();
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });

  }

  scrollDown() {
    setTimeout(() => {
        this.txtArea.nativeElement.scrollTop = this.txtArea.nativeElement.scrollHeight;
    }, 500)
  }

  public closeChatBox(){
    this.chatBoxShow = false;
  }

  public addIncidentNote(incident){
    var obj = {
      incidentId: incident._id,
      userFacId: this.user.userFacId,
      userId:{
        _id:  this.user.uid,
        userName: this.user.userName,
        image: this.user.image
      },
      message: this.appMessage,
      createdAt: new Date()
    }
    this.incidentNotes.push(obj);
    this.totalItems = this.incidentNotes.length;
    this.appMessage = '';
    this.scrollDown();
    this.IncidentService.addIncidentNote(obj).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) { } else { }
    })
  }

  eventHandler(event: any, type: string) {
    if (type == 'Enter') {
        this.addIncidentNote(this.incident);
    }
  }

  public ngOnInit(): void {
    let user = this.storage.get(this.config.token.userKey);
    this.user = user;
    if (this.storage.get(this.config.storage.KIOSK_MODE) == true) {
      this.kioskMode = true;
      this.router.navigate(['/facility/visitorKiosk']);
    } else {
      this.kioskMode = false;
    }
    this.getAllIncidentReports();
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
  }

  public support() {
    this.commingsoon = true;
  }

}
