import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from "../../../core/utility/http.client";


@Injectable()
export class VisitorsService {
  constructor(
    private http: HttpClient
  ) { }

  getAllVisitors(data: any): Observable<any> {
    return this.http.post('/visitor/getAllVisitors', data);
  }
  getCheckInLog(data: any): Observable<any> {
    return this.http.post('/visitor/getCheckInLog', data);
  }
  getVisitorById(data: any): Observable<any> {
    return this.http.get('/visitor/getVisitorById', data);
  }
  updateVisitorProfile(data: any): Observable<any> {
    return this.http.post('/visitor/updateVisitorProfile', data);
  }
  getCheckInLogByVisitorId(data: any): Observable<any> {
    return this.http.post('/visitor/getCheckInLogByVisitorId', data);
  }
  getVisitorMessages(data: any): Observable<any> {
    return this.http.post('/visitor/getVisitorMessages', data);
  }
  getListVistorsHeadersCount(data: any): Observable<any> {
    return this.http.post('/visitor/getListVistorsHeadersCount', data);
  }
  getCheckInLogHeaderCounts(data: any): Observable<any> {
    return this.http.post('/visitor/getCheckInLogHeaderCounts', data);
  }
  getVisitorMessageHeadersCount(data: any): Observable<any> {
    return this.http.get('/visitor/getVisitorMessageHeadersCount', data);
  }
  getVisitorTwilioChat(data: any): Observable<any> {
    return this.http.get('/visitor/getVisitorTwilioChat', data);
  }
  sendMessage(data: any): Observable<any> {
    return this.http.post('/visitor/sendMessage', data);
  }

  changeVisitorMenuStatus(data: any): Observable<any> {
    return this.http.post('/visitor/changeVisitorMenuStatus', data);
  }
  setVisitorAppMessage(data: any): Observable<any> {
    return this.http.post('/visitor/setVisitorAppMessage', data);
  }
  addIncidentReports(data: any): Observable<any> {
    return this.http.post('/visitor/addIncidentReports', data);
  }
  getIncidentByVisitorId(data: any): Observable<any> {
    return this.http.post('/visitor/getIncidentByVisitorId', data);
  }

  sendBroadCastAll(data: any): Observable<any> {
    return this.http.post('/visitor/sendBroadCastAll', data);
  }
  visitorCheckOut(data: any): Observable<any> {
    return this.http.post('/feedback/visitorCheckOut', data);
  }
  addBroadCastMessage(data: any): Observable<any> {
    return this.http.post('/visitor/addBroadCastMessage', data);
  }

  getBroadCastMessage(): Observable<any> {
    return this.http.get('/visitor/getBroadCastMessageDetails', '');
  }

  getReviewMessage(): Observable<any> {
    return this.http.get('/visitor/getReviewMessageDetails', '');
  }

  deleteMessage(data): Observable<any> {
    return this.http.post('/visitor/deleteSavedMessage', data);
  }
  getCheckInExpressResident(data: any): Observable<any> {
    return this.http.post('/feedback/getCheckInExpressResident', data);
  }

  deleteVisitor(data: any): Observable<any> {
    return this.http.post('/visitor/deleteVisitor', data);
  }

}
