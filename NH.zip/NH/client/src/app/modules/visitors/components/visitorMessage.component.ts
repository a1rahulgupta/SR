
import { Component, Inject, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
type AOA = Array<Array<any>>;

import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';
import { VisitorsService } from "../service/visitors.service";
import { FacilityService } from "../../facility/services/facility.services";
import { WebStorage } from "../../../core/utility/web.storage";

@Component({
    selector: 'app-visitor-message',
    preserveWhitespaces: false,
    templateUrl: './view/visitorMessage.view.html',
    providers: [
        VisitorsService,
        FacilityService
    ]
})
export class VisitorMessageComponent {
    a : any;
    b: any;
    c: any;
    avgNegativeRate: any;
    avgPositiveRate: any;
    visitorRatingCount: any;
    selectType: string;
    kioskMode: boolean;
    time: Date;
    prevNowPlaying: any;
    display: boolean;
    closebtn: any;

    constructor(
        public config: AppConfig,
        private toaster: ToastrService,
        private facility: FacilityService,
        private visitors: VisitorsService,
        private router: Router,
        private storage: WebStorage,
        private utills: Utills,
        private tmpStorage: TmpStorage,
        private confirmationService: ConfirmationService
    ) { }

    /*------------------ Listing Elements --------------------*/
    public asc: string = 'asc';
    public exportfile: string = '';
    public loading: boolean = true;
    public listData: any = [];
    public totalItems: number = 0;

    public body: any = {
        'page': 1,
        'count': this.config.perPageDefault,
        'searchText': '',
        'firstName': '',
        'phoneNumber': '',
        'CommentDate': '',
        'sorting': 'CommentDate',
        'order': 'asc',
    };

    public setRecordPerPage(records: number): void {
        this.body.page = 1;
        this.body.count = records;
        this.getVisitorMessages();
    }

    public sort(field: string, order: any): void {
        if (order == 'asc') {
            this.asc = 'asc';
        } else {
            this.asc = 'desc';
        }
        this.body.sorting = field;
        this.body.order = order;
        this.getVisitorMessages();
    }

    public pageChanged(event: any): void {

        this.body.page = event.page;
        this.getVisitorMessages();
    }

    public resetSearch(): void {
        this.body.searchText = '';
        this.body.phoneNumber = '';
        this.body.CommentDate = '';
        this.body.firstName = '';
        this.body.lastName = '';
        this.getVisitorMessages();
    }

    public changePageLimit(pageLimit: any) {
        this.body.count = parseInt(pageLimit);
        this.getVisitorMessages();
    }

    public getVisitorMessages() {
        this.loading = true;
        this.visitors.getVisitorMessages(this.body).subscribe((result) => {
            let rs = result.json();
            console.log("rs**************", rs);
            if (rs.code == this.config.statusCode.success) {
                this.listData = rs.data.data;
                this.totalItems = rs.data.total_count;
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
    }

    public getVisitorMessageHeadersCount() {
        this.visitors.getVisitorMessageHeadersCount({}).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.visitorRatingCount = rs.data.visitorRatingCount;
                this.avgPositiveRate = rs.data.avgPositiveRate;
                this.avgNegativeRate = rs.data.avgNegativeRate;
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
    }
    /*------------------ Listing Elements --------------------*/


    public exportAll(exportfile) {
        if (exportfile == 'xls') {
            this.exportXls();
        } else if (exportfile == 'json') {
            this.exportJson();
        } else if (exportfile == 'csv') {
            this.createCsvFile();
        } else if (exportfile == 'txt') {
            this.exportTxt();
        } else if (exportfile == 'xml') {
            this.exportXml();
        }
    }
    public createCsvFile() {
        this.confirmationService.confirm({
            message: 'Are you sure that you want to Export the data to csv file?',
            header: 'Confirmation',
            icon: 'fa fa-question-circle',
            accept: () => {
                var data = [];
                var options = {
                    fieldSeparator: ',',
                    quoteStrings: '"',
                    decimalseparator: '.',
                    showLabels: true,
                    showTitle: true,
                    useBom: true
                };
                for (let i = 0; i < this.listData.length; i++) {
                    data.push({
                        'Created At': this.listData[i].CommentDate,
                        'Name': this.listData[i].firstName + this.listData[i].lastName,
                        'Message': this.listData[i].comments,
                        'Phone Number': this.listData[i].phoneNumber,
                        'Ratings': this.listData[i].rating

                    });
                }
                new Angular2Csv(data, 'listData', { headers: Object.keys(data[0]) });
            },
            reject: () => {
            }
        });
    }

    public exportTxt() {
        this.confirmationService.confirm({
            message: 'Are you sure that you want to Export the data to text file?',
            header: 'Confirmation',
            icon: 'fa fa-question-circle',
            accept: () => {
                var data = [];
                for (let i = 0; i < this.listData.length; i++) {
                    data.push({
                        'Created At': this.listData[i].CommentDate,
                        'Name': this.listData[i].firstName + this.listData[i].lastName,
                        'Message': this.listData[i].comments,
                        'Phone Number': this.listData[i].phoneNumber,
                        'Ratings': this.listData[i].rating

                    });
                }
                var obj = objectToString(data);
                function objectToString(obj) {
                    var str = '';
                    var i = 0;
                    for (var key in obj) {
                        if (obj.hasOwnProperty(key)) {
                            if (typeof obj[key] == 'object') {
                                {
                                    str += key + ' : { ' + objectToString(obj[key]) + '} ' + (i > 0 ? ',' : '');
                                }
                            }
                            else {
                                str += key + ':\'' + obj[key] + '\'' + (i > 0 ? ',' : '');
                            }
                            i++;
                        }
                    }
                    return str;
                }
                var textToSave = obj,
                    filename = 'file.txt',
                    blob = new Blob([textToSave], { type: "text/plain;charset=utf-8" });
                saveAs(blob, filename);
            },
            reject: () => {
            }
        });
    }


    public exportXml() {
        this.confirmationService.confirm({
            message: 'Are you sure that you want to Export the data to Xml file?',
            header: 'Confirmation',
            icon: 'fa fa-question-circle',
            accept: () => {
                var data = [];
                for (let i = 0; i < this.listData.length; i++) {
                    data.push({
                        'id': this.listData[i]._id,
                        'column-1': this.listData[i].CommentDate,
                        'column-2': this.listData[i].firstName + this.listData[i].lastName,
                        'column-3': this.listData[i].comments,
                        'column-4': this.listData[i].phoneNumber,
                        'column-5': this.listData[i].rating

                    });

                }
                var obj = JSON.stringify(
                    {
                        "_declaration": {
                            "_attributes": {
                                "version": "1.0",
                                "encoding": "utf-8"
                            }
                        },
                        "tabledata": {
                            "field": [
                                [],
                                "Created At",
                                "Name",
                                "Phone Number",
                                "Flag"

                            ],
                            "data": {
                                "row": data
                            }
                        }
                    }
                )
                this.facility.exportXml(obj).subscribe((result) => {
                    let rs = result.json();
                    var textToSave = rs.data,
                        filename = 'file.xml',
                        blob = new Blob([textToSave], { type: "'application/xml charset=utf-8'" });
                    saveAs(blob, filename);
                })
            },
            reject: () => {
            }
        });

    }


    public exportJson() {
        this.confirmationService.confirm({
            message: 'Are you sure that you want to Export the data to json file?',
            header: 'Confirmation',
            icon: 'fa fa-question-circle',
            accept: () => {
                var data = [];
                for (let i = 0; i < this.listData.length; i++) {
                    data.push({
                        'Created At': this.listData[i].CommentDate,
                        'Name': this.listData[i].firstName + this.listData[i].lastName,
                        'Message': this.listData[i].comments,
                        'Phone Number': this.listData[i].phoneNumber,
                        'Ratings': this.listData[i].rating

                    });
                }
                var textToSave = JSON.stringify({ "header": [["Created At", "Name","Message", "Phone Number", "Ratings"]], "data": data }),
                    filename = 'file.json',
                    blob = new Blob([textToSave], { type: "'application/json; charset=utf-8'" });

                saveAs(blob, filename);
            },
            reject: () => {
            }
        });
    }

    public exportXls(): void {
        this.confirmationService.confirm({
            message: 'Are you sure that you want to Export the data to excel?',
            header: 'Confirmation',
            icon: 'fa fa-question-circle',
            accept: () => {
                let wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
                let fileName: string = 'visitors_' + new Date().getTime() + '.xlsx';
                let data: AOA = [
                    [
                        "Created At",
                        "Name",
                        "Message",
                        "Phone Number",
                        "Ratings"
                    ]
                ];

                this.listData.map((item: any) => {
                    data.push([
                        item.CommentDate,
                        item.firstName + item.lastName,
                        item.phoneNumber,
                        item.flag
                    ]);
                });

                const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(data);
                const wb: XLSX.WorkBook = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
                const wbout: ArrayBuffer = XLSX.write(wb, wopts);
                saveAs(new Blob([wbout], { type: 'application/octet-stream' }), fileName);
            },
            reject: () => {
            }
        });
    }


    showDialog() {
        this.display = true;
    }

    public ngOnInit(): void {
        if (this.storage.get(this.config.storage.KIOSK_MODE) == true) {
            this.kioskMode = true;
            // this.toaster.success("Visitor Kiosk Mode On.");
            this.router.navigate(['/facility/visitorKiosk']);
        } else {
            this.kioskMode = false;
        }
        var stationdate = new Date();
        if (this.prevNowPlaying) {
            clearInterval(this.prevNowPlaying);
        }
        this.prevNowPlaying = setInterval(() => {
            stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
            this.time = stationdate;
        }, 1000);
        this.getVisitorMessages();
        this.getVisitorMessageHeadersCount();
    }

}

