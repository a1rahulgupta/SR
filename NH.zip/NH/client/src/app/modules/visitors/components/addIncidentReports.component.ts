import { Component, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { VisitorsService } from "../service/visitors.service";
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { TmpStorage } from "../../../core/utility/temp.storage";
import { requiredTrim } from "../../../core/validators/validators";



@Component({
  selector: 'app-incident-report',
  preserveWhitespaces: false,
  templateUrl: './view/addIncidentReports.view.html',
  providers: [
    VisitorsService
  ]
})
export class AddIncidentReportsComponent {
    profileInfo: any;
    @Output('onClose') onClose = new EventEmitter<any>();
    time: Date;
  prevNowPlaying: any;

  public httpCall: any = false;
  public incidentFrm: FormGroup;

  constructor(
    private toaster: ToastrService,
    private visitor: VisitorsService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public config: AppConfig,
    private formBuilder: FormBuilder,
    private utills: Utills,
    private tmpStorage: TmpStorage
  ) {
    this.incidentFrm = formBuilder.group({
      firstName: ['', [requiredTrim]],
      lastName: ['', [requiredTrim]],
      concern:['', [requiredTrim]],
      department:['', [requiredTrim]],
      resolved: [''],
      subject : ['', [requiredTrim]],
      incidentType: ['',[requiredTrim]],
      notes : [''],
      employeeNotes : [''], 
      adminNotes : [''],  
      visitedTo: ['',[requiredTrim]],
      createdAt : ['',[requiredTrim]],
      resolutionNotes : ['']
    });
  }

incidentResolved(value){
this.incidentFrm.value.resolved = value;
}
    
resetForm(){
  this.onClose.emit();
  this.incidentFrm.reset();
}

  public save() {
    this.httpCall = true;
    let data = this.incidentFrm.value;
     data.visitorId = this.profileInfo._id;
     data.incidentTime = this.profileInfo.createdAt;
     if(this.incidentFrm.value.resolved == true){
       data.resolved = true
     } else{
       data.resolved = false
     }
    this.visitor.addIncidentReports(data).subscribe((result: any) => {
      this.httpCall = false;
      var rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.toaster.success(rs.message);
        this.onClose.emit();
        this.incidentFrm.reset();
        
      } else {
        this.toaster.error(rs.message);
      }
    });
  }

getProfileData(getData) {
    var createdAt = getData.createdAt;
          getData.createdAt = new Date(getData.createdAt);
    this.profileInfo = getData;
    this.incidentFrm.patchValue(this.profileInfo);
  }
  public ngOnInit() {
    var stationdate = new Date();
    if (this.prevNowPlaying) {
        clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
        stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
        this.time = stationdate;
    }, 1000);
   }

}
