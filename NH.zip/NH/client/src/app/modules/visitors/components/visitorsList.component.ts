
import { Component, Inject, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
type AOA = Array<Array<any>>;

import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';
import { VisitorsService } from "../service/visitors.service";
import { FacilityService } from "../../facility/services/facility.services";
import { WebStorage } from "../../../core/utility/web.storage";
import { EmployeeService } from '../../employee/services/employee.services';

@Component({
  selector: 'app-visitors-list',
  preserveWhitespaces: false,
  templateUrl: './view/visitorsList.view.html',
  styles: [`
  :host >>> .popover {
    color: #FFFFFF;
    background: #000000;
  
  }
 
`],
  providers: [
    VisitorsService,
    FacilityService,
    EmployeeService
  ]
})
export class VisitorsListComponent {
  a : any;
  b: any;
  c: any;
  permissionData: any;
  user: any;
  messageText: string = '';
  saveText: string = '';
  sendFeedbackTotalCount: any;
  engagedPercentage: any;
  visitedInLastThirtyDays: any;
  time: Date;
  kioskMode: boolean;
  prevNowPlaying: any;
  display: boolean;
  closebtn: any;
  sendSmsForm: FormGroup;
  public myModalLabel1 = false;
  public myModalLabel2 = false;
  public messageList: any = [];



  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private facility: FacilityService,
    private visitors: VisitorsService,
    private router: Router,
    private storage: WebStorage,
    private employee: EmployeeService,
    private utills: Utills,
    private tmpStorage: TmpStorage,
    private confirmationService: ConfirmationService,
    private fb: FormBuilder
  ) { }

  /*------------------ Listing Elements --------------------*/
  public asc: string = 'asc';
  public exportfile: string = '';
  public loading: boolean = true;
  public listData: any = [];
  public totalItems: number = 0;
  selectedValues: string[] = [];

  public body: any = {
    'page': 1,
    'count': this.config.perPageDefault,
    'searchText': '',
    'firstName': '',
    'phoneNumber': '',
    'flag': '',
    'createdAt': '',
    'sorting': 'createdAt',
    'order': 'asc',
  };

  public setRecordPerPage(records: number): void {
    this.body.page = 1;
    this.body.count = records;
    this.getAllVisitors();
  }

  public sort(field: string, order: any): void {
    if (order == 'asc') {
      this.asc = 'asc';
    } else {
      this.asc = 'desc';
    }
    this.body.sorting = field;
    this.body.order = order;
    this.getAllVisitors();
  }

  public pageChanged(event: any): void {

    this.body.page = event.page;
    this.getAllVisitors();
  }

  public resetSearch(): void {
    this.body.searchText = '';
    this.body.phoneNumber = '';
    this.body.createdAt = '';
    this.body.firstName = '';
    this.body.lastName = '';
    this.getAllVisitors();
  }

  public changePageLimit(pageLimit: any) {
    this.body.count = parseInt(pageLimit);
    this.getAllVisitors()
  }

  public getAllVisitors() {
    this.loading = true;
    console.log("rs.datathis.body", this.body);
    this.visitors.getAllVisitors(this.body).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.listData = rs.data.data;
        var self = this;
        this.listData.map((visitor, key) => {
          self.listData[key]['check_state'] = false;
        })
        this.totalItems = rs.data.total_count;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }
  /*------------------ Listing Elements --------------------*/


  public exportAll(exportfile) {
    if (exportfile == 'xls') {
      this.exportXls();
    } else if (exportfile == 'json') {
      this.exportJson();
    } else if (exportfile == 'csv') {
      this.createCsvFile();
    } else if (exportfile == 'txt') {
      this.exportTxt();
    } else if (exportfile == 'xml') {
      this.exportXml();
    }
  }


  public createCsvFile() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to csv file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        var options = {
          fieldSeparator: ',',
          quoteStrings: '"',
          decimalseparator: '.',
          showLabels: true,
          showTitle: true,
          useBom: true
        };
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'CreatedAt': this.listData[i].createdAt,
            'Name': this.listData[i].firstName + this.listData[i].lastName,
            'Phone Number': this.listData[i].phoneNumber,
            'flag': this.listData[i].flag

          });
        }
        new Angular2Csv(data, 'listData', { headers: Object.keys(data[0]) });
      },
      reject: () => {
      }
    });
  }

  public exportTxt() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to text file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'CreatedAt': this.listData[i].createdAt,
            'Name': this.listData[i].firstName + this.listData[i].lastName,
            'Phone Number': this.listData[i].phoneNumber,
            'flag': this.listData[i].flag

          });
        }
        var obj = objectToString(data);
        console.log(obj);
        function objectToString(obj) {
          var str = '';
          var i = 0;
          for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
              if (typeof obj[key] == 'object') {
                {
                  str += key + ' : { ' + objectToString(obj[key]) + '} ' + (i > 0 ? ',' : '');
                }
              }
              else {
                str += key + ':\'' + obj[key] + '\'' + (i > 0 ? ',' : '');
              }
              i++;
            }
          }
          return str;
        }
        var textToSave = obj,
          filename = 'file.txt',
          blob = new Blob([textToSave], { type: "text/plain;charset=utf-8" });
        saveAs(blob, filename);
      },
      reject: () => {
      }
    });
  }


  public exportXml() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to Xml file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'id': this.listData[i]._id,
            'column-1': this.listData[i].createdAt,
            'column-2': this.listData[i].firstName + this.listData[i].lastName,
            'column-3': this.listData[i].phoneNumber,
            'column-4': this.listData[i].flag

          });

        }
        var obj = JSON.stringify(
          {
            "_declaration": {
              "_attributes": {
                "version": "1.0",
                "encoding": "utf-8"
              }
            },
            "tabledata": {
              "field": [
                [],
                "Created At",
                "Name",
                "Phone Number",
                "Flag"

              ],
              "data": {
                "row": data
              }
            }
          }
        )
        this.facility.exportXml(obj).subscribe((result) => {
          let rs = result.json();
          var textToSave = rs.data,
            filename = 'file.xml',
            blob = new Blob([textToSave], { type: "'application/xml charset=utf-8'" });
          saveAs(blob, filename);
        })
      },
      reject: () => {
      }
    });

  }


  public exportJson() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to json file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'CreatedAt': this.listData[i].createdAt,
            'Name': this.listData[i].firstName + this.listData[i].lastName,
            'Phone Number': this.listData[i].phoneNumber,
            'flag': this.listData[i].flag

          });
        }
        var textToSave = JSON.stringify({ "header": [["Created At", "Name", "Phone Number", "Flag"]], "data": data }),
          filename = 'file.json',
          blob = new Blob([textToSave], { type: "'application/json; charset=utf-8'" });

        saveAs(blob, filename);
      },
      reject: () => {
      }
    });
  }

  public exportXls(): void {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to excel?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        let wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
        let fileName: string = 'visitors_' + new Date().getTime() + '.xlsx';
        let data: AOA = [
          [
            "Created At",
            "Name",
            "Phone Number",
            "Flag"
          ]
        ];

        this.listData.map((item: any) => {
          data.push([
            item.createdAt,
            item.firstName + item.lastName,
            item.phoneNumber,
            item.flag
          ]);
        });

        const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(data);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
        const wbout: ArrayBuffer = XLSX.write(wb, wopts);
        saveAs(new Blob([wbout], { type: 'application/octet-stream' }), fileName);
      },
      reject: () => {
      }
    });
  }


  showDialog() {
    this.display = true;
  }


  public getListVistorsHeadersCount() {
    this.visitors.getListVistorsHeadersCount({ todayDate: new Date() }).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.visitedInLastThirtyDays = rs.data.visitedInLastThirtyDays;
        this.engagedPercentage = rs.data.engagedPercentage;
        this.sendFeedbackTotalCount = rs.data.sendFeedbackTotalCount;
      } else {
        this.visitedInLastThirtyDays = 0;
        this.engagedPercentage = 0;
        this.sendFeedbackTotalCount = 0;
      }
      this.loading = false;
    });
  }

  public remove(id: string) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to delete?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        this.visitors.deleteVisitor({ _id: id }).subscribe((result) => {
          let rs = result.json();
          if (rs.code == this.config.statusCode.success) {
            this.getAllVisitors();
            this.toaster.success(rs.message);
          } else {
            this.toaster.error(rs.message);
          }
          this.loading = false;
        });
      },
      reject: () => {
      }
    });
  }

  public ngOnInit(): void {


    this.sendSmsForm = this.fb.group({
      message: new FormControl('', [Validators.required])
    });
    this.user = this.storage.get(this.config.token.userKey);
    if (this.user.role == 'employee') {
      var obj = {
        employeeId: this.user.uid,
      }
      this.employee.getEmployeePermissions(obj).subscribe((result) => {
        let rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.permissionData = rs.data;
        }
      })

    }
    if (this.storage.get(this.config.storage.KIOSK_MODE) == true) {
      this.kioskMode = true;
      // this.toaster.success("Visitor Kiosk Mode On.");
      this.router.navigate(['/facility/visitorKiosk']);
    } else {
      this.kioskMode = false;
    }
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
    this.getAllVisitors();
    this.getListVistorsHeadersCount();
  }

  onCellClick(data: any) {
    this.router.navigate(['/facility/visitors/edit', data]);
  }

  showModal() {
    this.myModalLabel1 = true;
  }

  showModaladdmsg() {
    this.messageText = '';
    this.myModalLabel1 = false;
    this.myModalLabel2 = true;
  }

  public cancel() {
    this.messageText = '';
    this.myModalLabel1 = false;
    this.myModalLabel2 = false;

  }

  //funtion is used to send broadcast messages to the selected visitors

  sendBroadCastAll() {
    this.myModalLabel1 = false;
    var visitor_id = [];
    this.listData.forEach(x => {
      if (x.check_state) {
        visitor_id.push(x._id);
      }
    });
    if (visitor_id.length) {
      let postdata = {
        "ids_array": visitor_id,
        "message": this.messageText
      }
      this.visitors.sendBroadCastAll(postdata).subscribe((result) => {
        let rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.toaster.success("Broadcast Message send successfully to the selected visitors.");
          this.messageText = '';
          this.getAllVisitors();
        } else {
          this.messageText = '';
          this.toaster.error(rs.message);
        }
      });
    } else {
      this.toaster.error('Please select at least one Visitor record.');
    }
  }
  /*Function for checking all check boxes */
  checkAll(ev) {
    this.listData.forEach(x => x.check_state = ev.target.checked)
  }

  /*Function to check all check boxes are checked or not*/
  isAllChecked() {
    return this.listData.every(x => x.check_state);
  }

  //function is used to save broadcast message
  saveBroadCastMessage() {
    let postdata = {
      "message": this.saveText
    }

    if (this.saveText.length) {
      this.visitors.addBroadCastMessage(postdata).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.myModalLabel2 = false;
          this.saveText = '';
          this.toaster.success(rs.message);
        } else {
          this.myModalLabel2 = false;
          this.saveText = '';
          this.toaster.error(rs.message);
        }
      });
    } else {
      this.toaster.error('Please enter a message.');
    }
  }

  //function is to get saved msg

  getBroadCastMessage() {
    this.visitors.getBroadCastMessage().subscribe((result: any) => {
      var rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.messageList = rs.data.messageDetails;

      }
    })
  }
  // function is used for to dispaly selected msg
  selectedmsg(message) {
    this.messageText = message;
  }
  //function is to delete saved message

  deleteMessage(id) {
    var data = {
      _id: id
    }
    this.visitors.deleteMessage(data).subscribe((result: any) => {
      var rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.toaster.success("Saved message deleted successfully");
      } else {
        this.toaster.error("Saved message not deleted please try it later");
      }
    })
  }



}

