
import { Component, Inject, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormGroup, FormArray, FormBuilder, Validators, FormControl } from '@angular/forms';

import { ConfirmationService } from 'primeng/primeng';
import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';
import { VisitorsService } from "../service/visitors.service";
import { FacilityService } from "../../facility/services/facility.services";
import { WebStorage } from "../../../core/utility/web.storage";
import { requiredTrim } from "../../../core/validators/validators";
import { Socket } from 'ngx-socket-io';
import { AddIncidentReportsComponent } from "./addIncidentReports.component";
import { EmployeeService } from '../../employee/services/employee.services';

@Component({
    selector: 'app-visitor-profile',
    preserveWhitespaces: false,
    templateUrl: './view/visitorProfile.view.html',
    styles: [`
    :host >>> .popover {
      color: #FFFFFF;
      background: #000000;
    
    }
   
  `],
    providers: [
        VisitorsService,
        FacilityService,
        EmployeeService
    ]
})
export class VisitorProfileComponent {
    showFamilyType: boolean = false;
    showVendorType: boolean = false;
    showPatientField: boolean = false;
    permissionData: any = {
        visitors: {
            "status": false,
            "edit": false,
            "isCheckInAlert": false,
            "isAppMessagePopUp": false,
            "isSms": false,
            "twilioChat": false,
            "documentIncident": false,
            "stickyNote": false
        }
    };
    incidentTotalItems: any;
    incidentData: any;
    googleLink: any;
    incidentViewDialoge: boolean;
    appMessage: string;
    appMessageDialoge: boolean;
    isSms: boolean;
    isAppMessagePopUp: boolean;
    isCheckInAlert: boolean;
    ratingResponse: any;
    user: any;
    smsHistoryArrayLength: boolean;
    message: string;
    @ViewChild('messgBx') txtArea: any;
    visitorPhoneNumber: any;
    smsHistoryArray: any;
    kioskMode: boolean;
    saveText: string = '';
    time: Date;
    first_name: string;
    // first_name = "vishaka";
    prevNowPlaying: any;
    httpCall: boolean;
    visitorName: string;
    visitorNo: any;
    createdAt: any;
    visitorData: any;
    public myModalLabel = false;
    @ViewChild('AddIncidentReportsComponent')
    private AddIncidentReportsComponent: AddIncidentReportsComponent;
    public visitorProfileFrm: FormGroup;
    public positiveList: any = [];
    public negativeList: any = [];
    public reviewList: any = [];
    public messageList: any = [];


    constructor(
        public config: AppConfig,
        private toaster: ToastrService,
        private facility: FacilityService,
        private visitors: VisitorsService,
        private activatedRoute: ActivatedRoute,
        private router: Router,
        private employee: EmployeeService,
        private storage: WebStorage,
        private formBuilder: FormBuilder,
        public  utills: Utills,
        private tmpStorage: TmpStorage,
        private socket: Socket,
        private confirmationService: ConfirmationService
    ) {

        this.socket.on('twilioSms', (data: any) => {
            this.getVisitorTwilioChatByVisitorId(data.visitorId);
        });

    }
    public loading: boolean = true;
    public listData: any = [];
    public totalItems: number = 0;

    public body: any = {
        'page': 1,
        'count': this.config.perPageDefault
    };

    public body1: any = {
        'page': 1,
        'count': this.config.perPageDefault
    };

    public pageChanged(event: any): void {
        this.body.page = event.page;
        this.getCheckInLogByVisitorId();
    }

    public changePageLimit(pageLimit: any) {
        this.body.count = parseInt(pageLimit);
        this.getCheckInLogByVisitorId();
    }

    public pageChangedIncident(event: any): void {
        this.body1.page = event.page;
        this.getIncidentByVisitorId();
    }

    public changePageLimiIncident(pageLimit: any) {
        this.body1.count = parseInt(pageLimit);
        this.getIncidentByVisitorId();
    }

    update() {
        this.httpCall = true;
        this.activatedRoute.params.subscribe((param: any) => {
            let data = this.visitorProfileFrm.value;
            data.phoneNumber = this.visitorProfileFrm.value.country_code + this.visitorProfileFrm.value.phoneNumber;
            data._id = param['id'];
            this.visitors.updateVisitorProfile(data).subscribe((result: any) => {
                this.httpCall = false;
                var rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.toaster.success(rs.message);
                } else {
                    this.toaster.error(rs.message);
                    this.getVisitorProfile();
                }
            });
        });
    }

    resetSearch(): void {
        this.appMessage = '';
    }

    saveVisitorAppMessage() {
        this.activatedRoute.params.subscribe((param: any) => {
            if (this.appMessage == null || this.appMessage == '' || this.appMessage == undefined) {
                this.toaster.info("Oops! App message is empty. Please fill the app message.");
            } else {
                var obj = {
                    appMessage: this.appMessage,
                    isAppMessagePopUp: true,
                    visitorId: param['id']
                }
                this.appMessageDialoge = false;
                this.visitors.setVisitorAppMessage(obj).subscribe((result: any) => {
                    var rs = result.json();
                    if (rs.code == this.config.statusCode.success) {
                        this.toaster.success(rs.message);
                        this.getVisitorProfile();
                    } else {
                        this.toaster.error(rs.message);
                    }
                })
            }
        })
    }

    getVisitorProfile() {
        this.activatedRoute.params.subscribe((param: any) => {
            this.visitors.getVisitorById({ id: param['id'] }).subscribe((result: any) => {
                var rs = result.json();
                console.log("rs--getVisitorById---", rs);
                if (rs.code == this.config.statusCode.success) {
                    let phoneNumber = rs.data.data.phoneNumber;
                    this.createdAt = rs.data.data.createdAt;
                    this.visitorNo = rs.data.data.phoneNumber;
                    this.ratingResponse = rs.data.avgRatingResponse;
                    this.isCheckInAlert = rs.data.data.isCheckInAlert;
                    this.isAppMessagePopUp = rs.data.data.isAppMessagePopUp;
                    this.appMessage = rs.data.data.appMessage;
                    this.isSms = rs.data.data.isSms;
                    this.visitorName = rs.data.data.firstName + ' ' + rs.data.data.lastName;
                    this.first_name = rs.data.data.firstName;
                    rs.data.data.phoneNumber = phoneNumber.slice(-10);
                    rs.data.data.country_code = phoneNumber.slice(0, -10);
                    this.visitorData = rs.data.data;
                    this.onChangeType(this.visitorData.visitor_type);
                    this.visitorProfileFrm.patchValue(this.visitorData);
                } else {
                    this.visitorData = {};
                    this.createdAt = '';
                    this.visitorNo = '';
                    this.ratingResponse = '';
                    this.visitorName = '';
                    this.isCheckInAlert = false;
                    this.isAppMessagePopUp = false;
                    this.isSms = false;
                    this.toaster.error(rs.message);
                }
            })
        })
    }
    
    getCheckInLogByVisitorId() {
        this.activatedRoute.params.subscribe((param: any) => {
            let data = this.body;
            data._id = param['id'];
            this.loading = true;
            this.visitors.getCheckInLogByVisitorId(data).subscribe((result) => {
                let rs = result.json();
                console.log("rs--getCheckInLogByVisitorId---", rs);
                if (rs.code == this.config.statusCode.success) {
                    this.listData = rs.data.data;
                    this.totalItems = rs.data.total_count;
                } else {
                    this.toaster.error(rs.message);
                }
                this.loading = false;
            });
        })
    }

    getIncidentByVisitorId() {
        this.activatedRoute.params.subscribe((param: any) => {
            let data = this.body1;
            data._id = param['id'];
            this.loading = true;
            this.visitors.getIncidentByVisitorId(data).subscribe((result) => {
                let rs = result.json();
                console.log("rs--getIncidentByVisitorId---", rs);
                if (rs.code == this.config.statusCode.success) {
                    this.incidentData = rs.data.data;
                    this.incidentTotalItems = rs.data.total_count;
                } else {
                    this.toaster.error(rs.message);
                }
                this.loading = false;
            });
        })
    }

    scrollDown() {
        setTimeout(() => {
            this.txtArea.nativeElement.scrollTop = this.txtArea.nativeElement.scrollHeight;
        }, 500)
    }

    getVisitorTwilioChat() {
        this.activatedRoute.params.subscribe((param: any) => {
            this.visitors.getVisitorTwilioChat({ id: param['id'] }).subscribe((result: any) => {
                var rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.visitorPhoneNumber = rs.data.visitorData.phoneNumber;
                    console.log("rs.data", this.visitorPhoneNumber);
                    this.smsHistoryArray = rs.data.smsHistoryData;
                    if (rs.data.smsHistoryData.length == 0) {
                        this.smsHistoryArrayLength = false;
                    }
                    this.scrollDown();
                } else {
                    this.smsHistoryArray = [];
                    this.toaster.error(rs.message);
                }
            })
        })
    }

    getVisitorTwilioChatByVisitorId(visitorId) {
        this.activatedRoute.params.subscribe((param: any) => {
            this.visitors.getVisitorTwilioChat({ id: visitorId }).subscribe((result: any) => {
                var rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.visitorPhoneNumber = rs.data.visitorData.phoneNumber;
                    console.log("rs.data", this.visitorPhoneNumber);
                    this.smsHistoryArray = rs.data.smsHistoryData;
                    if (rs.data.smsHistoryData.length == 0) {
                        this.smsHistoryArrayLength = false;
                    }
                    this.scrollDown();
                } else {
                    this.smsHistoryArray = [];
                    this.toaster.error(rs.message);
                }
            })
        })
    }

    sendMessage() {
        let data = {
            text: this.message,
            to: this.visitorPhoneNumber,
            from: this.user.twilioTollFreeNumber,
            createdAt: new Date()
        }
        console.log("data in send message", data);
        this.smsHistoryArray.push(data)
        this.message = '';
        this.scrollDown();
        this.visitors.sendMessage(data).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) { } else { }
        })
    }

    eventHandler(event: any, type: string) {
        if (type == 'Enter') {
            this.sendMessage();
        }
    }

    changeVisitorMenuStatus(orderNo) {
        this.activatedRoute.params.subscribe((param: any) => {
            var obj = {};
            if (orderNo == '0') {
                obj = {
                    isCheckInAlert: !this.isCheckInAlert,
                    isAppMessagePopUp: this.isAppMessagePopUp,
                    isSms: this.isSms,
                    visitorId: param['id']
                }
                this.changeVistorMenues(obj)
            } else if (orderNo == '1') {
                if (this.isAppMessagePopUp == false) {
                    this.appMessageDialoge = true;
                } else {
                    obj = {
                        isCheckInAlert: this.isCheckInAlert,
                        isAppMessagePopUp: !this.isAppMessagePopUp,
                        isSms: this.isSms,
                        visitorId: param['id']
                    }
                    this.changeVistorMenues(obj);
                }
            } else {
                obj = {
                    isCheckInAlert: this.isCheckInAlert,
                    isAppMessagePopUp: this.isAppMessagePopUp,
                    isSms: !this.isSms,
                    visitorId: param['id']
                }
                this.changeVistorMenues(obj)
            }
        })

    }

    changeVistorMenues(obj) {
        this.visitors.changeVisitorMenuStatus(obj).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.toaster.success(rs.message);
                this.getVisitorProfile();
            }
        })
    }

    public incidentReport() {
        var getData = this.visitorData;
        this.AddIncidentReportsComponent.getProfileData(getData);
        this.incidentViewDialoge = true;
    }

    closeIncidentDialoge() {
        this.incidentViewDialoge = false;
        this.getIncidentByVisitorId();
    }

    validateInput(formgroup: FormGroup) {
        if (formgroup.controls["visitor_type"].value == 'family') {
            formgroup.controls["visitedTo"].setValidators([Validators.required]),
            formgroup.controls["relation_type"].setValidators([Validators.required]),
            formgroup.controls["room_no"].setValidators([Validators.required]),
            formgroup.controls["vendor_type"].setValidators([]),
            formgroup.controls["company_name"].setValidators([])

        } else if (formgroup.controls["visitor_type"].value == 'friend' ||
            formgroup.controls["visitor_type"].value == 'poa' ||
            formgroup.controls["visitor_type"].value == 'hcp' ||
            formgroup.controls["visitor_type"].value == 'guardian' ||
            formgroup.controls["visitor_type"].value == 'attorney') {

                formgroup.controls["visitedTo"].setValidators([Validators.required]),
                formgroup.controls["relation_type"].setValidators([]),
                formgroup.controls["room_no"].setValidators([Validators.required]),
                formgroup.controls["vendor_type"].setValidators([]),
                formgroup.controls["company_name"].setValidators([])

        } else if (formgroup.controls["visitor_type"].value == 'vendor') {

            formgroup.controls["visitedTo"].setValidators([]),
            formgroup.controls["relation_type"].setValidators([]),
            formgroup.controls["room_no"].setValidators([]),
            formgroup.controls["vendor_type"].setValidators([Validators.required]),
            formgroup.controls["company_name"].setValidators([Validators.required])

        }else if (formgroup.controls["visitor_type"].value == 'guest_tour'){
            formgroup.controls["visitedTo"].setValidators([]),
            formgroup.controls["relation_type"].setValidators([]),
            formgroup.controls["room_no"].setValidators([]),
            formgroup.controls["vendor_type"].setValidators([]),
            formgroup.controls["company_name"].setValidators([])
        }

    }

    // Function is use to show input fields depend on selected Value from visitor Type dropdown
    onChangeType(data) {
        switch (data) {
            case 'family':
                this.showPatientField = true;
                this.showVendorType = false;
                this.showFamilyType = true;
                this.visitorProfileFrm.controls['vendor_type'].setValue('');
                this.visitorProfileFrm.controls['company_name'].setValue('');
                break;
            case 'friend':
                this.showPatientField = true;
                this.showVendorType = false;
                this.showFamilyType = false;
                this.visitorProfileFrm.controls['vendor_type'].setValue('');
                this.visitorProfileFrm.controls['relation_type'].setValue('');
                this.visitorProfileFrm.controls['company_name'].setValue('');
                break;
            case 'poa':
                this.showPatientField = true;
                this.showVendorType = false;
                this.showFamilyType = false;
                this.visitorProfileFrm.controls['vendor_type'].setValue('');
                this.visitorProfileFrm.controls['relation_type'].setValue('');
                this.visitorProfileFrm.controls['company_name'].setValue('');
                break;
            case 'hcp':
                this.showPatientField = true;
                this.showVendorType = false;
                this.showFamilyType = false;
                this.visitorProfileFrm.controls['vendor_type'].setValue('');
                this.visitorProfileFrm.controls['relation_type'].setValue('');
                this.visitorProfileFrm.controls['company_name'].setValue('');
                break;
            case 'guardian':
                this.showPatientField = true;
                this.showVendorType = false;
                this.showFamilyType = false;
                this.visitorProfileFrm.controls['vendor_type'].setValue('');
                this.visitorProfileFrm.controls['relation_type'].setValue('');
                this.visitorProfileFrm.controls['company_name'].setValue('');
                break;
            case 'attorney':
                this.showPatientField = true;
                this.showVendorType = false;
                this.showFamilyType = false;
                this.visitorProfileFrm.controls['vendor_type'].setValue('');
                this.visitorProfileFrm.controls['relation_type'].setValue('');
                this.visitorProfileFrm.controls['company_name'].setValue('');
                break;
            case 'guest_tour':
                this.showPatientField = false;
                this.showVendorType = false;
                this.showFamilyType = false;
                this.visitorProfileFrm.controls['vendor_type'].setValue('');
                this.visitorProfileFrm.controls['relation_type'].setValue('');
                this.visitorProfileFrm.controls['company_name'].setValue('');
                this.visitorProfileFrm.controls['room_no'].setValue('');
                this.visitorProfileFrm.controls['bed_no'].setValue('');
                this.visitorProfileFrm.controls['visitedTo'].setValue('');
                break;
            case 'vendor':
                this.showPatientField = false;
                this.showVendorType = true;
                this.showFamilyType = false;
                this.visitorProfileFrm.controls['relation_type'].setValue('');
                this.visitorProfileFrm.controls['room_no'].setValue('');
                this.visitorProfileFrm.controls['bed_no'].setValue('');
                this.visitorProfileFrm.controls['visitedTo'].setValue('');
                break;
        }
    }

    public ngOnInit(): void {
        this.user = this.storage.get(this.config.token.userKey);
        this.googleLink = this.user.googleLink;
        if (this.user.role == 'employee') {
            var obj = {
                employeeId: this.user.uid,
            }
            this.employee.getEmployeePermissions(obj).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.permissionData = rs.data;
                    console.log("this.permissionData@@@@@@@@@@@@@@@", this.permissionData);
                }
            })

        }
        if (this.storage.get(this.config.storage.KIOSK_MODE) == true) {
            this.kioskMode = true;
            // this.toaster.success("Visitor Kiosk Mode On.");
            this.router.navigate(['/facility/visitorKiosk']);
        } else {
            this.kioskMode = false;
        }

        this.visitorProfileFrm = this.formBuilder.group({
            country_code: ['+1', [requiredTrim]],
            phoneNumber: ['', [requiredTrim, Validators.minLength(10), Validators.maxLength(10)]],
            firstName: new FormControl('', [Validators.required]),
            lastName: new FormControl('', [Validators.required]),
            visitor_type: new FormControl("", [Validators.required]),
            email: new FormControl('', [Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
            visitedTo: new FormControl('', ),
            relation_type: new FormControl('', ),
            vendor_type: new FormControl('', ),
            company_name: new FormControl('', ),
            room_no: new FormControl('', ),
            bed_no: new FormControl('', )
        }, {
                validator: (formgroup: FormGroup) => {
                    return this.validateInput(formgroup);
                }
            }
        );

        this.user = this.storage.get(this.config.token.userKey)
        var stationdate = new Date();
        if (this.prevNowPlaying) {
            clearInterval(this.prevNowPlaying);
        }
        this.prevNowPlaying = setInterval(() => {
            stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
            this.time = stationdate;
        }, 1000);
        this.getVisitorProfile();
        this.getCheckInLogByVisitorId();
        this.getIncidentByVisitorId();
        this.getVisitorTwilioChat();
    }

    // function is used for to dispaly selected msg of auto save
    selectMessage(event) {
        var message = event.target.innerHTML;
        this.message = message;
    }

    // function is used for to dispaly selected msg from saved msg 
    selectMessageSaved(message) {
        this.message = message;
    }

    //Fuction is used to show add message modal
    showModaladdmsg() {
        this.myModalLabel = true;
    }

    //function is used to cancel modal
    public cancel() {
        this.myModalLabel = false;

    }

    //function is used to save broadcast message
    saveChatMessage() {
        let postdata = {
            "message": this.saveText
        }
        if (this.saveText.length) {
            this.visitors.addBroadCastMessage(postdata).subscribe((result: any) => {
                var rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.myModalLabel = false;
                    this.saveText = '';
                    this.toaster.success(rs.message);
                } else {
                    this.myModalLabel = false;
                    this.saveText = '';
                    this.toaster.error(rs.message);
                }
            });
        } else {
            this.toaster.error('Please enter a message.');
        }
    }

    //function is to get saved msg
    getSavedMessage() {
        this.visitors.getBroadCastMessage().subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.messageList = rs.data.messageDetails;


            }
        })
    }

    //function is to delete saved message
    deleteMessage(id) {
        var data = {
            _id: id
        }
        this.visitors.deleteMessage(data).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.toaster.success("Saved message deleted successfully");
            } else {
                this.toaster.error("Saved message not deleted please try it later");
            }
        })
    }

    public getCheckOut() {
        if (this.visitorPhoneNumber.length > 0) {
          this.loading = true;
          let user = this.user;
          var data: any = {};
          data.phoneNumber = this.visitorPhoneNumber;
          data.checkOutDate = new Date();
          data.userFacilityId = user.userFacId,
          data.byFacility = true;
          this.visitors.visitorCheckOut(data).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
              this.toaster.success("Visitor checked out successfully");
              this.getCheckInLogByVisitorId();
            } else {
              this.toaster.error(rs.message);
            }
            this.loading = false;
          });
        }
    }

}

