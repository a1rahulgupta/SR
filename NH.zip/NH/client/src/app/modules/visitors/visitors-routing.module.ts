import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";
import { VisitorsListComponent } from "./components/visitorsList.component";
import { VisitorsComponent } from "./visitors.component";
import { CheckInLogComponent } from "./components/checkInLog.component";
import { VisitorProfileComponent } from "./components/visitorProfile.component";
import { VisitorMessageComponent } from "./components/visitorMessage.component";

const routes: Routes = [
    {
        path: '',
        component: VisitorsComponent,
        children: [

            {
                path: '',
                component: VisitorsListComponent,
            },
            {
                path: 'checkInLog',
                component: CheckInLogComponent,
            },
            {
                path: 'messages',
                component: VisitorMessageComponent,
            },
            {
                path: 'edit/:id',
                component: VisitorProfileComponent,
            }

        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class VisitorsRoutingModule {

}