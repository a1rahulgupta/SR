import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
    PaginationModule
} from 'ngx-bootstrap';
import {
    ConfirmDialogModule,
    ConfirmationService,
    DialogModule,
    CalendarModule,
    CheckboxModule
} from 'primeng/primeng';

import { VisitorsRoutingModule } from "./visitors-routing.module";
import { VisitorsListComponent } from "./components/visitorsList.component";
import { VisitorsComponent } from "./visitors.component";
import { CheckInLogComponent } from "./components/checkInLog.component";
import { VisitorProfileComponent } from "./components/visitorProfile.component";
import { VisitorMessageComponent } from "./components/visitorMessage.component";
import { AddIncidentReportsComponent } from "./components/addIncidentReports.component";
import { PopoverModule } from "ngx-popover";
import { CountoModule }  from 'angular2-counto';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PaginationModule.forRoot(),
        ConfirmDialogModule,
        VisitorsRoutingModule,
        DialogModule,
        CalendarModule,
        CheckboxModule,
        PopoverModule,
        CountoModule
    ],
    declarations: [
        VisitorsComponent,
        VisitorsListComponent,
        CheckInLogComponent,
        VisitorProfileComponent,
        VisitorMessageComponent,
        AddIncidentReportsComponent
    ],
    providers: [
        ConfirmationService
    ]
})
export class VisitorsModule { }