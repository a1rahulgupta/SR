import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";

import { EmployeeDashboardComponent } from "./components/employeeDashboard.component";
import { EmployeeFeedbackComponent } from "./employee_feedback.component";
import { AddEmployeeComplaintComponent } from "./components/addEmployeeComplaint.component";
import { AddEmployeeReviewComponent } from "./components/addEmployeeReview.component";

const routes: Routes = [
    {
        path: '', 
        component: EmployeeFeedbackComponent,
        children: [

             {
                path: '',
                component: EmployeeDashboardComponent,
            },
             {
                path: 'review',
                component: AddEmployeeReviewComponent,
            },
             {
                path: 'complaint',
                component: AddEmployeeComplaintComponent,
            },
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class EmployeeFeedbackRoutingModule {

}