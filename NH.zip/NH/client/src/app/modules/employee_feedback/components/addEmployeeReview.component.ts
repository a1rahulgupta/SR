import { Input, Output, EventEmitter, Component,ViewChild,AfterViewInit, ElementRef } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { requiredTrim } from "../../../core/validators/validators";
import { EmployeeFeedbackService } from "../service/employee_feedback.service";
import { WebStorage } from "../../../core/utility/web.storage";

@Component({
  selector: 'app-employee_review',
  preserveWhitespaces: false,
  templateUrl: './view/addEmployeeReview.component.html',
  providers: [
    EmployeeFeedbackService
  ]
})
export class AddEmployeeReviewComponent {
    user: any;
    loading: boolean;
  getCategoryList: any;

  public verifyStatus: number = 0;
  public employeeReviewFrm: FormGroup;
  public httpCall: any = false;
  @Input() score;
	@Input() maxScore = 5;
	@Input() forDisplay = false;
	@Output() rateChanged = new EventEmitter();
  
  range = [];
  marked = -1;
  constructor(
    private toaster: ToastrService,
    private employeeFeedbackService: EmployeeFeedbackService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private utills: Utills,
    private config: AppConfig,
    private storage: WebStorage
      ) {
    this.employeeReviewFrm = formBuilder.group({
      comments:['',[requiredTrim]],
      rating:[''],
      category_id:['',[requiredTrim]]

    });
  }

	ngOnInit() {
    this.employeeFeedbackService.getCategory({}).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.getCategoryList = rs.data;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
    for (var i = 0; i < this.maxScore; i++) {
      this.range.push(i);
    }
  }
  
  public mark = (index) => {
    this.marked = this.marked == index ? index - 1 : index;
    this.score = this.marked + 1;
    this.rateChanged.next(this.score);
  }

  public isMarked = (index) => {
    if (!this.forDisplay) {
      if (index <= this.marked) {
        return 'fa-star';
      }
      else {
        return 'fa-star-o';
      }
    }
    else {
      if (this.score >= index + 1) {
        return 'fa-star';
      }
      else if (this.score > index && this.score < index + 1) {
        return 'fa-star-half-o';
      }
      else {
        return 'fa-star-o';
      }
    }
  }


  send() {
    this.httpCall = true;
    this.user = this.storage.get(this.config.token.userKey);
    var employeeReview = this.employeeReviewFrm.value;
        employeeReview.email = this.user.email;
        employeeReview.firstName = this.user.firstName;
        employeeReview.lastName = this.user.lastName;
        employeeReview.phoneNumber = this.user.phoneNumber;
        employeeReview.userFacilityId = this.user.userFacId;
        employeeReview.rating = this.score;
    this.employeeFeedbackService.addEmployeeReview(employeeReview).subscribe((result: any) => {
      this.httpCall = false;
      var rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.toaster.success(rs.message);
        this.router.navigate(['/facility/employee_feedback/']);
      } else {
        this.toaster.error(rs.message);
      }
    });
  }

}