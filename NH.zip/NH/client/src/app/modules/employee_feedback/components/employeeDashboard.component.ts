import { Input, Output, EventEmitter, Component,ViewChild,AfterViewInit, ElementRef } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { UserService } from "../../../core/services/user.services";
import { requiredTrim } from "../../../core/validators/validators";
import { WebStorage } from "../../../core/utility/web.storage";


@Component({
  selector: 'app-employee_review',
  preserveWhitespaces: false,
  templateUrl: './view/employeeDashboard.component.html',
  providers: [
    UserService
  ]
})
export class EmployeeDashboardComponent {
  kioskMode: boolean;
  prevNowPlaying: any;
  time: Date;
  user: any;
  constructor(
    public config: AppConfig,
    private router: Router,
    private storage: WebStorage,
  ) {
    
  }

	ngOnInit() {
    this.user = this.storage.get(this.config.token.userKey);
    if (this.storage.get(this.config.storage.KIOSK_MODE) == true) {
      this.kioskMode = true;
      this.router.navigate(['/facility/visitorKiosk']);
    } else {
      this.kioskMode = false;
    }
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
  }
  




}