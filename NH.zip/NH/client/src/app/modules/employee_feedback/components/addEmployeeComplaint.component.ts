import { Component } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { requiredTrim } from "../../../core/validators/validators";
import { EmployeeFeedbackService } from "../service/employee_feedback.service";
import { WebStorage } from "../../../core/utility/web.storage";


@Component({
    selector: 'app-employee_complaint',
    preserveWhitespaces: false,
    templateUrl: './view/addEmployeeComplaint.component.html',
    providers: [
        EmployeeFeedbackService
    ]
})
export class AddEmployeeComplaintComponent {
    user: any;
    getCategoryList: any;
    loading: any;
    public employeeComplaintFrm: FormGroup;
    public httpCall: any = false;
    constructor(
        private toaster: ToastrService,
        private employeeFeedbackService: EmployeeFeedbackService,
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private formBuilder: FormBuilder,
        private utills: Utills,
        private storage: WebStorage,
        private config: AppConfig
    ) {
        this.employeeComplaintFrm = formBuilder.group({
            complaint: ['', [requiredTrim]],
            category_id: ['', [requiredTrim]]
        });
    }

    ngOnInit() {
        this.employeeFeedbackService.getCategory({}).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.getCategoryList = rs.data;
            } else {
                this.toaster.error(rs.message);
            }
            this.loading = false;
        });
    }
    send() {
        this.httpCall = true;
        this.user = this.storage.get(this.config.token.userKey);
        var employeeComplaint = this.employeeComplaintFrm.value;
        employeeComplaint.email = this.user.email;
        employeeComplaint.firstName = this.user.firstName;
        employeeComplaint.lastName = this.user.lastName;
        employeeComplaint.phoneNumber = this.user.phoneNumber;
        employeeComplaint.complaint = this.employeeComplaintFrm.value.complaint;
        employeeComplaint.category_id = this.employeeComplaintFrm.value.category_id;
        employeeComplaint.userFacilityId = this.user.userFacId;
        console.log("employeeComplaint", employeeComplaint);
        this.employeeFeedbackService.addEmployeeComplaint(employeeComplaint).subscribe((result: any) => {
            this.httpCall = false;
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.toaster.success(rs.message);
                this.router.navigate(['/facility/employee_feedback/']);
            } else {
                this.toaster.error(rs.message);
            }
        });
    }

}