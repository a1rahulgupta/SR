import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from "../../../core/utility/http.client";


@Injectable()
export class EmployeeFeedbackService {
  constructor(
    private http: HttpClient
  ) { }

  addEmployeeReview(data: any): Observable<any> {
    return this.http.post('/feedback/addEmployeeReview', data);
  }

  addEmployeeComplaint(data: any): Observable<any> {
    return this.http.post('/feedback/addEmployeeComplaint', data);
  }
  addPatientReview(data: any): Observable<any> {
    return this.http.post('/feedback/addPatientReview', data);
  }
  addPatientComplaint(data: any): Observable<any> {
    return this.http.post('/feedback/addPatientComplaint', data);
  }
  getCategory(data:any): Observable<any>{
    return this.http.post('/feedback/getCategoryList', data);
  }
}
