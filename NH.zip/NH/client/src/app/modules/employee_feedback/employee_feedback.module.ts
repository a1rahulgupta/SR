import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
  PaginationModule
} from 'ngx-bootstrap';
import {
  ConfirmDialogModule,
  ConfirmationService
} from 'primeng/primeng';

import { EmployeeDashboardComponent } from "./components/employeeDashboard.component";
import { EmployeeFeedbackComponent } from "./employee_feedback.component";
import { EmployeeFeedbackRoutingModule } from "./employee_feedback-routing.module";
import { AddEmployeeComplaintComponent } from "./components/addEmployeeComplaint.component";
import { AddEmployeeReviewComponent } from "./components/addEmployeeReview.component";

@NgModule({
    imports: [
        CommonModule, 
        FormsModule,
        ReactiveFormsModule,
        PaginationModule.forRoot(),
        ConfirmDialogModule,
        EmployeeFeedbackRoutingModule
    ],
    declarations: [
        EmployeeFeedbackComponent,
        AddEmployeeReviewComponent,
        EmployeeDashboardComponent,
        AddEmployeeComplaintComponent
    ],
    providers: [
        ConfirmationService
    ]
})
export class EmployeeFeedbackModule { }