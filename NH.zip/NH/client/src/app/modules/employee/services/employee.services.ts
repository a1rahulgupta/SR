import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '../../../core/utility/http.client';


@Injectable()
export class EmployeeService {
  constructor(
    private http: HttpClient
  ) { }

  //employee start
  getEmployeeById(data: any): Observable<any> {
    return this.http.get('/employee/getEmployeeById', data);
  }

  getAllEmployeeList(data: any): Observable<any> {
    return this.http.post('/employee/getAllEmployeeList', data);
  }

  deleteEmployee(data: any): Observable<any> {
    return this.http.post('/employee/deleteEmployee', data);
  }
  exportXml(data: any): Observable<any> {
    return this.http.post('/company/exportXml', data);
  }
  activateDeactivateEmployee(data: any): Observable<any> {
    return this.http.post('/employee/activateDeactivateEmployee', data);
  }
  getEmployeePermissions(data: any): Observable<any> {
    return this.http.post('/employee/getEmployeePermissions', data);
  }
  updateEmployeePermission(data: any): Observable<any> {
    return this.http.post('/employee/updateEmployeePermission', data);
  }
  //employee end

}
