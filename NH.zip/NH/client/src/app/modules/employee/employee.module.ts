import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
    PaginationModule
} from 'ngx-bootstrap';
import {
    ConfirmDialogModule,
    ConfirmationService,
    DialogModule,
    CalendarModule,
    ProgressSpinnerModule
} from 'primeng/primeng';

import { EmployeeRoutingModule } from "./../../modules/employee/employee-routing.module";
import { EmployeeComponent } from "./../../modules/employee/employee.component";
import { EmployeeListComponent } from "./../../modules/employee/components/employee_list.component";
import { EmployeeAddComponent } from "./../../modules/employee/components/employee_add.component";
import { EmployeeEditComponent } from "./../../modules/employee/components/employee_edit.component";
import { ImageCropperModule } from 'ngx-image-cropper';
import { DataTableModule } from 'primeng/primeng';
import { MultiSelectModule } from 'primeng/primeng';
import { EmployeeViewComponent } from "./components/employee_view.component";
import { PopoverModule } from "ngx-popover";



@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PaginationModule.forRoot(),
        ConfirmDialogModule,
        EmployeeRoutingModule,
        ImageCropperModule,
        DataTableModule,
        MultiSelectModule,
        ProgressSpinnerModule,
        DialogModule,
        CalendarModule,
        PopoverModule
    ],
    declarations: [
        EmployeeComponent,
        EmployeeListComponent,
        EmployeeAddComponent,
        EmployeeEditComponent,
        EmployeeViewComponent
    ],
    providers: [
        ConfirmationService
    ]
})
export class EmployeeModule { }