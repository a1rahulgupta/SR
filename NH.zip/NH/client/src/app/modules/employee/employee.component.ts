import { Component } from "@angular/core";
// import {
//     Router, NavigationStart, NavigationCancel, NavigationEnd
// } from '@angular/router';

@Component({
    template: `
        <p-confirmDialog header="Confirmation" icon="fa fa-question-circle"></p-confirmDialog>
        <router-outlet></router-outlet>
    `,
})
export class EmployeeComponent {
    // loading: any;
    // constructor(
    //     private router: Router
    // ) {
    //     this.loading = true;
    // }
    // ngAfterViewInit() {
    //     this.router.events
    //         .subscribe((event) => {
    //             if (event instanceof NavigationStart) {
    //                 this.loading = true;
    //             }
    //             else if (
    //                 event instanceof NavigationEnd ||
    //                 event instanceof NavigationCancel
    //             ) {
    //                 this.loading = false;
    //             }
    //         });
    // }
}

