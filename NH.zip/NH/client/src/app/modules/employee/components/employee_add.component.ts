
import { Component, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';
import { WebStorage } from './../../../core/utility/web.storage';
import { requiredTrim } from "./../../../core/validators/validators";
import { EmployeeService } from '../services/employee.services';
declare var jQuery: any;
declare var $: any;



@Component({
  selector: 'app-employee-add',
  preserveWhitespaces: false,
  templateUrl: './view/employee_add.view.html',
  providers: [
    EmployeeService
  ]
})
export class EmployeeAddComponent {
  kioskMode: boolean;
  display: boolean = false;
  showFileName: boolean = false;
  baseImage: Blob;
  fileNameData: any;
  imageChangedEvent: any = '';
  croppedImage: any = '';
  cropperReady = false;
  time: Date;
  prevNowPlaying: any;
  loading: boolean = false;
  getFacilityList: any;
  phoneNumber: any;
  public httpCall: any = false;
  public logoSelected: any = true;
  public employeeFrm: FormGroup;
  imageData: any;

  constructor(
    private toaster: ToastrService,
    private employee: EmployeeService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public config: AppConfig,
    private formBuilder: FormBuilder,
    public utills: Utills,
    private tmpStorage: TmpStorage,
    private storage: WebStorage
  ) {
    this.employeeFrm = formBuilder.group({
      firstName: ['', [requiredTrim]],
      lastName: ['', [requiredTrim]],
      email: ['', [requiredTrim, Validators.pattern(this.config.pattern.EMAIL)]],
      country_code: ['+1', [requiredTrim]],
      filename: [{ value: '', disabled: true }],
      phoneNumber: ['', [requiredTrim, Validators.minLength(10), Validators.maxLength(10)]],
    });
  }
  fileChangeEvent(event: any): void {
    this.display = true;
    this.imageChangedEvent = event;
    let fileName = event.target.files[0];
    this.fileNameData = fileName.name;
  }
  imageLoaded() {
    this.cropperReady = true;
  }
  loadImageFailed() {
    this.display = false;
    this.toaster.error("You can upload only .jpg, .jpeg, .png file");
  }

  selectImage(action: any) {
    if (action == true) {
      this.imageLoaded();
      this.display = false;
    } else {
      this.display = false;
    }
  }

  public imageCropped(fileData: any) {
    this.croppedImage = fileData;
    let fileName = this.fileNameData;
    this.baseImage = this.utills.dataURItoBlob(fileData);
    let file = this.baseImage;
    let alowedSize = 1024 * 1024 * this.config.MaxUploadSixe;
    if (this.config.alowedFiletypes.indexOf(file.type) >= 0) {
      if (file.size <= alowedSize) {
        this.showFileName = true;
        this.employeeFrm.controls['filename'].patchValue(fileName);
      } else {
        this.toaster.error("Please select a file within " + this.config.MaxUploadSixe + "MB");
      }
    } else {
      this.toaster.error("You can upload only .jpg, .jpeg, .png, .gif file");
    }
  }

  public save(fileData) {
    this.loading = true;
    fileData = this.croppedImage;
    let fileName = this.fileNameData;
    let url = this.config.apiUrl + "/employee/addEmployee";
    if (fileData != '') {
      this.baseImage = this.utills.dataURItoBlob(fileData);
      let file = this.baseImage;
      let alowedSize = 1024 * 1024 * this.config.MaxUploadSixe;
      if (this.config.alowedFiletypes.indexOf(file.type) >= 0) {
        if (file.size <= alowedSize) {
          this.httpCall = true;
          this.phoneNumber = this.employeeFrm.value.country_code + this.employeeFrm.value.phoneNumber;
          let formData = new FormData();
          formData.append("file", file, fileName);
          formData.append("email", this.employeeFrm.value.email);
          formData.append("firstName", this.employeeFrm.value.firstName);
          formData.append("lastName", this.employeeFrm.value.lastName);
          formData.append("phoneNumber", this.phoneNumber);

          this.xhrRequest(url, formData);
        } else {
          this.toaster.error("Please select a file within " + this.config.MaxUploadSixe + "MB");
        }
      } else {
        this.toaster.error("You can upload only .jpg, .jpeg, .png file");
      }
    } else {
      console.log("fileData----else-----", fileData);

      this.httpCall = true;
      this.phoneNumber = this.employeeFrm.value.country_code + this.employeeFrm.value.phoneNumber;
      let formData = new FormData();
      formData.append("email", this.employeeFrm.value.email);
      formData.append("firstName", this.employeeFrm.value.firstName);
      formData.append("lastName", this.employeeFrm.value.lastName);
      formData.append("phoneNumber", this.phoneNumber);
      this.xhrRequest(url, formData);
    }
  }

  private xhrRequest(url, formData) {
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          this.loading = false;
          this.httpCall = false;
          let rs = JSON.parse(xhr.response);
          if (rs.code == this.config.statusCode.success) {
            this.toaster.success(rs.message);
            this.router.navigate(['/facility/employee']);
          } else {
            this.loading = false;
            this.toaster.error(rs.message);
          }
        } else {
          this.loading = false;
          this.httpCall = false;
          let rs = JSON.parse(xhr.response);
          if (rs.code == this.config.statusCode.success) {
            this.toaster.success(rs.message);
            this.router.navigate(['/facility/employee']);
          } else {
            this.toaster.error(rs.message);
          }
        }
      }
    }
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Authorization", "Bearer " + this.storage.get(this.config.token.keyID));
    xhr.send(formData);
  }

  public ngOnInit() {
    if (this.storage.get(this.config.storage.KIOSK_MODE) == true) {
      this.kioskMode = true;
      // this.toaster.success("Visitor Kiosk Mode On.");
      this.router.navigate(['/facility/visitorKiosk']);
    } else {
      this.kioskMode = false;
    }
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
  }

}
