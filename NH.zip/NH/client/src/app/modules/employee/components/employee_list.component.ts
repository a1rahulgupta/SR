import { Component, Inject, Output, ViewChild, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import { AppConfig } from './../../../core/config/app.config';
import { Utills } from './../../../core/utility/utills';
import { TmpStorage } from './../../../core/utility/temp.storage';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
import { EmployeeViewComponent } from './employee_view.component';
import { EmployeeService } from '../services/employee.services';
import { WebStorage } from '../../../core/utility/web.storage';
type AOA = Array<Array<any>>;

@Component({
  selector: 'app-employee-list',
  preserveWhitespaces: false,
  templateUrl: './view/employee_list.view.html',
  styles: [`
  :host >>> .popover {
    color: #FFFFFF;
    background: #000000;
  
  }
 
`],
  providers: [
    EmployeeService
  ]
})
export class EmployeeListComponent {
  kioskMode: boolean;
  user: any;
  permissionArray: any = {
    employee: {
      "status": false,
      "add": false,
      "edit": false,
      "delete": false,
      "activateDeactivate": false,
      "managePermission": false
    }
  };
  permission: any = {
    visitors: {
      "status": false,
      "edit": false,
      "visitorsList": false,
      "isCheckInAlert": false,
      "isAppMessagePopUp": false,
      "checkInLogList": false,
      "latestNegativeResponseList": false,
      "isSms": false,
      "twilioChat": false,
      "documentIncident": false,
      "stickyNote": false
    },
    employee: {
      "status": false,
      "list": false,
      "add": false,
      "edit": false,
      "delete": false,
      "activateDeactivate": false,
      "managePermission": false
    },
    kiosk: {
      "status": false,
      "visitorKiosk": false,
      "patientKiosk": false
    },
    newsFeed: {
      "status": false,
      "list": false,
      "save": false,
      "remove": false
    },
    dashboard: {
      "status": false,
      "totalVisitorsCount": false,
      "positiveRatingsCount": false,
      "negativeRatingsCount": false,
      "smsMessageCount": false,
      "clickTrackerSection": false,
      "todayChackList": false,
      "latestNegativeResponse": false,
      "latestPositiveRatings": false,
      "latestNegativeRatings": false,
      "visitorTrendsGraph": false,
      "visitorRatingGraph": false,
      "message": false,
      "responseRate": false,
      "linkTracking": false,
      "latestVisitorsList": false,
      "overallRatingGraph": false
    },
    incidentClaimReports: {
      "status": false,
      "allReports": false,
      "myReports": false

    },
    settings: {
      "status": false,
      "serviceStatus": false,
      "appSettings": false,
      "smsSettings": false,
      "ratingAndResponseSettings": false
    },
    googleLink: {
      "status": false,
      "viewGoogleLink": false
    }
  };
  permissionDialog: boolean;
  commingsoon: boolean;
  time: Date;
  prevNowPlaying: any;
  employeeViewDialoge: boolean;
  display: boolean;
  facilityViewDialoge: boolean;
  @ViewChild('EmployeeViewComponent')
  private EmployeeViewComponent: EmployeeViewComponent;


  public listData: any = [];
  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private employee: EmployeeService,
    private storage: WebStorage,
    private router: Router,
    private utills: Utills,
    private tmpStorage: TmpStorage,
    private confirmationService: ConfirmationService,

  ) {
  }

  /*------------------ Listing Elements --------------------*/
  public asc: string = 'asc';
  public loading: boolean = true;
  public exportfile: string = '';
  // public columnOptions: SelectItem = [];
  public totalItems: number = 0;
  public body: any = {
    'page': 1,
    'count': this.config.perPageDefault,
    'searchText': '',
    'phoneNumber': '',
    'userName': '',
    'createdAt': '',
    'sorting': 'createdAt',
    'order': 'asc',
  };

  public setRecordPerPage(records: number): void {
    this.body.page = 1;
    this.body.limit = records;
    this.getAll();
  }


  public sort(field: string, order: any): void {
    if (order == 'asc') {
      this.asc = 'asc';
    } else {
      this.asc = 'desc';
    }
    this.body.sorting = field;
    this.body.order = order;
    this.getAll();
  }

  public pageChanged(event: any): void {
    this.body.page = event.page;
    this.getAll();
  }

  public resetSearch(): void {
    this.body.userName = '';
    this.body.phoneNumber = '';
    this.body.createdAt = '';
    this.getAll()
  }

  public changePageLimit(pageLimit: any) {
    this.body.limit = pageLimit;
    this.getAll()
  }


  public getAll() {
    this.loading = true;
    this.employee.getAllEmployeeList(this.body).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.listData = rs.data.data;
        this.totalItems = rs.data.total_count;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }
  /*------------------ Listing Elements --------------------*/

  public remove(_id: string, userFacId: string) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to delete?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        this.employee.deleteEmployee({ userId: _id, userFacId: userFacId }).subscribe((result) => {
          let rs = result.json();
          if (rs.code == this.config.statusCode.success) {
            this.getAll();
            this.toaster.success(rs.message);
          } else {
            this.toaster.error(rs.message);
          }
          this.loading = false;
        });
      },
      reject: () => {
      }
    });
  }
  public enable(userId: string, userFacId: string, status: string, by: string) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to change status?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var empObj = {
          userId: userId,
          userFacId: userFacId,
          status: status,
          by: by
        };
        console.log("empObj", empObj);
        this.employee.activateDeactivateEmployee(empObj).subscribe((result) => {
          let rs = result.json();
          if (rs.code == this.config.statusCode.success) {
            this.getAll();
            this.toaster.success(rs.message);
          } else {
            this.toaster.error(rs.message);
          }
          this.loading = false;
        });
      },
      reject: () => {
      }
    });
  }

  public exportAll(exportfile) {
    if (exportfile == 'xls') {
      this.exportXls();
    } else if (exportfile == 'json') {
      this.exportJson();
    } else if (exportfile == 'csv') {
      this.createCsvFile();
    } else if (exportfile == 'txt') {
      this.exportTxt();
    } else if (exportfile == 'xml') {
      this.exportXml();
    }
  }
  public showDialog() {
    this.display = true;
  }

  public getEmployeePermissions(employeeData: any) {
    var obj = {
      employeeId: employeeData._id,
      userFacId: employeeData.userFacId
    }
    this.employee.getEmployeePermissions(obj).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.permission = rs.data;
        console.log("getEmployeePermissions", rs.data);
        this.permissionDialog = true;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  public updateEmployeePermission(permission) {
    console.log("updateEmployeePermission", permission);
    this.permissionDialog = false;
    this.employee.updateEmployeePermission(permission).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.toaster.success(rs.message);
        this.getAll();
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }


  public createCsvFile() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to csv file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        var options = {
          fieldSeparator: ',',
          quoteStrings: '"',
          decimalseparator: '.',
          showLabels: true,
          showTitle: true,
          useBom: true
        };
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'Employee Name': this.listData[i].userName,
            'Phone': this.listData[i].phoneNumber,
            'Created At': this.listData[i].createdAt
          });
        }
        new Angular2Csv(data, 'listData', { headers: Object.keys(data[0]) });
      },
      reject: () => {
      }
    });
  }

  public exportTxt() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to text file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'Employee Name': this.listData[i].userName,
            'Phone': this.listData[i].phoneNumber,
            'CreatedAt': this.listData[i].createdAt
          });
        }
        var obj = objectToString(data);
        console.log(obj);
        function objectToString(obj) {
          var str = '';
          var i = 0;
          for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
              if (typeof obj[key] == 'object') {
                {
                  str += key + ' : { ' + objectToString(obj[key]) + '} ' + (i > 0 ? ',' : '');
                }
              }
              else {
                str += key + ':\'' + obj[key] + '\'' + (i > 0 ? ',' : '');
              }
              i++;
            }
          }
          return str;
        }
        var textToSave = obj,
          filename = 'file.txt',
          blob = new Blob([textToSave], { type: "text/plain;charset=utf-8" });
        saveAs(blob, filename);
      },
      reject: () => {
      }
    });
  }


  public exportXml() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to Xml file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'id': this.listData[i]._id,
            'column-1': this.listData[i].userName,
            'column-2': this.listData[i].phoneNumber,
            'column-3': this.listData[i].createdAt
          });

        }
        var obj = JSON.stringify(
          {
            "_declaration": {
              "_attributes": {
                "version": "1.0",
                "encoding": "utf-8"
              }
            },
            "tabledata": {
              "field": [
                [],
                "Name",
                "Phone",
                "Created At"
              ],
              "data": {
                "row": data
              }
            }
          }
        )
        this.employee.exportXml(obj).subscribe((result) => {
          let rs = result.json();
          var textToSave = rs.data,
            filename = 'file.xml',
            blob = new Blob([textToSave], { type: "'application/xml charset=utf-8'" });
          saveAs(blob, filename);
        })
      },
      reject: () => {
      }
    });

  }


  public exportJson() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to json file?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        var data = [];
        for (let i = 0; i < this.listData.length; i++) {
          data.push({
            'Employee Name': this.listData[i].userName,
            'Phone': this.listData[i].phoneNumber,
            'Created At': this.listData[i].createdAt
          });
        }
        var textToSave = JSON.stringify({ "header": [["Employee Name", "Phone", "Created At"]], "data": data }),
          filename = 'file.json',
          blob = new Blob([textToSave], { type: "'application/json; charset=utf-8'" });

        saveAs(blob, filename);
      },
      reject: () => {
      }
    });
  }

  public exportXls(): void {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Export the data to excel?',
      header: 'Confirmation',
      icon: 'fa fa-question-circle',
      accept: () => {
        let wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
        let fileName: string = 'Employee_' + new Date().getTime() + '.xlsx';
        let data: AOA = [
          [
            "Employee Name",
            "Phone",
            "Created At"
          ]
        ];

        this.listData.map((item: any) => {
          data.push([
            item.userName,
            item.phoneNumber,
            item.createdAt
          ]);
        });

        const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(data);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
        const wbout: ArrayBuffer = XLSX.write(wb, wopts);
        saveAs(new Blob([wbout], { type: 'application/octet-stream' }), fileName);
      },
      reject: () => {
      }
    });
  }



  public viewEmployee(employeeData: any) {
    var getData = employeeData;
    this.EmployeeViewComponent.getEmployeeData(getData);
    this.employeeViewDialoge = true;
  }
  public ngOnInit(): void {
    if (this.storage.get(this.config.storage.KIOSK_MODE) == true) {
      this.kioskMode = true;
      // this.toaster.success("Visitor Kiosk Mode On.");
      this.router.navigate(['/facility/visitorKiosk']);
    } else {
      this.kioskMode = false;
    }
    this.user = this.storage.get(this.config.token.userKey);
    if (this.user.role == 'employee') {
      var obj = {
        employeeId: this.user.uid,
      }
      this.employee.getEmployeePermissions(obj).subscribe((result) => {
        let rs = result.json();
        if (rs.code == this.config.statusCode.success) {
          this.permissionArray = rs.data;
        }
      })
    }
    this.getAll();
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
  }

  public support() {
    this.commingsoon = true;
  }

}
