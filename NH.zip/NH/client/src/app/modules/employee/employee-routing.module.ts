import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";

import { EmployeeComponent } from "./../../modules/employee/employee.component";
import { EmployeeListComponent } from "./../../modules/employee/components/employee_list.component";
import { EmployeeAddComponent } from "./../../modules/employee/components/employee_add.component";
import { EmployeeEditComponent } from "./../../modules/employee/components/employee_edit.component";

const routes: Routes = [
    {
        path: '', 
        component: EmployeeComponent,
        children: [
            {
                path: '',
                component: EmployeeListComponent,
            },
            {
                path: 'add',
                component: EmployeeAddComponent,
            },
            {
                path: 'edit/:id',
                component: EmployeeEditComponent,
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class EmployeeRoutingModule {

}