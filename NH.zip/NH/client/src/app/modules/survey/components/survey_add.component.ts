import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { SurveyService } from "../service/survey.service";
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { TmpStorage } from "../../../core/utility/temp.storage";
import { requiredTrim } from "../../../core/validators/validators";



@Component({
  selector: 'app-survey-add',
  preserveWhitespaces: false,
  templateUrl: './view/survey_add.view.html',
  providers: [
    SurveyService
  ]
})
export class SurveyAddComponent {
  time: Date;
  prevNowPlaying: any;

  public httpCall: any = false;

  constructor(
    private toaster: ToastrService,
    private survey: SurveyService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public config: AppConfig,
    private formBuilder: FormBuilder,
    private utills: Utills,
    private tmpStorage: TmpStorage
  ) {
    
  }


  public ngOnInit() {
   
   }

}
