import { Component, Inject, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';
import { SurveyService } from "../service/survey.service";
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { TmpStorage } from "../../../core/utility/temp.storage";
import { requiredTrim } from "../../../core/validators/validators";
import { SurveyViewComponent } from "./survey_view.component";

@Component({
  selector: 'app-survey-list',
  preserveWhitespaces: false,
  templateUrl: './view/survey_list.view.html',
  styles: [`
  :host >>> .popover {
    color: #FFFFFF;
    background: #000000;
  }
`],
  providers: [
    SurveyService
  ]
})
export class SurveyListComponent {
  prevNowPlaying: any;
  time: Date;
  // @ViewChild('SurveyViewComponent')
  private SurveyViewComponent: SurveyViewComponent;

  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private survey: SurveyService,
    private router: Router,
    private utills: Utills,
    private tmpStorage: TmpStorage,
    private confirmationService: ConfirmationService
  ) { }

  public ngOnInit(): void {
      var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
   
  }

}
