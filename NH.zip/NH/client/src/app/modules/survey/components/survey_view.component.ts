import { Component, OnInit, ViewChild, Output, EventEmitter, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms'
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MessageService } from 'primeng/components/common/messageservice';
import { AppConfig } from './../../../core/config/app.config';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/primeng';


@Component({
  selector: 'app-survey-view',
  preserveWhitespaces: false,
  templateUrl: './view/survey_view.view.html',
})
export class SurveyViewComponent implements OnInit {

  constructor(
    public config: AppConfig,
    private toaster: ToastrService,
    private router: Router,
    private confirmationService: ConfirmationService
  ) {
     
  }
  
 ngOnInit() {
  }

  
}




