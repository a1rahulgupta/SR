import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
    PaginationModule
} from 'ngx-bootstrap';
import {
    ConfirmDialogModule,
    ConfirmationService,
    DialogModule
} from 'primeng/primeng';
import { SurveyEditComponent } from "./components/survey_edit.component";
import { SurveyListComponent } from "./components/survey_list.component";
import { SurveyComponent } from "./survey.component";
import { SurveyRoutingModule } from "./survey-routing.module";
import { SurveyAddComponent } from "./components/survey_add.component";
import { SurveyViewComponent } from "./components/survey_view.component";
import { PopoverModule } from "ngx-popover";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PaginationModule.forRoot(),
        ConfirmDialogModule,
        SurveyRoutingModule,
        DialogModule,
        PopoverModule
    ],
    declarations: [
        SurveyComponent,
        SurveyListComponent,
        SurveyAddComponent,
        SurveyEditComponent,
        SurveyViewComponent
    ],
    providers: [
        ConfirmationService
    ]
})
export class SurveyModule { }