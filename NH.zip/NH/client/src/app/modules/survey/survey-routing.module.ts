import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";
import { SurveyEditComponent } from "./components/survey_edit.component";
import { SurveyAddComponent } from "./components/survey_add.component";
import { SurveyListComponent } from "./components/survey_list.component";
import { SurveyComponent } from "./survey.component";



const routes: Routes = [
    {
        path: '', 
        component: SurveyComponent,
        children: [
            {
                path: '',
                component: SurveyListComponent,
            },
            {
                path: 'add',
                component: SurveyAddComponent,
            },
            {
                path: 'edit/:id',
                component: SurveyEditComponent,
            },
    
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SurveyRoutingModule {

}