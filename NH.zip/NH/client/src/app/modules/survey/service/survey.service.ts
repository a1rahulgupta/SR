import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from "../../../core/utility/http.client";

@Injectable()
export class SurveyService {
  constructor(
    private http: HttpClient
  ) { }

  //Settings start
  // getSettings(data: any): Observable<any> {
  //   return this.http.get('/user/getSettingById', data);
  // }
  // getAllSetting(data: any): Observable<any> {
  //   return this.http.get('/user/getAllSetting', data);
  // }

  // updateSetting(data: any): Observable<any> {
  //   return this.http.post('/user/updateSetting', data);
  // }
  // addSetting(data: any): Observable<any> {
  //   return this.http.post('/user/addSetting', data);
  // }
  //settings end

}
