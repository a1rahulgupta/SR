import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
    PaginationModule
} from 'ngx-bootstrap';
import {
    ConfirmDialogModule,
    ConfirmationService,
    DialogModule,
    CalendarModule,
    TabViewModule
} from 'primeng/primeng';

import { RssFeedComponent } from "./rssFeed.component";
import { RssFeedRoutingModule } from "./rssFeed-routing.module";
import { RssFeedListComponent } from "./../../modules/rssFeed/components/rssFeed_list.component";
import { CountoModule }  from 'angular2-counto';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PaginationModule.forRoot(),
        ConfirmDialogModule,
        RssFeedRoutingModule,
        DialogModule,
        CalendarModule,
        TabViewModule,
        CountoModule
    ],
    declarations: [
        RssFeedComponent,
        RssFeedListComponent
    ],
    providers: [
        ConfirmationService
    ]
})
export class RssFeedModule { }