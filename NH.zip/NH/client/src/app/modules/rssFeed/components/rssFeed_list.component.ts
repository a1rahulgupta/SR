import { Input, Output, EventEmitter, Component, ViewChild, AfterViewInit, ElementRef } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../core/config/app.config";
import { Utills } from "../../../core/utility/utills";
import { requiredTrim } from "../../../core/validators/validators";
import { RssFeedService } from '../services/rssFeed.services';
import { WebStorage } from "../../../core/utility/web.storage";
import { EmployeeService } from "../../employee/services/employee.services";
declare var $: any;

@Component({
  selector: 'app-employee_review',
  preserveWhitespaces: false,
  templateUrl: './view/rssFeed_list.view.html',
  providers: [
    RssFeedService,
    EmployeeService
  ]
})
export class RssFeedListComponent {
  a : any;
  b: any;
  c: any;
  permissionData: any = {
    newsFeed: {
      "status": false,
      "save" : false, 
      "remove" : false
    }
  };
  user: any;
  kioskMode: boolean;
  time: Date;
  prevNowPlaying: any;
  viewTabIndex: any;
  savedRssFeedlist: any;
  index: any;
  totalItems: any;
  params: any;
  firstTab: number = 0;
  secTab: number = 1;
  rssFeedlist: any;
  rssChannelsList: any;
  public body: any = {
    'page': 1,
    'count': 10
  };
  constructor(
    private rssFeed: RssFeedService,
    private employee: EmployeeService,
    private router: Router,
    private storage: WebStorage,
    public config: AppConfig,
    private toaster: ToastrService
  ) { }

  /*------------------ Listing Elements --------------------*/
  public loading: boolean = true;

  public changePageLimit(pageLimit: any) {
    this.body.count = parseInt(pageLimit);
    if (this.viewTabIndex == 1) {
      this.getSavedRssFeeds();
    } else {
      this.getAllRssFeed();
    }
  }

  public pageChanged(event: any): void {
    this.body.page = event.page;
    if (this.viewTabIndex == 1) {
      this.getSavedRssFeeds();
    } else {
      this.getAllRssFeed();
    }
  }

  public getTabViewId(tabIndex) {
    this.viewTabIndex = tabIndex;
    this.body.page = 1;
    this.body.count = 10;
    if (this.viewTabIndex == 1) {
      this.getSavedRssFeeds();
    } else {
      this.getAllRssFeed();
    }
  }

  public getAllRssChannels() {
    this.loading = true;
    this.rssFeed.getAllRssChannels(this.body).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.rssChannelsList = rs.data;
        this.getAllRssFeed();
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  public getAllRssFeed() {
    this.loading = true;
    this.body.rssChannelsList = this.rssChannelsList;
    this.rssFeed.getAllRssFeed(this.body).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.rssFeedlist = rs.data.data;
        this.totalItems = rs.data.total_count;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  public selectionRssChannels(id, status) {
    this.rssFeed.selectionRssChannels({ id: id, status: status }).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        if (this.viewTabIndex == 0) {
          this.getAllRssFeed();
        } else {
          this.getSavedRssFeeds();
        }
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  public saveFacilityFavouriteFeed(id, rssChannelId: any) {
    this.rssFeed.saveFacilityFavouriteFeed({ id: id, rssChannelId: rssChannelId }).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.toaster.success(rs.message);
        this.getAllRssFeed();
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  public getSavedRssFeeds() {
    this.loading = true;
    this.body.rssChannelsList = this.rssChannelsList;
    this.rssFeed.getSavedRssFeeds(this.body).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.savedRssFeedlist = rs.data.data;
        this.totalItems = rs.data.total_count;
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  public removeSavedFeed(id, rssChannelId: any) {
    this.rssFeed.removeSavedFeed({ id: id, rssChannelId: rssChannelId }).subscribe((result) => {
      let rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.toaster.success(rs.message);
        this.getSavedRssFeeds();
      } else {
        this.toaster.error(rs.message);
      }
      this.loading = false;
    });
  }

  public getDetails(id: any){
    alert(id);
  }

  public ngOnInit(): void {
    this.user = this.storage.get(this.config.token.userKey);
    if(this.user.role == 'employee'){
        var obj = {
          employeeId: this.user.uid,
        }
        this.employee.getEmployeePermissions(obj).subscribe((result) => {
          let rs = result.json();
          if (rs.code == this.config.statusCode.success) {
            this.permissionData = rs.data;
            console.log("this.permissionData",this.permissionData);
          }
        })

      }
    if (this.storage.get(this.config.storage.KIOSK_MODE) == true) {
      this.kioskMode = true;
      // this.toaster.success("Visitor Kiosk Mode On.");
      this.router.navigate(['/facility/visitorKiosk']);
    } else {
      this.kioskMode = false;
    }
    var stationdate = new Date();
    if (this.prevNowPlaying) {
      clearInterval(this.prevNowPlaying);
    }
    this.prevNowPlaying = setInterval(() => {
      stationdate = new Date(stationdate.setSeconds(stationdate.getSeconds() + 1));
      this.time = stationdate;
    }, 1000);
    
    this.firstTab = 0;
    this.secTab = 1;
    this.viewTabIndex = 0;
    this.getAllRssChannels();
  
  }
  
}