import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '../../../core/utility/http.client';


@Injectable()
export class RssFeedService {
  constructor(
    private http: HttpClient
  ) { }

  //rssFeed start
  getAllRssChannels(data: any): Observable<any> {
    return this.http.get('/rssFeed/getAllRssChannels', data);
  }

  getAllRssFeed(data: any): Observable<any> {
    return this.http.post('/rssFeed/getAllRssFeed', data);
  }

  selectionRssChannels(data: any): Observable<any> {
    return this.http.post('/rssFeed/selectionRssChannels', data);
  }

  saveFacilityFavouriteFeed(data: any): Observable<any> {
    return this.http.post('/rssFeed/saveFacilityFavouriteFeed', data);
  }

  getSavedRssFeeds(data: any): Observable<any> {
    return this.http.post('/rssFeed/getSavedRssFeeds', data);
  }

  removeSavedFeed(data: any): Observable<any> {
    return this.http.post('/rssFeed/removeSavedFeed', data);
  }
//   exportXml(data: any): Observable<any> {
//     return this.http.post('/company/exportXml', data);
//   }
//   activateDeactivateEmployee(data: any): Observable<any> {
//     return this.http.post('/employee/activateDeactivateEmployee', data);
//   }
  //employee end

}
