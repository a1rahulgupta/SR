import { NgModule } from "@angular/core";
import { Router, Route, Routes, RouterModule } from "@angular/router";
import { RssFeedComponent } from "./rssFeed.component";
import { RssFeedListComponent } from "./../../modules/rssFeed/components/rssFeed_list.component";



const routes: Routes = [
    {
        path: '', 
        component: RssFeedComponent,
        children: [
            {
                path: '',
                component: RssFeedListComponent,
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class RssFeedRoutingModule {

}