import { Component } from "@angular/core";
import { Router } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators, NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

import { AppConfig } from './../core/config/app.config';
import { Utills } from './../core/utility/utills';
import { TmpStorage } from './../core/utility/temp.storage';
import { WebStorage } from "./../core/utility/web.storage";
import { AuthService } from "./../core/services/auth.service";
// import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ProgressSpinnerModule } from 'primeng/primeng';
import {
    NavigationStart, NavigationCancel, NavigationEnd
} from '@angular/router';


import { requiredTrim } from "./../core/validators/validators";

@Component({
    selector: 'app-login',
    preserveWhitespaces: false,
    templateUrl: './view/login.component.html'
})
export class LoginComponent {
    commingsoon: boolean;

    public userlogin: FormGroup;
    private redirectUrl: any;
    public httpCall: any = false;
    loading: any;


    constructor(
        private toaster: ToastrService,
        private auth: AuthService,
        private router: Router,
        private formBuilder: FormBuilder,
        private utills: Utills,
        private tmpStorage: TmpStorage,
        private config: AppConfig,
        private storage: WebStorage
    ) {
        this.loading = true;
        this.redirectUrl = (this.utills.notEmpty(this.tmpStorage.get('redirectUrl'))) ? this.tmpStorage.get('redirectUrl') : 'user/dashboard';
        this.tmpStorage.remove('redirectUrl');

        this.userlogin = formBuilder.group({
            email: ['', [requiredTrim]],
            password: ['', [requiredTrim]],
            rememberme: [true]
        });
    }

    login() {
        this.httpCall = true;
        this.auth.login(this.userlogin.value).subscribe((res: any) => {
            this.httpCall = false;
            console.log("res", res);
            if (!res.auth) {
                this.toaster.error(res.message);
            }
            else if (res.role == this.config.role_type.SUPER_ADMIN.name) {
                this.router.navigate(['admin']);
            } else if (res.role == this.config.role_type.COMPANY_ADMIN.name) {
                this.router.navigate(['company']);
            } else if (res.role == this.config.role_type.FACILITY_ADMIN.name) {
                this.router.navigate(['facility']);
            } else { // This refer to employee of facility
                this.router.navigate(['facility']);
            }
        });
    }
    support() {
        this.commingsoon = true;
    }

    ngOnInit() {
        this.storage.clear(this.config.token.keyID);
        this.storage.clear(this.config.token.userKey);
        this.storage.clear(this.config.token.keyID);
        this.storage.clear(this.config.token.userKey);
        this.storage.clear(this.config.storage.VISITOR_PHONE);
        this.storage.clear(this.config.storage.VISITOR_ID);
        let switchLogin = this.storage.get(this.config.storage.SWITCH);
        console.log("switchLogin----------------", switchLogin);
        // if(switchLogin != '' && switchLogin != null && switchLogin != undefined){
        //     console.log("switchLogin",switchLogin);
        //   this.userlogin.value.email = this.storage.get(this.config.storage.EMAIL),
        //   this.userlogin.value.password = this.storage.get(this.config.storage.PASSWORD)
        //   console.log("this.userlogin.value",this.userlogin.value);
        //   this.login();

        // }
    }


    ngAfterViewInit() {
        this.router.events
            .subscribe((event) => {
                if (event instanceof NavigationStart) {
                    this.loading = true;
                }
                else if (
                    event instanceof NavigationEnd ||
                    event instanceof NavigationCancel
                ) {
                    this.loading = false;
                }
            });
    }
}
















