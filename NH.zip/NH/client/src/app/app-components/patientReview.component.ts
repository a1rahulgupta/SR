import { Input, Output, EventEmitter, Component, ViewChild, AfterViewInit, ElementRef } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

import { AppConfig } from './../core/config/app.config';
import { Utills } from './../core/utility/utills';
import { UserService } from './../core/services/user.services';

import { requiredTrim } from "./../core/validators/validators";

import {
  NavigationStart, NavigationCancel, NavigationEnd
} from '@angular/router';


@Component({
  selector: 'app-patient_review',
  preserveWhitespaces: false,
  templateUrl: './view/patientReview.component.html',
  providers: [
    UserService
  ]
})
export class PatientReviewComponent {

  public verifyStatus: number = 0;
  public patientReviewFrm: FormGroup;
  public httpCall: any = false;
  @Input() score;
  @Input() maxScore = 5;
  @Input() forDisplay = false;
  @Output() rateChanged = new EventEmitter();

  range = [];
  marked = -1;

  loading: any;

  constructor(
    private toaster: ToastrService,
    private user: UserService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private utills: Utills,
    private config: AppConfig
  ) {
    this.loading = true;
    this.patientReviewFrm = formBuilder.group({
      email: ['', [requiredTrim, Validators.pattern(this.config.pattern.EMAIL)]],
      patient_name: ['', [requiredTrim]],
      patient_phone: ['', [requiredTrim]],
      review: ['', [requiredTrim]],
      rating: [''],
      categoryName: ['', [requiredTrim]]
    });
  }

  ngOnInit() {
    for (var i = 0; i < this.maxScore; i++) {
      this.range.push(i);
    }
  }

  public mark = (index) => {
    console.log("mark", index);
    this.marked = this.marked == index ? index - 1 : index;
    this.score = this.marked + 1;
    this.rateChanged.next(this.score);
  }

  public isMarked = (index) => {
    console.log("isMarked", index);
    if (!this.forDisplay) {
      if (index <= this.marked) {
        return 'fa-star';
      }
      else {
        return 'fa-star-o';
      }
    }
    else {
      if (this.score >= index + 1) {
        return 'fa-star';
      }
      else if (this.score > index && this.score < index + 1) {
        return 'fa-star-half-o';
      }
      else {
        return 'fa-star-o';
      }
    }
  }


  send() {
    this.httpCall = true;
    this.patientReviewFrm.value.rating = this.score;
    console.log("this.patientReviewFrm.value.rating", this.patientReviewFrm.value.rating);
    this.user.sendPatientReview(this.patientReviewFrm.value).subscribe((result: any) => {
      this.httpCall = false;
      var rs = result.json();
      if (rs.status == this.config.statusCode.success) {
        this.toaster.success(rs.message);
        this.router.navigate(['login']);
      } else {
        this.toaster.error(rs.message);
      }
    });
  }




  ngAfterViewInit() {
    this.router.events
      .subscribe((event) => {
        if (event instanceof NavigationStart) {
          this.loading = true;
        }
        else if (
          event instanceof NavigationEnd ||
          event instanceof NavigationCancel
        ) {
          this.loading = false;
        }
      });
  }
}


