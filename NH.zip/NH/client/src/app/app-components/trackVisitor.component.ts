import { Component } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { AppConfig } from './../core/config/app.config';
import { UserService } from './../core/services/user.services';
import { ToastrService } from "ngx-toastr";
import {
    NavigationStart, NavigationCancel, NavigationEnd
} from '@angular/router';


@Component({
    templateUrl: './view/trackVisitor.component.html',
    providers: [
        UserService
    ]
})
export class TrackVisitorComponent {
    googleLink: any;

    public trackStatus: number = 0;
    loading: any;


    constructor(
        private user: UserService,
        private toaster: ToastrService,
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private config: AppConfig
    ) { this.loading = true; }

    public ngOnInit() {
        this.trackStatus = 1;
        this.activatedRoute.params.subscribe((param: any) => {
            this.user.trackVisitorViewedLink({ trackingToken: param['id'] }).subscribe((result: any) => {
                var rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.trackStatus = 2;
                    window.location.href = rs.data;
                } else if (rs.code == this.config.statusCode.invalid) {
                    this.trackStatus = 3;
                } else {
                    this.trackStatus = 4;
                }
            });
        });
    }



    ngAfterViewInit() {
        this.router.events
            .subscribe((event) => {
                if (event instanceof NavigationStart) {
                    this.loading = true;
                }
                else if (
                    event instanceof NavigationEnd ||
                    event instanceof NavigationCancel
                ) {
                    this.loading = false;
                }
            });
    }
}
