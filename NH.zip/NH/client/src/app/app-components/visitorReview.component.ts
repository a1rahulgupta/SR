import { Input, Output, EventEmitter, Component, ViewChild, AfterViewInit, ElementRef } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { UserService } from "../core/services/user.services";
import { Utills } from "../core/utility/utills";
import { AppConfig } from "../core/config/app.config";
import { WebStorage } from "../core/utility/web.storage";
import { requiredTrim } from "../core/validators/validators";
import {
    NavigationStart, NavigationCancel, NavigationEnd
} from '@angular/router';

@Component({
    selector: 'app-visitor-review',
    preserveWhitespaces: false,
    templateUrl: './view/visitorReview.component.html',
    providers: [
        UserService
    ]
})
export class VisitorReviewComponent {
    reviewData: any;
    user: any;
    loading: any;
    getCategoryList: any;

    public verifyStatus: number = 0;
    public visitorReviewFrm: FormGroup;
    public httpCall: any = false;
    @Input() score;
    @Input() maxScore = 5;
    @Input() forDisplay = false;
    @Output() rateChanged = new EventEmitter();

    range = [];
    marked = -1;

    constructor(
        private toaster: ToastrService,
        private userService: UserService,
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private formBuilder: FormBuilder,
        private utills: Utills,
        private config: AppConfig,
        private storage: WebStorage
    ) {
        this.loading = true;
        this.visitorReviewFrm = formBuilder.group({
            comments: ['', [requiredTrim]],
            rating: [''],

        });
    }

    ngOnInit() {
        this.verifyStatus = 1;
        this.activatedRoute.params.subscribe((param: any) => {
            this.userService.verifyReviewToken({ reviewToken: param['id'] }).subscribe((result: any) => {
                var rs = result.json();
                console.log("rs-------verifyReview", rs);
                if (rs.code == this.config.statusCode.success) {
                    this.reviewData = rs.data;
                    this.verifyStatus = 2;
                } else if (rs.code == this.config.statusCode.invalid) {
                    this.verifyStatus = 3;
                } else {
                    this.verifyStatus = 4;
                }
            });
        });
        for (var i = 0; i < this.maxScore; i++) {
            this.range.push(i);
        }
    }

    public mark = (index) => {
        this.marked = this.marked == index ? index - 1 : index;
        this.score = this.marked + 1;
        this.rateChanged.next(this.score);
    }

    public isMarked = (index) => {
        if (!this.forDisplay) {
            if (index <= this.marked) {
                return 'fa-star';
            }
            else {
                return 'fa-star-o';
            }
        }
        else {
            if (this.score >= index + 1) {
                return 'fa-star';
            }
            else if (this.score > index && this.score < index + 1) {
                return 'fa-star-half-o';
            }
            else {
                return 'fa-star-o';
            }
        }
    }


    send() {
        this.httpCall = true;
        this.user = this.storage.get(this.config.token.userKey);
        var visitorReview = this.visitorReviewFrm.value;
        visitorReview.userFacilityId = this.reviewData.visitorData.userFacilityId;
        visitorReview.rating = this.score;
        visitorReview.reviewToken = this.reviewData.visitorData.reviewToken;
        visitorReview.visitorId = this.reviewData.visitorData.visitorId;
        this.userService.addVisitorReview(visitorReview).subscribe((result: any) => {
            this.httpCall = false;
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.verifyStatus = 5;
            } else {
                this.toaster.error(rs.message);
            }
        });
    }


    ngAfterViewInit() {
        this.router.events
            .subscribe((event) => {
                if (event instanceof NavigationStart) {
                    this.loading = true;
                }
                else if (
                    event instanceof NavigationEnd ||
                    event instanceof NavigationCancel
                ) {
                    this.loading = false;
                }
            });
    }
}
