import { Component } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";

import { AppConfig } from './../core/config/app.config';
import { Utills } from './../core/utility/utills';
import { UserService } from './../core/services/user.services';
import { ToastrService } from "ngx-toastr";
import {
    NavigationStart, NavigationCancel, NavigationEnd
} from '@angular/router';

@Component({
    selector: 'app-emailverify',
    preserveWhitespaces: false,
    templateUrl: './view/emailverify.component.html',
    providers: [
        UserService
    ]
})
export class EmailverifyComponent {

    public verifyStatus: number = 0;
    loading: any;
    constructor(
        private user: UserService,
        private toaster: ToastrService,
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private utills: Utills,
        private config: AppConfig
    ) { this.loading = true; }

    public ngOnInit() {
        this.verifyStatus = 1;
        this.activatedRoute.params.subscribe((param: any) => {
            this.user.verifyAccount({ verifyToken: param['id'] }).subscribe((result: any) => {
                var rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.verifyStatus = 2;
                    this.toaster.success("You account has been verified successfully!");
                    this.router.navigate(['']);
                } else if (rs.code == this.config.statusCode.invalid) {
                    this.verifyStatus = 3;
                } else {
                    this.verifyStatus = 4;
                }
            });
        });
    }


    ngAfterViewInit() {
        this.router.events
            .subscribe((event) => {
                if (event instanceof NavigationStart) {
                    this.loading = true;
                }
                else if (
                    event instanceof NavigationEnd ||
                    event instanceof NavigationCancel
                ) {
                    this.loading = false;
                }
            });
    }
}

