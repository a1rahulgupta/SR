import { Component } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

import { AppConfig } from './../core/config/app.config';
import { Utills } from './../core/utility/utills';
import { UserService } from './../core/services/user.services';

import { requiredTrim } from "./../core/validators/validators";
import {
  NavigationStart, NavigationCancel, NavigationEnd
} from '@angular/router';


@Component({
  selector: 'app-forgotpassword',
  preserveWhitespaces: false,
  templateUrl: './view/forgotpassword.component.html',
  providers: [
    UserService
  ]
})
export class ForgotpasswordComponent {

  public verifyStatus: number = 0;
  public fgPwd: FormGroup;
  public httpCall: any = false;
  loading: any;
  constructor(
    private toaster: ToastrService,
    private user: UserService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private utills: Utills,
    private config: AppConfig
  ) {
    this.loading = true;
    this.fgPwd = formBuilder.group({
      email: ['', [requiredTrim, Validators.pattern(this.config.pattern.EMAIL)]]
    });
  }

  save() {
    this.httpCall = true;
    this.user.reqResetPassword(this.fgPwd.value).subscribe((result: any) => {
      this.httpCall = false;
      var rs = result.json();
      if (rs.code == this.config.statusCode.success) {
        this.toaster.info(rs.message);
        this.router.navigate(['']);
      } else {
        this.toaster.info(rs.message);
        this.router.navigate(['']);
      }
    });
  }




  ngAfterViewInit() {
    this.router.events
      .subscribe((event) => {
        if (event instanceof NavigationStart) {
          this.loading = true;
        }
        else if (
          event instanceof NavigationEnd ||
          event instanceof NavigationCancel
        ) {
          this.loading = false;
        }
      });
  }
}




