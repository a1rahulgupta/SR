import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from "@angular/router";
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';

import { AppConfig } from './core/config/app.config';
import { WebStorage } from './core/utility/web.storage';
import { TmpStorage } from './core/utility/temp.storage';
import { Utills } from './core/utility/utills';
import { HttpClient } from './core/utility/http.client';
import { AuthGuard } from "./core/guards/auth.guard";
import { AuthService } from './core/services/auth.service';

import { AppComponent } from './app-components/app.component';
import { AppRoutingModule } from "./app-routing.module";
import { SettingModule } from "./layout/common/setting.module";
import { LoginComponent } from './app-components/login.component';
import { EmailverifyComponent } from './app-components/emailverify.component';
import { ForgotpasswordComponent } from "./app-components/forgotpassword.component";
import { ResetpasswordComponent } from "./app-components/resetpassword.component";
import { PageNotFoundComponent } from "./pagenotfound.component";
import { PatientReviewComponent } from "./app-components/patientReview.component";
import { VisitorReviewComponent } from "./app-components/visitorReview.component";
import { TrackVisitorComponent } from './app-components/trackVisitor.component';
import { SocketIoModule, SocketIoConfig } from 'ngx-socket-io';
import { AgmCoreModule } from '@agm/core';
import { DialogModule, ConfirmDialogModule, ProgressSpinnerModule } from "primeng/primeng";
import { IncidentAcceptVerifyComponent } from './app-components/incidentAccept.component';
import { IncidentRejectVerifyComponent } from './app-components/incidentReject.component';
// import { MatProgressSpinnerModule } from '@angular/material';
// import { SlimScroll } from 'angular-io-slimscroll';
// const config: SocketIoConfig = { url: 'http://localhost:5115', options: { secure:false } };

const config: SocketIoConfig = { url: 'https://www.signin-repute.com', options: {} };

@NgModule({
  declarations: [
    AppComponent,
    PageNotFoundComponent,
    LoginComponent,
    EmailverifyComponent,
    ForgotpasswordComponent,
    ResetpasswordComponent,
    PatientReviewComponent,
    VisitorReviewComponent,
    TrackVisitorComponent,
    IncidentRejectVerifyComponent,
    IncidentAcceptVerifyComponent
    // SlimScroll
  ],
  imports: [
    BrowserModule,
    RouterModule,
    // MatProgressSpinnerModule,
    SettingModule.forChild(),

    BrowserAnimationsModule,
    SocketIoModule.forRoot(config),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyBF34eGmus7PbNf4Ie-bXnedpvYOENwx1w',
      // apiKey: 'AIzaSyALOkOurHJaGcSh2NtqKjVz7T-J4yRv6RU',
      // apiKey: 'AIzaSyAyiniR9Jsh6Cr7QinUcjEui4DTAdv0AjE',
      libraries: ['places']
    }),
    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot({
      preventDuplicates: true,
    }),
    HttpModule,
    AppRoutingModule,
    DialogModule,
    ConfirmDialogModule,
    ProgressSpinnerModule
  ],

  // exports: [
  //   MatProgressSpinnerModule
  // ],


  providers: [
    AppConfig,
    WebStorage,
    TmpStorage,
    Utills,
    HttpClient,
    AuthGuard,
    AuthService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
