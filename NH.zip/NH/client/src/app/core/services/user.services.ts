import {
  Injectable,
  EventEmitter
} from '@angular/core';
import {
  Observable
} from 'rxjs/Observable';
import {
  HttpClient
} from "../utility/http.client";



@Injectable()
export class UserService {
  refreshHeaderData: EventEmitter < any > = new EventEmitter();


  constructor(
    private http: HttpClient
  ) {}

    trackVisitorViewedLink(data: any): Observable < any > {
      return this.http.post('/user/trackVisitorViewedLink', data);
    }

    verifyAccount(data: any): Observable < any > {
      return this.http.post('/user/verifyAccount', data);
    }

    verifyReviewToken(data: any): Observable < any > {
      return this.http.post('/user/verifyReviewToken', data);
    }

    addVisitorReview(data: any): Observable < any > {
      return this.http.post('/user/addVisitorReview', data);
    }

    getEmployeeProfile(data: any): Observable < any > {
      return this.http.get('/user/getEmployeeProfile', data);
    }

    getProfile(data: any): Observable < any > {
      return this.http.get('/user/getprofile', data);
    }

    getCompanyProfileById(data: any): Observable < any > {
      return this.http.get('/user/getCompanyProfileById', data);
    }

    getFacilityProfileById(data: any): Observable < any > {
      return this.http.get('/user/getFacilityProfileById', data);
    }

    sendPatientReview(data: any): Observable < any > {
      return this.http.post('/user/patientReview', data);
    }

    changePassword(data: any): Observable < any > {
      return this.http.post('/user/changePassword', data);
    }

    saveNotification(data: any): Observable < any > {
      return this.http.post('/user/saveNotification', data);
    }

    getNotificationDetails(data: any): Observable < any > {
      return this.http.get('/user/getNotificationDetails', data);
    }

    notificationViewed(data: any): Observable < any > {
      return this.http.post('/user/notificationViewed', data);
    }
    reqResetPassword(data: any): Observable < any > {
      return this.http.post('/user/reqResetPassword', data);
    }
    verifyReSetPwdLink(data: any): Observable < any > {
      return this.http.post('/user/verifyReSetPwdLink', data);
    }
    resetPassword(data: any): Observable < any > {
      return this.http.post('/user/resetPassword', data);
    }
    checkInAllNotiStatusViewed(data: any): Observable < any > {
      return this.http.post('/user/checkInAllNotiStatusViewed', data);
    }
    getSettingsStatus(data: any): Observable < any > {
      return this.http.post('/user/getSettingsStatus', data);
    }
    updateAppSetting(data: any): Observable < any > {
      return this.http.post('/user/updateAppSetting', data);
    }
    updateSMSSetting(data: any): Observable < any > {
      return this.http.post('/user/updateSMSSetting', data);
    }
    updateRatingResponseSetting(data: any): Observable < any > {
      return this.http.post('/user/updateRatingResponseSetting', data);
    }
    updateNotificationSetting(data: any): Observable < any > {
      return this.http.post('/user/updateNotificationSetting', data);
    }
    incidentAcceptVerify(data: any): Observable < any > {
      return this.http.post('/user/incidentAcceptVerify', data);
    }
    incidentRejectVerify(data: any): Observable < any > {
      return this.http.post('/user/incidentRejectVerify', data);
    }
  }
