import { Injectable,EventEmitter, Output } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import { WebStorage } from "../utility/web.storage";
import { AppConfig } from "../config/app.config";
import { HttpClient } from "../utility/http.client";
import { Socket } from 'ngx-socket-io';
import { ReplaySubject } from 'rxjs/Rx';


@Injectable()
export class AuthService {
    refreshAdminProfileData: EventEmitter <any> = new EventEmitter();
    refreshCompanyProfileData: EventEmitter <any> = new EventEmitter();
    refreshFacilityProfileData: EventEmitter <any> = new EventEmitter();
    refreshEmployeeProfileData: EventEmitter <any> = new EventEmitter();
    kioskModeFile: any;
    kioskMode: boolean;
    redirectUrl: string;
    isLoggedIn = false;

    constructor(
        private http: HttpClient,
        private config: AppConfig,
        private storage: WebStorage,
        private socket: Socket,
    ) { }

    checkLogin(): Observable<any> {
        return this.http.get('/user/checklogin', []);
    }

    login(data: any): Observable<any> {
        return this.http.post('/user/login', data).map((res: any) => {
            let body = res.json();
            if (body.code == this.config.statusCode.badRequest || body.code == this.config.statusCode.notFound || body.code == this.config.statusCode.error || body.code == this.config.statusCode.unauthorized) {
                this.isLoggedIn = false;
                 this.kioskMode = false;
                 this.kioskModeFile = false;
                return { auth: false, message: body.message };
            } else {
                console.log("body.data", body);
                this.isLoggedIn = true;
                this.kioskMode = false;
                this.kioskModeFile = false;
                this.storage.localStore(this.config.storage.KIOSK_MODE, this.kioskMode);
                this.storage.localStore(this.config.storage.KIOSK_MODE_FILE, this.kioskModeFile);
                if (data.rememberme) {
                    this.storage.localStore(this.config.token.keyID, body.data.token);
                } else {
                    this.storage.sessionStore(this.config.token.keyID, body.data.token);
                }
                this.storage.localStore(this.config.token.userKey, body.data.user);
                this.storage.localStore(this.config.token.subLoginKey, body.data.sublogin);
                this.socket.emit('adduser', body.data,function(){
                    // alert("here")
                });
                return { auth: true, message: body.message,userData: body.data.user, role: body.data.user.role };
            }
        });
    }

    logout(): Observable<any> {
        this.socket.emit('leaveUser', this.storage.get(this.config.token.subLoginKey) ,function(){
            // alert("here")
        });
        this.storage.clear(this.config.token.keyID);
        this.storage.clear(this.config.token.userKey);
        this.storage.clear(this.config.token.subLoginKey);
        this.storage.clear(this.config.storage.VISITOR_PHONE);
        this.storage.clear(this.config.storage.VISITOR_ID);
        this.storage.clear(this.config.storage.KIOSK_MODE);
        this.storage.clear(this.config.storage.KIOSK_MODE_FILE);
        this.storage.clear(this.config.storage.EMAIL);
        this.storage.clear(this.config.storage.PASSWORD);
        this.storage.clear(this.config.storage.SWITCH);
        this.isLoggedIn = false;
        return Observable.of({ status: true });
    }
}
