import { Injectable } from '@angular/core';
import { WebStorage } from './web.storage';

@Injectable()
export class Utills {
    constructor(
        private storage: WebStorage
    ) { }

    isArray(value:any) {
        return value && typeof value === 'object' && value.constructor === Array;
    }

    isExists(data: any, key: any) {
        if (this.notEmpty(data)) {
            if (this.notEmpty(data[key])) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    notEmpty(data: any) {
        var res = true;
        var dataType = typeof data;
        switch (dataType) {
            case 'object':
                if (data == null || data.length < 1)
                    res = false;
                break;

            case 'undefined':
                res = false;
                break;

            case 'number':
                if (data == "")
                    res = false;
                break;
            case 'string':
                if (data.trim() == "")
                    res = false;
                break;
        }

        return res;
    }

    parseJson(data: any) {
        return JSON.parse(data);
    }

    blockNegative(numberInput: any) {
        if (numberInput >= 48 && numberInput <= 57) {
            return true;
        }
        else {
            return false;
        }
    }


       dataURItoBlob(dataURI) {
        console.log()
          var binary = atob(dataURI.split(',')[1]);
          var array = [];
        for (var i = 0; i < binary.length; i++) {
          array.push(binary.charCodeAt(i));
        }
          return new Blob([new Uint8Array(array)], {
          type: 'image/jpg'
      });
    }
}