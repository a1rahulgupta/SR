import { Injectable, EventEmitter } from '@angular/core';
import { Location } from '@angular/common';
import { CanActivate, CanActivateChild, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

import { AppConfig } from 'app/core/config/app.config';
import { WebStorage } from 'app/core/utility/web.storage';
import { TmpStorage } from 'app/core/utility/temp.storage';
import { HttpClient } from 'app/core/utility/http.client';
import { AuthService } from 'app/core/services/auth.service';
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class AuthGuard implements CanActivate, CanActivateChild {

    constructor(
        private toaster: ToastrService,
        private location: Location,
        private router: Router,
        private auth: AuthService,
        private config: AppConfig,
        private storage: WebStorage,
        private tmpStorage: TmpStorage
    ) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
        let url: string = state.url;
        return this.checkLogin(url, route);
    }
    
    canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
        if (route.children && route.children.length == 0) {
            return this.canActivate(route, state);
        } else {
            return Observable.of(true)
        }
    }

    checkLogin(url: string, route: any): Observable<boolean> {
        console.log("url: string, route: any",url, route)
        let currentUrl = route.url.map(function (u) { return u.path; });
        let currentPath = this.location.path();
        
        return this.auth.checkLogin().map((res) => {
            let body = res.json();
            if (body.code == this.config.statusCode.error || body.code == this.config.statusCode.unauthorized || body.code == this.config.statusCode.serviceUnavailable) {
                this.auth.logout();
                this.toaster.error(body.message);
                if (this.config.withoutLoginUrls.indexOf(currentUrl[0]) < 0) {
                    let splCP = currentPath.substring(1);
                    if (splCP != '') {
                        this.tmpStorage.set('redirectUrl', splCP);
                    }
                    this.router.navigate(['']);
                    return false;
                } else {
                    return true;
                }
            } else {
                console.log("checkLogin")
                this.auth.isLoggedIn = true;
                this.storage.localStore('erSuperAdminUser', body.data.user);
                if (this.config.withoutLoginUrls.indexOf(currentUrl[0]) >= 0) {
                    if(res.role == this.config.role_type.SUPER_ADMIN.name ){
                        this.router.navigate(['admin']);
                    }else if(res.role == this.config.role_type.COMPANY_ADMIN.name){
                        this.router.navigate(['company']);
                    }else if(res.role == this.config.role_type.FACILITY_ADMIN.name){
                        this.router.navigate(['facility']);
                    }else{ // This refer to employee of facility
                        this.router.navigate(['facility']);
                    }
                    return false;
                } else {
                    return true;
                }
            }
        })

    }
}


