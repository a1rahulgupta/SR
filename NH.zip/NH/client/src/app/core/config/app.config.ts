import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';
var baseApiUrl = 'http://localhost:5115';
var apiUrl = 'http://localhost:5115/api/v1';

//Dynamically change BASE and API URL 
if(window.location.origin!=='http://localhost:4200'){
    var baseApiUrl =  window.location.origin // 'http://52.34.207.5:5115'
    var apiUrl     = window.location.origin+"/api/v1"  // 'http://52.34.207.5:5115/api/v3' 
}

@Injectable()
export class AppConfig {
    withoutLoginUrls: any = ['login'];
    baseApiUrl: any = baseApiUrl;
    // apiUrl: any = (['localhost', '127.0.0.1'].indexOf(window.location.hostname)!== -1) ? "http://localhost:5115/api/v1" : "http://52.34.207.5:5115/api/v1";
    apiUrl: any = apiUrl;
    token: any = {
        keyID: 'osSuperAdminUserAuthToken',
        userKey: 'osSuperAdminUser',
        subLoginKey: 'subLoginData'
    };
    assetPath: any = "assets";
    perPageDefault: any = 5;
    perPageArray: any = [
        { val: 5, text: '5/Page' },
        { val: 10, text: '10/Page' },
        { val: 20, text: '20/Page' },
        { val: 30, text: '30/Page' },
        { val: 40, text: '40/Page' },
        { val: 50, text: '50/Page' },
        { val: 100, text: '100/Page' }
    ];
    MOMENT_DATE_TIME_FORMAT: any = 'YYYY-MM-DD HH:mm:ss';
    MaxUploadSixe: any = 5;
    MaxContentSixe: any = 99999;
    alowedFiletypes: any = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'image/gif',
        'image/jpeg',
        'image/png',
        'image/jpg'
    ];
    alowedBannertypes: any = [
        'image/jpeg',
        'image/jpg',
        'image/png'
    ];
    alowedContenttypes: any = [
        'audio/mp3',
        'audio/mpeg'
    ];
    alowedVideotypes: any = [
        'video/mp4'
    ];
    statusCode: any = {
        'error': 409,
        'success': 200,
        'badRequest': 400,
        'unauthorized': 401,
        'notFound': 404,
        'forbidden': 403,
        'invalid': 406,
        'serviceUnavailable': 503,
        'continue':100
    };
    role_type: any = {
        'SUPER_ADMIN': { name: 'super_admin' },
        'COMPANY_ADMIN': { name: 'company_admin' },
        'FACILITY_ADMIN': { name: 'facility_admin' },
        'EMPLOYEE': { name: 'employee' }
    };
      storage: any = {
        'VISITOR_PHONE': '_vis_ph_',
        'VISITOR_ID': '_vis_id_',
        'PATIENT_NAME':'_vis_pn',
        'KIOSK_MODE' : '_vis_km',
        'KIOSK_MODE_FILE': '_vis_kmf',
        'EMAIL': '_vis_email',
        'PASSWORD': '_password_',
        'SWITCH' : '_switch_'
    };
    pattern: any = {
        'NAME': /^[a-zA-Z . \-\']*$/,
        'CMPNAME': /^[a-zA-Z0-9 ]*$/,
        'AMOUNT': /^[0-9]/,
        'userName': /^[a-zA-Z0-9]*$/,
        'ROLENAME': /^[a-zA-Z\_\- ]*$/,
        "CITY": /^[a-zA-Z . \-\']*$/,
        "EMAIL": /^[a-zA-Z0-9]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/,
        "POSTAL_CODE": /(^\d{5}$)|(^\d{5}-\d{4}$)/,
        "PASSWORD": /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{5,15}$/,
        "PHONE": /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/,
        "DESCRIPT": /^[a-zA-Z\.\' ]*$/,
        "PHONE_NO_MASK": [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/],
        "CARD_NO_MASK": [/\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/],
        "CVV_NO_MASK": [/\d/, /\d/, /\d/],
    };
    mob_country_code: any = [
        { key: '+1', text: '+1' },
        { key: '+91', text: '+91' }
    ];
    ckEditorConfig: any = {
        //"uiColor": "#99000",
        "toolbarGroups": [
            { name: 'basicstyles', groups: ['basicstyles', 'cleanup'] },
            { name: 'clipboard', groups: ['clipboard', 'undo'] },
            { name: 'paragraph', groups: ['list', 'indent', 'blocks', 'align'] }, //, 'bidi'
            { name: 'styles' },
            { name: 'colors' },
            { name: 'insert'},
            { name: 'font' },
            { name: 'mode' }, //, 'document', 'doctools'
            
            //{ name: 'editing', groups: ['find', 'selection', 'spellchecker'] },            
            //{ name: 'forms' },
            //{ name: 'tools' },   
            //{ name: 'about' }            
        ],
        "removeButtons": "Image,SpecialChar,Flash,Smiley,Iframe,PageBreak" //Source,Save,Templates,Find,Replace,Scayt,SelectAll
    };
}