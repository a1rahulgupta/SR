import { Routes, RouterModule } from '@angular/router';
import { NgModule } from "@angular/core";


import { VisitorReviewComponent } from "./app-components/visitorReview.component";
import { LoginComponent } from "./app-components/login.component";
import { EmailverifyComponent } from "./app-components/emailverify.component";
import { ForgotpasswordComponent } from "./app-components/forgotpassword.component";
import { ResetpasswordComponent } from "./app-components/resetpassword.component";
import { PatientReviewComponent } from "./app-components/patientReview.component";
import { PageNotFoundComponent } from "./pagenotfound.component";
import { TrackVisitorComponent } from './app-components/trackVisitor.component';
import { IncidentAcceptVerifyComponent } from './app-components/incidentAccept.component';
import { IncidentRejectVerifyComponent } from './app-components/incidentReject.component';

const routes: Routes = [
    {
        path: '',
        component: LoginComponent,
    },
    {
        path: 'verify_account/:id',
        component: EmailverifyComponent
    },
    {
        path: 'forgotpassword',
        component: ForgotpasswordComponent
    },
    {
        path: 'resetpassword/:id',
        component: ResetpasswordComponent
    },
    {
        path: 'visitGoogleRating/:id',
        component: TrackVisitorComponent
    },
    {
        path: 'patient-review',
        component: PatientReviewComponent,

    },
    {
        path: 'visitorReview/:id',
        component: VisitorReviewComponent
    },
    {
        path: 'verify_incident_accept_request/:id',
        component: IncidentAcceptVerifyComponent,

    },
    {
        path: 'verify_incident_reject_request/:id',
        component: IncidentRejectVerifyComponent,

    },
    {
        path: 'admin',
        loadChildren: './layout/admin/admin_layout.module#AdminLayoutModule'
    },
    {
        path: 'company',
        loadChildren: './layout/company/company_layout.module#CompanyLayoutModule'
    },
    {
        path: 'facility',
        loadChildren: './layout/facility/facility_layout.module#FacilityLayoutModule'
    },
    {
        path: '**',
        component: PageNotFoundComponent,
    }
]

@NgModule({
    imports: [RouterModule.forRoot(routes, {
        //enableTracing: true
    })],
    exports: [RouterModule]
})
export class AppRoutingModule {

}