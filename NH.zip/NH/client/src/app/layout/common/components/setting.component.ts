import { Component, AfterViewInit, Input, EventEmitter, OnInit } from "@angular/core";
import { Router, NavigationEnd } from "@angular/router";
import { ConfirmationService } from 'primeng/primeng';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../core/config/app.config";
import { WebStorage } from "../../../core/utility/web.storage";
import { UserService } from "../../../core/services/user.services";
import { AuthService } from "../../../core/services/auth.service";
import { Socket } from 'ngx-socket-io';
import { EmployeeService } from "../../../modules/employee/services/employee.services";

declare var $: any;

@Component({
    selector: 'setting-component',
    templateUrl: './view/setting.html',
    providers: [
        UserService,
        EmployeeService
    ]
})
export class SettingComponent implements AfterViewInit {


    permissionData: any = {
        settings: {
            "status": false,
            "serviceStatus": false,
            "appSettings": false,
            "smsSettings": false,
            "ratingAndResponseSettings": false
        },
    };
    appSettingObj: any = {
        introSms: {
            "status": false,
            "message": ''
        },
        footerMessage: {
            "status": false,
            "message": ''
        },
        welcomeMessage: {
            "status": false,
            "greeting": '',
            "message": ''
        },
        goodbyeMessage: {
            "status": false,
            "greeting": '',
            "message": ''
        },
        checkInSmsInterval: {
            "status": false,
            "minutes": '',
            "period": ''
        },
        checkOutSmsInterval: {
            "status": false,
            "minutes": '',
            "period": ''
        },
        googleRatingSmsInterval: {
            "status": false,
            "minutes": '',
            "period": ''
        },
        smsLimits: {
            "status": false,
            "globalLimit": '',
            "dailyLimit": '',
            "weeklyLimit": '',
            "monthlyLimit": '',
        },
        alerts: {
            "status": false,
            "phoneNumber": '',
            "emailsArray": []
        },
        api: false

    };

    smsSettingObj: any = {
        "disableAutoReply": false,
        saturday: {
            "message": "",
            "status": false
        },
        friday: {
            "message": "",
            "status": false
        },
        thursday: {
            "message": "",
            "status": false
        },
        wednesday: {
            "message": "",
            "status": false
        },
        tuesday: {
            "message": "",
            "status": false
        },
        monday: {
            "message": "",
            "status": false
        },
        sunday: {
            "message": "",
            "status": false
        },
    };
    ratingResponseObj: any = {
        positive: {
            "from": 4,
            "to": 5,
            "autoResponse": '',
            "sendAlerts": true,
            "addReviewLink": true,
        },
        neutral: {
            "from": 3,
            "to": 3,
            "autoResponse": '',
            "sendAlerts": true,
            "addReviewLink": true,
        },
        negative: {
            "from": 1,
            "to": 2,
            "autoResponse": '',
            "sendAlerts": true
        },
    }

    imageEmployeeProfile: string;
    imagePathLogo: string;
    imagePathProfile: string;
    imagePath: string;
    data: any;
    notificationDetails: any = [];
    animateClass: string = '';
    messageCnt: number = 0;
    notificationCount: any;
    notificationlength: boolean;
    notificationData: any;
    body: any;
    kioskMode: any;
    public user: any;
    public notifications: any = [];

    constructor(
        public auth: AuthService,
        private UserService: UserService,
        private employee: EmployeeService,
        private toaster: ToastrService,
        private storage: WebStorage,
        private config: AppConfig,
        private router: Router,
        private socket: Socket,

        private confirmationService: ConfirmationService
    ) {

        this.socket.on('visitorCheckInNotify', (data: any) => {
            if (this.kioskMode == false) {
                this.getNotificationDetails();
            }
        });


        this.UserService.getFacilityProfileById({ data: this.data }).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.imagePathProfile = 'assets/upload/profiles/' + rs.data.image;
                this.imagePathLogo = 'assets/upload/profiles/' + rs.data.facLogo;
            }
        });
        this.auth.refreshFacilityProfileData.subscribe(() => {
            this.UserService.getFacilityProfileById({ data: this.data }).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.imagePathProfile = 'assets/upload/profiles/' + rs.data.image;
                    this.imagePathLogo = 'assets/upload/profiles/' + rs.data.facLogo;
                }
            });
        });
        let user = this.storage.get(this.config.token.userKey);
        this.UserService.getEmployeeProfile({ id: user.uid }).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.imageEmployeeProfile = 'assets/upload/profiles/' + rs.data.image;
            }
        });
        this.auth.refreshEmployeeProfileData.subscribe(() => {
            this.UserService.getEmployeeProfile({ id: user.uid }).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.imageEmployeeProfile = 'assets/upload/profiles/' + rs.data.image;
                }
            });
        });

    }

    focusOutFunctionPositive(to) {
        if (5 >= to && to >= 3) {
            this.ratingResponseObj.neutral.from = to - 1;
        } else {
            this.ratingResponseObj.positive.to = 5;
            this.toaster.error("Invalid Value");
            this.focusOutFunctionPositive(5);
        }
    }
    focusOutFunctionNeutral(to) {
        if (3 >= to && to >= 2) {
            this.ratingResponseObj.negative.from = to - 1;
        } else {
            this.ratingResponseObj.neutral.to = 3;
            this.toaster.error("Invalid Value");
            this.focusOutFunctionNeutral(3);
        }
    }

    public getNotificationDetails() {
        this.UserService.getNotificationDetails({ data: this.body }).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.notificationDetails = rs.data.notificationDetails;
                this.notificationCount = rs.data.notificationCount;
                if (rs.data.notificationDetails.length == 0) {
                    this.notificationlength = false;
                }
            } else {
                this.toaster.error(rs.message);
            }
        });
        this.UserService.refreshHeaderData.subscribe(() => {
            this.UserService.getNotificationDetails({ data: this.body }).subscribe((result) => {
                let rs = result.json();
                console.log("getNotificationDetails", rs.data)
                if (rs.code == this.config.statusCode.success) {
                    this.notificationDetails = rs.data.notificationDetails;
                    this.notificationCount = rs.data.notificationCount;
                    if (rs.data.notificationDetails.length == 0) {
                        this.notificationlength = false;
                    }
                } else {
                    this.toaster.error(rs.message);
                }
            });
            // }
        })
    }

    public getSettingsStatus(selectType) {
        this.UserService.getSettingsStatus({ selectType: selectType }).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                if (rs.data.introSms) {
                    this.appSettingObj = rs.data;
                } else if (rs.data.sunday) {
                    this.smsSettingObj = rs.data;
                } else if (rs.data.positive != null) {
                    this.ratingResponseObj = rs.data;
                }
            } else {
                this.toaster.error(rs.message);
            }
        });
    }

    public updateAppSetting(appSettingObj) {
        appSettingObj._id = this.appSettingObj._id;
        this.UserService.updateAppSetting(appSettingObj).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.toaster.success(rs.message);
            } else {
                this.toaster.error(rs.message);
            }
        });
    }
    public updateSMSSetting(smsSettingObj) {
        smsSettingObj._id = this.smsSettingObj._id;
        this.UserService.updateSMSSetting(smsSettingObj).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.toaster.success(rs.message);
            } else {
                this.toaster.error(rs.message);
            }
        });
    }

    public updateRatingResponseSetting(ratingResponseObj) {
        ratingResponseObj._id = this.ratingResponseObj._id;
        this.UserService.updateRatingResponseSetting(ratingResponseObj).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.toaster.success(rs.message);
            } else {
                this.toaster.error(rs.message);
            }
        });
    }

    public logout() {
        this.confirmationService.confirm({
            message: 'Are you sure that you want to logout?',
            header: 'Confirmation',
            icon: 'fa fa-question-circle',
            accept: () => {
                this.auth.logout().subscribe((res: any) => {
                    this.router.navigate(['']);
                });
            },
            reject: () => {
            }
        });
    }

    onCellClick(visitorId: any, notificationId) {
        this.router.navigate(['/facility/visitors/edit', visitorId]);
        this.UserService.notificationViewed({ notificationId: notificationId }).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.UserService.refreshHeaderData.emit();
            }


        });
    }

    checkInAllNotiStatusViewed(notificationDetails) {
        this.router.navigate(['/facility/visitors/checkInLog']);
        var notifyObj = {
            notificationDetails: notificationDetails
        };
        this.UserService.checkInAllNotiStatusViewed(notifyObj).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.UserService.refreshHeaderData.emit();
            }
        });

    }

    private ngOnInit() {
        this.user = this.storage.get(this.config.token.userKey);
        if (this.user.role == 'employee') {
            var obj = {
                employeeId: this.user.uid,
            }
            this.employee.getEmployeePermissions(obj).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.permissionData = rs.data;
                }
            })

        }
        this.getNotificationDetails();
    }

    ngAfterViewInit() {
        $.getMultiScripts = function (arr, path) {
            var _arr = $.map(arr, function (scr) {
                return $.getScript((path || "") + scr);
            });

            _arr.push($.Deferred(function (deferred) {
                $(deferred.resolve);
            }));

            return $.when.apply($, _arr);
        }

        var script_arr = [
            'materialize.min.js',
            'core/libraries/bootstrap.min.js',
            'plugins/visualization/d3/d3.min.js',
            'plugins/visualization/d3/d3_tooltip.js',
            'plugins/forms/styling/switchery.min.js',
            'plugins/forms/styling/uniform.min.js',
            'plugins/forms/selects/bootstrap_multiselect.js',
            'plugins/ui/moment/moment.min.js',
            'plugins/pickers/daterangepicker.js',
            'core/app.js',
            'plugins/ui/ripple.min.js',
            'custom.js'
        ];

        $.getMultiScripts(script_arr, 'assets/js/').done(function () {
            // all scripts loaded
        });
    }
}