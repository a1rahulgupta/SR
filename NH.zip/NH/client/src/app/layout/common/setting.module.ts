import { NgModule, ModuleWithProviders } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import {
    BsDropdownModule,
} from 'ngx-bootstrap';

import {
    ConfirmDialogModule,
    DialogModule,
    ConfirmationService,
    ChipsModule
} from 'primeng/primeng';

import { SettingComponent } from "./components/setting.component";
import { TagsInputModule } from 'ngx-tags-input/dist';


@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        BsDropdownModule.forRoot(),
        CommonModule,
        RouterModule,
        ConfirmDialogModule,

        DialogModule,
        ChipsModule,
        TagsInputModule.forRoot()
    ],
    declarations: [
        SettingComponent
    ],
    providers: [
        ConfirmationService
    ],
    exports: [
        SettingComponent
    ]
})
export class SettingModule {
    static forChild(): ModuleWithProviders {
        return <ModuleWithProviders>{
            ngModule: SettingModule,
            providers: [
                ConfirmationService
            ],
        };
    }
}
























