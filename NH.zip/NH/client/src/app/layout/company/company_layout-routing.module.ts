import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AuthGuard } from "../../core/guards/auth.guard";
import { CompanyLayoutComponent } from "./company_layout.component";

// import { AuthGuard } from "../core/guards/auth.guard";
// import { LayoutComponent } from "../layout/layout.component";

const routes: Routes = [
    {
        path: '',
        component: CompanyLayoutComponent,
        canActivateChild: [AuthGuard],
        children: [
            {
                path: 'facility',
                loadChildren: 'app/modules/facility/facility.module#FacilityModule'
            },
            {
                path: 'companyuser',
                loadChildren: 'app/modules/companyuser/companyuser.module#CompanyUserModule'
            },
            {
                path: '',
                loadChildren: 'app/modules/cmp_dashboard/cmp.module#CmpDashboardModule'
            },
            {
                path: 'profile',
                loadChildren: 'app/modules/cmp_dashboard/cmp.module#CmpDashboardModule'
            },
            {
                path: 'changePassword',
                loadChildren: 'app/modules/cmp_dashboard/cmp.module#CmpDashboardModule'
            }
        ]
    }
]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class CompanyLayoutRoutingModule {

}