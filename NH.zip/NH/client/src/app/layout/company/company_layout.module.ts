import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
  BsDropdownModule,
} from 'ngx-bootstrap';

import {
  ConfirmDialogModule,
  ConfirmationService
} from 'primeng/primeng';
import { FooterComponent } from "./components/footer/footer.component";
import { SidebarComponent } from "./components/sidebar/sidebar.component";
import { HeaderComponent } from "./components/header/header.component";
import { CompanyLayoutComponent } from "./company_layout.component";
import { CompanyLayoutRoutingModule } from "./company_layout-routing.module";


@NgModule({
    imports: [
        FormsModule, 
        ReactiveFormsModule,
        BsDropdownModule.forRoot(),
        CommonModule,
        RouterModule,
        ConfirmDialogModule,
        CompanyLayoutRoutingModule        
    ],
    declarations: [
        CompanyLayoutComponent, 
        HeaderComponent, 
        SidebarComponent, 
        FooterComponent
    ],
    providers: [
        ConfirmationService
    ]
})
export class CompanyLayoutModule {

}