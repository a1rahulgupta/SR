import { Component } from "@angular/core";

@Component({
    templateUrl: './company_layout.component.html',
    styles: []
})
export class CompanyLayoutComponent {

}