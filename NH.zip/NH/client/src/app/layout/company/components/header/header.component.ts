import { Component, AfterViewInit,EventEmitter, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { ConfirmationService } from 'primeng/primeng';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../../core/config/app.config";
import { WebStorage } from "../../../../core/utility/web.storage";
import { UserService } from "../../../../core/services/user.services";
import { AuthService } from "../../../../core/services/auth.service";
declare var $: any;

@Component({
    selector: 'header-component',
    templateUrl: './view/header.component.html',
    providers: [
        UserService
    ]
})
export class HeaderComponent implements AfterViewInit {
    imagePathLogo: string;
    imagePathProfile: string;
    imagePath: string;
    data: any;

    public user: any;
    public notifications: any = [];

    constructor(
        public auth: AuthService,
        private storage: WebStorage,
        private config: AppConfig,
        private UserService : UserService,
        private router: Router,
        private confirmationService: ConfirmationService
    ) { 

        this.UserService.getCompanyProfileById({ data: this.data }).subscribe((result: any) => {
        var rs = result.json();
        if (rs.code == this.config.statusCode.success) {
                this.imagePathProfile = 'assets/upload/profiles/'+ rs.data.image;
                this.imagePathLogo = 'assets/upload/profiles/'+ rs.data.cmpLogo;
            } 
        });
        this.auth.refreshCompanyProfileData.subscribe(() => {
            this.UserService.getCompanyProfileById({ data: this.data }).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.imagePathProfile = 'assets/upload/profiles/'+ rs.data.image;
                    this.imagePathLogo = 'assets/upload/profiles/'+ rs.data.cmpLogo;
                }
            });
        });
    }

    public logout() {
        this.confirmationService.confirm({
            message: 'Are you sure that you want to logout?',
            header: 'Confirmation',
            icon: 'fa fa-question-circle',
            accept: () => {
                this.auth.logout().subscribe((res: any) => {
                    this.router.navigate(['']);
                });
            },
            reject: () => {
            }
        });
    }

    private ngOnInit() {
        this.user = this.storage.get(this.config.token.userKey);
    }
    
    ngAfterViewInit() {
        $.getMultiScripts = function(arr, path) {
            var _arr = $.map(arr, function(scr) {
                return $.getScript( (path||"") + scr );
            });

            _arr.push($.Deferred(function( deferred ){
                $( deferred.resolve );
            }));

            return $.when.apply($, _arr);
        }

        var script_arr = [
            'materialize.min.js', 
            'core/libraries/bootstrap.min.js',
            'plugins/visualization/d3/d3.min.js',
            'plugins/visualization/d3/d3_tooltip.js',
            'plugins/forms/styling/switchery.min.js',
            'plugins/forms/styling/uniform.min.js',
            'plugins/forms/selects/bootstrap_multiselect.js',
            'plugins/ui/moment/moment.min.js',
            'plugins/pickers/daterangepicker.js',
            'core/app.js',
            'plugins/ui/ripple.min.js',
            'custom.js'
        ];

        $.getMultiScripts(script_arr, 'assets/js/').done(function() {
            // all scripts loaded
        });
    }
}