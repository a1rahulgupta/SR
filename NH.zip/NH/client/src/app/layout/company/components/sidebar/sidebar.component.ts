import { Component, EventEmitter } from "@angular/core";
import { AppConfig } from "../../../../core/config/app.config";
import { WebStorage } from "../../../../core/utility/web.storage";
import { UserService } from "../../../../core/services/user.services";
import { AuthService } from "../../../../core/services/auth.service";

@Component({
    selector: 'sidebar-component',
    preserveWhitespaces: false,
    templateUrl: './view/sidebar.component.html',
    styleUrls: ['./css/sidebar.css'],
    providers: [
        UserService
    ]
})
export class SidebarComponent {
    userName: string;
    imagePath: string;
    data: any;

    public user: any;

    constructor(
        private storage: WebStorage,
        public auth: AuthService,
        private UserService: UserService,
        private config: AppConfig
    ) {

        this.UserService.getCompanyProfileById({ data: this.data }).subscribe((result: any) => {
            var rs = result.json();
            console.log("rsssssss", rs)
            if (rs.code == this.config.statusCode.success) {
                this.imagePath = 'assets/upload/profiles/' + rs.data.cmpLogo;
                this.userName = rs.data.cmpName;
            }
        });
        this.auth.refreshCompanyProfileData.subscribe(() => {
            this.UserService.getCompanyProfileById({ data: this.data }).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.imagePath = 'assets/upload/profiles/' + rs.data.cmpLogo;
                    this.userName = rs.data.cmpName;
                }
            });
        });
    }

    ngOnInit() {
        this.user = this.storage.get(this.config.token.userKey);
    }
}