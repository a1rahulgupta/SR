import { Component } from "@angular/core";

@Component({
    selector: 'footer-component',
    preserveWhitespaces: false,
    templateUrl: './view/footer.component.html'
})
export class FooterComponent {

}