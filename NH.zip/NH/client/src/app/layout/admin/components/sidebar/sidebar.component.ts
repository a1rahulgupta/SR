import { Component } from "@angular/core";
import { WebStorage } from "../../../../core/utility/web.storage";
import { AppConfig } from "../../../../core/config/app.config";
import { UserService } from "../../../../core/services/user.services";
import { AuthService } from "../../../../core/services/auth.service";


@Component({
    selector: 'sidebar-component',
    preserveWhitespaces: false,
    templateUrl: './view/sidebar.component.html',
    styleUrls: ['./css/sidebar.css'],
    providers: [
        UserService
    ]
})
export class SidebarComponent {
    userName: any;
    toaster: any;
    imagePath: string;
    body: any;

    public user: any;

    constructor(
        public auth: AuthService,
        private storage: WebStorage,
        private UserService: UserService,
        private config: AppConfig
    ) { }

    ngOnInit() {
        this.user = this.storage.get(this.config.token.userKey);
        this.auth.refreshAdminProfileData.subscribe(() => {
            this.UserService.getProfile({ id: this.user.uid }).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.imagePath = 'assets/upload/profiles/' + rs.data.image;
                    this.userName = rs.data.userName;
                } else {
                    this.toaster.error(rs.message);
                }
            });
            // }
        })
        this.getProfile();
    }
    public getProfile() {
        this.UserService.getProfile({ id: this.user.uid }).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.imagePath = 'assets/upload/profiles/' + rs.data.image;
                this.userName = rs.data.userName;
            } else {
                this.toaster.error(rs.message);
            }
        });
    }
}