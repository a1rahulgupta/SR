import { Component, AfterViewInit, EventEmitter, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { ConfirmationService } from 'primeng/primeng';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../../core/config/app.config";
import { WebStorage } from "../../../../core/utility/web.storage";
import { UserService } from "../../../../core/services/user.services";
import { AuthService } from "../../../../core/services/auth.service";
declare var $: any;

@Component({
    selector: 'header-component',
    templateUrl: './view/header.component.html',
    providers: [
        UserService
    ]
})
export class HeaderComponent implements OnInit, AfterViewInit {
    imagePath: string;
    body: any;

    public user: any;
    public notifications: any = [];

    constructor(
        public auth: AuthService,
        private storage: WebStorage,
        private config: AppConfig,
        private router: Router,
        private UserService: UserService,
        private confirmationService: ConfirmationService
    ) {
    }

    public logout() {
        this.confirmationService.confirm({
            message: 'Are you sure that you want to logout?',
            header: 'Confirmation',
            icon: 'fa fa-question-circle',
            accept: () => {
                this.auth.logout().subscribe((res: any) => {
                    this.router.navigate(['']);
                });
            },
            reject: () => {
            }
        });
    }

    public ngOnInit() {
        this.auth.refreshAdminProfileData.subscribe(() => {
            this.UserService.getProfile({ id: this.user.uid }).subscribe((result) => {
                let rs = result.json();
                console.log("refreshAdminProfileData-----------", rs);
                if (rs.code == this.config.statusCode.success) {
                    this.imagePath = 'assets/upload/profiles/' + rs.data.image;
                }
            });
        })
        this.user = this.storage.get(this.config.token.userKey);
        this.getProfile();

    }



    public getProfile() {
        this.UserService.getProfile({ id: this.user.uid }).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.imagePath = 'assets/upload/profiles/' + rs.data.image;
            }
        });
    }

    ngAfterViewInit() {
        $.getMultiScripts = function (arr, path) {
            var _arr = $.map(arr, function (scr) {
                return $.getScript((path || "") + scr);
            });

            _arr.push($.Deferred(function (deferred) {
                $(deferred.resolve);
            }));

            return $.when.apply($, _arr);
        }

        var script_arr = [
            'materialize.min.js',
            'core/libraries/bootstrap.min.js',
            'plugins/visualization/d3/d3.min.js',
            'plugins/visualization/d3/d3_tooltip.js',
            'plugins/forms/styling/switchery.min.js',
            'plugins/forms/styling/uniform.min.js',
            'plugins/forms/selects/bootstrap_multiselect.js',
            'plugins/ui/moment/moment.min.js',
            'plugins/pickers/daterangepicker.js',
            'core/app.js',
            'plugins/ui/ripple.min.js',
            'custom.js'
        ];

        if (this.storage.get(this.config.storage.KIOSK_MODE_FILE) == false) {
            $.getMultiScripts(script_arr, 'assets/js/').done(function () {
                // all scripts loaded
            });
        }
    }
}