import { Component } from "@angular/core";

@Component({
    templateUrl: './admin_layout.component.html',
    styles: []
})
export class AdminLayoutComponent {
    
}

