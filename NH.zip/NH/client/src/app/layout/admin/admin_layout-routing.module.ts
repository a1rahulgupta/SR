import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AuthGuard } from "../../core/guards/auth.guard";
import { AdminLayoutComponent } from "./admin_layout.component";

const routes: Routes = [
    {
        path: '',
        component: AdminLayoutComponent,
        canActivateChild: [AuthGuard],
        children: [
            
            {
                path: 'company',
                loadChildren: 'app/modules/company/company.module#CompanyModule'
            },
            {
                path: 'facility',
                loadChildren: 'app/modules/facility/facility.module#FacilityModule'
            },
            {
                path: '',
                loadChildren: 'app/modules/adm_dashboard/adm.module#AdmDashboardModule'
            },
            {
                path: 'profile',
                loadChildren: 'app/modules/adm_dashboard/adm.module#AdmDashboardModule'
            },
            {
                path: 'changePassword',
                loadChildren: 'app/modules/adm_dashboard/adm.module#AdmDashboardModule'
            },
            {
                path: 'setting',
                loadChildren: 'app/modules/setting/setting.module#SettingModule'
            },
            {
                path: 'survey',
                loadChildren: 'app/modules/survey/survey.module#SurveyModule'
            },
        ]
    }
]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AdminLayoutRoutingModule {

}