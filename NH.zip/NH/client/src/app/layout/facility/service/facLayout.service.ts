import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from "../../../core/utility/http.client";


@Injectable()
export class FacLayoutService {
  constructor(
    private http: HttpClient
  ) { }

  getPopupMessages(data): Observable<any> {
    return this.http.post('/feedback/getPopupMessages', data);
  }
  sendMessageOnChatPopup(data): Observable<any> {
    return this.http.post('/feedback/sendMessageOnChatPopup', data);
  }
  viewMessageOnChatPopup(data): Observable<any> {
    return this.http.post('/feedback/viewMessageOnChatPopup', data);
  }
}
