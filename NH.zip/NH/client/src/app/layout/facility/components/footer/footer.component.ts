import { Component } from "@angular/core";

@Component({
    selector: 'footer-component',
    templateUrl: './view/footer.component.html'
})
export class FooterComponent {

}