import { Component, AfterViewInit, Input, EventEmitter, OnInit } from "@angular/core";
import { Router, NavigationEnd } from "@angular/router";
import { ConfirmationService } from 'primeng/primeng';
import { ToastrService } from 'ngx-toastr';
import { AppConfig } from "../../../../core/config/app.config";
import { WebStorage } from "../../../../core/utility/web.storage";
import { UserService } from "../../../../core/services/user.services";
import { AuthService } from "../../../../core/services/auth.service";
import { Socket } from 'ngx-socket-io';
import { EmployeeService } from "../../../../modules/employee/services/employee.services";
import swal from 'sweetalert2'

declare var $: any;

@Component({
    selector: 'header-component',
    templateUrl: './view/header.component.html',
    providers: [
        UserService,
        EmployeeService
    ]
})
export class HeaderComponent implements AfterViewInit {
    linkSmsInterval: string[];
    checkOutSmsInterval: string[];


    permissionData: any = {
        settings: {
            "status": false,
            "serviceStatus": false,
            "appSettings": false,
            "smsSettings": false,
            "ratingAndResponseSettings": false
        },
    };
    appSettingObj: any = {
        checkInSms: {
            "status": false,
            "visitorName": false,
            "message": ''
        },
        checkInMessageReceivedReplySms: {
            "status": false,
            "visitorName": false,
            "message": ''
        },
        checkOutSms: {
            "status": false,
            "visitorName": false,
            "message": ''
        },
        footerMessage: {
            "status": false,
            "message": ''
        },
        welcomeMessage: {
            "status": false,
            "greeting": '',
            "message": ''
        },
        goodbyeMessage: {
            "status": false,
            "greeting": '',
            "message": ''
        },
        checkInSmsInterval: {
            "status": false,
            "minutes": '',
            "period": ''
        },
        checkOutSmsInterval: {
            "status": false,
            "time": '',
            "period": ''
        },
        googleRatingSmsInterval: {
            "status": false,
            "minutes": '',
            "period": ''
        },
        smsLimits: {
            "status": false,
            "globalLimit": '',
            "dailyLimit": '',
            "weeklyLimit": '',
            "monthlyLimit": '',
        },
        expressResident: false

    };
    notificationSettingObj: any = {
        openIncident: {
            "status": false,
            "period": '',
            "phoneNumber": '',
            "emailsArray": []
        },
        updateResolvedIncident: {
            "status": false,
            "phoneNumber": '',
            "emailsArray": []
        },
        negative_rating_notification: {
            "status": false,
            "phoneNumber": '',
            "emailsArray": []
        },
        checkInNotification: {
            "status": false,
            "phoneNumber": '',
            "emailsArray": []
        }

    };

    smsSettingObj: any = {
        "disableAutoReply": false,
        saturday: {
            "message": "",
            "status": false
        },
        friday: {
            "message": "",
            "status": false
        },
        thursday: {
            "message": "",
            "status": false
        },
        wednesday: {
            "message": "",
            "status": false
        },
        tuesday: {
            "message": "",
            "status": false
        },
        monday: {
            "message": "",
            "status": false
        },
        sunday: {
            "message": "",
            "status": false
        },
    };
    ratingResponseObj: any = {
        positive: {
            "from": 4,
            "to": 5,
            "autoResponse": '',
            "sendAlerts": true,
            "addReviewLink": true,
            "googleLink": ''
        },
        negative: {
            "from": 1,
            "to": 3,
            "autoResponse": '',
            "sendAlerts": true
        },
        negativeRatingFollowUpSms: {
            "status": false,
            "visitorName": false,
            "message": ''
        },
    }

    imageEmployeeProfile: string;
    imagePathLogo: string;
    imagePathProfile: string;
    imagePath: string;
    data: any;
    notificationDetails: any = [];
    animateClass: string = '';
    messageCnt: number = 0;
    notificationCount: any;
    notificationlength: boolean;
    notificationData: any;
    body: any;
    kioskMode: any;
    public user: any;
    public notifications: any = [];

    constructor(
        public auth: AuthService,
        private UserService: UserService,
        private employee: EmployeeService,
        private toaster: ToastrService,
        private storage: WebStorage,
        private config: AppConfig,
        private router: Router,
        private socket: Socket,

        private confirmationService: ConfirmationService
    ) {

        this.socket.on('visitorCheckInNotify', (data: any) => {
            if (this.kioskMode == false) {
                this.getNotificationDetails();
            }
        });


        this.UserService.getFacilityProfileById({ data: this.data }).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.imagePathProfile = 'assets/upload/profiles/' + rs.data.image;
                this.imagePathLogo = 'assets/upload/profiles/' + rs.data.facLogo;
            }
        });
        this.auth.refreshFacilityProfileData.subscribe(() => {
            this.UserService.getFacilityProfileById({ data: this.data }).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.imagePathProfile = 'assets/upload/profiles/' + rs.data.image;
                    this.imagePathLogo = 'assets/upload/profiles/' + rs.data.facLogo;
                }
            });
        });
        let user = this.storage.get(this.config.token.userKey);
        this.UserService.getEmployeeProfile({ id: user.uid }).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.imageEmployeeProfile = 'assets/upload/profiles/' + rs.data.userData.image;
            }
        });
        this.auth.refreshEmployeeProfileData.subscribe(() => {
            this.UserService.getEmployeeProfile({ id: user.uid }).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.imageEmployeeProfile = 'assets/upload/profiles/' + rs.data.userData.image;
                }
            });
        });

    }

    focusOutFunctionPositive(to) {
        if (to <= this.ratingResponseObj.positive.from) {
            this.ratingResponseObj.negative.from = to - 1;
        } else {
            this.ratingResponseObj.positive.to = this.ratingResponseObj.positive.from;
            this.toaster.error("Invalid Value");
            this.focusOutFunctionPositive(this.ratingResponseObj.positive.from);
        }
    }

    public getCheckOutInterval(period) {
        if (period == 'minutes') {
            this.checkOutSmsInterval = [
                '1', '5', '10', '15', '20', '25', '30', '45', '60'
            ]
        } else if (period == 'hours') {
            this.checkOutSmsInterval = [
                '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'
            ]
        } else {
            this.checkOutSmsInterval = [];
        }
    }

    public getLinkSmsInterval(period) {
        if (period == 'minutes') {
            this.linkSmsInterval = [
                '1', '5', '10', '15', '20', '25', '30', '45', '60'
            ]
        } else if (period == 'hours') {
            this.linkSmsInterval = [
                '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'
            ]
        } else if (period == 'days') {
            this.linkSmsInterval = [
                '1', '2', '3', '4', '5', '6'
            ];
        } else if (period == 'weeks') {
            this.linkSmsInterval = [
                '1', '2', '3', '4'
            ];
        } else {
            this.linkSmsInterval = [];
        }
    }

    public getNotificationDetails() {
        this.UserService.getNotificationDetails({ data: this.body }).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.notificationDetails = rs.data.notificationDetails;
                this.notificationCount = rs.data.notificationCount;
                if (rs.data.notificationDetails.length == 0) {
                    this.notificationlength = false;
                }
            } else {
                this.toaster.error(rs.message);
            }
        });
        this.UserService.refreshHeaderData.subscribe(() => {
            this.UserService.getNotificationDetails({ data: this.body }).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.notificationDetails = rs.data.notificationDetails;
                    this.notificationCount = rs.data.notificationCount;
                    if (rs.data.notificationDetails.length == 0) {
                        this.notificationlength = false;
                    }
                } else {
                    this.toaster.error(rs.message);
                }
            });
            // }
        })
    }

    public getSettingsStatus(selectType) {
        this.UserService.getSettingsStatus({ selectType: selectType }).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                if (rs.data.checkInSms) {
                    this.getCheckOutInterval(rs.data.checkOutSmsInterval.period);
                    this.getLinkSmsInterval(rs.data.googleRatingSmsInterval.period);
                    this.appSettingObj = rs.data;
                } else if (rs.data.sunday) {
                    this.smsSettingObj = rs.data;
                } else if (rs.data.positive != null) {
                    this.ratingResponseObj = rs.data;
                } else if (rs.data.openIncident != null) {
                    this.notificationSettingObj = rs.data;
                }
            } else {
                this.toaster.error(rs.message);
            }
        });
    }

    public updateAppSetting(appSettingObj) {
        appSettingObj._id = this.appSettingObj._id;
        this.UserService.updateAppSetting(appSettingObj).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.toaster.success(rs.message);
            } else {
                this.toaster.error(rs.message);
            }
        });
    }
    public updateSMSSetting(smsSettingObj) {
        smsSettingObj._id = this.smsSettingObj._id;
        this.UserService.updateSMSSetting(smsSettingObj).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.toaster.success(rs.message);
            } else {
                this.toaster.error(rs.message);
            }
        });
    }

    public updateRatingResponseSetting(ratingResponseObj) {
        ratingResponseObj._id = this.ratingResponseObj._id;
        this.UserService.updateRatingResponseSetting(ratingResponseObj).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.toaster.success(rs.message);
            } else {
                this.toaster.error(rs.message);
            }
        });
    }
    
    public updateNotificationSetting(notificationSettingObj) {
        notificationSettingObj._id = this.notificationSettingObj._id;
        this.UserService.updateNotificationSetting(notificationSettingObj).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.toaster.success(rs.message);
            } else {
                this.toaster.error(rs.message);
            }
        });
    }

    public logout() {
        this.confirmationService.confirm({
            message: 'Are you sure that you want to logout?',
            header: 'Confirmation',
            icon: 'fa fa-question-circle',
            accept: () => {
                this.auth.logout().subscribe((res: any) => {
                    this.router.navigate(['']);
                });
            },
            reject: () => {
            }
        });
    }

    onCellClick(visitorId: any, notificationId) {
        this.router.navigate(['/facility/visitors/edit', visitorId]);
        this.UserService.notificationViewed({ notificationId: notificationId }).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.UserService.refreshHeaderData.emit();
            }


        });
    }

    checkInAllNotiStatusViewed(notificationDetails) {
        this.router.navigate(['/facility/visitors/checkInLog']);
        var notifyObj = {
            notificationDetails: notificationDetails
        };
        this.UserService.checkInAllNotiStatusViewed(notifyObj).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.UserService.refreshHeaderData.emit();
            }
        });

    }

    //Function is used for sweet-aleart of all the field
    myFunction(x) {

        switch (x) {
            case 'checkInSms':
                swal({
                    title: 'Check-In SMS',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">The Check-In SMS feature sends an instant message upon check-in to any visitor (and returning visitor). When you add and apply text to this field, when a visitor first visits your facility they will be greeted via SMS with the message you provide. This message does not impact the outgoing SMS which is sent when the visitor is checked out, this feature is more of a supplement to enhance a visitor experience by engaging with them the moment they check into the facility. Leaving this box blank will disable this feature.</div>',
                    imageUrl: 'assets/images/checkin.png',
                    imageWidth: 270,
                    width: 450,
                    imageHeight: 200,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false,
                    timer: 100000
                })
                break;
            case 'checkInMessageReceivedReplySms':
                swal({
                    title: 'Message Received',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">The Message Received feature sends an instant message upon recived message by visitor just after checking in to any visitor (and returning visitor). When you add and apply text to this field, when a visitor first replies back on checking in message to your facility they will be received SMS with the message you provide. This feature is more of a supplement to enhance a visitor experience by engaging with them the moment they check into the facility. Leaving this box blank will disable this feature.</div>',
                    imageUrl: 'assets/images/messagerecived.png',
                    imageWidth: 270,
                    width: 450,
                    imageHeight: 190,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false,
                    timer: 100000

                })
                break;
            case 'checkOutSms':
                swal({
                    title: 'Check-Out SMS',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">The Check-Out SMS feature sends an instant message upon check-out to any visitor (and returning visitor). When you add and apply text to this field, when a visitor checked out from your facility they will be received SMS with the message you provide. This message does not impact the outgoing SMS which is sent when the visitor is checking in, this feature is more of a supplement to enhance a visitor experience by engaging with them the moment they check out the facility. Leaving this box blank will disable this feature.</div>',
                    imageUrl: 'assets/images/checkout.png',
                    imageWidth: 270,
                    width: 450,
                    imageHeight: 190,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false,
                    timer: 100000
                })
                break;
            case 'negativeRatingFollowUpSms':
                swal({
                    title: 'Follow Up Negative Rating ',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">The Follow Up Negative Rating feature sends an instant message upon received follow up negative response from any visitor. When you add and apply text to this field, when a visitor submit their negative feedback to your facility they will be received SMS with the message you provide. This feature is more of a supplement to enhance the service of facility. Leaving this box blank will disable this feature.</div>',
                    imageUrl: 'assets/images/followup.png',
                    imageWidth: 270,
                    width: 450,
                    imageHeight: 200,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false,
                    timer: 100000
                })
                break;
            case 'welcomeMessage':
                swal({
                    title: 'App Welcome Message',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">The App welcome message will display upon a check-in of a guest, both new and returning. When you add a header and body messages, the message will display as soon as the checking-in is complete. Leaving this box blank will disable this feature.</div>',
                    imageUrl: 'assets/images/welcome.png',
                    imageWidth: 270,
                    width: 450,
                    imageHeight: 200,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false,
                    timer: 100000
                })
                break;
            case 'goodbyeMessage':
                swal({
                    title: 'App Goodbye Message',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">The App Goodbye message will display upon a check-out of a guest, both new and returning. When you add a header and body messages, the message will display as soon as the check-out is complete. Leaving this box blank will disable this feature.</div>',
                    imageUrl: 'assets/images/goodbye.png',
                    imageWidth: 270,
                    width: 450,
                    imageHeight: 200,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false,
                    timer: 100000
                })
                break;
            case 'footerMessage':
                swal({
                    title: 'App Footer',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">The App Footer message displays a global message on your iPad app right below the enter and exit buttons. You can customize this message to display any message or announcement you did like your guests to see right before checking in. Leaving this box blank will disable this feature.</div>',
                    imageUrl: 'assets/images/footer.png',
                    imageWidth: 270,
                    width: 450,
                    imageHeight: 200,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false,
                    timer: 100000
                })
                break;
            case 'checkInSmsInterval':
                swal({
                    title: 'Check-In Sms Interval',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">The Check-in SMS Interval tells the platform after how long to wait before an Check-in SMS is sent to a visitor. You can define a specific unit of time, for example 5 Minutes; which would tell the application that if a visitor has checking in, wait 5 Minutes after the check-in time to send the SMS. This feature allows you to configure if you prefer to have the SMS sent right away, or even at a much later time.</div>',
                    imageUrl: 'assets/images/checkinsms.png',
                    imageWidth: 270,
                    width: 450,
                    imageHeight: 180,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false,
                    timer: 100000
                })
                break;
            case 'checkOutSmsInterval':
                swal({
                    title: 'Check-Out Sms Interval',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">The Check-out SMS Interval tells the platform after how long to wait before an Check-out SMS is sent to a visitor. You can define a specific unit of time, for example 5 Minutes; which would tell the application that if a visitor has checked out, wait 5 Minutes after the check-out time to send the SMS. This feature allows you to configure if you prefer to have the SMS sent right away, or even at a much later time.</div>',
                    imageUrl: 'assets/images/checkoutsms.png',
                    imageWidth: 270,
                    width: 450,
                    imageHeight: 200,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false,
                    timer: 100000
                })
                break;
            case 'googleRatingSmsInterval':
                swal({
                    title: 'Link SMS Interval',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">The Link SMS Interval tells the platform after how long to wait before an follow up positive rating SMS is sent to a visitor. You can define a specific unit of time, for example 5 Minutes; which would tell the application that if a visitor has given positive rating, wait 5 Minutes after received positive rating time to send the SMS. This feature allows you to configure if you prefer to have the SMS sent right away, or even at a much later time.</div>',
                    imageUrl: 'assets/images/linksms.png',
                    imageWidth: 270,
                    width: 450,
                    imageHeight: 220,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false,
                    timer: 100000
                })
                break;
            case 'smsLimits':
                swal({
                    title: 'SMS Limits',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">Setting SMS limits gives you control over the SMS delivery frequency over-time. For example, a global limit of 25 means a visitor is only going to get 25 SMS messages. You can also specify out of the global amount, how often should the messages be sent and within what time period. If your global limit is 25, and your Weekly is set to 1; your visitors will get 1 message per week until the cap of 25 is reached.</div>',
                    imageUrl: 'assets/images/smslimit.png',
                    imageWidth: 270,
                    width: 500,
                    imageHeight: 280,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false,
                    timer: 100000
                })
                break;
            case 'days':
                swal({
                    title: 'Customized SMS Messages',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">Customizing your SMS messages can help you personalize and improve your engagement rating. Each day, a message sent to your visitors contains our stock pre-defined SMS requesting feedback; you can update the SMS messages by day to include custom text to personalize the outgoing SMS but keep in mind it is important and a must to mention the 1 to 5(5 being the best) rating. The platform is programmed to recognized an initial rating response of a number between 1 and 5 to record proper ratings and identify visitors. When you change these messages, you must include the 1 to 5 scale rating otherwise the message will not record ratings properly.</div>',
                    imageUrl: 'assets/images/smssetting.png',
                    imageWidth: 270,
                    width: 450,
                    imageHeight: 200,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false,
                    timer: 100000
                })
                break;
            case 'openIncident':
                swal({
                    title: 'Open Incident',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">Alerts are a great way to get notified when a there is a open incident even after the specific time. Currently, there are two ways to get alerted for open incident/complaint, you can enter e-mails (enter after enter email) in the e-mail field and an e-mail will trigger to all the addresses. You can also specify one phone number in the phone number field, when an alert is triggered an SMS will be sent automatically to this number and confirm via text that their is open incident/complaints remaining. The alerts fire in real-time, providing you the ability to quickly get notified of the event.</div>',
                    imageUrl: 'assets/images/openincident.png',
                    imageWidth: 270,
                    width: 400,
                    imageHeight: 300,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false,
                    timer: 100000
                })
                break;
            case 'updateResolvedIncident':
                swal({
                    title: 'Update/Resolved Incident',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">Alerts are a great way to get notified when a there is any update to the incident. Currently, there are two ways to get alerted for update/resolved incident/complaint, you can enter e-mails (enter after enter email) in the e-mail field and an e-mail will trigger to all the addresses. You can also specify one phone number in the phone number field, when an alert is triggered an SMS will be sent automatically to this number and confirm via text that their is open incident/complaints remaining. The alerts fire in real-time, providing you the ability to quickly get notified of the event.</div>',
                    imageUrl: 'assets/images/updateincident.png',
                    imageWidth: 270,
                    width: 450,
                    imageHeight: 310,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false,
                    timer: 100000
                })
                break;
            case 'negative_rating_notification':
                swal({
                    title: 'Negative Rating Notification',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">Alerts are a great way to get notified when a there is a low rating received by any visitor. Currently, there are two ways to get alerted for low rating, you can enter e-mails (enter after enter email) in the e-mail field and an e-mail will trigger to all the addresses. You can also specify one phone number in the phone number field, when an alert is triggered an SMS will be sent automatically to this number and confirm via text that their is low rating is received. The alerts fire in real-time, providing you the ability to quickly get notified of the event.</div>',
                    imageUrl: 'assets/images/negativerating.png',
                    imageWidth: 270,
                    timer: 100000,
                    width: 450,
                    imageHeight: 300,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false
                })
                break;
            case 'checkInNotification':
                swal({
                    title: 'Check-In Alert',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">Alerts are a great way to get notified when a there is a checking in by any visitor. Currently, there are two ways to get alerted for checking in, you can enter e-mails (enter after enter email) in the e-mail field and an e-mail will trigger to all the addresses. You can also specify one phone number in the phone number field, when an alert is triggered an SMS will be sent automatically to this number and confirm via text that their is check in by visitor. The alerts fire in real-time, providing you the ability to quickly get notified of the event.</div>',
                    imageUrl: 'assets/images/negativerating.png',
                    imageWidth: 270,
                    timer: 100000,
                    width: 450,
                    imageHeight: 300,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false
                })
                break;
            case 'expressResident':
                swal({
                    title: 'Express Resident',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">Express resident is the way to check-Out/check-In users living in a facility. After enable this feature express resident menu should be displayed on the visitor kiosk.</div>',
                    imageUrl: 'assets/images/express_resident.png',
                    imageWidth: 270,
                    timer: 100000,
                    width: 450,
                    imageHeight: 50,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false
                })
                break;
            case 'disaleReplies':
                swal({
                    title: 'Automated Reply',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">By default, when a message comes in the sender will get a confirmation "We got your response, Thank you, somene will check it shortly!" some locations prefer to disable these automated responses. If you disable the automated reply, the user who send in the text will get no confirmation or automated response; if you leave it enabled the user will get a confirmation per each message they send.</div>',
                    imageUrl: 'assets/images/disable_replies.png',
                    imageWidth: 270,
                    timer: 100000,
                    width: 450,
                    imageHeight: 50,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false
                })
                break;    
            case 'positiveRating':
                swal({
                    title: 'Positive Rating',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">The positive rating follow SMS feature sends an instant message after getting positive rating from visitor. This feature provide you the ability to add online link to sms to get review on online link and you can manage rating according your own criteria.</div>',
                    imageUrl: 'assets/images/positive_rating.png',
                    imageWidth: 270,
                    timer: 100000,
                    width: 450,
                    imageHeight: 380,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false
                })
                break;    
            case 'negativeRating':
                swal({
                    title: 'Negative Rating',
                    html: '<div calss="sweetalert" style="color: #4f4f4f;font-size: 14px; text-align: justify; font-weight: 300; position: relative; float: none; margin: 0;padding: 0 10px; line-height:21px;">The Negative rating follow SMS feature sends an instant message after getting negative rating from visitor. This feature provide you the ability to get feedback or experience of visitor.</div>',
                    imageUrl: 'assets/images/negative_rating.png',
                    imageWidth: 270,
                    timer: 100000,
                    width: 450,
                    imageHeight: 300,
                    imageAlt: 'Custom image',
                    animation: true,
                    allowOutsideClick: false
                })
                break;             
        }
    }

    private ngOnInit() {
        this.user = this.storage.get(this.config.token.userKey);
        if (this.user.role == 'employee') {
            var obj = {
                employeeId: this.user.uid,
            }
            this.employee.getEmployeePermissions(obj).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.permissionData = rs.data;
                }
            })

        }
        this.getCheckOutInterval('minutes');
        this.getLinkSmsInterval('minutes');
        this.getNotificationDetails();
    }

    ngAfterViewInit() {
        $.getMultiScripts = function (arr, path) {
            var _arr = $.map(arr, function (scr) {
                return $.getScript((path || "") + scr);
            });

            _arr.push($.Deferred(function (deferred) {
                $(deferred.resolve);
            }));

            return $.when.apply($, _arr);
        }

        var script_arr = [
            // 'jquery3.2.1.min.js',
            'materialize.min.js',
            'core/libraries/bootstrap.min.js',
            'plugins/visualization/d3/d3.min.js',
            'plugins/visualization/d3/d3_tooltip.js',
            'plugins/forms/styling/switchery.min.js',
            'plugins/forms/styling/uniform.min.js',
            'plugins/forms/selects/bootstrap_multiselect.js',
            'plugins/ui/moment/moment.min.js',
            'plugins/pickers/daterangepicker.js',
            'core/app.js',
            'plugins/ui/ripple.min.js',
            'custom.js'
        ];


        $.getMultiScripts(script_arr, 'assets/js/').done(function () {
            // all scripts loaded
        });


     
    }

























}