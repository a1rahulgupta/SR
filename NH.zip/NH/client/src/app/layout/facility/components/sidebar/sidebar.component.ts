import { Component, EventEmitter } from "@angular/core";
import { AppConfig } from "../../../../core/config/app.config";
import { WebStorage } from "../../../../core/utility/web.storage";
import { Router } from "@angular/router";
import { ToastrService } from 'ngx-toastr';
import { UserService } from "../../../../core/services/user.services";
import { AuthService } from "../../../../core/services/auth.service";
import { EmployeeService } from "../../../../modules/employee/services/employee.services";


declare var jQuery: any;
var popUpObj = null;

@Component({
    selector: 'sidebar-component',
    templateUrl: './view/sidebar.component.html',
    styleUrls: ['./css/sidebar.css'],
    providers: [
        UserService,
        EmployeeService
    ]
})
export class SidebarComponent {
    permissionData: any = {
        visitors: {
            "status": false,
            "visitorsList": false,
            "checkInLogList": false,
            "latestNegativeResponseList": false,
        },
        employee: {
            "status": false,
            "list": false,
        },
        kiosk: {
            "status": false,
            "visitorKiosk": false,
            "patientKiosk": false
        },
        newsFeed: {
            "status": false,
            "list": false
        },
        dashboard: {
            "status": false
        },
        incidentClaimReports: {
            "status": false,
            "allReports": false,
            "myReports": false

        }
    };
    commingsoon: boolean;
    employeeName: string;
    imagePathFacility: string;
    imageEmployeeProfile: string;
    data: any;
    userName: string;
    imagePathEmployee: string;
    kioskMode: boolean;
    public user: any;
    constructor(
        private storage: WebStorage,
        private toaster: ToastrService,
        public auth: AuthService,
        private UserService: UserService,
        private employee: EmployeeService,
        private config: AppConfig,
        private router: Router,
    ) {

        this.UserService.getFacilityProfileById({ data: this.data }).subscribe((result: any) => {
            var rs = result.json();


            if (rs.code == this.config.statusCode.success) {
                this.imagePathFacility = 'assets/upload/profiles/' + rs.data.facLogo;
                this.userName = rs.data.facName;
            }
        });
        this.auth.refreshFacilityProfileData.subscribe(() => {
            this.UserService.getFacilityProfileById({ data: this.data }).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.imagePathFacility = 'assets/upload/profiles/' + rs.data.facLogo;
                    this.userName = rs.data.facName;
                }
            });
        });
        let user = this.storage.get(this.config.token.userKey);
        this.UserService.getEmployeeProfile({ id: user.uid }).subscribe((result: any) => {
            var rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.imageEmployeeProfile = 'assets/upload/profiles/' + rs.data.facilityData.facLogo;
                this.employeeName = rs.data.facilityData.facName;
            }
        });
        this.auth.refreshEmployeeProfileData.subscribe(() => {
            this.UserService.getEmployeeProfile({ id: user.uid }).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.imageEmployeeProfile = 'assets/upload/profiles/' + rs.data.facilityData.facLogo;
                    this.employeeName = rs.data.facilityData.facName;

                }
            });
        });
    }

    ngOnInit() {
        this.user = this.storage.get(this.config.token.userKey);
        if (this.user.role == 'employee') {
            var obj = {
                employeeId: this.user.uid,
            }
            this.employee.getEmployeePermissions(obj).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.permissionData = rs.data;
                }
            })

        }

    }

    public setVisitorKiosk() {
        this.toaster.success("Visitor Kiosk Mode On.");
        setTimeout(() => {
            this.kioskMode = true;
            this.storage.localStore(this.config.storage.KIOSK_MODE, this.kioskMode);
            location.reload();
        }, 500);
    }

}