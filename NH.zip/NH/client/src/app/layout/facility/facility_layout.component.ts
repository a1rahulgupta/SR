import { Component } from "@angular/core";
import { AppConfig } from "../../core/config/app.config";
import { WebStorage } from "../../core/utility/web.storage";
import { Router } from "@angular/router";
import { Socket } from 'ngx-socket-io';
import { ToastrService } from 'ngx-toastr';
import { UserService } from "../../core/services/user.services";
import { VisitorsService } from "../../modules/visitors/service/visitors.service";
import { EmployeeService } from "../../modules/employee/services/employee.services";
import { FacLayoutService } from "./service/facLayout.service";
declare var Notification: any
declare var jQuery: any;
import * as $ from 'jquery';


@Component({
    templateUrl: './facility_layout.component.html',
    styles: [],
    providers: [
        UserService,
        VisitorsService,
        EmployeeService,
        FacLayoutService
    ]
})
export class FacilityLayoutComponent {

    chatBoxShow: boolean = false;
    miniChatBoxCount: boolean = false;
    pagination: boolean = false;
    lengthIndex: number;
    visitorData: object = {};
    arrayLength: number = 0;
    visitorArray = [];
    objVisitor: any = {
        message: [],
        visitorName: '',
        visitedTo: '',
        phoneNumber: '',
        tollFreeNo: '',
        _id: ''
    }
    visitorsId = [];
    permissionData: any;
    user: any;
    visitedTo: any;
    appMessage: any;
    tollFreeNo: any;
    _id: any;
    phoneNumber: any;
    visitorName: any;
    message: any;
    twilioDialoge: boolean;
    io: any;
    isActiveTab: boolean;
    showCustomNot: boolean;
    notification: any;
    replyArea: boolean = false;
    optionsNotification: any = {
        icon: "",
        body: "",
        title: "",
        sound: ""
    };
    kioskMode: any;
    constructor(
        private storage: WebStorage,
        private toaster: ToastrService,
        private UserService: UserService,
        private visitors: VisitorsService,
        private facLayout: FacLayoutService,
        private router: Router,
        private config: AppConfig,
        private socket: Socket,
        private employee: EmployeeService,
    ) {


    }

    public body: any = {};

    public rightArrow(){
        if(this.lengthIndex == this.arrayLength){}else{
            this.lengthIndex = this.lengthIndex + 1;
            this.visitorData = this.visitorArray[this.lengthIndex-1];
        }
    }

    public leftArrow(){
        if(this.lengthIndex == 1){}else{
            this.lengthIndex = this.lengthIndex - 1;
            this.visitorData = this.visitorArray[this.lengthIndex-1];
        }
    }

    public closeChatBox(){
        this.pagination = false;
        this.lengthIndex = 0;
        this.chatBoxShow = false;
        this.miniChatBoxCount = false;
        this.appMessage = '';
        this.visitorData = {};
    }

    ngOnInit() {

        this.user = this.storage.get(this.config.token.userKey);
        if (this.user.role == 'employee') {
            var obj = {
                employeeId: this.user.uid,
            }
            this.employee.getEmployeePermissions(obj).subscribe((result) => {
                let rs = result.json();
                if (rs.code == this.config.statusCode.success) {
                    this.permissionData = rs.data;
                }
            })

        }
        this.miniChatBoxCount = false;
        this.kioskMode = this.storage.get(this.config.storage.KIOSK_MODE);
        this.socket.on('visitorCheckInNotify', (data: any) => {
            if (this.kioskMode == false) {
                this.notify(data);
            }
        });

        this.socket.on('newChatMessage', (data: any) => {
            if (this.kioskMode == false) {
                this.notifyNewMessage(data);
            }
          });
        // if(this.user.role =='facility_admin' || this.user.role == 'employee'){
        //     this.socket.on('twilioSmsPopUp', (data: any) => {
        //         this.twilioDialoge = true;
        //         this.message = data.message;
        //         this.visitorName = data.visitorName;
        //         this.visitedTo = data.visitedTo;
        //         this.phoneNumber = data.from;
        //         this.tollFreeNo = data.to;
        //         this._id = data.visitorId;
        //     });
        // }
        this.visitorArray = [];
        if(this.user.role =='facility_admin' || this.user.role == 'employee'){
            var found = 0;
            this.socket.on('twilioSmsPopUp', (data: any) => {
                this.visitorsId.forEach(function (visitorId) {
                    if (visitorId == data.visitorId) {
                        found = 1;
                    }
                });
                if (found == 0) {
                    this.visitorsId.push(data.visitorId); 
                    this.body.visitorsId = this.visitorsId;
                    this.facLayout.getPopupMessages(this.body).subscribe((result) => {
                        let rs = result.json();
                        if (rs.code == this.config.statusCode.success && rs.data.visitorsArray.length>0) {
                            this.chatBoxShow = true;
                            this.visitorArray = rs.data.visitorsArray; 
                            this.visitorsId = rs.data.visitorsIds;
                            if(this.visitorArray.length > 1){
                                this.pagination = true;
                            }
                            this.visitorData = rs.data.visitorsArray[0];
                            this.lengthIndex = 0 + 1 ;
                            console.log("rasrasrarsasdrfasfasrd", this.visitorData);
                            this.arrayLength = (rs.data.visitorsArray).length;
                            // this.chatBox.nativeElement.show();
                        } else { 
                            this.chatBoxShow = false;
                            this.miniChatBoxCount = false;
                            this.visitorArray = rs.data.visitorsArray; 
                            this.visitorsId = rs.data.visitorsIds;
                            this.visitorData = rs.data.visitorsArray[0];
                            this.lengthIndex = 0;
                            this.arrayLength = (rs.data.visitorsArray).length;
                            this.pagination = false;
                        }
                    })
                }else{
                    this.body.visitorsId = this.visitorsId;
                    this.facLayout.getPopupMessages(this.body).subscribe((result) => {
                        let rs = result.json();
                        if (rs.code == this.config.statusCode.success && rs.data.visitorsArray.length>0) {
                            this.chatBoxShow = true;
                            this.visitorArray = rs.data.visitorsArray;
                            this.visitorsId = rs.data.visitorsIds;
                            if(this.visitorArray.length > 1){
                                this.pagination = true;
                            }
                            this.visitorData = rs.data.visitorsArray[0];
                            this.lengthIndex = 0 + 1 ;
                            console.log("rasrasrarsasdrfasfasrd", this.visitorData);
                            this.arrayLength = (rs.data.visitorsArray).length;
                        } else { 
                            this.chatBoxShow = false;
                            this.miniChatBoxCount = false;
                            this.visitorArray = rs.data.visitorsArray; 
                            this.visitorsId = rs.data.visitorsIds;
                            this.visitorData = rs.data.visitorsArray[0];
                            this.lengthIndex = 0;
                            this.arrayLength = (rs.data.visitorsArray).length;
                            this.pagination = false;
                        }
                    })
                }
                this.arrayLength = this.visitorsId.length;
                console.log("this.visitorsId", this.visitorsId);
            });
        }
    }

    sendMessageOnPopup() {
        let data = {
            text: this.appMessage,
            to: this.phoneNumber,
            from: this.tollFreeNo
        }
        this.visitors.sendMessage(data).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                this.appMessage = '';
            } else { }
        })

    }

    sendMessageOnChatPopup(visitorData){
        visitorData.appMessage = this.appMessage
        this.facLayout.sendMessageOnChatPopup(visitorData).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                var index = this.visitorsId.indexOf(visitorData._id);
                if (index > -1) {
                    this.visitorsId.splice(index, 1);
                    if(this.visitorsId.length>0){                                                                                           
                        this.body.visitorsId = this.visitorsId;
                        this.facLayout.getPopupMessages(this.body).subscribe((result) => {
                            let rs = result.json();
                            if (rs.code == this.config.statusCode.success && rs.data.visitorsArray.length>0) {
                                this.chatBoxShow = true;
                                this.visitorArray = rs.data.visitorsArray; 
                                this.visitorsId = rs.data.visitorsIds;
                                this.appMessage = '';
                                if(this.visitorArray.length > 1){
                                    this.pagination = true;
                                }else{
                                    this.pagination = false;
                                }
                                this.visitorData = rs.data.visitorsArray[0];
                                this.lengthIndex = 0 + 1 ;
                                this.arrayLength = (rs.data.visitorsArray).length;
                            } else { 
                                this.chatBoxShow = false;
                                this.miniChatBoxCount = false;
                                this.visitorArray = rs.data.visitorsArray; 
                                this.visitorsId = rs.data.visitorsIds;
                                this.visitorData = rs.data.visitorsArray[0];
                                this.lengthIndex = 0;
                                this.arrayLength = (rs.data.visitorsArray).length;
                                this.pagination = false;
                            }
                        })
                    }else{
                        this.chatBoxShow = false;
                        this.miniChatBoxCount = false;
                    }
                }
            } else { }
        })
    }

    appMessageEmpty() {
        this.appMessage = '';
    }
    onCellClick(data: any) {
        this.router.navigate(['/facility/visitors/edit', data._id]);
        this.facLayout.viewMessageOnChatPopup(data).subscribe((result) => {
            let rs = result.json();
            if (rs.code == this.config.statusCode.success) {
                var index = this.visitorsId.indexOf(data._id);
                if (index > -1) {
                    this.visitorsId.splice(index, 1);
                    if(this.visitorsId.length>0){                                                                                           
                        this.body.visitorsId = this.visitorsId;
                        this.facLayout.getPopupMessages(this.body).subscribe((result) => {
                            let rs = result.json();
                            if (rs.code == this.config.statusCode.success && rs.data.visitorsArray.length>0) {
                                // this.chatBoxShow = true;
                                this.visitorArray = rs.data.visitorsArray; 
                                this.visitorsId = rs.data.visitorsIds;
                                this.appMessage = '';
                                if(this.visitorArray.length > 1){
                                    this.pagination = true;
                                }else{
                                    this.pagination = false;
                                }
                                this.visitorData = rs.data.visitorsArray[0];
                                this.lengthIndex = 0 + 1 ;
                                this.arrayLength = (rs.data.visitorsArray).length;
                            } else { 
                                this.chatBoxShow = false;
                                this.miniChatBoxCount = false;
                                this.visitorArray = rs.data.visitorsArray; 
                                this.visitorsId = rs.data.visitorsIds;
                                this.visitorData = rs.data.visitorsArray[0];
                                this.lengthIndex = 0;
                                this.arrayLength = (rs.data.visitorsArray).length;
                                this.pagination = false;
                            }
                        })
                    }else{
                        this.chatBoxShow = false;
                        this.miniChatBoxCount = false;
                    }
                }
            } else { }
        })


    }

    notify(data) {
        let user = this.storage.get(this.config.token.userKey);
        let facId = user.facId;
        console.log("facId == data.facilityData._id", facId == data.facilityData._id);
        if (facId == data.facilityData._id) {
            var options = {
                icon: 'assets/upload/profiles/' + data.facilityData.facLogo,
                body: data.visitorData.firstName + ' ' + data.visitorData.lastName + " checking in  and  visited for: " + data.visitorData.visitedTo,
                sound: "assets/images/pnotify/inquisitiveness.mp3",
            }
            this.optionsNotification = options;
            this.optionsNotification.title = data.facilityData.facName;
            if (Notification.permission === "granted") {
                this.notification = new Notification(data.facilityData.facName, options);
                setTimeout(this.closeNotification, 10000);
            }
            else if (Notification.permission !== "denied") {
                Notification.requestPermission((permission) => {
                    if (permission === "granted") {
                        this.notification = new Notification(data.facilityData.facName, options);
                        setTimeout(this.closeNotification, 10000);
                    } else {
                        this.showCustomNot = true;
                        setTimeout(() => {
                            this.showCustomNot = false;
                        }, 10000);
                    }
                });
            } else {
                //IE 11 and Mobiles/Tabs browsers do not support Notification. Therefore, displays custom Notification instead.
                this.showCustomNot = true;
                setTimeout(() => {
                    this.showCustomNot = false;
                }, 10000);
            }
            this.saveNotification(data);

        }

    }

    notifyNewMessage(data) {
        let user = this.storage.get(this.config.token.userKey);
        let userFacId = user.userFacId;
        console.log("facId == data.facilityData._id", userFacId == data.userFacId);
        if (userFacId == data.userFacId && user.uid != data.sentBy) {
            var options = {
                icon: 'assets/upload/profiles/' + data.image,
                body: data.message,
                sound: "assets/images/pnotify/inquisitiveness.mp3",
            }
            this.optionsNotification = options;
            this.optionsNotification.title = data.userName;
            if (Notification.permission === "granted") {
                this.notification = new Notification('test facility', options);
                setTimeout(this.closeNotification, 10000);
            }
            else if (Notification.permission !== "denied") {
                Notification.requestPermission((permission) => {
                    if (permission === "granted") {
                        this.notification = new Notification('test facility', options);
                        setTimeout(this.closeNotification, 10000);
                    } else {
                        this.showCustomNot = true;
                        setTimeout(() => {
                            this.showCustomNot = false;
                        }, 10000);
                    }
                });
            } else {
                //IE 11 and Mobiles/Tabs browsers do not support Notification. Therefore, displays custom Notification instead.
                this.showCustomNot = true;
                setTimeout(() => {
                    this.showCustomNot = false;
                }, 10000);
            }
            // this.saveNotification(data);

        }

    }

    saveNotification(data) {
        console.log("saveNotification", data);
        this.UserService.saveNotification(data).subscribe((result: any) => {
            var rs = result.json();
        })
    }
    closeNotification() {
        if (this.notification)
            this.notification.close.bind(this.notification)
    }
}

