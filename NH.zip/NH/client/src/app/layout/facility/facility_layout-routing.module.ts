import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AuthGuard } from "../../core/guards/auth.guard";
import { FacilityLayoutComponent } from "./facility_layout.component";

const routes: Routes = [
    {
        path: '',
        component: FacilityLayoutComponent,
        canActivateChild: [AuthGuard],
        children: [
            {
                path: 'employee',
                loadChildren: 'app/modules/employee/employee.module#EmployeeModule'
            },
            {
                path: 'patient_feedback',
                loadChildren: 'app/modules/patient_feedback/patient_feedback.module#PatientFeedbackModule'
            },
            {
                path: 'employee_feedback',
                loadChildren: 'app/modules/employee_feedback/employee_feedback.module#EmployeeFeedbackModule'
            },
            {
                path: '',
                loadChildren: 'app/modules/fac_dashboard/fac.module#FacDashboardModule'
            },
            {
                path: 'profile',
                loadChildren: 'app/modules/fac_dashboard/fac.module#FacDashboardModule'
            },
            {
                path: 'changePassword',
                loadChildren: 'app/modules/fac_dashboard/fac.module#FacDashboardModule'
            },
            {
                path: 'employeeChangePassword',
                loadChildren: 'app/modules/fac_dashboard/fac.module#FacDashboardModule'
            },
            {
                path: 'employeeProfile',
                loadChildren: 'app/modules/fac_dashboard/fac.module#FacDashboardModule'
            },
            {
                path: 'rss_feed',
                loadChildren: 'app/modules/rssFeed/rssFeed.module#RssFeedModule'
            },
            {
                path: 'chat',
                loadChildren: 'app/modules/chat/chat.module#ChatModule'
            },
            {
                path: 'reviews',
                loadChildren: 'app/modules/reviews/reviews.module#ReviewsModule'
            },
            {
                path: 'visitorKiosk',
                loadChildren: 'app/modules/visitor-kiosk/visitorKiosk.module#VisitorKioskModule'
            },
            {
                path: 'visitors',
                loadChildren: 'app/modules/visitors/visitors.module#VisitorsModule'
            },
            {
                path: 'incidentReports',
                loadChildren: 'app/modules/incident_reports/incident_report.module#IncidentReportModule'
            }

        ]
    }
]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class FacilityLayoutRoutingModule {

}