import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
    BsDropdownModule,
} from 'ngx-bootstrap';

import {
    ConfirmDialogModule,
    DialogModule,
    ConfirmationService,
    ChipsModule
} from 'primeng/primeng';

import { FooterComponent } from "./components/footer/footer.component";
import { SidebarComponent } from "./components/sidebar/sidebar.component";
import { HeaderComponent } from "./components/header/header.component";
import { FacilityLayoutComponent } from "./facility_layout.component";
import { FacilityLayoutRoutingModule } from "./facility_layout-routing.module"
import { TagsInputModule } from 'ngx-tags-input/dist';
import { AngularDraggableModule } from "angular2-draggable";
// import { SweetAlertService } from 'ngx-sweetalert2';


@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        BsDropdownModule.forRoot(),
        CommonModule,
        RouterModule,
        ConfirmDialogModule,
        FacilityLayoutRoutingModule,
        DialogModule,
        ChipsModule,
        AngularDraggableModule,
        TagsInputModule.forRoot()
    ],
    declarations: [
        FacilityLayoutComponent,
        HeaderComponent,
        SidebarComponent,
        FooterComponent
    ],
    providers: [
        ConfirmationService,
        // SweetAlertService
    ]
})
export class FacilityLayoutModule {

}